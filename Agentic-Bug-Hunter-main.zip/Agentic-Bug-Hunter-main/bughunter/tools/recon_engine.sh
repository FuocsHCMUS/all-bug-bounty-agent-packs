#!/bin/bash
# =============================================================================
# Enhanced Recon Engine
# Full reconnaissance pipeline for bug bounty targets
# Usage: ./recon_engine.sh <target-domain> [--quick]
# =============================================================================

set -o pipefail

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log_ok()    { echo -e "${GREEN}[+]${NC} $1"; }
log_err()   { echo -e "${RED}[-]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
log_info()  { echo -e "${CYAN}[*]${NC} $1"; }
log_step()  { echo -e "    ${CYAN}[>]${NC} $1"; }
log_done()  { echo -e "    ${GREEN}[✓]${NC} $1"; }
log_vuln()  { echo -e "    ${RED}[VULN]${NC} $1"; }

TARGET="${1:?Usage: $0 <target> [--quick]  (target = FQDN, IP, CIDR, or path to a file of domains/hosts)}"
QUICK_MODE="${2:-}"
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"

# Auth-aware hunting: load BBHUNT_AUTH_HEADERS / BBHUNT_SESSION_ID into
# BB_AUTH_ARGS=(-H 'Name: val' ...). Empty session = no-op.
# shellcheck source=tools/_auth_helper.sh
. "$(dirname "$0")/_auth_helper.sh"

# OS-specific install hints for missing tools (dep_install_hint / warn_missing).
# shellcheck source=tools/_dep_hint.sh
. "$(dirname "$0")/_dep_hint.sh"

# Domain-list mode: if the target is a readable regular file, treat its
# contents as a pre-resolved scope list (one host per line, # comments OK).
# Useful for programs without wildcards where subdomain enum is wasted work.
# Output dir is derived from the file basename so multiple lists don't collide.
if [ -f "$TARGET" ] && [ -r "$TARGET" ]; then
    TARGET_TYPE="list"
    LIST_FILE="$TARGET"
    TARGET="$(basename "$LIST_FILE")"
    TARGET="${TARGET%.*}"
fi

# ── Normalize a URL/host/host:port into a bare host (+ optional port) ─────────
# Scanners need `9am.io`, not `https://9am.io/`; without this the pipeline ran
# `nmap https://9am.io/` (0 hosts) and wrote output to `recon/https:/9am.io`.
# Mirrors tools/target_normalize.py (cross-checked in tests). Sets globals
# TARGET (bare host, lowercased) and TARGET_PORT (empty when none). Skipped for
# file-list targets, whose TARGET is already a basename.
TARGET_PORT=""
_normalize_target() {
    local s="$1"
    # trim whitespace
    s="${s#"${s%%[![:space:]]*}"}"; s="${s%"${s##*[![:space:]]}"}"
    # strip scheme://
    shopt -s nocasematch
    [[ "$s" =~ ^[a-z][a-z0-9+.-]*:// ]] && s="${s#*://}"
    shopt -u nocasematch
    # drop path/query/fragment
    s="${s%%[/?#]*}"
    # userinfo user:pass@host -> host
    s="${s##*@}"
    local host="$s" port=""
    if [[ "$s" == \[*\]* ]]; then                 # [IPv6] or [IPv6]:port
        host="${s#\[}"; host="${host%%\]*}"
        local rest="${s##*\]}"
        [[ "$rest" =~ ^:([0-9]+)$ ]] && port="${BASH_REMATCH[1]}"
    elif [[ "$s" == *:*:* ]]; then                 # bare IPv6, leave intact
        host="$s"
    elif [[ "$s" =~ ^(.+):([0-9]+)$ ]]; then       # host:port
        host="${BASH_REMATCH[1]}"; port="${BASH_REMATCH[2]}"
    fi
    while [[ "$host" == *. ]]; do host="${host%.}"; done   # all trailing dots (match Python rstrip('.'))
    host="$(printf '%s' "$host" | tr '[:upper:]' '[:lower:]')"
    TARGET="$host"; TARGET_PORT="$port"
}
# Normalize hostnames/URLs only. A CIDR must keep its /NN mask (normalization
# would strip it as a path) and a file-list target is already a basename.
if [ "${TARGET_TYPE:-}" != "list" ] && [ "${TARGET_TYPE:-}" != "cidr" ] \
   && ! [[ "$TARGET" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+$ ]]; then
    _normalize_target "$TARGET"
fi

RECON_DIR="${RECON_OUT_DIR:-$BASE_DIR/recon/$TARGET}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
THREADS="${BB_THREADS:-50}"
RATE_LIMIT="${BB_RATE_LIMIT:-150}"  # requests per second

# shellcheck source=tools/banner.sh
. "$(dirname "$0")/banner.sh"
print_banner "Recon Engine · Bug Bounty" "$TARGET" \
    "Subdomain enum|subfinder · amass · crt.sh · wayback" \
    "Live probe|httpx + dnsx with tech fingerprinting" \
    "URL crawl|katana · gau · waybackurls" \
    "Templates|nuclei sweep (optional)"

# Prefer Go tools in ~/go/bin
export PATH="$HOME/go/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

# macOS compatibility: GNU timeout may not exist; use gtimeout or passthrough
if ! command -v timeout &>/dev/null; then
    if command -v gtimeout &>/dev/null; then
        timeout() { gtimeout "$@"; }
        export -f timeout
    else
        timeout() { shift; "$@"; }
        export -f timeout
    fi
fi

# ── Detect target type (passed from hunt.py or auto-detected here) ────────────
# "local" = loopback / RFC-1918 private / *.local — no public subdomain recon.
_detect_target_type() {
    local t="$1"
    # CIDR first so 10.0.0.0/24 is a range, not a single "local" host.
    if   [[ "$t" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+$ ]]; then echo "cidr"
    elif [[ "$t" == "localhost" || "$t" == "ip6-localhost" || "$t" == "::1" ]]; then echo "local"
    elif [[ "$t" == *.localhost || "$t" == *.local ]];         then echo "local"
    elif [[ "$t" =~ ^127\. ]];                                 then echo "local"
    elif [[ "$t" =~ ^10\. ]];                                  then echo "local"
    elif [[ "$t" =~ ^192\.168\. ]];                            then echo "local"
    elif [[ "$t" =~ ^172\.(1[6-9]|2[0-9]|3[01])\. ]];          then echo "local"
    elif [[ "$t" =~ ^169\.254\. ]];                            then echo "local"
    elif [[ "$t" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]];        then echo "ip"
    else echo "domain"; fi
}

_expand_cidr_hosts() {
    local target="$1"
    python3 - "$target" <<'PY'
import ipaddress
import itertools
import sys

network = ipaddress.ip_network(sys.argv[1], strict=False)
hosts = [str(host) for host in itertools.islice(network.hosts(), 254)]
if not hosts:
    hosts = [str(network.network_address)]
print("\n".join(hosts))
PY
}
TARGET_TYPE="${TARGET_TYPE:-$(_detect_target_type "$TARGET")}"

# Refuse a target that normalized away or carries path-traversal characters, so
# $RECON_DIR can never point outside recon/ (belt-and-suspenders with the
# Python-side safe_target_dirname check). A CIDR legitimately contains '/'.
if [ "$TARGET_TYPE" != "list" ] && [ "$TARGET_TYPE" != "cidr" ]; then
    if [ -z "$TARGET" ] || [ "$TARGET" = "." ] || [[ "$TARGET" == */* ]] || [[ "$TARGET" == *..* ]]; then
        echo "[-] Refusing unsafe/empty target '$1' after normalization" >&2
        exit 2
    fi
fi

# Debug/test hook: print the parsed target and exit before doing any scanning.
#   recon_engine.sh <target> --normalize-only
if [ "$QUICK_MODE" = "--normalize-only" ] || [ "${BB_NORMALIZE_ONLY:-0}" = "1" ]; then
    printf 'host=%s\nport=%s\ntype=%s\n' "$TARGET" "$TARGET_PORT" "$TARGET_TYPE"
    exit 0
fi

# For IP/CIDR/local: always scope-lock — no subdomain enum needed
if [ "$TARGET_TYPE" = "ip" ] || [ "$TARGET_TYPE" = "cidr" ] || [ "$TARGET_TYPE" = "local" ]; then
    SCOPE_LOCK=1
fi

# Resolve an absolute path to the *ProjectDiscovery* httpx, NOT the unrelated
# Python httpx CLI which Brew installs at /opt/homebrew/bin/httpx and which
# silently rejects PD flags like -silent / -tech-detect with "No such option"
# — producing 0 live hosts on macs where Brew's bin precedes ~/go/bin on PATH
# despite the export above.
#
# The PD binary's `-version` output contains the literal substring
# "projectdiscovery"; the Python httpx CLI doesn't. Fall back to the bare
# `httpx` token when no PD binary is found anywhere so the existing
# command-not-found error path still fires with a clear message.
_resolve_pd_httpx() {
    local cand
    for cand in \
        "$HOME/go/bin/httpx" \
        "/opt/homebrew/bin/httpx" \
        "/usr/local/bin/httpx" \
        "$(command -v httpx 2>/dev/null)"; do
        [ -z "$cand" ] && continue
        [ -x "$cand" ] || continue
        if "$cand" -version 2>&1 | grep -qi "projectdiscovery"; then
            echo "$cand"; return 0
        fi
    done
    echo "httpx"
    return 1
}
HTTPX_BIN="$(_resolve_pd_httpx || true)"
if ! "$HTTPX_BIN" -version 2>&1 | grep -qi "projectdiscovery"; then
    echo "[!] WARNING: ProjectDiscovery httpx not found on PATH. Live-host probing will fail." >&2
    dep_install_hint httpx >&2
fi
export HTTPX_BIN

mkdir -p "$RECON_DIR"/{subdomains,live,ports,urls,js,dirs,params}

# Safety net: merge partial subdomain results on early exit (watchdog kill, etc.)
_emergency_merge_subs() {
    if [ ! -s "$RECON_DIR/subdomains/all.txt" ] && \
       ls "$RECON_DIR/subdomains/"*.txt &>/dev/null; then
        cat "$RECON_DIR/subdomains/"*.txt 2>/dev/null \
            | tr '[:upper:]' '[:lower:]' \
            | sed 's/^\*\.//' \
            | grep -E "^[a-zA-Z0-9._-]+\.[a-zA-Z]{2,}$" \
            | sort -u > "$RECON_DIR/subdomains/all.txt" 2>/dev/null || true
    fi
}
trap _emergency_merge_subs EXIT

echo "============================================="
echo "  Recon Engine — $TARGET"
echo "  Output: $RECON_DIR/"
echo "  Mode: $([ "$QUICK_MODE" = "--quick" ] && echo "Quick" || echo "Full")"
echo "  Time: $(date)"
bb_auth_active && bb_auth_banner
echo "============================================="
echo ""

# ============================================================
# DNS wildcard pre-check — surfaces wildcard zones BEFORE Phase 1
# brute-forces 5,000+ candidates that all collapse to a single IP.
# Three random labels are queried under the apex; if 2+ resolve, the
# zone has a wildcard A record. Persists `subdomains/wildcard_dns.json`
# so a downstream pass can filter brute-forced subs whose A record
# matches `WILDCARD_DNS_IP`, saving 10+ min of dead-host probing on
# CDN-fronted brands and parked-domain marketing zones.
# Skipped for IP/CIDR/list targets (no apex to dork) and when `dig`
# isn't on PATH.
# ============================================================
_detect_dns_wildcard() {
    local apex="$1" hits=0 r1 r2 r3
    [ -z "$apex" ] && return
    [[ "$apex" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+ ]] && return
    if ! command -v dig &>/dev/null; then return; fi
    r1=$(dig +short +time=2 +tries=1 "bb-no-such-$RANDOM-$RANDOM.$apex" A 2>/dev/null | head -1)
    r2=$(dig +short +time=2 +tries=1 "bb-no-such-$RANDOM-$RANDOM.$apex" A 2>/dev/null | head -1)
    r3=$(dig +short +time=2 +tries=1 "bb-no-such-$RANDOM-$RANDOM.$apex" A 2>/dev/null | head -1)
    [ -n "$r1" ] && hits=$((hits+1))
    [ -n "$r2" ] && hits=$((hits+1))
    [ -n "$r3" ] && hits=$((hits+1))
    if [ "$hits" -ge 2 ]; then
        export WILDCARD_DNS=1
        export WILDCARD_DNS_IP="$r1"
        log_warn "DNS wildcard detected on $apex (random labels resolved to $r1) — brute-forced subs will collapse to wildcard_ip"
        cat > "$RECON_DIR/subdomains/wildcard_dns.json" <<EOF
{"target":"$apex","wildcard":true,"wildcard_ip":"${WILDCARD_DNS_IP:-}","detected_at":"$(date -u +%Y-%m-%dT%H:%M:%SZ)","note":"random labels resolved — brute-forced subs that resolve to wildcard_ip should be filtered before httpx live-probe to avoid wasted dirsearch on dead hosts."}
EOF
    fi
}
if [ "${TARGET_TYPE:-domain}" = "domain" ]; then
    _detect_dns_wildcard "$TARGET"
fi

# ============================================================
# Phase 1: Subdomain Enumeration (or Host Discovery for IP/CIDR)
# ============================================================
log_info "Phase 1: Subdomain Enumeration"

# ── For domain-list targets: load the file directly, skip enum entirely ───
if [ "$TARGET_TYPE" = "list" ]; then
    log_info "Domain-list target — loading $LIST_FILE (skipping subdomain enum)"
    grep -vE '^[[:space:]]*(#|$)' "$LIST_FILE" \
        | tr -d '\r' \
        | tr '[:upper:]' '[:lower:]' \
        | sed 's/^\*\.//' \
        | awk 'NF' \
        | sort -u > "$RECON_DIR/subdomains/all.txt"
    LIST_COUNT=$(wc -l < "$RECON_DIR/subdomains/all.txt" 2>/dev/null || echo 0)
    if [ "$LIST_COUNT" -eq 0 ]; then
        log_err "Domain list $LIST_FILE has no usable entries — aborting"
        exit 1
    fi
    log_ok "Loaded $LIST_COUNT host(s) from list"
    SCOPE_LOCK=1
elif [ "$TARGET_TYPE" = "cidr" ]; then
    log_info "CIDR target — running nmap ping sweep to discover live hosts"
    if command -v nmap &>/dev/null; then
        nmap -sn "$TARGET" -oG - 2>/dev/null \
            | awk '/Up$/{print $2}' \
            > "$RECON_DIR/subdomains/all.txt" || true
        LIVE_COUNT=$(wc -l < "$RECON_DIR/subdomains/all.txt" 2>/dev/null || echo 0)
        if [ "$LIVE_COUNT" -eq 0 ]; then
            log_warn "nmap did not identify live hosts — expanding the CIDR locally for downstream probing"
            _expand_cidr_hosts "$TARGET" > "$RECON_DIR/subdomains/all.txt"
        fi
        log_ok "CIDR sweep: $(wc -l < "$RECON_DIR/subdomains/all.txt") live host(s) discovered"
    else
        log_warn "nmap not installed — expanding the CIDR locally for downstream probing"
        _expand_cidr_hosts "$TARGET" > "$RECON_DIR/subdomains/all.txt"
    fi
    # Skip all subdomain enum tools — jump straight to live host probing
elif [ "$TARGET_TYPE" = "ip" ] || [ "$TARGET_TYPE" = "local" ]; then
    if [ "$TARGET_TYPE" = "local" ]; then
        log_info "Local/private target — skipping subdomain enum, crt.sh and wayback (no public data)"
    else
        log_info "Single IP target — skipping subdomain enumeration"
    fi
    # Seed the live-probe list with the exact host[:port] so httpx hits the
    # app's port (e.g. localhost:3000) instead of only 80/443.
    echo "${TARGET}${TARGET_PORT:+:$TARGET_PORT}" > "$RECON_DIR/subdomains/all.txt"
else

# Subfinder (passive, fast)
if command -v subfinder &>/dev/null; then
    log_step "Running subfinder..."
    subfinder -d "$TARGET" -silent -all -t 50 -o "$RECON_DIR/subdomains/subfinder.txt" 2>/dev/null || true
    log_done "subfinder: $(wc -l < "$RECON_DIR/subdomains/subfinder.txt" 2>/dev/null || echo 0) subdomains"
else
    warn_missing subfinder "subdomain enumeration"
fi

# Amass (passive)
if command -v amass &>/dev/null && [ "$QUICK_MODE" != "--quick" ]; then
    log_step "Running amass (passive, 5min timeout)..."
    timeout 300 amass enum -passive -d "$TARGET" -o "$RECON_DIR/subdomains/amass.txt" 2>/dev/null || true
    # Ensure amass output file exists even if amass failed
    [ ! -f "$RECON_DIR/subdomains/amass.txt" ] && touch "$RECON_DIR/subdomains/amass.txt"
    log_done "amass: $(wc -l < "$RECON_DIR/subdomains/amass.txt" 2>/dev/null || echo 0) subdomains"
else
    [ "$QUICK_MODE" = "--quick" ] && log_warn "Skipping amass (quick mode)"
fi

# crt.sh (certificate transparency)
log_step "Querying crt.sh..."
curl -s "https://crt.sh/?q=%25.$TARGET&output=json" 2>/dev/null \
    | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    names = set()
    for entry in data:
        for name in entry.get('name_value', '').split('\n'):
            name = name.strip().lower()
            if name and '*' not in name and name.endswith('.$TARGET'):
                names.add(name)
            elif name and '*' not in name and '.' in name:
                names.add(name)
    for n in sorted(names):
        print(n)
except: pass
" > "$RECON_DIR/subdomains/crtsh.txt" 2>/dev/null || true
log_done "crt.sh: $(wc -l < "$RECON_DIR/subdomains/crtsh.txt" 2>/dev/null || echo 0) subdomains"

# Wayback subdomains
log_step "Querying Wayback Machine for subdomains..."
curl -s "https://web.archive.org/cdx/search/cdx?url=*.$TARGET/*&output=text&fl=original&collapse=urlkey" 2>/dev/null \
    | sed -nE "s|.*://([a-zA-Z0-9._-]+\.$TARGET).*|\1|p" \
    | sort -u > "$RECON_DIR/subdomains/wayback_subs.txt" 2>/dev/null || true
log_done "wayback: $(wc -l < "$RECON_DIR/subdomains/wayback_subs.txt" 2>/dev/null || echo 0) subdomains"

# Merge and deduplicate all subdomains
cat "$RECON_DIR/subdomains/"*.txt 2>/dev/null | sort -u > "$RECON_DIR/subdomains/all.txt"
TOTAL_SUBS=$(wc -l < "$RECON_DIR/subdomains/all.txt" 2>/dev/null || echo 0)
log_ok "Total unique subdomains: $TOTAL_SUBS"

# Always include the seed host itself: deep (4+-level) hostnames, DNS-only
# zones and internal names return nothing from passive enum, and the app
# often lives exactly on the seed (mirrors the ip/local seeding above).
echo "${TARGET}${TARGET_PORT:+:$TARGET_PORT}" >> "$RECON_DIR/subdomains/all.txt"
sort -u -o "$RECON_DIR/subdomains/all.txt" "$RECON_DIR/subdomains/all.txt"
TOTAL_SUBS=$(wc -l < "$RECON_DIR/subdomains/all.txt" 2>/dev/null || echo 0)
log_ok "Seed host included; probe list now: $TOTAL_SUBS host(s)"

fi  # end of domain-only subdomain enum block

# ============================================================
# Phase 2: HTTP Probing
# ============================================================
echo ""
log_info "Phase 2: HTTP Probing"

if [ -x "$HTTPX_BIN" ] && [ -s "$RECON_DIR/subdomains/all.txt" ]; then
    log_step "Probing with httpx (status, title, tech, content-length)..."
    # Scope safety: when scope enforcement is active (SCOPE_ENFORCED=1, exported
    # by tools/hunt.py run_recon whenever a ScopeChecker is configured — always
    # true on the desktop agent path), do NOT follow redirects. An in-scope host
    # can 302 to an out-of-scope host, and httpx would follow it and put traffic
    # on the wire toward a host outside the program allowlist. Redirects are
    # still visible via the status code + Location; we just don't fetch them.
    HTTPX_REDIRECT_ARGS=(-follow-redirects)
    if [ "${SCOPE_ENFORCED:-0}" = "1" ]; then
        HTTPX_REDIRECT_ARGS=()
        log_info "Scope enforcement on: httpx redirect-following disabled (no off-scope hops)"
    fi
    "$HTTPX_BIN" -l "$RECON_DIR/subdomains/all.txt" \
        -silent \
        -status-code \
        -title \
        -tech-detect \
        -content-length \
        ${HTTPX_REDIRECT_ARGS[@]+"${HTTPX_REDIRECT_ARGS[@]}"} \
        -threads "$THREADS" \
        -rate-limit "$RATE_LIMIT" \
        ${BB_AUTH_ARGS[@]+"${BB_AUTH_ARGS[@]}"} \
        -o "$RECON_DIR/live/httpx_full.txt" 2>/dev/null || true

    # Extract just the URLs for other tools
    awk '{print $1}' "$RECON_DIR/live/httpx_full.txt" > "$RECON_DIR/live/urls.txt" 2>/dev/null || true

    LIVE_COUNT=$(wc -l < "$RECON_DIR/live/urls.txt" 2>/dev/null || echo 0)
    log_done "Live hosts: $LIVE_COUNT"

    # Separate by status code
    grep '\[200\]' "$RECON_DIR/live/httpx_full.txt" > "$RECON_DIR/live/status_200.txt" 2>/dev/null || true
    grep '\[30[12]\]' "$RECON_DIR/live/httpx_full.txt" > "$RECON_DIR/live/status_3xx.txt" 2>/dev/null || true
    grep '\[403\]' "$RECON_DIR/live/httpx_full.txt" > "$RECON_DIR/live/status_403.txt" 2>/dev/null || true
    grep '\[401\]' "$RECON_DIR/live/httpx_full.txt" > "$RECON_DIR/live/status_401.txt" 2>/dev/null || true

    log_done "200 OK: $(wc -l < "$RECON_DIR/live/status_200.txt" 2>/dev/null || echo 0)"
    log_done "3xx Redirect: $(wc -l < "$RECON_DIR/live/status_3xx.txt" 2>/dev/null || echo 0)"
    log_done "403 Forbidden: $(wc -l < "$RECON_DIR/live/status_403.txt" 2>/dev/null || echo 0)"
    log_done "401 Auth Required: $(wc -l < "$RECON_DIR/live/status_401.txt" 2>/dev/null || echo 0)"
else
    if ! [ -x "$HTTPX_BIN" ]; then
        warn_missing httpx "HTTP probing"
    else
        log_warn "No hosts to probe (empty subdomains/all.txt) — skipping HTTP probing"
    fi
fi

# ============================================================
# Phase 3: Port Scanning
# ============================================================
echo ""
log_info "Phase 3: Port Scanning"

if command -v nmap &>/dev/null; then
    log_step "Running nmap (top 1000 ports) on $TARGET..."
    nmap -sV --top-ports 1000 -T4 --open "$TARGET" \
        -oN "$RECON_DIR/ports/nmap_results.txt" \
        -oG "$RECON_DIR/ports/nmap_greppable.txt" 2>/dev/null || true
    log_done "Nmap scan complete"

    # Extract open ports (macOS compatible - no grep -P)
    grep "open" "$RECON_DIR/ports/nmap_greppable.txt" 2>/dev/null \
        | sed -nE 's/.*[^0-9]([0-9]+)\/open.*/\1\/open/p' \
        | sort -u > "$RECON_DIR/ports/open_ports.txt" 2>/dev/null || true
    log_done "Open ports: $(wc -l < "$RECON_DIR/ports/open_ports.txt" 2>/dev/null || echo 0)"
else
    warn_missing nmap "port scan"
fi

# ============================================================
# Phase 4: URL Collection
# ============================================================
echo ""
log_info "Phase 4: URL Collection"

# GAU - Get All URLs (wayback, commoncrawl, otx, urlscan)
# Local/private hosts have no public archive — skip straight to active crawling.
if [ "$TARGET_TYPE" = "local" ]; then
    log_info "Local target — skipping gau/wayback (no historical data); relying on katana crawl"
elif command -v gau &>/dev/null; then
    log_step "Running gau (historical URLs)..."
    echo "$TARGET" | gau --threads 20 --o "$RECON_DIR/urls/gau.txt" 2>/dev/null || \
    echo "$TARGET" | gau > "$RECON_DIR/urls/gau.txt" 2>/dev/null || true
    log_done "gau: $(wc -l < "$RECON_DIR/urls/gau.txt" 2>/dev/null || echo 0) URLs"
else
    log_warn "gau not installed — using wayback fallback. To install gau:"
    dep_install_hint gau
    curl -s "https://web.archive.org/cdx/search/cdx?url=*.$TARGET/*&output=text&fl=original&collapse=urlkey&limit=5000" \
        > "$RECON_DIR/urls/wayback.txt" 2>/dev/null || true
    log_done "wayback: $(wc -l < "$RECON_DIR/urls/wayback.txt" 2>/dev/null || echo 0) URLs"
fi

# katana — active crawl on live hosts (5 min cap prevents infinite crawl on
# content-heavy sites like news/video portals)
if command -v katana &>/dev/null && [ -s "$RECON_DIR/live/urls.txt" ]; then
    log_step "Running katana (active crawl, 5min cap, top 50 hosts)..."
    head -50 "$RECON_DIR/live/urls.txt" > "$RECON_DIR/urls/katana_targets.txt"
    timeout 300 katana \
        -list "$RECON_DIR/urls/katana_targets.txt" \
        -d 3 -jc -kf all -silent \
        -c 50 -p 20 \
        ${BB_AUTH_ARGS[@]+"${BB_AUTH_ARGS[@]}"} \
        -o "$RECON_DIR/urls/katana.txt" 2>/dev/null || true
    log_done "katana: $(wc -l < "$RECON_DIR/urls/katana.txt" 2>/dev/null || echo 0) URLs"
fi

# Merge all collected URLs
cat "$RECON_DIR/urls/"*.txt 2>/dev/null | sort -u > "$RECON_DIR/urls/all.txt" 2>/dev/null || true
log_done "Total unique URLs: $(wc -l < "$RECON_DIR/urls/all.txt" 2>/dev/null || echo 0)"

# Filter interesting URLs
if [ -s "$RECON_DIR/urls/all.txt" ]; then
    # URLs with parameters (potential injection points)
    grep '?' "$RECON_DIR/urls/all.txt" > "$RECON_DIR/urls/with_params.txt" 2>/dev/null || true
    log_done "URLs with parameters: $(wc -l < "$RECON_DIR/urls/with_params.txt" 2>/dev/null || echo 0)"

    # JS files
    grep -iE '\.js(\?|$)' "$RECON_DIR/urls/all.txt" > "$RECON_DIR/urls/js_files.txt" 2>/dev/null || true
    log_done "JS files: $(wc -l < "$RECON_DIR/urls/js_files.txt" 2>/dev/null || echo 0)"

    # API endpoints
    grep -iE '(/api/|/v[0-9]+/|/graphql|/rest/)' "$RECON_DIR/urls/all.txt" > "$RECON_DIR/urls/api_endpoints.txt" 2>/dev/null || true
    log_done "API endpoints: $(wc -l < "$RECON_DIR/urls/api_endpoints.txt" 2>/dev/null || echo 0)"

    # Potentially sensitive paths
    grep -iE '\.(env|config|xml|json|yaml|yml|bak|backup|old|orig|sql|db|log|txt|conf|ini|htaccess|htpasswd|git)' \
        "$RECON_DIR/urls/all.txt" > "$RECON_DIR/urls/sensitive_paths.txt" 2>/dev/null || true
    log_done "Sensitive paths: $(wc -l < "$RECON_DIR/urls/sensitive_paths.txt" 2>/dev/null || echo 0)"
fi

# ============================================================
# Phase 5: JS Analysis
# ============================================================
echo ""
log_info "Phase 5: JavaScript Analysis"

if [ -s "$RECON_DIR/urls/js_files.txt" ]; then
    log_step "Extracting endpoints from JS files (top 50)..."
    mkdir -p "$RECON_DIR/js"

    head -50 "$RECON_DIR/urls/js_files.txt" | while IFS= read -r js_url; do
        curl -s --max-time 10 ${BB_AUTH_ARGS[@]+"${BB_AUTH_ARGS[@]}"} "$js_url" 2>/dev/null | \
            sed -nE 's/.*["'"'"']([a-zA-Z0-9_/.-]*(\/[a-zA-Z0-9_/.-]+)+)["'"'"'].*/\1/p' \
            >> "$RECON_DIR/js/endpoints_raw.txt" 2>/dev/null || true
    done

    if [ -f "$RECON_DIR/js/endpoints_raw.txt" ]; then
        sort -u "$RECON_DIR/js/endpoints_raw.txt" > "$RECON_DIR/js/endpoints.txt"
        log_done "JS endpoints: $(wc -l < "$RECON_DIR/js/endpoints.txt" 2>/dev/null || echo 0)"

        # Extract potential secrets from JS
        head -50 "$RECON_DIR/urls/js_files.txt" | while IFS= read -r js_url; do
            curl -s --max-time 10 ${BB_AUTH_ARGS[@]+"${BB_AUTH_ARGS[@]}"} "$js_url" 2>/dev/null | \
                grep -oiE '(api[_-]?key|api[_-]?secret|access[_-]?token|auth[_-]?token|client[_-]?secret|password|secret[_-]?key)["\s]*[:=]["\s]*[a-zA-Z0-9_\-]{8,}' \
                >> "$RECON_DIR/js/potential_secrets.txt" 2>/dev/null || true
        done
        if [ -s "$RECON_DIR/js/potential_secrets.txt" ]; then
            sort -u "$RECON_DIR/js/potential_secrets.txt" -o "$RECON_DIR/js/potential_secrets.txt"
            log_warn "Potential secrets found in JS: $(wc -l < "$RECON_DIR/js/potential_secrets.txt")"
        fi
    fi
else
    log_warn "No JS files found — skipping JS analysis"
fi

# ============================================================
# Phase 6: Directory Fuzzing
# ============================================================
echo ""
log_info "Phase 6: Directory Fuzzing"

WORDLIST_DIR="$BASE_DIR/wordlists"
LEGACY_WORDLIST_DIR="$BASE_DIR/tools/wordlists"

if command -v ffuf &>/dev/null && [ -s "$RECON_DIR/live/urls.txt" ]; then
    # Select wordlist
    WORDLIST=""
    if [ -f "$WORDLIST_DIR/common.txt" ]; then
        WORDLIST="$WORDLIST_DIR/common.txt"
    elif [ -f "$LEGACY_WORDLIST_DIR/common.txt" ]; then
        WORDLIST="$LEGACY_WORDLIST_DIR/common.txt"
    elif [ -f "$WORDLIST_DIR/raft-medium-dirs.txt" ]; then
        WORDLIST="$WORDLIST_DIR/raft-medium-dirs.txt"
    elif [ -f "$LEGACY_WORDLIST_DIR/raft-medium-dirs.txt" ]; then
        WORDLIST="$LEGACY_WORDLIST_DIR/raft-medium-dirs.txt"
    elif [ -f /usr/share/wordlists/dirb/common.txt ]; then
        WORDLIST="/usr/share/wordlists/dirb/common.txt"
    fi

    if [ -n "$WORDLIST" ]; then
        # Fuzz top 5 live hosts
        FUZZ_COUNT=0
        MAX_FUZZ=$([ "$QUICK_MODE" = "--quick" ] && echo 2 || echo 5)

        while IFS= read -r url && [ "$FUZZ_COUNT" -lt "$MAX_FUZZ" ]; do
            domain=$(echo "$url" | sed 's|https\?://||;s|[/:].*||')
            log_step "Fuzzing: $url"
            ffuf -u "${url}/FUZZ" \
                -w "$WORDLIST" \
                -mc 200,301,302,403,405 \
                -t "$THREADS" \
                -rate "$RATE_LIMIT" \
                -sf \
                -timeout 10 \
                ${BB_AUTH_ARGS[@]+"${BB_AUTH_ARGS[@]}"} \
                -o "$RECON_DIR/dirs/ffuf_${domain}.json" \
                -of json 2>/dev/null || true
            ((FUZZ_COUNT++))
        done < "$RECON_DIR/live/urls.txt"

        log_done "Directory fuzzing complete ($FUZZ_COUNT hosts)"
    else
        log_warn "No wordlist found — run: python3 tools/hunt.py --setup-wordlists"
    fi
else
    if ! command -v ffuf &>/dev/null; then
        warn_missing ffuf "directory fuzzing"
    else
        log_warn "No live hosts — skipping directory fuzzing"
    fi
fi

# ============================================================
# Phase 6.5: Config File Exposure Check
# ============================================================
echo ""
log_info "Phase 6.5: Config File Exposure Check"

if [ -s "$RECON_DIR/live/urls.txt" ]; then
    log_step "Checking for exposed config files (env.js, app_env.js, .env, etc.)..."
    CONFIG_PATHS=(
        "/env.js"
        "/app_env.js"
        "/config.js"
        "/settings.js"
        "/.env"
        "/.env.local"
        "/.env.production"
        "/.env.development"
        "/config/env.js"
        "/static/env.js"
        "/assets/env.js"
    )

    mkdir -p "$RECON_DIR/exposure"
    : > "$RECON_DIR/exposure/config_files.txt"

    while IFS= read -r base_url; do
        for path in "${CONFIG_PATHS[@]}"; do
            STATUS=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 ${BB_AUTH_ARGS[@]+"${BB_AUTH_ARGS[@]}"} "${base_url}${path}" 2>/dev/null || echo "000")
            if [ "$STATUS" = "200" ]; then
                CONTENT_TYPE=$(curl -sI --max-time 5 ${BB_AUTH_ARGS[@]+"${BB_AUTH_ARGS[@]}"} "${base_url}${path}" 2>/dev/null | grep -i content-type | head -1)
                # Only flag if it returns JS/JSON/text (not HTML error pages)
                if echo "$CONTENT_TYPE" | grep -qiE '(javascript|json|text/plain)'; then
                    echo "[EXPOSED] ${base_url}${path}" >> "$RECON_DIR/exposure/config_files.txt"
                    log_vuln "Config exposed: ${base_url}${path}"
                fi
            fi
        done
    done < <(head -30 "$RECON_DIR/live/urls.txt")

    CONFIG_COUNT=$(wc -l < "$RECON_DIR/exposure/config_files.txt" 2>/dev/null | tr -d ' ')
    [ "$CONFIG_COUNT" -gt 0 ] && log_warn "Exposed config files: $CONFIG_COUNT" || log_done "Config files: clean"
else
    log_warn "No live hosts — skipping config check"
fi

# ============================================================
# Phase 7: Parameter Discovery
# ============================================================
echo ""
log_info "Phase 7: Parameter Discovery"

if [ -s "$RECON_DIR/urls/with_params.txt" ]; then
    log_step "Extracting parameters from collected URLs..."

    # Extract parameter names (macOS compatible - no grep -P)
    sed -nE 's/.*[?&]([^=&]+)=.*/\1/p' "$RECON_DIR/urls/with_params.txt" 2>/dev/null \
        | sort | uniq -c | sort -rn > "$RECON_DIR/params/param_frequency.txt" 2>/dev/null || true

    # Get unique param names
    awk '{print $2}' "$RECON_DIR/params/param_frequency.txt" > "$RECON_DIR/params/unique_params.txt" 2>/dev/null || true
    log_done "Unique parameters: $(wc -l < "$RECON_DIR/params/unique_params.txt" 2>/dev/null || echo 0)"

    # Flag interesting params (potential injection points)
    grep -iE '(url|redirect|next|return|callback|dest|file|path|page|template|include|src|ref|uri|link|target|goto|out|view|dir|show|site|domain|rurl|return_to|continue|window|data|reference|to|img|load|doc|download)' \
        "$RECON_DIR/params/unique_params.txt" > "$RECON_DIR/params/interesting_params.txt" 2>/dev/null || true

    if [ -s "$RECON_DIR/params/interesting_params.txt" ]; then
        log_warn "Interesting params (potential vulns): $(wc -l < "$RECON_DIR/params/interesting_params.txt")"
        echo "      Params: $(head -5 "$RECON_DIR/params/interesting_params.txt" | tr '\n' ', ')"
    fi
else
    log_warn "No parameterized URLs found — skipping"
fi

# ============================================================
# Phase 8: CI/CD Workflow Scan (auto-detect GitHub org)
# ============================================================
log_info "Phase 8: CI/CD Workflow Scan"

GITHUB_ORGS=""
CICD_SCANNER="$(dirname "$0")/cicd_scanner.sh"

# Extract github.com/<org> patterns from recon data
for f in "$RECON_DIR/live/httpx_full.txt" "$RECON_DIR/js/endpoints.txt" "$RECON_DIR/urls/all.txt"; do
    if [ -f "$f" ]; then
        GITHUB_ORGS="$GITHUB_ORGS $(grep -oE 'github\.com/[a-zA-Z0-9_-]+' "$f" 2>/dev/null | sed 's#.*github\.com/##' || true)"
    fi
done

# Deduplicate and limit to 5
GITHUB_ORGS=$(echo "$GITHUB_ORGS" | tr ' ' '\n' | grep -v '^$' | sort -u | head -5)

if [ -n "$GITHUB_ORGS" ] && [ -x "$CICD_SCANNER" ] && command -v sisakulint &>/dev/null; then
    for ORG in $GITHUB_ORGS; do
        log_info "CI/CD scan: org:$ORG"
        bash "$CICD_SCANNER" "org:$ORG" --output-dir "$RECON_DIR/cicd/$ORG/" || true
    done
else
    if [ -z "$GITHUB_ORGS" ]; then
        log_warn "GitHub org not detected — CI/CD scan skipped"
    elif ! command -v sisakulint &>/dev/null; then
        log_warn "sisakulint not installed — CI/CD scan skipped"
    fi
fi

# ============================================================
# Phase 9: Nuclei vulnerability sweep (optional, gated on installed binary)
# ============================================================
echo ""
log_info "Phase 9: Nuclei Vulnerability Sweep"

if command -v nuclei &>/dev/null && [ -s "$RECON_DIR/live/urls.txt" ]; then
    NUCLEI_OUT="$RECON_DIR/nuclei"
    mkdir -p "$NUCLEI_OUT"
    NUC_LIMIT=$([ "$QUICK_MODE" = "--quick" ] && echo 50 || echo 200)
    NUC_SEV=$([ "$QUICK_MODE" = "--quick" ] && echo "high,critical" || echo "medium,high,critical")
    NUC_TIMEOUT=$([ "$QUICK_MODE" = "--quick" ] && echo 600 || echo 1800)

    head -"$NUC_LIMIT" "$RECON_DIR/live/urls.txt" > "$NUCLEI_OUT/targets.txt"
    log_step "nuclei on $(wc -l < "$NUCLEI_OUT/targets.txt" | tr -d ' ') hosts (severity=$NUC_SEV, timeout=${NUC_TIMEOUT}s)..."

    NUC_RL="${NUC_RATE_LIMIT:-300}"
    NUC_C="${NUC_CONCURRENCY:-50}"
    NUC_BS="${NUC_BULK_SIZE:-50}"

    timeout "$NUC_TIMEOUT" nuclei \
        -l "$NUCLEI_OUT/targets.txt" \
        -severity "$NUC_SEV" \
        -rl "$NUC_RL" \
        -c "$NUC_C" \
        -bs "$NUC_BS" \
        -silent \
        -stats \
        ${BB_AUTH_ARGS[@]+"${BB_AUTH_ARGS[@]}"} \
        -jsonl \
        -o "$NUCLEI_OUT/findings.jsonl" 2>/dev/null || true

    if [ -s "$NUCLEI_OUT/findings.jsonl" ]; then
        # Severity buckets for human review
        for sev in critical high medium low info; do
            grep -F "\"severity\":\"$sev\"" "$NUCLEI_OUT/findings.jsonl" \
                > "$NUCLEI_OUT/${sev}.jsonl" 2>/dev/null || true
            n=$(wc -l < "$NUCLEI_OUT/${sev}.jsonl" 2>/dev/null | tr -d ' ')
            [ "$n" -gt 0 ] && log_done "nuclei $sev: $n"
        done
    else
        log_done "nuclei: no findings"
    fi
else
    [ -z "$(command -v nuclei)" ] && warn_missing nuclei "template scan"
fi

# ============================================================
# Phase 10: Subdomain takeover quick-check (CNAME fingerprint grep)
# ============================================================
echo ""
log_info "Phase 10: Subdomain Takeover Quick-Check"

if command -v dig &>/dev/null && [ -s "$RECON_DIR/subdomains/all.txt" ]; then
    TAKEOVER_OUT="$RECON_DIR/takeover_candidates.txt"
    : > "$TAKEOVER_OUT"
    SUB_LIMIT=$([ "$QUICK_MODE" = "--quick" ] && echo 100 || echo 500)

    log_step "Resolving CNAMEs for top $SUB_LIMIT subdomains..."
    head -"$SUB_LIMIT" "$RECON_DIR/subdomains/all.txt" | while IFS= read -r host; do
        [ -z "$host" ] && continue
        cname=$(dig +short "$host" CNAME 2>/dev/null | head -1)
        [ -z "$cname" ] && continue
        # Match common claimable-service CNAME suffixes (extend list as needed)
        case "$cname" in
            *github.io.*|*herokuapp.com.*|*herokussl.com.*|\
            *s3.amazonaws.com.*|*s3-website*.amazonaws.com.*|\
            *azurewebsites.net.*|*cloudapp.net.*|*trafficmanager.net.*|\
            *shopify.com.*|*myshopify.com.*|\
            *wordpress.com.*|*ghost.io.*|*tumblr.com.*|\
            *pantheonsite.io.*|*surge.sh.*|*netlify.app.*|*vercel.app.*|\
            *zendesk.com.*|*helpjuice.com.*|*helpscout.net.*|*statuspage.io.*|\
            *fastly.net.*|*readme.io.*|*intercom.help.*)
                echo "$host  CNAME→ $cname" >> "$TAKEOVER_OUT" ;;
        esac
    done

    n=$(wc -l < "$TAKEOVER_OUT" | tr -d ' ')
    if [ "$n" -gt 0 ]; then
        log_warn "$n potential takeover candidate(s) — review $TAKEOVER_OUT"
        log_warn "Confirm with: ./tools/takeover_scanner.sh --recon $RECON_DIR"
    else
        log_done "Takeover quick-check: clean"
    fi
fi

# ============================================================
# Summary
# ============================================================
echo ""
echo "============================================="
echo "  Recon Summary — $TARGET"
echo "  Completed: $(date)"
echo "============================================="
echo ""
echo "  Subdomains:        $(wc -l < "$RECON_DIR/subdomains/all.txt" 2>/dev/null || echo 0)"
[ -f "$RECON_DIR/live/urls.txt" ] && \
echo "  Live hosts:        $(wc -l < "$RECON_DIR/live/urls.txt" 2>/dev/null || echo 0)"
[ -f "$RECON_DIR/ports/open_ports.txt" ] && \
echo "  Open ports:        $(wc -l < "$RECON_DIR/ports/open_ports.txt" 2>/dev/null || echo 0)"
[ -f "$RECON_DIR/urls/all.txt" ] && \
echo "  URLs collected:    $(wc -l < "$RECON_DIR/urls/all.txt" 2>/dev/null || echo 0)"
[ -f "$RECON_DIR/urls/with_params.txt" ] && \
echo "  Parameterized:     $(wc -l < "$RECON_DIR/urls/with_params.txt" 2>/dev/null || echo 0)"
[ -f "$RECON_DIR/urls/api_endpoints.txt" ] && \
echo "  API endpoints:     $(wc -l < "$RECON_DIR/urls/api_endpoints.txt" 2>/dev/null || echo 0)"
[ -f "$RECON_DIR/js/endpoints.txt" ] && \
echo "  JS endpoints:      $(wc -l < "$RECON_DIR/js/endpoints.txt" 2>/dev/null || echo 0)"
[ -f "$RECON_DIR/params/unique_params.txt" ] && \
echo "  Unique params:     $(wc -l < "$RECON_DIR/params/unique_params.txt" 2>/dev/null || echo 0)"

[ -d "$RECON_DIR/cicd" ] && \
echo "  CI/CD findings:   $(find "$RECON_DIR/cicd" -name 'scan_results.txt' -exec grep -cF '.github/workflows/' {} + 2>/dev/null | awk -F: '{s+=$NF} END {print s+0}')"

[ -f "$RECON_DIR/nuclei/findings.jsonl" ] && \
echo "  Nuclei hits:       $(wc -l < "$RECON_DIR/nuclei/findings.jsonl" | tr -d ' ')"
[ -f "$RECON_DIR/takeover_candidates.txt" ] && \
echo "  Takeover candidates: $(wc -l < "$RECON_DIR/takeover_candidates.txt" | tr -d ' ')"

echo ""
echo "  Results: $RECON_DIR/"
echo "============================================="
echo ""
echo "  Next:"
echo "    ./tools/vuln_scanner.sh $RECON_DIR        # active vuln probes"
echo "    ./tools/takeover_scanner.sh --recon $RECON_DIR   # confirm CNAME takeovers"
echo "    ./tools/secrets_hunter.sh --js-bundle $RECON_DIR  # leaked-cred sweep"
echo "============================================="
