#!/usr/bin/env python3
"""
validate.py — Interactive bug validation assistant.
Walks through the 4 validation gates, checks for duplicates, calculates CVSS,
and generates a skeleton HackerOne report.

Usage:
  python3 tools/validate.py
  python3 tools/validate.py --output findings/myreport.md
"""

import argparse
import json
import os
import ssl
import sys
import urllib.request
import urllib.error
from datetime import datetime

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO not in sys.path:
    sys.path.insert(0, _REPO)
from tools.banner import print_banner  # noqa: E402
from tools.safe_http import safe_urlopen  # noqa: E402

# Prefer certifi's CA bundle when available (macOS Python may lack system
# SSL certs); otherwise fall back to the system CA store via
# ssl.create_default_context(), which is already a verifying context.
_SSL_CTX = ssl.create_default_context()
try:
    import certifi
    _SSL_CTX = ssl.create_default_context(cafile=certifi.where())
except ImportError:
    # certifi isn't installed — never disable verification: see
    # SECURITY-REVIEW-2026-08-22.md finding #9 — this fallback used to
    # disable verification outright, silently exposing every request to
    # MITM on any stock install, since certifi is not a declared dependency.
    _SSL_CTX = ssl.create_default_context()

# ─── Color codes ──────────────────────────────────────────────────────────────
RED    = "\033[91m"
YELLOW = "\033[93m"
GREEN  = "\033[92m"
CYAN   = "\033[96m"
BLUE   = "\033[94m"
BOLD   = "\033[1m"
DIM    = "\033[2m"
RESET  = "\033[0m"

# ─── CVSS 4.0 scoring ─────────────────────────────────────────────────────────
# Implements the CVSS 4.0 macro-vector approach from FIRST.org.
# For authoritative scores verify at: https://www.first.org/cvss/calculator/4.0

def _eq1(av: str, pr: str, ui: str) -> int:
    """EQ1: Attack Vector / Privileges Required / User Interaction (0=highest severity)."""
    if av == "N" and (pr == "N" or ui == "N"):
        return 0
    if av == "N" or pr == "N" or ui == "N":
        return 1
    return 2

def _eq2(ac: str, at: str) -> int:
    """EQ2: Attack Complexity / Attack Requirements."""
    return 0 if (ac == "L" and at == "N") else 1

def _eq3(vc: str, vi: str, va: str) -> int:
    """EQ3: Vulnerable System CIA impact."""
    if vc == "H" and vi == "H":
        return 0
    if vc == "H" or vi == "H" or va == "H":
        return 1
    return 2

def _eq4(sc: str, si: str, sa: str) -> int:
    """EQ4: Subsequent System impact (Safety > High > Low/None)."""
    if si == "S" or sa == "S":
        return 0
    if sc == "H" or si == "H" or sa == "H":
        return 1
    return 2

# CVSS 4.0 base score lookup by macro vector (eq1, eq2, eq3, eq4).
# EQ5=0 (E=Active, default for base metrics).
# EQ6 is derived from EQ3 with default CR=IR=AR=High.
# Values approximate FIRST.org CVSS 4.0 specification.
# Verify exact scores at: https://www.first.org/cvss/calculator/4.0
#
# eq1: 0=Network+(no-auth or no-UI), 1=partial advantage, 2=local/physical/high-priv+UI
# eq2: 0=Low-complexity+no-prereqs, 1=otherwise
# eq3: 0=VC+VI both High, 1=partial High, 2=no High CIA on vulnerable system
# eq4: 0=Safety impact, 1=High subsequent-system impact, 2=no subsequent impact
_CVSS40_TABLE: dict[tuple[int, int, int, int], float] = {
    # eq1=0 (widest attack reach: network + no-auth OR no-UI)
    (0, 0, 0, 0): 10.0, (0, 0, 0, 1): 10.0, (0, 0, 0, 2): 9.3,
    (0, 0, 1, 0): 9.5,  (0, 0, 1, 1): 9.1,  (0, 0, 1, 2): 7.1,
    (0, 0, 2, 0): 7.9,  (0, 0, 2, 1): 6.9,  (0, 0, 2, 2): 4.8,
    (0, 1, 0, 0): 9.5,  (0, 1, 0, 1): 9.1,  (0, 1, 0, 2): 8.0,
    (0, 1, 1, 0): 8.9,  (0, 1, 1, 1): 8.5,  (0, 1, 1, 2): 6.5,
    (0, 1, 2, 0): 7.0,  (0, 1, 2, 1): 5.5,  (0, 1, 2, 2): 4.0,
    # eq1=1 (some network/auth/UI advantage)
    (1, 0, 0, 0): 9.3,  (1, 0, 0, 1): 9.0,  (1, 0, 0, 2): 7.8,
    (1, 0, 1, 0): 8.8,  (1, 0, 1, 1): 8.5,  (1, 0, 1, 2): 6.5,
    (1, 0, 2, 0): 7.0,  (1, 0, 2, 1): 6.0,  (1, 0, 2, 2): 4.5,
    (1, 1, 0, 0): 9.0,  (1, 1, 0, 1): 8.5,  (1, 1, 0, 2): 7.5,
    (1, 1, 1, 0): 8.5,  (1, 1, 1, 1): 7.5,  (1, 1, 1, 2): 5.9,
    (1, 1, 2, 0): 6.0,  (1, 1, 2, 1): 5.5,  (1, 1, 2, 2): 3.5,
    # eq1=2 (local/physical or high-privileges + active UI required)
    (2, 0, 0, 0): 9.0,  (2, 0, 0, 1): 8.5,  (2, 0, 0, 2): 7.5,
    (2, 0, 1, 0): 8.0,  (2, 0, 1, 1): 7.5,  (2, 0, 1, 2): 6.5,
    (2, 0, 2, 0): 6.0,  (2, 0, 2, 1): 5.5,  (2, 0, 2, 2): 4.0,
    (2, 1, 0, 0): 8.5,  (2, 1, 0, 1): 8.0,  (2, 1, 0, 2): 7.0,
    (2, 1, 1, 0): 7.5,  (2, 1, 1, 1): 7.0,  (2, 1, 1, 2): 5.5,
    (2, 1, 2, 0): 5.5,  (2, 1, 2, 1): 5.0,  (2, 1, 2, 2): 3.5,
}


def calculate_cvss40(av, ac, at, pr, ui, vc, vi, va, sc, si, sa) -> tuple[float, str]:
    """Calculate CVSS 4.0 base score (approximate) and return (score, vector_string)."""
    e1 = _eq1(av, pr, ui)
    e2 = _eq2(ac, at)
    e3 = _eq3(vc, vi, va)
    e4 = _eq4(sc, si, sa)
    score = _CVSS40_TABLE.get((e1, e2, e3, e4), 5.0)
    vector = (
        f"CVSS:4.0/AV:{av}/AC:{ac}/AT:{at}/PR:{pr}/UI:{ui}"
        f"/VC:{vc}/VI:{vi}/VA:{va}/SC:{sc}/SI:{si}/SA:{sa}"
    )
    return score, vector


def severity_from_score(score: float) -> str:
    if score == 0.0:  return "NONE"
    if score < 4.0:   return "LOW"
    if score < 7.0:   return "MEDIUM"
    if score < 9.0:   return "HIGH"
    return "CRITICAL"


# ─── GraphQL string escaping ──────────────────────────────────────────────────

def _escape_graphql_string(s: str) -> str:
    """Escape a value for safe interpolation inside a GraphQL double-quoted string."""
    return (s
            .replace("\\", "\\\\")
            .replace('"', '\\"')
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t"))


# ─── HackerOne dup check ──────────────────────────────────────────────────────

def check_h1_dups(program_handle: str, vuln_keyword: str) -> list[dict]:
    """Search HackerOne for potential duplicates."""
    if not program_handle:
        return []

    query = {
        "query": f"""{{
          hacktivity_items(
            first: 10,
            order_by: {{ field: popular, direction: DESC }},
            where: {{
              team: {{ handle: {{ _eq: "{_escape_graphql_string(program_handle)}" }} }},
              report: {{ title: {{ _icontains: "{_escape_graphql_string(vuln_keyword)}" }} }}
            }}
          ) {{
            nodes {{
              ... on HacktivityDocument {{
                report {{
                  title
                  severity_rating
                  disclosed_at
                  url
                  state
                }}
              }}
            }}
          }}
        }}"""
    }
    try:
        req = urllib.request.Request(
            "https://hackerone.com/graphql",
            data=json.dumps(query).encode(),
            headers={"Content-Type": "application/json"},
        )
        with safe_urlopen(req, timeout=10, context=_SSL_CTX) as resp:
            data = json.loads(resp.read().decode())
        nodes = (data.get("data") or {}).get("hacktivity_items", {}).get("nodes", [])
        results = []
        for node in nodes:
            r = node.get("report")
            if r:
                results.append(r)
        return results
    except Exception as exc:
        print(
            f"  {YELLOW}HackerOne duplicate check failed: {exc}{RESET}",
            file=sys.stderr,
        )
        return []


# ─── Interactive prompt helpers ───────────────────────────────────────────────

def ask(prompt: str, default: str = "") -> str:
    if default:
        val = input(f"  {prompt} [{default}]: ").strip()
        return val if val else default
    return input(f"  {prompt}: ").strip()


def ask_yn(prompt: str, default: bool = True) -> bool:
    yn = "Y/n" if default else "y/N"
    val = input(f"  {prompt} [{yn}]: ").strip().lower()
    if not val:
        return default
    return val in ("y", "yes")


def ask_yn_required(prompt: str) -> bool:
    """Ask a required yes/no question. Blank answers auto-fail."""
    while True:
        val = input(f"  {prompt} [y/n]: ").strip().lower()
        if val in ("y", "yes"):
            return True
        if val in ("n", "no"):
            return False
        if not val:
            print(f"  {YELLOW}Blank answer auto-fails this check.{RESET}")
            return False
        print(f"  {YELLOW}Enter y or n.{RESET}")


def load_json_file(path: str) -> dict:
    if not path:
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except FileNotFoundError:
        return {}
    except json.JSONDecodeError as exc:
        print(
            f"  {YELLOW}Malformed JSON in {path}: {exc}{RESET}",
            file=sys.stderr,
        )
        return {}
    except OSError as exc:
        print(
            f"  {YELLOW}Could not read file {path}: {exc}{RESET}",
            file=sys.stderr,
        )
        return {}


def ask_choice(prompt: str, choices: list[tuple[str, str]]) -> str:
    """Ask user to pick from labeled choices. Returns the choice key."""
    print(f"\n  {prompt}")
    for key, label in choices:
        print(f"    {CYAN}{key}{RESET}) {label}")
    while True:
        val = input(f"  Choice: ").strip().upper()
        if val in [k for k, _ in choices]:
            return val
        print(f"  {YELLOW}Invalid — enter one of: {', '.join(k for k,_ in choices)}{RESET}")


def section(title: str):
    print(f"\n{BOLD}{BLUE}{'─' * 60}{RESET}")
    print(f"{BOLD}{BLUE}  {title}{RESET}")
    print(f"{BOLD}{BLUE}{'─' * 60}{RESET}\n")


def gate_header(n: int, name: str, status: str | None = None):
    status_str = ""
    if status == "PASS":
        status_str = f" {GREEN}✓ PASS{RESET}"
    elif status == "FAIL":
        status_str = f" {RED}✗ FAIL{RESET}"
    print(f"\n{BOLD}Gate {n}: {name}{RESET}{status_str}")
    print(f"{'─' * 40}")


# ─── Gate implementations ─────────────────────────────────────────────────────

# Auth-related vuln types that require session identity checks before Gate 1 can pass.
_AUTH_KEYWORDS = {
    "idor", "ato", "auth", "session", "login", "privilege", "account",
    "bypass", "takeover", "permission", "access control", "broken auth",
    "bac", "broken access", "insecure direct",
}

def _is_auth_related(vuln_type: str) -> bool:
    vt = vuln_type.lower()
    return any(k in vt for k in _AUTH_KEYWORDS)


def gate1_is_real(vuln_type: str = "") -> tuple[bool, dict]:
    gate_header(1, "Is It Real?")
    print("  Can you reproduce the bug from scratch — clean browser, no Burp artifacts?")
    print()
    repro3   = ask_yn("Reproduced 3/3 times deterministically?")
    no_burp  = ask_yn("Works with plain curl or fresh browser (not just in Burp)?")
    no_state = ask_yn("No unusual preconditions (doesn't require specific timing or race)?")
    rtfm     = ask_yn("Checked documentation — this isn't expected/documented behavior?")

    # Identity check for auth/access-control findings.
    # The #1 reason IDOR/ATO get N/A: tester only accessed their own data.
    identity_ok = True
    identity_notes: dict = {}
    if _is_auth_related(vuln_type):
        print(f"\n  {CYAN}Identity Check  (required — auth-related vuln type detected){RESET}")
        print(f"  {DIM}Most IDOR/ATO N/As happen because the tester only read their own data.{RESET}\n")
        cross_account = ask_yn_required("Tested with two accounts: Session A read Session B's data (not your own)?")
        fresh_session = ask_yn_required("Reproduced with a fresh session (not your existing logged-in cookie)?")
        anon_delta    = ask_yn_required("Confirmed the delta: anonymous is blocked, attacker-authenticated succeeds?")
        identity_ok   = cross_account and fresh_session and anon_delta
        identity_notes = {
            "cross_account_tested":    cross_account,
            "fresh_session_tested":    fresh_session,
            "anon_vs_auth_delta":      anon_delta,
            "identity_required":       True,
        }
        if not identity_ok:
            print(f"\n  {RED}Identity check FAIL — gate cannot pass without cross-account proof.{RESET}")

    passed = repro3 and no_burp and no_state and rtfm and identity_ok

    rejection_reason: str | None = None
    if not passed:
        rejection_reason = "identity_not_proven" if (repro3 and no_burp and no_state and rtfm and not identity_ok) else "not_reproducible"

    notes: dict = {
        "repro_3_3":               repro3,
        "works_without_proxy":     no_burp,
        "no_special_state":        no_state,
        "not_documented_behavior": rtfm,
        **identity_notes,
        "rejection_reason":        rejection_reason,
    }

    if not passed:
        print(f"\n  {RED}GATE 1 FAIL: {rejection_reason}{RESET}")
        print(f"  {DIM}Do not submit yet. Verify the bug is deterministic first.{RESET}")
    else:
        print(f"\n  {GREEN}GATE 1 PASS{RESET}")

    return passed, notes


def gate2_in_scope(program_handle: str) -> tuple[bool, dict]:
    gate_header(2, "Is It In Scope?")
    print("  Check the program scope page explicitly — don't assume.")
    print()

    asset_in_scope  = ask_yn("The affected domain/asset is listed on the program's scope page?")
    not_excluded    = ask_yn("Not in the out-of-scope list (check staging, third-party exclusions)?")
    version_ok      = ask_yn("Affected software version is in scope (not an excluded old version)?")

    if program_handle:
        print(f"\n  {DIM}Checking HackerOne scope for '{program_handle}'...{RESET}")
        try:
            query = {
                "query": f'{{ team(handle: "{_escape_graphql_string(program_handle)}") {{ policy_scopes(archived: false) {{ edges {{ node {{ asset_type asset_identifier eligible_for_bounty }} }} }} }} }}'
            }
            req = urllib.request.Request(
                "https://hackerone.com/graphql",
                data=json.dumps(query).encode(),
                headers={"Content-Type": "application/json"},
            )
            with safe_urlopen(req, timeout=8, context=_SSL_CTX) as resp:
                data = json.loads(resp.read().decode())
            scopes = (data.get("data") or {}).get("team", {}).get("policy_scopes", {}).get("edges", [])
            if scopes:
                print(f"\n  {CYAN}In-scope assets for {program_handle}:{RESET}")
                for edge in scopes[:10]:
                    node = edge.get("node", {})
                    bounty = " (eligible)" if node.get("eligible_for_bounty") else ""
                    print(f"    • [{node.get('asset_type','?')}] {node.get('asset_identifier','?')}{bounty}")
        except Exception as exc:
            print(
                f"  {YELLOW}Could not fetch scope: {type(exc).__name__}: {exc}{RESET}",
                file=sys.stderr,
            )

    passed = asset_in_scope and not_excluded and version_ok
    notes: dict = {
        "asset_in_scope":    asset_in_scope,
        "not_excluded":      not_excluded,
        "version_ok":        version_ok,
        "rejection_reason":  "out_of_scope" if not passed else None,
    }

    if not passed:
        print(f"\n  {RED}GATE 2 FAIL: out_of_scope{RESET}")
        print(f"  {DIM}Confirm scope before submitting.{RESET}")
    else:
        print(f"\n  {GREEN}GATE 2 PASS{RESET}")

    return passed, notes


def gate3_exploitable() -> tuple[bool, dict]:
    gate_header(3, "Is It Exploitable?")
    print("  Can you demonstrate concrete impact without unrealistic preconditions?")
    print()

    concrete_impact = ask_yn("Can you show concrete impact (not just 'theoretically an attacker could')?")
    no_unrealistic  = ask_yn("No unrealistic preconditions (not 'must be admin already', not 'victim must run JS')?")

    print()
    print("  What is the concrete impact? (be specific)")
    impact_desc = ask("Describe the impact")

    # Require a real curl PoC — yes/no on "have proof" is not enough.
    # A blank answer here is an automatic FAIL. This is the primary false-positive filter.
    print()
    print(f"  {BOLD}Paste the exact curl command that reproduces this.{RESET}")
    print(f"  {DIM}Example: curl -s 'https://target.com/api/user/456' -H 'Cookie: sess=ATTACKER'{RESET}")
    print(f"  {YELLOW}Leave blank or type 'skip' → auto-FAIL (no proof = no submit){RESET}")
    curl_poc   = ask("curl PoC").strip()
    curl_valid = bool(curl_poc) and curl_poc.lower() != "skip"

    if not curl_valid:
        print(f"\n  {RED}No PoC provided — this is a scanner hit, not a confirmed finding.{RESET}")
        print(f"  {DIM}Reproduce it with curl, then come back.{RESET}")

    passed = concrete_impact and no_unrealistic and curl_valid

    rejection_reason: str | None = None
    if not passed:
        if not curl_valid:
            rejection_reason = "no_reproducible_impact"
        elif not concrete_impact:
            rejection_reason = "no_concrete_impact"
        elif not no_unrealistic:
            rejection_reason = "unrealistic_privileges"
        else:
            rejection_reason = "no_reproducible_impact"

    notes: dict = {
        "concrete_impact":             concrete_impact,
        "no_unrealistic_preconditions":no_unrealistic,
        "curl_poc":                    curl_poc if curl_valid else "",
        "has_proof":                   curl_valid,
        "impact_description":          impact_desc,
        "rejection_reason":            rejection_reason,
    }

    if not passed:
        print(f"\n  {RED}GATE 3 FAIL: {rejection_reason}{RESET}")
        print(f"  {DIM}Build a working PoC before submitting.{RESET}")
    else:
        print(f"\n  {GREEN}GATE 3 PASS{RESET}")

    return passed, notes


def gate4_not_dup(vuln_type: str, endpoint: str, program_handle: str) -> tuple[bool, dict]:
    gate_header(4, "Is It a Dup?")
    print("  Check HackerOne disclosed reports, GitHub issues, and recent changelog.")
    print()

    # Auto-check HackerOne
    h1_results = []
    if program_handle and vuln_type:
        print(f"  {DIM}Searching HackerOne for '{vuln_type}' in '{program_handle}'...{RESET}")
        h1_results = check_h1_dups(program_handle, vuln_type)
        if h1_results:
            print(f"\n  {YELLOW}Found {len(h1_results)} potentially similar disclosed reports:{RESET}")
            for r in h1_results:
                disclosed = (r.get("disclosed_at") or "")[:10]
                print(f"    • [{r.get('severity_rating','?').upper()}] {r.get('title','')} ({disclosed})")
                if r.get("url"):
                    print(f"      {DIM}{r['url']}{RESET}")
        else:
            print(f"  {GREEN}No similar disclosed reports found on HackerOne.{RESET}")

    print()
    not_disclosed   = ask_yn("Not found in HackerOne disclosed reports for this program?")
    not_in_issues   = ask_yn("Not already fixed/reported in GitHub issues or CHANGELOG?")
    checked_history = ask_yn("Checked git log for recent security fixes with this pattern?")

    passed = not_disclosed and not_in_issues and checked_history
    notes: dict = {
        "not_in_h1_disclosed":  not_disclosed,
        "not_in_github_issues": not_in_issues,
        "checked_git_history":  checked_history,
        "h1_similar_reports":   [r.get("title") for r in h1_results],
        "rejection_reason":     "duplicate_or_already_disclosed" if not passed else None,
    }

    if not passed:
        print(f"\n  {RED}GATE 4 FAIL: duplicate_or_already_disclosed{RESET}")
        print(f"  {DIM}Verify it's not already known before submitting.{RESET}")
    else:
        print(f"\n  {GREEN}GATE 4 PASS{RESET}")

    return passed, notes


# ─── CVSS 4.0 interactive scorer ─────────────────────────────────────────────

def score_cvss() -> tuple[float, str, dict]:
    section("CVSS 4.0 Scoring")
    print(f"  {DIM}Scores are approximate — verify at https://www.first.org/cvss/calculator/4.0{RESET}\n")

    av = ask_choice("Attack Vector (AV)", [
        ("N", "Network — exploitable remotely over the internet"),
        ("A", "Adjacent — same network segment, Bluetooth, or VLAN"),
        ("L", "Local — requires local OS access or authenticated session"),
        ("P", "Physical — requires physical device access"),
    ])
    ac = ask_choice("Attack Complexity (AC)", [
        ("L", "Low — reliable, reproducible, no special conditions"),
        ("H", "High — requires specific conditions, evasion, or timing"),
    ])
    at = ask_choice("Attack Requirements (AT)  [NEW in 4.0]", [
        ("N", "None — no prerequisite deployment or execution conditions"),
        ("P", "Present — depends on specific target configuration or state"),
    ])
    pr = ask_choice("Privileges Required (PR)", [
        ("N", "None — no account or elevated access needed"),
        ("L", "Low — regular user account"),
        ("H", "High — admin or elevated privileges"),
    ])
    ui = ask_choice("User Interaction (UI)  [Changed in 4.0]", [
        ("N", "None — no victim interaction required"),
        ("P", "Passive — victim must access a URL or open an email (no explicit action)"),
        ("A", "Active — victim must explicitly click, download, or interact"),
    ])

    print(f"\n  {CYAN}Vulnerable System Impact{RESET}  (the component directly attacked)")
    vc = ask_choice("Confidentiality — Vulnerable System (VC)", [
        ("H", "High — complete or significant confidentiality loss"),
        ("L", "Low — partial or constrained disclosure"),
        ("N", "None"),
    ])
    vi = ask_choice("Integrity — Vulnerable System (VI)", [
        ("H", "High — complete or significant integrity loss"),
        ("L", "Low — limited modification possible"),
        ("N", "None"),
    ])
    va = ask_choice("Availability — Vulnerable System (VA)", [
        ("H", "High — complete denial of service"),
        ("L", "Low — reduced performance or intermittent outages"),
        ("N", "None"),
    ])

    print(f"\n  {CYAN}Subsequent System Impact{RESET}  (other systems or users beyond the attacked component)")
    sc = ask_choice("Confidentiality — Subsequent System (SC)", [
        ("H", "High — significant data exposure in downstream systems/users"),
        ("L", "Low — limited disclosure in downstream systems/users"),
        ("N", "None — no impact beyond the vulnerable component"),
    ])
    si = ask_choice("Integrity — Subsequent System (SI)", [
        ("S", "Safety — impacts physical safety of people"),
        ("H", "High — complete integrity loss in downstream system"),
        ("L", "Low — limited modification in downstream system"),
        ("N", "None"),
    ])
    sa = ask_choice("Availability — Subsequent System (SA)", [
        ("S", "Safety — impacts physical safety of people"),
        ("H", "High — complete denial of service in downstream system"),
        ("L", "Low — reduced performance in downstream system"),
        ("N", "None"),
    ])

    score, vector = calculate_cvss40(av, ac, at, pr, ui, vc, vi, va, sc, si, sa)
    sev = severity_from_score(score)

    sev_color = RED if sev in ("CRITICAL", "HIGH") else (YELLOW if sev == "MEDIUM" else GREEN)
    print(f"\n  {BOLD}CVSS 4.0 Score: {sev_color}{score} {sev}{RESET}")
    print(f"  {BOLD}Vector:{RESET} {vector}")
    print(f"  {DIM}Verify: https://www.first.org/cvss/calculator/4.0#{vector}{RESET}")

    params = {
        "AV": av, "AC": ac, "AT": at, "PR": pr, "UI": ui,
        "VC": vc, "VI": vi, "VA": va, "SC": sc, "SI": si, "SA": sa,
    }
    return score, vector, params


# ─── Report skeleton generator ────────────────────────────────────────────────

def generate_report_skeleton(info: dict) -> str:
    """Generate a HackerOne-style report skeleton."""
    vuln_type  = info.get("vuln_type", "VULN_TYPE")
    target     = info.get("target", "TARGET")
    endpoint   = info.get("endpoint", "ENDPOINT")
    impact     = info.get("impact", "IMPACT_DESCRIPTION")
    score      = info.get("cvss_score", 0.0)
    vector     = info.get("cvss_vector", "CVSS:3.1/...")
    sev        = severity_from_score(score)
    scanner_confidence = info.get("scanner_confidence", "unknown")
    validation_status = info.get("validation_status", "scanner_hit")
    scanner_summary = info.get("scanner_summary", {})
    date       = datetime.now().strftime("%Y-%m-%d")

    return f"""# {vuln_type} on {endpoint} — [fill in specific impact]

**Program:** {target}
**Severity:** {sev} ({score}) — {vector}
**Scanner Confidence:** {scanner_confidence}
**Validation Status:** {validation_status}
**Scanner Summary:** {scanner_summary if scanner_summary else "n/a"}
**Date Found:** {date}

---

## Summary

[2-3 sentences. What is the vulnerability? Where is it? What can an attacker do?]

The `{endpoint}` endpoint [describe the vulnerability in one sentence]. By [describe
the attack], an attacker can [describe the concrete impact].

---

## Steps to Reproduce

> **Setup:** Create two accounts — Attacker (email: attacker@test.com) and Victim (email: victim@test.com).

1. Log in as **Attacker**
2. [Step 2 — specific action]
3. [Step 3 — specific request with actual parameter names]
   ```
   [INSERT ACTUAL HTTP REQUEST HERE — e.g., curl command or Burp request]
   ```
4. [Step 4 — what to observe in the response]
5. Confirm: [what proves the vulnerability — e.g., victim's data appears in response]

---

## Proof of Concept

**Request:**
```http
[PASTE ACTUAL REQUEST — METHOD, URL, HEADERS, BODY]
```

**Response:**
```json
[PASTE ACTUAL RESPONSE SHOWING THE VULNERABILITY]
```

**Screenshots:** [attach: TARGET-{vuln_type.lower().replace(' ','-')}-step1.png, etc.]

---

## Impact

{impact}

[Quantify: number of users affected, type of data exposed, what actions an attacker can take]

---

## CVSS

**Vector:** `{vector}`
**Score:** {score} ({sev})

| Metric | Value | Rationale |
|---|---|---|
| Attack Vector (AV) | {info.get('cvss_params', {}).get('AV', '?')} | [explain] |
| Attack Complexity (AC) | {info.get('cvss_params', {}).get('AC', '?')} | [explain] |
| Attack Requirements (AT) | {info.get('cvss_params', {}).get('AT', '?')} | [explain] |
| Privileges Required (PR) | {info.get('cvss_params', {}).get('PR', '?')} | [explain] |
| User Interaction (UI) | {info.get('cvss_params', {}).get('UI', '?')} | [explain] |
| Vuln. Confidentiality (VC) | {info.get('cvss_params', {}).get('VC', '?')} | [explain] |
| Vuln. Integrity (VI) | {info.get('cvss_params', {}).get('VI', '?')} | [explain] |
| Vuln. Availability (VA) | {info.get('cvss_params', {}).get('VA', '?')} | [explain] |
| Subseq. Confidentiality (SC) | {info.get('cvss_params', {}).get('SC', '?')} | [explain] |
| Subseq. Integrity (SI) | {info.get('cvss_params', {}).get('SI', '?')} | [explain] |
| Subseq. Availability (SA) | {info.get('cvss_params', {}).get('SA', '?')} | [explain] |

---

## Fix Recommendation

[Specific code-level fix — name the file, function, and what to change]

Example: In `path/to/file.ts`, the `functionName` function should verify
`resource.user_id === req.user.id` before returning data.

---

## Validation Notes

| Gate | Result |
|---|---|
| Is it real? | {'PASS' if info.get('gate1_pass') else 'FAIL'} |
| Is it in scope? | {'PASS' if info.get('gate2_pass') else 'FAIL'} |
| Is it exploitable? | {'PASS' if info.get('gate3_pass') else 'FAIL'} |
| Is it a dup? | {'PASS' if info.get('gate4_pass') else 'FAIL'} |
"""


PRE_SUBMIT_CHECKLIST = [
    "Title follows formula: [Class] in [endpoint] allows [actor] to [impact]",
    "First sentence states exact impact in plain English",
    "Steps to Reproduce has exact HTTP request (copy-paste ready)",
    "Response showing the bug is included (screenshot or JSON body)",
    "Two test accounts used — not just one account testing itself",
    "CVSS score calculated and included",
    "Recommended fix is 1-2 sentences (not a lecture)",
    "No typos in endpoint paths or parameter names",
    "Report is < 600 words — triagers skim long reports",
    "Severity claimed matches impact described — don't overclaim",
    "Never used \"could potentially\" or \"may allow\"",
    "PoC is reproducible by triager from a fresh state",
]


def write_submission_notes(
    output_dir: str,
    report_path: str,
    info: dict,
    gates: list[tuple[int, str, bool]],
    all_pass: bool,
    notes_path: str = "",
) -> str:
    """Persist terminal guidance that would otherwise be lost in scrollback."""
    path = notes_path or os.path.join(output_dir, "submission-notes.md")
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    gate_rows = "\n".join(
        f"| Gate {n} | {name} | {'PASS' if passed else 'FAIL'} |"
        for n, name, passed in gates
    )
    checklist = "\n".join(f"- [ ] {item}" for item in PRE_SUBMIT_CHECKLIST)
    verdict = (
        "All validation gates passed. The report is a submission candidate after "
        "you fill in the exact request, response, screenshots, and fix notes."
        if all_pass else
        "One or more validation gates failed. Keep this as a draft until the "
        "failed gates are resolved; do not submit it yet."
    )

    content = f"""# Submission Notes

Generated: {date}

## Finding

- Program: {info.get('target', 'unknown')}
- Vulnerability type: {info.get('vuln_type', 'unknown')}
- Endpoint: {info.get('endpoint', 'unknown')}
- Scanner confidence: {info.get('scanner_confidence', 'unknown')}
- Validation status: {info.get('validation_status', 'scanner_hit')}
- Report draft: {report_path}
- CVSS: {info.get('cvss_score', 'n/a')} — `{info.get('cvss_vector', 'n/a')}`

## Validation Summary

| Gate | Question | Result |
|---|---|---|
{gate_rows}

## One Note Before Submitting

{verdict}

## Final Checklist Before Submitting

{checklist}

## References

- `commands/report.md` — platform-specific report structure.
- `skills/report-writing/SKILL.md` — impact-first templates, downgrade counters, and pre-submit checklist.
- `skills/triage-validation/SKILL.md` — 7-Question Gate and never-submit list.
- https://www.first.org/cvss/calculator/4.0 — verify the CVSS 4.0 vector.
"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


def write_validation_json(output_dir: str, info: dict, gate_notes: dict) -> str:
    """Persist the structured validation answers for future tmux/session pickup."""
    path = os.path.join(output_dir, "validation.json")

    all_pass = all([
        info.get("gate1_pass"), info.get("gate2_pass"),
        info.get("gate3_pass"), info.get("gate4_pass"),
    ])

    # Collect rejection reasons across all failed gates (chain-not-proven is set by caller)
    rejection_reasons = [
        n.get("rejection_reason")
        for n in gate_notes.values()
        if n.get("rejection_reason")
    ]

    status = "validated_finding" if all_pass else "scanner_hit"
    finding_id = None
    try:
        from tools.research_log import draft_from_validation, new_finding_id
        finding_id = new_finding_id()
        memory_dir = os.environ.get("BBHUNT_MEMORY_DIR", "hunt-memory")
        draft_from_validation(
            target=str(info.get("target") or "unknown"),
            vuln_class=str(info.get("vuln_type") or "unknown"),
            endpoint=str(info.get("endpoint") or "unknown"),
            status=status,
            rejection_reasons=rejection_reasons,
            finding_id=finding_id,
            memory_dir=memory_dir,
            write=True,
        )
    except Exception as exc:  # noqa: BLE001 — learning must never break validation
        print(f"[!] research log skipped: {exc}")

    payload = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        # scanner_confidence comes from --scanner-confidence CLI arg (confirmed/possible/informational/unknown)
        "scanner_confidence": info.get("scanner_confidence", "unknown"),
        # validated_finding = all 4 gates passed with real curl PoC
        # scanner_hit = gates failed or no PoC — do not submit
        "status": status,
        "finding_id": finding_id,
        "curl_poc": info.get("curl_poc", ""),
        "scanner_summary": info.get("scanner_summary", {}),
        "rejection_reasons": rejection_reasons,
        "finding": {
            "program":            info.get("target"),
            "vulnerability_type": info.get("vuln_type"),
            "endpoint":           info.get("endpoint"),
            "impact":             info.get("impact"),
            "curl_poc":           info.get("curl_poc", ""),
            "cvss_score":         info.get("cvss_score"),
            "cvss_vector":        info.get("cvss_vector"),
            "cvss_params":        info.get("cvss_params"),
        },
        "gates": {
            "is_real":      {"passed": info.get("gate1_pass"), "notes": gate_notes["gate1"]},
            "in_scope":     {"passed": info.get("gate2_pass"), "notes": gate_notes["gate2"]},
            "exploitable":  {"passed": info.get("gate3_pass"), "notes": gate_notes["gate3"]},
            "not_duplicate":{"passed": info.get("gate4_pass"), "notes": gate_notes["gate4"]},
        },
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
        f.write("\n")
    return path


# ─── Main ─────────────────────────────────────────────────────────────────────

def _run_auto(finding_path: str, output_dir: str) -> int:
    """Non-interactive path: run the programmatic verifier gate on a finding
    JSON and persist validation.json. This is what the swarm coordinator, the
    report gate, and CI call — no prompts, deterministic oracle only."""
    from tools.validate_core import verify_finding_programmatic, is_report_ready

    try:
        with open(finding_path, "r", encoding="utf-8") as fh:
            finding = json.load(fh)
    except (OSError, ValueError) as exc:
        print(f"{RED}[-] bad finding JSON: {exc}{RESET}", file=sys.stderr)
        return 3

    out_dir = output_dir or os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "findings",
        "auto-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    result = verify_finding_programmatic(
        finding, session_dir=out_dir, write_dir=out_dir,
    )
    status = result["status"]
    color = GREEN if status == "validated_finding" else YELLOW
    print(f"  {BOLD}{color}status: {status}{RESET}  (gate: {result['gate_verdict']})")
    print(f"  verifier: {result['verifier']['oracle']}")
    if result["rejection_reasons"]:
        for r in result["rejection_reasons"]:
            print(f"    {DIM}- {r}{RESET}")
    print(f"  validation.json: {os.path.join(out_dir, 'validation.json')}")
    return 0 if is_report_ready(result) else 1


def main():
    parser = argparse.ArgumentParser(description="Interactive bug validation assistant")
    parser.add_argument("--auto", default="", metavar="FINDING_JSON",
                        help="Non-interactive: run the deterministic verifier gate on a finding JSON")
    parser.add_argument("--output",  default="", help="Output path for generated report skeleton")
    parser.add_argument("--notes-output", default="", help="Output path for persisted submission notes")
    parser.add_argument("--program", default="", help="HackerOne program handle for dup check")
    parser.add_argument(
        "--scanner-summary",
        default="",
        help="Path to tools/vuln_scanner.sh summary.json for calibration handoff",
    )
    parser.add_argument(
        "--scanner-confidence",
        default="unknown",
        choices=["confirmed", "possible", "informational", "unknown"],
        help="Confidence level from the scanner that produced this finding",
    )
    args = parser.parse_args()

    if args.auto:
        out_dir = os.path.dirname(os.path.abspath(args.output)) if args.output else ""
        sys.exit(_run_auto(args.auto, out_dir))

    print_banner(
        "Bug Validation Assistant",
        target=args.program or None,
        steps=[
            ("Gate 1 — Real",        "is the finding reproducible / not a placebo?"),
            ("Gate 2 — In scope",    "matches program scope + asset list"),
            ("Gate 3 — Exploitable", "real attacker, real impact, right now"),
            ("Gate 4 — Not dup",     "search disclosures + Hacktivity"),
            ("CVSS + report",        "score + H1 report skeleton"),
        ],
    )

    # Collect basic info upfront
    section("Target Information")
    target_program = args.program or ask("HackerOne program handle (e.g., 'target-program')", "unknown")
    vuln_type      = ask("Vulnerability type (e.g., 'IDOR', 'Stored XSS', 'SSRF')")
    endpoint       = ask("Affected endpoint (e.g., '/api/invoices/:id')")
    scanner_summary = load_json_file(args.scanner_summary)

    # Run the 4 gates
    g1_pass, g1_notes = gate1_is_real(vuln_type)
    g2_pass, g2_notes = gate2_in_scope(target_program)
    g3_pass, g3_notes = gate3_exploitable()
    g4_pass, g4_notes = gate4_not_dup(vuln_type, endpoint, target_program)

    # Summary
    section("Validation Summary")
    gates = [
        (1, "Is it real?",       g1_pass),
        (2, "Is it in scope?",   g2_pass),
        (3, "Is it exploitable?",g3_pass),
        (4, "Is it a dup?",      g4_pass),
    ]
    all_pass = all(p for _, _, p in gates)

    for n, name, passed in gates:
        icon = f"{GREEN}✓{RESET}" if passed else f"{RED}✗{RESET}"
        print(f"  Gate {n} — {name}: {icon}")

    print()
    if all_pass:
        print(f"  {BOLD}{GREEN}All gates passed! This looks like a valid finding.{RESET}")
    else:
        failed = [name for _, name, p in gates if not p]
        print(f"  {BOLD}{RED}Failed: {', '.join(failed)}{RESET}")
        print(f"  {DIM}Resolve the failed gates before submitting.{RESET}")

    if not all_pass:
        if not ask_yn("\nContinue to CVSS scoring anyway?", default=False):
            sys.exit(0)

    # CVSS scoring
    cvss_score, cvss_vector, cvss_params = score_cvss()

    # Generate report skeleton
    section("Report Generation")
    impact_desc = g3_notes.get("impact_description", "")

    info = {
        "target":             target_program,
        "vuln_type":          vuln_type,
        "endpoint":           endpoint,
        "impact":             impact_desc,
        "curl_poc":           g3_notes.get("curl_poc", ""),
        "scanner_confidence": args.scanner_confidence,
        "scanner_summary":    scanner_summary,
        "cvss_score":         cvss_score,
        "cvss_vector":        cvss_vector,
        "cvss_params":        cvss_params,
        "gate1_pass":         g1_pass,
        "gate2_pass":         g2_pass,
        "gate3_pass":         g3_pass,
        "gate4_pass":         g4_pass,
        "validation_status":  "validated_finding" if all_pass else "scanner_hit",
    }

    skeleton = generate_report_skeleton(info)

    # Determine output path
    if args.output:
        output_path = args.output
    else:
        safe_name = vuln_type.lower().replace(" ", "-").replace("/", "-")
        safe_target = target_program.replace(" ", "-")
        base_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "findings", f"{safe_target}-{safe_name}"
        )
        os.makedirs(base_dir, exist_ok=True)
        output_path = os.path.join(base_dir, "hackerone-report.md")

    output_dir = os.path.dirname(os.path.abspath(output_path)) or "."
    os.makedirs(output_dir, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(skeleton)

    notes_path = write_submission_notes(output_dir, output_path, info, gates, all_pass, args.notes_output)
    validation_path = write_validation_json(output_dir, info, {
        "gate1": g1_notes,
        "gate2": g2_notes,
        "gate3": g3_notes,
        "gate4": g4_notes,
    })

    print(f"  {BOLD}{GREEN}Report skeleton generated:{RESET} {output_path}")
    print(f"  {BOLD}{GREEN}Submission notes saved:{RESET} {notes_path}")
    print(f"  {BOLD}{GREEN}Validation JSON saved:{RESET} {validation_path}")
    print(f"\n  {BOLD}Next steps:{RESET}")
    print(f"    1. Fill in the actual HTTP request + response in the PoC section")
    print(f"    2. Attach screenshots (naming: TARGET-VULN-TYPE-STEP-N.png)")
    print(f"    3. Replace all [bracketed] placeholders with specific details")
    print(f"    4. Review submission-notes.md before sending the report")
    print()


if __name__ == "__main__":
    main()
