import asyncio
from contextlib import suppress
from json import loads
from os import getenv
from re import search
from unittest.mock import AsyncMock, Mock, call

import pytest
from anyio import CancelScope
from mcp.client import Client
from mcp.types import TextContent
from patchright.async_api import Error as PatchrightError
from patchright.async_api import TimeoutError as PatchrightTimeoutError
from pydantic import ValidationError

from scrapling.core.ai import ScraplingMCPServer, SessionType
from scrapling.core.ai.server import _SessionEntry
from scrapling.core._types import Any
from scrapling.engines._browsers._base import AsyncSession


HTML = """<!DOCTYPE html><html><head><style>
#target { position: absolute; left: 80px; top: 80px; width: 120px; height: 60px; }
#target:hover { background: rgb(0, 128, 0); }
#next { position: absolute; left: 80px; top: 180px; width: 120px; height: 40px; }
#below { position: absolute; left: 80px; top: 4000px; width: 120px; height: 60px; }
</style></head><body><button id="target">Target</button><a id="next" href="/next">Next page</a>
<button id="below">Below</button>
<textarea id="events" hidden>[]</textarea><script>
const events = document.querySelector('#events');
for (const type of ['mousemove', 'mousedown', 'mouseup', 'click', 'dblclick', 'contextmenu', 'auxclick']) {
    document.addEventListener(type, event => {
        events.value = JSON.stringify([...JSON.parse(events.value), {type, x: event.clientX, y: event.clientY,
            button: event.button, buttons: event.buttons, detail: event.detail, trusted: event.isTrusted,
            target: event.target.id}]);
        if (type === 'contextmenu') event.preventDefault();
    });
}
</script></body></html>"""


def _server(session_type: SessionType = "stealthy") -> tuple[ScraplingMCPServer, AsyncSession, Mock]:
    server = ScraplingMCPServer()
    session = AsyncSession()
    session._is_alive = True
    page = Mock()
    page.is_closed.return_value = False
    page.mouse.move = AsyncMock()
    page.mouse.click = AsyncMock()
    page.mouse.up = AsyncMock()
    page.mouse.wheel = AsyncMock()
    page.locator.return_value.click = AsyncMock()
    page.locator.return_value.hover = AsyncMock()
    session.page_pool.add_page(page).mark_ready()
    server._sessions["browser"] = _SessionEntry(session, session_type)
    return server, session, page


@pytest.mark.asyncio
async def test_browser_mouse_schema_and_annotations() -> None:
    async with Client(ScraplingMCPServer()._build_server("127.0.0.1", 8000)) as client:
        tools = {tool.name: tool for tool in (await client.list_tools()).tools}
        for name in ("browser_mouse", "browser_mouse_move", "browser_click", "browser_mouse_wheel"):
            assert name not in tools
            assert (await client.call_tool(name, {"session_id": "browser"})).is_error
    tool = tools["browser_actions"]
    assert tool.title == "Browser actions"
    schema = tool.input_schema
    assert set(schema["properties"]) == {"session_id", "actions", "slowly"}
    assert schema["properties"]["slowly"]["type"] == "boolean"
    assert schema["properties"]["slowly"]["default"] is False
    assert schema["required"] == ["session_id", "actions"]
    actions = schema["properties"]["actions"]
    assert actions["type"] == "array" and actions["minItems"] == 1
    items = actions["items"]
    assert items["discriminator"]["propertyName"] == "type"
    variants = {kind: schema["$defs"][ref.rsplit("/", 1)[1]] for kind, ref in items["discriminator"]["mapping"].items()}
    assert set(variants) == {
        "move",
        "click",
        "wheel",
        "wait_time",
        "wait_element",
        "wait_load",
        "textbox",
        "checkbox",
        "radio",
        "combobox",
        "press_key",
        "dialog",
    }
    assert len(items["oneOf"]) == 12
    assert "_Selector" not in schema["$defs"] and "_Ref" not in schema["$defs"]
    for kind in ("move", "click", "wheel"):
        variant = variants[kind]
        assert variant["required"] == ["type"]
        assert variant["properties"]["type"]["const"] == kind
    for kind in ("move", "click"):
        assert variants[kind]["properties"]["target"] == {"$ref": "#/$defs/_Target"}
        assert schema["$defs"]["_Target"] == {
            "anyOf": [{"minLength": 1, "type": "string"}, {"type": "null"}],
            "description": "Playwright selector or snapshot ref as aria-ref=<ref>.",
            "title": "Target",
        }
    move = variants["move"]["properties"]
    assert set(move) == {"type", "x", "y", "steps", "target", "timeout"}
    assert move["steps"]["exclusiveMinimum"] == 0
    assert move["steps"]["default"] == 1
    assert move["timeout"]["minimum"] == 0
    assert move["timeout"]["default"] == 30000
    click = variants["click"]["properties"]
    assert set(click) == {"type", "target", "x", "y", "button", "click_count", "delay", "timeout"}
    assert set(click["button"]["enum"]) == {"left", "right", "middle"}
    assert click["click_count"]["exclusiveMinimum"] == 0
    assert click["delay"]["minimum"] == click["timeout"]["minimum"] == 0
    assert {name: click[name]["default"] for name in ("button", "click_count", "delay", "timeout")} == {
        "button": "left",
        "click_count": 1,
        "delay": 0,
        "timeout": 30000,
    }
    assert tool.output_schema is None
    assert tool.annotations is not None
    assert tool.annotations.read_only_hint is False
    assert tool.annotations.destructive_hint is True
    assert tool.annotations.idempotent_hint is False
    assert tool.annotations.open_world_hint is True


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "tool, target, options, expected",
    [
        ("move", {"x": -12.5, "y": 23.5}, {}, {"steps": 1}),
        ("move", {"x": -12.5, "y": 23.5, "target": None}, {}, {"steps": 1}),
        ("move", {"x": -12.5, "y": 23.5}, {"steps": 5, "timeout": 400}, {"steps": 5}),
        ("move", {"target": "button"}, {}, {"timeout": 30000}),
        ("move", {"target": "aria-ref=e4"}, {"steps": 5, "timeout": 500}, {"timeout": 500}),
        ("move", {"target": "button"}, {"timeout": 0}, {"timeout": 0}),
        ("move", {"target": "e12", "x": None, "y": None}, {}, {"timeout": 30000}),
        ("click", {"x": -12.5, "y": 23.5}, {}, {"button": "left", "click_count": 1, "delay": 0}),
        ("click", {"x": -12.5, "y": 23.5, "target": None}, {}, {"button": "left", "click_count": 1, "delay": 0}),
        (
            "click",
            {"x": -12.5, "y": 23.5},
            {"button": "middle", "timeout": 400},
            {"button": "middle", "click_count": 1, "delay": 0},
        ),
        (
            "click",
            {"target": "button"},
            {},
            {"button": "left", "click_count": 1, "delay": 0, "timeout": 30000},
        ),
        (
            "click",
            {"target": "aria-ref=e4"},
            {"button": "right", "click_count": 2, "delay": 30, "timeout": 500},
            {"button": "right", "click_count": 2, "delay": 30, "timeout": 500},
        ),
    ],
)
async def test_browser_mouse_forwards_native_actions(
    tool: str, target: dict[str, Any], options: dict[str, Any], expected: dict[str, Any]
) -> None:
    server, session, page = _server()
    async with Client(server._build_server("127.0.0.1", 8000)) as client:
        result = await client.call_tool(
            "browser_actions", {"session_id": "browser", "actions": [{"type": tool, **target, **options}]}
        )
    assert not result.is_error
    assert result.structured_content is None
    assert result.content == [TextContent(type="text", text="Actions completed.")]
    if tool == "move" and target.get("x") is not None:
        page.mouse.move.assert_awaited_once_with(-12.5, 23.5, **expected)
        page.mouse.click.assert_not_awaited()
        page.locator.assert_not_called()
    elif target.get("x") is not None:
        page.mouse.click.assert_awaited_once_with(-12.5, 23.5, **expected)
        page.mouse.move.assert_not_awaited()
        page.locator.assert_not_called()
    else:
        page.locator.assert_called_once_with(target["target"])
        action = "hover" if tool == "move" else "click"
        getattr(page.locator.return_value, action).assert_awaited_once_with(**expected)
        getattr(page.locator.return_value, "click" if action == "hover" else "hover").assert_not_awaited()
        page.mouse.move.assert_not_awaited()
        page.mouse.click.assert_not_awaited()
    assert session.page_pool.pages_count == 1
    assert session.page_pool.pages[0].state == "ready"
    for name in (
        "goto",
        "evaluate",
        "add_init_script",
        "set_extra_http_headers",
        "unroute_all",
        "set_default_timeout",
        "set_default_navigation_timeout",
        "wait_for_load_state",
    ):
        getattr(page, name).assert_not_called()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "tool, values",
    [
        ("move", {"x": "invalid"}),
        ("move", {"y": None}),
        ("move", {"steps": 1.5}),
        ("move", {"steps": 0}),
        ("move", {"steps": -1}),
        ("move", {"target": ""}),
        ("move", {"target": 123}),
        ("move", {"timeout": -1}),
        ("click", {"button": "back"}),
        ("click", {"click_count": 1.5}),
        ("click", {"click_count": 0}),
        ("click", {"click_count": -1}),
        ("click", {"delay": -1}),
        ("click", {"delay": "invalid"}),
        ("click", {"timeout": -1}),
        ("click", {"target": ""}),
        ("click", {"target": 123}),
    ],
)
async def test_browser_mouse_invalid_input_does_not_reserve_or_use_page(tool: str, values: dict[str, Any]) -> None:
    server, session, page = _server()
    async with Client(server._build_server("127.0.0.1", 8000)) as client:
        result = await client.call_tool(
            "browser_actions",
            {
                "session_id": "browser",
                "actions": [{"type": "move", "x": 1, "y": 2}, {"type": tool, "x": 10, "y": 20, **values}],
            },
        )
    assert result.is_error
    assert result.content and isinstance(result.content[0], TextContent)
    page.mouse.move.assert_not_awaited()
    page.mouse.click.assert_not_awaited()
    page.is_closed.assert_not_called()
    assert session.page_pool.pages[0].state == "ready"


@pytest.mark.parametrize("tool, fields", [("move", ("x", "y", "timeout")), ("click", ("x", "y", "delay", "timeout"))])
@pytest.mark.parametrize("value", [float("nan"), float("inf"), float("-inf")])
def test_browser_mouse_schema_rejects_nonfinite_values(tool: str, fields: tuple[str, ...], value: float) -> None:
    server, session, page = _server()
    registered = server._build_server("127.0.0.1", 8000)._tool_manager.get_tool("browser_actions")
    assert registered is not None
    for field in fields:
        with pytest.raises(ValidationError):
            registered.fn_metadata.arg_model.model_validate(
                {"session_id": "browser", "actions": [{"type": tool, "x": 10, "y": 20, field: value}]}
            )
    page.mouse.move.assert_not_awaited()
    page.mouse.click.assert_not_awaited()
    page.is_closed.assert_not_called()
    assert session.page_pool.pages[0].state == "ready"


@pytest.mark.asyncio
@pytest.mark.parametrize("tool", ["move", "click"])
@pytest.mark.parametrize(
    "target",
    [
        {},
        {"x": 1},
        {"y": 2},
        {"target": None},
        {"selector": "button"},
        {"ref": "e2"},
        {"target": "button", "x": 1},
        {"target": "aria-ref=e2", "y": 2},
        {"target": "button", "x": 1, "y": 2},
        {"target": "aria-ref=e2", "x": 1, "y": 2},
    ],
)
async def test_browser_mouse_requires_exactly_one_complete_target(tool: str, target: dict[str, Any]) -> None:
    server, session, page = _server()
    async with Client(server._build_server("127.0.0.1", 8000)) as client:
        result = await client.call_tool(
            "browser_actions",
            {"session_id": "browser", "actions": [{"type": "move", "x": 1, "y": 2}, {"type": tool, **target}]},
        )
    assert result.is_error
    page.is_closed.assert_not_called()
    page.mouse.move.assert_not_awaited()
    page.mouse.click.assert_not_awaited()
    page.locator.assert_not_called()
    assert session.page_pool.pages[0].state == "ready"


@pytest.mark.asyncio
@pytest.mark.parametrize("tool", ["move", "click"])
@pytest.mark.parametrize(
    "state, message",
    [
        ("missing", "not found"),
        ("dead", "no longer alive"),
        ("static", "'stealthy'"),
        ("empty", "browser_fetch"),
        ("busy", "busy"),
        ("closed", "closed"),
    ],
)
async def test_browser_mouse_session_errors_reach_mcp(tool: str, state: str, message: str) -> None:
    server, session, page = _server("static" if state == "static" else "stealthy")
    if state == "missing":
        server._sessions.clear()
    elif state == "dead":
        session._is_alive = False
    elif state == "empty":
        session.page_pool.clear()
    elif state == "busy":
        session.page_pool.pages[0].mark_busy()
    elif state == "closed":
        page.is_closed.return_value = True
    async with Client(server._build_server("127.0.0.1", 8000)) as client:
        result = await client.call_tool(
            "browser_actions", {"session_id": "browser", "actions": [{"type": tool, "x": 10, "y": 20}]}
        )
    assert result.is_error
    assert result.content and isinstance(result.content[0], TextContent)
    assert message in result.content[0].text
    page.mouse.move.assert_not_awaited()
    page.mouse.click.assert_not_awaited()
    if state == "closed":
        assert session.page_pool.pages_count == 0
    elif state == "busy":
        assert session.page_pool.pages[0].state == "busy"


@pytest.mark.asyncio
@pytest.mark.parametrize("tool", ["move", "click"])
@pytest.mark.parametrize("closed", [False, True])
@pytest.mark.parametrize("target", [{"x": 10, "y": 20}, {"target": "button"}, {"target": "aria-ref=e1"}])
async def test_browser_mouse_failure_is_not_retried_and_releases_page(
    tool: str, closed: bool, target: dict[str, Any]
) -> None:
    server, session, page = _server()

    async def fail(*args: Any, **kwargs: Any) -> None:
        page.is_closed.return_value = closed
        raise RuntimeError("mouse failed")

    if tool == "move":
        action = page.mouse.move if "x" in target else page.locator.return_value.hover
    else:
        action = page.mouse.click if "x" in target else page.locator.return_value.click
    action.side_effect = fail
    async with Client(server._build_server("127.0.0.1", 8000)) as client:
        result = await client.call_tool(
            "browser_actions", {"session_id": "browser", "actions": [{"type": tool, **target}]}
        )
    assert result.is_error
    assert result.content and isinstance(result.content[0], TextContent)
    assert "mouse failed" in result.content[0].text
    action.assert_awaited_once()
    if closed:
        assert session.page_pool.pages_count == 0
    else:
        assert session.page_pool.pages[0].state == "ready"
        action.side_effect = None
        await server.browser_actions("browser", [{"type": tool, **target}])
    page.close.assert_not_called()
    page.mouse.wheel.assert_not_awaited()
    page.mouse.up.assert_not_awaited()


@pytest.mark.asyncio
@pytest.mark.parametrize("target", [{"x": 10, "y": 20}, {"target": "button"}, {"target": "aria-ref=e1"}])
async def test_browser_mouse_reserves_page_until_cancelled(target: dict[str, Any]) -> None:
    server, session, page = _server()
    entered = asyncio.Event()
    release = asyncio.Event()

    async def move(*args: Any, **kwargs: Any) -> None:
        entered.set()
        await release.wait()

    action = page.mouse.move if "x" in target else page.locator.return_value.hover
    action.side_effect = move
    task = asyncio.create_task(
        server.browser_actions("browser", [{"type": "move", **target, "steps": 3}, {"type": "wheel", "delta_y": 120}])
    )
    try:
        await asyncio.wait_for(entered.wait(), 5)
        assert session.page_pool.pages[0].state == "busy"
        assert session.page_pool.get_ready_page() is None
        with pytest.raises(RuntimeError, match="busy"):
            await server.browser_actions("browser", [{"type": "click", "x": 10, "y": 20}])
        with pytest.raises(RuntimeError, match="busy"):
            await server.browser_extract("browser")
    finally:
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task
    assert session.page_pool.pages[0].state == "ready"
    page.close.assert_not_called()
    page.mouse.wheel.assert_not_awaited()


@pytest.mark.asyncio
async def test_browser_mouse_click_timeout_holds_page_until_button_is_released() -> None:
    server, session, page = _server()
    releasing = asyncio.Event()
    release = asyncio.Event()

    async def unpress(*args: Any, **kwargs: Any) -> None:
        releasing.set()
        await release.wait()

    page.locator.return_value.click.side_effect = PatchrightTimeoutError("click timed out")
    page.mouse.up.side_effect = unpress
    task = asyncio.create_task(
        server.browser_actions("browser", [{"type": "click", "target": "button", "button": "right"}])
    )
    try:
        await asyncio.wait_for(releasing.wait(), 5)
        assert session.page_pool.pages[0].state == "busy"
        assert session.page_pool.get_ready_page() is None
        with pytest.raises(RuntimeError, match="busy"):
            await server.browser_actions("browser", [{"type": "move", "x": 30, "y": 40}])
        release.set()
        with pytest.raises(RuntimeError, match=r"Action 1 \(click\) failed: click timed out") as error:
            await task
        assert isinstance(error.value.__cause__, PatchrightTimeoutError)
    finally:
        release.set()
        with suppress(RuntimeError):
            await task
    page.mouse.up.assert_awaited_once_with(button="right")
    page.locator.return_value.click.assert_awaited_once()
    assert session.page_pool.pages[0].state == "ready"
    page.close.assert_not_called()
    page.mouse.wheel.assert_not_awaited()


@pytest.mark.asyncio
@pytest.mark.parametrize("cancel_mode", ["task", "scope"])
@pytest.mark.parametrize("target", [{"x": 10, "y": 20}, {"target": "button"}, {"target": "aria-ref=e1"}])
async def test_browser_mouse_cancelled_click_holds_page_until_button_is_released(
    cancel_mode: str, target: dict[str, Any]
) -> None:
    server, session, page = _server()
    entered = asyncio.Event()
    releasing = asyncio.Event()
    release = asyncio.Event()
    scope = CancelScope()

    async def press(*args: Any, **kwargs: Any) -> None:
        entered.set()
        await asyncio.Event().wait()

    async def unpress(*args: Any, **kwargs: Any) -> None:
        releasing.set()
        await release.wait()

    async def click() -> None:
        with scope:
            await server.browser_actions(
                "browser",
                [{"type": "click", **target, "button": "right", "delay": 60000}, {"type": "wheel", "delta_y": 120}],
            )

    action = page.mouse.click if "x" in target else page.locator.return_value.click
    action.side_effect = press
    page.mouse.up.side_effect = unpress
    task = asyncio.create_task(click())
    try:
        await asyncio.wait_for(entered.wait(), 5)
        scope.cancel() if cancel_mode == "scope" else task.cancel()
        await asyncio.wait_for(releasing.wait(), 5)
        assert session.page_pool.pages[0].state == "busy"
        assert session.page_pool.get_ready_page() is None
        with pytest.raises(RuntimeError, match="busy"):
            await server.browser_actions("browser", [{"type": "move", "x": 30, "y": 40}])
        release.set()
        if cancel_mode == "scope":
            await asyncio.wait_for(task, 5)
            assert scope.cancelled_caught
        else:
            with pytest.raises(asyncio.CancelledError):
                await task
    finally:
        release.set()
        if not task.done():
            task.cancel()
        with suppress(asyncio.CancelledError):
            await task
    page.mouse.up.assert_awaited_once_with(button="right")
    action.assert_awaited_once()
    assert session.page_pool.pages[0].state == "ready"
    page.close.assert_not_called()
    page.mouse.wheel.assert_not_awaited()


@pytest.mark.asyncio
@pytest.mark.parametrize("cancelled", [False, True])
@pytest.mark.parametrize("native_cleanup_error", [False, True])
@pytest.mark.parametrize("closed", [False, True])
async def test_browser_mouse_cleanup_failure_preserves_click_error(
    cancelled: bool, native_cleanup_error: bool, closed: bool
) -> None:
    server, session, page = _server()
    entered = asyncio.Event()
    release = asyncio.Event()
    timeout = PatchrightTimeoutError("click timed out")
    cleanup_error = (PatchrightError if native_cleanup_error else RuntimeError)("button release failed")

    async def press(*args: Any, **kwargs: Any) -> None:
        entered.set()
        await release.wait()
        raise timeout

    async def unpress(*args: Any, **kwargs: Any) -> None:
        assert session.page_pool.pages[0].state == "busy"
        page.is_closed.return_value = closed
        raise cleanup_error

    async def click() -> None:
        with pytest.raises(asyncio.CancelledError if cancelled else RuntimeError) as error:
            await server.browser_actions(
                "browser",
                [{"type": "click", "target": "#target", "button": "right"}, {"type": "wheel", "delta_y": 120}],
            )
        original = error.value if cancelled else error.value.__cause__
        if not cancelled:
            assert str(error.value) == "Action 1 (click) failed: click timed out"
            assert original is timeout
        assert original is not None and original.__cause__ is cleanup_error
        raise error.value

    page.locator.return_value.click.side_effect = press
    page.mouse.up.side_effect = unpress
    task = asyncio.create_task(click())
    try:
        await asyncio.wait_for(entered.wait(), 5)
        task.cancel() if cancelled else release.set()
        with pytest.raises(asyncio.CancelledError if cancelled else RuntimeError):
            await asyncio.wait_for(task, 5)
    finally:
        if not task.done():
            task.cancel()
        with suppress(Exception, asyncio.CancelledError):
            await task
    page.locator.return_value.click.assert_awaited_once()
    page.mouse.up.assert_awaited_once_with(button="right")
    page.mouse.wheel.assert_not_awaited()
    if closed:
        assert session.page_pool.pages_count == 0
    else:
        assert session.page_pool.pages[0].state == "ready"


@pytest.mark.asyncio
@pytest.mark.parametrize("actions", [[], [{}], [{"type": "drag", "x": 10, "y": 20}]])
async def test_browser_mouse_rejects_empty_or_unknown_actions(actions: list[dict[str, Any]]) -> None:
    server, session, page = _server()
    async with Client(server._build_server("127.0.0.1", 8000)) as client:
        result = await client.call_tool("browser_actions", {"session_id": "browser", "actions": actions})
    assert result.is_error
    page.is_closed.assert_not_called()
    assert session.page_pool.pages[0].state == "ready"


@pytest.mark.asyncio
async def test_browser_mouse_mixed_chain_keeps_one_page_reserved() -> None:
    server, session, page = _server()
    reservations = []

    async def record(*args: Any, **kwargs: Any) -> None:
        reservations.append(session.page_pool.pages[0].state)

    for action in (
        page.mouse.move,
        page.mouse.wheel,
        page.mouse.click,
        page.locator.return_value.hover,
        page.locator.return_value.click,
    ):
        action.side_effect = record
    actions = [
        {"type": "move", "x": 10, "y": 20, "steps": 4},
        {"type": "move", "target": "#panel", "timeout": 500},
        {"type": "wheel", "delta_y": 120},
        {"type": "click", "target": "aria-ref=e4", "button": "right"},
        {"type": "click", "x": 30, "y": 40, "click_count": 2},
    ]
    async with Client(server._build_server("127.0.0.1", 8000)) as client:
        result = await client.call_tool("browser_actions", {"session_id": "browser", "actions": actions})
    assert not result.is_error
    assert result.content == [TextContent(type="text", text="Actions completed.")]
    assert page.mock_calls == [
        call.is_closed(),
        call.mouse.move(10, 20, steps=4),
        call.locator("#panel"),
        call.locator().hover(timeout=500),
        call.mouse.wheel(0, 120),
        call.locator("aria-ref=e4"),
        call.locator().click(button="right", click_count=1, delay=0, timeout=30000),
        call.mouse.click(30, 40, button="left", click_count=2, delay=0),
        call.is_closed(),
    ]
    assert reservations == ["busy"] * len(actions)
    assert session.page_pool.pages[0].state == "ready"


@pytest.mark.asyncio
@pytest.mark.parametrize("kind", ["move", "click", "wheel"])
async def test_browser_mouse_chain_reports_failed_index_and_keeps_completed_actions(kind: str) -> None:
    server, session, page = _server()
    native_error = RuntimeError("native failure")
    failing = {
        "move": page.locator.return_value.hover,
        "click": page.locator.return_value.click,
        "wheel": page.mouse.wheel,
    }[kind]
    failing.side_effect = native_error
    actions = [
        {"type": "move", "x": 10, "y": 20},
        {"type": kind, **({"target": "#target"} if kind != "wheel" else {"delta_y": 120})},
        {"type": "click", "x": 30, "y": 40},
    ]
    with pytest.raises(RuntimeError, match=rf"Action 2 \({kind}\) failed: native failure") as error:
        await server.browser_actions("browser", actions)
    assert error.value.__cause__ is native_error
    page.mouse.move.assert_awaited_once_with(10, 20, steps=1)
    failing.assert_awaited_once()
    page.mouse.click.assert_not_awaited()
    page.mouse.up.assert_not_awaited()
    assert session.page_pool.pages[0].state == "ready"


@pytest.mark.browser
@pytest.mark.asyncio
async def test_browser_mouse_live_native_events_and_navigation() -> None:
    server = ScraplingMCPServer(executable_path=getenv("SCRAPLING_EXECUTABLE_PATH"))
    requests: list[str] = []

    async def serve(route: Any) -> None:
        if route.request.is_navigation_request():
            requests.append(route.request.url)
        await route.fulfill(
            status=200,
            content_type="text/html",
            body="<html><body><h1>Arrived</h1></body></html>" if route.request.url.endswith("/next") else HTML,
        )

    async with Client(server._build_server("127.0.0.1", 8000)) as client:
        opened = await client.call_tool("browser_open", {"session_id": "browser"})
        assert not opened.is_error
        try:
            session = server._sessions["browser"].session
            await session.context.route("**/*", serve)
            fetched = await client.call_tool(
                "browser_fetch", {"session_id": "browser", "url": "https://mouse.test/", "google_search": False}
            )
            assert not fetched.is_error
            page_info = session.page_pool.pages[0]
            page = page_info.page
            initial_dom = await page.content()
            moved = await client.call_tool(
                "browser_actions",
                {"session_id": "browser", "actions": [{"type": "move", "x": 140, "y": 110, "steps": 4}]},
            )
            assert not moved.is_error
            assert (
                await page.locator("#target").evaluate("element => getComputedStyle(element).backgroundColor")
                == "rgb(0, 128, 0)"
            )
            events = loads(await page.locator("#events").input_value())
            assert events and events[-1]["type"] == "mousemove"
            assert (events[-1]["x"], events[-1]["y"]) == (140, 110)
            for options, event_type, button, detail in (
                ({}, "click", 0, 1),
                ({"click_count": 2, "delay": 10}, "dblclick", 0, 2),
                ({"button": "right"}, "contextmenu", 2, 0),
                ({"button": "middle"}, "auxclick", 1, 1),
            ):
                await page.locator("#events").evaluate("element => element.value = '[]'")
                result = await client.call_tool(
                    "browser_actions",
                    {"session_id": "browser", "actions": [{"type": "click", "x": 140, "y": 110, **options}]},
                )
                assert not result.is_error
                events = loads(await page.locator("#events").input_value())
                assert all(event["trusted"] for event in events)
                assert {"mousedown", "mouseup", event_type} <= {event["type"] for event in events}
                match = next(event for event in events if event["type"] == event_type)
                assert (match["button"], match["detail"]) == (button, detail)
                assert session.page_pool.pages == [page_info] and page_info.state == "ready"
            assert await page.content() == initial_dom
            assert requests == ["https://mouse.test/"]
            clicked = await client.call_tool(
                "browser_actions", {"session_id": "browser", "actions": [{"type": "click", "x": 140, "y": 200}]}
            )
            assert not clicked.is_error
            await page.wait_for_url("https://mouse.test/next", timeout=5000)
            snapshot = await client.call_tool("browser_extract", {"session_id": "browser"})
            assert not snapshot.is_error
            assert snapshot.content and isinstance(snapshot.content[0], TextContent)
            assert "Arrived" in snapshot.content[0].text
            assert requests == ["https://mouse.test/", "https://mouse.test/next"]
            assert session.page_pool.pages == [page_info] and page_info.state == "ready"
        finally:
            closed = await client.call_tool("close_session", {"session_id": "browser"})
            assert not closed.is_error


@pytest.mark.browser
@pytest.mark.asyncio
@pytest.mark.parametrize("cancel_mode", ["task", "scope"])
@pytest.mark.parametrize("target_type", ["xy", "ref"])
async def test_browser_mouse_live_cancelled_click_releases_native_button(cancel_mode: str, target_type: str) -> None:
    server = ScraplingMCPServer(executable_path=getenv("SCRAPLING_EXECUTABLE_PATH"))
    scope = CancelScope()
    target: dict[str, Any] = {"x": 140, "y": 110}

    async def serve(route: Any) -> None:
        await route.fulfill(status=200, content_type="text/html", body=HTML)

    async def click() -> None:
        with scope:
            await server.browser_actions("browser", [{"type": "click", **target, "delay": 60000, "timeout": 0}])

    async with Client(server._build_server("127.0.0.1", 8000)) as client:
        opened = await client.call_tool("browser_open", {"session_id": "browser"})
        assert not opened.is_error
        task = None
        try:
            session = server._sessions["browser"].session
            await session.context.route("**/*", serve)
            fetched = await client.call_tool(
                "browser_fetch", {"session_id": "browser", "url": "https://mouse.test/", "google_search": False}
            )
            assert not fetched.is_error
            page_info = session.page_pool.pages[0]
            page = page_info.page
            if target_type == "ref":
                match = search(r'button "Target".*?\[ref=([^\]]+)\]', await server.browser_extract("browser"))
                assert match is not None
                target = {"target": f"aria-ref={match[1]}"}
            task = asyncio.create_task(click())
            await page.wait_for_function(
                "JSON.parse(document.querySelector('#events').value).some(event => event.type === 'mousedown')",
                timeout=5000,
            )
            assert page_info.state == "busy"
            scope.cancel() if cancel_mode == "scope" else task.cancel()
            if cancel_mode == "scope":
                await asyncio.wait_for(task, 5)
                assert scope.cancelled_caught
            else:
                with pytest.raises(asyncio.CancelledError):
                    await asyncio.wait_for(task, 5)
            assert page_info.state == "ready"
            moved = await client.call_tool(
                "browser_actions", {"session_id": "browser", "actions": [{"type": "move", "x": 150, "y": 120}]}
            )
            assert not moved.is_error
            events = loads(await page.locator("#events").input_value())
            assert all(event["trusted"] for event in events)
            assert len([event for event in events if event["type"] == "mousedown"]) == 1
            assert next(event for event in events if event["type"] == "mousedown")["buttons"] == 1
            assert next(event for event in events if event["type"] == "mouseup")["buttons"] == 0
            assert (events[-1]["type"], events[-1]["buttons"]) == ("mousemove", 0)
            assert session.page_pool.pages == [page_info] and page_info.state == "ready"
        finally:
            if task is not None and not task.done():
                task.cancel()
                with suppress(asyncio.CancelledError):
                    await task
            closed = await client.call_tool("close_session", {"session_id": "browser"})
            assert not closed.is_error


@pytest.mark.browser
@pytest.mark.asyncio
@pytest.mark.parametrize("tool", ["move", "click"])
async def test_browser_mouse_live_selectors_refs_and_scroll(tool: str) -> None:
    server = ScraplingMCPServer(executable_path=getenv("SCRAPLING_EXECUTABLE_PATH"))

    async def serve(route: Any) -> None:
        await route.fulfill(status=200, content_type="text/html", body=HTML)

    async with Client(server._build_server("127.0.0.1", 8000)) as client:
        opened = await client.call_tool("browser_open", {"session_id": "browser"})
        assert not opened.is_error
        try:
            session = server._sessions["browser"].session
            await session.context.route("**/*", serve)
            fetched = await client.call_tool(
                "browser_fetch", {"session_id": "browser", "url": "https://mouse.test/", "google_search": False}
            )
            assert not fetched.is_error
            page_info = session.page_pool.pages[0]
            page = page_info.page
            match = search(r'button "Target".*?\[ref=([^\]]+)\]', await server.browser_extract("browser"))
            assert match is not None
            ref = match[1]
            initial_dom = await page.content()
            for target in (
                {"target": "#target"},
                {"target": 'xpath=//button[@id="target"]'},
                {"target": f"aria-ref={ref}"},
                {"target": "#below"},
            ):
                await page.mouse.move(0, 0)
                await page.locator("#events").evaluate("element => element.value = '[]'")
                result = await client.call_tool(
                    "browser_actions", {"session_id": "browser", "actions": [{"type": tool, **target}]}
                )
                assert not result.is_error
                events = loads(await page.locator("#events").input_value())
                expected_id = "below" if target.get("target") == "#below" else "target"
                if tool == "move":
                    assert events and all(event["type"] == "mousemove" and event["trusted"] for event in events)
                    assert events[-1]["target"] == expected_id
                    assert await page.locator(f"#{expected_id}").evaluate("element => element.matches(':hover')")
                else:
                    clicks = [event for event in events if event["type"] == "click"]
                    assert len(clicks) == 1 and clicks[0]["trusted"]
                    assert clicks[0]["target"] == expected_id
            assert await page.evaluate("window.scrollY") > 0
            assert await page.content() == initial_dom
            await page.locator("#target").evaluate("element => element.remove()")
            for target in ({"target": "button, a"}, {"target": "#missing"}, {"target": f"aria-ref={ref}"}):
                await page.locator("#events").evaluate("element => element.value = '[]'")
                with pytest.raises(RuntimeError, match=rf"Action 1 \({tool}\) failed:") as error:
                    await server.browser_actions(
                        "browser",
                        [{"type": tool, **target, "timeout": 100}],
                    )
                events = loads(await page.locator("#events").input_value())
                if target.get("target") != "button, a":
                    assert isinstance(error.value.__cause__, PatchrightTimeoutError)
                    assert not any(event["type"] in ("mousedown", "click") for event in events)
                    released = [event for event in events if event["type"] == "mouseup"]
                    if tool == "click":
                        assert len(released) == 1 and released[0]["buttons"] == 0
                    else:
                        assert not released
                else:
                    assert isinstance(error.value.__cause__, PatchrightError)
                    assert "strict mode violation" in str(error.value)
                    assert not any(event["type"] in ("mousedown", "mouseup", "click") for event in events)
                assert session.page_pool.pages == [page_info] and page_info.state == "ready"
        finally:
            closed = await client.call_tool("close_session", {"session_id": "browser"})
            assert not closed.is_error


@pytest.mark.browser
@pytest.mark.asyncio
async def test_browser_mouse_click_live_timeout_releases_native_button() -> None:
    server = ScraplingMCPServer(executable_path=getenv("SCRAPLING_EXECUTABLE_PATH"))

    async def serve(route: Any) -> None:
        await route.fulfill(status=200, content_type="text/html", body=HTML)

    async with Client(server._build_server("127.0.0.1", 8000)) as client:
        opened = await client.call_tool("browser_open", {"session_id": "browser"})
        assert not opened.is_error
        try:
            session = server._sessions["browser"].session
            await session.context.route("**/*", serve)
            fetched = await client.call_tool(
                "browser_fetch", {"session_id": "browser", "url": "https://mouse.test/", "google_search": False}
            )
            assert not fetched.is_error
            page_info = session.page_pool.pages[0]
            page = page_info.page
            failed = await client.call_tool(
                "browser_actions",
                {
                    "session_id": "browser",
                    "actions": [{"type": "click", "target": "#target", "delay": 1000, "timeout": 300}],
                },
            )
            assert failed.is_error
            events = loads(await page.locator("#events").input_value())
            assert next(event for event in events if event["type"] == "mousedown")["buttons"] == 1
            moved = await client.call_tool(
                "browser_actions", {"session_id": "browser", "actions": [{"type": "move", "x": 150, "y": 120}]}
            )
            assert not moved.is_error
            events = loads(await page.locator("#events").input_value())
            assert (events[-1]["type"], events[-1]["buttons"]) == ("mousemove", 0)
            assert next(event for event in events if event["type"] == "mouseup")["buttons"] == 0
            assert all(event["trusted"] for event in events)
            assert session.page_pool.pages == [page_info] and page_info.state == "ready"
        finally:
            closed = await client.call_tool("close_session", {"session_id": "browser"})
            assert not closed.is_error
