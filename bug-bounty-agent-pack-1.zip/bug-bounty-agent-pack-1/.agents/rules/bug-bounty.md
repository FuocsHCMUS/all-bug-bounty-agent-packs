---
description: Workspace entry point for bug bounty research and security learning
trigger: always_on
---

Read root AGENTS.md and SKILL.md. Read prompts/00-master-agent.md for a new engagement. Preserve the recorded execution preferences and distinguish evidence states. Load detailed references when relevant. Confirm actual files read; this rule grants no tool execution permission.

