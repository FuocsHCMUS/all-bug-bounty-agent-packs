---
name: bug-bounty-research
description: Use when working in this pack on bug bounty research, CVE applicability, security writeups, vulnerability evidence, reports, or foundational cyber learning.
---

# Bug bounty research loader

Read [the canonical workspace instructions](../../../AGENTS.md), then [the complete skill](../../../SKILL.md). For a new engagement read [the master prompt](../../../prompts/00-master-agent.md). Load relevant linked references from the pack root.

Keep this loader inside the complete pack: its relative links depend on this layout. It does not independently contain the workflow. Confirm the files actually read and preserve the execution preferences in AGENTS.md.

