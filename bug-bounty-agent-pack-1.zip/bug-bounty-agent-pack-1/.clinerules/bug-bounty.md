# Bug bounty pack entry point

Read the workspace root AGENTS.md and SKILL.md. For a new engagement, read prompts/00-master-agent.md. Follow the execution preferences, evidence states, and teaching workflow there. Load only relevant references and confirm actual loaded files. This adapter adds no execution approval.

