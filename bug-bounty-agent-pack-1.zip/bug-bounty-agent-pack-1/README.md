# Bug Bounty Agent Pack 1

An English, workspace-local operating pack for a senior security research agent and a beginner learning beside it.

**Start here:** Open this folder itself as the project workspace. Read [AGENTS.md](AGENTS.md), [SKILL.md](SKILL.md), and [the master prompt](prompts/00-master-agent.md). Paste the master prompt into your agent. No account, subscription, MCP server, or security tool is required to read and use the pack.

The pack supports program discovery, scope interpretation, passive research, CVE applicability analysis, writeup learning, creative hypothesis generation, permitted validation planning, evidence review, report drafting, remediation analysis, and first-principles teaching. It does not promise vulnerabilities, rewards, zero days, or unattended execution. No live company testing was performed when creating this pack.

## Quick start

1. Open this folder, rather than only its parent, in your chosen agent.
2. Ask it to read AGENTS.md and the master prompt, then give you a loading receipt.
3. Start with public program research or the fictional worked example. No program is preselected.
4. Save a program brief and its retrieval date before proposing live tests.
5. Create one case for one program and work from its decision log.
6. Approve a concrete execution plan when a script or security tool actually needs to run.
7. Receive a draft report and a separate learning note. You submit reports yourself.

Copy-and-paste first message:

~~~
Read AGENTS.md, SKILL.md, and prompts/00-master-agent.md in this workspace.
Use public-research mode first. I am a beginner using Windows 11 and Python 3.14.x+.
Research suitable public programs without testing company assets. Explain the
differences between program policy, asset scope, and permission to execute tools.
Create a ranked shortlist, a source ledger, and a proposed first case.
Tell me which files you loaded, what is still unknown, and the next useful action.
~~~

For an offline lesson, substitute:

~~~
Read the same entry points, then use examples/worked-authorization-case.md.
Teach the concepts from the beginning and produce a hypothesis, a control matrix,
a finding decision, a remediation note, and a SOC learning note. Label every
example as fictional; do not browse or send requests to a target.
~~~

## Find the right document

| Need | Read |
|---|---|
| Persistent workspace instructions | [AGENTS.md](AGENTS.md) |
| Skill entry point and routing | [SKILL.md](SKILL.md) |
| Windows and client setup | [SETUP.md](SETUP.md), [compatibility](adapters/COMPATIBILITY.md) |
| Strong initial system-style task prompt | [Master prompt](prompts/00-master-agent.md) |
| Copy-and-paste task prompts | [Prompt library](prompts/01-task-library.md) |
| Roles and optional delegation | [Research roles](prompts/02-role-cards.md) |
| Full research lifecycle | [Research workflow](references/01-research-workflow.md) |
| Offensive reasoning and new hypotheses | [Creative research](references/02-creative-research.md) |
| CVE and patch analysis | [CVE research](references/03-cve-research.md) |
| Writeups, CTFs, and source quality | [Writeup learning](references/04-writeup-learning.md) |
| Web, API, identity, cloud, source, AI surfaces | [Testing playbook](references/05-testing-playbook.md) |
| Controls, falsification, and evidence | [Validation](references/06-validation-evidence.md) |
| Reports, severity, and remediation | [Reporting](references/07-reporting-remediation.md) |
| Security posture, detection, and SOC | [Posture and SOC](references/08-posture-soc.md) |
| Networking and security from first principles | [Foundations](references/09-foundations.md) |
| Learning progression and retention | [Learning system](references/10-learning-system.md) |
| Downloads, approvals, Python, and optional integrations | [Tools and approvals](references/11-tools-approvals.md) |
| Restarting work and memory | [State and handoff](references/12-state-handoff.md) |
| Official sources and freshness notes | [SOURCES.md](SOURCES.md) |
| Case forms and ledgers | [Template guide](templates/README.md) |
| Offline helper and validation | [Script guide](scripts/README.md) |
| Evaluation scenarios and actual QA | [Evaluation](evaluation/SCENARIOS.md), [QA](evaluation/QA-REPORT.md) |

## How the pack is organized

AGENTS.md contains durable instructions. SKILL.md routes tasks to detailed references. The master prompt defines the research and teaching behavior. Templates define reusable evidence and output structures. Thin native entry points help clients discover the same content without copying the whole manual into every context window.

The native skill folders contain loaders, not independent copies. **Keep the whole folder together.** Installing only a loader into a global skills directory will break its relative links. See SETUP.md for installation choices.

## What was added beyond the initial request

- Explicit evidence states so leads, applicability, and demonstrated impact stay distinguishable.
- Falsification and negative controls to reduce false positives.
- An invariant-based creativity method, chain analysis, and patch-variant research.
- A scoped execution approval ledger that remembers earlier approvals.
- Separate public research, local lab, and approved live-test modes.
- A security posture model that includes strengths, uncertainty, and confidence.
- SOC telemetry, detection ideas, incident triage, and purple-team learning.
- Reusable learning notes, misconception checks, and an eight-stage study path.
- Offline case creation, URL classification, evidence hashing, and pack verification.
- Version-aware adapters and behavioral evaluation scenarios.

These are research aids. They do not bypass the selected model's policies or the agent client's execution controls.

