# Setup on Windows 11

This folder is a complete local pack. You do not need to install it globally, change system settings, or enable every integration.

## Recommended layout

Open bug-bounty-agent-pack-1 as the agent's workspace. The root AGENTS.md is the canonical durable instruction file. Root SKILL.md is the complete routing entry point. Client-specific skill folders contain small loaders that refer back to the root.

| Client | Included entry point |
|---|---|
| Claude Code | Root AGENTS.md; .claude/skills/bug-bounty-research/SKILL.md |
| Codex | Root AGENTS.md; .agents/skills/bug-bounty-research/SKILL.md |
| OpenCode | Root AGENTS.md; shared .agents/skills loader |
| Cline | Root AGENTS.md; .clinerules/bug-bounty.md; .cline/skills loader |
| Cursor | Root AGENTS.md; .cursor/rules/bug-bounty.mdc |
| Antigravity | Root AGENTS.md; shared .agents/skills loader; .agents/rules/bug-bounty.md |

These are filesystem integrations, not installed extensions. See [compatibility](adapters/COMPATIBILITY.md) for verified documentation and limitations. Do not assume identical precedence across clients.

## First-session loading check

Ask the agent to read AGENTS.md, SKILL.md, and the master prompt. Request a receipt with actual paths and a summary of tool-execution preferences. Ask it what it will do when a CVE matches only a version banner. It should answer that applicability and impact still require evidence.

If a client does not show the skill automatically, explicitly reference the root SKILL.md in chat. A plain instruction to read a file is a fallback workflow; it is not a guarantee that a client imported the file before the model began.

## Claude Code

Modern Claude Code can use AGENTS.md directly. There is deliberately no root CLAUDE.md in this pack. Check your version and whether project or ancestor CLAUDE.md/CLAUDE.local.md files suppress default AGENTS.md discovery. Inspect /memory after starting the session.

For a legacy session that cannot read AGENTS.md, copy adapters/claude/CLAUDE.legacy.md to the pack root as CLAUDE.md only if needed. Its @AGENTS.md import retains one canonical file. Do not put a literal relative path to the legacy file into a new CLAUDE.md and assume that is an import.

## Working from a larger project

If this pack is a subfolder of another workspace, discovery may not activate its root instructions for every task. Either open the pack folder directly or explicitly tell the agent to read this pack's AGENTS.md and SKILL.md. Do not overwrite an existing repository's instructions without reviewing and merging relevant content.

For global skill installation, use a self-contained copy of the whole pack and adapt loader paths, or create a local wrapper pointing to the installed pack. Never copy only one of the shipped loaders and assume its relative links still resolve. Global installation of skills/plugins/MCP remains a user action.

## Python 3.14.x+

The helper uses only Python's standard library. No pip install is required. It performs local filesystem operations and URL parsing; it makes no network requests.

After approving local helper execution, run from the pack root:

~~~powershell
python --version
python .\scripts\packctl.py --help
python .\scripts\packctl.py verify
python -m unittest discover -s tests -v
python .\scripts\packctl.py init-case --slug training-case
python .\scripts\packctl.py classify-url --scope .\examples\scope-lab.json --url https://api.example.test/profile
~~~

For optional third-party Python tooling, use a local environment. The user's standing permission covers pip libraries; the displayed commands still need to fit the current execution agreement:

~~~powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --only-binary=:all: PACKAGE_NAME
~~~

PACKAGE_NAME is an intentional user-selected dependency, not a command to paste unchanged. Prefer the exact interpreter path over virtual-environment activation. This avoids changing PowerShell's execution policy.

If Python 3.14 lacks a compatible wheel, explain the incompatibility. Do not silently downgrade Python or install build tools system-wide. Source builds may execute package build hooks; review them and request approval when they exceed the agreed installation allowance.

## Optional tools and integrations

Start with the browser and filesystem capabilities already available. If a proxy, browser connector, code-search service, or documentation MCP would materially help, describe the task it enables, where data travels, installation scope, credentials needed, and a fallback. Let the user install or add it.

Portable files belong in tools or vendor under this workspace, with a provenance record. A Windows installer, driver, background service, elevated executable, or persistent environment change is not classified as portable merely because its download is small.

No live scanner, exploit framework, background service, platform credential, auto-submitter, or privileged installer is bundled.

