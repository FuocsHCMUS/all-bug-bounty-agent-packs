---
name: bug-bounty-agent-pack-1
description: Use when conducting scoped bug bounty research, evaluating CVE applicability, learning from public security writeups, preparing vulnerability evidence or reports, or teaching the underlying security concepts.
---

# Bug bounty research and learning

Read [AGENTS.md](AGENTS.md) and identify public-research, local-lab, or live-validation mode. Load [the master prompt](prompts/00-master-agent.md) for an end-to-end engagement. The pack is instruction-only unless the user separately approves execution.

## Workflow

1. Establish the question, current program brief, asset and technique scope, accounts, and existing approvals.
2. Record sources and observations. Separate facts, claims, inferences, and unknowns.
3. Form a hypothesis around an explicit security invariant. Identify prerequisites, a negative control, an alternative explanation, and the smallest useful experiment.
4. Research applicability before selecting tools. Prepare a concrete execution request only if needed.
5. Review results against controls; preserve reproducible evidence and uncertainty.
6. Produce a draft report, remediation reasoning, a bounded posture assessment, and beginner-oriented learning notes.
7. Update case state and the next action.

## Load by task

| Task | Reference |
|---|---|
| Select and organize programs | [Research workflow](references/01-research-workflow.md) |
| Generate novel hypotheses and analyze chains | [Creative research](references/02-creative-research.md) |
| Match versions, configurations, fixes, and CVEs | [CVE research](references/03-cve-research.md) |
| Extract transferable lessons from writeups and CTFs | [Writeup learning](references/04-writeup-learning.md) |
| Choose surface-specific questions | [Testing playbook](references/05-testing-playbook.md) |
| Design controls and judge evidence | [Validation and evidence](references/06-validation-evidence.md) |
| Draft severity, reports, and remediation | [Reporting](references/07-reporting-remediation.md) |
| Analyze strengths, risks, and SOC visibility | [Posture and SOC](references/08-posture-soc.md) |
| Explain networking and security prerequisites | [Foundations](references/09-foundations.md) |
| Build lessons and exercises | [Learning system](references/10-learning-system.md) |
| Handle tools, Windows, dependencies, and approvals | [Tools and approvals](references/11-tools-approvals.md) |
| Resume work and hand off | [State and handoff](references/12-state-handoff.md) |

Use [templates](templates/README.md) for records and [task prompts](prompts/01-task-library.md) for focused sessions. Consult [official sources](SOURCES.md) before time-sensitive claims.

## Evidence discipline

A banner is a lead. A relevant advisory supports applicability only after prerequisites match. A lab reproduction establishes lab behavior; a target reproduction establishes only the observed target behavior. Use [the evidence states](references/06-validation-evidence.md) and include control results.

For example, account A reading B's object is not enough to establish broken access control if B delegated access to A. Establish expected policy, remove the confounder in an approved lab, and compare the same harmless object under independent accounts.

## Common mistakes

- Treating a public program listing or downloaded PoC as execution permission.
- Confusing CVE relevance with target exploitability.
- Calling ordinary reflection XSS or a response difference an authorization bypass.
- Inferring enterprise-wide maturity from one endpoint.
- Installing just a loader while omitting its linked pack.

