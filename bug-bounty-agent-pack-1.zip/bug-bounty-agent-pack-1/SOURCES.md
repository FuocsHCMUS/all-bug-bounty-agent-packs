# Sources and maintenance

Documentation review date: **2026-11-03, Asia/Saigon**. Links are starting points, not a frozen substitute for current program policy. This pack's research methods and examples are original synthesis; it does not reproduce entire source manuals.

## Client integration sources

| Topic | Primary source | Review note |
|---|---|---|
| Codex project instructions | [AGENTS.md guide](https://learn.chatgpt.com/docs/agent-configuration/agents-md) | Opened official guide through the developers.openai.com redirect |
| Codex skills | [Build skills](https://learn.chatgpt.com/docs/build-skills) | Opened official guide |
| Claude Code instructions | [Memory and AGENTS.md](https://code.claude.com/docs/en/memory) | Opened; consulted native support and precedence |
| Claude Code skills | [Skills](https://code.claude.com/docs/en/skills) | Opened |
| OpenCode instructions | [Rules](https://opencode.ai/docs/rules/) | Opened |
| OpenCode skills | [Agent skills](https://opencode.ai/docs/skills/) | Opened |
| Cline instructions | [Rules](https://docs.cline.bot/customization/cline-rules) | Opened |
| Cline skills | [Skills](https://docs.cline.bot/customization/skills) | Opened; workspace path checked |
| Cursor instructions | [Rules](https://cursor.com/docs/rules) | Opened; AGENTS.md and MDC formats checked |
| Antigravity instructions | [Rules](https://antigravity.google/docs/rules/) | Opened; trigger syntax and discovery checked |
| Antigravity skills | [Agent skills](https://antigravity.google/docs/skills/) | Opened |

The Claude Code AGENTS.md question was also cross-checked through Context7's indexed official Claude Code documentation. Current official pages take precedence over stale community summaries.

## Program and research references

| Topic | Primary source | Use |
|---|---|---|
| HackerOne scope | [Scope best practices](https://docs.hackerone.com/en/articles/8495670-scope-best-practices) | Read original program scope and exclusions |
| HackerOne asset definitions | [Defining scope](https://docs.hackerone.com/en/articles/8494552-defining-scope) | Scope, report eligibility, and reward distinctions |
| Bugcrowd discovery | [Finding a program](https://docs.bugcrowd.com/researchers/participating-in-program/finding-program/) | Program discovery and access requirements |
| Bugcrowd briefs | [Reviewing bounty briefs](https://docs.bugcrowd.com/researchers/participating-in-program/reviewing-bounty-briefs/) | Program-specific targets and expectations |
| Web testing methodology | [OWASP WSTG](https://owasp.org/projects/web-security-testing-guide) | Select relevant tests; version references deliberately |
| API security | [OWASP API Security](https://api-security.owasp.org/) | Object, function, and property-level security concepts |
| Practice and research | [PortSwigger Web Security Academy](https://portswigger.net/web-security) | Owned training exercises and mechanism learning |
| Public CVE records | [CVEProject official list repository](https://github.com/CVEProject/cvelistV5) | Cross-check records and published metadata |
| Known exploitation | [CISA KEV data repository](https://github.com/cisagov/kev-data) | Cross-check catalog information, not target applicability |
| Severity | [FIRST CVSS v4 specification](https://www.first.org/cvss/v4.0/specification-document) | Use only the scoring version requested by the program |
| Python runtime | [Python 3.14 documentation](https://docs.python.org/3.14/whatsnew/3.14.html) | Interpreter and dependency compatibility context |

## Fetch limitations

The CVE website rendered a JavaScript-only page in the research tool. NVD pages returned no readable body, and the CISA catalog page returned a blocked response. The official CVE and CISA repositories above were opened as alternative starting points. These access limitations are not evidence that any vulnerability record or catalog entry is absent.

A few initial guessed program-documentation paths failed; the table uses discovered official pages that could be opened. No live program scope snapshot is bundled, because no company or engagement was selected.

## Refresh procedure

Before relying on a client feature after an upgrade, reopen its official documentation and verify local discovery with a loading receipt. Before a live-test session, refresh the actual program page and record policy changes.

For an advisory, record publication, modification, and retrieval dates. Prefer vendor-specific affected-version and patch information over generic index summaries. Preserve uncertainty when sources conflict.

Keep a case-local source ledger recording the exact claim a source supports. This source index is not evidence that every future candidate was verified.

