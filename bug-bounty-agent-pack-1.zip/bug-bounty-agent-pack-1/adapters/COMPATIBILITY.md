# Client compatibility

Documentation checked on 2026-11-03. These are documented integration paths, not a claim that six applications were installed and tested here. Confirm behavior in the installed version and repeat the loading receipt after upgrades.

## Claude Code

Native AGENTS.md support is documented from v2.1.277. Default discovery uses AGENTS.md when no project or ancestor CLAUDE.md/CLAUDE.local.md takes precedence; settings and session type can alter this. Check /memory. The supplied legacy import is optional. Claude-native skills use .claude/skills. [Official memory documentation](https://code.claude.com/docs/en/memory), [skills](https://code.claude.com/docs/en/skills).

## Codex

AGENTS.md supplies project guidance. Native repository skills use .agents/skills. The included loader points to the complete pack; keep both together. Guidance inheritance and size limits belong to Codex, so load large references on demand. [Official instructions](https://learn.chatgpt.com/docs/agent-configuration/agents-md), [skills](https://learn.chatgpt.com/docs/build-skills).

## OpenCode

OpenCode reads AGENTS.md and discovers skills in several supported directories, including .agents/skills. No opencode.json override is needed for this pack. The pack deliberately does not change shell permissions or enable plugins. [Official rules](https://opencode.ai/docs/rules/), [skills](https://opencode.ai/docs/skills/).

## Cline

Current documentation lists AGENTS.md and workspace rule directories. Cline's workspace skill path is .cline/skills. Included native rules and the skill loader provide a discoverable entry point; check the Rules/Skills panel and toggle if needed. [Official rules](https://docs.cline.bot/customization/cline-rules), [skills](https://docs.cline.bot/customization/skills).

## Cursor

Current documentation supports root and nested AGENTS.md. Project rules use .cursor/rules/*.mdc with YAML frontmatter. The included alwaysApply rule directs reading of pack instructions; verify the agent actually opens them. [Official rules](https://cursor.com/docs/rules).

## Antigravity

Current documentation supports AGENTS.md and .agents/rules/*.md. Modular rule files need recognized YAML trigger metadata. The shipped rule uses always_on; skills use .agents/skills. Open the pack itself because discovery across workspace and descendant folders can differ from other clients and older documentation. [Official rules](https://antigravity.google/docs/rules/), [skills](https://antigravity.google/docs/skills/).

## Universal fallback

Tell the agent: "Read the AGENTS.md and SKILL.md at this pack's root, then read prompts/00-master-agent.md. Report actual loaded paths and current execution approvals."

A loading receipt is a retrieval check. It does not override a client's policy, sandbox, permissions, organizational instructions, or model capabilities.

