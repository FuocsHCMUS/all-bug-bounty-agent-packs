@AGENTS.md

This file is an optional legacy bridge. Copy it to the pack root and rename it CLAUDE.md only for a session that needs the bridge. Keep the canonical content in AGENTS.md.

