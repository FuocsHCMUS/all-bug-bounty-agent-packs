# Pack build plan and design

Date: 2026-11-03. This is a new document and skill package, built under the user's instruction to create it in a separate folder. No existing repository files were present. No global installation or live-company testing is part of this build.

## Deliverables

- Canonical AGENTS.md and a short SKILL.md with progressive reference loading.
- English master/task/role prompts and twelve substantive reference modules.
- Six client adapters, with current official documentation and explicit discovery limitations.
- Case templates for scope, hypotheses, CVEs, writeups, tests, evidence, reporting, posture, learning, approvals, provenance, and handoff.
- A fictional worked example and reserved-domain scope fixture.
- A standard-library offline helper: case initialization, URL classification, hashing, and integrity checks.
- Meaningful offline tests and independent behavioral application scenarios.

## Validation

Verify internal Markdown links, JSON, frontmatter, Python syntax, utility behavior, no case-directory overwrite, exclusion precedence, domain boundaries, exact URL matching, unsupported rules, and hash paths. Evaluate how an independent reader applies the guidance to ambiguous evidence and execution permissions.

Native client runtime behavior will be documented from official sources and clearly distinguished from local testing. Template fields are intentional fill-in forms, not unfinished implementation.

## Completion record

See evaluation/QA-REPORT.md for actual checks and their limitations.

