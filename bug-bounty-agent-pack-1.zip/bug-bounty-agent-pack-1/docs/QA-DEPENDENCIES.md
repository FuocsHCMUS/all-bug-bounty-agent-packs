# Build-time QA dependencies

The pack's offline helper requires no third-party libraries.

For the external skill-creator metadata validator, this build used PyYAML 6.0.3 from the configured pip package index. Pip selected the cp314 Windows x86-64 wheel and installed it with --target tools/qa-python-libs.

This workspace-local dependency was used to validate YAML metadata and was not installed into the system interpreter's site-packages. It is excluded by the pack's tools ignore rule.

Reproduction, if the user approves local QA execution:

~~~powershell
python -m pip install --target .\tools\qa-python-libs --only-binary=:all: PyYAML==6.0.3
$env:PYTHONPATH = (Resolve-Path .\tools\qa-python-libs).Path
python C:\Users\Admin\.codex\skills\.system\skill-creator\scripts\quick_validate.py .
~~~

The validator path above is specific to the build machine. Other installations should locate their own skill-creator validator. Setting PYTHONPATH in this shell is temporary and does not change the machine-wide environment.

