# Worked example: authorization, delegation, and revocation

**Entirely fictional.** All requests, responses, times, identities, and logs below are teaching fixtures. They are not results from a company, a running lab, or a live service. The .test names must not be treated as real targets.

## The product

Training Reports lets an owner create a private report and delegate read access to a collaborator. Its fictional documented rule says: "After a delegation is revoked, access through permission-checked report routes ends immediately. Public sharing is disabled in this exercise."

Actors:
- Alice: owner of Report-41 in Tenant-Blue.
- Ben: separate researcher-controlled account.
- Chen: a researcher-controlled non-member.
- Report-41 contains only the synthetic marker training-note-41.

The invariant is: an actor may read Report-41 only if that actor is Alice or holds a current read grant.

## Begin with the concepts

An HTTP request asks the server to perform an operation. A session tells the server which account is acting. The report identifier tells it which object is requested. Authorization decides whether that account may perform that operation on that object.

A predictable identifier does not cause the flaw by itself. The key question is whether the server checks the actor's current authority.

Delegation complicates the test: Ben can legitimately read Alice's report when Alice granted access. A successful read under delegation proves the feature worked, not a bypass.

## Fixture observations

| Fixture ID | Actor and state | Route | Result supplied by the exercise |
|---|---|---|---|
| FX-1 | Alice owns report | GET /reports/41 | Synthetic marker returned |
| FX-2 | Ben has active read delegation | GET /reports/41 | Synthetic marker returned |
| FX-3 | Chen has no grant | GET /reports/41 | Denied, marker absent |
| FX-4 | Alice revokes Ben; no other grant exists | POST /reports/41/revoke | Grant now inactive |
| FX-5 | Ben after verified revocation | GET /reports/41 | Denied, marker absent |
| FX-6 | Ben after verified revocation | GET /exports/report-41 | Synthetic marker returned |
| FX-7 | Chen, never granted access | GET /exports/report-41 | Denied, marker absent |

These are supplied fixture facts. No script has generated them.

## First decision: before revocation

Claim: Ben reading Alice's report is an authorization vulnerability.

Decision: REJECTED for FX-2 under the known active grant. The observation is expected. Do not assign severity.

Learning: effective permission can derive from a relationship rather than ownership. A two-account test must record that relationship.

## Second hypothesis: inconsistent revocation

HYP-002: the export path continues to accept a previously authorized account after its only grant is revoked.

Prerequisites:
- Immediate revocation is the promised behavior.
- Report and export share the same private-access semantics.
- Ben has no remaining direct, inherited, public, or delegated grant.
- The report marker is synthetic and the accounts belong to the researcher.
- The capture context is consistent and not an old response.

The fixture explicitly supplies these conditions. In real research each needs evidence.

Experiment design:
1. Baseline: Alice can read the report.
2. Positive feature control: Ben can read while delegated.
3. Negative control: Chen is denied.
4. State change: verify Ben's only grant is removed.
5. Compare Ben's ordinary report route and export route.
6. Compare Chen's export access.
7. Review cache and worker timing if results do not distinguish them.

## Fixture-based interpretation

FX-5 and FX-6 support a route-specific inconsistency in the exercise. FX-7 suggests that the export route may preserve a former grant rather than allow all users. The fixture does not reveal implementation, so that root-cause explanation remains an inference.

For this document, use the label **illustrated failure supported by supplied fixtures**. Do not label it LAB-REPRODUCED or TARGET-REPRODUCED, because no actual execution occurred.

A real case could reach those evidence states only after an authorized experiment with actual captures and controls.

## Draft report excerpt

**Title:** Removed collaborator retains access to a private report through its export route.

**Expected:** Ben loses permission to both private report routes after his only read grant is revoked.

**Actual in supplied fixtures:** ordinary report access is denied, but export access returns the synthetic private marker. A never-authorized account is denied on both routes.

**Demonstrated consequence in the exercise:** a former collaborator retains read access to one private report through one route.

**Not established:** all users, all reports, every tenant, credential disclosure, or account takeover.

**Severity:** unscored. The exercise does not provide actual deployment sensitivity or program requirements.

## Remediation reasoning

Apply a common effective-authorization decision at the actual export retrieval boundary. If exports are intentionally bearer capabilities, document and design their lifetime and revocation semantics explicitly rather than assuming they behave like permission-checked routes.

Do not fix only the UI by hiding the export button. Ben's existing route would still reach the server.

Regression cases:
- Owner access remains available.
- Active delegation permits expected access.
- Non-members are denied.
- Revoked users are denied on ordinary and export routes.
- Other valid grants continue to work.
- Caches and background jobs follow the selected policy.

## Observed posture in the exercise

Strengths: the ordinary route correctly denies a non-member and a revoked collaborator. The export route denies a never-authorized account.

Gap: one export-route revocation condition conflicts with the fictional policy.

Unknown: the implementation, other routes, other object types, internal logs, patching process, and organization-wide maturity.

## SOC lesson

Useful events would include grant creation/revocation, effective actor, report owner, route, authorization outcome, and request/job IDs.

A detection hypothesis compares successful private reads after revocation against all current grants. A public share or another valid grant is a false-positive explanation. Clock skew and documented propagation delay also matter.

Synthetic event table:

| Time UTC | Event | Actor | Grant state | Result |
|---|---|---|---|---|
| 10:00:00 | delegation_created | Alice → Ben | active | success |
| 10:01:00 | report_read | Ben | active | success |
| 10:02:00 | delegation_revoked | Alice → Ben | inactive | success |
| 10:03:00 | report_read | Ben | inactive | denied |
| 10:03:10 | export_read | Ben | inactive | success |

The last row is an investigation candidate under the fixture's policy. It does not by itself establish malicious intent.

## Self-check

1. Would changing report identifiers prove BOLA if Ben has delegation?
2. Why is FX-3 useful but insufficient to establish revocation behavior?
3. Why does FX-6 not prove the implementation used a stale grant cache?
4. What changes if the product explicitly promises export links remain usable for one hour?
5. Why should a local lesson avoid TARGET-REPRODUCED?

## Answers

1. No. Unauthorized effect, not identifier modification, is the property being tested.
2. It demonstrates non-member behavior, but Ben is a former collaborator with a different history.
3. A worker, capability, cache, or another implementation could explain the same result. More evidence is needed.
4. The expected invariant changes. A result inside that promised lifetime may be intended behavior.
5. The label claims an actual target experiment. This document contains supplied fictional observations only.

## Next exercise

Create a paper state table with a second valid grant, a moved report, and a queued export job. Predict which accesses should succeed under an explicitly chosen policy. Explain which additional evidence would distinguish an intended capability from an authorization flaw.

