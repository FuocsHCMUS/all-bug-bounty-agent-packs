# Focused task prompts

Use these after the master prompt. Replace brace fields with actual case data. Requests for a plan do not grant execution approval. Each task should update the case's state and relevant records.

## 1. Public program discovery

Research public HackerOne and Bugcrowd programs suitable for a beginner. Read original program pages and record retrieval dates. Compare web/API scope clarity, account access, automation policy, available documentation, learning value, and unresolved restrictions. Produce a shortlist with evidence and one recommended first case. Do not test company assets.

## 2. Program intake

Read the saved brief at {{path}} and its source URL. Extract asset rules, exclusions, permitted techniques, automation limits, account requirements, report requirements, and ambiguous terms. Distinguish report eligibility from bounty eligibility and testing permission. Produce a scope register and questions only for ambiguities that change the next experiment.

## 3. Passive surface model

Using program-provided asset lists, public documentation, and already available artifacts, map identities, application surfaces, APIs, dependencies, trust boundaries, and data flows. Label inferred relationships. Do not resolve every IP or actively enumerate hosts just because they share branding. Produce a surface map and ranked questions.

## 4. CVE applicability

Evaluate {{CVE or advisory}} for {{candidate component}}. Prioritize vendor sources and patch evidence. Fill the CVE matrix with product, versions, backports, features, reachable path, privileges, mitigations, evidence, and contradictions. Return an applicability decision and minimum validation proposal, not an automatic exploit attempt.

## 5. Learn from a writeup

Analyze {{URL or local writeup}} using the writeup template. Explain prerequisites and the vulnerable invariant. Separate the author's evidence from your inference. Extract three transferable research questions, a disconfirming test, a local exercise, remediation, and SOC visibility. Cite original material; do not copy long passages.

## 6. Generate creative hypotheses

For {{owned lab or scoped feature}}, model role, tenant, object, action, lifecycle state, and execution context. Generate distinct invariant-based hypotheses. For each, state preconditions, evidence, smallest experiment, control, failure explanation, estimated effort, and expected information gain. Rank for learning and evidence quality; retain contradictory evidence.

## 7. Authorization review

Build an actor/object/action/tenant/state matrix for {{feature}}. Include delegation, public sharing, role changes, revocation, alternate endpoints, and asynchronous workers. Use only researcher-controlled accounts and records in the proposed experiment. Decide what would demonstrate unauthorized access rather than ordinary feature behavior.

## 8. Business logic review

Model {{workflow}} as states, transitions, and invariants. Identify conservation rules, idempotency assumptions, authority changes, and stale decisions. Propose small sequential tests first. Put concurrency experiments in a separate bounded execution request. Explain why a surprising result is or is not a security issue.

## 9. Source and patch variant review

Read {{owned or permitted source path}} and {{patch reference}}. Trace the relevant input to its decision and use site. Explain what invariant the patch restores. Find semantically similar paths and missing variants in that codebase. Produce code references, counterexamples, and local regression cases without claiming a remote target is affected.

## 10. Minimal validation plan

Turn hypothesis {{ID}} into an approval-ready experiment. Include exact command or manual browser actions, accounts, harmless marker, request bounds, negative controls, evidence outputs, stop conditions, and cleanup. Inspect any selected external code first. Reuse existing approvals only if all bounds match.

## 11. Evidence triage

Review {{evidence directory}} without sending network requests. Separate observed facts, confounders, unsupported claims, and missing controls. Assign an evidence state. Give the strongest defensible claim, a falsification attempt, and the next smallest evidence gap.

## 12. Report draft

Use finding {{ID}} to draft a program-ready report. Explain the violated invariant, attacker prerequisites, minimal reproduction, controls, demonstrated impact, fix, and regression tests. Align with the program's taxonomy. State limitations and keep unsupported chain impact separate. Prepare the report locally for my review.

## 13. Posture assessment

Using only case evidence, evaluate observed strengths, gaps, risks, and unknowns. Cover the domains in references/08-posture-soc.md. Include sample size, confidence, business consequence, and a next check. Do not produce an organization-wide security grade from limited visibility.

## 14. SOC and detection lesson

Explain what logs could distinguish legitimate use from the observed behavior. Propose event fields, correlation, a generic detection idea, likely false positives, and a local test dataset. Mark detection logic as a hypothesis until evaluated against actual telemetry. Do not claim an alert exists.

## 15. Teach from zero

Teach {{concept}} assuming no networking background. Start with the smallest prerequisite, use an analogy and its limits, then a concrete fictional example. Connect it to the case, explain the failure and fix, and finish with three questions plus separate answers and one owned-lab exercise.

## 16. Resume

Read the current case state, policy source and timestamp, decision log, hypothesis ledger, approval ledger, and latest evidence summary. State what remains valid and what must be refreshed. Continue the next independent action; do not repeat completed tests or expired approvals.

## 17. Tool capability request

Identify the smallest missing tool capability for {{task}}. First inspect existing capabilities. Compare a built-in option, a portable workspace-local option, and a user-installed integration where applicable. Recommend one with concrete provenance, Python/Windows compatibility, data access, install effects, and fallback. Do not install MCP/plugins/skills yourself.

## 18. End-of-session review

Summarize hypotheses evaluated, evidence states, confirmed observations, rejected ideas, effective controls, unanswered questions, lessons, time spent, and next actions. Update state so another session can resume without reconstructing the conversation. Clearly distinguish no finding from no work.

