# Research workflow

## 1. Program discovery

Start from public program directories, but read the actual program page before recommending work. A platform hosts many unrelated programs; permission for one does not transfer to another.

Build a shortlist using observable criteria: scope clarity, accessible test accounts, web/API documentation, beginner learning value, feature depth, permitted automation, available time, and unresolved conditions. Rewards can guide effort but do not establish likely payout.

For each candidate record the program URL, platform, public/private status, retrieved date, official scope location, practical access requirements, suitable research question, and uncertainty. If login is required, record the missing information and let the user handle account access.

Public reading includes program policies and technical documentation. DNS enumeration, port scanning, crawling target endpoints, account creation, and form submissions have different effects and belong in an explicit test plan rather than being hidden under "passive research."

## 2. Intake and scope interpretation

Save a local policy snapshot or structured summary with the original URL and timestamp. Capture:
- Asset identifiers and types, explicit exclusions, wildcard interpretation, paths and ports.
- Permitted and excluded vulnerability classes or techniques.
- Automation rules, request limits, identification headers, testing windows, and service-specific requirements.
- Account ownership, tenant restrictions, test data, callback requirements, and third-party boundaries.
- Report format, taxonomy, submission eligibility, bounty eligibility, disclosure terms, and program updates.

Mark unknown fields as unknown. A missing automation limit does not imply unlimited requests. An asset being eligible for a report does not automatically mean every testing technique is allowed.

Preserve the program's exact wildcard statement. The helper's wildcard convention is only a local comparison aid. Handle CIDR, mobile identifiers, source repositories, and path-specific rules manually when the helper cannot represent them.

## 3. Case model

Create one directory per program or bounded engagement. Keep program policy, research sources, asset inventory, hypotheses, evidence, reports, and lessons together. Use stable IDs and append decisions instead of silently rewriting history.

Map the system using actors, objects, actions, trust boundaries, stores, and asynchronous jobs. Label each relationship as documented, observed, or inferred. A diagram of guessed architecture is useful only when the guesses remain visible.

A first surface map might include browser, API gateway, identity provider, application service, object store, export worker, and notification service. Ask where identity and tenant context enter and whether they survive every hop.

## 4. Select hypotheses

Do not start with a scanner menu. Start with a business or security invariant and a reason it may fail.

Example: "A private export remains accessible only to its owner and currently authorized collaborators." This yields meaningful questions about download links, worker authorization, role revocation, tenant moves, and alternate routes.

Rank by evidence relevance, prerequisite feasibility, likely impact, information gain, time, and expected side effects. Use ordinal estimates rather than pretending the ranks are measured probabilities. Maintain a mix of quick falsification and deeper model-driven questions.

## 5. Separate design from execution

For each selected hypothesis, prepare the baseline, changed variable, negative control, expected results, evidence fields, and stop conditions. Determine whether existing execution approval covers the actual command and target.

Perform static/local preparation while execution approval is pending. Inspect scripts, make deterministic fixtures, write the report skeleton, and identify prerequisite documentation. Do not treat this preparation as permission to execute the live plan.

## 6. Interpret results

Compare semantics, not only status codes or byte lengths. Ask whether a response contains protected data, whether an operation persisted, whether a role changed, and whether the expected policy is known.

Record both successful controls and anomalies. Reject an attractive hypothesis if the behavior is intended. Keep inconclusive findings open with a specific missing observation and a next action.

When enough proof exists, stop expanding access. Evidence quality comes from controlling the experiment and preserving context, rather than collecting more sensitive data.

## 7. Deliver and learn

Create a report draft and a separate learning note. The draft serves a triager and engineer; the note serves the beginner. Link them through finding and evidence IDs.

If no vulnerability is established, deliver an honest result: tested hypothesis, scope of observations, effective controls, confounders, remaining uncertainty, and the next informative question.

## 8. Revisit and retest

Refresh policy before a new live-test session and after meaningful program changes. Do not assume a saved scope list remains current indefinitely.

For a fix verification, compare the original reproduction against expected denial or invariant restoration, then check semantically related paths and legitimate behavior. Record build/version and test conditions. A single failed reproduction can reflect a changed environment rather than a complete fix.

End each session with a state file concise enough to resume from, and retain the detailed ledgers as evidence.

