# Creative offensive research through testable models

Creativity becomes useful when it produces a better question or a discriminating experiment. Keep creative exploration broad in modeling and precise in execution. Use owned labs for unfamiliar mechanics before adapting a test to a real program.

## Start with invariants

An invariant is a rule that should remain true across operations:
- An actor can access a private object only through a valid, current authorization relation.
- A tenant's identity context survives API, queue, worker, cache, and storage transitions.
- A refunded purchase cannot create more reusable credit than the accepted refund policy permits.
- Revocation removes the authority that the product promises to revoke.
- Untrusted content remains data when it crosses a parser, renderer, or tool boundary.
- A signature covers the same meaning that the receiver later uses.

Write the intended rule before describing how it might break. If product behavior is undocumented, state an assumption and seek a control rather than inventing a policy.

## Use systematic dimensions

Generate variants across dimensions rather than random strings:

| Dimension | Research questions |
|---|---|
| Identity | Anonymous, user, collaborator, manager, service account, former member? |
| Object | Owned, shared, private, archived, moved, deleted, restored? |
| Operation | Read, create, update, export, attach, copy, invite, revoke? |
| Tenant | Same organization, different organization, transferred object? |
| State | Before approval, during processing, after revocation, after expiry? |
| Route | UI action, documented API, alternate API version, worker job? |
| Representation | Different valid encodings, media types, names, canonical forms? |
| Timing | Decision at request time, execution time, or cache retrieval time? |
| Authority | Direct grant, delegated grant, inherited grant, temporary grant? |

A full Cartesian product is usually wasteful. Choose pairs suggested by the architecture and observed failure mechanisms.

## Reason about boundaries

Trace data from entry to validation to use. Ask whether the component making the security decision sees the same identity, object, tenant, type, and normalized representation as the component performing the action.

A useful hypothesis is "the export worker receives an object identifier but not the authorization context." This is still a hypothesis. Worker implementation, route behavior, and controls must establish it.

Parser disagreements, caching decisions, and asynchronous jobs can produce sophisticated flaws, but the initial experiment should remain small. Reproduce protocol ambiguity or concurrency mechanics in an owned lab before considering a program-specific plan.

## Work backward from legitimate capabilities

List what a low-privilege actor can legitimately do. Consider which outputs feed later trusted decisions. An invitation, import, attachment, generated link, or integration configuration may cross a different boundary later.

Model the chain as:
actor capability → controlled value → security decision → resulting authority or data.

For each arrow, require an observed or documented transition. Do not replace missing arrows with "could probably lead to takeover."

## Composition and chain analysis

Two weaknesses form a chain only if the first supplies an actual prerequisite of the second. Track identity continuity, object continuity, token audience, tenant context, freshness, user interaction, and reachable endpoints.

Record demonstrated impact separately from hypothetical amplification. A limited disclosure of a non-secret identifier does not automatically provide a session, credential, or administrative capability.

Stop at the smallest sufficient proof in live work. Explore larger chains in a controlled model or lab when live expansion would introduce new scope or consequences.

## Patch and variant research

Read the original root cause and patch. Describe what changed semantically:
- Where authorization moved.
- Which representation is normalized.
- Which identity now accompanies a worker task.
- Which invariant became atomic.
- Which renderer or sink now uses structured data.

Find sibling code paths with the same decision pattern in owned or permitted source. Compare alternate endpoints, import/export features, legacy versions, or lifecycle operations. Seek a semantic variant rather than a one-character payload variation.

Patch commits are informative but not complete proof of the deployed fix. Version labels, backports, configuration, and deployment state still matter.

## Novelty and originality

Label an idea "novelty unverified." Search original advisories and related weakness classes before claiming originality. A new instance of a known vulnerability can still be valuable; it need not be a new exploit technique.

For a new technique proposal, document:
1. The architectural assumption being challenged.
2. The smallest synthetic model exhibiting the mechanism.
3. Preconditions and a counterexample where it does not work.
4. Evidence from the local model.
5. Relationship to known techniques.
6. Conditions required before any live adaptation.

## Research budget and stopping

For each hypothesis choose an effort cap and evidence threshold. Stop or pivot when prerequisites are absent, controls explain the anomaly, a policy excludes the technique, or new evidence makes another hypothesis more informative.

Keep a rejection ledger. "Denied correctly after delegated access was removed" teaches an authorization mechanism and prevents rediscovering the same false lead.

When stuck, change the model before increasing volume: ask a different invariant, compare a different state transition, consult an implementation source, or build a smaller lab.

