# Validation, falsification, and evidence

## Evidence states

| State | Meaning |
|---|---|
| LEAD | An observation or source suggests investigation |
| APPLICABILITY-SUPPORTED | Relevant prerequisites are supported; impact is not yet reproduced |
| LAB-REPRODUCED | The mechanism was reproduced in a controlled owned environment |
| TARGET-REPRODUCED | A permitted target experiment reproduced the stated security failure |
| READY-FOR-USER-REVIEW | Evidence, controls, scope, and report were reviewed; user submission remains separate |
| REJECTED | A specific tested claim is contradicted or explained by intended behavior |
| INCONCLUSIVE | Missing or mixed evidence prevents a defensible decision |

These are evidence descriptions, not an automatic ladder. Lab reproduction does not have to precede every target observation, and report readiness is not report acceptance.

## Hypothesis contract

Write:
- Claim and security invariant.
- Starting identity, privileges, tenant, and account state.
- Target object, operation, and data sensitivity.
- Prerequisites and supporting evidence.
- Baseline and expected behavior.
- One-variable experiment and intended observation.
- Negative control and alternative explanation.
- Scope and execution approval references.
- Effect limits, stop conditions, and cleanup.
- Decision rule for promoting, rejecting, or preserving the hypothesis.

A decision rule written before testing reduces the temptation to redefine success after an interesting response.

## Baseline, variant, and controls

The baseline shows normal operation under known conditions. The variant changes the variable being tested. A negative control shows how the system behaves when the suspected failure should not occur.

For authorization, controls can include owner access, a non-delegated account, a nonexistent object, a public object, and a revoked relation. Choose controls that distinguish actual confounders, rather than adding requests mechanically.

Keep session identity and object provenance explicit. Label browser profiles and avoid storing raw passwords or tokens in ordinary notes.

## Read semantics

HTTP 200 can carry a denial or an empty wrapper. HTTP 403 can accompany a state change that already happened. An error can echo the request body. A response-length difference can come from a timestamp.

Inspect the protected field, persisted effect, current ownership, and expected policy. When a follow-up read is needed, include it in the execution plan rather than silently expanding the test.

## Alternative explanations

Check at least the plausible alternatives:
- Intended public or delegated access.
- Shared test account, browser profile confusion, or stale authentication.
- Cached data, asynchronous propagation, eventual consistency, or timing noise.
- Validation echo rather than retrieved data.
- Feature flag, tenant-specific configuration, or administrative privilege.
- Redirect, proxy, or worker responding instead of the intended component.
- Changed program policy, application deployment, or invalid test setup.

No fixed count of repetitions can solve a missing control. Repeat only when repetition answers a defined reliability question.

## Evidence record

For every decisive observation save:
- Case, hypothesis, test, and evidence IDs.
- Timestamp with timezone and environment/build where available.
- Actor aliases, tenant aliases, object alias, and relevant authority relationships.
- Request method and route, sanitized relevant headers/body, and session alias.
- Response status and relevant fields; persisted state where applicable.
- Baseline/control relationships and expected versus actual behavior.
- Source path, capture method, redaction notes, and content hash.
- Interpretation, confidence, and limitations.

Hashes support integrity comparison. They do not prove authenticity, authorization, or that a claimed experiment occurred. Screenshots help explanation but rarely replace a reproducible request/state record.

## Minimal proof

Use researcher-owned accounts and synthetic markers. Prove the boundary failure with the smallest sufficient observation and stop. Do not collect unrelated user data, expand privilege, establish persistence, or perform destructive actions to increase apparent severity.

If unexpected sensitive data appears, stop that experiment, avoid further retrieval, record minimal context, and prepare the report for the user. Keep sensitive raw material separate from shareable summaries.

## False positives and false negatives

A false positive claims a flaw without the required security failure. A false negative misses a real failure under untested conditions. Avoid both by bounding conclusions.

"Not reproduced in this configuration" is stronger and more accurate than "secure." A successful control is evidence for one property in one context.

Document negative results with the tested conditions, reason, and next useful question. Negative evidence is valuable when it eliminates a plausible mechanism.

## Review before reporting

Read the evidence as a skeptical triager:
1. Is intended policy known?
2. Is the actor's authority established?
3. Does the observation demonstrate a forbidden effect?
4. Is a meaningful control present?
5. Can the procedure be reproduced without private assumptions?
6. Does the claimed impact follow directly?
7. Are scope, approval, and limitations recorded?
8. Are sensitive details redacted appropriately for the draft?

If a required element is missing, keep the appropriate evidence state and prepare the smallest follow-up. Never fill an evidence gap with a plausible narrative.

