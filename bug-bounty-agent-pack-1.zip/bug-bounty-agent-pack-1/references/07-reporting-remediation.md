# Reporting, severity, and remediation

## The report's job

A useful report lets a triager verify the claim and an engineer restore the failed invariant. It should not require them to reconstruct the research conversation.

Lead with the concrete failure and demonstrated consequence. Example: "A removed collaborator can retrieve a private synthetic report through the export endpoint after the documented revocation interval." This is more assessable than "critical access control vulnerability."

Use a draft while evidence or review is incomplete. Submission, communication, and publication are separate user actions.

## Structure

1. Title naming the behavior and affected surface.
2. Summary and violated security invariant.
3. Asset and program-policy reference.
4. Preconditions, account roles, object ownership, and environment.
5. Minimal numbered reproduction steps.
6. Expected and actual behavior.
7. Controls and linked evidence.
8. Demonstrated impact and explicit limitations.
9. Suggested CWE/taxonomy and severity rationale.
10. Remediation and regression tests.
11. Cleanup and current state where relevant.

Use the program's requested fields when they differ. One root cause can affect multiple endpoints; group or separate reports according to evidence and program guidance rather than creating duplicates for every route.

## Reproduction quality

Each step should have a clear action and observable result. Use stable aliases such as Owner-A, Removed-Collaborator-B, Tenant-1, and Synthetic-Report-1.

Include the exact relevant request/state transition without exposing reusable tokens or unrelated personal data. Explain how a triager can create their own equivalent data. Reference attachments by evidence ID.

Avoid a long reconnaissance diary. Keep dead ends in the case ledger and include them in the report only when they explain a limitation or control.

## Impact

Distinguish:
- **Observed:** the exact data or state affected in the experiment.
- **Supported scope:** which actors, objects, or routes the evidence establishes.
- **Plausible extension:** a hypothesis requiring further conditions.
- **Unknown:** untested behavior or unavailable deployment information.

Do not claim full account takeover, remote code execution, or organization-wide compromise from a lower-impact primitive without establishing the required transitions. Explain business consequence in concrete terms: unauthorized report access, changed approval state, or weakened isolation.

## Severity

Follow the program's taxonomy and requested scoring version. If using CVSS, record the full vector, version, assumptions, and justification per metric. Use the official calculator rather than inventing arithmetic.

Technical severity, exploit likelihood, asset sensitivity, business priority, bounty eligibility, and bounty amount are different judgments. A scanner's CVSS label does not transfer automatically to a target-specific finding.

If evidence does not establish a metric, state uncertainty and offer a defensible range or omit the score until clarified. Do not fabricate a numeric value to make the draft look complete.

For Bugcrowd taxonomy or other platform categories, consult current authoritative documentation. The program may have specific severity rules or exclusions.

## Root-cause remediation

Identify the correct enforcement point:
- Object authorization belongs where the operation obtains or modifies the object.
- Worker jobs need sufficient identity/tenant context or an explicit capability model.
- Revocation needs consistent enforcement across direct routes, generated links, caches, and workers.
- Untrusted values need structured APIs or context-correct interpretation controls at the actual sink.
- Business invariants may need atomic transactions, idempotency keys, or state-transition validation.

Avoid superficial fixes such as hiding a button, blocking one parameter spelling, removing a banner, or applying a WAF rule while the underlying invariant still fails.

Explain design tradeoffs. A signed URL can intentionally be a time-limited bearer capability; a product promising immediate revocation may need a different access model. The right fix depends on the intended semantics.

## Regression coverage

Specify behavioral tests:
- Authorized use still works.
- Unauthorized actors are denied.
- Alternate routes enforce the same policy.
- Role changes, tenant changes, expiry, deletion, and revocation behave correctly.
- Worker and cache paths preserve the invariant.
- Error responses do not leak protected fields or hide successful state changes.

Choose cases from the actual failure mechanism. Do not propose every conceivable test without relevance.

## Retest report

Record the deployed build if available, test date, original reproduction result, control result, related-path coverage, and remaining limitations. "Original request now denied" is one observation; "root cause fixed everywhere" requires broader evidence.

## User handoff

Provide a clean draft, evidence index, brief rationale, unresolved questions, and suggested next action. State which attachments contain sensitive material and which are shareable. Do not imply the report has been submitted or accepted.

