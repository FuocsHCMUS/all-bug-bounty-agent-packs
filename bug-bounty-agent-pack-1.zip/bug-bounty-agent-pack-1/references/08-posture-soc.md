# Observed security posture, SOC, and purple-team learning

A bug bounty case provides a sample of external behavior. Use it to make bounded observations, not to invent an enterprise audit.

## Observation categories

| Category | Required basis |
|---|---|
| Observed strength | A documented or tested control behaved as expected in the sampled conditions |
| Improvement opportunity | A concrete control gap or fragile design with a supported explanation |
| Risk lead | A plausible concern with unresolved prerequisites |
| Demonstrated risk | A reproduced security failure with supported impact |
| Unknown | Insufficient visibility to assess the property |

Keep risk, confidence, evidence state, and coverage separate. "High confidence, low impact, one endpoint" differs from "high impact hypothesis, low confidence." Do not compress both into one color.

## Domains to examine when evidence exists

- Identity: account lifecycle, MFA, recovery, session validity, revocation.
- Authorization: object/action checks, delegated access, role transitions.
- Tenant isolation: context propagation, cross-organization state, exports.
- Data protection: exposure boundaries, storage permissions, retention observations.
- Application design: server-side validation, parser boundaries, asynchronous operations.
- Configuration: feature exposure, intentional sharing, observable settings.
- Dependency management: component evidence, advisory applicability, patch/backport signals.
- Abuse controls: documented limits and observed handling under permitted tests.
- Logging and detection: telemetry actually supplied versus proposed telemetry.
- Incident readiness: observable response workflow and report handling.
- Secure development: supplied regression tests, code review evidence, design decisions.
- Operational resilience: only conditions directly observed without stress testing.

An external response cannot establish backup quality, internal monitoring coverage, employee behavior, or secure development maturity unless relevant evidence is provided.

## Observation card

Include the control domain, sampled assets/operations/roles, date, expected property, evidence IDs, strength or gap, confidence, alternative explanations, business relevance, coverage limits, and next verification.

Example: "The API denied a non-member's read of Synthetic-Report-1 in Tenant-1, including the direct download route. This supports object authorization for those routes; export-worker authorization is untested."

Do not convert "no alert seen" into "the company has no monitoring." You may not have access to the alert system.

## SOC: turn behavior into observable events

For each finding ask what a defender would need to reconstruct:
- Actor and effective identity.
- Tenant and object owner.
- Action, object type and alias, and route.
- Authorization decision and reason.
- Delegation/share relation and relevant grant/revocation event.
- Session alias, client context, and request/trace ID.
- Worker job identity and parent request.
- Timestamp with synchronized clocks and relevant delay.
- Resulting state or data-access event.

These are proposed fields, not a claim that the company logs them. Avoid logging raw credentials, entire tokens, or sensitive payloads just to improve detection.

## Detection hypothesis

Describe:
1. Expected legitimate behavior.
2. Suspicious deviation.
3. Required telemetry and joins.
4. Time window and identity/tenant matching.
5. Threshold or semantic condition.
6. False-positive cases.
7. A local synthetic validation dataset.
8. Known blind spots and response action.

For revocation behavior, a semantic condition can be more useful than a generic high request count: a successful protected-object access after revocation, beyond documented propagation delay, with no other current grant.

Illustrative pseudocode:

~~~
for each protected_access:
    grants = effective_grants(actor, object, access_time)
    if access_succeeded and grants.is_empty:
        create_investigation_candidate(
            actor, tenant, object_alias, request_id, policy_version
        )
~~~

This is not a production rule. The availability, semantics, clock quality, and completeness of grants must be validated. It may miss intentionally public bearer capabilities or incomplete grant sources.

## False positives and triage

Check expected public sharing, direct/inherited/delegated grants, service accounts, delayed revocation, stale audit joins, clock skew, and object transfers.

A triage note should distinguish suspicious event, confirmed policy violation, and confirmed incident. Correlate context before assigning intent. A researcher-owned test event can be useful to validate detection without simulating an entire intrusion.

## Purple-team exercise

Use a local synthetic dataset:
- A valid owner access.
- A valid delegated access.
- A revoked grant followed by denied access.
- A success during documented propagation delay.
- A success after the delay without any remaining grant.
- A public capability allowed by policy.

Predict which events should alert, run the approved local analysis, inspect false positives, and refine the rule. Link the exercise to the underlying authorization invariant.

## Prioritization for improvements

Tie recommendations to observed risk and operational value:
- Restore the failed invariant first.
- Add regression coverage for the demonstrated mechanism.
- Improve telemetry needed to distinguish future violations.
- Reduce design ambiguity and document expected semantics.
- Revisit adjacent paths where the same assumption may exist.

Do not recommend products or large architecture changes merely because the case found one bug. Explain evidence, benefit, cost, uncertainty, and what information could change the recommendation.

