# Networking and security from first principles

Teach this material in the order needed for the current case. Start with a simple model, make it technically precise, show a fictional example, and explain the model's limits.

## 1. Programs and processes

A program is stored instructions. A process is a running instance with memory, handles, identity, and permissions. A Python script is data until an interpreter executes it; then it can read files, start processes, and use the network according to its privileges.

This explains why downloading a repository differs from executing it. A virtual environment separates Python dependencies, but it is not an operating-system security sandbox.

Self-check: Can a package installation run code? Some installation and build mechanisms can, so provenance and build behavior matter.

## 2. Hosts, IP addresses, ports, and protocols

A host is a device or computing instance. An IP address identifies a network interface or destination in a routing context. A port helps transport protocols identify a service endpoint. A protocol defines how participants interpret messages.

One IP can serve many domains through shared hosting or a CDN. One domain can resolve to many IPs. Therefore, an in-scope hostname does not automatically authorize testing every service at its resolved address.

A port number is a convention, not proof of the actual service or software version. Explain the observed protocol rather than trusting labels.

## 3. DNS

DNS maps names to records. A and AAAA records identify addresses; CNAME records alias names. DNS evidence helps understand infrastructure but does not establish ownership or permission to test.

A wildcard scope pattern is a policy expression, not a DNS query. In this pack's local helper, *.example.test matches proper subdomains and excludes the apex example.test. A real program may define different semantics.

A domain merely containing the text example.test is not a subdomain. The label boundary matters: badexample.test and example.test.other.test do not belong to *.example.test.

## 4. TCP, UDP, and TLS

TCP provides an ordered byte stream between endpoints. UDP sends datagrams without TCP's ordering/retransmission model. Applications add their own behavior on top.

TLS protects a connection's confidentiality and integrity and authenticates a peer according to certificate validation. HTTPS is HTTP over a protected transport, although modern protocol stacks may implement transport differently.

TLS does not decide whether one application user may read another user's invoice. Encryption in transit and application authorization solve different problems.

## 5. URLs and origins

A URL can include scheme, hostname, port, path, query, and fragment. The fragment is normally interpreted by the client and is not sent as part of an HTTP request target.

An origin is scheme, host, and port. Two different subdomains are different origins even when operated by one company. Cookie site semantics use a different concept; same-site does not mean same-origin.

A redirect tells a client to navigate to another location. It does not transfer scope or permission. Inspect each destination independently before continuing a test.

## 6. HTTP requests and responses

A request includes a method, target, headers, and sometimes a body. A response includes a status, headers, and sometimes content. The method describes intended semantics, but the application implementation determines actual effects.

A 200 response is a transport/application status, not proof of authorized data access. A 403 response suggests denial, but a poorly designed operation may already have changed state. Compare the actual protected data and state.

A reverse proxy or gateway can respond before the application. The server header may describe that layer rather than the component you are investigating.

## 7. Browsers and APIs

A browser enforces origin-related rules and maintains cookies and client state. An API exposes operations to clients. A button in the UI is only one way to invoke a server operation.

A disabled button is a usability restriction unless the server independently checks permission. Conversely, an API route existing does not mean it lacks authorization.

A command-line client and browser have different security contexts. A response obtainable by a script is not automatically readable by arbitrary website JavaScript in a victim's browser.

## 8. Identity, authentication, sessions, and tokens

Identity answers "who is acting?" Authentication establishes confidence in that identity. A session preserves authenticated context across requests.

A cookie is a browser storage/transport mechanism. A token is a value representing a claim or capability in a protocol. Many are bearer tokens: possession can be sufficient to use them, so do not put real values into ordinary notes.

A JWT is a token format. Its structure does not guarantee secure verification or appropriate authorization. Signature validity, intended audience, issuer, expiry, and application policy are separate checks.

Use session aliases in evidence and keep browser profiles distinct so account confusion does not invalidate experiments.

## 9. Authorization, roles, and objects

Authorization answers whether this actor may perform this action on this resource under current conditions.

A role is one input to a decision. Object ownership, tenant, delegation, sharing, lifecycle state, and purpose may also matter. "Logged in" is not sufficient authority for every operation.

IDOR commonly describes insecure use of object references. BOLA emphasizes broken object-level authorization in APIs. Guessability alone is not the core flaw: a predictable identifier can be safe if authorization is correct.

Fictional example: Owner-A can read private Report-1. User-B cannot unless A granted access. If B has a valid grant, a successful read does not demonstrate BOLA.

## 10. Tenants, delegation, and revocation

A tenant groups an organization's or customer's resources. Tenant isolation requires every relevant operation to preserve the intended boundary.

Delegation grants another actor limited authority. Revocation removes authority according to the product's semantics. Grants may be direct, inherited, role-based, or capability-based.

A successful access after one grant was removed may still be legitimate if another grant remains. This is why controls must examine effective authority rather than one UI setting.

For asynchronous systems, record when revocation becomes effective. Do not label documented propagation delay a bypass without examining the policy and actual behavior.

## 11. Data flow, trust boundaries, sources, and sinks

A source introduces data. A sink uses it in a sensitive context. A trust boundary separates components or identities with different authority assumptions.

Input validation checks whether data meets expectations. Normalization produces a canonical representation. Output encoding makes data safe for a specific rendering context. These are different operations.

A value can be validated in one representation and later interpreted differently. To reason correctly, trace the entire path to the decision and use site.

## 12. Injection and parameterization

Injection happens when untrusted data influences the structure or meaning of an interpreted instruction.

A database query built from string concatenation can mix data and syntax. Parameter binding separates them. The same general idea applies to shell commands, templates, and other interpreters, but the correct API differs by context.

An error is evidence of unexpected behavior, not proof of arbitrary execution. Establish the mechanism and smallest relevant effect in a lab or permitted experiment.

## 13. Browser rendering and XSS

HTML, attributes, URLs, CSS, and JavaScript are different parsing contexts. A string safely encoded for one may be unsafe in another.

XSS requires attacker-influenced content to execute with unintended browser authority. Reflection of text does not by itself establish execution.

CSP can limit some execution paths, but does not replace correct rendering and data handling. Explain the actual context, control, and result.

## 14. State machines, transactions, and races

A state machine describes valid states and transitions. Business security often depends on rules across multiple operations, such as approve-before-export or revoke-before-next-read.

A race occurs when timing affects results. A security issue requires the timing to violate a relevant invariant. Ordinary asynchronous delay or repeated requests are not automatically exploitable.

Atomicity means a group of changes behaves as one unit for the property being enforced. Idempotency means repeating an operation has the intended stable effect. These are related but different.

## 15. Caches and asynchronous workers

A cache reuses earlier computation or responses. Its key must include the context needed to avoid serving one user's protected result to another.

A worker performs deferred tasks. It may execute after the original request's identity or permission changed. The design must define which authority applies at execution and download time.

A stale result can be a correctness issue, a documented tradeoff, or a security issue depending on what the product promises and what data or authority is affected.

## 16. Vulnerability, exposure, exploitability, and impact

A weakness is a deficient pattern or property. A vulnerability is a concrete security-relevant flaw. Exposure describes whether the relevant surface is accessible. Exploitability depends on prerequisites and attacker capability. Impact is the resulting security consequence.

A vulnerable package can be installed but unreachable. An exposed endpoint can be correctly authorized. A severe CVE can be irrelevant to a patched deployment.

Do not collapse these concepts into one scanner label.

## 17. Evidence and scientific reasoning

A hypothesis predicts an observation. A control tests whether another explanation accounts for it. Falsification deliberately seeks evidence against the hypothesis.

Fact: "User-B received marker training-note-41 from the report endpoint." Inference: "The endpoint omitted object authorization." The inference needs supporting context and alternative explanations.

Confidence depends on evidence quality and applicability. A hash supports file-integrity comparison but does not prove the file came from a real target.

## 18. Prevention, detection, response, and assurance

Prevention enforces the property. Detection identifies suspicious or violating behavior. Response investigates and contains consequences. Assurance evaluates whether controls work.

A log records an event. An alert is a detection output. An incident is an investigated security event meeting an organization's criteria. Their existence and severity are not interchangeable.

For one authorization failure, connect:
- Prevention: enforce effective object authority.
- Detection: correlate successful access with active grants.
- Response: examine affected objects, sessions, and grants.
- Assurance: regression tests cover ownership, delegation, and revocation.

## Teaching method

Never teach all eighteen sections before allowing a beginner to start. Select the prerequisite chain for the current result. For an object authorization case, the chain may be HTTP → sessions → identity → objects → authorization → delegation → controls → evidence → remediation → SOC.

