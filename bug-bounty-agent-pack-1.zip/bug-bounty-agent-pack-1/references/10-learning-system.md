# A learning system for a beginning cyber student

Learning should produce transferable reasoning, not only a finished report.

## The lesson contract

For every significant hypothesis, effective control, rejected finding, or confirmed issue, create a learning note with:
1. The practical question.
2. Prerequisite concepts in dependency order.
3. A plain-language mental model and its limits.
4. A precise technical explanation.
5. The case's actual evidence and uncertainty.
6. A worked comparison or small state table.
7. The root cause or reason the control succeeded.
8. Prevention, remediation, detection, and triage connections.
9. A misconception and a corrective example.
10. A short exercise with answers separated.
11. A next review date and one transfer question.

Definitions belong near their first use. Introduce acronyms in full before shortening them.

## Progressive explanation

Use three passes:
- Beginner: what happens and why anyone cares.
- Mechanism: actors, messages, state, decisions, and failure point.
- Professional: edge cases, competing models, deployment assumptions, detection, and fix tradeoffs.

The beginner pass should not be technically false. For example, avoid saying HTTPS makes a website secure. Explain that it protects the connection while application authorization remains separate.

Use analogies deliberately. A hotel key helps explain authorization, but a digital bearer token can be copied and transmitted in ways a physical key analogy hides.

## An eight-stage path

| Stage | Skill | Practice | Evidence of progress |
|---|---|---|---|
| 1 | Hosts, URLs, DNS, ports, HTTP | Annotate a fictional request/response | Explain each field and the origin |
| 2 | Sessions and identity | Compare separate owned browser sessions | Distinguish account and session |
| 3 | Authorization and tenancy | Build role/object/action matrices | Predict allowed and denied reads |
| 4 | Data flow and interpretation | Trace a small owned-code example | Identify source, transform, sink |
| 5 | State and business logic | Model an approval/export workflow | State invariants and controls |
| 6 | CVEs and research sources | Fill an applicability matrix | Explain unknown prerequisites |
| 7 | Evidence and reporting | Draft a fictional report | Reproduce the claim from the draft |
| 8 | SOC and remediation | Analyze synthetic events | Distinguish valid use from violation |

These are stages, not a fixed timetable. Advance when the learner can explain and transfer the idea, not when a certain number of days pass.

## Exercises that teach reasoning

Ask the learner to predict before revealing the result:
- Does a predictable report identifier imply IDOR?
- Can two subdomains be same-site but different-origin?
- Does a valid JWT prove access to this object?
- Does a CVE's affected version range prove a deployment is exploitable?
- Does a 403 guarantee no state change happened?
- Could access after revocation still be legitimate?

Have the learner justify the answer with the missing condition or control. This develops diagnostic questions instead of memorized yes/no rules.

## Learning from controls that work

For a successful denial, explain:
- Which decision blocked the action.
- What evidence supports that interpretation.
- Which alternate explanation remains.
- What neighboring path is still untested.
- What regression case preserves this behavior.

This makes negative results useful and builds respect for architecture rather than reward-driven guessing.

## Spaced review and transfer

Use a practical default: review after a few days, again after roughly a week, and again after several weeks, adjusted to performance. Record dates in the learner's local timezone.

During review, change the example rather than repeating the same answer. Transfer an object authorization principle from reports to attachments or worker jobs. Transfer a trust-boundary principle from SQL to templates while explaining the different APIs.

## Progress journal

Track concepts explained, exercises attempted, misconceptions corrected, evidence reviewed, and questions still unclear. Use confidence labels grounded in performance: introduced, practiced with help, explained independently, transferred to a new example.

Do not invent an objective proficiency score. A successful lab or report is one observation, not proof of professional competence across a domain.

## Connect offensive and defensive skills

For each mechanism ask:
- What would the attacker need?
- Which preventive control should stop it?
- What would an engineer change?
- What should a test assert?
- What telemetry could reveal it?
- What would an analyst investigate?
- Which uncertainty would remain?

This connects pentesting, application security, secure development, SOC, and incident response without pretending they are identical jobs.

## Explain uncertainty kindly and precisely

When the learner is wrong, identify the exact mistaken assumption and offer a counterexample. Avoid flooding them with advanced jargon. When evidence is incomplete, teach why "unknown" is a useful answer and how a well-chosen control reduces uncertainty.

