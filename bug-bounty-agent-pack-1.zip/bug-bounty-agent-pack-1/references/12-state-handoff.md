# Case state, memory, and handoff

## Case directory

The offline helper creates a local case with:
- case.json: identity and creation timestamp.
- state.md: current objective, mode, status, next action.
- policy.md and scope.json: source policy and local scope model.
- sources.csv, hypotheses.csv, cve-candidates.csv.
- approvals.csv and tools.csv.
- decisions.md and test-log.md.
- evidence/raw and evidence/sanitized.
- reports, learning, and notes.

Additional specialized records can be created from templates. The helper does not choose a program, mark policy verified, or grant execution permission.

## Stable identifiers

Use case-local IDs such as SRC-001, HYP-001, TEST-001, EVD-001, CVE-CAND-001, APR-001, TOOL-001, FIND-001, and LESSON-001.

Use actual CVE identifiers only when verified. A candidate row can use a case ID before the public identifier is known. Do not invent something that resembles a real CVE.

## Minimal state

Keep state.md short:
- Goal and current mode.
- Program/source/policy timestamp.
- Evidence states of active hypotheses.
- Current execution approvals and their limits.
- Important decisions and unresolved inputs.
- Current artifacts and latest evidence.
- Next concrete action.
- What must be refreshed before live work.

Do not copy full conversations or raw tool output into the state file. Link to detailed artifacts.

## Decisions

Append a decision when a conclusion changes. Include timestamp, question, evidence, chosen interpretation, alternatives considered, confidence, and consequence for the next action.

Do not silently rewrite a rejected hypothesis as if it had always been confirmed. Research history should make changes of mind intelligible.

## Evidence separation

Raw captures may contain secrets or sensitive details. Keep them local and separate from sanitized material. The pack's .gitignore excludes cases by default, but Git ignore is not encryption or access control.

Before any export, review actual contents and included filenames. Do not assume redaction succeeded because a script ran. A manifest or hash can itself reveal filenames and should be reviewed for sharing.

Do not upload raw case material to external AI tools, paste services, or collaboration platforms without the user's explicit instruction and appropriate handling.

## Resume algorithm

1. Read state, case metadata, and the latest decisions.
2. Read the policy summary and original source reference.
3. Check policy freshness and scope changes before live testing.
4. Read active hypotheses, their last tests, and evidence.
5. Read direct user execution approvals, limits, and validity.
6. Confirm local tools, interpreter, and dependencies still match the recorded environment.
7. State the next action and continue the independent work it permits.

Do not repeat completed tests just to reconstruct context. Repeat only when state changes, missing evidence, or a defined reliability question justifies it.

## Handoff packet

Include one bounded objective, case path, current mode, policy reference, allowed inputs, approval references, evidence summary, unanswered questions, owned output paths, and next action.

A receiving agent must read the original approval record rather than treating the sending agent's confidence as authority. Handoff does not enlarge permissions or convert a draft into a submitted report.

## Session end

Report what was established, what was rejected, what remains uncertain, what control worked, what the learner should remember, and the next useful step.

If external access or approval is missing, name the exact dependency and continue any independent local work. Do not describe an incomplete live experiment as a successful hunt.

