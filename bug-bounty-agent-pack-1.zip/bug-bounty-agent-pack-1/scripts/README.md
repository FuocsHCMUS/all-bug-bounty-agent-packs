# Offline helper

packctl.py uses Python's standard library and was designed for Windows 11 with Python 3.14.x+. No network calls, scanner invocation, subprocesses, downloads, or exploit execution are implemented.

Ask for script-execution approval under the pack's preferences unless an earlier bounded approval already covers these commands.

## Verify

~~~powershell
python .\scripts\packctl.py verify
python -m unittest discover -s tests -v
~~~

Checks cover local Markdown links, JSON syntax, this pack's simple frontmatter fields, skill naming, Python compilation, and required files. The helper's scalar frontmatter reader is not a general YAML validator. These checks do not prove research correctness or native-client loading.

## Create a case

~~~powershell
python .\scripts\packctl.py init-case --slug first-program
~~~

Creates records under cases/first-program. Existing cases are refused. Slugs are lowercase letters, digits, and hyphens with Windows reserved names rejected. A new case begins in public-research mode with empty scope and no execution approval.

No program is selected automatically. Fill policy, scope, ledgers, and state from actual inputs.

## Compare one URL

~~~powershell
python .\scripts\packctl.py classify-url --scope .\examples\scope-lab.json --url https://api.example.test/profile
~~~

The result is MATCH, EXCLUDED, NO-MATCH, or UNKNOWN. Every result states that it is not authorization. No DNS lookup or HTTP request occurs.

Supported local rule types:
- domain: an exact DNS host, or *.example.test matching proper subdomains.
- url: an exact HTTP(S) URL after scheme/host/default-port normalization. The query is significant; fragments are ignored on the candidate because they are client-side.

Exclusions take precedence. A wildcard excludes its apex. Domain rules compare hostnames only and do not decide path, port, technique, ownership, or permission. URL rules are exact, not path-prefix rules. A URL excluded at /private does not exclude /private/child under this schema.

Paths are deliberately not decoded or normalized; application semantics may differ. Credential URLs, ambiguous backslashes, whitespace, malformed ports, unsupported rules, and invalid models require manual review. CIDR, mobile identifiers, repository rules, and path-prefix scope are not implemented.

Do not replace manual program-policy review with this helper.

## Hash evidence

~~~powershell
python .\scripts\packctl.py hash-evidence --path .\cases\first-program\evidence\sanitized --output .\cases\first-program\evidence-manifest.json
~~~

Creates a new JSON manifest outside the hashed directory, or prints to stdout when --output is absent. Existing output files are refused. Paths are relative to the evidence directory and hashes are SHA-256.

Symlinks and Windows junctions in evidence are rejected. Do not modify evidence while hashing. This is a local integrity aid, not a forensic acquisition system or proof that a capture is authentic.

## Exit codes

- 0: command completed; URL classification may still be EXCLUDED or NO-MATCH.
- 1: pack verification found errors.
- 2: invalid input, unsupported classification, filesystem problem, or usage error.

Human review still determines policy scope, evidence meaning, and permissions.

