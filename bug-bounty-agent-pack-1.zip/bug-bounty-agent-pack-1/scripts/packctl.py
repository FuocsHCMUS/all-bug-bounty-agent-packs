"""Offline helpers for case records, URL comparison, and evidence integrity.

No network requests, subprocess execution, scanning, or exploit functionality.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import ipaddress
import json
from pathlib import Path
import re
import sys
from urllib.parse import unquote, urlsplit

PACK_ROOT = Path(__file__).resolve().parents[1]
CASE_TEMPLATE_MAP = {
    "program-brief.md": "policy.md",
    "scope.json": "scope.json",
    "session-state.md": "state.md",
    "sources.csv": "sources.csv",
    "hypotheses.csv": "hypotheses.csv",
    "cve-candidates.csv": "cve-candidates.csv",
    "approvals.csv": "approvals.csv",
    "tools.csv": "tools.csv",
    "evidence-index.csv": "evidence-index.csv",
}
IGNORED_PARTS = {
    "cases", "tools", "vendor", ".venv", ".git", "__pycache__",
}
REQUIRED_FILES = (
    "README.md", "AGENTS.md", "SKILL.md", "SETUP.md", "SOURCES.md",
    "prompts/00-master-agent.md", "templates/scope.json",
    "examples/worked-authorization-case.md", "evaluation/SCENARIOS.md",
    "evaluation/QA-REPORT.md", "scripts/README.md", "tests/test_packctl.py",
)
RESERVED_WINDOWS = {"con", "prn", "aux", "nul"}
RESERVED_WINDOWS.update(f"{prefix}{number}" for prefix in ("com", "lpt")
                        for number in range(1, 10))


def linked(path: Path) -> bool:
    """Reject symlinks and Windows junctions when handling case/evidence paths."""
    return path.is_symlink() or path.is_junction()


def hostname(value: str) -> str:
    if not isinstance(value, str) or not value or value != value.strip():
        raise ValueError("Host must be a non-empty string without outer whitespace")
    if any(c.isspace() or ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError("Host contains whitespace or control characters")
    if any(c in value for c in "/\\%@?#"):
        raise ValueError("Host contains URL syntax instead of a DNS name")
    value = value.removesuffix(".").lower()
    try:
        return ipaddress.ip_address(value).compressed
    except ValueError:
        pass
    try:
        result = value.encode("idna").decode("ascii").lower()
    except UnicodeError as exc:
        raise ValueError("Invalid internationalized hostname") from exc
    if len(result) > 253:
        raise ValueError("Hostname is too long")
    labels = result.split(".")
    if any(not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", item)
           for item in labels):
        raise ValueError("Invalid DNS label")
    return result


def normalized_url(value: str) -> tuple:
    if not isinstance(value, str) or not value:
        raise ValueError("URL must be a non-empty string")
    if any(c.isspace() or ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError("URL contains whitespace or control characters")
    if "\\" in value:
        raise ValueError("Backslash URLs are ambiguous")
    try:
        parsed = urlsplit(value)
        if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
            raise ValueError("Only absolute HTTP(S) URLs are supported")
        if parsed.username is not None or parsed.password is not None:
            raise ValueError("Credential-bearing URLs are not supported")
        if parsed.netloc.endswith(":"):
            raise ValueError("Empty port is not supported")
        host = hostname(parsed.hostname or "")
        port = parsed.port
    except (ValueError, UnicodeError) as exc:
        raise ValueError(f"Invalid URL: {exc}") from exc
    scheme = parsed.scheme.lower()
    if port is None:
        port = 443 if scheme == "https" else 80
    if not 1 <= port <= 65535:
        raise ValueError("Port must be between 1 and 65535")
    # Deliberately do not decode or normalize paths: server semantics can differ.
    return scheme, host, port, parsed.path or "/", parsed.query


def validated_scope(model: object) -> dict:
    if not isinstance(model, dict):
        raise ValueError("Scope model must be an object")
    if type(model.get("version")) is not int or model["version"] != 1:
        raise ValueError("Only scope model version 1 is supported")
    if set(model) - {"version", "include", "exclude", "notes"}:
        raise ValueError("Unsupported scope fields require manual review")
    if "notes" in model and not isinstance(model["notes"], str):
        raise ValueError("Scope notes must be a string")
    for group in ("include", "exclude"):
        if not isinstance(model.get(group), list):
            raise ValueError(f"{group} must be a list")
        for rule in model[group]:
            if not isinstance(rule, dict) or set(rule) != {"kind", "value"}:
                raise ValueError("Each scope rule must contain only kind and value")
            value = rule["value"]
            if not isinstance(value, str) or not value:
                raise ValueError("Scope rule values must be non-empty strings")
            if rule["kind"] == "domain":
                base = value[2:] if value.startswith("*.") else value
                normalized = hostname(base)
                try:
                    ipaddress.ip_address(normalized)
                except ValueError:
                    pass
                else:
                    raise ValueError("Use an exact URL rule for IP literals")
                if "*" in base:
                    raise ValueError("Only a leading *. wildcard is supported")
            elif rule["kind"] == "url":
                normalized_url(value)
                if urlsplit(value).fragment:
                    raise ValueError("URL rules cannot contain fragments")
            else:
                raise ValueError("Only domain and exact url rules are supported")
    return model


def load_scope(path: Path) -> dict:
    return validated_scope(json.loads(path.read_text(encoding="utf-8-sig")))


def rule_matches(rule: dict, target: tuple) -> bool:
    if rule["kind"] == "url":
        return normalized_url(rule["value"]) == target
    value = rule["value"]
    wildcard = value.startswith("*.")
    base = hostname(value[2:] if wildcard else value)
    host = target[1]
    return host.endswith("." + base) if wildcard else host == base


def classify_url(model: object, value: str) -> dict:
    result = {
        "url": value,
        "classification": "UNKNOWN",
        "not_authorization": True,
        "reason": "",
        "matched_rule": None,
    }
    try:
        validated_scope(model)
        target = normalized_url(value)
    except (ValueError, TypeError) as exc:
        result["reason"] = str(exc)
        return result
    for group, classification in (("exclude", "EXCLUDED"), ("include", "MATCH")):
        for rule in model[group]:
            if rule_matches(rule, target):
                result.update(
                    classification=classification,
                    matched_rule=rule,
                    reason=("Local rule comparison only; review policy, ownership, "
                            "path/port/technique bounds, redirects, and execution approval."),
                )
                return result
    result.update(classification="NO-MATCH",
                  reason="No local inclusion matched; this is not a policy decision.")
    return result


def init_case(pack_root: Path, slug: str) -> Path:
    if (not isinstance(slug, str)
            or not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?", slug)
            or slug in RESERVED_WINDOWS):
        raise ValueError("Use 1-64 lowercase letters/digits/hyphens; no Windows reserved name")
    root = pack_root.resolve(strict=True)
    cases = root / "cases"
    if linked(cases) or cases.resolve().parent != root:
        raise ValueError("Cases directory must be an ordinary child of the pack")
    case = cases / slug
    if case.exists() or linked(case):
        raise FileExistsError(f"Refusing to overwrite case: {case}")
    # Read every required template before creating a case.
    payloads = {
        destination: (root / "templates" / source).read_text(encoding="utf-8-sig")
        for source, destination in CASE_TEMPLATE_MAP.items()
    }
    created = datetime.now(timezone.utc).isoformat()
    payloads["state.md"] = payloads["state.md"].replace("{{value}}", "unknown")
    payloads["state.md"] += (
        f"\nCreated case: {slug}\nCreated at: {created}\n"
        "No program selected and no execution approval granted by this helper.\n"
    )
    cases.mkdir(exist_ok=True)
    case.mkdir()  # No exist_ok: also refuses an existing case on a later call.
    for directory in ("evidence/raw", "evidence/sanitized", "reports", "learning", "notes"):
        (case / directory).mkdir(parents=True, exist_ok=True)
    metadata = {
        "case_id": slug, "created_at": created, "mode": "public-research",
        "program_url": None, "policy_verified": False, "execution_approved": False,
    }
    payloads["case.json"] = json.dumps(metadata, indent=2) + "\n"
    payloads["decisions.md"] = "# Decisions\n\nNo research decisions recorded yet.\n"
    payloads["test-log.md"] = "# Test log\n\nNo tests executed.\n"
    for name, content in payloads.items():
        (case / name).write_text(content, encoding="utf-8")
    return case


def evidence_manifest(directory: Path) -> list[dict]:
    if linked(directory) or not directory.is_dir():
        raise ValueError("Evidence path must be an existing ordinary directory")
    root = directory.resolve(strict=True)
    records = []
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix()):
        if linked(path):
            raise ValueError(f"Refusing linked evidence entry: {path}")
        resolved = path.resolve(strict=True)
        if not resolved.is_relative_to(root):
            raise ValueError(f"Evidence entry escapes root: {path}")
        if not path.is_file():
            continue
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        records.append({
            "path": path.relative_to(root).as_posix(),
            "size_bytes": path.stat().st_size,
            "sha256": digest.hexdigest(),
        })
    return records


def frontmatter(text: str) -> dict:
    """Read the simple scalar frontmatter used by this pack; not a full YAML parser."""
    lines = text.splitlines()
    if not lines or lines[0] != "---":
        raise ValueError("Missing YAML frontmatter")
    try:
        end = lines.index("---", 1)
    except ValueError as exc:
        raise ValueError("Unterminated YAML frontmatter") from exc
    result = {}
    for line in lines[1:end]:
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        key, separator, value = line.partition(":")
        if not separator:
            raise ValueError("Unsupported frontmatter line")
        result[key.strip()] = value.strip().strip('"').strip("'")
    return result


def verify_pack(root: Path) -> list[str]:
    """Check readable text, JSON, used frontmatter, Python syntax, and local links."""
    root = root.resolve(strict=True)
    errors = []
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if any(part in IGNORED_PARTS for part in relative.parts):
            continue
        if linked(path):
            errors.append(f"{relative}: linked pack entry requires review")
            continue
        if not path.is_file() or path.suffix not in {".md", ".mdc", ".json", ".py", ".yaml", ".csv"}:
            continue
        try:
            content = path.read_text(encoding="utf-8-sig")
            if path.suffix == ".json":
                model = json.loads(content)
                if path.name in {"scope.json", "scope-lab.json"}:
                    validated_scope(model)
            if path.suffix == ".py":
                compile(content, str(path), "exec")
            if path.name == "SKILL.md":
                fields = frontmatter(content)
                name = fields.get("name", "")
                if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name) or len(name) > 64:
                    raise ValueError("Invalid skill name")
                if name != path.parent.name:
                    raise ValueError("Skill name must match its directory")
                if not fields.get("description") or len(fields["description"]) > 1024:
                    raise ValueError("Missing or oversized skill description")
            if path.suffix == ".mdc" and frontmatter(content).get("alwaysApply") != "true":
                raise ValueError("Cursor adapter must have alwaysApply: true")
            if relative.as_posix() == ".agents/rules/bug-bounty.md":
                if frontmatter(content).get("trigger") != "always_on":
                    raise ValueError("Antigravity adapter must use trigger: always_on")
            if path.suffix in {".md", ".mdc"}:
                for match in re.finditer(r"\[[^\]]*\]\(([^)]+)\)", content):
                    target = match.group(1).strip().strip("<>")
                    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", target) or target.startswith("#"):
                        continue
                    target = unquote(target.split("#", 1)[0])
                    if not target:
                        continue
                    destination = (path.parent / target).resolve()
                    if not destination.is_relative_to(root) or not destination.exists():
                        errors.append(f"{relative}: missing or escaping link: {target}")
        except (ValueError, OSError, SyntaxError, UnicodeError) as exc:
            errors.append(f"{relative}: {exc}")
    return errors


def print_json(value: object) -> None:
    print(json.dumps(value, indent=2, ensure_ascii=True))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("verify", help="Verify pack files locally")
    create = commands.add_parser("init-case", help="Create local case records without permissions")
    create.add_argument("--slug", required=True)
    classify = commands.add_parser("classify-url", help="Compare one URL with local rules; no network")
    classify.add_argument("--scope", type=Path, required=True)
    classify.add_argument("--url", required=True)
    hashes = commands.add_parser("hash-evidence", help="Hash local evidence without uploading")
    hashes.add_argument("--path", type=Path, required=True)
    hashes.add_argument("--output", type=Path,
                        help="New JSON file outside the evidence directory; never overwrite")
    args = parser.parse_args(argv)
    try:
        if args.command == "verify":
            errors = verify_pack(PACK_ROOT)
            errors.extend(f"Missing required file: {item}" for item in REQUIRED_FILES
                          if not (PACK_ROOT / item).is_file())
            print_json({"ok": not errors, "errors": errors,
                        "scope": "Offline structure checks; not six-client runtime testing"})
            return 1 if errors else 0
        if args.command == "init-case":
            print_json({"case_path": str(init_case(PACK_ROOT, args.slug)),
                        "execution_approved": False})
            return 0
        if args.command == "classify-url":
            result = classify_url(load_scope(args.scope), args.url)
            print_json(result)
            return 2 if result["classification"] == "UNKNOWN" else 0
        if args.command == "hash-evidence":
            if args.output and args.output.resolve().is_relative_to(args.path.resolve()):
                raise ValueError("Manifest output must be outside the evidence directory")
            records = evidence_manifest(args.path)
            payload = {
                "algorithm": "sha256", "generated_at": datetime.now(timezone.utc).isoformat(),
                "root": str(args.path.resolve()), "files": records,
                "note": "Integrity comparison only; not proof of authenticity or authorization",
            }
            if args.output:
                with args.output.open("x", encoding="utf-8") as stream:
                    stream.write(json.dumps(payload, indent=2) + "\n")
                print_json({"manifest_path": str(args.output.resolve()), "file_count": len(records)})
            else:
                print_json(payload)
            return 0
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print_json({"ok": False, "error": str(exc)})
        return 2
    return 2


if __name__ == "__main__":
    sys.exit(main())

