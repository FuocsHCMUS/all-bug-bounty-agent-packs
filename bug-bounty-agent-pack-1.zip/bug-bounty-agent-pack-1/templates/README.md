# Case templates

Fields in double braces are intentional fill-in fields. Replace them with observed values, or write unknown and explain why. Do not invent evidence to complete a form.

The offline helper creates a basic case and empty CSV ledgers. Copy these additional forms when the research needs them.

| Template | Purpose |
|---|---|
| [Program brief](program-brief.md) | Source policy, assets, techniques, and uncertainty |
| [Program shortlist](program-shortlist.md) | Compare public opportunities |
| [Scope model](scope.json) | Local URL classification input; never permission |
| [Hypothesis](hypothesis.md) | Invariant, prerequisites, control, and decision rule |
| [Test plan](test-plan.md) | Concrete reviewable execution |
| [Evidence](evidence-record.md) | Context, captures, redaction, and interpretation |
| [CVE matrix](cve-matrix.md) | Product and deployment applicability |
| [Writeup card](writeup-card.md) | Transfer a published mechanism |
| [Report](finding-report.md) | User-reviewable disclosure draft |
| [Posture](posture-assessment.md) | Strengths, risks, gaps, and unknowns |
| [Lesson](learning-note.md) | First-principles explanation and exercise |
| [SOC](soc-detection-note.md) | Telemetry, detection hypothesis, triage |
| [State](session-state.md) | Resume and handoff |
| [Approval ledger](approvals.csv) | Direct user approvals and limits |
| [Tool ledger](tools.csv) | Portable downloads and dependencies |
| [Source ledger](sources.csv) | Claim-specific provenance |
| [Hypothesis ledger](hypotheses.csv) | Evidence states and next decisions |
| [CVE ledger](cve-candidates.csv) | Candidate applicability status |
| [Evidence index](evidence-index.csv) | Capture inventory and relationships |

CSV files contain only header rows. Quote values that contain commas or newlines. Keep raw secrets out of ordinary ledgers.

