# Evidence {{EVD-ID}}

- Case/hypothesis/test IDs: {{value}}
- Capture timestamp and timezone: {{value}}
- Mode and actual source: {{value}}
- Environment/build: {{value}}
- Actor/session/tenant aliases: {{value}}
- Object owner and effective grants: {{value}}
- Request method/route/relevant fields: {{sanitized value}}
- Response status/relevant content: {{sanitized value}}
- Persisted effect: {{observed or untested}}
- Baseline/control relationship: {{value}}
- Expected versus actual behavior: {{value}}

## Preservation

- Raw path: {{value}}
- Sanitized path: {{value}}
- Capture method: {{value}}
- SHA-256 and file size: {{value}}
- Redactions and interpretation consequences: {{value}}
- Related request/trace IDs: {{value}}

## Interpretation

- Direct observation: {{value}}
- Inference: {{value}}
- Alternative explanation: {{value}}
- Confidence and limits: {{value}}
- Claim this evidence does not establish: {{value}}

