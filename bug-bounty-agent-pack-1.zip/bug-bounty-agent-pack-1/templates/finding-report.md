# Draft: {{concrete failure and affected feature}}

Status: {{evidence state}}. Prepared for user review; not submitted.

## Summary

{{Actor, forbidden action, affected object, and demonstrated consequence.}}

## Asset and prerequisites

- Program and current policy reference: {{value}}
- Affected asset/route/build: {{value}}
- Starting privileges and accounts: {{value}}
- Object ownership, grants, tenant, and state: {{value}}
- Necessary configuration or user interaction: {{value}}

## Reproduction

1. {{Exact action and observable result.}}
2. {{Exact action and observable result.}}
3. {{Exact action and observable result.}}

## Expected and actual behavior

- Expected invariant: {{value}}
- Actual effect: {{value}}
- Controls and their outcomes: {{value}}
- Evidence IDs and sanitized attachments: {{value}}

## Impact and severity

- Demonstrated impact: {{value}}
- Supported affected scope: {{value}}
- Untested amplification: {{value}}
- Limitations and alternate explanations: {{value}}
- Suggested classification: {{value}}
- Scoring version/vector/metric rationale if requested: {{value}}
- Business consequence: {{value}}

## Remediation and regression tests

- Root cause and enforcement point: {{value}}
- Proposed fix and tradeoffs: {{value}}
- Authorized-use control: {{value}}
- Unauthorized-use regression: {{value}}
- Alternate/lifecycle path coverage: {{value}}
- Retest prerequisites: {{value}}

## Evidence handling and handoff

- Sensitive material requiring review: {{value}}
- Cleanup and current test state: {{value}}
- Questions for user review: {{value}}

