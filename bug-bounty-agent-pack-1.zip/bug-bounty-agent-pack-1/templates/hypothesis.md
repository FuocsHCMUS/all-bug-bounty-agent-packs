# Hypothesis {{HYP-ID}}: {{specific claim}}

- Evidence state: {{state}}
- Mode and case: {{value}}
- Security invariant: {{rule}}
- Starting actor/role/tenant/authority: {{value}}
- Object/operation/lifecycle state: {{value}}
- Architectural reason to investigate: {{value}}

## Prerequisites

| Condition | Supported/contradicted/unknown | Evidence |
|---|---|---|
| {{condition}} | {{state}} | {{reference}} |

## Experiment design

- Baseline: {{action and expected result}}
- Changed variable: {{one distinction}}
- Negative control: {{what it distinguishes}}
- Alternative explanation: {{value}}
- Falsifying observation: {{value}}
- Minimum decisive evidence: {{value}}
- Proposed execution plan and approval: {{reference}}
- Effort and effect bounds: {{value}}

## Decision

- Actual observations and evidence IDs: {{value}}
- Interpretation and confidence: {{value}}
- Demonstrated impact: {{value}}
- Untested extension: {{value}}
- Decision rule outcome: {{value}}
- Next action and learning note: {{value}}

