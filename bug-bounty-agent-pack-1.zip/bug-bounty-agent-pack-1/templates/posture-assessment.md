# Observed security posture: {{case}}

Assessment date: {{value}}. Scope of visibility: {{assets, roles, routes, dates}}.

| Domain | Observation category | Evidence | Confidence | Coverage limits | Business consequence | Next verification |
|---|---|---|---|---|---|---|
| Identity | {{strength/gap/risk/unknown}} | {{IDs}} | {{value}} | {{sample}} | {{value}} | {{value}} |
| Authorization | {{category}} | {{IDs}} | {{value}} | {{sample}} | {{value}} | {{value}} |
| Tenant isolation | {{category}} | {{IDs}} | {{value}} | {{sample}} | {{value}} | {{value}} |
| Data handling | {{category}} | {{IDs}} | {{value}} | {{sample}} | {{value}} | {{value}} |
| Patching/configuration | {{category}} | {{IDs}} | {{value}} | {{sample}} | {{value}} | {{value}} |
| Monitoring/response | {{category}} | {{IDs}} | {{value}} | {{sample}} | {{value}} | {{value}} |

## Synthesis

- Strongest observed controls: {{value}}
- Demonstrated risks in priority order: {{value}}
- Improvement opportunities with evidence: {{value}}
- Unknown internal controls: {{value}}
- Contradictory evidence and alternatives: {{value}}
- Recommended next checks: {{value}}
- Claims this sample cannot support: {{value}}

