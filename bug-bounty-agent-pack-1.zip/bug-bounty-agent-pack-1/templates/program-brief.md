# Program intake: {{case ID}}

- Program/platform/source URL: {{value}}
- Original page retrieved at, with timezone: {{value}}
- Snapshot path and policy revision: {{value}}
- Public/private status and access requirements: {{value}}
- Research objective and permitted mode: {{value}}

## Asset rules

| Original identifier | Type | Inclusion/exclusion | Paths/ports | Evidence | Ambiguity |
|---|---|---|---|---|---|
| {{identifier}} | {{type}} | {{rule}} | {{bounds}} | {{source}} | {{unknowns}} |

## Technique and execution conditions

- Permitted techniques: {{value}}
- Excluded techniques: {{value}}
- Automation, rate, concurrency, testing window: {{value}}
- Identification headers or account conventions: {{value}}
- Owned test accounts, tenants, and synthetic data: {{value}}
- Callback and redirect destinations: {{value}}
- Third-party dependencies and boundaries: {{value}}
- Reporting and bounty eligibility: {{value}}
- Required taxonomy/severity/report fields: {{value}}
- Current execution approval IDs: {{value}}

## Decision

- Resolved facts: {{value}}
- Unknowns that change the next action: {{value}}
- Independent work possible now: {{value}}
- Required refresh before live testing: {{value}}

