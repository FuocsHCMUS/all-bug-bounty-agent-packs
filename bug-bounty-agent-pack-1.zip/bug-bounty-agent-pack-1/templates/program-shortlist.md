# Public program shortlist

Research date: {{date and timezone}}. No target testing is implied.

| Program and official URL | Platform | Scope clarity | Accounts | Web/API relevance | Automation terms | Learning value | Unknowns |
|---|---|---|---|---|---|---|---|
| {{program}} | {{platform}} | {{evidence}} | {{access}} | {{surface}} | {{policy}} | {{reason}} | {{gaps}} |

## Recommendation

- First candidate and evidence-based reason: {{value}}
- Suitable first research question: {{value}}
- Documents to save: {{value}}
- Inputs needed from the user: {{value}}
- Passive research that can proceed: {{value}}

