# Case state

- Case: {{value}}
- Last updated with timezone: {{value}}
- Objective: {{value}}
- Mode: public-research
- Program/policy source and retrieval date: unknown
- Scope/technique interpretation: unresolved until documented
- Execution approvals: none unless recorded from direct user authorization
- Active hypotheses and evidence states: {{value}}
- Latest evidence and artifacts: {{value}}
- Decisions and rejected explanations: {{value}}
- Learning notes and review dates: {{value}}
- Missing inputs: {{value}}
- Independent work possible now: {{value}}
- Refresh required before live work: policy, scope, accounts, approvals
- Next concrete action: {{value}}

