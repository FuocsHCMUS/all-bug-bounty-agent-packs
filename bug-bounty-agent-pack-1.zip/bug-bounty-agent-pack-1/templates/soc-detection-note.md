# Detection research note {{ID}}

- Related finding and security invariant: {{value}}
- Expected legitimate behavior: {{value}}
- Suspicious deviation: {{value}}
- Telemetry actually available: {{value}}
- Additional telemetry proposed: {{value}}

## Correlation model

- Actor/effective identity: {{value}}
- Tenant/object/grant relationships: {{value}}
- Request/job/trace linkage: {{value}}
- Timing, delay, clock assumptions: {{value}}
- Rule condition and rationale: {{value}}
- False positives: {{value}}
- Blind spots: {{value}}

## Validation

- Synthetic positive/negative examples: {{value}}
- Approved local analysis: {{value}}
- Actual outcome or untested: {{value}}
- Triage steps and evidence required: {{value}}
- Status: {{proposal/local-evaluated/production-validated}}

