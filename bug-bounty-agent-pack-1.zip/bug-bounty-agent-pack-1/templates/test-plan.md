# Execution plan {{TEST-ID}}

- Case/hypothesis/mode: {{value}}
- Purpose and security invariant: {{value}}
- Policy source, revision, retrieval date: {{value}}
- Exact asset/technique match: {{value}}
- Existing approval considered and whether it covers this action: {{value}}

## Concrete action

- Command or exact manual browser actions: {{value}}
- Working directory: {{value}}
- Interpreter/tool version/commit: {{value}}
- Inspected script path and hash: {{value}}
- Accounts, tenant, synthetic marker: {{value}}
- Input files: {{value}}
- Network destinations and redirects: {{value}}
- File/state effects: {{value}}
- Request/concurrency/retry/time limits: {{value}}
- Stop conditions: {{value}}
- Cleanup: {{value}}

## Controls and observations

| Step | Variable | Expected result | Evidence to capture |
|---|---|---|---|
| Baseline | {{value}} | {{value}} | {{value}} |
| Variant | {{value}} | {{value}} | {{value}} |
| Negative control | {{value}} | {{value}} | {{value}} |

## Approval request

Requested scope: {{one action or bounded reusable batch}}.
Direct user response and approval ID: {{pending until supplied}}.
Dependent execution remains pending until approved.

