# Writeup card {{SRC-ID}}

- Title/author/original URL: {{value}}
- Published/retrieved dates: {{value}}
- Original disclosure/advisory references: {{value}}
- Environment and available evidence: {{value}}
- Reliability and omissions for this claim: {{value}}

## Mechanics

- Legitimate feature: {{value}}
- Starting capabilities: {{value}}
- Security invariant: {{value}}
- Trust boundary and failed assumption: {{value}}
- Prerequisites: {{value}}
- Experiment and controls: {{value}}
- Demonstrated impact: {{value}}
- Author's claim versus independent inference: {{value}}

## Transfer

- General principle: {{value}}
- CTF/toy assumptions requiring replacement: {{value}}
- Comparable architectural questions: {{value}}
- Small owned-lab exercise: {{value}}
- Falsifying condition: {{value}}
- Remediation and regression test: {{value}}
- SOC question: {{value}}
- Novelty/applicability still unknown: {{value}}

