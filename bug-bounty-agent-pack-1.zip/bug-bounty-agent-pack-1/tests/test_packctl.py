"""Behavior tests for the offline helper. No target network requests."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

PACK = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACK / "scripts"))
try:
    import packctl
except ModuleNotFoundError as exc:
    if exc.name != "packctl":
        raise
    packctl = None


class DeliveryTests(unittest.TestCase):
    def test_offline_helper_exists(self):
        self.assertTrue((PACK / "scripts" / "packctl.py").is_file(),
                        "The offline helper has not been implemented")


@unittest.skipIf(packctl is None, "Helper not implemented yet")
class ScopeTests(unittest.TestCase):
    def setUp(self):
        self.scope = {
            "version": 1,
            "include": [
                {"kind": "domain", "value": "*.example.test"},
                {"kind": "url", "value": "https://example.test/training"},
            ],
            "exclude": [
                {"kind": "domain", "value": "blocked.example.test"},
                {"kind": "url", "value": "https://api.example.test/private"},
            ],
        }

    def status(self, url):
        result = packctl.classify_url(self.scope, url)
        self.assertTrue(result["not_authorization"])
        return result["classification"]

    def test_subdomain_matches(self):
        self.assertEqual(self.status("https://api.example.test/profile"), "MATCH")

    def test_apex_not_covered_by_wildcard(self):
        self.assertEqual(self.status("https://example.test/"), "NO-MATCH")

    def test_apex_exact_url_can_match(self):
        self.assertEqual(self.status("https://example.test/training"), "MATCH")

    def test_suffix_confusion_does_not_match(self):
        for url in ("https://badexample.test/", "https://example.test.other.test/"):
            with self.subTest(url=url):
                self.assertEqual(self.status(url), "NO-MATCH")

    def test_exclusion_wins(self):
        self.assertEqual(self.status("https://blocked.example.test/"), "EXCLUDED")
        self.assertEqual(self.status("https://api.example.test/private"), "EXCLUDED")

    def test_exact_rule_does_not_exclude_other_paths(self):
        self.assertEqual(self.status("https://api.example.test/private/child"), "MATCH")

    def test_query_is_part_of_exact_url(self):
        self.assertEqual(self.status("https://example.test/training?x=1"), "NO-MATCH")

    def test_case_default_port_and_fragment_normalization(self):
        self.assertEqual(self.status("HTTPS://EXAMPLE.TEST:443/training#lesson"), "MATCH")

    def test_malformed_and_credential_urls_are_unknown(self):
        for url in (
            "https://user:pass@api.example.test/",
            "https://@api.example.test/",
            "javascript:alert(1)",
            "https://api.example.test:99999/",
            "https://api.example.test\\@other.test/",
            " https://api.example.test/",
            "https://api.example.test/\n",
            "https://api.example.test:abc/",
            "https://api.example.test:/",
            "https:///missing-host",
            "https://api.example.test%2eother.test/",
        ):
            with self.subTest(url=url):
                self.assertEqual(self.status(url), "UNKNOWN")

    def test_unicode_domain_is_compared_as_idna(self):
        model = {"version": 1, "include": [{"kind": "domain", "value": "bücher.test"}],
                 "exclude": []}
        result = packctl.classify_url(model, "https://xn--bcher-kva.test/")
        self.assertEqual(result["classification"], "MATCH")

    def test_unrecognized_rule_makes_decision_unknown(self):
        self.scope["exclude"].append({"kind": "cidr", "value": "192.0.2.0/24"})
        self.assertEqual(self.status("https://api.example.test/"), "UNKNOWN")

    def test_invalid_model_types_are_unknown(self):
        for model in (None, [], {"version": True, "include": [], "exclude": []},
                      {"version": 1, "include": "*", "exclude": []}):
            with self.subTest(model=model):
                self.assertEqual(packctl.classify_url(model, "https://api.example.test/")
                                 ["classification"], "UNKNOWN")

    def test_non_exact_domain_wildcard_is_unknown(self):
        self.scope["include"][0]["value"] = "*example.test"
        self.assertEqual(self.status("https://api.example.test/"), "UNKNOWN")

    def test_rule_with_path_as_domain_is_unknown(self):
        self.scope["include"][0]["value"] = "example.test/path"
        self.assertEqual(self.status("https://api.example.test/"), "UNKNOWN")

    def test_redirect_has_no_inherited_match(self):
        self.assertEqual(self.status("https://api.example.test/redirect"), "MATCH")
        self.assertEqual(self.status("https://external.test/next"), "NO-MATCH")

    def test_empty_scope_has_no_matches(self):
        self.assertEqual(packctl.classify_url(
            {"version": 1, "include": [], "exclude": []},
            "https://api.example.test/")["classification"], "NO-MATCH")

    def test_exact_ip_url_requires_explicit_url_rule(self):
        model = {"version": 1, "include": [
            {"kind": "url", "value": "http://127.0.0.1:8080/lesson"}], "exclude": []}
        self.assertEqual(packctl.classify_url(model, "http://127.0.0.1:8080/lesson")
                         ["classification"], "MATCH")
        self.assertEqual(packctl.classify_url(model, "http://127.0.0.1:8081/lesson")
                         ["classification"], "NO-MATCH")


@unittest.skipIf(packctl is None, "Helper not implemented yet")
class FilesystemTests(unittest.TestCase):
    def test_init_case_copies_templates_with_no_permissions(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            template_root = root / "templates"
            template_root.mkdir()
            for name in packctl.CASE_TEMPLATE_MAP:
                (template_root / name).write_text("fixture\n", encoding="utf-8")
            case = packctl.init_case(root, "first-case")
            metadata = json.loads((case / "case.json").read_text(encoding="utf-8"))
            self.assertEqual(metadata["case_id"], "first-case")
            self.assertEqual(metadata["mode"], "public-research")
            self.assertFalse(metadata["execution_approved"])
            self.assertTrue((case / "evidence" / "raw").is_dir())
            self.assertTrue((case / "state.md").is_file())

    def test_init_case_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "cases" / "existing").mkdir(parents=True)
            sentinel = root / "cases" / "existing" / "keep.txt"
            sentinel.write_text("keep", encoding="utf-8")
            with self.assertRaises((ValueError, FileExistsError)):
                packctl.init_case(root, "existing")
            self.assertEqual(sentinel.read_text(encoding="utf-8"), "keep")

    def test_case_slug_prevents_traversal_and_windows_reserved_names(self):
        with tempfile.TemporaryDirectory() as temp:
            for slug in ("../escape", "..", "AUX", "con", "com1", "lpt9",
                         "two words", "trailing.", "a/b", "C:drive", ""):
                with self.subTest(slug=slug):
                    with self.assertRaises(ValueError):
                        packctl.init_case(Path(temp), slug)

    def test_hashes_known_bytes_and_relative_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "nested").mkdir()
            (root / "nested" / "capture.txt").write_bytes(b"abc")
            records = packctl.evidence_manifest(root)
            self.assertEqual(records, [{
                "path": "nested/capture.txt", "size_bytes": 3,
                "sha256": hashlib.sha256(b"abc").hexdigest()}])

    def test_hash_manifest_is_sorted_and_handles_empty_directory(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.assertEqual(packctl.evidence_manifest(root), [])
            (root / "z.txt").write_bytes(b"z")
            (root / "a.txt").write_bytes(b"a")
            self.assertEqual([r["path"] for r in packctl.evidence_manifest(root)],
                             ["a.txt", "z.txt"])

    def test_hashing_missing_path_fails(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                packctl.evidence_manifest(Path(temp) / "missing")

    def test_hashing_symlink_is_rejected_when_supported(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            target = root / "original.txt"
            target.write_bytes(b"abc")
            link = root / "link.txt"
            try:
                link.symlink_to(target)
            except OSError:
                self.skipTest("Creating symlinks is unavailable in this Windows session")
            with self.assertRaises(ValueError):
                packctl.evidence_manifest(root)

    def test_case_parent_symlink_is_rejected_when_supported(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "pack"
            outside = Path(temp) / "outside"
            root.mkdir()
            outside.mkdir()
            try:
                (root / "cases").symlink_to(outside, target_is_directory=True)
            except OSError:
                self.skipTest("Creating symlinks is unavailable in this Windows session")
            with self.assertRaises(ValueError):
                packctl.init_case(root, "escape-case")

    def test_verifier_detects_broken_internal_link(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "note.md").write_text("[missing](missing.md)\n", encoding="utf-8")
            errors = packctl.verify_pack(root)
            self.assertTrue(any("missing.md" in error for error in errors))

    def test_verifier_accepts_external_and_existing_links(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "a.md").write_text(
                "[external](https://example.test/x)\n[local](b.md#topic)\n",
                encoding="utf-8")
            (root / "b.md").write_text("# Topic\n", encoding="utf-8")
            self.assertEqual(packctl.verify_pack(root), [])


if __name__ == "__main__":
    unittest.main()

