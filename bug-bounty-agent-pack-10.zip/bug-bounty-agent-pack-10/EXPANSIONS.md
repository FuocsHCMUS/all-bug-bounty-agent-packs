# Expansions in Pack 16 (ideas added beyond merging 10–15)
1. **Creative Offensive Lab as a first-class doc (docs/04)** with 10 named, schedulable methods: assumption inversion, parser differentials, state-machine abuse, trust-boundary mapping, primitive chaining, second-order hunting, time/race, differential testing, feature-abuse-first, invent-then-kill.
2. **Hypothesis Ledger as a mandatory Phase 2** (not just a template) with kill criteria and chain-potential scoring.
3. **Primitives-over-bug-names framing** in AGENTS.md §6 — hunt identity confusion / state desync / authority leaks, then name the class later.
4. **Chain Canvas template** and chain scoring in workflows/06-chain-sprint.md.
5. **OAuth/OIDC/SSO/passkeys playbook** and a **chaining-at-scale playbook** (both absent as standalone files in 10–15).
6. **Invent-Then-Kill creative session workflow** (workflows/07) with a 10-hypothesis quota.
7. **Differential-testing matrix template** inside the hypothesis ledger.
8. Explicit statement of *why* the minimal program RoE stays (AGENTS.md §2) — framed as program enforcement, not as a creativity limit.
