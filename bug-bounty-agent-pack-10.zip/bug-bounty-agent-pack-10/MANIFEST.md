# Manifest — bug-bounty-agent-pack-16
Built 2026-11-03 by merging packs 10–15 (see MERGE-NOTES.md). 114 files, English.
Canonical: AGENTS.md (no CLAUDE.md). Platforms: Claude Code, Codex, OpenCode, Cline, Cursor (4 rules), Antigravity (rules + 6 workflows).
Scripts: 6 stdlib-only Python helpers, all compile + --help + offline functional tests passed (scope_guard in/out, inventory, headers/http dry-run, make_hunt scaffold).
All worked examples are fictional.
