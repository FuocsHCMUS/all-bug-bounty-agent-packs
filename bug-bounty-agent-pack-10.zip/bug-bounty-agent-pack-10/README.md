# bug-bounty-agent-pack-16 — Merged Super Agent Pack
The consolidation of packs 10–15 (uploaded by Joshua), keeping the best of each, removing duplicates,
and adding a dedicated creative-offensive core. English throughout. No CLAUDE.md — Claude Code reads AGENTS.md.

Start: `START_HERE.md` → `AGENTS.md` → copy the adapter for your tool from `platforms/` → run your first hunt with `workflows/01-new-program-to-first-report.md`.
What came from where: `MERGE-NOTES.md`. What is new/expanded in 16: `EXPANSIONS.md`.
