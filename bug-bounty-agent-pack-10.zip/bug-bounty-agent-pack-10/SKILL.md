---
name: bug-bounty
description: Authorized bug bounty hunting for HackerOne/Bugcrowd-style programs — threat-model-first hunting, CVE and writeup research, creative exploitation R&D, validation, reporting to the owner, and first-principles tutoring with a SOC lens.
---
# Bug Bounty Skill (Pack 16)
Canonical rules live in `AGENTS.md` at the pack root — read it first, in full, every new workspace.
Quick start: 1) Intake + scope_guard. 2) Threat model. 3) Hypothesis Ledger. 4) Research loop (CVE/writeups).
5) Test one hypothesis at a time (Tier B approval for target traffic). 6) Validate + try to disprove.
7) Report to Joshua only. 8) Posture analysis + learning notes. 9) Retest on fix.
Playbooks: `playbooks/`. Workflows: `workflows/`. Templates: `templates/`. Scripts: `scripts/` (stdlib-only, dry-run default).
Creative core: `docs/04-creative-offensive-lab.md` — assumption inversion, parser differentials, state-machine abuse, chaining.
