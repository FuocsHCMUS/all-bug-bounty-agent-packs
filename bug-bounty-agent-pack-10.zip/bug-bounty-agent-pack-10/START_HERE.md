# Start Here
1. Read AGENTS.md fully.
2. Pick your platform in `platforms/` and copy its files into your project.
3. Fill `templates/00-scope-intake.md` from a live program page.
4. Run `python scripts/scope_guard.py --help`, then check your target.
5. Threat-model (template 02) before any test. 6. Open a Hypothesis Ledger (template 05).
