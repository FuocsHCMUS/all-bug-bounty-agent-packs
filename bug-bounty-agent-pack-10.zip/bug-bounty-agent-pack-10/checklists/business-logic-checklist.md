# Checklist — Business Logic (your own orders/credits/accounts)
- [ ] Draw the state machine for: signup/verify, checkout/pay/refund, trial, invite/accept, approval flows
- [ ] Skip a step / reorder steps / replay a completed step
- [ ] Price/quantity: negative, zero, decimal, currency-switch, coupon stacking (small values, own cart)
- [ ] Limits: per-user quotas, one-time actions — parallel replay (race) on your own resource, small counts
- [ ] Role transitions: downgrade/upgrade mid-flow, invite into higher role, removed member retains access?
- [ ] Time: expired trials/coupons/codes still honored? Timezone edge on billing/booking?
- [ ] Idempotency: double-submit create/pay/redeem — duplicate effect?
- [ ] Cross-feature: export includes deleted/private items? Search indexes leak other-tenant titles? (own tenants)
- [ ] Cleanup: cancel/refund/delete test artifacts; note residual effects in cleanup.log
