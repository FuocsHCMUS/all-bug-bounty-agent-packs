# OWASP WSTG Quick Checklist (hunting prompts — full detail in owasp.org WSTG)
Use as idea prompts inside hypotheses, not as a scanner substitute. Mark: T=tested, N/A, date.

Information gathering: search-engine discovery, server/app fingerprint, entry points,
error handling, infra/app admin interfaces.
Configuration: platform config, file extensions, backup/old files, HTTP methods, HSTS/context.
Identity/Auth: roles, registration, provisioning, credential recovery, MFA, session fixation,
logout, timeout, account lockout (lockout testing can DoS real accounts — own accounts only, gated).
Authorization: directory traversal, object references (IDOR/BOLA), privilege escalation, CORS in context.
Data validation: XSS (reflected/stored/DOM), SQL/NoSQL/LDAP/XML injection, SSTI, command
injection, SSRF, file inclusion/upload, deserialization, prototype pollution, HTTP smuggling.
Business logic: workflow bypass, limits/quotas, race conditions, price/coupon abuse, CAPTCHA purpose.
Cryptography/session: weak TLS in context, token randomness, cookie attributes in context, JWT verification.
Client-side: DOM XSS, CORS, clickjacking in context, WebSockets auth, storage of secrets in browser.
API: endpoint inventory, BOLA, mass assignment, excessive data, versioning, GraphQL authz.
