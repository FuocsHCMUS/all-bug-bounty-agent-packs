# Checklist — Pre-Flight Scope Check (run before ANY active test)
- [ ] Live program page fetched today; date recorded
- [ ] Program open and I am eligible (not private-without-invite)
- [ ] Exact asset in scope.yaml in-scope list (not just a similar domain)
- [ ] Technique not in the program's prohibited list and not in pack defaults (docs/01)
- [ ] Automation: allowed? rate cap? required header/user-agent set?
- [ ] Test accounts: own accounts only; labels A/B ready
- [ ] scope_guard.py passes for every target host in the plan
- [ ] Approval: operator approved this plan (tool, rate, duration, stop condition)
- [ ] Evidence folder + hunt log ready; cleanup tracking ready
If any box is unchecked → do not test. Fix the paperwork, it takes 5 minutes.
