# Checklist — Recon
Passive:
- [ ] Program docs, API docs, developer portal, help center, status page, changelog read
- [ ] CT logs reviewed for subdomains (each still needs Scope Guard)
- [ ] Public GitHub / SDKs / Postman / app-store listings reviewed
- [ ] Search-engine + Wayback review for structure hints
- [ ] Engineering blog / job posts skimmed for stack signals (posture input)
Normal-user:
- [ ] Feature map as a regular user completed
- [ ] Object model written: types, ID format, ownership, sharing states
- [ ] Role list: guest / member / admin / other roles in *your* accounts
- [ ] DevTools network inventory: API hosts, endpoints, auth type, versions
- [ ] Fingerprint table with confidence labels (CONFIRMED/LIKELY/GUESS)
Output: inventory.md complete or gaps explicitly listed.
