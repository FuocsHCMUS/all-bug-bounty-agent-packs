# 00 — Foundations for Beginners (Root-First)

Read this before your first hunt. Every later doc assumes these roots. The agent must use this ladder when teaching: never explain a vulnerability without the root below it.

## 1. How computers talk — Networking in 6 steps
1. **Device & IP address:** Every device on a network has an address (like a house number). Private IPs work inside a home/company network; public IPs are reachable on the internet.
2. **DNS:** Humans use names (`example.com`); machines use IPs. DNS is the phone book that translates name → IP. If DNS is wrong/controlled, traffic goes to the wrong house.
3. **Ports & services:** One IP hosts many services, separated by ports (like apartment numbers): 443 = HTTPS web, 80 = HTTP web, 22 = SSH, 53 = DNS.
4. **TCP & TLS:** TCP makes sure packets arrive in order. TLS (the padlock) encrypts the conversation and checks the server's identity certificate.
5. **Routing / internet:** Packets hop router to router. Anyone on the path who can read unencrypted traffic can spy — that is why HTTPS matters.
6. **Firewall / WAF:** A firewall filters by address/port rules. A Web Application Firewall (WAF) inspects web requests for attack patterns. Both are *filters*, not fixes for broken code.

**Check yourself:** What is the difference between IP, DNS, and port? (Answer: IP = which machine, DNS = name→IP lookup, port = which service on that machine.)

## 2. How the web works — HTTP in 6 steps
1. Browser sends an **HTTP request**: method (`GET` read, `POST` create/send, `PUT/PATCH` update, `DELETE` remove), a URL path, headers, and sometimes a body.
2. Server (often behind a CDN / load balancer / reverse proxy) routes it to an **application**.
3. App checks: *Who are you?* (**authentication**) and *Are you allowed to do this?* (**authorization**). Confusing these two is the root of most high-impact bugs.
4. App talks to a **database** (stores users, posts, orders), files, caches, and other services/APIs.
5. Server returns an **HTTP response**: status code (200 OK, 301 redirect, 400 bad request, 401 not logged in, 403 logged in but not allowed, 404 not found, 500 server error), headers, body (HTML/JSON).
6. Browser renders HTML, runs **JavaScript**, stores **cookies**.

Key headers to learn first: `Cookie`, `Authorization`, `Content-Type`, `Location`, `Set-Cookie`, `Strict-Transport-Security`, `Content-Security-Policy`, `Access-Control-Allow-Origin` (CORS).

## 3. Identity, sessions, and trust
- **Cookie / session token:** After login, the server gives the browser a random token. Whoever presents it is treated as that user. Stealing/forging it = impersonation.
- **Token types:** session cookie, JWT (a signed, self-contained token — read about header.payload.signature), API key, OAuth access/refresh tokens.
- **Trust boundary:** Any place where data moves from "less trusted" to "more trusted" (browser → server, user input → database query, one service → another). Vulnerabilities live at trust boundaries where the receiving side *assumes* instead of *verifies*.
- **Server must never trust the browser:** Prices, roles, IDs, and permissions sent from the browser can be changed by the user. The server must recompute and re-check everything.

## 4. Databases and injection intuition
An app builds database queries from user input. If input is pasted into the query as *code* instead of treated as *data*, the attacker changes the query's meaning — that family is **injection** (SQLi, NoSQLi, command injection, template injection). Fix root: parameterized queries / separation of code and data.

## 5. Same-origin & the browser security model
Browsers isolate sites by **origin** (scheme + host + port). A page from `evil.com` cannot normally read responses from `bank.com`. Features that poke holes in this on purpose (CORS, `postMessage`, cookies with loose settings) must be configured exactly, or data leaks across origins (XSS, CSRF, CORS misconfiguration — learn them in doc 05).

## 6. Attacker, Defender, SOC — three lenses
- **Attacker (red):** "What can I make this system do that it should not?"
- **Builder (fix):** "What check was missing, and where is the *root* place to add it?"
- **Defender (blue / SOC):** SOC = Security Operations Center. Analysts watch logs (SIEM), alerts (WAF, EDR on endpoints, identity logs) and ask: "Would we *see* this attack, and how fast?" Every finding in this pack gets a SOC lens: what log line / alert would this create?

## 7. Your safe practice ladder (never learn on real users)
PortSwigger Web Security Academy (free labs) → OWASP Juice Shop / DVWA in a *local* lab → CTFs (CTFtime) → disclosed reports study → scoped bug bounty with test accounts. This order builds skill without legal or ethical risk.

## Glossary discipline
When the agent introduces any new term, it must define it in one plain sentence on first use. Keep a personal glossary in your learning notes.
