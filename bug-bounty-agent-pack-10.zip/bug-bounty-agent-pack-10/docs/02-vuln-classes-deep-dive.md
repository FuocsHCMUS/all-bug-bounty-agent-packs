# 05 — Vulnerability Classes Deep Dive

Format per class: **Root** (why it happens) → **Where to look** → **Safe test idea (own accounts/data only)** → **Real impact** → **Fix root** → **SOC lens**.
This is a study map, not a payload list. Get hands-on payload practice in PortSwigger Academy / local labs, then apply the *thinking* here within scope.

## Broken Access Control / IDOR / BOLA
Root: server checks login (authentication) but not per-object permission (authorization). Look: numeric/UUID object IDs in APIs, export/download endpoints, sharing features. Safe test: Account A tries to read Account B's *test* object by changing the ID. Impact: data exposure, account takeover chains. Fix: server-side per-object authorization check on every request. SOC: logs of cross-account object access, unusual enumeration patterns.

## Broken Authentication & Session
Root: weak login, reset, MFA, or session lifecycle logic. Look: password reset token predictability/expiry, MFA bypass via response/flow manipulation, session not rotated after login/privilege change, "remember me". Safe test: only on your own accounts, flow-state confusion (skip/reorder steps). Fix: strong tokens, expiry, rotation, rate limits, MFA enforced server-side. SOC: credential-stuffing patterns, impossible travel, reset-request spikes.

## Injection (SQLi, NoSQLi, OS Command, SSTI, LDAP, XPath)
Root: user input crosses into a code/query context (doc 00 §4). Look: search, filters, sorting, report builders, import features, any parameter that reaches a backend interpreter. Safe test: error/behavior-based detection on your own data; time-based only if program allows and at minimal intensity. Fix: parameterization / allowlists / least-privilege DB accounts. SOC: WAF query-pattern alerts, DB error spikes.

## XSS (Reflected / Stored / DOM)
Root: user data reaches a browser as HTML/JS instead of inert text, breaking origin trust. Look: search echoes, profile fields, comments, file names, error messages, JS sinks (`innerHTML`, etc.). Safe test: harmless marker payload on your own content, viewed in your own session; prove execution without touching other users (self-XSS alone is usually low/no impact — look for stored contexts others/admins view). Fix: contextual output encoding + CSP as defense-in-depth. SOC: CSP reports, WAF XSS signatures.

## SSRF
Root: server fetches a user-supplied URL, letting attackers reach internal/metadata services the server can see. Look: URL import, image fetch, webhook testers, PDF/screenshot generators, link unfurling. Safe test: point it at a server *you control* (your collaborator/interactsh-style listener, with operator approval) and observe the request; internal access proof stops at the minimum the program allows. Fix: allowlists, egress filtering, metadata-service hardening (IMDSv2), no redirect-to-internal. SOC: egress logs to metadata IPs, unusual internal DNS.

## CSRF
Root: browser automatically sends cookies; a malicious site tricks it into making a state-changing request. Look: state changes via GET, missing/weak anti-CSRF tokens, lax `SameSite`. Safe test: PoC page acting only on your own account. Fix: tokens + SameSite + origin checks. SOC: referer/origin anomalies (weak signal — prevention beats detection here).

## Security Misconfiguration & Exposed Data
Root: defaults, debug modes, verbose errors, open storage, missing headers, directory listing, old admin panels. Look: error pages, `.env`-style exposure *reports* (never harvest real secrets — stop and report), public buckets linked from the app, CORS over-permissiveness with credentials. Fix: hardened baselines, secret management, least exposure. SOC: internet-exposure monitoring, secret-scanning alerts.

## Business Logic
Root: the app correctly implements a flawed rule — price, quantity, coupon, workflow order, role transition, limit. Look: checkout, credits/refunds, trials, invites, approval flows, race-prone balances. Safe test: your own orders/credits, small values, full cleanup/refund where possible. This class wins bounties because scanners cannot see it. Fix: server-side state machines, invariant checks, idempotency, transaction locking. SOC: anomaly detection on refunds/discounts/limit breaches. See doc 07.

## Race Conditions
Root: two requests in parallel pass a check that only holds sequentially (check-then-act gap). Look: coupon redeem, gift cards, withdrawal, one-time actions, file upload processing. Safe test: parallel requests on your own one-time resource, small counts. Fix: atomic operations, locks, unique constraints. SOC: burst patterns on single-action endpoints.

## File Upload
Root: trusting user files (type, content, storage location, serving origin). Look: avatar/doc upload, import (CSV/XML/zip — XXE and zip-slip live here), image processing (CVE-rich). Safe test: your own benign test files in your own account, prove storage/serving behavior. Fix: allowlist types, random names, separate serving domain, AV/content scanning, unzip safely. SOC: upload-type anomalies, malware-scan hits.

## API-Specific (also doc 08)
Mass assignment (extra JSON fields set role/balance), excessive data exposure (API returns more than UI shows), GraphQL introspection/depth/batch abuse, missing rate limits on sensitive actions (with care — no DoS), old API versions (`/v1`) missing new auth checks, JWT issues (alg confusion, weak verification, kid handling) on your own tokens only.

## Cryptography & Secrets Failures
Root: home-grown crypto, predictable tokens, secrets in client code/repos, encryption without integrity. Look: token formats, password-reset codes (short/no expiry), mobile app / JS bundle secrets (public clients cannot keep secrets — an API key in an app is a finding only if it grants real privilege). Fix: standard libraries, long random tokens, secret vaults, rotation.

## How to study a class
Academy lab (learn payload safely) → root-cause writeup → one disclosed real report → add 3 hypotheses to your next sprint's Coverage Matrix row. Depth in 3 classes beats shallow scanning of 15.
