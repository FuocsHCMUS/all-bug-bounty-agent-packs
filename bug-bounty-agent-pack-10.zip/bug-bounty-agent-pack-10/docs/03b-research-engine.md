# The Research Engine — CVEs, Advisories, Writeups, CTFs

## Source hierarchy (trust order)
1. Vendor advisory / NVD / GitHub Advisory Database (facts about a CVE)
2. Platform disclosed reports (what actually paid, on real programs)
3. Researcher writeups & conference talks (technique + reasoning)
4. CTF writeups (pure technique, often more creative than real-world reports)
5. Social posts / threads (leads only — verify everything)

## For every CVE you consider
Record: CVE ID, title, affected product + versions, fixed version, CWE, references, exploit-availability note (public PoC exists? in-the-wild?), and YOUR applicability verdict with evidence. `scripts/cve_lookup.py` fetches NVD data; your brain does applicability. A CVE for a component the target doesn't run is a learning note, not a finding.

## For every writeup / CTF you read
Extract a technique card (template 07). Ask: What was the broken assumption? What preconditions existed? What's the *transferable idea*? What would detect/prevent it? Link the card into your technique graph by precondition (e.g. "needs file upload", "needs two accounts", "needs a parser differential").

## Keeping research honest
Cite sources in notes (URL + date read). Summarise in your own words; don't copy payload dumps you don't understand. If you can't explain a technique at L1, you are not ready to test it on a live program — take it to a lab first (PortSwigger Academy, a local vulnerable app in your workspace, a CTF).
