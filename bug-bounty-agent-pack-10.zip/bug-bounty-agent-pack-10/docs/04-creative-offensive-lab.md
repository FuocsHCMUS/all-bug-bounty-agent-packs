# CREATIVE EXPLOITATION — Think Up Techniques, Don't Just Repeat Checklists

Checklists find known bugs. Creative thinking finds the bugs the checklist missed — and the sophisticated chains a company has not patched yet because no one thought to combine two "low" issues that way. This file teaches the agent how to generate new techniques systematically, safely, and inside scope.

## 1. The core question, asked for every feature

For every feature, endpoint, and flow, ask, in order:

1. **What does the developer assume here?** Write the assumption down. Most bugs are a violated assumption, not a typo.
2. **Who is trusted, and where does trust change?** Browser → server, user → admin, service A → service B, old version → new version, cached → fresh.
3. **What state is involved?** Sessions, tokens, counters, limits, time windows, order status, payment status. What happens if state is skipped, repeated, replayed, raced, or restored from an old snapshot?
4. **What parsers touch this input?** Browser, server framework, database, template engine, file parser, URL parser, JSON parser. Do any two disagree on the same input (encoding, case, separators, duplicates, truncation)?
5. **What is the second-order effect?** Input stored now, used later — in a report, an email, a PDF, an admin view, a search index, a downstream service. The bug may not trigger where you inject it.
6. **What does the attacker control that the developer forgot?** Headers, order of parameters, duplicate parameters, array vs. string, type confusion (number vs. string), null vs. missing, empty vs. absent.

Generate at least three novel variants per feature from these questions before moving on. Test the safest variant first.

## 2. Seven creative lenses (use at least three per target)

### Lens 1 — Role and boundary crossing
- Same request, different role. Same object, different owner. Same action, before / after a role change. What does the server check — the role at login time, or the role right now?
- Try: a low-priv user calling an admin endpoint directly, a user accessing an object after it was transferred, a former member accessing a resource after removal.

### Lens 2 — Time and order
- Steps out of order, steps repeated, steps raced (two requests at once), expired tokens replayed, old cached responses reused.
- Try: submit step 3 before step 2, submit the same coupon / action twice quickly, reuse a reset link after use, use a token after logout.

### Lens 3 — Parser differentials
- Two systems reading the same input differently: URL parsers, JSON parsers, HTML parsers, file-type detectors, path normalizers.
- Try: duplicate parameters, mixed encoding, case variations, trailing slashes / dots, Unicode look-alikes — as test ideas, judged by the response difference, not by a memorized payload.

### Lens 4 — Composition and chaining
- Two lows make a high. List every low / informational finding, then ask: "If I combine A (leak) with B (weak check), what becomes possible that neither allows alone?"
- Classic chains: info leak → IDOR, CSRF → state change, XSS (self, stored in your own account) → admin view second-order, SSRF to your own server → internal trust signal, rate-limit gap → enumeration → targeted logic abuse.
- Only report a chain you demonstrated end to end, on your own accounts, in scope.

### Lens 5 — The "boring" feature
- The most overlooked features are often the most vulnerable: search, filters, sorting, pagination, export, import, preview, "share," "invite," "forgot password," profile settings, and admin bulk actions. Attackers (and checklists) focus on login and payments; test the boring features with the same rigor.

### Lens 6 — Configuration and defaults
- Default settings, sample data, debug flags, old API versions, staging-like behavior on production, permissive CORS / CSP, verbose errors. A secure feature with an insecure default is still insecure.

### Lens 7 — The defender's blind spot
- What would a SOC analyst NOT see? Actions that look like normal user behavior, low-rate abuse, abuse through a legitimate feature (export, share, invite), or abuse that spans two services so no single log shows the full chain. If you find such a path, that is exactly what the company assessment should highlight for SOC detection.

## 3. From idea to safe test — the creative test card

For each novel idea, fill in a test card before running it:

- **Idea:** One sentence.
- **Assumption it breaks:** What the developer assumed.
- **Feature / endpoint (in scope):** Exact asset, verified against scope.
- **Safe test:** Steps with your own accounts, read-only first, reversible, single request first.
- **Vulnerable signal:** What you would observe if it works.
- **Not-vulnerable signal:** What you would observe if the control works.
- **Impact if true:** Who is affected, what is at stake, in plain language.
- **Stop condition:** When to stop this idea (for example, after 3 clean negatives, or on any block warning).

If you cannot write the "not-vulnerable signal," you cannot interpret the test — research more first.

## 4. Sophisticated does not mean destructive or out-of-scope

Sophisticated techniques are about *understanding* — a subtle state confusion, a parser difference, a chain across two features — not about louder scanning, more payloads, or crossing scope. The most sophisticated report this pack aims for is one where the company says: "We had not thought of that combination, and the fix is a root-cause design change, not a filter."

Rules that keep creativity authorized:
- Creativity stays inside scope, inside program rules, and inside safe testing. A creative idea that requires an out-of-scope asset, another user's data, or a destructive action is not a test — it is a note for the human to ask the program about.
- When a creative idea needs a new tool, follow the Tier rules (portable = workspace, pip = allowed, system / MCP / plugin = ask).
- When a creative idea works, document the *thinking* in the learning note, not just the payload — so the student can re-derive it for the next target.

## 5. After a creative finding — what to write down

In addition to the normal report, record:
- The original assumption and how you thought to question it.
- The variants you tried that did NOT work, and why (this is how the next hunt gets faster).
- The generalized pattern, in a form you can reuse on a different stack.
- The defensive fix at the root cause, and the SOC detection idea that would catch this pattern next time.
- Whether this technique is new to the program's disclosed reports (check first) — if it appears novel, say so carefully: "I did not find this pattern in the program's disclosed reports I checked on [date]" — not "no one has ever found this."

## 6. Practice prompts for the student (safe labs only)

- Take a feature you use every day. Write down five assumptions its developers made. Try to break one in a lab you own.
- Take a disclosed report. Rewrite it as a generalized pattern, then invent two variants that would work on a different feature with the same pattern.
- Take two low findings from your own notes. Write a chain that combines them, then check: is every step proven, or is one step still a guess?

---
## Pack 16 additions — schedulable creative methods
Run one 90-minute creative sprint per hunt day using AGENTS.md §7: (1) Assumption inversion table — assumption / if false / cheapest test / kill criterion. (2) Parser differential hunt — list every pair of parsers touching your input. (3) State-machine sketch — draw it, mark states reachable without the previous step. (4) Second-order map — every place input sleeps before waking in a privileged context. (5) Chain canvas — connect today's primitives before rating any of them 'low'. (6) Invent-then-kill — 10 wild hypotheses, kill 9 cheaply, fund the survivor. Record everything in the Hypothesis Ledger; a creative idea not written down did not happen.
