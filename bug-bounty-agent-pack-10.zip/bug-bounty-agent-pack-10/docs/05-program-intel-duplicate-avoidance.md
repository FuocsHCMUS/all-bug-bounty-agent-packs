# Program Intelligence & Duplicate Avoidance

## Before hunting a program
- Read the full policy twice: scope, exclusions, safe harbour, disclosure rules, bounty table, "known issues / out of scope" notes.
- Read recent program updates and scope changes (a newly added asset is the least-hunted asset).
- Read disclosed reports on that program (HackerOne Hacktivity / Bugcrowd Disclosure): what classes were already found, in which features? Don't re-hunt exhausted ground unless you have a genuinely new hypothesis (variant, chain, or a code path the earlier report didn't cover).
- Note the tech stack the program volunteers (help docs, status page, job ads are public intel — reading them is passive and fine).

## Choosing where to hunt
Prefer: new scope, complex features (payments, sharing/permissions, imports/exports, integrations, file handling), features with many roles, and anything involving money movement or cross-account interaction. Avoid (early on): purely static marketing pages and third-party widgets the program doesn't control (usually out of scope anyway).

## Duplicate discipline
If a class was disclosed on the same endpoint recently, assume it's patched or known; test for *variants/bypasses* only with a clear hypothesis card, and say in your notes that it's a variant attempt. Never submit a likely duplicate knowingly — tell Joshua the duplicate risk honestly in the report draft.
