# 10 — Company Security Posture Analysis

After every sprint, analyze the *company*, not just the bug. Use `templates/posture-analysis.md`. This is how a student learns to think like a security team, not only a hunter.

## What to analyze (work through all 12, write "No signal yet" where you have none — do not invent signals)
1. **Asset & scope hygiene:** Is the program scope clear/current? Are wildcards sane? Fast program-page updates = mature.
2. **Identity & access:** MFA/passkey/SSO quality, session behavior, role granularity, admin protections observed.
3. **Authorization architecture:** Per-object checks consistent or patchy? Patchy authz usually means a systemic missing middleware — say so (kindly, with evidence) in reports.
4. **Input handling & output encoding:** Centralized validation? Consistent error behavior? WAF present and tuned, or theater?
5. **API security maturity:** Versioning discipline, schema strictness, rate limits, deprecation of old endpoints.
6. **Data protection:** Encryption in transit, redaction in UI/API responses, export controls, retention signals, public-exposure hygiene.
7. **Dependency & patch management:** Fingerprinted versions vs. current — are CVEs patched promptly? (doc 04 discards are data here.)
8. **Secure SDLC signals:** Changelogs, security.txt, headers evolution, bug bounty history patterns (repeat vuln classes = root process gap).
9. **Detection & response (SOC lens):** Would tests be logged/alerted? Did you get blocked, challenged, or contacted? `security.txt` / response speed / triage quality as IR maturity signals. Map likely telemetry: WAF logs, IdP logs, API gateway, EDR, SIEM use cases that *should* fire.
10. **Cloud & infrastructure hygiene:** Only from in-scope observations: headers/CDN config, storage exposure, metadata protections inferred from SSRF-surface design.
11. **Third-party & supply-chain risk:** Vendors/integrations visible, OAuth scope discipline, sub-processor transparency.
12. **Security culture signals:** Transparency reports, public postmortems, researcher friendliness, remediation speed on your report.

## Scoring — use words, not fake precision
For each area: `Strength / Adequate / Needs Improvement / High Risk / No Signal`, each with 1–3 evidence bullets and a confidence (Low/Med/High). End with:
- **Top 3 strengths** (genuinely credit them — in the report thank-you note too)
- **Top 3 systemic risks** (patterns, not single bugs)
- **If I were their AppSec lead, my next 90 days:** prioritized, realistic fixes mapped to OWASP ASVS / CIS Controls / NIST CSF functions (Govern, Identify, Protect, Detect, Respond, Recover — define on first use).
- **What this teaches me:** 2–3 lessons for your own future building/defending.

## Tone rule
Posture analysis is a private learning document for the operator. In anything sent to the company, be factual, kind, and specific. You are a guest helping them improve.
