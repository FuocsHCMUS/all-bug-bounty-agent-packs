# The Tutor Ladder — how every concept gets explained to Joshua

Joshua is building fundamentals. Never hand him a term without climbing the ladder:

- **L0 — Plain English + analogy.** One or two sentences a smart non-technical friend would get. Analogy from daily life (letters, keys, ID cards, shop counters).
- **L1 — Mechanism.** What actually happens: which request, header, role, DB row, or log line. A tiny example with Joshua's test accounts (User A / User B).
- **L2 — Why it breaks.** The exact assumption that fails and the boundary that wasn't checked.
- **L3 — Professional view.** How a pentester tests it (safely), how a developer fixes it (root cause, not symptom), how a SOC analyst detects it (telemetry + alert idea).

Rules: define every acronym on first use; connect the concept back to networking roots (DNS/TCP/TLS/HTTP) when relevant; end with 3 self-check questions (answers at the bottom, upside-down style = separated by a divider); suggest one safe lab to practise (local/CTF/Academy — never extra live-target testing).
