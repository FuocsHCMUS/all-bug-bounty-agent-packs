# Severity & Impact — honest scoring

## Impact first
Answer in plain words: who is harmed, what data/money/access, at what scale (one user = your other test account proves the *class*; scale claims need a mechanism, not imagination), and what an attacker still needs (victim interaction? a leaked ID? an account?).

## CVSS v3.1 in 60 seconds
A vector like `CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N` encodes: network-reachable, low complexity, low privileges required, no user interaction, unchanged scope, high confidentiality impact. Use a public calculator, paste the vector, and write one sentence justifying each non-obvious choice. If you can't justify it, lower it.

## Common honesty traps
- Calling stored XSS "critical" with no session/account impact shown.
- Claiming "full account takeover" from a step that needs the victim's password.
- Counting a self-only bug (affects only your own account) as affecting others.
- Reporting a missing header as a vulnerability by itself (it's hardening — note it in posture, not as a finding, unless chained to a proven exploit).

Programs reward clear, proven, honest reports with faster triage and better long-term trust. That's worth more than one inflated bounty.
