# Evidence, Privacy & Hygiene for Hunters

- Keep hunt data in the hunt folder; encrypt/back up per Joshua's normal practice. Never commit hunt data to a public repo.
- Redact: session tokens, API keys, real emails/IDs of strangers (if accidentally seen — minimise, don't store, flag to Joshua).
- Your own test-account credentials: store in Joshua's password manager, never in notes or scripts.
- Use a dedicated browser profile for testing so test cookies/data never mix with personal accounts.
- Timestamps: record local (Asia/Saigon) + UTC for anything that might be compared with server logs.
- Clean up: delete test files/uploads you created on a target after reporting, if the program allows/expects it, and note that you did.
