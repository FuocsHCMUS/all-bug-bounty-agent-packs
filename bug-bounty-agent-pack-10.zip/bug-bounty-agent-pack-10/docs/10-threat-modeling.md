# Knowledge — Lightweight Threat Modeling for a Single Feature

Use this 15-minute model before deep testing of any important feature. Keep it in the hunt folder.

## Template
```
Feature:
Actors & roles:
Data in / out (and its sensitivity):
Trust boundaries crossed:
Server-side components involved (guess + confidence):
Invariants (must-always-be-true statements):
Abuse cases (one line each, "an attacker who ___ could ___"):
Existing controls you can see:
Controls you cannot see (assumptions to test):
Top 3 hypotheses this generates:
```

## Prompts that generate good abuse cases
- What if I do this as the *other* role / tenant / logged-out?
- What if I skip, repeat, reorder, or parallelize a step?
- What if the value is negative, huge, fractional, in another currency/unit/timezone, or a string where a number is expected?
- What if two parsers see this input differently?
- What if this feature's output becomes another feature's input?
- What would a SOC analyst see if I did this — anything at all?

## Output discipline
Every abuse case either becomes a numbered hypothesis or is explicitly parked with a reason (out of scope, needs approval, low value). No silent drops.
