# Tools Catalog — Portable First

Philosophy: skill > tools. Master the browser + one proxy + small scripts before collecting scanners. Prefer portable builds in `tools-local/` per the Permission Model.

## Tier 0 — Already in your hands (learn deeply first)
- **Browser DevTools** (Network, Application, Console) — your first recon and evidence tool.
- **curl** — precise manual requests; scriptable, transparent.
- **Python 3.14 + requests/httpx** — custom checks you fully understand (scripts/ in this pack).
- **Text editor + this pack's templates** — notes are a security tool.

## Tier 1 — Core hunting (operator installs/approves; some are Windows installers → Ask First)
- **Burp Suite Community/Pro** (intercepting proxy — the industry standard for manual web testing; installer → ask).
- **OWASP ZAP** (free, open-source proxy/scanner alternative).
- **Foxtrot / browser profiles** — separate Firefox/Chrome profiles for Account A / B sessions (no tool needed).

## Tier 2 — Recon helpers (many are portable Go binaries / git clones → often pre-approved if workspace-local)
- `subfinder`, `assetfinder`, `httpx`, `katana`, `naabu` (ProjectDiscovery) — use ONLY within program automation rules + approved rates.
- `nuclei` — template scanner: powerful and noisy; use narrow templates, approved plan only; every hit is a hypothesis, not a finding.
- `ffuf` — content discovery/fuzzing (approval + rate discipline).
- `arjun`, `paramspider`-style parameter discovery — passive-leaning, still respect scope.
- `gau` / `waybackurls` — historical URL research (passive).
- `jwt_tool` / jwt.io — inspect *your own* tokens.
- `interactsh` client — SSRF/blind callback listener for *your* test server (approval required before target use).

## Tier 3 — Learning labs (install nothing on targets; local only)
- PortSwigger Web Security Academy (online labs, free), OWASP Juice Shop (local/Docker), DVWA (local VM/Docker only), Hack The Box / TryHackMe (platform labs).
- Docker on Windows is a system install → Ask First once; individual lab containers after that still get logged.

## Rule for every tool
Record in the hunt log: name, version, source, command shape, target list, rate. If you cannot explain what a tool sends, do not point it at a target — learn it in a lab first.
