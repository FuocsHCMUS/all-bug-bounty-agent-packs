# Knowledge — Writeup Mining (from disclosures & CTFs to reusable technique)

**Goal:** Learn the *primitive* behind other hunters' wins, then look for the same primitive — not the same payload — in your in-scope target.

## Sources (public, read-only)
- HackerOne Hacktivity / disclosed reports; Bugcrowd disclosure lists & Crowdstream highlights.
- PortSwigger Research + Web Security Academy (topics + labs — labs are your practice ground).
- PentesterLand writeup aggregator (search by bug class / technology).
- CTF writeups: CTFtime, team blogs, GitHub writeup repos — especially web/API challenges using your target's stack.
- Vendor/framework security blogs and release notes ("what did they fix last year? that pattern recurs").

## The Technique Card (one per useful writeup)
```
Source: <title + link + date>
Target class: <the kind of app/feature, not just that one company>
Bug class / CWE:
Root-cause primitive: <the underlying mistake in one sentence, e.g., "server trusted a client-supplied tenant ID on one of five endpoints">
Preconditions: <roles, features, config needed>
Signals to look for: <what you can observe passively/normally that hints this exists>
Safe test idea (in-scope, own accounts):
Detection / fix pattern: <for the learning note>
Freshness: <is this technique patched by design in modern frameworks? where is it still alive?>
```

## From CTF to real world — translate, don't transplant
CTF tricks assume a toy app. Ask: what real feature would have the same shape? (importers, preview renderers, URL fetchers, invite flows, file converters, search, webhooks). Note where CTF techniques would violate real program rules (volume, destructiveness) and redesign a minimal version.

## Cadence
Mine writeups (a) at Phase 4 for the current target's stack, (b) weekly for one bug class the Operator is learning. Always convert reading into cards + hypotheses or a lab exercise — passive reading alone does not build skill.
