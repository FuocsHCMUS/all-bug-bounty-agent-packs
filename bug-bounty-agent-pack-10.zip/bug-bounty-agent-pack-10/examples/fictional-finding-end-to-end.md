# Example — One Finding, End to End (FICTIONAL — for learning the workflow)

Target: "ShopDemo" (invented SaaS, example program, `app.shopdemo.test` in scope).

## Phase 0–3 (compressed)
Scope intake filed: `*.shopdemo.test` web only, no automated scanning,
≤1 rps, test accounts provided. Dossier notes: invoices are objects with
sequential IDs; invariant #3: "a user can only view their own invoices."

## Hypothesis H2 (from backlog)
"As Account B I can read Account A's invoice by changing its ID"
— BOLA, playbooks/03+04, Impact 4 × Likely 3 ÷ Effort 1.

## Experiment EXP-007 (Tier B approved: 4 manual requests)
Baseline: B opens B's own invoice `/api/invoices/1007` → 200, B's data.
Test: B requests `/api/invoices/1006` (A's, created minutes earlier) → 200,
A's invoice total + item list. One variable changed (the ID). Stop — minimum
proof reached. No other IDs touched.

## Validation (playbooks/12)
Reproduced next day from a fresh B session. Docs confirm invoices are
private. Not in known-issues. Severity: program uses CVSS — proposed
6.5 (network, low complexity, low privileges, no interaction, changed
confidentiality high for that object) with business impact stated plainly:
any customer can read any other customer's invoices (prices, items, addresses
shown in the full invoice view — the address field is what raises this).

## Report
Filed from templates/03: title "[app.shopdemo.test] Broken object-level
authorisation on GET /api/invoices/{id} allows any customer to read other
customers' invoices", steps = the 4 requests, remediation = server-side
ownership check per object + regression test with two accounts.

## Posture analysis (extract, templates/05 style)
- Doing well (Observed): authorisation *is* enforced on payments endpoints
  (14 cross-account tests all 403) — suggests checks exist but are applied
  per-endpoint by hand rather than in a shared middleware.
- Needs improvement: make object-ownership a framework-level default.
- SOC view: bulk invoice reads would be visible as sequential-ID GETs from
  one account — a detection idea: alert on >N distinct invoice IDs/account/hour.
- High-risk pattern: sequential IDs + manual per-endpoint checks = the same
  bug likely exists on rarer endpoints (exports, refunds) — recommended audit.

## Learning notes (extract, templates/06 style — abbreviated)
Fundamental: an **object** is a thing the app stores (an invoice). An **ID**
is its name tag. **Authorisation** is the server asking "does *this* user own
*this* object?" on *every* request — the app asked "are you logged in?"
(authentication) but forgot the second question. Analogy: a hotel checking
you have *a* key, but not whether it opens *this* room.
Full notes would continue: happy path → assumption → fix → SOC view →
self-check Qs ("What's the difference between a UUID and an ownership check?
Why doesn't hiding the ID in the UI fix this?") → PortSwigger access-control lab.

*This example is deliberately small. Real hunts add evidence hashes, the
experiment log and fuller notes — the shapes stay exactly these.*
