# Worked Example (FICTIONAL — no real target)

Program: "ShopDemo" (fictional), scope: `app.shopdemo.test` + its API, test accounts allowed, automation <=1 rps.
Intake: completed; forbidden: payment with real cards, accessing other customers' data.
Threat model (orders feature): A creates order #1001. Assumption: "only the owner can view an order, because the UI only links your own."
Hypothesis H-1: the API checks login but not ownership (BOLA).
Test (Tier B approved): B requests `GET /api/orders/1001` (A's test order).
Signal: 200 with A's test order contents ("TEST-ORDER-A marker") -> Confirmed, class proven with test data only. Stop.
Report: drafted in template 03, CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N (justified: any logged-in user, others' order PII).
Posture notes: ShopDemo does well — TLS, cookie flags, rate limiting on login all present (headers_check output). Needs improvement: per-object authz was inconsistent (the PDF-export endpoint DID check ownership — inconsistent coverage is the systemic pattern). SOC lens: repeated cross-account 200s on /api/orders/* from one account would be a clean alert; likely not logged today.
Tutor notes: BOLA climbed L0 (a shop clerk handing you someone else's receipt because you knew its number) -> L3 (fix: central ownership check per object; detect: log owner vs requester mismatches).
Lesson: inconsistent authz coverage across endpoints for the same object is one of the highest-value patterns to hunt.
