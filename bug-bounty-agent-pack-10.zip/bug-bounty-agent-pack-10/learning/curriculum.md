# Learning Curriculum — from fundamentals to hunter (self-paced)

## Stage 0 — Networking roots (do not skip)
DNS, IP/ports, TCP handshake, TLS certificates, HTTP requests/responses, cookies/sessions, status codes.
Done when: you can narrate docs/01 Section 1 from memory with an example.

## Stage 1 — Web basics + labs
HTML/JS basics, how APIs/JSON work, Burp-style intercepting-proxy concepts.
Labs: PortSwigger Web Security Academy (free) — start: SQLi, XSS, access control tracks.

## Stage 2 — Core bounty classes (playbooks 02,03,04,07 in labs first, then in scope)
Auth/session, IDOR/BOLA, business logic, XSS. Done when: 4 technique cards + 1 lab writeup each.

## Stage 3 — Server-side & APIs (playbooks 06,08,09,10)
Injection concepts, SSRF, file handling, GraphQL. Add: basic SQL, basic JavaScript reading.

## Stage 4 — Research skills (workflows 02,03)
CVE loop fluency, writeup mining, technique graph growing (target: 2 cards/week).

## Stage 5 — Blue lens & breadth (playbook 11-14 + SOC)
Logging/detection basics (what a SIEM sees), cloud/SaaS config, mobile backends, AI-app security.
Scripting: Python for hunters — extend scripts/ (always stdlib-first, always dry-run option).

## Weekly rhythm
2 lab sessions + 1 mining session + 1-2 scoped hunt sessions + 1 retro (template 09). Consistency beats marathons.
