# Learning — Fundamentals Roadmap (what the agent teaches, in dependency order)

The agent uses this ladder when explaining concepts: never explain rung 5 using rung 7 words without first covering the missing rungs the Operator needs.

1. **Computers & networks, tiny pieces:** client vs server; IP address; port; DNS (name → IP, like a phonebook); TCP vs UDP in one line; TLS/HTTPS (encryption + identity).
2. **The web:** URL anatomy; HTTP request (method, path, headers, body) and response (status, headers, body); statelessness; cookies; sessions; caching in one paragraph.
3. **Identity:** authentication (who are you) vs authorization (what may you do) — the single most profitable distinction in bug bounty; passwords, MFA, OAuth/SSO at flow level; tokens (session cookie vs JWT shape).
4. **Servers & data:** frontend vs backend vs API; databases in one model (tables, queries); files/uploads; queues/background jobs; CDNs and caches.
5. **Code-level causes:** input validation, encoding/escaping (context matters), parameterized queries, server-side enforcement, secrets/config.
6. **Bug classes as broken invariants:** IDOR/BOLA, XSS, SQLi, SSRF, CSRF, auth bypass, race conditions, business-logic abuse — each taught as "which invariant broke, where".
7. **Defense:** patching the root cause, least privilege, defense-in-depth, WAFs (and their limits), logging/monitoring.
8. **Blue team / SOC:** logs, alerts, SIEM in plain words; IOCs; detection ideas per bug class; incident response at a high level.
9. **Professional practice:** scope & authorization, responsible disclosure, report writing, CVSS, program etiquette.

**Rule for the agent:** when the Operator is lost, go *down* the ladder, not louder. One rung, one tiny example, check understanding, then climb.
