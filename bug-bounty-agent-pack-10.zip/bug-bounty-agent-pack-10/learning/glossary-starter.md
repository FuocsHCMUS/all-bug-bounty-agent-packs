# Glossary Starter (grow it in your own words)
- **AuthN / AuthZ:** proving who you are / checking what you may do.
- **BOLA/IDOR:** accessing another user's object by changing its ID, because the server skipped the ownership check.
- **CVE:** a catalogued, publicly disclosed vulnerability with an ID (CVE-YYYY-NNNN).
- **CVSS:** a standard severity scoring system (vector + 0-10 score).
- **PoC:** proof-of-concept — the minimal demonstration that a bug is real.
- **RAG:** retrieval-augmented generation — an AI answers using documents it fetches; per-user filtering there is an authz problem.
- **Scope:** the written list of assets/techniques a program authorises. Outside it = no permission.
- **SOC:** Security Operations Centre — the team watching logs/alerts to detect attacks.
- **SSRF:** making a server fetch an attacker-chosen URL.
- **TOCTOU:** time-of-check/time-of-use race — a check passes, then state changes before the action.
- **Trust boundary:** where data/actors go from untrusted to trusted; checks belong here.
(Add 2 terms per hunt, in your own words, L0 style.)
