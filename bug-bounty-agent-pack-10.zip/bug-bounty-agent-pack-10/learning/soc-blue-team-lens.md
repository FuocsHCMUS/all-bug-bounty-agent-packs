# Learning — The SOC / Blue-Team Lens (required in every learning note)

Offense teaches defense. For every finding or serious hypothesis test, answer:

1. **Footprint:** What would this activity look like in normal logs? (web/access logs, auth logs, API gateway, WAF, application audit log, cloud logs — whichever apply.)
2. **Signals:** Which fields would betray it? (impossible object IDs across tenants, user-agent/IP anomalies, error spikes, unusual export volume, off-hours admin actions…) Distinguish strong signals from noise.
3. **Detection idea in plain English:** "Alert when the same account reads objects from two different org IDs within 5 minutes" — no SIEM query syntax required unless the Operator asks; if you give a query sketch, explain each condition.
4. **Telemetry gaps:** What is probably *not* logged that should be? (object-level access logs, role changes, export events…)
5. **Response sketch:** If a SOC saw this for real: triage → contain (session revoke, key rotation) → scope the impact → fix → hunt for the same pattern historically.
6. **Career bridge:** Name the blue-team skill this builds (log analysis, detection engineering, incident response) in one line — the Operator is building a whole Cyber career, not just hunting.

Keep this honest: say "this would be nearly invisible in logs because…" when true — that invisibility is itself a posture finding.
