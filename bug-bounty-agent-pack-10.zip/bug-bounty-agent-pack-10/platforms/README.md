# Platforms
Copy ONE adapter into your project root, alongside the canonical AGENTS.md. Claude Code: use .claude/skills/bug-bounty/ (no CLAUDE.md needed). Codex: root AGENTS.md is native. OpenCode: .opencode/agent/bug-bounty.md. Cline: .clinerules. Cursor: .cursor/rules/*.mdc (4 files in pack 16). Antigravity: .agent/rules + .agent/workflows + GEMINI.md.
