# Antigravity Rules — Bug Bounty (always on)

1. Canonical file: project root `AGENTS.md`. Read it; it wins on conflict.
2. No completed scope intake (`templates/00-scope-intake.md`) → no target traffic.
3. Approval tiers: Tier A = read-only research, in-project files, portable
   clones into `./tools/`, venv pip installs for own scripts. Tier B = ask
   first (core/02 format): anything run against a target, system installs,
   MCP/plugins/skills, report submission, program contact, uploads, spending.
   Tier C = never: out-of-scope, DoS, persistence, social engineering,
   real-user data beyond one minimum-proof request.
4. Phases 0–9 in order; log experiments and evidence; redact before sharing.
5. Every finding: report + posture analysis + learning notes (English,
   beginner-first, from fundamentals upward).
