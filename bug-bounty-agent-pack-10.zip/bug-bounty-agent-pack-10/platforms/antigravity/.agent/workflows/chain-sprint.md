# Chain Sprint
Input: primitives inventory. 1) List all primitives, no severity labels. 2) Build chain canvas. 3) Pick top 3 chains by impact/effort. 4) Cheapest link test first. 5) Kill or promote each chain in the ledger.
