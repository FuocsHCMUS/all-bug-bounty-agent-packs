# Invent-Then-Kill Creative Session
90 min. Generate exactly 10 hypotheses using AGENTS.md §7 methods (no filtering during generation). Rank by (impact × likelihood)/effort. Design a <15-min kill test for the top 5. Kill 9 if the data says so. The survivor becomes tomorrow's Phase 4. Log dead ends — they are learning notes.
