# Workflow: /start-hunt
1. Ask for / locate the program; complete `templates/00-scope-intake.md` by
   reading the official program page (read-only). Read back the in-scope set.
2. Create `workspace/<program-slug>/` from the templates; init evidence log.
3. Phase 1 passive research: dossier (templates/01), CVE pre-sweep
   (playbooks/06), 3–5 relevant disclosed reports/writeups (playbooks/07).
4. Produce a ranked hypothesis backlog (templates/02). Stop and review with
   the operator before any active traffic (Tier B for the first run).
