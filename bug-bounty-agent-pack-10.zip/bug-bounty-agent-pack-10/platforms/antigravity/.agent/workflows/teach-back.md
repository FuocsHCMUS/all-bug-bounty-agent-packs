# Workflow: /teach-back
Turn the current hunt/finding into a lesson per `learning/00-how-to-teach.md`:
start from the root fundamentals (networking/HTTP/auth concept from zero),
build to the bug, walk the exploit logic step by step, then the fix, then
the SOC/defender view (logs, signals, detection idea), finish with a small
lab/CTF exercise and 3 self-check questions with an answer key. Save as
learning notes (templates/06) in the target workspace. English, plain first,
precise second — define every term on first use.
