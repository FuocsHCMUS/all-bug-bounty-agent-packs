# Workflow: /write-report
1. Confirm the finding reproduces from a clean state; freeze evidence,
   hash files, prepare redacted shareable copies (core/03).
2. Draft with `templates/03-finding-report.md` (or 04 platform variant).
3. Run `checklists/report-qa.md`; fix every failing line.
4. Draft posture analysis (templates/05) and learning notes (templates/06).
5. Present the full package to the operator. Submission is Tier B — the
   operator submits or explicitly approves submission. Never submit silently.
