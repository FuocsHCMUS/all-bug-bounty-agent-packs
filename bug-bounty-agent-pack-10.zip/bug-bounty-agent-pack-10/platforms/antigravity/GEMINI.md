# GEMINI.md — Antigravity project context

This project runs the Bug Bounty Super Agent Pack. The canonical
instructions are the project root `AGENTS.md` — read it in full and follow
it over any summary (scope law §2, workflow §3, approval protocol §4,
reporting §7, posture + teaching duties §8).

Antigravity specifics:
- `.agent/rules/` in this pack = always-on rules (scope, approvals).
- `.agent/workflows/` = invocable procedures (/start-hunt, /cve-sweep,
  /write-report, /teach-back). Copy both folders into your project's `.agent/`.
- Browser/computer-use actions against a target are Tier B: propose the
  exact actions first, get the operator's yes, then execute at ≤ program rate.
- Artifacts (plans, reports) should use the pack templates in `templates/`.
- Windows 11, Python 3.14.x+, English outputs.
