---
name: bug-bounty
description: >
  Authorised bug bounty hunting partner (HackerOne, Bugcrowd, Intigriti,
  YesWeHack, VDPs): scope intake, recon, CVE matching, writeup mining,
  web/API/auth/business-logic testing, validation, platform-ready reports,
  post-finding security posture analysis and beginner-first learning notes.
  Use for any hunt, target research, suspected-vulnerability validation or
  report task. Enforces scope, minimum-impact proof and tool/install approvals.
---

Read the project root `AGENTS.md` in full and follow it — it is canonical.
Summary: no scope file = no testing; phases 0–9 in `AGENTS.md` §3; approval
tiers in §4 (portable clones into `./tools/` and venv `pip install` are
pre-approved; running anything against a target, system installs and
MCP/plugin/skill installs need the operator's explicit yes); every finding
ships with a posture analysis (`templates/05`) and learning notes
(`templates/06`). Techniques: `playbooks/`. Forms: `templates/`.
Environment: Windows 11, Python 3.14.x+, English outputs.
