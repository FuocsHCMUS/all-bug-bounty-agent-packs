# Claude Code setup

Modern Claude Code reads **`AGENTS.md`** natively — that is the primary file.
Setup:
1. Copy the pack root `AGENTS.md`, `SKILL.md` (optional) and the shared folders
   (`core/ playbooks/ learning/ templates/ checklists/ prompts/ scripts/
   references/ examples/`) into your project root.
2. Install the skill: copy `.claude/skills/bug-bounty/SKILL.md` from this folder
   into your project's `.claude/skills/bug-bounty/SKILL.md`.
3. Keep root `CLAUDE.md` only if an older setup expects it — it is a shim that
   points to `AGENTS.md`. Do not maintain instructions in two places.
4. Optional MCP servers (Burp, browser, search) are **Tier B**: the agent must
   name the server and why; you install it, the agent never self-installs.
   Suggested starting point: no MCP at all — the playbooks work with
   browser + terminal + your proxy of choice.
5. Permissions tip: allow file writes inside the project and `git clone` into
   `./tools/`; keep network tools against targets behind your approval.
