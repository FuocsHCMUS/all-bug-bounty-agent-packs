# Codex — project instructions

This project uses the Bug Bounty Super Agent Pack. Read the pack root
`../../AGENTS.md` in full before doing anything and treat it as canonical
(scope law §2, workflow §3, approval protocol §4, reporting §7,
post-finding analysis + teaching §8). The root `SKILL.md`, `core/`,
`playbooks/`, `learning/`, `templates/`, `checklists/` and `prompts/`
folders are part of these instructions.

Codex-specific notes:
- Sandbox: keep writes inside the workspace; network access to a *target*
  is a Tier B action even if the sandbox would allow it.
- Approvals: never use `--dangerously-bypass-approvals`-style flows for
  target interaction. Ask in the Tier B format (core/02).
- Shell: operator is on Windows 11 — prefer PowerShell; Python via `py -3.14`.
