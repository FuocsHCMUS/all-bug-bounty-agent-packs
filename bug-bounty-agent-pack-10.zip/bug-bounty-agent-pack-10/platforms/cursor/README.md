# Cursor / Cline setup
- Cursor: copy `.cursor/rules/*.mdc` into your project's `.cursor/rules/`
  and keep pack root `AGENTS.md` at project root (Cursor reads it too).
- Cline: copy `.muserules` to your project root (or split it into a
  `.muserules/` folder if you prefer per-topic files — keep the approval
  rules in an always-loaded file).
Both adapters are thin: canonical instructions stay in root `AGENTS.md`.