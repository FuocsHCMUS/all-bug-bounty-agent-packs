# OpenCode setup
Copy pack root `AGENTS.md` to your project root (OpenCode loads it
automatically), copy `.opencode/agent/bug-bounty.md` into your project's
`.opencode/agent/`, and — only after reviewing it yourself — copy
`opencode.json.example` to `opencode.json`. Adding MCP servers in that
config is operator-only (Tier B rule in AGENTS.md §4).