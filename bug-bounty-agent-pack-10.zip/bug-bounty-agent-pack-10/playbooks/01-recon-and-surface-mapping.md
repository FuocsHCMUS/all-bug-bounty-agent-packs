# Playbook: Recon & Attack-Surface Mapping

Passive first: program docs, help centre, public JS, sitemap/robots (public files), app-store listing, API docs if published. Build an asset/feature inventory: hosts, roles, features, file flows, integrations, webhooks. Active recon (port/dir discovery) is Tier B, in-scope only, rate-limited, and only if the program allows automation. Output: surface map in the threat-model template, with each surface linked to a playbook.

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
