# Playbook: Authentication, Session & Account Lifecycle

Concepts L1: credentials -> session token (cookie/JWT) -> every request proves identity via that token; MFA adds a second factor; password reset is an alternate login path and must be as strong as login. Test areas (own accounts only): registration (duplicate/alias emails, role fields smuggled in signup), login (error-message differences = info leak note, rate limiting presence), reset flow (token predictability/expiry/single-use, host-header trust — concept level), session (logout actually invalidates? session survives password change? cookie flags via headers_check), MFA (bypass via lifecycle gaps, e.g. session issued before MFA completes), account deletion/re-registration edge cases. Stop at proof: e.g. 'reset token still worked after use' with your own account.

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
