# Playbook: Authorisation — IDOR / BOLA / Function-Level AuthZ

The #1 bounty class. L1: every object (order, file, message) has an owner; every request must check 'does THIS user own THIS object?' on the server. Method: with Account A create objects, capture their IDs; with Account B request/change/delete them (read first, write only on your own test data created for this). Vary: numeric IDs, UUIDs (check other leaks of the UUID), nested IDs (/users/A/orders/B-order), method change (GET works blocked, try the API/mobile variant), role endpoints (user token on admin function). Also: mass-assignment (adding role/is_admin/price fields to an update the UI never sends). Proof = B sees/changes A's test object. Log the exact check that was missing.

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
