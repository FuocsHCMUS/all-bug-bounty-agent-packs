# Playbook: Business Logic & Workflow Abuse

Logic bugs = the app follows its rules to a harmful conclusion. Map the workflow as states; test: skip a step, repeat a paid step's benefit, negative/zero/huge quantities, price/coupon manipulation via API parameters the UI hides, refund/return flows, trial/subscription lifecycle, invite/referral self-dealing (check program rules first), limits enforced only in UI. Always hypothesis-card first; money flows need Tier-B approval and test-mode payments only. Proof is a ledger/screenshot from your own test accounts showing the incorrect final state.

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
