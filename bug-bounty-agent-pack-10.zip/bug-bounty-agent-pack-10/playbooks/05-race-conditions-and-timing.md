# Playbook: Race Conditions & Timing

L1: 'check then act' is two steps; two requests arriving between them can both pass the check (TOCTOU). Classic shapes: redeem-once codes redeemed twice, limited stock/coupons, vote/like limits, withdrawal > balance (test accounts, test money only). Method concept: send a small burst (start with 2, then ~10) of identical requests in parallel against YOUR test resource; compare final state to the intended invariant. Rate-limit yourself, single endpoint, stop once the invariant breaks (or holds). Many programs restrict automated/burst testing — check policy; Tier B always.

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
