# Playbook: Injection — Concepts & Safe Checks

L1: injection = user input is interpreted as code/query/template by a component that should treat it as data. Classes: SQLi, NoSQLi, OS command, SSTI, LDAP/XPath, header/log injection. Safe-check philosophy: use harmless differential probes (a quote that breaks syntax vs. escaped; a time/boolean difference) on YOUR test data, single parameter at a time; the moment a differential is confirmed, stop escalating — you have proven the class; do NOT dump databases or read other users' rows. Extracting data beyond a minimal proof marker is a Tier-C violation in this pack. Fix lens: parameterised queries / safe APIs / context encoding; SOC lens: query-error logs, WAF events.

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
