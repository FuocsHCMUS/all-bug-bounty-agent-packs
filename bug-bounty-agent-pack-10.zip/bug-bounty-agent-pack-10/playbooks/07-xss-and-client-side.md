# Playbook: XSS & Client-Side Security

L1: XSS = attacker script runs in a victim's browser in the site's origin, inheriting trust. Types: stored (in DB, shown to others/admins), reflected (in the response), DOM (pure client-side JS sinks). Safe method: use a unique harmless marker payload on your own content (e.g. a console/DOM marker or the classic alert on YOUR browser only), check where your input lands (HTML, attribute, JS string, URL) and whether encoding matches that context. Also check: CSP header presence/strength (posture note), DOM sinks (innerHTML, document.write) in public JS, postMessage handlers without origin checks (concept), and clickjacking (frame headers) as a chain element only. Never target real users; proof = your payload firing in your browser on your test content, or in an admin-view simulation if the program provides one.

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
