# Playbook: SSRF & Server-Side Requests

L1: SSRF = you make the server fetch a URL you choose; the server's network position (internal services, cloud metadata) becomes reachable if unchecked. Test surfaces: URL fetch/preview, webhook testers, PDF/image import-by-URL, avatar-by-URL. Safe method: point it at a server YOU control (your own listener/collaborator-style endpoint approved by Joshua, Tier B) and confirm the server made the request (log the User-Agent/IP). Do NOT probe internal addresses or cloud metadata on a live target beyond what the program explicitly allows — server-side request to your own endpoint already proves the class; internal reachability claims need program permission. Fix lens: allowlist, DNS/IP validation after redirects, block private ranges, separate egress.

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
