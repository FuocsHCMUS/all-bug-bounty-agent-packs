# Playbook: File Upload, Download & Path Handling

Upload checks: type validation (extension vs magic bytes vs server re-encoding), stored location (web-accessible? executed? separate domain?), filename handling (traversal characters, overwriting), size/zip handling (zip-slip concept, decompression bombs — concept only, never deploy a bomb on a live target), malware scanning presence, and who can download the file afterwards (authz on download = IDOR with files). Download checks: path traversal via ../ in your own file paths, signed-URL expiry/sharing, range-request quirks. Proof with harmless test files (a text file with a unique marker) that you uploaded yourself.

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
