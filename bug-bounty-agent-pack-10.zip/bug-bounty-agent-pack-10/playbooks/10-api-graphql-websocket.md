# Playbook: API, GraphQL & WebSocket Security

REST: authz per object (BOLA, playbook 03), mass assignment, verb tampering, version drift (v1 lacks a check v2 has), pagination/export bulk leaks, error verbosity. GraphQL concepts: introspection enabled (posture note unless it leaks real schema-sensitive ops), nested/batched queries bypassing per-object authz, field-level authz gaps (one field on a type is sensitive), query depth/cost (DoS-adjacent: concept only, no exhaustion testing). WebSocket: is the handshake authenticated? Are per-message authorisations checked, or only at connect time? Cross-site websocket hijacking concept. Method: replay with A/B tokens using the pack's http_probe for single logged requests; document the exact missing check.

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
