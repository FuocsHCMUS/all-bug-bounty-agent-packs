# Playbook: Cloud, SaaS & Configuration Exposure

In-scope only, and mostly passive/observation: publicly exposed storage (only if the asset is in scope and access is via its public URL — do not brute-force bucket names of third parties), verbose error/debug pages, exposed .git/.env (check only on in-scope hosts with a single gentle request, Tier B; if found, do NOT download secrets beyond the first lines needed to prove exposure — stop and report), default credentials on in-scope test instances (only if program allows), subdomain takeover concepts (dangling CNAME to a service you can claim — proof is the DNS record + provider documentation, claim only with Joshua + program approval), security headers/TLS as posture notes (headers_check script).

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
