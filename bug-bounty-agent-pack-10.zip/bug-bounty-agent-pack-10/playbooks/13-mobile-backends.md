# Playbook: Mobile App Backends

The app is a client; the API is the target (and must be in scope — many programs scope the API via the app, verify in intake). Concepts: certificate pinning (what it does/doesn't protect), secrets embedded in the app package (publicly downloadable = public; note as exposure if a live key works — validate minimally, Tier B), the API often trusts mobile-only fields/headers, deep links exporting data, and local storage of tokens. Method: treat it as playbook 10 with A/B accounts; add checks for older API versions still accepted by the server.

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
