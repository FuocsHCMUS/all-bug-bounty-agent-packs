# Playbook: AI / LLM Application Features

For in-scope AI features (chatbots, summarizers, RAG over documents, agents with tools): concepts — prompt injection (user text treated as instructions), indirect injection (a document/webpage the AI reads carries instructions), excessive agency (the AI can call tools/send email/query DB with weak confirmation), data leakage (system prompt, other users' documents in RAG, training/memoised data), and output handling (AI output rendered as HTML/SQL without sanitisation = second-order XSS/injection). Safe method: your own accounts/documents only; a unique marker document proving cross-account retrieval is the clean proof. Never exfiltrate real user content the model surfaces — stop at the first marker, redact, report. Fix lens: least-privilege tools, human confirmation for actions, per-user retrieval filtering, treat model output as untrusted input.

## Beginner root (read first)
Re-read `docs/01-foundations-from-zero.md` and climb the Tutor Ladder for any term here you cannot explain at L1. If you cannot explain it, lab it first — do not test it live.

## Exit criteria
Either (a) a validated finding drafted in template 03, or (b) a logged negative result: what you tested, with which accounts, and why you believe the control holds — that negative is posture evidence.
