# OAuth / OIDC / SSO / Passkeys (new in 16)
Redirect URI parsing differentials, state/nonce binding, PKCE downgrade, account-linking confusion (pre-account-takeover via SSO email trust), tenant confusion in multi-tenant IdPs, passkey/WebAuthn: origin binding, challenge reuse, downgrade to password reset. Test only with your own accounts in both IdP and RP; log every parameter diff.
