# Chaining at Scale (new in 16)
Maintain primitives inventory per target. Weekly: try every pair (leak × trust, low-priv write × privileged read, self-XSS × admin bot/CSRF). Score chains by final impact and number of independent assumptions broken. A chain report proves each link in order, from a clean account.
