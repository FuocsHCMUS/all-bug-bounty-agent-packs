# RESEARCH_SOURCES.md — Trusted Sources (use primary sources first)

Always record: source name, URL, date accessed, and whether a claim is [Observed] there
or your [Inference]. Prefer vendor/official > platform > reputable researcher > aggregator.

## Bug bounty platforms & program info
- HackerOne — https://hackerone.com/directory/programs ; Hacktivity (disclosed reports)
- Bugcrowd — https://bugcrowd.com/programs ; Crowdstream (disclosed activity)
- Intigriti — https://www.intigriti.com/programs
- YesWeHack — https://yeswehack.com/programs
- Synack (vetted researchers), Cobalt, HackerOne/Bugcrowd VDPs, company `security.txt`
  (RFC 9116, usually `/.well-known/security.txt`) and `/security` pages
- Disclosure policy aggregator: https://disclose.io (safe-harbor language reference)

## CVE / vulnerability intelligence
- NVD — https://nvd.nist.gov/vuln/search (API 2.0 used by `scripts/cve_lookup.py`)
- CVE.org — https://www.cve.org/CVERecord
- CISA KEV (Known Exploited Vulnerabilities) — https://www.cisa.gov/known-exploited-vulnerabilities-catalog
- FIRST EPSS — https://www.first.org/epss/ (exploit probability scoring)
- GitHub Advisory Database / GHSA — https://github.com/advisories
- Vendor advisories & release notes (always the ground truth for "is it patched / backported?")
- OSV — https://osv.dev (open-source vulns, good API)
- Exploit-DB — https://www.exploit-db.com (read to understand; running PoCs follows AGENTS.md §7 approval)

## Methodology & learning (free, high quality)
- PortSwigger Web Security Academy — https://portswigger.net/web-security (labs included)
- OWASP WSTG — https://owasp.org/www-project-web-security-testing-guide/
- OWASP ASVS, API Security Top 10, Cheat Sheet Series — https://cheatsheetseries.owasp.org/
- HackTricks — https://book.hacktricks.xyz/
- PayloadsAllTheThings — https://github.com/swisskyrepo/PayloadsAllTheThings
- MITRE ATT&CK (adversary behavior / detection mapping) — https://attack.mitre.org/
- CWE database (root-cause classification for reports) — https://cwe.mitre.org/

## Writeups, disclosed reports, CTFs
- HackerOne disclosed reports (search Hacktivity by program/vuln type)
- Bugcrowd Crowdstream + researcher blogs (verify claims against your own validation)
- CTFtime — https://ctftime.org/writeups ; team writeup blogs
- Conference talks: DEF CON / Black Hat / OWASP AppSec / BSides (slides + code repos)
- Note: a writeup proves a technique worked *somewhere, once*. Your job is to extract the
  transferable principle (technique card, AGENTS.md §3.3) and re-validate safely in scope.

## News / fresh intel (verify before trusting)
- Vendor blogs, GitHub release feeds for the target's stack, CISA alerts,
  BleepingComputer / The Record (journalism — trace back to the primary advisory)

## Source hygiene rules
1. Never trust a version banner alone — check the vendor advisory + behavior.
2. Never copy a payload from a writeup into a production target without understanding
   every part of it and getting approval per AGENTS.md §7.
3. If two sources conflict, the vendor + your own safe observation win; note the conflict.
