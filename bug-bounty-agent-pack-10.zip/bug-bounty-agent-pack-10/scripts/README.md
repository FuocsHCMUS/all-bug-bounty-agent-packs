# Scripts — stdlib-only, Python 3.14 / Windows 11
- `scope_guard.py` — offline check: is a host/URL inside a scope JSON? Run before any active test.
- `headers_check.py` — check security headers (dry-run by default where shipped that way; read --help).
- `http_probe.py` — minimal probe, dry-run by default.
- `cve_lookup.py` — query NVD for a CVE ID / keyword (network to NVD only, not to a target).
- `make_hunt.py` — scaffold a hunt folder from templates.
- `inventory.py` — build an asset inventory from a subdomain list (offline).
All: `python <script>.py --help` first. Tier rules in AGENTS.md §3 apply: target traffic = Tier B (ask Joshua).
