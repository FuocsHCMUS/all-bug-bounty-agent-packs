#!/usr/bin/env python3
"""
cve_lookup.py — Query the NVD API (v2) for a CVE ID or keyword and print a
summary formatted for the pack's CVE Match Sheet (templates/07).

Pure standard library. Touches ONLY nvd.nist.gov — never a target.
An NVD API key is optional (raises rate limits); set env var NVD_API_KEY.

Usage:
    py -3.14 cve_lookup.py CVE-2024-12345
    py -3.14 cve_lookup.py --keyword "apache http server" --limit 5
"""
from __future__ import annotations
import argparse, json, os, sys, urllib.parse, urllib.request

BASE = "https://services.nvd.nist.gov/rest/json/cves/2.0"

def fetch(params: dict) -> dict:
    url = f"{BASE}?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(url, headers={"User-Agent": "bug-bounty-pack-15/cve_lookup"})
    key = os.environ.get("NVD_API_KEY")
    if key:
        req.add_header("apiKey", key)
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))

def summarise(vuln: dict) -> str:
    cve = vuln.get("cve", {})
    cid = cve.get("id", "?")
    descs = [d["value"] for d in cve.get("descriptions", []) if d.get("lang") == "en"]
    metrics = cve.get("metrics", {})
    score = "n/a"
    for k in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        if metrics.get(k):
            score = str(metrics[k][0].get("cvssData", {}).get("baseScore", "n/a"))
            break
    refs = [r["url"] for r in cve.get("references", [])][:5]
    lines = [f"## {cid}  (CVSS base: {score})", (descs[0] if descs else "No EN description."), "References:"]
    lines += [f"  - {u}" for u in refs] or ["  - (none)"]
    lines.append("-> Paste into templates/07-cve-match.md; verify affected versions against the VENDOR advisory.")
    return "\n".join(lines)

def main() -> int:
    ap = argparse.ArgumentParser(description="Look up CVEs on NVD (read-only, never touches a target).")
    ap.add_argument("cve_id", nargs="?", help="e.g. CVE-2024-12345")
    ap.add_argument("--keyword", help="Keyword search instead of a CVE ID")
    ap.add_argument("--limit", type=int, default=5, help="Max results for keyword search (default 5)")
    args = ap.parse_args()
    if not args.cve_id and not args.keyword:
        ap.error("give a CVE ID or --keyword")
    params = {"cveId": args.cve_id.upper()} if args.cve_id else {"keywordSearch": args.keyword, "resultsPerPage": args.limit}
    try:
        data = fetch(params)
    except Exception as e:  # network / API errors are reported, not hidden
        print(f"ERROR querying NVD: {e}", file=sys.stderr)
        return 1
    vulns = data.get("vulnerabilities", [])
    if not vulns:
        print("No results. A CVE with no NVD entry yet is possible — check vendor advisories and GHSA.")
        return 0
    print("\n\n".join(summarise(v) for v in vulns))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
