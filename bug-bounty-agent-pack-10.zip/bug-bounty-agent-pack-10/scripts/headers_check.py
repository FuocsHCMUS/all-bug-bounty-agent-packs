#!/usr/bin/env python3
"""headers_check.py — Pack 10. Check security headers + cookie flags for ONE URL.
DRY-RUN by default (prints what it would do). Add --live to actually fetch (Tier B: this is target traffic).
Usage: py scripts/headers_check.py --url https://example.com [--live]
Stdlib only."""
import argparse, sys, urllib.request, urllib.error

WANT = ["strict-transport-security","content-security-policy","x-content-type-options","x-frame-options","referrer-policy","permissions-policy"]
def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument("--url", required=True); ap.add_argument("--live", action="store_true")
    a = ap.parse_args()
    if not a.live:
        print(f"DRY-RUN: would send ONE GET to {a.url} and inspect headers/cookies. Re-run with --live (Tier-B approval) to fetch.")
        return 0
    req = urllib.request.Request(a.url, headers={"User-Agent": "Pack10-HeadersCheck/1.0 (authorized research)"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            headers = {k.lower(): v for k, v in r.headers.items()}
            print(f"Status: {r.status}  Final URL: {r.geturl()}")
            for h in WANT:
                print(f"{h}: {'PRESENT - ' + headers[h][:120] if h in headers else 'MISSING (posture note, not a finding by itself)'}")
            for raw in r.headers.get_all("Set-Cookie") or []:
                flags = [f for f in ("Secure","HttpOnly","SameSite") if f.lower() in raw.lower()]
                print(f"Set-Cookie flags: {flags} :: {raw.split(';')[0][:60]}...")
    except urllib.error.URLError as e:
        print(f"ERROR fetching: {e}"); return 1
    return 0
if __name__ == "__main__":
    sys.exit(main())
