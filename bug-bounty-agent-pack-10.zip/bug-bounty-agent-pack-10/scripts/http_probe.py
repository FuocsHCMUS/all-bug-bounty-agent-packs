#!/usr/bin/env python3
"""http_probe.py — Pack 10. ONE gentle GET request, fully logged. DRY-RUN by default.
Usage: py scripts/http_probe.py --url https://app.example.com/api/me --token-env TEST_TOKEN [--live]
Use for single, hypothesis-driven checks (playbook 10). Not a scanner/fuzzer. Stdlib only."""
import argparse, os, sys, urllib.request, urllib.error, datetime
def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument("--url", required=True)
    ap.add_argument("--token-env", default=""); ap.add_argument("--live", action="store_true")
    a = ap.parse_args()
    if not a.live:
        print(f"DRY-RUN: would send ONE GET to {a.url} (auth header {'from env '+a.token_env if a.token_env else 'none'}). --live needs Tier-B approval + scope_guard pass.")
        return 0
    headers = {"User-Agent": "Pack10-HttpProbe/1.0 (authorized research)"}
    if a.token_env:
        tok = os.environ.get(a.token_env, "")
        if not tok: print(f"ERROR: env var {a.token_env} is empty/unset"); return 3
        headers["Authorization"] = f"Bearer {tok}"
    req = urllib.request.Request(a.url, headers=headers)
    print(f"# {datetime.datetime.now(datetime.timezone.utc).isoformat()} GET {a.url}")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            body = r.read(4096).decode("utf-8", "replace")
            print(f"Status: {r.status}\nHeaders: {dict(r.headers)}\nBody (first 4KB, REDACT before sharing):\n{body}")
    except urllib.error.HTTPError as e:
        print(f"Status: {e.code}\nBody: {e.read(2048).decode('utf-8','replace')}")
    except urllib.error.URLError as e:
        print(f"ERROR: {e}"); return 1
    return 0
if __name__ == "__main__":
    sys.exit(main())
