#!/usr/bin/env python3
"""inventory_from_subdomains.py — Build an inventory.md table from a subdomain list.

Reads one hostname per line (as produced by CT-log research, e.g. crt.sh),
optionally checks each against scope.yaml via scope_guard's logic, and prints
a Markdown table ready to paste into inventory.md. Discovery != authorization:
rows are marked IN SCOPE / OUT / UNKNOWN so nothing gets tested by accident.
"""
from __future__ import annotations
import argparse, sys
from scope_guard import load_scope, match, host_of

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("subdomain_file")
    ap.add_argument("--scope", help="scope.yaml to check against")
    args = ap.parse_args()
    hosts = sorted({host_of(l) for l in open(args.subdomain_file, encoding="utf-8") if l.strip()})
    in_s, out_s = ([], [])
    if args.scope:
        in_s, out_s = load_scope(args.scope)
    print("| Asset | Type | In scope? | Auth model | Roles | Main objects | Tech signals | Notes |")
    print("|---|---|---|---|---|---|---|---|")
    for h in hosts:
        status = "UNVERIFIED — DO NOT TEST"
        if args.scope:
            if any(match(h, p) for p in out_s): status = "OUT"
            elif any(match(h, p) for p in in_s): status = "YES (cite scope)"
        print(f"| {h} | web/api? | {status} | | | | | |")
    print(f"\n<!-- {len(hosts)} assets listed. Verify each in Scope Guard before any testing. -->")
    return 0

if __name__ == "__main__":
    sys.exit(main())
