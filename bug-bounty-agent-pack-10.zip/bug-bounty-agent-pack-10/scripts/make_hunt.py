#!/usr/bin/env python3
"""make_hunt.py — scaffold a hunt folder for pack 16 (stdlib only).
Usage: python make_hunt.py --name acme --out ./hunts
Copies pack templates 00 (scope intake), 02 (threat model), 05 (hypothesis ledger),
11 (hunt notes) into hunts/<name>/ with the hunt name prepended to the title line.
"""
from __future__ import annotations
import argparse, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
TEMPLATES = ["00-scope-intake.md","02-threat-model.md","05-hypothesis-ledger.md","11-hunt-notes.md"]
def main() -> int:
    ap = argparse.ArgumentParser(description="Scaffold a pack-16 hunt folder")
    ap.add_argument("--name", required=True, help="hunt/program slug, e.g. acme")
    ap.add_argument("--out", default="hunts", help="parent folder (default: hunts)")
    args = ap.parse_args()
    target = pathlib.Path(args.out) / args.name
    target.mkdir(parents=True, exist_ok=True)
    for t in TEMPLATES:
        src = ROOT / "templates" / t
        if not src.exists():
            print(f"missing template: {src}", file=sys.stderr); return 1
        (target / t).write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    (target / "README.md").write_text(f"# Hunt: {args.name}\n\nStart with 00-scope-intake.md, then 02-threat-model.md. No active testing before scope_guard passes.\n", encoding="utf-8")
    print(f"Created {target} with {len(TEMPLATES)+1} files")
    return 0
if __name__ == "__main__":
    sys.exit(main())
