#!/usr/bin/env python3
"""scope_guard.py — Check hosts/URLs against a pack scope.yaml.

Usage:
    py scope_guard.py --scope scope.yaml --check https://api.example.com/path
    py scope_guard.py --scope scope.yaml --check app.example.com other.example.org

Exit codes: 0 = all in scope, 2 = any out-of-scope/unknown, 1 = usage/file error.
Stdlib-first; uses PyYAML if available, else a small fallback parser that
understands the pack's scope.yaml template shape (in_scope/out_of_scope asset lists).
"""
from __future__ import annotations
import argparse, re, sys
from urllib.parse import urlparse

def host_of(value: str) -> str:
    v = value.strip()
    if "://" in v:
        return (urlparse(v).hostname or "").lower()
    return v.split("/")[0].split(":")[0].lower().strip(".")

def load_scope(path: str) -> tuple[list[str], list[str]]:
    text = open(path, encoding="utf-8").read()
    try:
        import yaml  # type: ignore
        data = yaml.safe_load(text) or {}
        def assets(section):
            out = []
            for item in data.get(section) or []:
                if isinstance(item, dict) and item.get("asset"):
                    out.append(host_of(str(item["asset"])))
                elif isinstance(item, str):
                    out.append(host_of(item))
            return [a for a in out if a]
        return assets("in_scope"), assets("out_of_scope")
    except ImportError:
        pass
    # Fallback: scan the two sections for "- asset:" lines.
    in_s, out_s, current = [], [], None
    for line in text.splitlines():
        if re.match(r"^in_scope\s*:", line): current = in_s; continue
        if re.match(r"^out_of_scope\s*:", line): current = out_s; continue
        if re.match(r"^[a-z_]+\s*:", line): current = None
        m = re.search(r"-\s*asset:\s*[\"']?([^\s\"'#]+)", line)
        if m and current is not None:
            current.append(host_of(m.group(1)))
    return in_s, out_s

def match(host: str, pattern: str) -> bool:
    if pattern.startswith("*."):
        base = pattern[2:]
        return host == base or host.endswith("." + base)
    return host == pattern

def main() -> int:
    ap = argparse.ArgumentParser(description="Validate hosts against bug bounty scope.yaml")
    ap.add_argument("--scope", required=True)
    ap.add_argument("--check", nargs="+", required=True)
    args = ap.parse_args()
    try:
        in_scope, out_scope = load_scope(args.scope)
    except OSError as e:
        print(f"ERROR: cannot read scope file: {e}"); return 1
    if not in_scope:
        print("ERROR: no in_scope assets parsed — refusing to pass anything."); return 1
    worst = 0
    for raw in args.check:
        h = host_of(raw)
        if any(match(h, p) for p in out_scope):
            print(f"OUT-OF-SCOPE (explicit)  {h}"); worst = 2
        elif any(match(h, p) for p in in_scope):
            print(f"IN SCOPE                 {h}")
        else:
            print(f"UNKNOWN — TREAT AS OUT   {h}"); worst = 2
    return worst

if __name__ == "__main__":
    sys.exit(main())
