# Scope Intake (GATE — complete before any testing)
Program: | Platform/URL of policy: | Date checked (local+UTC):
Safe-harbour wording (quote):
## In scope (exact)
- 
## Out of scope (exact)
- 
## Allowed techniques / Forbidden techniques
- Allowed: | Forbidden:
## Rate limits / automation rules
## Test account rules
## Disclosure & communication rules
## Ambiguities (and Joshua's decision on each)
- 
Verdict: [ ] CLEARED for passive research  [ ] CLEARED for Tier-B active testing request  [ ] BLOCKED — reason:
