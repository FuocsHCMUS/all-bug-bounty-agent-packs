# Template 01 — Target Dossier: <program / asset>

## What this product is (2–3 lines, own words)
## Company & context (funding/product news only if it changes risk/effort)

## Asset inventory
| Host/app | Purpose | In scope? | Tech/fingerprints (evidence) | Auth model |
|---|---|---|---|---|

## Identity & roles matrix
| Role | How obtained | Can do (observed) | Owns (object types) |
|---|---|---|---|
Test accounts: A = / B = (credentials location: operator's password manager — never in this file)

## Surface map per key asset
- Endpoints & params: / State-changing actions:
- Uploads / imports / exports: / Webhooks & integrations:
- Payments / credits / quotas: / PII & sensitive data types:

## Invariants worth testing (numbered — hypotheses link here)
1. "The server must always …"

## Fingerprints for CVE matching (→ playbooks/06)
| Component | Observed version | How observed | Confidence |
|---|---|---|---|

## History
Disclosed bugs for this program (class + link): / Known issues list checked on:
