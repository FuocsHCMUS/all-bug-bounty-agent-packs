# Threat Model — <feature>
## Assets (data, money, functions worth protecting)
## Actors (anon, user, premium, admin, support, API client, webhook, cron, AI agent)
## Trust boundaries (draw/list where untrusted becomes trusted)
## Flows (step-by-step normal use, both accounts)
## Assumptions the app appears to make
1.
## Attacker questions (what if...?) -> hypothesis card IDs
## Surfaces -> playbook numbers
