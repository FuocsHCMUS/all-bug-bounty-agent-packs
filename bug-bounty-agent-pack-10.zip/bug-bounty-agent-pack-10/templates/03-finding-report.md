# Finding Report (draft for Joshua — Joshua submits)
Title: <component> — <vuln class> allows <impact>
Program / Asset: | Date (local+UTC): | Reporter accounts: A/B (own test accounts)
## Summary (3 sentences)
## Severity — CVSS vector + one-line justification + honest impact statement
## Preconditions
## Steps to reproduce (numbered, exact)
1.
## Evidence (file names in this folder; redacted)
## Proven impact (what you actually demonstrated)
## What was NOT tested, and why
## Duplicate risk assessment
## Suggested remediation (root cause)
## Timeline of testing (timestamps)
