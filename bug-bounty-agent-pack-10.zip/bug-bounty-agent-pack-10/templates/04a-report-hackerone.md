# [Title: asset + vuln class + impact in one line]

## Summary

## Severity / CVSS
Vector: | Reasoning per metric:

## Steps to Reproduce
1. Create / use test Account A (owner) and Account B (other test user).
2. ...

## Evidence
Attachments (redacted): screenshots / request-response excerpts with timestamps.

## Impact

## Remediation
Root cause fix: | Defense in depth:

## Scope & Cleanup Note
Testing stayed within the <Program> scope using only my own test accounts. Test data created: … Deleted: …

## Supporting Material / References
OWASP / CWE links:
