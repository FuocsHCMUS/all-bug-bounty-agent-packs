# [Title: asset + vuln class + impact in one line]

## VRT Category (Bugcrowd Vulnerability Rating Taxonomy)
Category: | Proposed priority + reasoning:

## Summary

## Steps to Reproduce
1. Test Account A (owner) / Account B (other test user) setup: …
2. ...

## Evidence (redacted attachments)

## Impact (business terms, proven scale only)

## Remediation
Root cause fix: | Defense in depth:

## Scope & Cleanup Note
In-scope asset per program brief; own accounts only; test data created/deleted: …
