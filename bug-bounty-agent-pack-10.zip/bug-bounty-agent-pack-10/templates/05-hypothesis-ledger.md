# Hypothesis Card #<id>
Idea (one sentence):
Assumption I think is broken:
Preconditions:
Smallest safe test:
Expected signal if TRUE: | Expected signal if FALSE:
Stop condition:
Tier needed: A / B (Joshua approval date:)
Result: Confirmed / Likely / Ruled-out — evidence:

## Pack 16 ledger fields (add as a table)
| # | Assumption attacked | Primitive sought | Cheapest test | Kill criterion | Chain potential (links to #) | Status |
