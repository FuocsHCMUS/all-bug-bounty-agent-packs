# Posture Analysis + Learning Notes — <program / hunt>
## A. Security posture
### Doing well (control, evidence, why it works)
### Needs improvement (gap, evidence, risk if unaddressed)
### Systemic patterns / high-risk areas
### SOC / detection lens (telemetry present or likely missing; one concept-level detection idea; what log you'd want)
## B. Tutor notes (per concept, climb L0->L3)
### Concept: <name>
L0 analogy: | L1 mechanism: | L2 why it breaks: | L3 pro test / fix / monitor:
Networking root: | Mini-glossary additions:
Safe lab to practise (local/CTF/Academy):
Self-check Q&A (3 questions, answers below divider)
---
Answers:
## C. Skill map update (Cyber/Pentest/SOC skills exercised; next to learn)
