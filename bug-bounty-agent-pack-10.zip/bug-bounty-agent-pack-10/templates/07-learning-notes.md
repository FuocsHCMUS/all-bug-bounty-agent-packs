# Learning Note — <Concept / Finding> — <YYYY-MM-DD>
Skill-tree tags: [ ] Networking [ ] HTTP [ ] AuthN [ ] AuthZ [ ] API [ ] Injection [ ] XSS [ ] SSRF [ ] Business Logic [ ] CVE Literacy [ ] SOC Detection [ ] Reporting

## 1. Everyday analogy
## 2. Root concept (define every term)
## 3. How it normally works (step by step)
## 4. Where trust broke
## 5. Vulnerability walk-through (own test accounts only)
## 6. Why it matters (impact)
## 7. Defender / SOC lens (logs, alerts, analyst questions)
## 8. The fix (root + defense in depth)
## 9. Safe practice (PortSwigger topic / local lab / CTF category)
## 10. Next concept this unlocks

---
## Check questions (try before scrolling)
1.
2.
3.

## Answers (spoiler — read only after trying)
1.
2.
3.
## My confidence after this note (1–5) + what still confuses me:
