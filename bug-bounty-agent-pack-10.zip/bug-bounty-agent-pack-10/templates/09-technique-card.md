# Technique Card — <name>
Source (URL, author, date read):
Problem class: | Broken assumption:
Preconditions (link graph: needs ... / enables ...):
The idea in my own words (L1):
Detection signal when testing:
Variants to think about (not copy):
Fix (root cause): | SOC detection idea:
Lab where I practised it:
