# Chain Canvas
Primitive A (proved):
Primitive B:
Missing link:
Combined impact if linked:
Cheapest link test:
Kill criterion:
