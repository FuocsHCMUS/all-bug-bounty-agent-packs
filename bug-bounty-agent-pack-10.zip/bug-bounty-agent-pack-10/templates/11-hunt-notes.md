# Hunt Notes — <program> <date>
Session goal:
Log (timestamped, local+UTC):
- 
Negatives (tested, held up):
Open hypotheses:
Next session:
