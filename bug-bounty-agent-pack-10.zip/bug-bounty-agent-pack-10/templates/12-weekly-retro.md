# Weekly Retro
Hunts done: | Findings: | Best negative result:
New technique cards: | CVEs checked (applicable / not):
Scope or safety mistakes (honest):
Concepts I can now explain at L3:
Next week's learning target (from learning/curriculum.md):
