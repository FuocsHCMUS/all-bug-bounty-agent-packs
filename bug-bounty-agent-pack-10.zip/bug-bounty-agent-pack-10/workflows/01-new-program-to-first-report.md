# Workflow 01 — New Program to First Report
1. Intake (template 01) + scope_guard setup. [Gate: no intake, no testing]
2. Program intel (doc 02): disclosed reports, updates, stack.
3. Passive recon -> surface map. Pick ONE feature with a threat model (template 02).
4. Hypothesis cards (2-5). Choose playbooks.
5. Tier-B request to Joshua for active testing on that feature. Test, log, validate.
6. Finding? -> template 03 draft -> Joshua reviews -> Joshua submits.
7. Always: template 04 posture + learning notes, skill-map update, retro (what to hunt next session).
