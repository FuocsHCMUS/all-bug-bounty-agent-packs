# Workflow 03 — Writeup / CTF Mining Session (60-90 min, no target traffic)
1. Pick 3 sources (1 disclosed report, 1 research writeup, 1 CTF writeup) on one theme.
2. For each: technique card (template 07) in your own words, L0-L2 climbed.
3. Link cards into the technique graph by shared preconditions.
4. Generate 1-3 hypothesis cards for programs you hunt (to be checked against scope later — mining itself authorises nothing).
5. Add one lab task to your practice list to internalise the technique safely.
