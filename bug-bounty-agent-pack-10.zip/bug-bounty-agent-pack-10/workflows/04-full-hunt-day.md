# Workflow 04 — A Full Hunt Day (template schedule)
- 30 min: scope re-check, program updates, pick the day's ONE feature + threat model.
- 60 min: manual exploration as a normal user (both test accounts), notes on assumptions.
- 90 min: hypothesis testing (playbooks), logging as you go.
- 30 min: validation / chain check.
- 45 min: write-up (finding or negatives) + posture & learning notes.
- 15 min: retro + tomorrow's hypotheses. Stop while it's still fun and careful — tired hunting makes scope mistakes.
