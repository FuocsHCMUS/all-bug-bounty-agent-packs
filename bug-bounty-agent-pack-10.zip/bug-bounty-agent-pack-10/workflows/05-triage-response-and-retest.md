# Workflow 05 — After Joshua Submits: Triage, Duplicates, Retest
- If triage asks for info: draft the reply for Joshua (extra evidence, clearer repro) — Joshua sends it.
- If duplicate: study the original (if disclosed later), add a technique-card lesson, no hard feelings — log what signal you missed in program intel.
- If fixed: with Joshua's approval and program permission, retest the exact repro + one variant, confirm the fix, draft the retest note for Joshua.
- If out-of-scope/informative: extract the scope-reading lesson into your notes so the same misread never repeats.
