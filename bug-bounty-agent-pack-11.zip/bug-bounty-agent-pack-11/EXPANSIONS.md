# Expansions Beyond the Original Brief
(Joshua asked to be told what was added — here it is.)

1. **Hypothesis Ledger as a mandatory Phase-2 artefact** — systematised
   from pack 15's backlog + pack 10's hypothesis card; creativity becomes
   a trackable queue, not a mood.
2. **Invent-then-kill workflow** (`workflows/06`) — formalises "generate
   wild, then falsify" so creative time produces validated findings.
3. **Chain sprint + chain canvas** — chaining promoted from a paragraph
   (packs 10/14) to a workflow + template + playbook 17.
4. **CVE diffing** (from pack 16, expanded) — patch-reading as a variant-
   hunting technique, not just version matching.
5. **OAuth/OIDC/SSO/passkeys, deserialisation/prototype-pollution/supply-
   chain, and client-side/browser playbooks** — surfaces the source packs
   touched only inside other playbooks, now standalone (15–16, 07).
6. **SOC Mirror role + posture false-positive analysis** — every posture
   claim must state what a defender would actually see/log.
7. **Spaced-repetition learning cards** (`scripts/learning_card.py`,
   Day 1/3/7/21) — so findings compound into skill, per Joshua's goal.
8. **State tracker** (`scripts/state.py`) — findings survive across
   sessions and tools instead of living in chat history.
9. **One lean gate** — see MERGE-NOTES: guardrail *consolidation* as a
   feature that frees attention for offensive thinking.
