# Merge Notes — What Pack 17 Took From Each Source Pack

Verified against the actual zip inventories of packs 10–16 (10: 78 files,
11: 38, 12: 60, 13: 64, 14: 72, 15: 71, 16: 64).

| Source | Best ideas kept in Pack 17 |
|---|---|
| **10** | Program-intel & duplicate avoidance; research engine; creative R&D lab; severity/impact honesty; evidence & OPSEC hygiene; race/API/GraphQL/cloud/mobile/AI playbook set; worked fictional example; `scope_guard` + dry-run `http_probe` pattern |
| **11** | Flat, plain-language docs; company security assessment as a first-class output; student learning-note format; creative-exploitation essay (folded into `docs/05`) |
| **12** | Multi-agent role prompts (orchestrator/recon/CVE/web/validator/mentor → `prompts/` + AGENTS §8); OWASP-WSTG-flavoured checklists; foundations + glossary learning set |
| **13** | Knowledge-base structure (threat modeling, CVE workflow, writeup mining); SOC/blue-team lens; skill tree; `tech_fingerprint` + hunt initialiser; per-target checklists |
| **14** | Per-class checklists (web/API/auth/business-logic); platform report templates (HackerOne, Bugcrowd, generic VDP); portable-first tool catalog + permission model; posture-analysis doc; CVE→validation and writeup-ingestion workflow loops |
| **15** | Core persona/mission + 3-tier approval protocol; hypothesis backlog; fictional end-to-end finding; teach-back workflow; trusted-sources reference |
| **16 (original)** | Prompt chain 00→08 (orchestrator→debrief); `engagement/scope/tool-policy` configs as YAML; knowledge series (HTTP, DNS/TLS, authn/authz, CVE/CVSS/CWE); CVE diffing; CVSS calculator; findings state tracker; 12-week curriculum + lab targets |

## Deliberately dropped / consolidated
- **All duplicate safety chapters** (packs 11/12/13/14/15/16 each carried
  1–3) → consolidated into AGENTS §1–§2 + `docs/02`. Nothing the *programs*
  require was removed; the repetition was.
- `CLAUDE.md` shims (packs 10/12/15) → dropped. Claude Code reads
  `AGENTS.md` natively now, per Joshua's own note.
- Duplicate scripts with the same job under different names
  (`scope_check`/`scope_checker`/`scope_guard`, three header checkers) →
  one canonical version each in `scripts/`.
- Pack 11's flat all-caps docs → their content, in the standard structure.

## On Joshua's "remove the guardrails" request — read this
Pack 17 does **not** strip the programs' Rules of Engagement, and no prompt
can: HackerOne/Bugcrowd enforce scope, own-data and no-disruption rules
themselves — violating them means bans, unpaid/invalid reports and real
legal exposure for testing computers you were *not* authorised to test
(the authorisation is literally the scope list). What Pack 17 *does* remove
is everything else: the duplicated moralising, the repeated warnings in
every file, the defensive hedging. Inside scope, §5 makes creative
offensive thinking the default operating mode. That is the maximum real
freedom a hunter actually has — and it is not small.
