# Bug Bounty Agent Pack 17 — Merged Edition

The single, canonical pack merged from packs **10, 11, 12, 13, 14, 15 and 16**.
English throughout. Built for a cybersecurity student (Joshua) on **Windows 11,
Python 3.14.x+**, hunting **authorised** bug bounty programs on HackerOne /
Bugcrowd-style platforms, and learning Cyber / Security / Pentest / SOC from
first principles as he goes.

## The one idea behind this merge
Seven packs repeated the same cautions in dozens of places until the caution
*was* the pack. Pack 17 compresses ALL of that into **one lean operational
gate** (`AGENTS.md` §1–§2 + `docs/02`): scope is authorisation, use your own
test accounts, no destructive / availability impact, findings go to Joshua
only. Those four lines are not decoration — they are the programs' own Rules
of Engagement, and they are what makes a report payable instead of bannable.
**Everything inside that gate is deliberately unrestricted**: hypothesis
invention, assumption inversion, parser differentials, chaining, CVE diffing,
writeup/CTF mining, state-machine abuse and second-order thinking are the
*default mode*, not an exception you have to argue for.

## Start here
1. Read `START_HERE.md` (10 minutes).
2. Your tool's adapter: `platforms/` (Claude Code now reads `AGENTS.md`
   natively — there is intentionally **no CLAUDE.md**; Codex, OpenCode,
   Cline, Cursor, Antigravity each get a native adapter that points back to
   the canonical `AGENTS.md`).
3. First hunt: `workflows/01-new-program-to-first-report.md`.
4. Every session runs the prompt chain in `prompts/` (00 orchestrator →
   08 debrief), inherited from pack 16, the strongest sequencing idea in
   the source packs.

## Map
- `AGENTS.md` — canonical instructions. Every adapter defers to it.
- `SKILL.md` — skill-format mirror of the same mission.
- `docs/` — foundations, research engine, creative R&D lab, posture/SOC lens.
- `playbooks/` — 18 attack-surface playbooks.
- `workflows/` — 8 end-to-end loops. `checklists/` — 9 short gates.
- `templates/` — 15 fill-in artefacts (hypothesis ledger is mandatory).
- `learning/` — beginner-first curriculum, glossaries, tutor ladder, labs.
- `prompts/` — 9 role/session prompts (orchestrator + specialists).
- `scripts/` — 11 tested, stdlib-only Python helpers.
- `examples/` — 3 fully fictional worked findings. `references/` — sources.
- `MERGE-NOTES.md` — exactly what was taken from each source pack, and why.
- `EXPANSIONS.md` — ideas added beyond Joshua's original brief.
