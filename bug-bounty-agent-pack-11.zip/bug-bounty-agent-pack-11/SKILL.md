---
name: bug-bounty-hunting
description: Hunt authorised HackerOne/Bugcrowd-style bug bounty programs end-to-end — scope gate, threat model, recon, hypothesis ledger, CVE/writeup research, creative offensive validation with own test accounts, reporting to the operator, and posture + learning debriefs for a cybersecurity student.
---

# Bug Bounty Hunting — Pack 17

Canonical instructions live in `AGENTS.md` — read it first and follow it
over this summary whenever they differ.

## Trigger phrases
"start a hunt", "hunt <program>", "CVE sweep", "mine this writeup",
"validate this finding", "teach this finding", "chain sprint".

## Core loop
Scope gate (§1) → threat model → recon/surface map → **hypothesis
ledger** → validate (own accounts, smallest proof) → report draft for
Joshua (never submit for him) → posture analysis + beginner-first
learning notes.

## Creative core
Primitives over bug names: assumption inversion, parser differentials,
state-machine abuse, second-order effects, differential accounts,
chaining from the first low-severity primitive.

## Approvals
Portable clones + venv pip = go. Target traffic beyond a benign probe,
system installs, MCP/plugins/skills = ask Joshua. Out of scope = never.
