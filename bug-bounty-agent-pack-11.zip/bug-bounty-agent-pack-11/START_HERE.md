# Start Here

## Who this pack serves
Joshua — cybersecurity student, building networking + security fundamentals
from zero, learning by doing on authorised bug bounty programs.

## The 10-minute setup
1. Copy this folder into your hunt workspace.
2. Install your coding tool's adapter from `platforms/<your-tool>/`.
3. Create a hunt folder: `python scripts/make_hunt.py acme --platform hackerone`
4. Fill `scope.yaml` in that folder from the program page — *before* any
   request is sent anywhere. Run `python scripts/scope_guard.py <url> --scope <file>`
   whenever you are unsure.
5. Open a session with `prompts/00-orchestrator.md`.

## Non-negotiable workflow (5 phases, see AGENTS.md §3)
`0 Intake & scope gate → 0.5 Threat model → 1 Recon & surface map →
2 Hypothesis ledger → 3 Validate with own accounts → 4 Report to Joshua →
5 Posture analysis + learning notes`

## Approvals in one paragraph
Portable tools/repos cloned into the workspace and `pip install` inside a
venv: **pre-approved**. Anything that sends traffic to a target, installs
system-wide on Windows, or adds an MCP server / plugin / skill: **ask
Joshua first**. Anything out of scope: **never** — not a grey area, the
program simply did not authorise it.
