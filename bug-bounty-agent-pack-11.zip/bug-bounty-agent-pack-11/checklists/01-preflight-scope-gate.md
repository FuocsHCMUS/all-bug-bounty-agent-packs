# Checklist — Preflight Scope Gate

- [ ] Program page re-read today; scope.yaml matches it
- [ ] Every host/asset to touch passes scope_guard.py
- [ ] Two test accounts ready (A/B), labelled
- [ ] Program's testing rules noted (rate, automation, headers)
- [ ] Tier-2 actions in today's plan have Joshua's OK
