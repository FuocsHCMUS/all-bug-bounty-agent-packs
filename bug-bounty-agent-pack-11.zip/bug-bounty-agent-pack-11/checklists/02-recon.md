# Checklist — Recon

- [ ] Passive sources exhausted before active probing
- [ ] Inventory filed with fingerprint confidence levels
- [ ] Surface map grouped by function (money/identity/data/admin)
- [ ] JS/API/mobile surfaces included
- [ ] New-in-scope / recently changed areas flagged
