# Checklist — Web

- [ ] Authz differential matrix run on main objects
- [ ] One field traced through UI/export/email/admin/API
- [ ] State machine drawn for the main workflow
- [ ] Upload→serve path checked
- [ ] Headers/CSP/CORS observed (headers_check.py)
