# Checklist — Api

- [ ] Every verb checked, not just GET
- [ ] Old versions probed gently (v1/v2 diff)
- [ ] GraphQL: per-resolver authz sampled; batching considered
- [ ] WebSocket subscriptions re-checked after handshake
- [ ] Mobile vs web response diff reviewed
