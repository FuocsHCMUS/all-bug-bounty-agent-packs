# Checklist — Auth And Session

- [ ] Token lifecycle table completed (reset/invite/magic link)
- [ ] Logout & password-change session behaviour observed
- [ ] MFA checked on sensitive changes, not only login
- [ ] Account-linking flows modelled (OAuth playbook)
- [ ] Lockout behaviour noted without stressing it
