# Checklist — Business Logic

- [ ] State machine: skip/replay/reorder/resurrect attempted on own flows
- [ ] Totals/prices verified server-side with own cart
- [ ] Limits tested at boundary (0, -1, max, max+1)
- [ ] Coupon/quota single-use assumptions ledgered
- [ ] Race candidates handed to playbook 05
