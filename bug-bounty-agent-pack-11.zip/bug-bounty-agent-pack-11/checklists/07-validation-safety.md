# Checklist — Validation Safety

- [ ] Proof uses own accounts/data only
- [ ] Smallest proof that demonstrates impact — and stop
- [ ] No real-world side effect triggered
- [ ] Evidence captured with timestamps & account labels
- [ ] Counts/rates minimal; shared resources untouched
