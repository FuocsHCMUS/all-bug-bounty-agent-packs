# Checklist — Pre Submit Report Qa

- [ ] A tired triager can reproduce in ≤5 minutes
- [ ] CVSS matches *demonstrated* impact only
- [ ] Steps use labelled test accounts; secrets redacted
- [ ] Title states asset + class + impact plainly
- [ ] Posture + learning notes attached for Joshua
