# Checklist — Learning Retention

- [ ] Root concept explained at tutor-ladder L1–L3
- [ ] Flashcards created; Day 1/3/7/21 reviews scheduled
- [ ] One lab selected for this concept
- [ ] Technique card filed (if a new primitive appeared)
- [ ] Skill matrix updated honestly
