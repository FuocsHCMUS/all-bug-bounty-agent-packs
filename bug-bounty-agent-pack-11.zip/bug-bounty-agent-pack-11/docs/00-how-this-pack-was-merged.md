# How Pack 17 Was Merged

Read MERGE-NOTES.md for the per-pack table. Method: inventory all 7 zips, keep the strongest version of every duplicated idea, drop shim files (CLAUDE.md) and duplicate scripts, consolidate repeated rule chapters into one gate, then add the expansions in EXPANSIONS.md. When two packs disagreed, the newer pack won on structure (16's prompt chain, 15's approvals) and the richer pack won on content (10's playbooks, 14's templates).
