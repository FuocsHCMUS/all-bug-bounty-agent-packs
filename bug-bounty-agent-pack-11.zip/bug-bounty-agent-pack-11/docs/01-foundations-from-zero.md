# Foundations From Zero

For Joshua, in dependency order — never skip a layer you cannot explain back:

1. **Networks**: IP, ports, DNS (names→addresses), TCP vs UDP, TLS (encrypted, authenticated channel).
2. **HTTP**: request = method + path + headers + body; response = status + headers + body; statelessness and how cookies/sessions fake state.
3. **Web app anatomy**: browser ↔ CDN/proxy ↔ app ↔ API ↔ database; every arrow is a trust boundary.
4. **Identity**: authentication (who are you?) vs authorisation (what may you do?) vs session (how the app remembers).
5. **Data formats**: URLs & encodings, JSON, JWT structure, HTML/JS basics.
6. **Vuln grammar**: a bug = an *assumption* in code that an attacker can make false, with impact. CWE names the weakness, CVE names a specific instance, CVSS scores severity.

Deeper series: `learning/01-networking-from-zero.md`, `learning/02-web-and-http-from-zero.md`.
