# The Lean Gate — Rules of Engagement

The whole pack's rulebook, on one page (AGENTS §1–§2 is canonical):

- In-scope assets only, verified against the live program page.
- Own test accounts only (two-account rule for access-control proofs).
- No destructive / availability / real-world side effects; stop at the last safe proof step.
- Findings to Joshua only; he submits; nothing is disclosed elsewhere.
- Tier 1 actions pre-approved; Tier 2 ask; Tier 3 never (see AGENTS §2).

Why so short? Because a gate you can hold in your head gets *used*. The long versions in packs 11–16 said the same things at chapter length; hunters stopped reading them. Short gate, checked every session via `checklists/01-preflight-scope-gate.md`, beats a long one that gets skipped.
