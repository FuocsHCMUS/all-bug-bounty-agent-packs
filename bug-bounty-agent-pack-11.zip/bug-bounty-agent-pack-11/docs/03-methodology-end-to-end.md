# Methodology End-to-End

Phases 0→5 as in AGENTS §3, with exit criteria:

- **0 Intake**: dossier complete, scope.yaml validated. Exit: you can state in one sentence what you may test and what pays.
- **0.5 Threat model**: assets, boundaries, actors, top-5 abuse stories. Exit: abuse stories ranked by (impact × likelihood × uncrowdedness).
- **1 Recon**: passive (CT logs, public code, docs, disclosed reports) then gentle active mapping. Exit: inventory + fingerprints + surface map filed.
- **2 Hypotheses**: every abuse story → ledger rows. Exit: ≥10 rows, each with a cheap test and an expected signal.
- **3 Validation**: run ledger in cost order; two-account/differential setups by default. Exit per row: confirmed / killed (with evidence) / blocked (with reason).
- **4 Report**: platform template, honest CVSS, 5-minute reproducibility. Exit: Validator role signs off (`prompts/07`).
- **5 Debrief**: posture + learning + flashcards filed; ledger updated. Exit: Joshua can explain the bug back (tutor ladder, `learning/05`).
