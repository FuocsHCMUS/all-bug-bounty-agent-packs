# Creative Offensive R&D Lab

The pack's creative core (merges pack 10's R&D lab, 11's creative-exploitation essay, 13/14's creative docs, 16's technique forge).

**Principles**: primitives over bug names; wild in hypotheses, boring in execution; quantity first (invent-then-kill), judgement second.

**Generators** — run all seven per surface (AGENTS §5): assumption inversion; parser differentials; state-machine abuse; second-order/stored-later execution; differential accounts/roles/tenants; feature-combination collisions (two safe features whose *combination* is unsafe — export+sharing, import+preview, cache+auth); time & race windows.

**Lab discipline**: reproduce a new technique in a local lab (Juice Shop / PortSwigger labs / a 30-line Python mock) *before* spending target requests on it. A technique you cannot reproduce locally is a rumour.

**Technique graph**: link technique cards by shared primitive; when a new card lands, ask which old cards it chains with (playbook 17).
