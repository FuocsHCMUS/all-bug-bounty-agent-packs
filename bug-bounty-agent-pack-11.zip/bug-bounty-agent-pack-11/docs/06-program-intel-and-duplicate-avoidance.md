# Program Intel & Duplicate Avoidance

Duplicates pay $0, so intel is hunting:

- Read the program's disclosed reports and scope history: what class keeps recurring? What area just entered scope (uncrowded) or is about to leave it?
- Note response-time and severity precedents — they calibrate your CVSS honesty (`docs/07`).
- Prefer: new features, recently changed code, acquisitions' subdomains newly in scope, mobile/API surfaces behind the flagship web app, second-order/admin/internal-ish surfaces reachable by normal users.
- Avoid: the homepage login form's most famous bug class in week 1 of a public program — unless your angle is a *variant* (diffing, chaining, parser differential) the crowd's scanners cannot produce.
