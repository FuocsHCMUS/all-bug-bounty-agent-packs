# Severity, CVSS & Impact Honesty

Score what you *proved*, not what you imagine: CVSS 3.1 vector from the demonstrated impact (`scripts/cvss.py`), then adjust the write-up, not the number.

- Confidentiality/Integrity/Availability: only claim the ones demonstrated with your own accounts/data.
- Attack complexity goes *up* (score down) honestly when preconditions are rare — triage notices, and credibility compounds across reports.
- Business impact paragraph: translate technical impact into the company's language (money flow, trust flow, regulated data) without inflating the vector.
- Chains: score the chain's end state; file the primitives separately in the ledger for future chains.
