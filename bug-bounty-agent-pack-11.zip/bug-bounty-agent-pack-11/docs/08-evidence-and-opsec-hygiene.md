# Evidence & OPSEC Hygiene

- Capture as you go: full request/response for the proof step, timestamps, account labels (A/B), before/after states.
- Minimal & yours: redact tokens, and never include another user's real data — if it appears in a response, stop, note the fact, screenshot the smallest redacted proof.
- Reproducibility kit: exact steps, test-account setup, environment notes; a stranger must reproduce in ≤5 minutes.
- File hygiene: one hunt folder per program (`scripts/make_hunt.py`), evidence hashed/listed with `templates/14-evidence-manifest.md`; secrets in a password manager, never in notes.
