# Posture Analysis & SOC Lens

After every finding/near-miss (Joshua's standing request), write `templates/09`:

1. **Doing well** — controls that worked, limited blast radius, or detected/slowed you. Be specific; praise with evidence teaches as much as criticism.
2. **Needs improvement** — the missing check, the inconsistent enforcement, the pattern across findings (one bug is a typo; three siblings are a process gap).
3. **Risk view** — likelihood × impact for a real attacker, stated assumptions, and a **false-positive check**: could this be intended behaviour / a compensating control you cannot see? Say so if yes.
4. **SOC mirror** — what would a defender see? Which logs/telemetry would fire, which would stay silent, what detection rule would catch this class? (Pack 13's blue-team lens, made mandatory.)
5. **Fix sketch** — the smallest correct fix and the regression test that proves it.
