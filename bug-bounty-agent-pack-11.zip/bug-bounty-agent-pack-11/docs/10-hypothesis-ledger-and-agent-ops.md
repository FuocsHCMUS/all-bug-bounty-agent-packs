# Hypothesis Ledger & Autonomous Agent Ops

The ledger (`templates/04`) is the agent's working memory across sessions and tools: id, surface, assumption, inversion, test, cost, signal, status, evidence link.

Rules: no test without a row; no row dies silently (killed rows record *why* — that negative knowledge is what stops re-testing); weekly, mine killed rows for chain components.

Agent ops: keep hunt state in files (`scripts/state.py`, hunt folder), not in chat; at session end, the debrief (`prompts/08`) rewrites the state so *any* tool (Claude Code/Codex/OpenCode/Cline/Cursor/Antigravity) can resume from the same folder.
