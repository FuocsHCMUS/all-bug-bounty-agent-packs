# Disclosure, Retest & Duplicates

- Joshua submits; the agent's job ends at a submittable draft + a retest plan.
- If triage asks for more proof: smallest additional step, same accounts, update evidence manifest.
- Duplicate? Ask (via Joshua) what was distinct in the first report; feed the answer into `docs/06` intel and into your variant strategy.
- Retest after a fix: re-run the original proof, then one *variant* from the same ledger row family — fixes often patch the example, not the class. Log in `templates/15-retest-log.md`.
- Never disclose outside the program, even after closure, without the program's own disclosure process.
