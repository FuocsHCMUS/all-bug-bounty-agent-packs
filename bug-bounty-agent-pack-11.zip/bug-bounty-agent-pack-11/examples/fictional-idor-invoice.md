# Example — Fictional: IDOR on Invoices

Company 'AcmeDocs' is invented. A (user 101) owns invoice 5001; B (user 102) requests `/api/invoices/5001` and receives it: ownership checked on the list page, not the object endpoint. Proof stopped at B reading B's *test counterpart* invoice created for this test. Impact: demonstrated cross-account read of one own object. Fix: central authorisation on object load. Lesson (L2): authorisation is a per-object, per-request check, not a page property. SOC view: alert on sequential object access across owners.

*Fictional end-to-end illustration for learning; formats follow templates/05, 09, 10.*
