# Example — Fictional: Race on Single-Use Coupon

Company 'ShopDemo' is invented, sandbox mode. One coupon, two near-simultaneous redemptions from the same test account both succeeded at count=2 parallel requests — check-then-act was not atomic. Stopped at 2 (no scaling). Fix: atomic decrement / unique constraint. Lesson: a race is a *time* assumption; draw the check→act gap. SOC view: velocity alert on redemption attempts per code.

*Fictional end-to-end illustration for learning; formats follow templates/05, 09, 10.*
