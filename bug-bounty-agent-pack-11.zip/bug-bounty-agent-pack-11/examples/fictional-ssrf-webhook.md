# Example — Fictional: SSRF via Webhook Tester

Company 'Hookly' is invented. Its webhook test fetcher followed a redirect from Joshua's own listener to a second path on the same listener, showing redirect targets are not re-validated. Proof: own listener only; no internal address was scanned. Impact phrased as 'server-side request to an attacker-chosen redirect target (demonstrated externally); internal reachability not tested'. Lesson: validate at fetch time, after redirects, with the fetcher's own parser. That honest scoping is why the fictional report is credible.

*Fictional end-to-end illustration for learning; formats follow templates/05, 09, 10.*
