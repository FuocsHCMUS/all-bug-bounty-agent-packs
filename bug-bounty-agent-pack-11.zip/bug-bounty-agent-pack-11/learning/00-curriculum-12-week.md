# 12-Week Curriculum (from pack 16, extended)

Weeks 1–2 networking & HTTP (`learning/01–02`). 3–4 browser, cookies, authn/authz. 5–6 core web classes via PortSwigger labs. 7 APIs & GraphQL. 8 business logic & races. 9 CVE loop + first real program (read-only recon + ledger only). 10 supervised hunting. 11 chaining + CVE diffing. 12 first reports + posture debriefs. Rule: no week is 'done' until you can teach it back in your own words.
