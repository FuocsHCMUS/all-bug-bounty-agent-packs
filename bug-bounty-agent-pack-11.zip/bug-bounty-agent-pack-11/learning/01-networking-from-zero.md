# Networking From Zero

IP address = location; port = door; DNS = phone book (A/AAAA/CNAME, TTL, why subdomain takeover exists); TCP = reliable conversation (handshake, ordering), UDP = postcards; TLS = identity + encryption (certificates, SNI, why mixed content matters); HTTP rides on top. Lab: `nslookup`, browser devtools Network tab on one page load, list every request and which layer it belongs to.
