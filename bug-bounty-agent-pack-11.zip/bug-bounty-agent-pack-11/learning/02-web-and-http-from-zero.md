# Web & HTTP From Zero

Request/response anatomy; methods & idempotency; status codes as the app's mood; headers that matter (Cookie, Authorization, Content-Type, Origin, Referer); sessions vs tokens vs JWT (structure: header.payload.signature — signed, *not* encrypted); same-origin policy & CORS in one paragraph: the browser's rulebook, not the server's. Lab: replay one request in Burp/curl and change exactly one field at a time.
