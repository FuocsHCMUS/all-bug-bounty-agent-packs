# Skill Tree & Matrix

Rate yourself 0–3 per row monthly: Networking · HTTP · Browser/JS · AuthN/Z · APIs · Logic/Race · Injection concepts · Client-side · Cloud basics · CVE research · Report writing · Detection/SOC. A row moves up only with an artefact: a lab write-up, a technique card, or a finding. The matrix decides next week's study — always the lowest row that blocks a current hunt.
