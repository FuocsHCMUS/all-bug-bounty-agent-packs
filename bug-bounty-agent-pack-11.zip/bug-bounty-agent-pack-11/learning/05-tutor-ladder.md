# Tutor Ladder — How Explanations Work Here

Every explanation climbs: **L1** plain-words story → **L2** the mechanism (packets/requests/code shape) → **L3** why the bug follows from the mechanism → **L4** the fix → **L5** the detection. The agent must not skip levels with Joshua, and must check understanding with one question per finding, not a quiz. If Joshua can teach it back at L3, it is learned; schedule the flashcard (`scripts/learning_card.py`).
