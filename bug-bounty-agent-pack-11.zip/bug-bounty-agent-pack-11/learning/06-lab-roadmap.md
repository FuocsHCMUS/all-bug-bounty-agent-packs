# Safe Lab Roadmap

PortSwigger Web Security Academy (primary) · OWASP Juice Shop (local) · HackTheBox / TryHackMe (guided) · CTFtime archives (technique mining) · a local Python mock you write yourself for one technique per month. Labs are where payloads get loud; real programs get the quiet, minimal version.
