# SOC Lens For Hunters

For each technique card, add: what log line appears, what a SIEM rule would match, what normal traffic it hides inside, and what a defender could alert on without drowning in false positives. Hunting with a SOC lens makes your reports better (impact is credible) and makes Joshua employable on both sides of the wall.
