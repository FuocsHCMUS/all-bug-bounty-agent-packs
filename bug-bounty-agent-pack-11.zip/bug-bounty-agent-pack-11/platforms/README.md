# Platform Adapters

`AGENTS.md` at the pack root is canonical for every tool. Adapters below only *wire* each tool to it — they never fork the rules. No CLAUDE.md is shipped: Claude Code reads AGENTS.md natively.
