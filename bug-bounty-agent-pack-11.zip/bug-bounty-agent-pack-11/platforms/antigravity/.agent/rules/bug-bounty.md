# Pack 17 Rules (Antigravity)

Canonical: pack root `AGENTS.md`. In-scope only · own accounts · no destructive/availability impact · findings to Joshua only · Tier-2 = ask first · hypothesis ledger mandatory · posture + learning notes end every finding.
