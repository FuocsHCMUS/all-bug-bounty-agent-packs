# Workflow — chain-sprint

Run workflows/05 on the current primitives inventory. Inherit AGENTS.md §1–§2 throughout.
