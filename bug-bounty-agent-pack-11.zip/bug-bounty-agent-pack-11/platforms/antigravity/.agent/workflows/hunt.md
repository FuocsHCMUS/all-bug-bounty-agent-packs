# Workflow — hunt

Run phases 0→5 for the named program using the hunt folder. Inherit AGENTS.md §1–§2 throughout.
