# Workflow — learn

Run workflows/08 debrief for the named finding. Inherit AGENTS.md §1–§2 throughout.
