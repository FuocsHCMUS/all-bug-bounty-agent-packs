# Workflow — report

Draft + self-attack a report via prompts/07. Inherit AGENTS.md §1–§2 throughout.
