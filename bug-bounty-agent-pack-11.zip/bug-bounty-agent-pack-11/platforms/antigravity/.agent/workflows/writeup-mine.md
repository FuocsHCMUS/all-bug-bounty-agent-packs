# Workflow — writeup-mine

Run workflows/03 on the writeup Joshua named. Inherit AGENTS.md §1–§2 throughout.
