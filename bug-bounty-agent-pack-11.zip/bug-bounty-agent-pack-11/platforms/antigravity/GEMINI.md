# Bug Bounty Pack 17 (Antigravity)

Follow the pack root `AGENTS.md`: lean gate, tiers, phases, ledger, creative generators, report-to-Joshua-only, posture + learning debrief.
