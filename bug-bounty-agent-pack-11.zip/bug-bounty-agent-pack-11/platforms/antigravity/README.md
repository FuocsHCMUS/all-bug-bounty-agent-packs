# Antigravity

Copy `.agent/` and `GEMINI.md` into your workspace. Workflows mirror `workflows/` in the pack root.
