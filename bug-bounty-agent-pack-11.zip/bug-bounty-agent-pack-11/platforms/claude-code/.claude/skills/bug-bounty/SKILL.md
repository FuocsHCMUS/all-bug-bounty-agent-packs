---
name: bug-bounty
description: Pack-17 bug bounty hunting — see the pack root AGENTS.md (canonical) and SKILL.md.
---

Follow the pack root `AGENTS.md`: lean gate (§1), approval tiers (§2), phases (§3), hypothesis ledger, creative generators (§5), posture + learning debrief (§3 Phase 5). Report findings to Joshua only.
