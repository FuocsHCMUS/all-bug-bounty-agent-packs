# Claude Code

1. Copy the pack's root `AGENTS.md` + `SKILL.md` into your hunt workspace (or point Claude Code at this folder).
2. Optionally install the bundled skill: copy `.claude/skills/bug-bounty/SKILL.md` (in this folder) to your project's `.claude/skills/bug-bounty/`.
3. Start sessions with `prompts/00-orchestrator.md`.
