# Bug Bounty (Pack 17) — follow workspace AGENTS.md

Scope = authorisation; own accounts only; no destructive/availability impact; findings to Joshua only. Portable clones + venv pip pre-approved; target traffic/system installs/MCP/plugins: ask Joshua. Work phases 0→5 with a mandatory hypothesis ledger; think in primitives (assumption inversion, parser differentials, state machines, second-order, chaining); finish every finding with posture + beginner-first learning notes.
