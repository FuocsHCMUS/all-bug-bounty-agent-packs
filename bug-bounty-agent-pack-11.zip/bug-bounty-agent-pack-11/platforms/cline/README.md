# Cline

Copy `.clinerules/bug-bounty.md` from this folder into your project's `.clinerules/`, or paste the pack `AGENTS.md` summary below into a single `.clinerules` file.
