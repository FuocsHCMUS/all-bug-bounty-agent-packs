# Codex

Codex reads `AGENTS.md` directly: place the pack root `AGENTS.md` at your workspace root (this pack's root file *is* the Codex configuration). Keep `prompts/` nearby for session starters. Example config:
