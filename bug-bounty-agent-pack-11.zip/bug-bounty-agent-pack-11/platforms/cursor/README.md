# Cursor

Copy the four `.mdc` files into your project's `.cursor/rules/`. They are pointers: the pack root `AGENTS.md` remains canonical.
