# OpenCode

Copy `opencode.json` and `.opencode/agent/bug-bounty.md` from this folder into your project, or run OpenCode from the pack root so it picks up `AGENTS.md`.
