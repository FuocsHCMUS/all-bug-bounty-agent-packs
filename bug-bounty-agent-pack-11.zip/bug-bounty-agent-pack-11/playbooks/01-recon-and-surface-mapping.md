# Playbook — Recon & Surface Mapping

## Signals / where this lives
CT logs, program docs, JS bundles, API docs, mobile apps, disclosed reports, response headers, error pages.

## Assumptions to invert
The real surface is only the web UI (false: APIs, old versions, partner integrations, exports and webhooks usually carry weaker checks). Subdomains in scope all enforce auth equally (often false).

## Creative angles
Map by *function* (money, identity, data, admin) not by URL count. Fingerprint quietly, record confidence. Hunt the seams: versioned APIs (v1 still alive?), locale/tenant variants, import/export endpoints.

## Validation discipline
Passive first. Active mapping = Tier 2, gentle, in-scope hosts only (scope_guard every batch). Output: inventory + surface map in the hunt folder.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
