# Playbook — Auth & Session Lifecycle

## Signals / where this lives
Login, MFA, password reset, magic links, session cookies, remember-me, logout, account recovery, invite flows.

## Assumptions to invert
Reset tokens expire and are single-use (test with your own account). Sessions die at logout/password change (check). MFA is enforced on *sensitive changes*, not just login (check email/payout changes).

## Creative angles
Token lifecycle table: issued→used→replayed→after-logout→after-reset. Invite/recovery flows are auth in disguise — model them as login endpoints. Race the reset: request two tokens, use them out of order.

## Validation discipline
Own accounts only; lockout testing is availability impact — stop at the first lockout signal and report the policy observation instead.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
