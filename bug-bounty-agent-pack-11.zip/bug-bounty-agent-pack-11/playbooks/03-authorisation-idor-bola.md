# Playbook — Authorisation — IDOR / BOLA / BFLA

## Signals / where this lives
Numeric/UUID object ids in URLs, APIs, exports, websockets; role-gated admin functions; tenant/workspace switching.

## Assumptions to invert
The server re-checks ownership on *every* object access (the classic false assumption). UUID = unguessable therefore safe (false if ids leak in lists, emails, JS, shared links).

## Creative angles
Differential matrix by default: A-owned object requested as A / B / unauthenticated / other-role / other-tenant. Check *every verb* (GET often checked, DELETE/export/share forgotten) and every representation (API, PDF export, thumbnail, embed). Function-level: call admin functions as a normal user with the UI merely hiding them.

## Validation discipline
Two-account rule is the whole proof. One cross-account read of your *own* B-account object is enough — stop there.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
