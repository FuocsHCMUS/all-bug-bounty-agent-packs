# Playbook — Business Logic & Workflow / State Machines

## Signals / where this lives
Checkout, coupons, quotas, approvals, onboarding steps, KYC tiers, pricing, refunds, subscriptions.

## Assumptions to invert
Steps happen in order, once, by the right actor (draw the state machine, then break each property). Prices/totals computed client-side are re-checked server-side (verify). Limits are enforced atomically (see race playbook).

## Creative angles
Negative/zero/overflow quantities; currency & rounding seams; coupon stacking/reuse across accounts you own; step-skipping by calling step 3 directly; resurrecting cancelled/refunded states; abusing 'pending' states that already grant access.

## Validation discipline
Use test/sandbox payment modes and your own accounts; never complete a real-world fulfilment — stop before dispatch/payment capture and document.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
