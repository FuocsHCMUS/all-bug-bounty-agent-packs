# Playbook — Race Conditions & Timing

## Signals / where this lives
Single-use anything (coupons, votes, invites, OTP), balance/limit checks, file processing, 'first come' allocations.

## Assumptions to invert
Check-then-act is atomic (it rarely is). The window is too small to matter (HTTP/2 and parallelism disagree).

## Creative angles
Model the exact check→act gap; send parallel requests only against your own objects/limits, small counts first (2, then 5). Look for partial races: two different endpoints mutating the same counter.

## Validation discipline
Rate/volume = Tier 2. Keep counts minimal that still prove the point; races against shared/global resources are out — prove it on resources only you own.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
