# Playbook — Injection Concepts

## Signals / where this lives
Search, filters, sorting, report builders, template/preview features, PDF/CSV generation, GraphQL arguments, headers reflected server-side.

## Assumptions to invert
All inputs are parameterised/escaped in *all* contexts (the same field rendered in HTML, email, PDF and admin panel is four different contexts). Sort/order parameters are whitelisted (often concatenated).

## Creative angles
Think context-first: where does this input *land*? Follow one field through UI, export, email, admin and API. Encoding seams (double encoding, Unicode normalisation, charset confusion) live between components — parser differentials again.

## Validation discipline
Prove with benign markers on your own data (e.g. a unique string/calculation on your own records). No data extraction beyond the minimum proof.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
