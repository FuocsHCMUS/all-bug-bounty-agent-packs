# Playbook — XSS & Client-Side / Browser Security

## Signals / where this lives
Reflected parameters, stored profile/content fields, DOM sinks (innerHTML, postMessage handlers), file/SVG uploads, CORS headers, CSP, clickjacking surface.

## Assumptions to invert
postMessage handlers check origin (read the JS). CORS reflection is harmless because of credentials rules (check `Allow-Credentials` pairing). A strict CSP on the main page covers subdomains/exports (often false).

## Creative angles
Mine the JS: source maps, sink grep, postMessage listeners. Stored-XSS hunting grounds are second-order surfaces: admin views, notification emails rendered in webmail, PDF/HTML exports. XS-Leaks and cache behaviour for cross-origin state inference — conceptual, validate only on your own accounts.

## Validation discipline
Self-XSS alone is not a finding — find the delivery (victim = your B account). Benign proof payload: a console/DOM marker, not a credential grab.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
