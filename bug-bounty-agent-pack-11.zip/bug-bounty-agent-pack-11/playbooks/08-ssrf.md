# Playbook — SSRF

## Signals / where this lives
URL fetchers, webhooks, image import, link previews, PDF renderers, integration settings, metadata-adjacent internal services.

## Assumptions to invert
The fetcher blocks private IPs (check DNS rebinding concepts, redirect following, 0.0.0.0/decimal/IPv6 representations — as *parser differentials*). Only the initial URL is validated, redirects are safe to follow blindly (classic false).

## Creative angles
Map what the fetcher follows: redirects, DNS changes between check and fetch, URL parser differences between validator and fetcher libraries. Cloud metadata reachability is the impact question — establish it with the platform's own harmless metadata paths only where the program permits, and never pull credentials.

## Validation discipline
Your own external listener (Tier 2, your infrastructure) proves outbound fetch. Internal scanning is out: one or two targeted, permitted checks, not a sweep.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
