# Playbook — Files — Upload, Download, Path

## Signals / where this lives
Avatars, attachments, import (CSV/zip/XML), download-by-id endpoints, file sharing links, image processing pipelines.

## Assumptions to invert
Extensions are validated server-side *and* at serving time (stored file served with a safe Content-Type?). Zip/XML parsers reject traversal and entity tricks (check with harmless entries in your own archives). Download endpoints check ownership like page views do (they forget).

## Creative angles
Upload→storage→processing→serving is four trust boundaries; test each. Signed URLs: expiry, scope (one object or a prefix?), replay after sharing is revoked. Path traversal in your own filenames/ids only.

## Validation discipline
Upload only benign proof files (a text file with a marker, an image that displays a marker). Never upload anything executable to be run against other users.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
