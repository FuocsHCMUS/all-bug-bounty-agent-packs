# Playbook — API, GraphQL & WebSocket

## Signals / where this lives
REST versioning, GraphQL endpoints, batching, introspection, websocket channels/subscriptions, API keys in mobile/JS clients.

## Assumptions to invert
GraphQL resolvers each enforce authz (field-level gaps are the norm, not the exception). Deprecated API versions are decommissioned (v1 usually answers). WebSocket messages are authorised like the handshake (subscriptions often are not re-checked).

## Creative angles
Build the differential matrix *per resolver/field/channel*. Introspection (if enabled) is a map, not a bug — the bug is what the map lets your B account reach. Batching turns one rate limit into many operations: reason about it, test gently on your own objects.

## Validation discipline
Own keys/accounts only. Keep query rates human-scale; automated sweeps are Tier 2 with Joshua's go-ahead.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
