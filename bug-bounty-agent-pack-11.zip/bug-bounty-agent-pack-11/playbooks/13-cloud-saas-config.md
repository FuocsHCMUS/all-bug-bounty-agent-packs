# Playbook — Cloud & SaaS Configuration

## Signals / where this lives
Public buckets/links, share settings, OAuth app consents, webhook secrets, CI/build artefacts, status/debug pages, SaaS tenant settings.

## Assumptions to invert
Sharing defaults are private (check 'anyone with the link' on *your own* files). Tenant isolation holds across every integration, not just the main app.

## Creative angles
Configuration *is* code here: enumerate your own tenant's sharing, integration and export settings as an attacker with a normal account would see them. Look for cross-tenant references in integration objects (playbook 03 in SaaS clothing).

## Validation discipline
Only your own tenant/resources. Never open a link that resolves to someone else's real data — if one does, stop and report the fact with minimal evidence.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
