# Playbook — Mobile Backends

## Signals / where this lives
Mobile API traffic, deep links, certificate pinning presence, local storage, push/notification payloads, older app versions.

## Assumptions to invert
The mobile API is a different, weaker API (it is usually the *same* API with extra trust in the client: hidden fields, client-set prices/roles). Deep links validate their parameters like web pages do (rarely).

## Creative angles
Diff web vs mobile API responses for the same object (extra fields leak here). Treat client-sent flags (isAdmin, price, verified) as hypotheses. Old app versions keep old endpoints alive.

## Validation discipline
Your device/emulator, your accounts. No intercepting anyone else's traffic, ever.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
