# Playbook — AI / LLM Application Surfaces

## Signals / where this lives
Chatbots, RAG over documents, agents with tools, summarise/share features, prompt-driven workflows, file ingestion for AI.

## Assumptions to invert
The model is the security boundary (it is not — the *tools and data plumbing* are). Instructions inside retrieved documents are treated as data (indirect prompt injection exists precisely because they are not). Tenants' documents never mix in retrieval (test with your own two workspaces).

## Creative angles
Map the plumbing: ingestion → embedding store → retrieval → prompt → tool calls → output rendering (stored XSS via model output rendered as HTML is a real chain). Test cross-tenant retrieval and tool authorisation with your own accounts/documents containing unique markers.

## Validation discipline
Markers are benign unique strings in your own docs. No extracting model/system data beyond demonstrating your own marker crossed a boundary.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
