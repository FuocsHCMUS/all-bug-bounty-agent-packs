# Playbook — OAuth / OIDC / SSO / Passkeys

## Signals / where this lives
Social login, SSO/SAML, account linking, redirect URIs, state/nonce, token storage, passkey enrolment/ceremony, session after SSO.

## Assumptions to invert
redirect_uri validation is exact-match (loose matching is still common). Account linking checks the existing session's owner (linking attacks live here). State is present, random *and verified* (all three).

## Creative angles
Lifecycle table again, per provider: start → callback → link → unlink → re-link. Test with two IdP accounts you own linked across A/B app accounts. Passkeys: enrolment on a hijacked session and cross-device flows are the interesting seams — reason first, test only on your own accounts.

## Validation discipline
All identities involved are yours. Never attempt to link or reset an account you cannot already prove you own.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
