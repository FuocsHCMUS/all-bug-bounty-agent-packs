# Playbook — Deserialisation, Prototype Pollution & Supply Chain

## Signals / where this lives
Import/restore features, JSON merge/patch endpoints, settings objects, webhooks with signed payloads, third-party widgets/scripts, dependency manifests in public repos.

## Assumptions to invert
Merging user JSON into server objects is safe because the framework 'handles it' (pollution lives in merge utilities). Signed webhooks are verified before parsing (order matters).

## Creative angles
Follow one user-controlled object through merge/parse into a privileged context. Supply-chain angle is *research*: which third-party scripts run on sensitive pages, what happens if one is compromised — report as posture/hardening unless you can prove a concrete, permitted impact.

## Validation discipline
Local lab reproduction first (docs/05) for this whole class; target tests are single, benign, own-account markers.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
