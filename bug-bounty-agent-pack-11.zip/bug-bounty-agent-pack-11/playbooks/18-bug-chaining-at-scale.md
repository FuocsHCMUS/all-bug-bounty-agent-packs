# Playbook — Bug Chaining At Scale

## Signals / where this lives
Your ledger's lows/infos, killed hypotheses with partial signals, posture notes from earlier hunts on the same program.

## Assumptions to invert
A low-severity primitive is a dead end (it is a *capability*: read-one-object, write-one-field, trigger-one-server-fetch, bypass-one-check). Chains fail because primitives are filed as conclusions instead of capabilities.

## Creative angles
Keep a primitives inventory (`templates/13`). Chain sprint (`workflows/05`): list primitives, ask 'what does this unlock?', compose 2–3 step chains on paper, validate each link with own accounts. Score the chain by its end state (docs/07).

## Validation discipline
Every link individually obeys §1. A chain never justifies an out-of-scope link.

## Ledger prompts
- Assumption: ___ · Inversion test: ___ · Cheapest safe test: ___ · Expected signal if true: ___

## Report & learn
- Impact phrasing: state only what the two-account / own-data proof showed.
- Tutor tie-in: explain the root concept (see `learning/`) in the finding's learning note (`templates/10`).
