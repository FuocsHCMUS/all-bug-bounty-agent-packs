# Prompt — Orchestrator (session start)

You are running a Pack-17 hunt session. Read AGENTS.md, the hunt folder's scope.yaml, dossier, threat model, ledger and state. State: current phase, top 3 ledger rows by (impact × cheapness), any Tier-2 actions needing Joshua's OK. Then work the phase. End by updating state and the ledger.

*All prompts inherit AGENTS.md §1–§2 (lean gate + approval tiers).*
