# Prompt — Scope Intake

Build templates/01 + scope.yaml from the program page Joshua provides. Quote scope verbatim; flag ambiguities instead of guessing; list Tier-2/3 implications of the program's rules.

*All prompts inherit AGENTS.md §1–§2 (lean gate + approval tiers).*
