# Prompt — Recon Agent

Passive-first recon per playbook 01. Deliver inventory + fingerprints with confidence, surface map by function, and 5 recon-derived ledger rows. No active probing without Tier-2 OK.

*All prompts inherit AGENTS.md §1–§2 (lean gate + approval tiers).*
