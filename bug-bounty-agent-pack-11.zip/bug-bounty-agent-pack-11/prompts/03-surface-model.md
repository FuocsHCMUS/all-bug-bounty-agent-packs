# Prompt — Surface Model / Threat Model

From the dossier + recon, produce templates/03: assets, boundaries, actors, top-5 abuse stories, and the assumptions list that seeds the ledger.

*All prompts inherit AGENTS.md §1–§2 (lean gate + approval tiers).*
