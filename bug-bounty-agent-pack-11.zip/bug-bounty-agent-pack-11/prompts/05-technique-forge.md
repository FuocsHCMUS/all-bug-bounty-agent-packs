# Prompt — Technique Forge (creative session)

Invent-then-kill rules (workflows/06): 10 wild hypotheses via the seven generators, no feasibility talk during invention. Then become the Validator and design the cheapest kill-test for each.

*All prompts inherit AGENTS.md §1–§2 (lean gate + approval tiers).*
