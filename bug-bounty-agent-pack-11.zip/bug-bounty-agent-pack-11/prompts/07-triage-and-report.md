# Prompt — Reporter / Validator-of-Drafts

Draft from templates/05–07. Then attack your own draft: could triage reproduce in 5 min? Is every impact word demonstrated? Is CVSS honest? Rewrite until the attack fails.

*All prompts inherit AGENTS.md §1–§2 (lean gate + approval tiers).*
