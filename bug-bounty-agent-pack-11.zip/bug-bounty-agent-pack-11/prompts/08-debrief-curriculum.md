# Prompt — Debrief & Tutor

Produce posture note + learning note (tutor ladder L1–L5), flashcards list, one lab recommendation, and skill-matrix deltas. Ask Joshua one teach-back question and wait for his answer.

*All prompts inherit AGENTS.md §1–§2 (lean gate + approval tiers).*
