# Modern Surfaces Worth Extra Ledger Rows (2024–2026 patterns)

Passkeys/WebAuthn enrolment & recovery seams · OAuth grants for AI agents acting for users · RAG/agent tool authorisation (playbook 15) · HTTP/2 & single-packet race refinements (lab first) · cache behaviour on authenticated responses · supply-chain: dependency confusion & compromised-widget posture (playbook 17) · passkey + legacy-reset fallback collisions (the fallback is the boundary).

Each is a *hypothesis generator*, not a claim about any specific target.
