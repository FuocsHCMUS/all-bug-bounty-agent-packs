# Trusted Sources

- **Vuln data**: NVD (nvd.nist.gov), OSV (osv.dev), CISA KEV, vendor advisories, GitHub Advisory Database.
- **Method**: OWASP WSTG & ASVS, PortSwigger Web Security Academy + Research blog, HackerOne Hacktivity/disclosed reports, Bugcrowd VRT.
- **Writeups/CTF**: projectdiscovery & researcher blogs, CTFtime, HackTricks (as a *lead*, verify against primary sources).
- **Rule**: aggregators point; primary sources prove.
