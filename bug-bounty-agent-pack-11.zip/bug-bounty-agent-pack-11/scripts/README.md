# Scripts — Pack 17 (stdlib only, Python 3.14, Windows 11 friendly)

| Script | Job | Network? |
|---|---|---|
| `scope_guard.py` | URL/host vs scope.yaml/JSON → IN / OUT / UNKNOWN (exit 0/2/3) | no |
| `inventory.py` | hostname list → scope-marked Markdown inventory | no |
| `headers_check.py` | one GET, security-header gaps | 1 request |
| `http_probe.py` | one GET, **dry-run by default** (`--live` to send) | opt-in |
| `tech_fingerprint.py` | one GET, tech signals with confidence caveats | 1 request |
| `cve_lookup.py` | NVD lookup by CVE id or keyword (`NVD_API_KEY` optional) | NVD only |
| `cve_match.py` | CVE data × surface JSONL → candidate rows | no |
| `cvss.py` | CVSS 3.1 base score from a vector | no |
| `make_hunt.py` | scaffold a hunt folder with core templates + scope.yaml | no |
| `learning_card.py` | learning note → Day 1/3/7/21 flashcards | no |
| `state.py` | findings JSONL: add / list / set | no |

Anything that touches a target: run `scope_guard.py` first, and remember
Tier 2 (AGENTS §2) — target traffic beyond a benign probe needs Joshua's OK.
