#!/usr/bin/env python3
"""Look up a CVE id or keyword on the NVD API 2.0. Stdlib only.
Usage: python cve_lookup.py --cve CVE-2024-0000 | --keyword nginx
Set NVD_API_KEY env var to raise rate limits.
"""
from __future__ import annotations
import argparse, json, os, sys, urllib.parse, urllib.request

NVD = "https://services.nvd.nist.gov/rest/json/cves/2.0"
def fetch(params: dict) -> dict:
    url = NVD + "?" + urllib.parse.urlencode(params)
    h = {"User-Agent": "Pack17-CVELookup/1.0"}
    if os.environ.get("NVD_API_KEY"): h["apiKey"] = os.environ["NVD_API_KEY"]
    with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=40) as r:
        return json.loads(r.read())

def summarise(data: dict) -> list:
    out = []
    for item in data.get("vulnerabilities", []):
        c = item.get("cve", {})
        desc = next((d["value"] for d in c.get("descriptions", []) if d.get("lang") == "en"), "")
        out.append({"id": c.get("id"), "published": c.get("published"), "description": desc[:300]})
    return out

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--cve"); ap.add_argument("--keyword")
    a = ap.parse_args()
    if not a.cve and not a.keyword:
        ap.error("give --cve or --keyword")
    data = fetch({"cveId": a.cve} if a.cve else {"keywordSearch": a.keyword, "resultsPerPage": "10"})
    for row in summarise(data): print(json.dumps(row, indent=2))
    return 0

if __name__ == "__main__": sys.exit(main())
