#!/usr/bin/env python3
"""Match CVE keyword data against surface fingerprints (JSONL) -> candidate rows.
Usage: python cve_match.py --cves cves.json --surface surface.jsonl
cves.json: {"keyword": "nginx", "vulnerabilities": [...]} (NVD-shaped or simple list).
Reachability is always a human/ledger decision — this only proposes candidates.
"""
from __future__ import annotations
import argparse, json, sys

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--cves", required=True); ap.add_argument("--surface", required=True)
    a = ap.parse_args()
    data = json.load(open(a.cves, encoding="utf-8"))
    kw = (data.get("keyword") or "").lower()
    n = len(data.get("vulnerabilities", data if isinstance(data, list) else []))
    hits = 0
    for line in open(a.surface, encoding="utf-8"):
        row = json.loads(line)
        blob = json.dumps(row).lower()
        if kw and kw in blob:
            hits += 1
            print(json.dumps({"host": row.get("host"), "candidate_cves": n, "status": "candidate — check reachability"}))
    print(f"# {hits} candidate surface rows for keyword '{kw}'", file=sys.stderr)
    return 0

if __name__ == "__main__": sys.exit(main())
