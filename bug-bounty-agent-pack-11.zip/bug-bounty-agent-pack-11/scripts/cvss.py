#!/usr/bin/env python3
"""CVSS 3.1 base score. Usage: python cvss.py CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N
Also importable: score(vector) -> (float, severity str). Stdlib only.
"""
import math, sys
W = {"AV": {"N": .85, "A": .62, "L": .55, "P": .2}, "AC": {"L": .77, "H": .44},
     "UI": {"N": .85, "R": .62}, "CIA": {"H": .56, "L": .22, "N": 0.0}}
PR = {"U": {"N": .85, "L": .62, "H": .27}, "C": {"N": .85, "L": .68, "H": .5}}

def _roundup(x: float) -> float:
    return math.ceil(x * 10 - 1e-9) / 10

def score(vec: str) -> tuple:
    v = vec.split("/", 1)[1] if vec.startswith("CVSS:") else vec
    m = dict(p.split(":", 1) for p in v.split("/") if ":" in p)
    for k in ("AV", "AC", "PR", "UI", "S", "C", "I", "A"):
        if k not in m: raise ValueError(f"missing metric {k}")
    s = m["S"]
    iss = 1 - (1 - W["CIA"][m["C"]]) * (1 - W["CIA"][m["I"]]) * (1 - W["CIA"][m["A"]])
    impact = 6.42 * iss if s == "U" else 7.52 * (iss - .029) - 3.25 * (iss - .02) ** 15
    expl = 8.22 * W["AV"][m["AV"]] * W["AC"][m["AC"]] * PR[s][m["PR"]] * W["UI"][m["UI"]]
    if impact <= 0: base = 0.0
    elif s == "U": base = _roundup(min(impact + expl, 10))
    else: base = _roundup(min(1.08 * (impact + expl), 10))
    sev = ("None" if base == 0 else "Low" if base < 4 else "Medium" if base < 7
           else "High" if base < 9 else "Critical")
    return base, sev

def main() -> int:
    if len(sys.argv) == 2 and sys.argv[1] in ("-h", "--help"): print(__doc__); return 0
    if len(sys.argv) != 2: print(__doc__); return 2
    b, s = score(sys.argv[1]); print(f"{b:.1f} ({s})"); return 0

if __name__ == "__main__": sys.exit(main())
