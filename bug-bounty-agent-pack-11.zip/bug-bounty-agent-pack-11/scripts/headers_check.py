#!/usr/bin/env python3
"""One GET; report missing/weak security response headers. Stdlib only.
Usage: python headers_check.py https://in-scope.example/
Run scope_guard.py first — this script sends a real request.
"""
from __future__ import annotations
import argparse, sys, urllib.request, urllib.error

WANT = {
    "strict-transport-security": "HSTS",
    "content-security-policy": "CSP",
    "x-content-type-options": "nosniff",
    "referrer-policy": "Referrer-Policy",
    "x-frame-options": "clickjacking (or CSP frame-ancestors)",
    "permissions-policy": "Permissions-Policy",
}
def check_headers(headers: dict) -> list:
    low = {k.lower(): v for k, v in headers.items()}
    return [f"MISSING {label} ({name})" for name, label in WANT.items() if name not in low]

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__); ap.add_argument("url")
    a = ap.parse_args()
    req = urllib.request.Request(a.url, headers={"User-Agent": "Pack17-HeadersCheck/1.0 (single request)"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            print(f"{r.status} {a.url}")
            issues = check_headers(dict(r.headers.items()))
    except urllib.error.URLError as e:
        print(f"ERROR: {e}"); return 1
    print("\n".join(issues) if issues else "All checked headers present.")
    print("Note: a missing header is a hardening note, not automatically a finding.")
    return 0

if __name__ == "__main__": sys.exit(main())
