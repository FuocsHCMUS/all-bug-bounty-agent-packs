#!/usr/bin/env python3
"""Minimal HTTP probe. DRY-RUN by default: prints what it *would* request.
Usage: python http_probe.py https://in-scope.example/ [--live]
--live sends exactly one GET. Check scope first (scope_guard.py).
"""
from __future__ import annotations
import argparse, sys, urllib.request, urllib.error

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("url"); ap.add_argument("--live", action="store_true")
    a = ap.parse_args()
    if not a.live:
        print(f"DRY-RUN: would GET {a.url} (pass --live for one real request, after scope check)")
        return 0
    req = urllib.request.Request(a.url, headers={"User-Agent": "Pack17-Probe/1.0 (single request)"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            body = r.read(512)
            print(f"{r.status} {r.headers.get('server','')} {len(body)}+ bytes preview")
    except urllib.error.URLError as e:
        print(f"ERROR: {e}"); return 1
    return 0

if __name__ == "__main__": sys.exit(main())
