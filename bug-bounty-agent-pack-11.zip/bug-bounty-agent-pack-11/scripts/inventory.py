#!/usr/bin/env python3
"""Build a Markdown inventory table from a hostname list, scope-checked.
Usage: python inventory.py hosts.txt --scope scope.yaml
Discovery is not authorisation: rows are marked IN / OUT / UNKNOWN.
"""
from __future__ import annotations
import argparse, sys
from scope_guard import load_scope, verdict, host_of

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("host_file"); ap.add_argument("--scope")
    a = ap.parse_args()
    hosts = sorted({host_of(l) for l in open(a.host_file, encoding="utf-8") if l.strip()})
    scope = load_scope(a.scope) if a.scope else {"in": [], "out": []}
    print("| Host | Scope | Tech signals | Notes |")
    print("|---|---|---|---|")
    for h in hosts:
        print(f"| {h} | {verdict(h, scope) if a.scope else 'UNCHECKED'} | | |")
    return 0

if __name__ == "__main__": sys.exit(main())
