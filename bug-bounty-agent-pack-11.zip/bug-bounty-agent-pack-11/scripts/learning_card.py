#!/usr/bin/env python3
"""Turn a learning note into spaced-repetition flashcards (Day 1/3/7/21).
Usage: python learning_card.py notes.md [-o cards.md]
Cards are made from '## ' headings: front = heading, back = first lines.
"""
from __future__ import annotations
import argparse, datetime, sys

def cards_from(text: str) -> list:
    cards, head, body = [], None, []
    for line in text.splitlines():
        if line.startswith("## "):
            if head: cards.append((head, " ".join(body)[:400]))
            head, body = line[3:].strip(), []
        elif head and line.strip(): body.append(line.strip())
    if head: cards.append((head, " ".join(body)[:400]))
    return cards

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("note"); ap.add_argument("-o", "--output", default="cards.md")
    a = ap.parse_args()
    cards = cards_from(open(a.note, encoding="utf-8").read())
    today = datetime.date.today()
    reviews = ", ".join(str(today + datetime.timedelta(days=d)) for d in (1, 3, 7, 21))
    with open(a.output, "w", encoding="utf-8") as f:
        f.write(f"# Flashcards from {a.note}\nReview on: {reviews}\n\n")
        for i, (front, back) in enumerate(cards, 1):
            f.write(f"## Card {i}\n**Q:** Explain: {front}\n**A:** {back}\n\n")
    print(f"{len(cards)} cards -> {a.output} (reviews: {reviews})")
    return 0

if __name__ == "__main__": sys.exit(main())
