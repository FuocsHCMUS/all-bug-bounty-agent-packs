#!/usr/bin/env python3
"""Create a hunt folder for a program with the pack's core artefacts.
Usage: python make_hunt.py acme --platform hackerone [--base hunts]
Stdlib only. Copies templates by name from ../templates when run in-pack,
otherwise creates titled stubs.
"""
from __future__ import annotations
import argparse, pathlib, sys

CORE = ["01-scope-intake.md", "02-target-dossier.md", "03-threat-model.md",
        "04-hypothesis-ledger.md", "08-hunt-notes.md", "11-cve-match.md", "13-chain-canvas.md"]

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("program"); ap.add_argument("--platform", default="hackerone")
    ap.add_argument("--base", default="hunts")
    a = ap.parse_args()
    root = pathlib.Path(a.base) / a.program
    for sub in ("evidence", "notes", "reports"): (root / sub).mkdir(parents=True, exist_ok=True)
    tpl = pathlib.Path(__file__).resolve().parent.parent / "templates"
    for name in CORE:
        src = tpl / name; dst = root / name
        dst.write_text(src.read_text(encoding="utf-8") if src.exists() else f"# {name}\n", encoding="utf-8")
    (root / "scope.yaml").write_text(
        f"program: {a.program}\nplatform: {a.platform}\nchecked: \nin_scope:\nout_of_scope:\n", encoding="utf-8")
    print(f"Created {root} — fill scope.yaml from the live program page before any testing.")
    return 0

if __name__ == "__main__": sys.exit(main())
