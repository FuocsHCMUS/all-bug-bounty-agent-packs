#!/usr/bin/env python3
"""Check a URL/host against a hunt scope file. Stdlib only, Python 3.14.

Scope file formats: the pack's simple scope.yaml (in_scope:/out_of_scope:
lists, see templates/scope.yaml.example) or JSON {"in_scope": [...]}.
Usage: python scope_guard.py https://api.acme.example/x --scope scope.yaml
Exit 0 = in scope, 2 = out of scope, 3 = unknown / no scope file match.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from urllib.parse import urlparse

def host_of(value: str) -> str:
    v = value.strip().strip(",").strip("'\"")
    if "://" in v:
        return (urlparse(v).hostname or "").lower()
    return v.split("/")[0].lower()

def load_scope(path: str) -> dict:
    text = Path(path).read_text(encoding="utf-8")
    if path.endswith(".json"):
        d = json.loads(text); return {"in": d.get("in_scope", []), "out": d.get("out_of_scope", [])}
    data, cur = {"in": [], "out": []}, None
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("in_scope:"): cur = "in"; continue
        if s.startswith("out_of_scope:"): cur = "out"; continue
        if s.startswith("-") and cur:
            data[cur].append(s[1:].strip().strip("'\""))
        elif ":" in s and not s.startswith("-"): cur = None
    return data

def match(host: str, patterns: list) -> bool:
    for p in patterns:
        p = host_of(p)
        if p.startswith("*."):
            base = p[2:]
            if host == base or host.endswith("." + base): return True
        elif host == p: return True
    return False

def verdict(host: str, scope: dict) -> str:
    if match(host, scope["out"]): return "OUT"
    if match(host, scope["in"]): return "IN"
    return "UNKNOWN"

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("target"); ap.add_argument("--scope", required=True)
    a = ap.parse_args()
    v = verdict(host_of(a.target), load_scope(a.scope))
    print(f"{host_of(a.target)}: {v}")
    return {"IN": 0, "OUT": 2, "UNKNOWN": 3}[v]

if __name__ == "__main__": sys.exit(main())
