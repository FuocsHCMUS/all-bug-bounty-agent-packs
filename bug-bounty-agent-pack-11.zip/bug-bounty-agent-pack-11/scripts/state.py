#!/usr/bin/env python3
"""Append/query a findings state file (JSONL). Stdlib only.
  python state.py add --title "IDOR on /invoices" --asset https://... --status open
  python state.py list [--status open]
  python state.py set F-001 status validated
State file: ./state/findings.jsonl (override with --file).
"""
from __future__ import annotations
import argparse, json, pathlib, sys, time

def read(path) -> list:
    p = pathlib.Path(path)
    if not p.exists(): return []
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]

def write(path, rows) -> None:
    p = pathlib.Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("".join(json.dumps(r) + "\n" for r in rows), encoding="utf-8")

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--file", default="state/findings.jsonl")
    sub = ap.add_subparsers(dest="cmd", required=True)
    ad = sub.add_parser("add"); ad.add_argument("--title", required=True)
    ad.add_argument("--asset", default=""); ad.add_argument("--status", default="open")
    li = sub.add_parser("list"); li.add_argument("--status")
    se = sub.add_parser("set"); se.add_argument("id"); se.add_argument("key"); se.add_argument("value")
    a = ap.parse_args(); rows = read(a.file)
    if a.cmd == "add":
        fid = f"F-{len(rows)+1:03d}"
        rows.append({"id": fid, "title": a.title, "asset": a.asset, "status": a.status, "ts": time.time()})
        write(a.file, rows); print(fid)
    elif a.cmd == "list":
        for r in rows:
            if not a.status or r.get("status") == a.status: print(f"{r['id']} [{r.get('status')}] {r['title']}")
    elif a.cmd == "set":
        for r in rows:
            if r["id"] == a.id: r[a.key] = a.value
        write(a.file, rows); print(f"{a.id} {a.key}={a.value}")
    return 0

if __name__ == "__main__": sys.exit(main())
