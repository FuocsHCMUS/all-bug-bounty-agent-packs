#!/usr/bin/env python3
"""One gentle GET; print technology signals WITH confidence caveats.
Usage: python tech_fingerprint.py https://in-scope.example/
Signals are hints for the CVE matrix, never proof of a version.
"""
from __future__ import annotations
import argparse, re, sys, urllib.request, urllib.error

SIGS = [(r"wp-content|wp-includes", "WordPress (high)"), (r"__NEXT_DATA__|/_next/", "Next.js (medium)"),
        (r"react", "React hints in page (low)"), (r"csrf|xsrf", "CSRF token present (info)"),
        (r"cloudflare", "Cloudflare in page (low)"), (r"/graphql", "GraphQL reference (medium)")]

def fingerprint(headers: dict, body: str) -> list:
    found = []
    srv = headers.get("Server") or headers.get("server")
    if srv: found.append(f"Server header: {srv} (low confidence — often masked/stale)")
    if headers.get("X-Powered-By") or headers.get("x-powered-by"):
        found.append(f"X-Powered-By: {headers.get('X-Powered-By') or headers.get('x-powered-by')} (low)")
    for pat, label in SIGS:
        if re.search(pat, body, re.I): found.append(label)
    return found

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__); ap.add_argument("url")
    a = ap.parse_args()
    req = urllib.request.Request(a.url, headers={"User-Agent": "Pack17-Fingerprint/1.0 (single request)"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            rows = fingerprint(dict(r.headers.items()), r.read(200_000).decode("utf-8", "ignore"))
    except urllib.error.URLError as e:
        print(f"ERROR: {e}"); return 1
    print("\n".join(rows) if rows else "No signals found.")
    return 0

if __name__ == "__main__": sys.exit(main())
