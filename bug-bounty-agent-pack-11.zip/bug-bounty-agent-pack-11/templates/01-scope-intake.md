# Template — Scope Intake / Program Dossier

Program: · Platform: · Date checked:
## In scope (copy exactly)
## Out of scope (copy exactly)
## Program rules (rate/automation/headers/disclosure)
## Severity & payout norms · response-time history
## Known duplicates / disclosed-report patterns
## Why this program, why now (uncrowded angle)
