# Template — Target Dossier

Company in one paragraph · Product & money flow · Tech fingerprints (+confidence) · Surface map link · Threat model link · Intel notes (docs/06) · Hunt history on this program
