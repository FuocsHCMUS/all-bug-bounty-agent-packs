# Template — Threat Model

## Assets (data, money, identity, admin)
## Trust boundaries (draw them)
## Actors (anon, user, admin, tenant-admin, integration, insider)
## Abuse stories (top 5, ranked impact × likelihood × uncrowdedness)
## Assumptions the design seems to rely on → feed the ledger
