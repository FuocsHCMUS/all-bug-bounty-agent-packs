# Template — Hypothesis Ledger (mandatory, Phase 2)

| ID | Surface | Assumption | Inversion | Cheapest safe test | Signal if true | Status | Evidence |
|---|---|---|---|---|---|---|---|
| H-001 | | | | | | open | |

Statuses: open / confirmed / killed (why) / blocked (why). Killed rows are kept forever.
