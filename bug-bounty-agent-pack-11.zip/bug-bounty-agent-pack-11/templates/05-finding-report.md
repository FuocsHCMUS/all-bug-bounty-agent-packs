# Template — Finding Report (generic)

# [Asset] — [Class] allows [impact]
## Summary
## Affected asset & preconditions (test accounts A/B)
## Steps to reproduce (numbered, ≤5 min)
## Evidence (manifest link)
## Impact (demonstrated only)
## Severity suggestion + CVSS vector & reasoning
## Fix sketch
## Timeline of testing
