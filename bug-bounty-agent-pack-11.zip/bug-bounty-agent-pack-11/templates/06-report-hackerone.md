# Template — Report — HackerOne Variant

Title: [asset]: [class] → [impact]
## Summary
## Steps To Reproduce
## Supporting Material (evidence manifest)
## Impact
## Suggested CVSS (vector + per-metric justification)
