# Template — Report — Bugcrowd Variant

Title · VRT category suggestion · Affected URL/parameter
## Description
## Steps to reproduce
## Expected vs actual
## Impact & business risk
## Evidence links
