# Template — Hunt Notes & Weekly Retro

## Session log (date, phase, actions, tool log)
## Signals & dead ends
## Retro (weekly): what worked / what was noise / one process change / ledger stats (opened, killed, confirmed)
