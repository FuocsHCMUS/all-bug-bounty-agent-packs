# Template — Company Security Posture Analysis

## Doing well (with evidence)
## Needs improvement (patterns, not just instances)
## Risk view (likelihood × impact, assumptions stated)
## False-positive check (could this be intended / compensated?)
## SOC view: what detection would see / miss; suggested detection idea
## Fix sketch + regression test idea
