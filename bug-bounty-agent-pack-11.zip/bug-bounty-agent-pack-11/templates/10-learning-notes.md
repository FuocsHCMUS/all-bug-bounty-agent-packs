# Template — Learning Notes (per finding)

## The concept from zero (L1 story → L2 mechanism)
## Why the bug follows (L3)
## The fix (L4) · The detection (L5)
## My teach-back (Joshua, in your own words)
## Lab to practise · Flashcards made (Y/N)
