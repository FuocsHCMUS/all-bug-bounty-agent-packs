# Template — Technique Card

Name · Primitive (input → parser → assumption → sink) · Preconditions · Detection signal · Where else this shape appears · Source (writeup/CTF/CVE) · Lab reproduction link · Chain potential
