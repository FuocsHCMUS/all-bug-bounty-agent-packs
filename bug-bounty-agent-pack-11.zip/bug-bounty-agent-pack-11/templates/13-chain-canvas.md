# Template — Chain Canvas

Primitives inventory: P1 (capability, from finding/ledger #) …
Chain sketch (text or Mermaid): P? → unlocks → P? → end impact
Per link: validated? own-account proof? · End-state CVSS reasoning
