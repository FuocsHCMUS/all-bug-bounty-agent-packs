# Template — Evidence Manifest

| File | Time (tz) | Account | Step it proves | SHA-256 |
|---|---|---|---|---|

Redaction note: confirm no third-party real data is included; tokens redacted.
