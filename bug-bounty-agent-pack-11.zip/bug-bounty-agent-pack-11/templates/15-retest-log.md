# Template — Retest & Disclosure Log

Original finding id · Fix announced (date, via Joshua) · Original proof re-run: pass/fail · Variant tried: result · Status update for Joshua · Disclosure state (program process only)
