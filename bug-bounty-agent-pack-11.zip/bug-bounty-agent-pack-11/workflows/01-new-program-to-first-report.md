# Workflow — New Program → First Report

Day 0: dossier + scope gate (Phase 0) + intel (docs/06). Day 1: threat model + passive recon. Day 2: surface map + fingerprints + CVE matrix v1. Day 3: ledger ≥10 rows. Days 4–5: validate top 5 by cost. Then report (Phase 4) and debrief (Phase 5) — even if the 'finding' is a well-killed ledger; the debrief is the deliverable that compounds.

**Exit artefact:** the template named above, filed in the hunt folder, plus an updated hypothesis ledger.
