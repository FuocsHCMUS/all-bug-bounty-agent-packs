# Workflow — Writeup / CTF Mining Loop

Pick one writeup (≤20 min): extract primitive → technique card (`templates/12`) → search current targets for the same shape → ledger rows → lab-reproduce if the technique is new to you → validate in scope. Two writeups a week beats twenty skimmed.

**Exit artefact:** the template named above, filed in the hunt folder, plus an updated hypothesis ledger.
