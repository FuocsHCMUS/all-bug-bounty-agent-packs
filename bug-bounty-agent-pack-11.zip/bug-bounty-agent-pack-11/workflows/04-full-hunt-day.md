# Workflow — Full Hunt Day

09:00 scope/ledger review · 09:30 research block (CVE/writeups) · 11:00 validation block 1 · 13:00 differential-matrix block · 15:00 validation block 2 / chain review · 16:30 report drafting · 17:30 debrief: posture, learning note, flashcards, state update (`scripts/state.py`). No new hypotheses after 16:00 — depth over breadth late in the day.

**Exit artefact:** the template named above, filed in the hunt folder, plus an updated hypothesis ledger.
