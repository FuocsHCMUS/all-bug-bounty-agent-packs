# Workflow — Chain Sprint

1) Dump primitives inventory. 2) Pairwise: what does A unlock in B? 3) Sketch 3 chains on the canvas (`templates/13`). 4) Kill the impossible links on paper. 5) Validate the surviving chain link-by-link, own accounts. Half a day, scheduled whenever ≥3 primitives sit unchained.

**Exit artefact:** the template named above, filed in the hunt folder, plus an updated hypothesis ledger.
