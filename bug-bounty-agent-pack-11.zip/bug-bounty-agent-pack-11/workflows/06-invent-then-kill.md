# Workflow — Invent-Then-Kill

30 minutes, timer on: write 10 hypotheses using the seven generators (docs/05) — wildness mandatory, feasibility banned from discussion. Then switch to Validator role: for each, name the cheapest test that would *kill* it. Run kill-tests in cost order. Survivors graduate to the ledger as priority rows. This workflow is the pack's answer to 'guardrails kill creativity': creativity gets a protected half-hour, then rigour gets its turn.

**Exit artefact:** the template named above, filed in the hunt folder, plus an updated hypothesis ledger.
