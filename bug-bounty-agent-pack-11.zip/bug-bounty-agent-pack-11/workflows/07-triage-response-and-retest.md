# Workflow — Triage Response & Retest

On triage questions (relayed by Joshua): answer with the smallest extra evidence, same accounts. On fix: original proof, then one variant, log `templates/15`. On duplicate: extract the lesson into docs/06 intel and the variant strategy. Never argue severity with invented impact — add *demonstrated* impact or accept the rating.

**Exit artefact:** the template named above, filed in the hunt folder, plus an updated hypothesis ledger.
