# Workflow — Learn After Finding (Debrief Loop)

Per finding/near-miss: posture note (`templates/09`) → learning note (`templates/10`, tutor ladder L1–L5) → one flashcard set (`scripts/learning_card.py`, Day 1/3/7/21) → one lab chosen to practise the root concept → skill matrix update (`learning/04`). Weekly: `templates/15` is for retests; the weekly retro lives in `templates/08-hunt-notes.md` §Retro.

**Exit artefact:** the template named above, filed in the hunt folder, plus an updated hypothesis ledger.
