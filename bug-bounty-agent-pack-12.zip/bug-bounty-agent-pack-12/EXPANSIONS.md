# EXPANSIONS — ideas added beyond Joshua's original brief
(Per Joshua's standing rule: expansions are listed after the build.)
1. **Preservation:** old pack-18 kept as `bug-bounty-agent-pack-18-v1-successor-15/`.
2. **Creative Offensive Thinking Engine** (core/09): the 7 generators +
   90-minute session protocol, synthesised from 6 source packs + new
   invent-then-kill discipline.
3. **Hypothesis Ledger as a mandatory Phase 2** with its own template (09) —
   no testing without written hypotheses.
4. **Minimal-ROE explainer** (core/12): documents exactly which guardrail
   text was removed, what was kept, and why (platform enforcement).
5. **Three new playbooks**: OAuth/OIDC/SSO/passkeys (17), chaining at scale
   (18), WebSocket/realtime (20); CVE-diffing (19) grafted from pack 16.
6. **Two new workflows**: chain sprint (08), invent-then-kill (09).
7. **Two new scripts**: `cvss_calc.py` (correct CVSS 3.1, replaces pack 16's
   broken cvss.py) and `learning_card.py` (spaced-repetition cards).
8. **Evidence manifest template** (16) with SHA-256 hashes.
9. **Cursor 4th rule + Antigravity chain-sprint workflow** for parity.
10. **configs/ YAML set** (scope/engagement/tool-policy) from pack 16, so
    hunts can be machine-checked by scope_guard.
