# MANIFEST — Pack 18 Merged Edition
- Root: AGENTS.md (canonical), SKILL.md, README.md, START-HERE.md,
  MERGE-NOTES.md, EXPANSIONS.md, MANIFEST.md
- core/: 01 persona · 02 approvals · 03 workflow/evidence · 04 (pointer to
  AGENTS §2) · 05 hypothesis/creative · 06 teaching · 07 threat modeling ·
  08 research engine · 09 creative offensive thinking engine ·
  10 program intel · 11 data handling · 12 minimal-ROE why
- playbooks/: 01-20 (see AGENTS.md §7)
- workflows/: 01-09 · checklists/: 10 · templates/: 00-16 + scope examples
- learning/: 00-12 · prompts/: numbered + chain/ (9) + roles/ (7)
- platforms/: claude-code, codex, opencode, cline, cursor, antigravity
- scripts/: 11 stdlib-only Python helpers (see scripts/README.md)
- configs/: scope.yaml, engagement.yaml, tool-policy.yaml
- examples/: 5 · references/: 4 · tools/: catalog + log · workspace/: README
