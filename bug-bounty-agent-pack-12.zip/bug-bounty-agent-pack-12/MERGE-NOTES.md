# MERGE-NOTES — Pack 18 Merged Edition: provenance

Sources: uploaded originals of packs 10, 11, 12, 13, 14, 15, 16, merged onto
the previous pack-18 (v1, successor-to-15) skeleton, which is preserved
untouched as `bug-bounty-agent-pack-18-v1-successor-15/` + `.zip`.

| Pack | Best ideas kept | Where they landed |
|---|---|---|
| 10 | Foundations-from-zero, program intel/duplicate avoidance, research engine, creative R&D lab, tutor ladder, severity honesty, evidence hygiene; race/API/GraphQL/WS/cloud/mobile/AI playbooks; scope.example.json | core/08, core/10, core/11, playbooks (base set), templates/scope.example.json |
| 11 | Flat senior-pentester framing, creative exploitation essay, company security assessment, student learning notes, PROMPT.md brevity | core/09 sources, templates/05 posture lineage, examples/example-learning-note.md |
| 12 | 6 role-agent prompts + master orchestrator, research source catalog, OWASP-WSTG checklist lineage, vuln-classes-explained-simply | prompts/roles/, references/source-catalog.md |
| 13 | Knowledge trio (creative/CVE/threat-model), SOC blue-team lens, tech_fingerprint, workspace scope.yaml pattern | core/08+09 sources, learning/05, scripts/tech_fingerprint.py |
| 14 | Deep-dive docs structure, per-class checklists (web/API/auth/business-logic), platform report variants (HackerOne/Bugcrowd), posture template, filled scope example | checklists/per-class-*.md, templates/13+14, templates/scope.example.yaml |
| 15 | Core persona/approvals/workflow files, 12 playbooks, fictional end-to-end example, 3-tier approval protocol | core/01-03, playbooks/01-12, AGENTS.md §3 |
| 16 (original upload) | Sequential prompt chain 00-08, YAML configs (scope/engagement/tool-policy), compact knowledge base (DNS/TLS, authN/authZ, CVE/CVSS/CWE), 12-week curriculum, skill matrix, lab targets, cve-diffing playbook, cve_match.py, state.py, cve-matrix.csv | prompts/chain/, configs/, learning/07-12, playbooks/19, scripts/, templates/15 |
| 18 v1 | Threat-model-first Phase 0.5, client-side + deserialization playbooks, disclosure/retest playbook, spaced-repetition checklist, chain canvas + threat model templates, inventory.py | skeleton throughout |

## Deliberately dropped / replaced
- **All repeated safety/legal/ethics chapters** (11's SAFETY file, 12 pb-01,
  13 pb-00, 14 doc-01, 15 core-04, 16 safety/ + configs ROE, v1 core-04
  duplication) → consolidated into AGENTS.md §2 + core/12 (the programs' own
  ROE only). Rationale in core/12.
- **CLAUDE.md** (all packs) → dropped; Claude Code reads AGENTS.md natively.
- Pack 16's `cvss.py` (crashed on --help) → rewritten as `scripts/cvss_calc.py`.
- Pack 16's `probe.py` (duplicated http_probe), `scope_pull.py` (fragile
  platform scraping), `report_build.py` (layout-specific) → not carried over;
  functions covered by http_probe / templates.
- Near-duplicate playbooks across packs → one canonical playbook per topic,
  best version kept, unique sections folded in.
