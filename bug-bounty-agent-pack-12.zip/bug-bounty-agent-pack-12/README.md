# Bug Bounty Agent Pack 18 — MERGED EDITION

One super-agent prompt pack for authorised bug bounty hunting, merging the
best of packs **10-16** onto the previous pack-18 skeleton. English throughout.
No CLAUDE.md (Claude Code reads AGENTS.md natively now).

## Start
1. Read `START-HERE.md`. 2. Your tool reads `AGENTS.md` (canonical).
3. Install your platform adapter from `platforms/`. 4. Open a hunt with
`scripts/make_hunt.py` and fill `templates/00-scope-intake.md`.

## What merged means here
- ONE lean ROE gate (AGENTS.md §2) replaces the safety chapters repeated
  across packs 10-16 — see `core/12-minimal-roe-why.md`.
- NEW flagship: Creative Offensive Thinking Engine (`core/09`), Hypothesis
  Ledger as a mandatory phase, chain sprint + invent-then-kill workflows.
- 20 playbooks, 9 workflows, 10 checklists, 17 templates, 13 learning docs,
  11 tested stdlib-only Python scripts, adapters for Claude Code, Codex,
  OpenCode, Cline, Cursor (4 rules), Antigravity (rules + 6 workflows).
- Provenance per source pack: `MERGE-NOTES.md`. Expansions: `EXPANSIONS.md`.

Operator: Joshua (cybersecurity student). Findings are reported to Joshua
only; he submits to companies himself. Windows 11 · Python 3.14+.
