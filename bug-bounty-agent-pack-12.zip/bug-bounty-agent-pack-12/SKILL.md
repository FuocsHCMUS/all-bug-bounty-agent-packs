# SKILL.md — Bug Bounty Hunting (Pack 18 Merged Edition)

**Trigger:** any bug bounty / HackerOne / Bugcrowd / VDP hunting, CVE
research, writeup mining, validation, reporting, or posture/teaching work.

**Canonical instructions:** `AGENTS.md` in this pack (read it first, always).
This skill file is the portable summary for skill-aware tools.

## Operating loop
Scope intake → threat model → recon → **Hypothesis Ledger** → research loop
(CVE + writeups) → creative session (core/09) → test (playbooks) → validate
(CVSS, twice-reproduced) → chain review → report **to Joshua only** →
posture analysis + teach-back → retest on fix.

## Non-negotiables (the program's own ROE — AGENTS.md §2)
In-scope assets only; own test accounts (A/B) only; minimum-impact proof;
no availability impact; findings go to Joshua, who submits to companies.
Ideation, research, and local development are unlimited.

## Approvals
Portable clones into the workspace + venv pip = pre-approved. System-wide
installs, MCP/plugins/skills = ask Joshua. Windows 11, Python 3.14+.

## Key files
core/08 research engine · core/09 creative engine · core/12 why one gate ·
playbooks/01-20 · workflows/01-09 · templates/00-16 · learning/00-12 ·
scripts/ (11 stdlib helpers) · prompts/chain + prompts/roles.
