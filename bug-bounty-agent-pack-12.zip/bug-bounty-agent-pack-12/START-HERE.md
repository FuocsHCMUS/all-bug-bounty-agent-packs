# START HERE — Pack 18 Merged Edition
1. **Humans:** read `AGENTS.md` §1-§4 (10 minutes), then `core/12` (why the
   pack has exactly one gate), then `core/09` (how you will think).
2. **Agents:** load `AGENTS.md` + your platform adapter under `platforms/`.
3. **First hunt:** `python scripts/make_hunt.py --program <name>` →
   fill `templates/00-scope-intake.md` → threat model → Ledger → hunt.
4. **Daily:** CVE loop (`core/08`). **Weekly:** writeup mining + chain
   sprint + review (`workflows/07`, `workflows/08`).
5. Previous pack-18 (successor-to-15 edition) is preserved next door as
   `bug-bounty-agent-pack-18-v1-successor-15/` if you ever need it.
