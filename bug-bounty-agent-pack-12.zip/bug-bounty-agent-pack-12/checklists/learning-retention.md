# Checklist — Learning Retention (spaced repetition)

Finding bugs teaches once. Reviewing teaches permanently. This system turns
every hunt into durable skill for the operator.

## Flashcard format (append to `workspace/<program>/flashcards.md` or an Anki import file)
```
Q: <one precise question>
A: <short answer, max 3 lines>
Tags: #class-idor #target-acme #fundamental
Source: findings/<slug>/learning-notes.md
```
Rules: one fact per card; the question must be answerable from the
fundamental, not from memorising a payload; include at least one
"why does the fix work?" card per finding.

## Review intervals
Day 1 (same day as the finding) → Day 3 → Day 7 → Day 21 → monthly in
workflow 07. A card the operator answers wrong twice goes back to Day 1
AND the underlying concept is re-taught from rung 2 of the ladder (core 06).

## Per-finding checklist
- [ ] 3–5 cards written, tagged, sourced.
- [ ] 3 self-check questions answered by the operator (in his own words).
- [ ] Shaky concepts added to the dossier list.
- [ ] One safe lab linked for hands-on repetition (learning/06).

## Weekly check (workflow 07)
- [ ] Due cards reviewed.  [ ] Misses re-taught.  [ ] Deck pruned of
      cards that test trivia instead of understanding.
