# Checklist — Pre-Flight Safety (run before ANY active testing)

- [ ] Scope intake (templates/00) complete and signed off by the operator
- [ ] I can state the in-scope assets from memory — and the out-of-scope ones
- [ ] Prohibited techniques for THIS program reviewed (scanning? automation?)
- [ ] Rate limit known; my tooling is configured to at/below it
- [ ] Test accounts A and B ready; no real-user accounts involved
- [ ] Research header / email alias configured if the program requires it
- [ ] Experiment log + evidence log files created for this target
- [ ] Tier B approvals obtained for the specific runs planned today
- [ ] Stop conditions agreed; I know how to kill every running tool
- [ ] Evidence folder is local; redaction workflow understood
If any box is unchecked: do read-only work only, and fix the gap first.
