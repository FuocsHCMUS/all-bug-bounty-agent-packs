# Checklist — Recon & Testing Coverage (per target; mark N/A with a reason)

## Recon
- [ ] All in-scope hosts fingerprinted (tech + version evidence filed)
- [ ] API docs / OpenAPI / GraphQL schema located or confirmed absent
- [ ] JS bundles reviewed for endpoints, keys, feature flags
- [ ] Roles & account matrix built; own objects created and labelled per account
- [ ] Disclosed reports + known issues for this program reviewed
- [ ] CVE match sheets filed for every fingerprinted component

## Testing passes (each = hypotheses in the backlog, logged as experiments)
- [ ] Access control: horizontal, vertical, cross-tenant (A vs B, every object type)
- [ ] Auth: reset, email change, OAuth/SSO, MFA, session invalidation
- [ ] API: verb/content-type tricks, mass assignment, version downgrade, exports, pagination
- [ ] Inputs: XSS contexts, injection points, uploads, URL fetchers (SSRF), templates/renderers
- [ ] Logic: state-machine skips/repeats, money math, quotas, coupons, races (own objects)
- [ ] Platform: CORS/cache/redirect interplay where relevant; AI features if present (pb/11)
- [ ] Negatives recorded (tested-solid areas feed the posture analysis)
