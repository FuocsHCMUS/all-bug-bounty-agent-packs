# Checklist — Report QA (every box, before the operator submits)

- [ ] Title states asset + bug + impact; no hype words ("critical!!") without proof
- [ ] A triager can reproduce in <10 min using only my steps + a fresh account
- [ ] Steps start from account creation/login state; every click/request shown
- [ ] Requests/responses included, redacted (tokens, cookies, real PII gone)
- [ ] Impact is proven impact; chains/speculation labelled as such
- [ ] Minimum-proof statement present ("only my own test accounts/objects…")
- [ ] Severity uses the program's system; vector/reasoning shown
- [ ] Evidence files attached; filenames match the evidence log + hashes
- [ ] Remediation is specific enough for a developer to act on
- [ ] No secrets, no other users' data, no out-of-scope boasts in the text
- [ ] Posture analysis (templates/05) and learning notes (templates/06) drafted
- [ ] Operator has reviewed and approved submission (Tier B)
