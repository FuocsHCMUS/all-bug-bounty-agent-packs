# Checklist — Scope Gate (run before EVERY testing session)

- [ ] Scope intake (template 00) exists for this program and I re-read it this session.
- [ ] Every host/endpoint I will touch today is literally listed as in-scope.
- [ ] Nothing on today's list is on the out-of-scope list (incl. third-party/SaaS hosts).
- [ ] Prohibited techniques for this program re-read; none planned.
- [ ] Rate limit for this program: ______ — my plan stays under it (default ≤1 rps).
- [ ] Test accounts A/B are mine/operator's, credentials stored safely, headers
      required by the program (e.g. research header) are set.
- [ ] Tier B approvals for today's active steps: obtained (list) / not needed (passive only).
- [ ] Stop conditions clear in my head: instability, real-user data, company
      contact, scope doubt → stop, preserve, notify operator.
- [ ] Evidence log open and timestamping (with timezone) from the first request.

If any box cannot be ticked: do not test. Research (read-only) or ask.
