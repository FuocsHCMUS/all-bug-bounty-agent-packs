# Core 02 — Approval Protocol (Tools, Scripts, Downloads, Installs)

Canonical version is `AGENTS.md` §4. This file adds the worked examples.

## Decision table

| Action | Tier | Notes |
|---|---|---|
| Read program page, docs, NVD, GitHub advisories, writeups | A | Log sources in research notes |
| Write/edit any file inside the project | A | — |
| `git clone` a portable tool/repo into `./tools/<name>/` | A | Log URL + version in `tools/TOOLS-LOG.md` |
| Download a standalone/portable binary into `./tools/` | A | Verify publisher/checksum if provided; note it |
| Create venv + `pip install` libs for *your own* scripts | A | Pin in `scripts/requirements.txt` |
| Clone a writeup/CTF repo for reading | A | Reading ≠ running; running its PoC vs a target = B |
| Run *any* script/tool against a target (even 1 request scripts) | B | State target, request count, rate, purpose |
| Active scan / fuzz / brute force / wordlist attack | B | Plus: must be allowed by program rules |
| Run a third-party exploit PoC | B | Plus: read its code first, say what it does |
| System-wide install (installer, winget, global packages, services) | B | Offer the portable alternative first |
| Install MCP server / plugin / skill / extension | B | Name + why + source link; operator installs |
| Create accounts, submit reports, contact program/company | B | Operator identity only; drafts first |
| Upload evidence anywhere external | B | Redacted copy only, named destination |
| Out-of-scope asset, DoS, real-user data pull, persistence | C | Refuse — see AGENTS.md §2/§4 |

## Windows / Python specifics
- Python launcher: `py -3.14`. Venv: `py -3.14 -m venv .venv`, activate with
  `.venv\Scripts\Activate.ps1` (PowerShell) or `source .venv/Scripts/activate` (Git Bash).
- Prefer PowerShell-native commands; give the Git Bash/WSL equivalent when different.
- Paths in scripts must use `pathlib`, never hard-coded `C:\...`.
- If a tool needs Linux (some scanners), say so and propose WSL2 or a Docker
  option as a Tier B question — never silently install either.

## The Tier B ask format (copy this)
```
TIER-B REQUEST
What:    <tool/script + version + source>
Why:     <hypothesis it tests>
Target:  <exact in-scope hosts/endpoints>
Load:    <requests, rate, duration, wordlist size if any>
Risk:    <noise, WAF, data touched — and why it's minimum-impact>
Stop:    <how it stops; what you'll watch for>
```
Wait for an explicit yes. A yes covers that run only, not future runs.
