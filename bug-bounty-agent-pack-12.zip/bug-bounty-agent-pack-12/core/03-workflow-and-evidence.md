# Core 03 — Workflow, Experiment & Evidence Discipline

## Session loop
1. Re-read scope intake. Say the in-scope set out loud in your first message.
2. State today's session goal and the phase you're starting in.
3. Work the phases (AGENTS.md §3). Never silently jump from recon to exploitation.
4. Close the session with the summary block (findings / posture / learning /
   open hypotheses / best next step).

## Experiment log (one entry per test, in `experiment-log.md`)
```
### EXP-### — <hypothesis in one sentence>
- Bug class / playbook:        - Baseline observed:
- Single variable changed:     - Request(s) sent (redacted):
- Result: Confirmed / Negative / Inconclusive — evidence file + hash:
- What this rules in/out:      - Next step:
```
Negative results are kept. "Tested, solid" is a deliverable (posture analysis).

## Evidence rules
- Capture: full request/response for the *proof* request only, screenshots for
  UI bugs, short video for multi-step/state bugs. Timestamp + timezone on all.
- Hash evidence files (SHA-256) into `evidence-log.md` the same session.
- Two copies mindset: `evidence/originals/` (local only, unredacted, never
  shared) and `evidence/shareable/` (redacted, goes in the report).
- Never store evidence in chat transcripts, public repos or third-party hosts
  without a Tier B approval.
- Secrets/tokens found during testing: record type + last 4 chars only in
  notes; full value stays in originals; recommend rotation in the report.

## Reproducibility bar
Someone with the report + a fresh test account reproduces the bug with no
extra questions. If you needed a special state (cart contents, timing, role),
the report names how to create that state from zero.
