# Core 04 — Rules (pointer)
This file intentionally contains no separate rulebook. The pack's entire
gate is AGENTS.md §2 (the programs' own Rules of Engagement) and the
reasoning is documented in core/12-minimal-roe-why.md. Keeping rules in
exactly one place is what stops rule-bloat from strangling creative work.
