# Core 05 — Hypothesis & Creative Engine

How a senior turns "a big web app" into a ranked list of falsifiable bets,
and how genuinely new techniques are invented safely.

## 1. A hypothesis is a sentence, not a vibe

Format: **Because** [observed fact], **the system probably** [assumption/
behaviour], **so if I** [smallest test], **then** [observable result] **would
prove/disprove it**, with impact [X] if true.

Example: "Because the invoice PDF endpoint takes an `id` and the list endpoint
is tenant-filtered, the PDF endpoint probably relies on the same filter —
so if Account B requests Account A's invoice PDF id and gets a 200 with A's
marker data, broken object-level authorisation is proven; impact = cross-tenant
PII/financial exposure."

If you cannot write the sentence, you do not have a hypothesis yet — you have
curiosity. Curiosity goes in the dossier as a research question, not a test.

## 2. Ranking

Score each hypothesis 1–5 on: Impact if true, Likelihood (evidence-based),
Cost to test (requests, time, noise), Uniqueness (is every hunter testing this?
disclosed-report history says what?). Rank by (Impact × Likelihood) ÷ Cost,
then demote anything a scanner already covers well — your edge is human logic.

## 3. The creative engine — seven generators

1. **Assumption inversion:** list what developers assumed (IDs are unguessable,
   the frontend validates, only the UI calls this API, webhooks only come from
   the real sender, prices come from the server). Test each assumption.
2. **Feature interaction:** pair features that were built separately —
   export + sharing, coupons + refunds, file upload + profile rendering,
   SSO + account linking. Bugs live at the seams.
3. **Parser differentials:** two components parse the same input differently
   (proxy vs app, URL parsers, JSON/XML/multipart, Unicode normalisation).
   Feed both sides a disagreement and watch which one wins.
4. **State-machine abuse:** enumerate states and legal transitions; test every
   illegal transition, replay, skip, and out-of-order call (playbooks/05).
5. **Time & races:** anything checked-then-used (balance, inventory, OTP,
   one-time links) is a race candidate. Single-pair burst first, log precisely.
6. **Second-order storage:** input stored safely, then rendered/used unsafely
   elsewhere (admin panels, emails, PDFs, exports, logs, support tools).
   Always ask: "where does this string wake up later, and in whose browser/context?"
7. **Chain building:** a primitive is not an impact. Maintain a chain canvas
   (`templates/10-chain-canvas.md`): self-XSS + login CSRF, open redirect +
   OAuth, SSRF + metadata, IDOR-read + password-reset. Rate chains, test links
   one at a time, never assume the next link works.

## 4. Experiment discipline

Baseline → one variable → observation → verdict (Confirmed / Ruled out /
Inconclusive + why) → log entry. Inconclusive twice with different angles =
park it, note what evidence would un-park it, move on. Timebox creative
sessions (workflow 04): 90 minutes, then write up even if the answer is "no".

## 5. Novelty without recklessness

A "new technique" in this pack means: a new *combination, context, or bypass*
discovered by reasoning from first principles and proven with minimum impact.
It never means: running unreviewed exploit code at scale, weaponising a bug
against real users, or keeping a technique secret from the affected company.
Find → prove minimally → report to the operator → the operator reports →
the company patches. That loop is the whole point.
