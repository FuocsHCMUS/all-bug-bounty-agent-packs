# Core 06 — Teaching Protocol (Beginner-First, From the Root Up)

The operator is a cybersecurity student building fundamentals — networking
and security from the ground up, learning Cyber / Security / Pentest / SOC
by doing. Every learning artefact in this pack follows this protocol.

## 1. The ladder (never skip rungs)

1. **Everyday analogy** — one sentence a non-technical person would get.
2. **The fundamental** — the actual concept from zero: what a packet is,
   what HTTP request/response really are, what a cookie proves, what
   "server-side check" means. Define every term on first use.
3. **The normal, safe version** — how the feature *should* work, with a diagram
   or a step list. A beginner cannot spot "broken" before seeing "correct".
4. **The break** — exactly which assumption/check failed, in this finding.
5. **The exploit logic** — step by step, why each step works, tied back to rung 2.
6. **The fix** — the code/config change a developer would make, and why it works.
7. **The defender's view** — what a SOC analyst would see: logs, alerts,
   telemetry gaps (see `learning/05-soc-lens.md`).
8. **Check & practise** — 3 self-check questions (answers hidden at the bottom
   or in a fold), 1 safe lab (PortSwigger / HTB / TryHackMe / CTF) that
   teaches the same class, and 3–5 flashcards for the retention deck
   (`checklists/learning-retention.md`).

## 2. Rules

- **Comprehensive, not condensed.** The operator asked for detail: long,
  thick, clear explanations beat clever summaries. Length is welcome when
  every paragraph teaches something.
- **No unexplained jargon.** If a term is needed, define it inline the first
  time, then use it freely. Glossary additions go to `learning/02`.
- **Show the bytes when it helps.** A redacted real request/response from the
  hunt teaches more than ten paragraphs. Annotate it line by line.
- **Connect every concept sideways.** "This is the same trust-boundary idea as
  the SSRF last week, one layer down." The operator is building a graph, not
  a pile of facts.
- **Honest difficulty labels:** [Foundation] [Core] [Advanced] on each section,
  so the operator can re-read in passes without feeling lost.
- **Never condescend, never hand-wave.** "It's complicated" is banned;
  "here is the simple model first, then the complication" is the pattern.

## 3. Where teaching artefacts live

Per finding: `learning-notes.md` (template 06). Per concept reused across
findings: a technique card (template 08). Per week: review session
(workflow 07) that re-tests the operator with the self-check questions and
updates the "shaky concepts" list in the target dossier.
