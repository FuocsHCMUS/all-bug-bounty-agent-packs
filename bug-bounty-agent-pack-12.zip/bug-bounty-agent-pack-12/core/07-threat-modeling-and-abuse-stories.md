# Core 07 — Threat Modeling & Abuse Stories

Companion to `AGENTS.md` §12 and `templates/12-threat-model.md`.
Timebox: 20–40 minutes per target, before any active testing.

## 1. Why threat-model first (for the student operator)

Recon tells you what exists. A threat model tells you what *matters*.
Without one, hunters test whatever a scanner flags. With one, you test the
paths an actual attacker — who wants money, data, or access — would take,
in the order they would take them. That is also the order companies pay for.

## 2. The five questions (answer in writing)

1. **What are we protecting?** Crown jewels: payment flows, PII stores,
   credentials/session tokens, admin capabilities, tenant isolation,
   integrity of prices/balances, availability of the core service.
2. **Who might attack it, and as whom?** Anonymous internet user, free-tier
   user, paying user, malicious tenant, compromised integration, curious
   insider. Bug bounty mostly models the first four.
3. **Where are the trust boundaries?** Draw them (Mermaid is fine):
   browser ↔ CDN/WAF ↔ API ↔ internal services ↔ database; tenant A ↔ tenant B;
   user content ↔ rendering; uploads ↔ processing workers; us ↔ third-party
   webhooks/APIs; mobile app ↔ backend (the app is attacker-controlled —
   anything "checked in the app" is not checked at all).
4. **What must NEVER happen?** Invariants, written as sentences:
   "A user must never read another tenant's objects, even by guessing IDs."
   "A total must never be computed from client-supplied prices."
   "A password-reset token must never be usable twice, or by another account."
5. **How could it happen anyway?** One abuse story per invariant:
   "As a free user, I want tenant B's invoices. The list view filters by
   tenant — but the PDF export endpoint might not. I would test the export
   with B's known ID from my own tenant's data pattern…" Each abuse story
   becomes a Phase-4 hypothesis verbatim.

## 3. STRIDE as a checklist, not a religion

Walk each crown-jewel flow once with STRIDE: **S**poofing (can I act as
someone else?), **T**ampering (can I change data in transit/at rest?),
**R**epudiation (can I act without a log?), **I**nformation disclosure,
**D**enial of service (note it — usually out of scope to test, still worth
reporting as design risk), **E**levation of privilege. One line per letter
is enough; the goal is coverage, not paperwork.

## 4. Output & upkeep

Save as `workspace/<program>/threat-model.md`. Update it when recon reveals
a new feature, integration, or role — models rot fast. In the posture
analysis (template 05), add a short "threat model vs reality" section:
which invariants held, which broke, which were never tested.
