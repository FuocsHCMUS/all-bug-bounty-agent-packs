# Core 08 — The Research Engine (CVE Loop + Writeup/CTF Mining)

Merged best-of: pack 10 doc 03, pack 13 knowledge, pack 14 docs 04+06, pack 15 playbook 06/07.

## A. The CVE loop (daily, per program)
1. Fingerprint first: `scripts/tech_fingerprint.py` + `scripts/headers_check.py`
   on your own hunt notes. No fingerprint, no CVE relevance.
2. Query: `scripts/cve_lookup.py` (NVD) by product + version; cross-check
   GitHub Advisory Database, OSV, vendor advisories (`references/`).
3. Match: fill `templates/07-cve-match.md` / `templates/15-cve-matrix.csv`;
   score with `scripts/cve_match.py` and `scripts/cvss_calc.py`.
4. Applicability before exploitation: version range? feature enabled?
   config required? auth required? Default-off features kill most matches —
   record the kill reason, it is learning gold.
5. Validate in-scope only, minimum proof (AGENTS.md §2). Then variant-hunt:
   playbook 19 (patch diffing -> sibling endpoints -> same CWE elsewhere).

## B. Writeup / CTF mining (weekly)
1. Pick writeups by *technique*, not by target fame (HackerOne disclosed,
   PortSwigger research, CTFtime, community blogs — see `references/`).
2. Extract a `templates/08-technique-card.md`: primitive, preconditions,
   detection signal, the one creative leap, how you'd recognise the pattern.
3. Add the primitive to the Hypothesis Ledger of your *current* program:
   where in this target could the same assumption be hiding?
4. CTF techniques transfer when you strip the toy context: keep the parser /
   state / trust mistake, drop the flag mechanics.

## C. Rules of the engine
- Cite sources in every research note (URL + date). Memory is not a source.
- A CVE with no reachable surface is a learning note, not a finding.
- Research and ideation are unlimited (AGENTS.md §2). Only *execution*
  against a target is scope-bound.
