# Core 09 — Creative Offensive Thinking Engine (flagship, NEW in merged 18)

Merged best-of: pack 11 CREATIVE-EXPLOITATION, pack 12 playbook 08,
pack 13 knowledge/creative-exploitation, pack 14 doc 07, pack 15 playbook 08,
pack 16 prompts/05-technique-forge + 06-exploit-dev.

## Mindset
Hunt *primitives and broken assumptions*, not bug-class names. A bug class is
a label applied afterwards; the money is in the moment a developer assumption
meets a parser, a state machine, or a second system that disagrees with it.
Think like the system's most creative *user*, then like its laziest
*developer*, then like the *machine* that has to reconcile both.

## The 7 generators (run at least 3 per hunt session, log in the Ledger)
1. **Assumption inversion** — list what the feature assumes (input shape,
   order, count, identity, timing, encoding, ownership). Invert each one.
2. **Parser differentials** — two components parse the same bytes differently
   (proxy vs app, WAF vs framework, JSON vs form, URL decoders, Unicode).
   Feed the seam, not the surface.
3. **State-machine abuse** — draw the lifecycle (cart->pay->refund, invite->
   accept->revoke, draft->publish->archive). Test transitions out of order,
   twice, skipped, and after expiry. Races live here too.
4. **Second-order / stored-for-later** — data saved now, used dangerously
   later somewhere else (admin panel, export, email, webhook, PDF, search
   index). Follow your input through the whole company.
5. **Differential accounts** — Account A vs B vs anonymous vs stale session:
   same request, four identities, diff the responses. Most BOLA/IDOR and
   privilege bugs are visible only in the diff.
6. **Composition / chaining** — a low that unlocks a medium that unlocks a
   high. Keep a chain canvas (`templates/10-chain-canvas.md`) from day one;
   grade primitives by what they *enable*, not what they are.
7. **Invent-then-kill** — deliberately invent the wildest plausible attack,
   write it in the Ledger, then spend 15 minutes trying to *kill* it with
   evidence. Survivors become tests; corpses become learning notes.

## Session protocol (90 minutes)
- 0-15: generators 1+3 on one feature -> Ledger entries.
- 15-60: test survivors, differential accounts open the whole time.
- 60-80: generator 6 — can anything found today chain with anything old?
- 80-90: kill review, update Ledger, write one technique card.

## Anti-patterns
- Scanner-first hunting (noise, duplicates, no understanding).
- Payload bingo without a hypothesis ("spray and pray").
- Falling in love: a hypothesis you won't kill owns you.
- Novelty for its own sake: a boring IDOR that pays beats a beautiful
  theoretical chain that doesn't reproduce.
