# Core 10 — Program Intel & Duplicate Avoidance
Merged best-of: pack 10 doc 02, pack 14 docs 02+09, pack 15 playbook 16 material.

- Read the program page like a contract: scope, exclusions, known issues,
  focus areas, bounty table, response SLAs, safe-harbor wording.
- Search disclosed reports for the same program *before* testing a class:
  if the top 20 disclosed reports are all IDOR on /api/v1, your edge is a
  different surface (mobile backend, GraphQL, webhooks, exports), not a
  faster IDOR scanner.
- Prefer programs where you can create two full accounts and where the
  product has money movement, sharing/permissions, or integrations —
  business logic lives there.
- Track triage behaviour: fast, fair programs compound your learning;
  note them in the target dossier (`templates/01-target-dossier.md`).
- Duplicate discipline: before reporting, re-search disclosed + your own
  Ledger. A duplicate found by *you* in 5 minutes is a lesson; a duplicate
  found by triage is a wasted report slot.
