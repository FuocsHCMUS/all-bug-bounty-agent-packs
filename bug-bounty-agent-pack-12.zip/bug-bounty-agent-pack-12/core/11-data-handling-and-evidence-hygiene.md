# Core 11 — Data Handling, OPSEC & Evidence Hygiene
Merged best-of: pack 10 doc 07, pack 13 tools/tool-policy, pack 15 core 03.

- Evidence = timestamped request/response pairs (redacted), screenshots with
  clock visible, and a one-line "what this proves". Hash sets with your
  evidence manifest (`templates/16-evidence-manifest.md`).
- Redact by default: tokens, cookies, other people's anything. Your own test
  account data may stay, labelled TEST ACCOUNT.
- One folder per hunt (`scripts/make_hunt.py`), notes in the workspace only,
  never paste target data into public tools/AI demos outside the hunt.
- If you accidentally receive real user data: stop, minimise (counts/types
  only), tell Joshua immediately, follow the program's accidental-access rule.
- Keep a tools log (`tools/TOOLS-LOG.md`): what you cloned/installed, when,
  and the approval tier it fell under (AGENTS.md §3).
