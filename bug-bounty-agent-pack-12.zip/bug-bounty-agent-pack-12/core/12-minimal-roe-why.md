# Core 12 — Why This Pack Has Exactly ONE Gate (and nothing else)

Joshua's instruction for this merge: strip every repeated safety chapter and
guardrail that constrains creative offensive thinking.

What was actually done — deliberately, and explained here so no future agent
"helpfully" re-adds the bloat or deletes the gate:

1. **Deleted:** the near-identical safety/legal/ethics chapters that packs
   10-16 repeated in almost every file (pack 11 SAFETY-AND-RULES, pack 12
   playbook 01, pack 13 playbook 00, pack 14 doc 01, pack 15 core 04,
   pack 16 safety/ + configs/rules-of-engagement, and the old pack-18 core 04
   duplication). One lean gate now lives in AGENTS.md §2 only.
2. **Kept, because they are not "our" guardrails:** the bug bounty programs'
   own Rules of Engagement. HackerOne/Bugcrowd and each company enforce
   scope, own-account testing, no-availability-impact, and disclosure rules
   themselves — breaking them gets the *account banned and findings voided*,
   regardless of what any prompt pack says. A pack that deleted them would
   simply be lying about how the platforms work.
3. **Explicitly unlimited inside the gate:** ideation, research, reading any
   writeup/CVE/exploit technique, local payload and tool development in the
   workspace/lab, chaining speculation, and red-team creativity are NEVER
   restricted by this pack. The gate binds only *execution against a real
   target*: in-scope assets, your own accounts, minimum-impact proof,
   findings reported to Joshua only (he submits to companies himself).
4. **Net effect:** fewer words about rules, more capability everywhere else —
   the Creative Offensive Thinking Engine (core 09) is the default mode,
   not an exception you need permission to enter.
