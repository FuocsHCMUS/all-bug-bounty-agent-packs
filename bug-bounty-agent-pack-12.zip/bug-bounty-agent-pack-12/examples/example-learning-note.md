# Learning Note — Broken Access Control (IDOR)

**Date:** 2026-10-28 (example)
**Source hunt / program:** Fictional Example Shop — see examples/example-report-draft.md
**Related finding:** Broken Access Control on order details (fictional).

## 1. In one sentence
A website lets you see or change something that belongs to someone else, because it never checks whether it is yours.

## 2. Real-world analogy
A hotel gives you a room key, but the door to every room opens with any key. The front desk only *shows* you your own room number — but if you walk to another room and try the door, it opens anyway. The real check should be at the door, not just at the front desk.

## 3. Root concept — why does this exist?
Websites need two separate questions: "Who are you?" (authentication) and "May you do this?" (authorization). Login answers the first. Authorization must be answered again, on the server, for every single object and action — because the browser, the URL, and the UI are all under the user's control and cannot be trusted to enforce rules.

## 4. How it works, step by step
1. You log in. The server gives your browser a session cookie — your "hotel key."
2. You visit your order: the browser asks for order 1001.
3. The server should ask: "Is order 1001 owned by the user holding this cookie?" If yes, return it. If no, refuse.
4. In a correct system, step 3 happens on the server, every time, for every object — not just in the page that lists your orders.

## 5. How it breaks (root cause)
The developer checks authorization in the UI only ("only show the user their own orders in the list") and forgets the server check on the direct endpoint. An attacker skips the list and asks for the object directly, by ID. The server trusts the ID in the request.

## 6. How an attacker abuses it (in-scope example, own test accounts only)
With two test accounts you control, Account A creates an order, Account B requests Account A's order ID directly. If Account B sees Account A's data, the check is missing. In the fictional example, that is exactly what happened.

## 7. How to fix it
- Root-cause fix: Server-side ownership check on every object request: does this user own this object, or have the role for this action? Deny by default.
- Defense in depth: Non-sequential IDs, a shared authorization helper for all endpoints, and automated tests that try cross-account access for every object type.

## 8. What a SOC analyst looks for
- Logs / signals: One account requesting objects owned by many different users, especially with a high rate of failed-then-successful accesses, or sequential ID enumeration.
- Normal vs. suspicious: Normal = a user mostly accesses their own objects, with occasional failures (a mistyped link). Suspicious = one account touching dozens of other users' objects in minutes.
- Detection idea: Alert when one account successfully accesses objects owned by more than N different users in M minutes.

## 9. Related skills
- Pentesting: Access-control testing with two accounts — the most reliable, cheapest test in web pentesting.
- SOC / Defensive: Log analysis for enumeration and cross-account patterns; authorization design review.
- General Cyber: Authentication vs. authorization — the distinction behind a large share of real web bugs.

## 10. Practice next (safe lab only)
In a vulnerable lab you own, create two users and one object per user. Try to access User A's object as User B, by direct URL and by API. Success = you can explain, in your own words, which server check is missing and where it should be added.

## 11. Key terms defined
- Authentication: Proving who you are (login).
- Authorization: Checking what you are allowed to do, for this specific object and action.
- IDOR (Insecure Direct Object Reference): An object is accessed by an ID in the request, without a proper authorization check.
- Session cookie: A small token the browser stores so the server remembers who you are between requests.
