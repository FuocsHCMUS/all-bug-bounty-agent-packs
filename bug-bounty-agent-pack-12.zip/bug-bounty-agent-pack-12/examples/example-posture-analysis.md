# Example Posture Analysis (FICTIONAL — Acme Notes, teaching example)

- **Authorization architecture — Needs Improvement (Confidence: High).** Read endpoints enforced ownership, export endpoint did not. Pattern suggests per-endpoint hand-written checks instead of shared middleware. Systemic, not one-off.
- **Identity & access — Strength (Med).** Passkey support, sensible session expiry, MFA step-up on email change observed in own-account testing.
- **Patch management — Adequate (Med).** Two fingerprinted components were current; one library lagged one minor version with no applicable CVE (checked via doc 04 loop, discard logged).
- **Detection (SOC) — No Signal / Opportunity.** No challenge or outreach during slow, header-identified testing. The cross-account export pattern is very detectable in API logs — recommended as a detection use case in the report's defense-in-depth section.

**Top strength:** modern identity stack. **Top systemic risk:** inconsistent authorization checks on secondary endpoints (export, share, duplicate, print views are the usual blind spots). **Lesson for the student:** hunt the *variants* of a feature, not only the feature itself — bugs cluster where a second code path reaches the same object.
