# Example (FICTIONAL) — Chain Building Walkthrough

Invented target "NotesApp". All proof used the hunter's own two accounts.

## Primitives found (each too small alone)
- P1: Login page honours `?next=` open redirect to any absolute URL. (Info)
- P2: OAuth "connect calendar" flow returns the auth code to the `next`
  URL's host without re-validating it against the registered redirect URI
  list — spotted by reading the flow, not yet proven. (Speculative)
- P3: Session cookie lacks `SameSite` (observed). (Info/Low)

## Chain hypothesis (canvas, template 10)
```mermaid
flowchart LR
  A[Victim clicks crafted login link] --> B[P1 redirect]
  B --> C[P2: OAuth code leaks to attacker domain]
  C --> D[Attacker exchanges code] --> E[Victim account takeover]
```
Weakest link: P2 — everything depends on it. Test P2 FIRST, with the
hunter's own account as the "victim": complete the flow via a redirect
to a domain the hunter controls, see if his own code arrives there.

## Result (fictional)
P2 confirmed with own account only → chain is real end-to-end at the
proof-of-concept level, zero real users involved. Report: one chained
finding, end impact = account takeover, links listed with individual
severities, CVSS scored on the chain's proved impact (playbook 15 §3).

## Lessons filed
- Primitives are assets; keep the canvas current (workflow 04).
- Test the weakest link first — it saves hours.
- A chain report must prove each link; "and then presumably…" is not proof.
