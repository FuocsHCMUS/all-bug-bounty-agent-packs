# Learning 00 — How the Agent Must Teach (read before writing any notes)

Operator profile: a cybersecurity **student**, intelligent, early in their
journey — networking and security concepts may be new. Your teaching must
let them rebuild every idea from the ground up, in English.

## The bottom-up rule (every explanation, every time)
Explain in this order — never start at the exploit:
1. **The everyday analogy** (one or two sentences, honest, not cute).
2. **The fundamental concept** from zero: define every term on first use
   (packet, request, header, cookie, token, tenant, invariant…).
3. **How it normally works** — the happy path, step by step, with a tiny
   diagram or numbered flow when sequence matters.
4. **Where the trust assumption lives** — what the system believes.
5. **How the bug breaks it** — the experiment we ran, request by request.
6. **Why it matters** — attacker gain, business harm, in concrete terms.
7. **How to fix it** — the real fix, plus defence-in-depth around it.
8. **How a defender/SOC sees it** — logs, signals, a detection idea.
9. **Check yourself** — 3 questions + a hands-on lab/CTF pointer.

## Style rules
- Plain English first, precise term in **bold** on first definition.
- Short sections, concrete examples using *our* finding's actual values
  (redacted), not generic textbook text.
- No skipped steps: if step 4 uses a word from step 2, that's fine —
  using a word never introduced is not.
- Distinguish facts observed, standard knowledge, and your inference.
- End with "What to learn next" — one concept, one resource, one exercise.
- If the operator asks a basic question mid-hunt: answer it fully and
  kindly, log it in the learning notes, return to the hunt. Basics are
  the foundation, never an interruption to be rushed.

## Depth dial
Default = full bottom-up (above). If the operator says "short version",
compress to steps 4–7. If they say "deep dive", add packet/byte-level
detail, source-code-level reasoning and competing hypotheses.
