# Learning 01 — Foundations Curriculum (learn in this order, hunt in parallel)

Each block: concept → why a hunter cares → free practice. The agent should
link the current hunt to whichever block it illustrates.

## Block 1 — How the internet moves data
IP addresses & ports, DNS (A/AAAA/CNAME/TXT, resolution chain), TCP vs UDP,
TLS handshake in plain words, what a packet is.
*Hunter lens:* scope lives in DNS; SSRF/redirect/DNS bugs exploit this layer.
Practice: `nslookup`/`dig` your own domains; Wireshark on your own traffic.

## Block 2 — HTTP, the web's language
Request/response anatomy, methods & idempotency, status codes, headers,
cookies (attributes!), content types, caching, proxies (Burp as a
"listening post" between browser and server).
*Hunter lens:* 80% of web bugs are visible in raw HTTP. Learn to read it raw.
Practice: PortSwigger Web Security Academy (free) — HTTP basics labs.

## Block 3 — How web apps are built
Browser (HTML/CSS/JS, DOM, same-origin policy), frontend vs backend,
databases & SQL in one evening, sessions vs tokens, REST APIs returning JSON,
frameworks and what they auto-protect (and don't).
*Hunter lens:* you attack the gaps between layers and assumptions.
Practice: build a tiny Flask/Express app with login + one database table.

## Block 4 — Identity & access
Authentication vs authorisation, sessions, JWT structure, OAuth 2.0 flow,
password reset design, MFA, RBAC/tenancy models.
*Hunter lens:* playbooks/04 — the most consistently paid category (IDOR/BOLA).
Practice: PortSwigger access-control & authentication lab tracks.

## Block 5 — Core bug classes
Playbook 02, one class per week, Academy lab first, then hunt that class only.
Keep a personal "class card": root cause, tell-tale signs, my test steps, fix.

## Block 6 — The defender's chair (SOC/Blue Team literacy)
Logging & telemetry, SIEM in one paragraph, alert vs log vs metric, incident
response lifecycle, OWASP ASVS (what "good" looks like), NIST CSF functions.
*Hunter lens:* your posture analyses (templates/05) are written from here —
and many students get hired blue-side first; this dual view is a career asset.
Practice: read one public post-mortem per week; write its timeline yourself.

## Block 7 — Craft skills
Linux & Windows CLI fluency, Python for security (requests, parsing, small
tools — see `scripts/`), Git, reading other people's code, technical writing
(your reports *are* writing samples), and English disclosure communication.

## Suggested free resources (verify currency when used)
PortSwigger Web Security Academy · OWASP Testing Guide & ASVS · HackTheBox /
TryHackMe beginner paths · CTFtime (beginner CTFs) · "How HTTP Works"-style
primers · vendor docs for whatever stack a target uses.
