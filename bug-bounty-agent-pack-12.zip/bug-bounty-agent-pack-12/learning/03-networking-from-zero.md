# Learning 03 — Networking From Zero (for the student operator)

Read this before playbook 01 makes sense. Plain language, bottom-up.

## 1. What a network actually is
Computers send each other small chunks of data called **packets**. Every
packet needs: where it's from (source IP address), where it's going
(destination IP), and what conversation it belongs to (ports + protocol).
An **IP address** is a machine's address on the network; a **port** is a
numbered door on that machine ("port 443" is the usual HTTPS door).

## 2. DNS — the phone book
Names like `api.example.com` are for humans. **DNS** translates names to IPs.
Subdomains (`api.`, `admin.`, `staging.`) are separate names that may point
to different machines — which is why scope documents list them so carefully,
and why "related-looking" does NOT mean "in scope".

## 3. TCP, TLS, and the handshake in plain words
**TCP** makes packet delivery reliable and ordered. **TLS** wraps it in
encryption and proves (via certificates) that you're really talking to the
owner of that name. HTTPS = HTTP carried inside TLS. When you hunt, TLS
usually means you inspect traffic through a proxy (e.g. Burp Suite) using a
CA certificate YOUR browser trusts on YOUR machine — against in-scope targets.

## 4. The client is a liar (the most important idea in web security)
Your browser/phone app runs on a device the user fully controls. Anything
computed, validated, hidden, or "secured" only in the client can be changed
by the user. Servers must re-check everything. Half of all bug classes are
some version of: *the server believed the client.*

## 5. Addresses inside addresses
Packets contain IPs; HTTP inside them contains hostnames, paths, headers,
cookies. Firewalls, WAFs, and the application each read *different layers* —
parser differentials (core 05) live in the gaps between those readers.

## 6. What to practise
learning/06 labs: inspect your own traffic to a practice site, follow one
request from DNS lookup to TLS to HTTP response, and draw it. If you can
draw it, you understand it well enough to start hunting the layer above.
