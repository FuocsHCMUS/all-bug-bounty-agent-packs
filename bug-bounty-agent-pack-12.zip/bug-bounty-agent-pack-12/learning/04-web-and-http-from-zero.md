# Learning 04 — The Web & HTTP From Zero

Companion to learning/03. By the end you can read a raw request like a sentence.

## 1. One HTTP exchange, dissected
```
GET /invoices/123 HTTP/1.1            <- method + path + version
Host: app.example.com                 <- which site (one IP can host many)
Cookie: session=abc...                <- "who I am" — the server believes this
Accept: application/json

HTTP/1.1 200 OK                       <- status: 2xx ok, 3xx redirect, 4xx your fault, 5xx theirs
Content-Type: application/json
Set-Cookie: ...; HttpOnly; Secure     <- server telling the browser how to behave

{"id":123,"owner":"user-A","total":50}  <- the body: the actual data
```
Every line is a place a bug can live: methods can be swapped, paths contain
IDs (IDOR!), cookies carry identity, headers steer caches and CORS, the body
carries prices and roles that should never have been trusted from the client.

## 2. Sessions & identity
HTTP is **stateless** — it forgets you between requests. Cookies/tokens are
the memory. Whoever presents a valid session token IS that user, as far as
the server knows. That sentence explains session theft, fixation, and why
`HttpOnly` (JS can't read it) and `Secure` (HTTPS only) matter.

## 3. Same-origin, CORS, CSRF — three cousins, never confuse them
- **Same-Origin Policy:** a page may not *read* another origin's responses.
- **CORS:** the server's permission slip relaxing that read rule for named origins.
- **CSRF:** origins don't need to *read* — a malicious page can make your
  browser *send* a state-changing request with your cookies attached.
  Defences: SameSite cookies, CSRF tokens, checking Origin on writes.

## 4. The rendering side
HTML is instructions; the **DOM** is the live tree the browser builds;
JavaScript edits the DOM. If attacker text is inserted as HTML/JS instead
of inert text — that's XSS (playbooks 02/13). Browsers also store data
(localStorage, IndexedDB) — readable by any script on that origin.

## 5. APIs are just HTTP with less makeup
REST/JSON APIs, GraphQL (one endpoint, client-shaped queries), WebSockets
(a long-lived two-way pipe). The makeup changes; the questions never do:
*Who are you? Are you allowed this object? Should I trust this value?*
Those three questions, asked of every endpoint, are 80% of hunting.
