# Learning 05 — The SOC Lens (think like the defender who watches you hunt)

The operator studies SOC alongside pentest. Every attack in this pack has a
mirror image: the telemetry that would catch it. Learn both sides of each bug.

## 1. What a SOC actually sees
Logs (web/app/auth/database), alerts built from those logs (SIEM rules),
network telemetry (WAF, CDN, DNS), endpoint telemetry for internal systems.
An attack invisible in all four is either very quiet or the company is
blind there — posture analysis should say which, with evidence.

## 2. Attack → detection translation table (starter)
| Attack step | Telemetry that should exist | A detection idea |
|---|---|---|
| IDOR probing (sequential IDs) | App access logs w/ user+object IDs | Alert: one user requesting many distinct object IDs, high 403/404 ratio |
| Credential stuffing / brute force | Auth logs | Velocity + failure-rate alerting per IP/account/ASN |
| SSRF to metadata | Egress proxy / cloud flow logs | Alert on app servers reaching link-local/metadata addresses |
| XSS stored payload fires | CSP reports, WAF logs | CSP report-uri volume + WAF XSS signatures on stored fields |
| Race-condition abuse | App transaction logs | Same user: concurrent mutations on one resource inside 1s window |
| CVE exploit attempt | WAF/IPS, app error logs | Known exploit signatures + sudden 5xx spike on one endpoint |
| postMessage/DOM abuse | Almost nothing server-side | Be honest: client-side bugs are a detection blind spot; CSP + reporting is the main lever |

## 3. How to write the SOC section of a posture analysis
For the specific finding: (1) what logs would contain the proof —
name the fields; (2) did anything visibly react during testing (WAF block,
lockout, challenge) — observed only, don't guess their internal tooling;
(3) propose 2–3 detections in plain language a junior analyst could build;
(4) name the blind spot if there is one. Label guesses as guesses.

## 4. The mindset
Red finds the hole. Blue asks "would we know?" Purple — the role this pack
trains — does both in one document. A hunter who writes detections becomes
the kind of professional companies hire full-time.
