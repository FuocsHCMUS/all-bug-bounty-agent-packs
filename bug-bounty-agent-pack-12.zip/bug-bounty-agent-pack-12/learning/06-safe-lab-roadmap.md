# Learning 06 — Safe Lab Roadmap (practise where it's legal and free/cheap)

Rule: if it isn't a program in scope, a lab, or your own machine — don't test
it. These environments exist so you never need to break that rule to learn.

## Tier 1 — Web fundamentals (start here)
- **PortSwigger Web Security Academy** — free, best-in-class labs for every
  class in playbooks 02–05/13/14, with explanations. Do: SQLi, XSS (reflected/
  stored/DOM), authentication, access control, SSRF, business logic, race
  conditions, prototype pollution, deserialization.
- **OWASP Juice Shop** (run locally) — a deliberately vulnerable shop app;
  safe because it's yours. Great for A/B-account access-control practice.
- **DVWA / WebGoat** (local) — older, still useful for raw fundamentals.

## Tier 2 — Guided platforms
- **Hack The Box** (Starting Point first, then easy boxes) — networking,
  enumeration, and exploitation discipline.
- **TryHackMe** — beginner paths (Pre-Security → Jr Penetration Tester)
  that fill networking/Linux gaps from learning/03.
- **PentesterLab** — focused web exercises with code-level explanations.

## Tier 3 — CTF muscle
- **CTFtime** calendar; beginner-friendly recurring events; read writeups
  AFTER attempting (workflow 03's mining skill applies here too).
- Keep a personal technique-card file for CTF tricks — it merges with the
  hunt technique graph (playbook 07) over time.

## How labs connect to hunts
For every finding class you meet in a real program, do the matching lab the
same week (checklist: learning-retention). Lab = safe reps; hunt = real
judgement. Neither replaces the other.

## Local lab hygiene
Run vulnerable apps only on your own machine/VM, never exposed to the
internet, never on a network with other people's devices you don't own.
