# DNS and TLS — names, trust, and the records that leak

## DNS record types

| Type | Meaning | Hunter angle |
|---|---|---|
| A / AAAA | host -> IP | direct targets |
| CNAME | alias to another name | dangling = takeover |
| MX | mail server | SPF, mail spoofing |
| TXT | free text | SPF, DKIM, verification tokens |
| NS | delegation | dangling NS = full zone control |
| SOA | zone authority | admin contact, serial |
| CAA | allowed CAs | misconfig = cert issuance |

## Enumeration

Certificate Transparency logs are public and permanent. Every cert ever issued for a domain
is in `crt.sh` and Certspotter, including SANs the company forgot. That is passive recon
with zero packets to the target.

## Subdomain takeover

The chain: `dev.example.com` CNAMEs to `example.s3.amazonaws.com`. The bucket is deleted.
Anyone who creates that bucket now serves content on `dev.example.com`.

Confirm before claiming: resolve the CNAME, fetch it, look for the provider's "no such
bucket" string, then check whether the name is available. Do not claim a bucket on a live
program without noting it in the report.

## TLS

The handshake proves the server holds a key for the name, and derives session keys.

- **SAN** — the names in the cert. Leaks internal names.
- **Issuer** — Let's Encrypt means automated, which means a fast, forgetful pipeline.
- **Expiry** — an expired cert on an internal host is a finding of neglect, not usually a bug.
- **Pinning** — mobile clients pin; that is a bypass target, not a vuln itself.

## Why this matters for exploitation

TLS failures are trust failures. If the client accepts a wrong cert, or the app accepts a
`Host` header that does not match the cert, the boundary between "our domain" and "attacker
domain" collapses. That is how reset-link poisoning and cache poisoning work.
