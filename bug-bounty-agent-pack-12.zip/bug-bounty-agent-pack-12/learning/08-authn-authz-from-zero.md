# Authentication, authorization, sessions, tenancy

## Session

A session is a server-side record keyed by an opaque value in a cookie. The cookie is a
bearer token: whoever holds it is you. That is why `HttpOnly` (no JS read), `Secure`
(no cleartext), and rotation on login matter.

## Tokens

JWTs are `base64(header).base64(payload).signature`. The payload is readable, not secret.
Trust comes only from the signature check. Common failures: `alg: none` accepted, HMAC
verified with the public key, `kid` used in a file path, no `aud`/`iss` check, no expiry.

Opaque tokens are just session IDs with a different name. Same rules.

## Tenancy

Multi-tenant apps must derive the tenant from something the user cannot forge — usually a
session field or a signed claim — and must apply it to *every* query. The classic bug is
deriving the tenant correctly for the list endpoint and forgetting it on the detail endpoint,
which then looks up by global ID.

Test: two tenants, same object ID, every verb.

## Authorization models

- **RBAC** — roles to permissions. Test the matrix, not the happy path.
- **ABAC** — attributes (owner, department, region). Test attribute spoofing.
- **ReBAC** — relationships. Test relationship forgery (invite yourself, accept another's).

## The failure taxonomy

1. Missing check (no authz call at all).
2. Check on the wrong object (checks A, returns B).
3. Check on the client only (button hidden, endpoint open).
4. Check that trusts client input (header, body field, JWT claim).
5. Check applied to the list but not the detail, export, or bulk path.
6. Check that passes for a soft-deleted or re-created object.

## Why it pays

It needs no payload, survives WAFs, and the request looks legitimate. It is also the class
most often missed by automated scanners, which is exactly why a human with a matrix beats
a scanner here.
