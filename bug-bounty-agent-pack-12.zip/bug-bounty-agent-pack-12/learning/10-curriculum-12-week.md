# 12-week curriculum

Two hours a day. Every week ends with a lab you can show. Do not skip ahead; the order is the
dependency graph.

| Week | Theme | Lab | Done when |
|---|---|---|---|
| 1 | Networking: IP, TCP, DNS, HTTP | `curl -v` a site, read every header | you can explain each header |
| 2 | Burp/mitmproxy, raw requests | replay a login by hand | you can edit and resend without the browser |
| 3 | Authn vs authz | PortSwigger access control labs | all apprentice labs solved |
| 4 | IDOR/BOLA on two accounts | crAPI or juice-shop, two users | 5 authz bugs written up |
| 5 | Injection: SQLi, NoSQL | PortSwigger SQLi apprentice | blind boolean extraction by hand |
| 6 | XSS and DOM tracing | PortSwigger XSS apprentice | you can trace source to sink in devtools |
| 7 | SSRF, XXE, cloud metadata | PortSwigger SSRF + local IMDS mock | metadata read via SSRF |
| 8 | Request smuggling and cache | PortSwigger smuggling labs | one CL.TE solved |
| 9 | Recon at scale | subfinder + httpx + gowitness on a VDP | 50-host inventory with screenshots |
| 10 | CVE work | pick a recent CVE, diff the patch, build a PoC | PoC on a vulnerable docker image |
| 11 | Reporting | write 3 reports from your own findings | a peer reproduces from the doc alone |
| 12 | First real program | a wide VDP, 20 hours | one submitted report |

## Weekly rhythm

- 30 min reading (the `knowledge/` file for the theme)
- 60 min lab
- 30 min write-up in `notes/`

## Milestones

- Week 4: you can find authz bugs without a scanner.
- Week 8: you can break a parser.
- Week 12: you can write a report a triager accepts.

## Resources

PortSwigger Web Security Academy (free labs), OWASP WSTG, HackTricks, PayloadsAllTheThings,
juice-shop, crAPI, DVWA, `docker compose` on WSL2.
