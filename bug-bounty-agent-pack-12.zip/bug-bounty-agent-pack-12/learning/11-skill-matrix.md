# Skill matrix

Rate 0-3: 0 never done, 1 seen, 2 done with help, 3 done alone and reported.

| Skill | Rating | Evidence | Next drill |
|---|---|---|---|
| DNS and subdomain enumeration | 0 | | crt.sh on a VDP |
| HTTP raw request crafting | 0 | | replay a login in Burp |
| Authz matrix testing | 0 | | two-account IDOR sweep |
| SQLi boolean blind | 0 | | PortSwigger lab |
| DOM XSS tracing | 0 | | devtools source-to-sink |
| SSRF and IMDS | 0 | | mock metadata server |
| Request smuggling | 0 | | CL.TE lab |
| Patch diffing | 0 | | diff a CVE fix |
| Report writing | 0 | | peer review |
| Triage prediction | 0 | | self-triage 5 reports |

The agent updates this after every debrief. Only raise a rating with evidence.
