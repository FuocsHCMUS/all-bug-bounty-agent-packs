# Local lab targets

All local, all free, all safe.

- **juice-shop** — `docker run -p 3000:3000 bkimminich/juice-shop`. Broad, gamified.
- **crAPI** — `docker compose up` from the official repo. API-first, BOLA-heavy.
- **DVWA** — classic, low difficulty, good for injection basics.
- **PortSwigger Academy** — hosted labs, the best structured path. Apprentice first.
- **OWASP wrongsecrets** — secrets and cloud misconfig.
- **Vulnerable GraphQL** — `dvga`, for introspection and batching.
- **Kubernetes Goat** — cluster scenarios.
- **AD labs** — GOAD or `vulnerable-AD` if you go the internal route.

Rules: local only, no rate limits, break everything. Keep a `notes/` file per lab with the
payload and the root cause — the note is the point, not the flag.
