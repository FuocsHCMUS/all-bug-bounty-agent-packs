# Antigravity Workflow — Chain Sprint
Run workflows/08-chain-sprint.md from the pack root: lay out Ledger
primitives on templates/10-chain-canvas.md, test joins cheapest-first with
differential accounts, report survivors as one chained finding.
