# Workflow — /retest

Follow `workflows/07-weekly-review-and-retest.md` and
`playbooks/16-disclosure-retest-and-duplicates.md`.

1. Open `templates/11-retest-and-disclosure-log.md` for the finding.
2. Re-run the ORIGINAL proof steps exactly (Tier B approval for target traffic).
3. Run the regression variants listed in playbook 16 (encoding, method,
   sibling endpoint, second account role).
4. Verdict: Fixed / Partially fixed / Not fixed / Cannot verify — with evidence.
5. Draft the retest comment for the operator to post; never post it yourself.
