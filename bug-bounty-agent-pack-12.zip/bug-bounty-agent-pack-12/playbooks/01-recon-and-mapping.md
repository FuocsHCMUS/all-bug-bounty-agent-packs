# Playbook 01 — Recon & Surface Mapping

Goal: a trustworthy map of what exists, what it does, and where trust
boundaries sit — before testing anything.

## Phase A — Passive only (Tier A, no target traffic beyond normal browsing)
- Program/company research: product docs, developer/API docs, status page,
  engineering blog, changelog/release notes, public GitHub org, job posts
  (stack hints), acquisition news.
- Certificate Transparency (`crt.sh`) and public DNS for candidate hosts —
  **candidates are NOT in scope until checked against the scope file.**
- Search engines / URL archives (Wayback, Common Crawl index) for forgotten
  endpoints, old API versions, exposed docs (`/swagger`, `/.well-known/`).
- JS bundle & mobile app *store listing* review for API base URLs and feature hints.
- Disclosed-report search for this program: what bug classes paid before?

## Phase B — Active recon (Tier B, only if program allows scanning)
State tool, wordlist size, rate and duration in the Tier B ask. Typical order:
1. Host liveness + HTTP fingerprint for in-scope hosts only.
2. Content discovery with a *small, curated* wordlist before any big one.
3. Parameter discovery on interesting endpoints; API schema harvesting
   (OpenAPI/GraphQL introspection only where the program permits it).
4. Screenshots/notes per host into the target dossier.
Tools are operator-approved per run; portable clones live in `./tools/`.

## Surface mapping output (dossier, templates/01)
For each asset: purpose, tech/fingerprints (+ evidence), auth model, roles,
user-controlled inputs, state-changing actions, integrations/webhooks,
uploads, payments, PII types, and *invariants worth testing*.

## Beginner note (explain while you work)
Recon is cartography, not breaking in. Every later finding is usually
visible in embryo here: the forgotten staging host, the v1 API still live,
the admin feature exposed to a low role. Teach the operator to read a map.
