# Playbook 02 — Web Vulnerability Classes (test method, not payload dump)

For each class: understand the root cause → find the sink/source → baseline →
one-variable test → impact proof (minimum) → fix + detection note for the
learning notes. Payload craft comes from PortSwigger Web Security Academy
and the operator's proxy history — learn principles, don't spray lists.

| Class | Root cause to explain first | Core test idea | Honest impact framing |
|---|---|---|---|
| XSS (reflected/stored/DOM) | Untrusted data reaches a browser execution context without correct encoding | Trace data flow input→storage→render context (HTML/JS/URL/attr) | Whose browser? Self-only = low; stored+admin = high |
| SQLi / NoSQLi / ORM leaks | Query structure built from untrusted input | Error/boolean/time differences on one parameter; confirm with a benign extract (your own row) | Data class reachable, not "full DB" unless proven |
| SSRF | Server fetches attacker-influenced URL without allowlist/egress control | Your collaborator/canary URL first; internal reach only as program allows, metadata access = stop & report | Internal services reachable; cloud metadata = critical path |
| SSTI / code injection | Template/command built from input | Engine fingerprint via harmless math probes | Usually RCE-equivalent — minimal proof only |
| Path traversal / LFI | File path from input, no canonicalisation check | Read a known harmless file (`/etc/hostname`-class), never configs with secrets beyond proof | File classes reachable |
| File upload | Type/content/ storage/destination not enforced together | Your own benign file → then execution/access question | Stored XSS / RCE / overwrite, as proven |
| CSRF | State change relies on ambient cookies, no token/SameSite defence-in-depth | PoC page acting on *your own* account | Which state change, under which victim role |
| Open redirect | Redirect target from input, used in auth/trusted flows | Redirect to your domain; check OAuth interplay | Phishing/token theft chain value |
| CORS misconfig | Origin reflection + credentials on sensitive API | Your origin reading your own account data | Cross-site data theft from a logged-in victim |
| Cache poisoning/deception | Cache key vs origin response mismatch | Only on your own paths/accounts; stop if others could be affected | Shared impact — extra caution, program rules first |
| Request smuggling | Front/back-end disagree on message boundaries | Lab-grade caution; only where program explicitly allows | Potentially affects other users — Tier B + explicit allowance |
| Deserialisation / XXE | Untrusted structured data parsed with dangerous features | Parser fingerprint; harmless external entity to your canary (XXE) | File read / SSRF / code exec as proven |
| Info disclosure | Verbose errors, debug endpoints, backups, secrets in JS/git | Read-only checks on in-scope hosts | Sensitivity of the actual data class |

## Rules for every row
- Baseline first; change one thing; log experiment (core/03).
- Never use another real user's session, data or browser as the victim.
  Victim = your Account B / your browser profile.
- If impact needs a chain, prove each link or label the unproven link.
