# Playbook 03 — API & GraphQL Testing

## First principles to teach
An API is a contract: client asks, server must re-check *who is asking,
what they may do, and whether the request makes business sense* on every
call. Most API bugs are the server trusting the app to have checked.

## Method
1. **Inventory:** base URLs, versions (v1/v2/mobile/legacy), docs/OpenAPI,
   GraphQL endpoint, auth scheme (cookie, bearer, API key, signed requests).
2. **Object map:** every object type + its ID format (sequential? UUID?
   prefixed?), ownership field, and which endpoints read/write it.
3. **Function map:** admin/privileged functions callable by low roles?
   Hidden params (mass assignment: `role`, `is_admin`, `price`, `owner_id`).
4. **Tests that pay:**
   - BOLA/IDOR on every object endpoint with Account A vs B (playbooks/04).
   - Verb tampering (GET↔POST↔PUT/PATCH/DELETE), content-type switching
     (JSON↔form↔XML), API version downgrade to legacy behaviour.
   - Pagination/filter/sort injection; export endpoints (CSV formula
     injection, over-broad exports); batch/bulk endpoints skipping checks.
   - Rate limits on sensitive actions (OTP, password reset, gift cards) —
     test gently, within program rules, on your own accounts only.
   - GraphQL: introspection exposure, field-level auth (nested objects),
     alias/batch abuse, query depth/cost, mutations reachable via GET/CSRF.
5. **Response analysis:** over-posting (responses leaking fields the UI
   never shows), error verbosity, timing differences for enumeration —
   prove enumeration only on your own test identifiers.

## Evidence
Record request pairs (A-allowed / B-denied-or-allowed) — the contrast *is*
the proof for access-control bugs. Redact tokens; note token types only.
