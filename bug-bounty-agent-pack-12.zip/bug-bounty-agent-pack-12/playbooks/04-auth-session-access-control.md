# Playbook 04 — Authentication, Session & Access Control

## Model first (teach this)
- **Authentication** = who are you? **Session** = how the server remembers.
- **Authorisation** = what may *this identity* do to *this object* now?
- Bugs live when any of the three is checked in the wrong place, once
  instead of always, or on the client instead of the server.

## Setup that makes everything else possible
Account matrix in the dossier: anonymous, A (free), B (free, second user),
paid/tenant-admin if the program provides them, same-tenant vs cross-tenant.
Label every object you create with owner + ID for later cross-account tests.

## Test families
- **Access control:** horizontal (A→B's object), vertical (user→admin
  function), tenant isolation, role change mid-session, forced browsing to
  privileged endpoints, method/parameter tricks from playbooks/03.
- **Auth flows:** password reset (token entropy/expiry/reuse, host-header
  poisoning of reset links, reset for Account A affecting B), email change
  without re-auth, OAuth/SSO (redirect_uri validation, state/nonce, account
  linking/pre-account-takeover, JWT: alg confusion, kid, weak secrets —
  verify against *your own* tokens only), MFA (bypass via flow skipping,
  backup codes, remember-me cookies, rate limits on OTP — own accounts).
- **Session:** token predictability, fixation, invalidation on logout /
  password change / role change, concurrent sessions, cookie flags
  (HttpOnly/Secure/SameSite — report as hardening unless exploitable),
  long-lived tokens in URLs/logs.
- **Account lifecycle:** signup with duplicate/Unicode/case-variant emails,
  invite flows accepting wrong tenants, deactivated accounts still working,
  deletion not deleting (privacy angle).

## Impact honesty
"Can read one other test user's profile name" ≠ account takeover. State
exactly which step toward ATO is proven and which is hypothetical chain.
