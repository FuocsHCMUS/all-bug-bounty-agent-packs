# Playbook 05 — Business Logic, State Machines & Race Conditions

The highest-value, least-scanner-detectable class — and the most creative.
Scanners check syntax; logic bugs break *meaning*.

## Method: model the business
1. Draw the state machine: order (cart→paid→shipped→refunded), subscription,
   wallet/credits, coupons, referrals, quotas, approvals, KYC steps.
2. Write invariants per transition ("refund ≤ paid amount, once, to payer").
3. Attack transitions: skip a step, repeat a step, do steps out of order,
   do a step as the wrong role/tenant, abandon mid-flow and resume, mix
   two flows in two tabs/sessions (TOCTOU thinking).

## Classic hunting grounds
- Money math: negative/zero/huge quantities, rounding & currency switching,
  price in client-supplied fields, discount stacking/reuse, gift-card loops.
- Limits: quota/rate/feature gates enforced in UI but not API; plan
  downgrade keeping paid features; trial resets.
- Races (own accounts/objects only, tiny request counts, program rules
  first): double-spend of coupon/balance, parallel approvals, like/vote/
  follow inflation that converts to money or trust, inventory oversell.
  Use single-packet-style minimal bursts, never load-like volumes.
- Workflow: approval by requester, password/email change races, webhook
  replay/forgery (missing signature, replay window, wrong-tenant webhook).
- Abuse economics: referral self-dealing, free-tier farming at scale is
  usually *abuse*, not a reportable vuln — frame as logic flaw with a
  concrete loss scenario or don't report.

## Documentation
Logic reports live or die on the invariant sentence + the exact sequence.
Include a small state diagram or numbered flow in the report, plus the
business loss in the company's own units (orders, credits, seats).
