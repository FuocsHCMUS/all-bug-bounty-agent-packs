# Playbook 07 — Mining Writeups, Disclosed Reports & CTFs

Goal: steal *patterns*, not payloads. One hour of reading often saves a
day of blind testing.

## Sources (read-only)
- HackerOne Hacktivity + disclosed reports; Bugcrowd Disclosure reports.
- PortSwigger Research (blog + Top 10 Web Hacking Techniques, yearly),
  Orange Tsai, James Kettle, Gareth Heyes, Frans Rosén, and similar
  practitioner research; conference talks (Black Hat, DEF CON, BSides).
- CTF writeups: CTFtime, team blogs, GitHub writeup repos — especially for
  parser bugs, crypto misuse, deserialisation, sandbox escapes, race logic.
- Target-specific: the program's own previously paid bug classes.

## Extraction protocol — one Technique Card per idea (templates/08)
1. **The primitive:** what capability did the researcher gain, in one line?
2. **Preconditions:** stack, feature, role, config needed. (Most techniques
   die here when moved targets — check before investing.)
3. **The false assumption:** what did the developers believe that wasn't true?
4. **The transfer:** where in *our* dossier does the same assumption appear?
5. **The safe test:** smallest experiment that would confirm/deny it here.
6. **Detection idea:** what log/signal would a SOC see? (feeds posture notes)

## Research hygiene
- Cite: title, author, date, URL, target/stack it was proven on.
- Separate "worked in a lab/CTF" from "worked in production elsewhere" from
  "should work here" — three different confidence levels.
- Beware survivorship bias: writeups show successes. Note base rates when
  ranking hypotheses; a famous technique is not automatically likely here.
- Keep a running `technique-cards/index.md` per program so future sessions
  (and future you) reuse the mining instead of redoing it.
