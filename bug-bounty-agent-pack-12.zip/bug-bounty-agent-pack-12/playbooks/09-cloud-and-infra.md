# Playbook 09 — Cloud & Infrastructure (light-touch, scope-critical)

Cloud assets are in scope **only when listed**. Cloud mistakes are common,
but "I found their provider" is not permission to probe the account.

## In-scope checks (read-mostly, minimum touch)
- Storage: public bucket/container policies surfaced from the app's own
  URLs; test with *your uploaded file's* URL patterns, never list others' data.
- Exposed services the program lists (staging APIs, Jenkins/GitLab/etc.):
  default credentials are usually a *prohibited* test — check program text;
  a login page being public is a posture note, not a finding by itself.
- SSRF → cloud metadata: see playbooks/02; reaching metadata = stop, report.
- Secrets in public places: company GitHub repos, JS bundles, mobile apps —
  report type + location; do not *use* a found key (using it = new access,
  needs explicit program allowance; default: don't).
- DNS: dangling CNAME / subdomain takeover candidates — prove with the
  provider's fingerprint page only; claiming a subdomain is an action many
  programs restrict: check rules, ask if unsure, remove claims after proof.
- TLS/config: expired certs, weak configs = hardening notes unless they
  enable a concrete attack in this app's threat model.

## Concepts to teach alongside
Shared-responsibility model, IAM least privilege, public-by-mistake vs
public-by-design, why metadata services are high-value (IMDSv1 vs v2),
and the SOC view: CloudTrail/GCP audit logs that would show this activity.
