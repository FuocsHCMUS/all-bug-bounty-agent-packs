# Playbook 10 — Mobile Apps (when the program lists them)

## Approach
The app is a client; the API is the target. Most mobile findings are API
bugs (playbooks/03/04) plus client-side storage/secrets issues.

- Obtain the app only from official stores / program links. Static review
  of *the program's own app* (strings, endpoints, embedded configs) is
  standard research; respect program rules on reverse engineering clauses.
- Map: API base URLs, pinning behaviour, deep links / app links (exported
  handlers accepting untrusted input), WebView settings, local storage of
  tokens, backup flags, clipboard/logging of sensitive data.
- Test deep-link → privileged action, WebView → JS bridge exposure, and
  every API call as Account A vs B (the server must not trust the app).
- Certificate pinning bypass / proxying your own device traffic: your
  device, your accounts. Some programs forbid instrumentation — check.
- Report client issues with device/OS/app version and reproduction on a
  stock device where possible.

## Teach alongside
Mobile trust model: "the device is enemy territory" — why servers must
re-validate everything, and what MDM/attestation can and cannot prove.
