# Playbook 11 — AI / LLM Features (modern attack surface)

Many programs now include chatbots, copilots, RAG search, AI agents with
tools. Treat the model as an *untrusted-input interpreter with privileges*.

## Map first
What can the AI read (docs, tickets, other tenants' data via RAG?), what
can it *do* (tools/plugins, code exec, browsing, email), whose identity
does it act with, and what guardrails are claimed?

## Test families (own accounts/data only)
- **Direct prompt injection:** instructions in your prompt overriding
  system behaviour — impact only counts if it crosses a boundary (data or action).
- **Indirect injection:** instructions hidden in content the AI ingests
  (your doc, your ticket, your web page it browses) that fire when a
  *victim context* processes it — victim = your Account B session.
- **Data leakage:** system-prompt extraction (usually low — frame honestly),
  cross-tenant RAG retrieval, training-data/regurgitation claims need proof.
- **Tool/agent abuse:** getting the agent to call tools with attacker-chosen
  arguments (SSRF via browsing tool, over-broad file/SQL access), approval
  steps that the model can be talked around.
- **Classic bugs in AI clothing:** the surrounding API still needs
  playbooks/03/04 — IDOR on conversation IDs is a top real-world finding.

## Framing
Report the *boundary crossed and data/action reached*, not "the chatbot
said a bad word". Content-policy slips alone are rarely in-scope security
findings; unauthorised data access via the model is.
