# Playbook 12 — Validation, Impact & Severity Honesty

## Validation gate (all must pass before reporting)
- [ ] Reproduces from a clean state, twice, following only my written steps.
- [ ] Not explained by caching, my own permissions, a feature, or intended behaviour (docs checked).
- [ ] Not a known issue / duplicate per program disclosures + search.
- [ ] Evidence is redacted-shareable + originals hashed and logged.
- [ ] Impact statement names: attacker preconditions, victim, data/action
      reached, scale *proven* (not extrapolated), business consequence.
- [ ] Scanner-only findings have been manually confirmed or discarded.

## Severity without inflation
- Use the program's system (CVSS / Bugcrowd VRT / internal) and show your
  vector + reasoning, but lead with the business story.
- Distinguish: proven impact / reasonably chained impact / speculative.
  Only the first sets the headline severity.
- Common downgrade traps to avoid claiming: self-XSS, logout CSRF, banner
  versions, missing headers alone, rate-limit absence on non-sensitive
  actions, "could phish" open redirects without a chain.

## Retest etiquette
After a fix: retest only the reported issue, on the program's invitation
or policy, confirm fix + check one obvious bypass variant, reply briefly.
Log the retest; update posture analysis if the fix reveals process insight
(fast fix + regression test = a "doing well" data point).
