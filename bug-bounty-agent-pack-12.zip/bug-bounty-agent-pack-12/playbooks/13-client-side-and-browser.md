# Playbook 13 — Client-Side & Browser Security (NEW in v18)

The browser is a trust boundary, not a display. Everything the server sends
can be read and changed by the user; everything a page *does* with data from
other origins, messages, or the DOM is attack surface.

## 0. Fundamentals first (teach these)
Origin (scheme+host+port), Same-Origin Policy, CORS (a *relaxation* of SOP
for reads, not authentication), CSP (an allowlist the browser enforces for
the page), cookies' `SameSite`/`HttpOnly`/`Secure`, and the DOM as a live
tree that code — including attacker strings — can reshape.

## 1. DOM-based XSS
- Sources: `location.*`, `document.URL`, `postMessage` data, `localStorage`,
  URL fragments. Sinks: `innerHTML`, `document.write`, `eval`, `setTimeout(string)`,
  jQuery `.html()`, framework "unsafe" APIs (`dangerouslySetInnerHTML`, `v-html`,
  Angular bypass helpers).
- Method: in your own browser/session, trace source→sink with benign markers
  first (`<b>marker</b>` rendering as HTML proves the sink; alert-box payloads
  only on your own session, per program rules).
- Stored-in-DOM variants: values saved in localStorage/IndexedDB by one page,
  rendered unsafely by another.

## 2. postMessage abuse
- Listeners with no `origin` check, or checks like `includes('trusted')`.
- Test from a page YOU control (local file / your own domain) sending a crafted
  message to the target tab; prove with your own session only.
- Impact framing: what action does the handler perform with message data?

## 3. CORS misconfiguration
- Reflected `Origin` + `Access-Control-Allow-Credentials: true` = cross-origin
  read of authenticated responses. Prove by fetching from your origin and
  reading YOUR OWN account's data cross-origin.
- `Origin: null`, subdomain wildcards, internal origins in the allowlist.
- Remember: CORS without credentials is usually informational, not a finding.

## 4. CSP analysis (as a weakness multiplier, rarely standalone)
- `unsafe-inline`/`unsafe-eval`, wildcard sources, JSONP endpoints on allowed
  origins, base-uri/form-action gaps. A weak CSP turns a minor HTML injection
  into full XSS — say exactly that, chained, in the report.

## 5. DOM clobbering, prototype pollution (client side)
- Named form/element IDs overwriting JS variables (`window.x`, form fields
  shadowing config). See playbook 14 for the pollution mechanics.
- Test with harmless sentinel values; observe config changes in your session.

## 6. XS-Leaks & browser side channels (advanced, low-noise only)
- Timing/frame-count/state leaks that reveal cross-origin information about
  YOUR OWN test accounts (e.g., "is this reset token valid" oracles).
- Keep request counts tiny; these are finesse bugs — log meticulously.

## 7. Web cache deception / poisoning (coordination with playbook 09)
- Cache key confusion on static-looking suffixes; prove only with your own
  account's benign marker page; never cache another user's real data.

## Reporting notes
Client-side findings die without a clear victim story: who clicks what,
whose session is affected, what the attacker gains. Self-XSS alone is
usually informational — find the delivery (CSRF, postMessage from any site,
stored source) or log it as a chain primitive on the canvas (template 10).
