# Playbook 14 — Deserialization, Prototype Pollution & Supply Chain (NEW in v18)

Three classes united by one idea: **the application trusts a data format to
describe objects — and the attacker gets to write the description.**

## Part A — Insecure deserialization

### Fundamentals
Serialization turns objects into bytes/text (JSON, XML, Java native, PHP
`serialize`, Python pickle, .NET formats). Deserialization rebuilds objects —
and some formats let the data dictate *which classes to build and which
magic methods to run*. If untrusted input reaches those, gadgets in the
app's libraries can chain into code execution or logic abuse.

### Recon signals
- Cookies/params that are base64 blobs starting with tell-tale magic:
  Java `rO0AB`, PHP `O:`/`a:`, Python pickle `gASV`/`\x80\x04`, .NET `AAEAAAD`.
- Content types: `application/x-java-serialized-object`, `application/x-php-serialized`.
- Frameworks known for risky loaders; error messages naming deserializers.

### Safe testing doctrine
- **Detection before exploitation:** use vendor/research *benign* checks —
  malformed-input error differentials, DNS-canary style callbacks ONLY where
  the program allows outbound-interaction testing and only to infrastructure
  you control for this hunt (Tier B, named in the ask).
- Never fire a public RCE PoC at a target as a first step. Version + config +
  error-behaviour evidence, reviewed exploit code, single proof, in that order
  (same doctrine as playbook 06 CVE matching).
- Logic-level wins are common and safer: type confusion, unexpected fields
  surviving deserialization into mass-assignment, auth objects rehydrated
  from client blobs (tamper your OWN session blob: role/expiry fields).

## Part B — Prototype pollution (JavaScript)

### Fundamentals
JS objects inherit from `Object.prototype`. If attacker JSON like
`{"__proto__": {"isAdmin": true}}` is deep-merged into an object, the
*pollution* changes defaults for every object afterwards. Client-side it can
flip config/security checks; server-side (Node) it can alter auth defaults,
disable protections, or reach code execution via polluted options.

### Testing
- Candidate inputs: JSON bodies merged server-side, query parsers (`qs`),
  config/settings endpoints, GraphQL variables.
- Prove harmlessly: pollute a sentinel property and observe it in YOUR OWN
  subsequent response/session. Never pollute a shared production property
  that affects other users — if the only proof does that, stop and report
  the code-path evidence to the operator for a careful Tier B decision.
- Client-side: sources from URL/JSON into merge utilities feeding DOM sinks
  (pairs with playbook 13).

## Part C — Supply chain & dependency angles (in-scope only)

### What counts in bug bounty
Only where the program scopes it: the company's public repos, their published
packages, their CI that builds in-scope products, or a demonstrable
dependency-confusion path against their build. Random upstream libraries are
those projects' programs, not this target's.

### Angles
- **Dependency confusion:** internal package names leaked in JS bundles /
  lockfiles / error pages, unclaimed on public registries. Report the *leak
  and claimability* evidence; do NOT publish a malicious package — registration
  squatting for proof is a Tier B conversation with the operator, and often
  the right report is purely documentary.
- **CI/CD:** exposed build logs, unsigned artefacts, mutable action tags in
  public workflows of in-scope repos — read-only research, report as design risk.
- **Version lag as intel:** public lockfiles/bundles reveal exact dependency
  versions → feed straight into the CVE pipeline (playbook 06).

## Teaching thread (for learning notes)
One root idea, three costumes: *data that describes code-shaped things must
be treated as code*. Connect to: JSON mass assignment (playbook 03),
template injection, and XXE (playbook 02) in the operator's notes.
