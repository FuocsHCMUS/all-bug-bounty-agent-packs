# Playbook 15 — Validation, Severity & CVSS (expanded in v18)

Extends playbook 12. A finding is a claim; this playbook is how the claim
survives a sceptical triager — and a sceptical future you.

## 1. Validation gauntlet (all must pass)
1. **Reproduce from clean state:** fresh session, documented steps, twice.
2. **Baseline contrast:** show the correct behaviour on a control object/
   account next to the broken one. Differentials convince; screenshots alone don't.
3. **Rule out the usual ghosts:** scanner false positive, intended feature
   (read the docs/changelog — really), test-environment-only behaviour,
   your own browser extensions/cache, a bug in your test script.
4. **Scope & rules re-check:** asset in scope, technique allowed, proof minimal.
5. **Impact honesty test:** write the impact sentence without the words
   "could potentially maybe". If you can't, the impact is speculative —
   label it that way or find the one safe rung higher (§2).

## 2. The impact ladder
Climb one rung at a time, stopping where proof would start harming:
read-own → read-other-test-account → modify-other-test-account →
cross-tenant (both accounts yours, different tenants you created) →
business consequence demonstrated on your own objects (price, balance,
state) → clearly-argued (not demonstrated) production consequence.
Report the rung you *reached* as fact and higher rungs as reasoned risk.

## 3. Severity & CVSS without the theatre
- Program severity (P1–P5 / VRT) is the language that pays; use the program's
  own taxonomy first (template 04), CVSS second, as supporting evidence.
- CVSS 3.1 vector: score what you PROVED. Attack complexity, privileges
  required, and user interaction are where hunters most often inflate —
  set them as the victim's reality, not the demo's convenience.
- CVSS 4.0 (when a program uses it): note the new supplemental metrics
  (safety, automatable, recovery) only if you can justify them in one line each.
- Chained findings: score the chain's end impact, list each link's individual
  severity separately. Never add scores together.
- Disagreement language that works: "We scored X because [concrete fact];
  if triage sees the precondition differently ([fact]), Y follows — happy
  to provide [specific extra evidence]." Facts, not pressure.

## 4. Duplicate & N/A armour (before you submit)
Search disclosed reports + the program's known-issues page for your bug
class + asset (research phase should already have this). If your variant
differs (different endpoint, bypass of their fix, different root cause),
say exactly how in the first paragraph — that sentence saves most duplicates.
