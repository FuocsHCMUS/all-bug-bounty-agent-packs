# Playbook 16 — Disclosure, Retest & Duplicates (NEW in v18)

The report is submitted (by the operator). The hunt is not over — how this
phase goes decides reputation, retests, and future invites.

## 1. Lifecycle states & your job in each
| State | Agent's job |
|---|---|
| Triaging | Answer clarification questions with evidence, fast and short. Draft replies for the operator to send. |
| Needs more info | Provide exactly what was asked + one notch more context; no new claims without new proof. |
| Duplicate | §3. Log what their original had that yours didn't; update research notes so the class/asset is pre-checked next time. |
| Resolved / fix deployed | §2 retest. |
| Disclosure requested | Only via the program's disclosure process; public writeups wait for approval + fix. The operator decides. |
| Bounty/severity dispute | Playbook 15 §3 language. One factual appeal, then accept. Reputation > one report. |

## 2. Retest protocol
1. Wait for the program to say the fix is live (or a stated deploy window).
2. Tier B ask: retest = target traffic, same minimal footprint.
3. Run the **original proof verbatim** — it must now fail.
4. Run **regression variants**: alternate encoding, HTTP method swap,
   sibling endpoints with the same pattern, the other role/tenant,
   the API version twin (v1 vs v2), mobile vs web path.
5. Verdict per variant: Fixed / Still works / Partially fixed (which layer
   was patched — WAF rule vs root-cause fix; say which, politely, with evidence).
6. Log in `templates/11-retest-and-disclosure-log.md`; draft the comment;
   operator posts it.

## 3. Duplicates — extract the value anyway
A duplicate still taught you: the class exists/existed here, triage speed,
severity calibration. Mine it: ask (via operator) whether the original's
scope covers your variant; file the technique card; add the asset+class to
the "already known" section of the dossier so future hunts skip it.
Never argue a duplicate that is genuinely the same root cause.

## 4. Disclosure etiquette
- Nothing public — no tweets, blogs, talks, or "redacted" screenshots —
  until the program approves disclosure in writing.
- Writeups after approval follow playbook 07's ethics in reverse: teach the
  technique, credit the program's fix, omit anything that endangers users
  who haven't patched downstream forks.
- The operator owns his public reputation; all external text is his to approve.

## 5. Closing the loop for learning
Every closed report gets a 10-minute retrospective in the learning notes:
what signal first pointed here, what wasted time, what the fix teaches
about secure design, and one flashcard. Workflow 07 runs this weekly.
