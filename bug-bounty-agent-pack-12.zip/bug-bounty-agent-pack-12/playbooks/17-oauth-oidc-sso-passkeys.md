# Playbook 17 — OAuth / OIDC / SSO / Passkeys (deep dive)
Merged best-of: pack 12 playbook 06, pack 16 knowledge 03 + playbooks/auth.

## Model first (from zero)
OAuth = delegation ("let this app act for me"), OIDC = OAuth + identity
(ID token), SSO = one identity provider, many apps, passkeys/WebAuthn =
public-key login bound to an origin. Every bug below is a broken *binding*:
between token and client, redirect and allowlist, identity and account,
challenge and origin.

## Test map
- redirect_uri: prefix/suffix/wildcard matching, open-redirect chaining,
  fragment vs query leakage, referer leakage of codes.
- state / nonce: missing, predictable, not bound to session -> login CSRF,
  account linking CSRF.
- Flow confusion: code vs implicit vs hybrid, PKCE downgrade (drop the
  verifier), token accepted at the wrong endpoint/audience.
- Account linking: link a social identity to a victim email, pre-account-
  takeover via unverified email change, IdP email trust.
- JWT: alg confusion (none / RS256->HS256 with public key), kid/jku/x5u
  injection, audience/issuer not verified, stale tokens after password reset.
- SSO/SAML: assertion signature wrapping, IdP-initiated vs SP-initiated
  confusion, tenant confusion in multi-tenant IdPs.
- Passkeys: registration to another account, challenge replay across
  origins (should fail — verify), downgrade to password reset paths.
## Proof discipline
Two accounts + your own IdP test tenant where possible. Never test against
another user's linked identity. Log every binding you checked in the Ledger,
including the ones that held — that list *is* the posture analysis.
