# Playbook 18 — Bug Chaining at Scale
Merged best-of: pack 10 docs 04, pack 14 doc 07, old pack-18 chain example.

## Grade primitives, not findings
Keep every confirmed primitive in the Ledger with: what it gives (read /
write / execute / impersonate / bypass), preconditions, and cost.
A stored XSS is "execute JS in admin context" — that phrasing chains;
"XSS" does not.

## Chain patterns that recur
- Self-XSS + login CSRF -> stored-in-admin. Open redirect + OAuth -> token
  theft. SSRF (metadata) + weak internal auth -> cloud keys -> data.
- IDOR read (export IDs) + IDOR write (share/transfer) -> full takeover.
- Race (coupon) + business logic (refund) -> money. Info leak (version) +
  CVE match -> known-exploit path (playbook 19).
- Password-reset token leak (referer/host header) + reset flow -> ATO.

## Method
1. Weekly: lay all open primitives on `templates/10-chain-canvas.md`.
2. Ask of each pair: does A's output satisfy B's precondition?
3. Test the *join* first (cheapest request), not the whole chain.
4. Report the chain as one finding with the full impact; also file the
   strongest single primitive separately only if the program prefers it.
## Severity honesty
A chain's CVSS is scored on the *final* impact with the *real* preconditions
of the first step. Do not score the last step as if it were unauthenticated
when step one required an account.
