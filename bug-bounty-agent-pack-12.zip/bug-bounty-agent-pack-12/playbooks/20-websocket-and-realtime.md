# Playbook 20 — WebSocket & Realtime Channels
Merged best-of: pack 10 playbook 10, pack 15 playbook 03.

## Model first
A WebSocket is a long-lived, stateful pipe: auth usually happens ONCE at the
handshake, then messages flow with implicit trust. That asymmetry is where
the bugs live. Same for SSE, socket.io, GraphQL subscriptions, gRPC-web.

## Test map
- Handshake auth: cookie-only? token in URL (logged!)? Origin checked?
  -> Cross-Site WebSocket Hijacking (CSWSH) if not.
- Post-connect authorisation: subscribe to another user's channel/room/topic;
  replay Account B's subscription IDs in Account A's socket.
- Message-level IDOR: change object IDs inside frames — servers often check
  REST authorisation but not frame handlers.
- State confusion: send messages out of order, before "join", after
  "leave/kick"; duplicate frames (race over a socket).
- Injection through frames: the payload a REST WAF blocks may sail through
  a frame into the same backend sink (parser differential, core 09).
- Scale/abuse: oversized frames, subscription floods — observe only within
  program rate rules; note the *absence* of limits as an observation,
  prove with a handful of messages, never a flood.
## Evidence
Log raw frames (timestamped, redacted), note handshake response, and which
identity each socket belonged to. Frame logs are your request/response pairs.
