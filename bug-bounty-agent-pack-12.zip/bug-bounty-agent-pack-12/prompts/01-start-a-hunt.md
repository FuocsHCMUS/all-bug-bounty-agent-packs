# Prompt 01 — Start a Hunt (copy, replace <…>, paste)

Using the Bug Bounty Super Agent Pack (read AGENTS.md first):
Start a hunt on <program name> (<platform>, <program URL>).
1. Build my scope intake from the official program page (read-only) and
   read the in-scope / out-of-scope sets back to me. No active testing yet.
2. Create workspace/<program-slug>/ with all templates.
3. Do Phase 1 passive research: target dossier, fingerprint list, CVE
   pre-sweep (match sheets), and 3–5 relevant disclosed reports/writeups
   turned into technique cards.
4. Give me a ranked hypothesis backlog and your proposed first three
   Tier B test runs (in the core/02 ask format) — then wait for my OK.
Teach as you go: explain each concept from the fundamentals up, in English.
