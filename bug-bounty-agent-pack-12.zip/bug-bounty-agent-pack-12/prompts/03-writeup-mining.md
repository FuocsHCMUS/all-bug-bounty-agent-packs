# Prompt 03 — Mine Writeups for This Target

Using playbooks/07: find 5 high-quality writeups / disclosed reports /
CTF solutions relevant to <target's stack or feature set>.
For each, file a technique card (templates/08): primitive, preconditions,
false assumption, where that assumption appears in our dossier, and the
smallest safe test. End with the 3 transfers most worth adding to the
hypothesis backlog, ranked, and explain the underlying concept of the
best one from first principles (learning/00 style).
