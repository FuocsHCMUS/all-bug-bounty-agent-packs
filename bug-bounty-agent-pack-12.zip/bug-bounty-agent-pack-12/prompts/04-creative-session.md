# Prompt 04 — Creative Technique Session

Run playbooks/08 against workspace/<program-slug>/'s dossier.
Use at least three idea generators (assumption inversion, feature
interaction, parser differentials, second-order, identity confusion,
chaining). Produce up to 7 candidate experiments — each with the
falsifiable hypothesis, predicted observable, baseline and single test —
added to the backlog and ranked. No target traffic until I approve the
specific runs (Tier B). Explain the most promising idea to me from the
fundamentals up, like a senior mentoring a student.
