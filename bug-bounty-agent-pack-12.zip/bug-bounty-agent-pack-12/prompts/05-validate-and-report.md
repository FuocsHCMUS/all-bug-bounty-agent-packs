# Prompt 05 — Validate & Draft a Report

I think I found something: <describe behaviour / paste experiment IDs>.
Work playbooks/12: try to disprove it first (feature? my permissions?
cache? known issue?), reproduce it cleanly twice from a fresh state,
then draft templates/03 (+ the platform variant from templates/04),
run checklists/report-qa.md out loud with me, and draft the posture
analysis (templates/05) and learning notes (templates/06).
Do NOT submit anything — draft only, I submit.
