# Prompt 06 — Teach Me This (post-finding / any concept)

Explain <finding or concept> to me using learning/00-how-to-teach.md:
analogy → fundamentals from zero (define every term) → how it normally
works → the trust assumption → how the bug breaks it (our real requests,
redacted) → impact → fix → what a SOC analyst would see → 3 self-check
questions with answers → one lab I can do this week. Save it as
learning notes (templates/06) in the target workspace. English, no
skipped steps — I am building my Cyber/Sec/Pentest/SOC foundations.
