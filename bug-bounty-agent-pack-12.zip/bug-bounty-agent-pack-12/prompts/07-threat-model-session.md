# Prompt 07 — Threat-Model Session (copy-paste)

Use after scope intake, before any testing (workflow 01, step 5).

---
Using this pack's AGENTS.md, run a threat-model session for [PROGRAM/TARGET].
Scope intake is at workspace/[slug]/00-scope-intake.md; dossier notes so far
are attached/pasted below.

Produce templates/12-threat-model.md in full: crown jewels ranked by business
value, actors with legitimate and explicit non-powers, a Mermaid trust-boundary
diagram, at least 6 invariants written as "must NEVER allow" sentences, and
one abuse story per invariant. Then convert the abuse stories into scored
hypotheses (core 05 format) and append them to the hypothesis backlog.
Teach as you go: explain trust boundary and invariant from zero in 5 lines each.
No target traffic in this session — research and reasoning only.
---
