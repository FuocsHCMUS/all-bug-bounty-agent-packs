# Prompt 08 — Retest Session (copy-paste)

Use when a program says a fix is live (playbook 16).

---
Using this pack's AGENTS.md, retest report [PLATFORM ID / TITLE] on [PROGRAM].
The original finding folder is workspace/[slug]/findings/[finding]/ and the
log is templates/11 format at workspace/[slug]/retest-disclosure-log.md.

First prepare the retest plan WITHOUT touching the target: original proof
steps verbatim, plus the regression variants from playbook 16 §2 (encoding,
method, sibling endpoints, other role, API twin). Then make ONE Tier B ask
covering the whole retest (requests, rate, duration). After my approval, run
it, log evidence, give the verdict (Fixed / Partially fixed / Not fixed /
Cannot verify), draft my retest comment, and update the learning notes with
what the fix teaches about secure design.
---
