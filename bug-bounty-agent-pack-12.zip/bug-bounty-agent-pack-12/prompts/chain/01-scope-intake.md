# S0/S1 — Intake and scope

Fetch the program page and the policy. Use `web_scrape`. If the page is JS-rendered, use the
platform's public JSON (`https://bugcrowd.com/engagements.json`, the HackerOne directory
GraphQL at `https://hackerone.com/graphql`) or `scripts/scope_pull.py`.

Extract verbatim, then normalize:

- program name, handle, policy URL, retrieval timestamp
- in-scope: hosts, wildcards, CIDRs, mobile packages, repos, APIs, cloud accounts
- out-of-scope: explicit exclusions, third parties, staging, marketing sites
- restrictions: banned tools, banned test types, required accounts, notification rules
- rewards, SLA, disclosure window

Write `configs/scope.yaml`. Mark anything ambiguous `needs_clarification` — do not resolve
ambiguity by assumption.

Then print the GATE block and stop. Show the scope file inline so the human can diff it
against the policy without opening anything.

Watch for: wildcard vs apex, `*.example.com` that excludes the apex, subdomains of
third-party SaaS, "all assets" phrasing that hides a linked-asset exclusion, mobile apps
listed but out of scope in a later paragraph.
