# S2 — Recon

Passive first. Every step writes to a file; nothing is only in the terminal.

Passive:
- CT logs: `crt.sh` JSON, `certspotter`. Collect SANs, including expired.
- DNS history: `securitytrails` (if key), `dnsdumpster`, `urlscan.io` search by domain.
- ASN and netblocks via `asnmap`; note if scope includes IPs.
- GitHub org and public repos: `gitleaks`, dork for `.env`, `*.pem`, CI configs.
- Wayback and `gau` for URL and parameter harvest; pull `.js` and grep for endpoints,
  GraphQL operations, feature flags, internal hostnames.
- `security.txt`, `robots.txt`, `sitemap.xml`, `/docs`, `/openapi.json`, `/swagger`.
- Job posts and public docs for stack names.
- Mobile: download the APK from the store, `apktool d`, grep strings and manifest.

Active, in scope only:
- `dnsx` resolve, `httpx -title -tech-detect -status-code -favicon -tls-grab`
- `gowitness` screenshots into `workspace/captures/shots/`
- `ffuf` content discovery with a small wordlist, 40 threads max
- `tlsx` for SAN expansion inside scope

Output `state/surface.json`:

```json
{"host":"api.example.com","ports":[443],"status":200,"tech":["nginx","express"],
 "tls":{"san":["api.example.com","*.example.com"],"issuer":"LE"},
 "auth":"bearer","tenancy":"multi","notes":"v2 and v3 both live"}
```

Gate: 5+ distinct in-scope hosts, or a documented reason. Then GATE block and stop.
