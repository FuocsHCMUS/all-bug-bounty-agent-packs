# S3 — Surface model

Turn hosts into trust boundaries. For each group, answer:

- Who can reach it (anon / user / admin / service / partner)?
- What data class sits behind it (public, PII, financial, config, secrets)?
- What is the tenancy model (single, multi, per-org)?
- What state machine exists (cart, order, invite, approval, KYC)?
- What third party is in the path (SSO, payment, email, CDN, queue)?
- What parses untrusted input (template, XML, YAML, archive, image, CSV, URL fetch)?

Draw the boundaries in ASCII in `notes/surface-model.md`. Mark every arrow that crosses a
trust level as a seam.

Then pick 3 seams and score them:

```
seam: <name>
likelihood: n/5   impact: n/5   cost: n/5   novelty: 1.0-1.5
score: <result>
why: <one sentence>
```

Gate: the model is readable in under 2 minutes and the top 3 are justified. GATE, stop.

Anti-pattern: a host list with no boundaries. That is S2 output, not S3.
