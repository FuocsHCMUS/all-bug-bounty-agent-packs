# S4c — Technique forge

The checklist is done. Now invent.

Method: take a known pattern, name the invariant it relies on, then break that invariant.

Invariant families to attack:
- **Identity** — "the ID in the URL belongs to the caller", "the tenant comes from the
  session", "the email is unique". Break with: second account, second tenant, case and
  unicode variants, `+alias`, trailing dot, ID reissue, soft-deleted objects.
- **State** — "step N implies step N-1", "coupon applies once", "refund after capture".
  Break with: out-of-order calls, replay, parallel duplicate requests (single-packet),
  interrupt mid-flow, negative and zero quantities, currency swap.
- **Parser** — "the proxy and the app parse the same bytes". Break with: `Transfer-Encoding`
  and `Content-Length` disagreement, H2 downgrade, duplicate keys, nested encoding, JSON
  with trailing garbage, unicode normalization, path with `..%2f`, double-decoding.
- **Cache** — "the cache key covers the varying input". Break with: unkeyed headers,
  parameter cloaking, fat GET, body-vs-URL confusion, normalization mismatch between edge
  and origin.
- **Trust handoff** — "the service trusts the internal caller". Break with: header injection
  from the edge, SSRF to the internal API, JWT `alg` swap, SAML signature wrapping, OAuth
  `redirect_uri` path tricks, cross-tenant service tokens.
- **Feature seam** — two features that each validate correctly but compose badly: SSO +
  email invite, export + share link, rename + cache, delete + async worker, import + path.

Differential testing: find two implementations of the same rule (web vs mobile API, v2 vs
v3, tenant A vs tenant B, staging vs prod) and look for the divergence. Divergence is a bug
in one of them.

For each idea, write a card from `templates/technique-card.md` with: invariant, hypothesis,
cheapest test, expected signal, verdict. Score novelty 1.0-1.5. Run the top 3 by score.
A failed technique is a finished card, not a failure.
