# S7 — Triage and report

First, self-triage. Answer all of these; if any is weak, fix it or downgrade the severity.

- Is it in scope, on the exact asset?
- Does it need a click, a non-default config, or an unlikely precondition?
- Is it self-XSS, a known duplicate, or documented behavior?
- Is the impact stated in data terms (records, tenants, money, tokens)?
- Can a stranger reproduce it from the report alone?
- Would a triager call this informational?

Then write with `templates/report-hackerone.md` or `templates/report-bugcrowd.md`.

Title formula: `[Class] on [asset] allows [impact]` — e.g. "IDOR on /v2/invoices allows
reading any tenant's billing PDFs".

CVSS: use 3.1 base, and add 4.0 if the program accepts it. Justify each metric in one
clause; do not inflate `A` or `C` without proof.

Sections in order: Summary (3 lines), Affected asset, Preconditions, Steps to reproduce
(numbered, with exact requests), Evidence (fenced request/response, redacted), Impact,
CVSS + vector, CWE, Remediation (specific and testable), Notes (variants, related endpoints).

Then produce the Vietnamese chat summary: 5 lines, impact first, severity, asset, and the
report path.

Never submit. Hand over.
