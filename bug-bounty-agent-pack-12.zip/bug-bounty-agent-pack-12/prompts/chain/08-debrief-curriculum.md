# S8 — Debrief and curriculum

No target traffic in this phase. Work from `state/` only.

Produce `notes/debriefs/<date>-<program>.md` using `templates/debrief.md`:

1. **Posture snapshot** — table of control areas (authn, authz, session, input handling,
   crypto, logging, cloud, SDLC, client) with a rating: strong / adequate / gap / risk /
   high risk, and the evidence that justifies the rating. Only rate what you touched.
2. **What they do well** — be specific. A good pattern here is worth teaching too.
3. **Gap analysis** — root cause per finding, not the symptom. "Missing object-level authz
   on the read path because the controller trusts the session tenant and the ID is passed
   straight to the ORM."
4. **Root concepts, from zero** — pick the underlying concept (e.g. how a session identifies
   a tenant, how an ORM builds a WHERE clause, what TLS actually authenticates) and explain
   it to someone who has never opened Wireshark. Define every term on first use. Use an
   everyday analogy, then the precise mechanism, then the failure mode.
5. **Local lab** — how to reproduce the class at home: PortSwigger Academy lab name, or a
   docker compose (juice-shop, DVWA, crAPI) with the exact steps.
6. **Skill targets** — 3 concrete next skills, each with a drill and a success criterion.
7. **Self-check** — 5 questions the student should be able to answer. Answers at the bottom.

Update `learning/skill-matrix.md`: raise any skill you demonstrated, and list what the
finding exposed as weak.

Rules: no filler, no "great job". Explain the concept, not just the bug. If the finding was
a duplicate, the debrief still happens — the concept is the deliverable.
