# References — Trusted Sources (verify on use; policies/content change)

## Programs & platforms
HackerOne (docs.hackerone.com, hackerone.com/hacktivity) · Bugcrowd
(bugcrowd.com, Vulnerability Rating Taxonomy on GitHub) · Intigriti ·
YesWeHack · the target program's own page (always the primary source).

## Vulnerability knowledge
NVD — nvd.nist.gov (CVE search + API v2) · CISA KEV catalogue ·
GitHub Advisory Database (github.com/advisories) · vendor security
advisories & release notes · Exploit-DB (read-only research) ·
MITRE CWE (weakness classes) · OWASP: Web Security Testing Guide,
API Security Top 10, ASVS, Cheat Sheet Series (owasp.org).

## Learning & research
PortSwigger Web Security Academy + Research blog (portswigger.net) ·
PortSwigger "Top 10 Web Hacking Techniques" (annual) · CTFtime
(ctftime.org) writeups · HackTheBox / TryHackMe beginner paths ·
HackerOne disclosed reports ("hacktivity" with the disclosed filter).

## Rules for citing
Cite full URL + access date in notes. Prefer vendor/NVD over blogs for
version facts; prefer primary writeups over aggregators for techniques.
If two sources disagree, say so and trust the vendor for patch facts.
