# References — Writeup & CTF Sources

For the mining workflow (workflow 03, playbook 07). Extract patterns, not payloads.

| Source | What lives there |
|---|---|
| HackerOne Hacktivity / disclosed reports | Real bugs, real targets, real triage outcomes — the single best pattern library |
| Bugcrowd disclosed reports / CrowdStream | Same, with VRT severity context |
| PortSwigger Research (Web Security Academy blog) | Deep technique research (races, parser differentials, prototype pollution, deserialization) with labs |
| Project Zero blog | Browser/OS-class research — advanced reading, mine for ideas not payloads |
| CTFtime (writeups tab) | CTF solutions by challenge — filter to web |
| GitHub `ctf-writeups` org & team repos | Full CTF writeup archives, searchable by technique |
| Conference talks (DEF CON, Black Hat, OWASP Global AppSec, local BSides) | New classes usually debut here 6–18 months before they're common knowledge |
| Vendor engineering / security blogs of the TARGET | How the target builds things — feature posts reveal architecture and assumptions |

## Mining discipline
- Date every card: techniques age; a 2016 bypass may be framework-fixed now.
- Record the FRAMEWORK/VERSION context of the original bug — transfer fails
  silently when the target's stack differs.
- Prefer primary writeups (the hunter's own) over summaries of summaries.
- If a writeup's technique needs tooling, log it in `tools/tool-catalog.md`
  style: portable (Tier A clone) vs install (Tier B ask).
