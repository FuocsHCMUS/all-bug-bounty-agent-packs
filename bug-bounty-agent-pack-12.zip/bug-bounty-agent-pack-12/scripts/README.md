# Scripts — Pack 18 Merged Edition (stdlib-only, Python 3.14+, Windows 11)
| Script | What it does | Touches a target? |
|---|---|---|
| scope_guard.py | Check a URL/host against a scope file (YAML/JSON) | No |
| inventory.py | Build an asset inventory from a subdomain list | No |
| headers_check.py | Security-header check (one GET) | Yes — in-scope only |
| http_probe.py | Lightweight HTTP probe — **dry-run by default** | Only with --live |
| tech_fingerprint.py | Fingerprint tech from headers/HTML | Yes — in-scope only |
| cve_lookup.py | CVE lookup via NVD by keyword/CVE ID | No (NVD only) |
| cve_match.py | Match a CVE list against a surface inventory (pack 16) | No |
| cvss_calc.py | CVSS 3.1 base score from a vector string | No |
| make_hunt.py | Create a hunt folder from the pack templates | No |
| state.py | Track hunt state across sessions (add/list/set) (pack 16) | No |
| learning_card.py | Generate a spaced-repetition learning card | No |
All scripts: `python <script>.py --help` works; no third-party dependencies.
