"""Match state/cves.json against state/surface.jsonl fingerprints.

  python scripts/cve_match.py -c state/cves.json -s state/surface.jsonl -o state/matrix.jsonl
Produces candidate rows for templates/cve-matrix.csv. Reachability is still manual.
"""
import argparse, json


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("-c", "--cves", required=True)
    ap.add_argument("-s", "--surface", required=True)
    ap.add_argument("-o", "--output", default="state/matrix.jsonl")
    a = ap.parse_args()

    cves = json.load(open(a.cves, encoding="utf-8"))
    kw = cves.get("keyword", "").lower()
    rows = []

    for line in open(a.surface, encoding="utf-8"):
        try:
            host = json.loads(line)
        except json.JSONDecodeError:
            continue
        blob = json.dumps(host).lower()
        if kw and kw not in blob:
            continue
        for src in ("nvd", "osv"):
            for c in cves.get(src, []):
                rows.append({"host": host.get("host"), "cve": c.get("id"),
                             "score": c.get("score", ""), "source": src,
                             "reachable": "unverified",
                             "summary": c.get("summary", "")[:200]})

    with open(a.output, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")
    print(f"{len(rows)} candidate pairs -> {a.output} (verify reachability by hand)")


if __name__ == "__main__":
    main()
