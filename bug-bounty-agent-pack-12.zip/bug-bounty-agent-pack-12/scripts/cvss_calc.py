#!/usr/bin/env python3
"""CVSS 3.1 base-score calculator (standard library only).

Usage:
  python cvss_calc.py "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"
  -> 9.8 Critical
Written for pack 18 because pack 16's cvss.py crashed on --help.
"""
import math, sys

VALS = {
    "AV": {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.20},
    "AC": {"L": 0.77, "H": 0.44},
    "UI": {"N": 0.85, "R": 0.62},
    "C": {"N": 0.0, "L": 0.22, "H": 0.56},
    "I": {"N": 0.0, "L": 0.22, "H": 0.56},
    "A": {"N": 0.0, "L": 0.22, "H": 0.56},
}
PR_U = {"N": 0.85, "L": 0.62, "H": 0.27}
PR_C = {"N": 0.85, "L": 0.68, "H": 0.50}

def roundup(x: float) -> float:
    i = int(round(x * 100000))
    if i % 10000 == 0:
        return i / 100000.0
    return (math.floor(i / 10000) + 1) / 10.0

def score(vector: str) -> float:
    parts = {}
    for tok in vector.replace("CVSS:3.1/", "").replace("CVSS:3.0/", "").split("/"):
        if ":" in tok:
            k, v = tok.split(":", 1); parts[k] = v
    scope = parts["S"]
    pr = (PR_U if scope == "U" else PR_C)[parts["PR"]]
    iss = 1 - (1 - VALS["C"][parts["C"]]) * (1 - VALS["I"][parts["I"]]) * (1 - VALS["A"][parts["A"]])
    if scope == "U":
        impact = 6.42 * iss
    else:
        impact = 7.52 * (iss - 0.029) - 3.25 * (iss - 0.02) ** 15
    expl = 8.22 * VALS["AV"][parts["AV"]] * VALS["AC"][parts["AC"]] * pr * VALS["UI"][parts["UI"]]
    if impact <= 0:
        return 0.0
    if scope == "U":
        return roundup(min(expl + impact, 10))
    return roundup(min(1.08 * (expl + impact), 10))

def severity(s: float) -> str:
    return ("None" if s == 0 else "Low" if s < 4 else "Medium" if s < 7
            else "High" if s < 9 else "Critical")

def main(argv):
    if len(argv) != 2 or argv[1] in ("-h", "--help"):
        print(__doc__.strip()); return 0
    s = score(argv[1])
    print(f"{s:.1f} {severity(s)}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
