#!/usr/bin/env python3
"""headers_check.py — inspect HTTP security headers for ONE URL.

Stdlib only (Python 3.14+, Windows 11 friendly).

SAFETY / APPROVAL: this makes a real GET request to the URL you pass.
Running it against a bug-bounty target is Tier B in this pack — get the
operator's approval first, confirm the host is in scope (scope_guard.py),
and keep it to a single request (this script sends exactly one).

Usage:
    py -3.14 headers_check.py https://example.com/
    py -3.14 headers_check.py https://example.com/ --timeout 15
"""
from __future__ import annotations

import argparse
import ssl
import sys
import urllib.request
import urllib.error

SECURITY_HEADERS = {
    "strict-transport-security": "HSTS — forces HTTPS for future visits",
    "content-security-policy": "CSP — allowlist for scripts/styles/etc.",
    "x-content-type-options": "Should be 'nosniff' — stops MIME sniffing",
    "referrer-policy": "Controls how much referrer leaks to other sites",
    "permissions-policy": "Restricts browser features (camera, mic, ...)",
    "cross-origin-opener-policy": "Isolates browsing contexts (tabnabbing class)",
    "x-frame-options": "Legacy clickjacking guard (CSP frame-ancestors is modern)",
}

COOKIE_FLAGS = ("Secure", "HttpOnly", "SameSite")


def fetch_headers(url: str, timeout: float) -> tuple[int, dict[str, str], list[str]]:
    ctx = ssl.create_default_context()
    req = urllib.request.Request(
        url, method="GET", headers={"User-Agent": "headers-check/18 (single request)"}
    )
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
        headers = {k.lower(): v for k, v in resp.headers.items()}
        cookies = resp.headers.get_all("Set-Cookie") or []
        return resp.status, headers, cookies


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Check security headers of one URL (1 GET request).")
    ap.add_argument("url", help="Full URL, e.g. https://example.com/")
    ap.add_argument("--timeout", type=float, default=10.0)
    args = ap.parse_args(argv)

    if not args.url.startswith(("http://", "https://")):
        print("ERROR: URL must start with http:// or https://", file=sys.stderr)
        return 2

    try:
        status, headers, cookies = fetch_headers(args.url, args.timeout)
    except urllib.error.URLError as exc:
        print(f"ERROR: request failed: {exc}", file=sys.stderr)
        return 1

    print(f"URL: {args.url}\nStatus: {status}\n")
    print("== Security headers ==")
    for name, desc in SECURITY_HEADERS.items():
        value = headers.get(name)
        mark = "PRESENT" if value else "MISSING"
        print(f"[{mark:7}] {name}: {value if value else '-'}")
        print(f"          ({desc})")
    print("\n== Server / tech signals (feed the CVE pipeline, workflow 02) ==")
    for name in ("server", "x-powered-by", "x-generator", "via"):
        if name in headers:
            print(f"{name}: {headers[name]}")
    print("\n== Cookies ==")
    if not cookies:
        print("(no Set-Cookie headers)")
    for cookie in cookies:
        missing = [f for f in COOKIE_FLAGS if f.lower() not in cookie.lower()]
        print(f"- {cookie.split(';', 1)[0]}")
        print(f"  missing flags: {', '.join(missing) if missing else 'none'}")
    print("\nNote: a MISSING header is a hardening observation, not automatically")
    print("a reportable vulnerability. Judge in context (playbook 15).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
