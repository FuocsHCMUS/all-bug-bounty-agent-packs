#!/usr/bin/env python3
"""
http_probe.py — Minimal, polite HTTP prober for IN-SCOPE hosts only.

- DRY-RUN by default: prints what it *would* request. Pass --run to actually send.
- Refuses to run unless every host passes scope_guard's allowlist (--scope file required with --run).
- GET/HEAD only, max 20 URLs, ~1 request/second, no redirects followed automatically beyond reporting them.
- Records status, key security headers and redirect target — a recon *note-taking* aid, not a scanner.

This is a Tier B tool in the pack's approval protocol: get the operator's OK for the exact run first.

Usage (Windows, Python 3.14):
    py -3.14 http_probe.py https://example.com/ https://example.com/login
    py -3.14 http_probe.py --run --scope scope.txt https://example.com/
"""
from __future__ import annotations
import argparse, sys, time, urllib.request, urllib.error
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from scope_guard import load_scope, host_of, in_scope  # reuse the pack's scope logic

WATCH_HEADERS = ["strict-transport-security", "content-security-policy", "x-content-type-options",
                 "x-frame-options", "referrer-policy", "permissions-policy", "server", "x-powered-by"]

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **kw):  # report redirects, don't chase them
        return None

def probe(url: str) -> str:
    req = urllib.request.Request(url, method="GET", headers={"User-Agent": "bug-bounty-pack-15/http_probe (authorised research)"})
    opener = urllib.request.build_opener(NoRedirect)
    try:
        with opener.open(req, timeout=15) as r:
            status, headers = r.status, r.headers
    except urllib.error.HTTPError as e:
        status, headers = e.code, e.headers
    except Exception as e:
        return f"{url}\n  ERROR: {e}"
    out = [f"{url}", f"  status: {status}"]
    for h in WATCH_HEADERS:
        if headers.get(h):
            out.append(f"  {h}: {headers[h][:160]}")
    if headers.get("Location"):
        out.append(f"  location: {headers['Location']}")
    out.append("  note: missing headers are hardening notes, not findings by themselves (see playbooks/12).")
    return "\n".join(out)

def main() -> int:
    ap = argparse.ArgumentParser(description="Polite in-scope HTTP prober (dry-run by default).")
    ap.add_argument("urls", nargs="+")
    ap.add_argument("--run", action="store_true", help="Actually send requests (default: dry-run)")
    ap.add_argument("--scope", help="Scope allowlist file (required with --run)")
    ap.add_argument("--delay", type=float, default=1.0, help="Seconds between requests (default 1.0)")
    args = ap.parse_args()
    if len(args.urls) > 20:
        print("Refusing >20 URLs per run — keep probes small and deliberate.", file=sys.stderr); return 2
    if not args.run:
        print("DRY-RUN (no requests sent). Would probe:")
        [print(f"  GET {u}") for u in args.urls]
        print("Re-run with --run --scope <file> after Tier B approval.")
        return 0
    if not args.scope:
        print("ERROR: --run requires --scope <allowlist file>.", file=sys.stderr); return 2
    suffix, exact = load_scope(Path(args.scope))
    for u in args.urls:
        if not in_scope(host_of(u), suffix, exact):
            print(f"REFUSED: {u} is out of scope per {args.scope}. Nothing sent.", file=sys.stderr); return 2
    for i, u in enumerate(args.urls):
        if i: time.sleep(max(args.delay, 0.5))
        print(probe(u)); print()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
