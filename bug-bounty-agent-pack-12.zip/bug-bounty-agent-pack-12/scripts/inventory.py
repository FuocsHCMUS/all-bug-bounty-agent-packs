#!/usr/bin/env python3
"""inventory.py — turn a plain asset list into a dossier-ready inventory table.

Offline only — makes NO network requests. Reads a text file with one host,
URL, or "host,note" per line, de-duplicates, sorts, and prints a Markdown
table you can paste into the target dossier, flagging entries that do not
match an optional scope pattern file.

Usage:
    py -3.14 inventory.py assets.txt
    py -3.14 inventory.py assets.txt --scope scope.txt
    py -3.14 inventory.py assets.txt --out inventory.md

Scope file: one allowed suffix per line, e.g.  example.com  or  *.example.com
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from urllib.parse import urlparse


def host_of(entry: str) -> str:
    entry = entry.strip()
    if "://" in entry:
        return (urlparse(entry).hostname or entry).lower()
    return entry.split("/", 1)[0].split(":", 1)[0].lower()


def in_scope(host: str, patterns: list[str]) -> bool:
    for pat in patterns:
        pat = pat.strip().lower().lstrip("*.")
        if host == pat or host.endswith("." + pat):
            return True
    return False


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Build a Markdown asset inventory from a list file (offline).")
    ap.add_argument("assets", type=Path, help="Text file, one asset per line ('host' or 'host,note')")
    ap.add_argument("--scope", type=Path, help="Optional scope suffix file to flag out-of-scope rows")
    ap.add_argument("--out", type=Path, help="Write Markdown here instead of stdout")
    args = ap.parse_args(argv)

    if not args.assets.exists():
        print(f"ERROR: not found: {args.assets}", file=sys.stderr)
        return 2
    patterns: list[str] = []
    if args.scope and args.scope.exists():
        patterns = [ln for ln in args.scope.read_text(encoding="utf-8").splitlines() if ln.strip()]

    rows: dict[str, str] = {}
    for line in args.assets.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        asset, _, note = line.partition(",")
        asset = asset.strip()
        rows.setdefault(host_of(asset), note.strip())

    lines = ["| Host | In scope? | Surface / role | Notes |", "|---|---|---|---|"]
    for host in sorted(rows):
        scope_cell = ("yes" if in_scope(host, patterns) else "CHECK") if patterns else "?"
        lines.append(f"| {host} | {scope_cell} |  | {rows[host]} |")
    lines.append(f"\n{len(rows)} unique hosts. 'CHECK' rows must be resolved against the")
    lines.append("program page by a human — this script does not decide scope.")
    output = "\n".join(lines) + "\n"

    if args.out:
        args.out.write_text(output, encoding="utf-8")
        print(f"Wrote {args.out} ({len(rows)} hosts)")
    else:
        print(output, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
