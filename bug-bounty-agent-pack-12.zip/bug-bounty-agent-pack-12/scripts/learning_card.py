#!/usr/bin/env python3
"""Generate a spaced-repetition learning card (Markdown) for a concept.
Standard library only. Review intervals: 1, 3, 7, 14, 30 days (core: learning/00).

Usage:
  python learning_card.py --concept "IDOR / BOLA" --front "Why does BOLA happen?" \
      --back "Server checks login but not object ownership." -o card.md
"""
import argparse
from datetime import date, timedelta

def main():
    ap = argparse.ArgumentParser(description="Create a spaced-repetition learning card.")
    ap.add_argument("--concept", required=True)
    ap.add_argument("--front", default="")
    ap.add_argument("--back", default="")
    ap.add_argument("-o", "--output", default=None)
    a = ap.parse_args()
    today = date.today()
    reviews = ", ".join(str(today + timedelta(days=d)) for d in (1, 3, 7, 14, 30))
    card = (f"# Learning Card — {a.concept}\n\n"
            f"**Front (question):** {a.front}\n\n"
            f"**Back (answer, from first principles):** {a.back}\n\n"
            f"**Created:** {today}\n**Review on:** {reviews}\n"
            f"**Rule:** explain it out loud in your own words at each review; "
            f"if you can't, the card resets to day 1.\n")
    if a.output:
        open(a.output, "w", encoding="utf-8").write(card)
        print(f"wrote {a.output}")
    else:
        print(card)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
