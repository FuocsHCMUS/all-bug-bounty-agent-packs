#!/usr/bin/env python3
"""
make_hunt.py — Scaffold workspace/<program-slug>/ from the pack templates.
Pure standard library, local files only, never touches the network.
    py -3.14 make_hunt.py "Example Program"
Creates the folder set + copies templates with their working names +
empty experiment/evidence logs, so a hunt starts organised (AGENTS.md §3).
"""
from __future__ import annotations
import re, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
COPIES = {
    "00-scope-intake.md": "00-scope-intake.md",
    "01-target-dossier.md": "01-target-dossier.md",
    "02-hypothesis-backlog.md": "hypotheses.md",
    "05-posture-analysis.md": "posture-analysis.md",
}

def slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "program"

def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__); return 2
    dest = ROOT / "workspace" / slugify(sys.argv[1])
    for sub in ("findings", "evidence/originals", "evidence/shareable", "technique-cards", "cve"):
        (dest / sub).mkdir(parents=True, exist_ok=True)
    for src, out in COPIES.items():
        target = dest / out
        if not target.exists():
            shutil.copy(ROOT / "templates" / src, target)
    for log, title in (("experiment-log.md", "# Experiment Log (see core/03)\n"),
                       ("evidence-log.md", "# Evidence Log — file | sha256 | date | notes\n")):
        p = dest / log
        if not p.exists():
            p.write_text(title, encoding="utf-8")
    print(f"Hunt workspace ready: {dest}")
    print("Next: complete 00-scope-intake.md. No scope = no testing.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
