#!/usr/bin/env python3
"""
scope_guard.py — Check URLs/hosts against a plain-text scope allowlist.

Part of Bug Bounty Agent Pack v15. Pure standard library. Python 3.14+ (Windows 11 friendly).

Usage:
    py -3.14 scope_guard.py --scope scope.txt https://api.example.com/path https://evil.test/
Scope file format (one entry per line, # = comment):
    example.com          -> matches example.com and any subdomain
    =exact.example.com   -> matches only that exact host
    *.api.example.com    -> treated like example.com-style suffix match for api.example.com
This tool NEVER contacts the network. Exit code 0 = all in scope, 2 = any out of scope.
"""
from __future__ import annotations
import argparse, sys
from pathlib import Path
from urllib.parse import urlparse

def load_scope(path: Path) -> tuple[list[str], list[str]]:
    suffix, exact = [], []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip().lower()
        if not line or line.startswith("#"):
            continue
        if line.startswith("="):
            exact.append(line[1:])
        else:
            suffix.append(line[2:] if line.startswith("*.") else line)
    return suffix, exact

def host_of(value: str) -> str:
    v = value.strip().lower()
    host = urlparse(v if "://" in v else f"//{v}").hostname or ""
    return host.rstrip(".")

def in_scope(host: str, suffix: list[str], exact: list[str]) -> bool:
    if host in exact:
        return True
    return any(host == s or host.endswith("." + s) for s in suffix)

def main() -> int:
    ap = argparse.ArgumentParser(description="Check hosts against a bug-bounty scope allowlist (offline).")
    ap.add_argument("--scope", required=True, help="Path to scope allowlist file")
    ap.add_argument("targets", nargs="+", help="URLs or hostnames to check")
    args = ap.parse_args()
    suffix, exact = load_scope(Path(args.scope))
    if not suffix and not exact:
        print("ERROR: scope file is empty — refusing to guess.", file=sys.stderr)
        return 2
    all_ok = True
    for t in args.targets:
        host = host_of(t)
        ok = bool(host) and in_scope(host, suffix, exact)
        all_ok &= ok
        print(f"{'IN-SCOPE ' if ok else 'OUT-OF-SCOPE'}  {host or t}")
    print("\nReminder: scope is defined by the program page, not by this file. When in doubt, STOP.")
    return 0 if all_ok else 2

if __name__ == "__main__":
    raise SystemExit(main())
