"""Append/query findings.jsonl. Stdlib only.

  python scripts/state.py add --title "IDOR on /invoices" --asset https://... --cwe CWE-639
  python scripts/state.py list --status open
  python scripts/state.py set F-001 status validated
"""
import argparse, json, pathlib, sys, time

F = pathlib.Path("state/findings.jsonl")


def read() -> list:
    if not F.exists():
        return []
    rows = []
    for line in F.read_text(encoding="utf-8").splitlines():
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    return rows


def next_id(rows: list) -> str:
    n = max([int(r["id"].split("-")[1]) for r in rows if r.get("id", "").startswith("F-")],
            default=0) + 1
    return f"F-{n:03d}"


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("add")
    for k in ("title", "asset", "cwe", "summary"):
        a.add_argument(f"--{k}", default="")
    a.add_argument("--confidence", default="hypothesis")

    l = sub.add_parser("list")
    l.add_argument("--status", default="open")

    s = sub.add_parser("set")
    s.add_argument("id")
    s.add_argument("key")
    s.add_argument("value")

    args = ap.parse_args()
    F.parent.mkdir(parents=True, exist_ok=True)
    rows = read()

    if args.cmd == "add":
        row = {"id": next_id(rows), "ts": time.time(), "status": "open",
               "confidence": args.confidence, "title": args.title,
               "asset": args.asset, "cwe": args.cwe, "summary": args.summary,
               "slug": args.title.lower().replace(" ", "-")[:40] or "finding"}
        with F.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row) + "\n")
        print(row["id"])
    elif args.cmd == "list":
        for r in rows:
            if r.get("status") == args.status:
                print(f'{r["id"]}  {r.get("confidence")}  {r.get("title")}')
    else:
        hit = [r for r in rows if r.get("id") == args.id]
        if not hit:
            sys.exit("not found")
        hit[0][args.key] = args.value
        F.write_text("\n".join(json.dumps(r) for r in rows) + "\n", encoding="utf-8")
        print(f'{args.id} {args.key}={args.value}')


if __name__ == "__main__":
    main()
