#!/usr/bin/env python3
"""tech_fingerprint.py — passive-ish tech fingerprint for ONE URL.

Sends exactly ONE GET request and reports signals useful for the CVE
pipeline (workflow 02): server banners, generator meta tags, common
framework cookies, and version-looking strings in the HTML/JS references.

Stdlib only. Tier B if the URL is a bug-bounty target (operator approval
+ scope check first). Works offline against a saved page with --file.

Usage:
    py -3.14 tech_fingerprint.py https://example.com/
    py -3.14 tech_fingerprint.py --file saved-page.html
"""
from __future__ import annotations

import argparse
import re
import ssl
import sys
import urllib.request
import urllib.error
from pathlib import Path

FRAMEWORK_COOKIES = {
    "phpsessid": "PHP", "jsessionid": "Java (servlet container)",
    "asp.net_sessionid": "ASP.NET", "csrftoken": "Django (likely)",
    "laravel_session": "Laravel", "wordpress_": "WordPress",
    "x-csrf-token": "Rails/Django-style CSRF cookie present",
}
VERSION_RE = re.compile(r"\b[a-zA-Z][a-zA-Z0-9._-]*(?:/|[-_.]v?)(\d+\.\d+(?:\.\d+)?)\b")
GENERATOR_RE = re.compile(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']([^"\']+)', re.I)
SCRIPT_RE = re.compile(r'<script[^>]+src=["\']([^"\']+)', re.I)


def analyse(html: str, headers: dict[str, str], cookies: list[str]) -> None:
    print("== Header signals ==")
    for name in ("server", "x-powered-by", "x-generator", "x-aspnet-version", "x-runtime"):
        if name in headers:
            print(f"{name}: {headers[name]}")
    gen = GENERATOR_RE.search(html)
    if gen:
        print(f"meta generator: {gen.group(1)}")
    print("\n== Cookie-based framework hints ==")
    found = False
    for cookie in cookies:
        low = cookie.lower()
        for needle, label in FRAMEWORK_COOKIES.items():
            if needle in low:
                print(f"{cookie.split('=', 1)[0]} -> {label}")
                found = True
    if not found:
        print("(none matched)")
    print("\n== Script / version-looking references ==")
    seen: set[str] = set()
    for src in SCRIPT_RE.findall(html)[:50]:
        for match in VERSION_RE.findall(src):
            token = f"{src}  [version-like: {match}]"
            if token not in seen:
                seen.add(token)
                print(token)
    if not seen:
        print("(no version-like tokens in script URLs)")
    print("\nReminder: fingerprints are LEADS. Confirm versions before any")
    print("CVE verdict (workflow 02, step 4). Banners can be faked or stripped.")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Fingerprint one URL (1 GET) or a saved HTML file (offline).")
    ap.add_argument("url", nargs="?", help="Full URL to fetch once")
    ap.add_argument("--file", type=Path, help="Analyse a saved HTML file instead (no network)")
    ap.add_argument("--timeout", type=float, default=10.0)
    args = ap.parse_args(argv)

    if args.file:
        html = args.file.read_text(encoding="utf-8", errors="replace")
        analyse(html, {}, [])
        return 0
    if not args.url or not args.url.startswith(("http://", "https://")):
        print("ERROR: give a full http(s) URL or --file <page.html>", file=sys.stderr)
        return 2
    ctx = ssl.create_default_context()
    req = urllib.request.Request(args.url, headers={"User-Agent": "tech-fingerprint/18 (single request)"})
    try:
        with urllib.request.urlopen(req, timeout=args.timeout, context=ctx) as resp:
            headers = {k.lower(): v for k, v in resp.headers.items()}
            cookies = resp.headers.get_all("Set-Cookie") or []
            body = resp.read(2_000_000).decode("utf-8", errors="replace")
    except urllib.error.URLError as exc:
        print(f"ERROR: request failed: {exc}", file=sys.stderr)
        return 1
    analyse(body, headers, cookies)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
