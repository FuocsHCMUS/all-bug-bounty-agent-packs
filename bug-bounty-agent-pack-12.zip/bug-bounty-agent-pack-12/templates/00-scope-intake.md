# Template 00 — Scope Intake (complete BEFORE any testing)

- Program name: / Platform + program URL:
- Researcher account / username: / Required research header or email alias:
- Date scope read: / Scope page archived at (local path/URL):

## In scope (copy exactly from the program)
| Asset | Type (web/API/mobile/cloud) | Notes / tiers |
|---|---|---|

## Out of scope (copy exactly)
| Asset/technique | Source line |
|---|---|

## Rules that change how I test
- Prohibited techniques: / Automated scanning allowed? (Y/N + wording):
- Rate limit: / Testing windows: / Test account rules:
- Data rules (what I may/may not access, deletion duties):
- Safe harbor wording (quote): / Disclosure policy:
- Severity system (CVSS/VRT/internal): / Duplicate & known-issues policy:
- Payout notes (only if relevant to effort decisions):

## My stop conditions for this program
1. 2. 3.
## Uncertainty log (things to ask the program before testing)
- [ ]
**Sign-off:** Operator confirmed this intake on <date>. No testing before this.
