# Template 02 — Hypothesis Backlog: <program>

Rank = (Impact 1–5 × Likelihood 1–5) ÷ Effort 1–5. Re-rank as evidence arrives.

| # | Hypothesis (falsifiable sentence) | Bug class / playbook | Invariant (dossier #) | Impact | Likely | Effort | Status |
|---|---|---|---|---|---|---|---|
| H1 | "As Account B I can read A's invoice by changing its ID" | BOLA / 03+04 | 1 | 4 | 3 | 1 | Open |

Status values: Open / Testing / Confirmed / Ruled out / Parked (why).
Primitives inventory (small capabilities already proven — chaining material):
- 
Dead ends worth remembering (tested, solid, one line each):
- 
