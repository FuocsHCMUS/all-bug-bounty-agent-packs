# Template 03 — Finding Report (platform-ready draft)

**Title:** [<Asset>] <Bug class> in <feature> allows <attacker role> to <impact>
**Program / asset:** / **Date:** / **Researcher accounts:** A (attacker) / B (victim) — both mine
**Suggested severity:** <program system> — score/vector + one-line justification

## Summary (3–5 lines: what, where, why it matters)
## Affected endpoint(s) & parameters
`METHOD /path` — params: / Required role/state:
## Background (only what a triager needs: the invariant that should hold)

## Steps to reproduce (from a clean account, numbered, copy-pasteable)
1. 2. 3.
### Request (redacted)
```http
```
### Response (redacted, relevant excerpt)
```http
```
## Impact (proven, in business terms)
Attacker preconditions: / Victim: / Data or action reached: / Proven scale:
What I did NOT do (minimum-proof statement): e.g. "I accessed only my second
test account's object; no real user data was accessed, altered or stored."

## Evidence
- Screenshots/video: (filenames) / SHA-256: (from evidence log)

## Remediation (specific, code-level where possible)
Primary fix: / Defence-in-depth: / Regression test idea:

## References (CVE / OWASP / writeup that explains the class)
## Timeline & disclosure note (testing dates, this report is private to the program)
