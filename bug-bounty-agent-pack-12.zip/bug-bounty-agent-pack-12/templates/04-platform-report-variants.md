# Template 04 — Platform Field Variants (use with Template 03)

## HackerOne
- Asset: pick the exact structured scope asset. Weakness: pick the closest
  CWE-type entry honestly. Severity: CVSS vector via their calculator.
- Put reproduction in numbered steps; attach redacted evidence files.
- Summary field = Template 03 Summary + Impact merged, business-first.

## Bugcrowd
- Target: exact target group name. Category: closest VRT entry — note the
  VRT's suggested priority and say if/why you believe it differs here.
- "Description" = Summary; "Proof of Concept" = Steps + requests.

## Intigriti / YesWeHack
- Domain/type fields exactly as their scope tiers name them; upload PoC
  evidence in their formats; state your test accounts in the report.

## Email / self-hosted VDP
Subject: [Security] <Title> — <asset>
Body: Template 03 in full + your contact + "Tested under your published
VDP on <dates>, using my own accounts, minimum-impact proof only."
Submission of any variant = Tier B (operator sends/approves).
