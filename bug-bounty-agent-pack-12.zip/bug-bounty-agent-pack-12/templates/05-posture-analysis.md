# Template 05 — Security Posture Analysis: <company / program>
Produced after every finding and at the end of every hunt (AGENTS.md §8).
Label every judgement: Observed (evidence) / Inferred (reasoning) / Guessed.

## Snapshot
Target & period: / Assets covered: / Findings so far: (count by severity)

## What they do WELL (strengths — name control + evidence for each)
| Control/strength | Evidence I observed | Why it matters |
|---|---|---|
e.g. "Consistent server-side authorisation on billing API" — "B-account
requests returned 403 across 14 endpoints (experiment log EXP-…)".

## What needs IMPROVEMENT (gaps that aren't (yet) findings)
| Gap | Evidence | Risk if unchanged | Suggested fix (effort S/M/L) |
|---|---|---|---|

## RISK register
| Risk | Likelihood | Impact | Basis | Trend/notes |
|---|---|---|---|---|
### High-risk patterns (call these out explicitly, or write "none observed")
- 

## Architecture & trust-boundary notes
Where checks live (edge/app/DB), tenancy isolation quality, secrets/config
hygiene observed, dependency & patch posture (from CVE match sheets),
third-party/integration risk, logging/monitoring *visibility* from outside.

## Defender / SOC perspective
- Would this attack be visible? Which logs/signals (auth, API, WAF, cloud)?
- Did anything visibly react during testing (blocks, alerts, lockouts)? (Observed)
- One concrete detection rule idea per major finding (plain-language logic).

## Maturity read (labelled inference — 1 paragraph)
Development security practices, response quality/speed so far, disclosure
handling — and what would change my mind.

## Prioritised recommendations (top 5, mapped plainly)
1. … (maps to: OWASP ASVS §… / NIST CSF function — explained in one line)

## What I could NOT assess from outside (honesty box)
Internal network, code quality beyond fingerprints, employee security,
incident history — black-box limits, listed so nobody over-reads this doc.
