# Template 06 — Learning Notes: <finding / hunt topic>
Follow `learning/00-how-to-teach.md` exactly. English, bottom-up.

## 1. The everyday analogy (2 sentences max)
## 2. Fundamentals from zero (define every new term in **bold**)
The smallest set of concepts needed: networking / HTTP / auth / data —
only what THIS topic needs, built in order.
## 3. How it normally works (happy path, numbered or small diagram)
## 4. The trust assumption (what the system believed)
## 5. The bug, step by step (our experiment, redacted requests, what changed)
## 6. Why it matters (attacker gain → business harm, concrete)
## 7. The fix (primary) + defence in depth
## 8. The defender's view (logs, signals, one detection idea, SOC takeaway)
## 9. Where this fits the bigger map (Pentest / SOC / Blue Team / careers)
## 10. Check yourself (3 questions)
1. 2. 3.
<details><summary>Answer key</summary> … </details>
## 11. Do it in a lab (one free lab/CTF link + what to notice while doing it)
## 12. What to learn next (one concept, one resource, one exercise)
