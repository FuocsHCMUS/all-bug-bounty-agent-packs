# Template 08 — Technique Card (from a writeup / disclosed report / CTF)
- Source: title / author / date / URL / proven on (stack/target type):
## The primitive (one line: what capability it grants)
## Preconditions (stack, feature, role, config)
## The false assumption it exploits
## Transfer to our target (where the same assumption appears — dossier ref)
## Smallest safe test (experiment draft; Tier B if it touches the target)
## Result when tried (or "not tried — why")
## Detection idea (what a SOC would see)
## Confidence: Lab-proven / Production-proven elsewhere / Speculative here
