# Template 09 — Hypothesis Ledger (MANDATORY, Phase 2 of every hunt)
| # | Hypothesis (one sentence) | Generator (core 09) | Assumption broken | Test (cheapest first) | Accounts | Result | Kill reason / Evidence | Priority |
|---|---|---|---|---|---|---|---|---|
| H1 |  |  |  |  | A/B/anon | open |  |  |
Rules: no target testing without Ledger rows; a hypothesis is only closed
with evidence (killed) or a finding link (confirmed). Review weekly.
