# Template 10 — Chain Canvas

Target / program: ______  Date: ______

## Primitives inventory
| # | Primitive | Where | Proven? | Standalone severity | Notes |
|---|---|---|---|---|---|
| P1 | e.g. Open redirect on /login?next= | auth host | Yes (own session) | Info | Any absolute URL accepted |

## Chain sketch (Mermaid — one per candidate chain)
```mermaid
flowchart LR
  A[Attacker sends link] --> B[P1: open redirect]
  B --> C[OAuth code sent to attacker domain]
  C --> D[Account takeover of victim session]
```

## Chain hypotheses
| Chain | Links (P#s) | Weakest link | Test for weakest link | End impact if whole chain holds | Status |
|---|---|---|---|---|---|

## Dead chains (keep them — they prove defences)
| Chain | Where it died | Control that stopped it | Posture-analysis credit |
|---|---|---|---|
