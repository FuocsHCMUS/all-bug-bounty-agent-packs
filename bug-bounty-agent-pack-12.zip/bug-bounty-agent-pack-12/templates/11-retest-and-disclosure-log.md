# Template 11 — Retest & Disclosure Log

One row per submitted report. The operator submits; this log tracks reality.

| Report title | Platform ID | Submitted (date, by operator) | State | Severity asked / given | Bounty | Next action | Due |
|---|---|---|---|---|---|---|---|

## Retest record (per report)
- Report: ______
- Original proof summary (link to finding folder): ______
- Fix announced: date ______ / deploy note ______
- Tier B retest approval: date ______
- Original proof rerun: PASS (now blocked) / FAIL (still works) — evidence: ______
- Regression variants tried (playbook 16 §2 step 4): ______
- Verdict: Fixed / Partially fixed / Not fixed / Cannot verify
- Draft comment sent to operator on: ______  Posted by operator on: ______

## Disclosure
- Disclosure requested via program process on: ______
- Approved in writing on: ______  / Scope of approval: ______
- Public writeup URL (only after approval): ______
