# Template 12 — Threat Model

Program / target: ______  Date: ______  Author: ______

## 1. Crown jewels (what is worth stealing/breaking?)
| Asset | Why it matters (money / trust / legal) | Where it lives |
|---|---|---|

## 2. Actors & what each SHOULD be able to do
| Actor | Legitimate powers | Explicit non-powers |
|---|---|---|
| Anonymous | | |
| Free user | | |
| Paid user | | |
| Tenant admin | | |
| Support / internal | | |
| Third-party integration | | |

## 3. Trust boundaries (draw it)
```mermaid
flowchart LR
  Browser -->|HTTPS| CDN_WAF --> API --> Services --> DB
  API -->|webhooks| ThirdParties
  Uploads --> Storage --> Workers
```
Boundary list (one line each, what must be checked crossing it):

## 4. Invariants — "The system must NEVER allow…"
1.
2.
3.

## 5. Abuse stories (one per invariant → becomes a hypothesis)
> As a [actor], I want [crown jewel], so I would [path across a boundary
> that might forget the check]…

## 6. STRIDE sweep (one line per letter, per main flow)
S:  T:  R:  I:  D: (design risk only — usually not testable)  E:

## 7. Threat model vs reality (fill after testing — workflow 06)
| Invariant | Held / Broke / Untested | Evidence / finding link |
|---|---|---|
