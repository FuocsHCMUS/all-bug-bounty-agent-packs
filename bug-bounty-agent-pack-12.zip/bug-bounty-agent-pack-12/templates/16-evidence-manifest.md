# Template 16 — Evidence Manifest
Hunt: ______  Program: ______  Date: ______
| File | Type (req/resp, screenshot, frame log, video) | SHA-256 | Proves | Redacted? |
|---|---|---|---|---|
|  |  |  |  | yes |
Notes: hash originals before editing; keep one unedited copy per artifact.
