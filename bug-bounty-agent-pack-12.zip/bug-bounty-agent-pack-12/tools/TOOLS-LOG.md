# Tools Log — everything the agent clones/downloads into ./tools/
Rule (AGENTS.md §4, Tier A): portable, lightweight, no system install only.
Anything else = Tier B question to the operator first.

| Date | Tool/repo | Source URL | Version/commit | Why (hunt/hypothesis) | Portable? |
|---|---|---|---|---|---|
| — | (example row — delete me) | https://github.com/… | v… / abc1234 | … | Yes |
