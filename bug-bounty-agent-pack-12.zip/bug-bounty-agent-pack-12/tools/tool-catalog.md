# Tool Catalog — Portable First (v18)

Tier key: **A** = portable / no system install → clone or download into
`./tools/<name>/`, log in `tools/TOOLS-LOG.md`, no need to ask.
**B** = installs system-wide, or a service/driver, or MCP/plugin/skill →
ask the operator first (AGENTS.md §4). Running ANY tool against a target is
always Tier B regardless of how the tool was obtained.

| Job | Tool ideas | Tier to obtain | Notes |
|---|---|---|---|
| Interception proxy | Burp Suite Community (installer) | B | The daily driver; installer = ask |
| Interception proxy (portable) | mitmproxy (pip, in venv) | A (venv) | Scriptable; good for automation |
| HTTP CLI | curl (built into Win11), httpx (pip) | A | curl ships with Windows 11 |
| Recon (passive) | theHarvester, Recon-ng (clones) | A | Passive only until Tier B for active |
| Subdomain enum | subfinder / amass (portable binaries) | A to obtain, B to run vs target | Verify release checksums |
| Content discovery | ffuf / feroxbuster (portable binaries) | A / B-to-run | Wordlist size goes in the Tier B ask |
| Nuclei templates | nuclei (portable binary) + templates repo clone | A / B-to-run | Validate every hit by hand (playbook 15) |
| JS analysis | LinkFinder / SecretFinder (clones), ripgrep | A | Reading in-scope JS is research; crawling is traffic |
| API testing | Postman (installer) / Bruno (portable options) | B / A | Collections = evidence-friendly |
| Mobile | jadx (portable), apktool (jar), Frida (install) | A / A / B | Own test devices/accounts only |
| CVE intel | `scripts/cve_lookup.py` (this pack), OSV API | A | No install at all |
| Note/evidence | this pack's templates + SHA-256 via PowerShell `Get-FileHash` | A | Built-in, zero install |
| Wordlists | SecLists (clone) | A | Size/noise belongs in Tier B asks |

Rules that never change: log URL + version/commit for every Tier A clone;
prefer official releases; if a "portable" tool turns out to need a driver,
service, or admin rights — it just became Tier B, stop and ask.
