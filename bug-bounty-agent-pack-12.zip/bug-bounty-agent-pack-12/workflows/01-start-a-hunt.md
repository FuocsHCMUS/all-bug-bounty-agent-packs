# Workflow 01 — Start a Hunt

Input: one program URL. Output: a hunt ready for Phase 5 testing.

1. [ ] Read the program page fully (read-only). Fill `templates/00-scope-intake.md`.
       Any unknown field → research or ask the operator. STOP if safe harbor is absent/unclear — flag to operator.
2. [ ] `py -3.14 scripts/make_hunt.py <program-slug>` to scaffold `workspace/<program-slug>/`.
3. [ ] Passive research (playbook 06 §1, playbook 01 passive half): company,
       product, tech stack signals, docs, API reference, changelog, disclosed
       reports for this program. Save to target dossier (template 01).
4. [ ] Create Account A and Account B (Tier B if signup automation is involved;
       manual signup by the operator is normal). Record roles/tenants in dossier.
5. [ ] Threat model (template 12, core 07): crown jewels, actors, boundaries,
       invariants, abuse stories. 20–40 min, in writing.
6. [ ] Surface map: main flows end-to-end as a normal user (both accounts),
       noting endpoints/params/roles into the dossier + inventory (template/script).
7. [ ] Hypothesis backlog (template 02): abuse stories → hypotheses, scored
       per core 05 §2. Aim 10–20, ranked.
8. [ ] Present to operator: scope summary, top 5 hypotheses, any Tier B
       requests grouped in ONE message. Wait for approvals.
9. [ ] Begin Phase 5 with hypothesis #1 (checklists/scope-gate.md first).
