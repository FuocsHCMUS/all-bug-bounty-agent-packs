# Workflow 03 — Writeup-Mining Sprint (90 minutes)

Input: a bug class or target feature. Output: technique cards + hypotheses.

1. [ ] Define the question in one line: "How have hunters broken [feature/class]
       in the last 3 years?" Sources: references/writeup-and-ctf-sources.md.
2. [ ] Collect 8–15 items: disclosed HackerOne/Bugcrowd reports, PortSwigger
       research, CTF writeups (CTFtime/GitHub), conference talks. Read-only, Tier A.
       Cloning a writeup repo to read = Tier A; running its code vs a target = Tier B.
3. [ ] Per item, extract onto a technique card (template 08): precondition,
       developer assumption, primitive, detection idea, "what would this look
       like on OUR target?"
4. [ ] Build/update the technique graph (playbook 07): primitives as nodes,
       "chains into" as edges. Mark primitives already present in this target.
5. [ ] Convert the 3 best-fitting patterns into hypotheses (core 05 format)
       and add them, scored, to the backlog.
6. [ ] Teach-back: 5-minute summary for the operator — the pattern, in plain
       language, from the fundamental up (core 06 ladder, rungs 1–3 minimum).
