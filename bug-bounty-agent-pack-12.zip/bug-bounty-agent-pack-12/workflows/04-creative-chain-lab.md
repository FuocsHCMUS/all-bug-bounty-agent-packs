# Workflow 04 — Creative Chain Lab (timeboxed, 90 minutes)

Input: primitives found so far (even "informational" ones). Output: chain
canvas + ranked chain hypotheses, or a written "no chain found, and why".

1. [ ] List every primitive on the chain canvas (template 10): self-XSS,
       open redirect, weak CORS, IDOR-read on low-value objects, CSRF on
       minor actions, info leaks, rate-limit gaps… "Too small to report"
       is exactly what chains are built from.
2. [ ] Run the seven generators (core 05 §3) over the canvas, 10 min each max:
       assumption inversion, feature interaction, parser differential,
       state machine, race, second-order, chain extension.
3. [ ] For each candidate chain: draw it in Mermaid on the canvas
       (attacker step → system step → impact). Kill any chain whose link
       you cannot state as a testable hypothesis.
4. [ ] Score surviving chains (core 05 §2). Pick ONE. Test link by link,
       cheapest/most-uncertain link first — a chain dies at its weakest
       link, find that link early.
5. [ ] Log everything, including dead chains and why they died — dead chains
       are posture-analysis gold ("these two weaknesses do NOT combine
       because control X sits between them" = something the company does well).
6. [ ] End: update backlog + teach-back summary for the operator.
