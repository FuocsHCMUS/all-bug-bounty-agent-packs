# Workflow 05 — Validate & Report

Input: a suspected finding. Output: a submission-ready draft for the operator.

1. [ ] Run playbook 15 §1 validation gauntlet. Any failure → back to testing
       or park it honestly; never write the report around an unvalidated claim.
2. [ ] Evidence pack: clean reproduction requests/responses (redacted copies),
       baseline contrast, timestamps, account details, hashes in evidence-log.
       Clean up test artefacts you created where the program expects it.
3. [ ] Draft with template 03 (or platform variant template 04): title =
       asset + bug + impact; steps a tired triager reproduces in <10 minutes.
4. [ ] Severity: program taxonomy first, CVSS as support (playbook 15 §3).
       Impact ladder rung stated honestly.
5. [ ] Run `checklists/report-qa.md` line by line. Fix every miss.
6. [ ] Duplicate armour (playbook 15 §4): differentiation sentence in para 1.
7. [ ] Hand to the OPERATOR. He reads and submits himself (Tier B rule).
       Record submission in template 11 log when he confirms it.
8. [ ] Immediately continue to workflow 06 — posture + learning are mandatory.
