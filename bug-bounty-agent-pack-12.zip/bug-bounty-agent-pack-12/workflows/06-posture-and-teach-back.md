# Workflow 06 — Posture Analysis & Teach-Back (MANDATORY after every finding/hunt)

1. [ ] Posture analysis (template 05): strengths with evidence, gaps, risk
       register, high-risk patterns, architecture notes, maturity labelled
       Observed/Inferred/Guessed, recommendations mapped to OWASP ASVS /
       NIST CSF in plain language.
2. [ ] SOC section: for the bug class — what SHOULD have detected this
       (logs/alerts), what visibly DID react (WAF, lockouts, nothing),
       and 2–3 concrete detection opportunities (learning/05).
3. [ ] Threat-model vs reality: which invariants held, broke, or went untested
       (update template 12 file).
4. [ ] Learning notes (template 06) via the core 06 ladder: analogy →
       fundamental from zero → safe version → break → exploit logic → fix →
       defender's view → 3 self-check questions + 1 safe lab.
5. [ ] Flashcards: 3–5 cards appended to the deck per
       `checklists/learning-retention.md` format.
6. [ ] Teach-back message to the operator: the 5-minute plain-language version,
       file locations, and the single concept to review again next week
       (added to the dossier's "shaky concepts" list).
