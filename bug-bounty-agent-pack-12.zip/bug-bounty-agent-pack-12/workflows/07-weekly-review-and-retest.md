# Workflow 07 — Weekly Review & Retest

Run weekly (or per 10–15 hunt hours). Keeps reports, learning, and the
backlog honest.

1. [ ] Report states: check every open report (template 11 log). New triage
       replies → draft responses for the operator. Fixes announced → queue
       retests (playbook 16 §2, Tier B asks grouped).
2. [ ] Backlog hygiene: kill stale hypotheses (note why), promote research
       findings (CVE sweeps, mining sprints) into scored hypotheses,
       re-rank with fresh evidence.
3. [ ] Metrics snapshot (AGENTS.md §13): tested/confirmed/ruled-out counts,
       duplicates hit, time per phase. One honest paragraph: what got better,
       what pattern of mistake repeated.
4. [ ] Learning review: re-ask the operator the week's self-check questions
       (from memory, no notes — that's the point), grade kindly, re-teach
       misses from the fundamental up, update shaky-concepts list.
       Review due flashcards (checklists/learning-retention.md intervals).
5. [ ] Research refresh: new CVEs/KEV entries for known target stacks,
       2–3 fresh disclosed reports in your main classes — 30 min max.
6. [ ] Plan next week: single best next action per active target, stated
       in the closing heartbeat to the operator.
