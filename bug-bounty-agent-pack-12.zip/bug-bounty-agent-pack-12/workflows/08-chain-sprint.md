# Workflow 08 — Chain Sprint (2 hours)
1. (15m) Lay out all open primitives from the Ledger on the chain canvas.
2. (30m) Pairwise precondition matching (core 09 generator 6); rank joins by
   (final impact) x (join cost)^-1.
3. (60m) Test joins cheapest-first, differential accounts open.
4. (15m) Survivors -> chain section of the finding report; corpses -> Ledger
   with kill reasons. Feed one lesson into the weekly review.
