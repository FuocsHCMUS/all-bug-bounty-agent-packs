# Workflow 09 — Invent-Then-Kill Session (60-90 minutes)
1. Pick one feature. Write its assumption list (core 09 generator 1).
2. Invent: 5 wildest plausible attacks, no filtering, 15 minutes.
3. Kill: for each, find the cheapest evidence that would disprove it.
   Run the kill tests first — most inventions die in one request.
4. Survivors become Ledger hypotheses with priority = impact x survival.
5. Close: one technique card + one learning note, even if all 5 died.
   A clean kill list is a posture finding: "we tried X, the control held."
