# workspace/ — one subfolder per program
Create with: `py -3.14 scripts/make_hunt.py "Program Name"`
Each program folder holds its scope intake, dossier, hypotheses, experiment
and evidence logs, findings/, cve/ match sheets and technique-cards/.
Never mix two programs in one folder. Evidence originals stay local.
