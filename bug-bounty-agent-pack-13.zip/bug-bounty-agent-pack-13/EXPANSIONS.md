# Expansions

Superseded in v21 by `MERGE-NOTES.md`, which records — per source pack
(16–20) — what was kept, what was grafted, what was dropped as
duplication, what is new in v21, and which ideas were expanded beyond
the operator's original brief.
