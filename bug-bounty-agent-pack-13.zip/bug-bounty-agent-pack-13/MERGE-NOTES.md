# MERGE NOTES — how v21 was built from packs 16–20

v21 is a synthesis, not a fresh rewrite. Each source pack was read and
mined; the table below is the provenance record (the operator asked
explicitly which ideas were kept/expanded — this is that list).

## Kept as the base — Pack 20 (137 files, the most complete)

- Canonical structure: root `AGENTS.md` + `SKILL.md`, no CLAUDE.md.
- All 20 strategic playbooks, incl. the newest: 17 WebSocket/realtime &
  HTTP smuggling/cache, 18 OAuth/OIDC/SSO/passkeys, 19 serverless/edge,
  20 bug chaining at scale.
- Core 01–10, incl. autonomous agent ops & memory (08), data
  handling/OPSEC (09), detection & purple-team lens (10).
- Learning 00–09, incl. cryptography from zero (07), OS basics (08),
  SOC→Pentest career roadmap (09).
- 10 workflows incl. OSINT sweep, chain sprint, 90-day review.
- Templates 00–15, checklists incl. AI-agent preflight and
  smuggling/cache safety, references incl. modern sources 2024–2026.
- Scripts: scope_guard, inventory, tech_fingerprint, headers_check,
  http_probe, har_analyzer, js_extract, evidence_hash, cve_lookup,
  make_hunt.

## Grafted from Pack 17 (the specialist pack)

- **11 role agents** → `adapters/role-agents/` (recon-lead,
  surface-mapper, vuln-hunter, exploit-dev, cve-researcher,
  writeup-miner, technique-synthesist, reporter, reviewer,
  posture-analyst, scribe).
- **16 granular per-vuln playbooks** → `playbooks/granular/`
  (SQLi, XSS, SSRF, SSTI, XXE, JWT, OAuth, IDOR/BOLA, GraphQL, race,
  cache poisoning, desync, file upload, subdomain takeover,
  business logic, mobile API).
- **JSON schemas** → `schemas/` (finding, hypothesis, scope).
- **Deep-dive learning set** → `learning/deep-dives/` (HTTP/2 & parsers,
  caching/proxies, crypto pitfalls, JS runtime/DOM, same-origin/CORS,
  DNS, TLS, cloud IAM/metadata, CTF→bounty transfer, …).
- **Tools** → `scripts/jwt_inspect.py`, `scripts/diff_response.py`
  (A/B-account differential testing is core to this method),
  `workspace/state-template.json`.

## Grafted from Pack 19 (the hypothesis pack)

- **Hypothesis Ledger as a first-class phase** → `templates/16-…`,
  mandatory Phase 2 in AGENTS.md.
- **Role prompts** → `prompts/roles/` (senior pentester, research
  librarian, SOC mirror, tutor).
- **learning_card.py** spaced-repetition generator → `scripts/`.
- Its 3 fictional examples (IDOR invoice, SSRF webhook, race coupon)
  join pack 20's examples.
- Its rule that posture analysis must include false-positive analysis
  is in AGENTS.md §8.

## Grafted from Pack 18 (the threat-model pack)

- Threat-model-first **Phase 0.5** (already in pack 20's flow, kept and
  re-affirmed as mandatory), scope-gate & exploit-safety checklists,
  retest workflow — all present in the pack-20 base and retained.

## Grafted from Pack 16 (the configs pack)

- **Machine-readable configs** → `configs/` (engagement.yaml,
  scope.yaml, tool-policy.yaml, rules-of-engagement.md).
- **Compact knowledge base** → `knowledge/` (8 short references:
  HTTP, DNS/TLS, authN/authZ, vuln classes, CVE/CVSS/CWE, tooling,
  report writing).
- **cvss.py** → `scripts/cvss_calc.py`.

## Dropped as duplication

- Packs 16–19's own root AGENTS/SKILL/README files (superseded by the
  new v21 canonical files), their duplicate platform adapters (pack 20's
  are the newest), duplicate templates/scripts where pack 20's version
  is a superset, pack 17's `oob_listener.py` / `race_runner.py` active
  tools (the *techniques* are fully covered in playbooks; the pack's
  script set stays offline/dry-run-first), and pack-specific
  CHANGELOG-vs-* files (superseded by this file).

## New in v21 (written for the merge)

1. `AGENTS.md` v21 — rewritten canonical file: ROE compressed to one
   short section (§2), creativity promoted to its own section (§3).
2. `core/11-creative-offensive-thinking-engine.md` — the 7 creativity
   generators + a timed creative-session protocol.
3. `core/12-rules-of-engagement-as-enabler.md` — why the pack keeps the
   programs' own ROE despite the brief asking to remove all guardrails:
   platforms enforce them regardless, they are what make findings
   valid/payable, and every winning technique in this pack executes
   inside them. Also lists the *friction* v21 did remove (research
   refusals, permission-seeking for offline work, banned-class thinking).
4. This merge/provenance file, replacing five packs' EXPANSIONS files
   (`EXPANSIONS.md` now points here).

## Expansions beyond the operator's original brief

- JSON schemas + YAML configs so agent state is machine-checkable,
  not just prose (16/17).
- Differential A/B testing tooling as a first-class method (17).
- Spaced-repetition learning cards generated from findings (19).
- Purple-team/detection lens on every attack (20, kept).
- The creativity session protocol with time-boxes and kill-criteria (21).
