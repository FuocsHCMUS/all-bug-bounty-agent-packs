# Bug Bounty Super Agent Prompt Pack — v21 (The Merge)

A complete, platform-agnostic prompt pack that turns a coding agent
(Claude Code, Codex, OpenCode, Cline, Cursor, Antigravity — or any agent
that reads `AGENTS.md`) into a senior-level, creative bug bounty
research partner and tutor for a cybersecurity student.

**v21 is the synthesis of packs 16–20** — not a rewrite. The strongest
structure and newest playbooks of pack 20 form the base; pack 17's
specialist role-agents, granular per-vuln playbooks, JSON schemas and
extra tools; pack 19's Hypothesis Ledger and role prompts; pack 18's
threat-model-first flow; and pack 16's machine-readable configs and
compact knowledge base are grafted in. Two new core files (11–12) add
the creativity engine and the Rules-of-Engagement rationale.
Full provenance: `MERGE-NOTES.md`.

## Start

1. Read `START-HERE.md` (10-minute setup per platform).
2. Agents: read `AGENTS.md` fully — it is canonical. No CLAUDE.md is
   included; Claude Code reads AGENTS.md natively.
3. First hunt: `workflows/01-start-a-hunt.md`.

## The deal in one paragraph

Think like an attacker with **no limits on ideas** — assumption
inversion, parser differentials, chaining, writeup/CTF transfer,
CVE-driven hunting — and execute with professional discipline:
**in authorized scope only, on your own test accounts, minimum-impact
proof, reports handed to the operator (Joshua) who submits them
himself.** Those rules of engagement are the programs' own rules;
they are what makes findings valid, payable, and worth learning from.
See `core/12-rules-of-engagement-as-enabler.md`.

## Layout

- `AGENTS.md`, `SKILL.md` — canonical instructions + skill entry
- `core/` — persona, approvals, workflow, creative engine (11), ROE (12),
  threat modeling, agent ops, OPSEC, purple-team lens
- `playbooks/` — 20 strategic playbooks + `granular/` 16 per-vuln deep dives
- `workflows/`, `prompts/` (+ `prompts/roles/`), `checklists/`, `templates/`
- `adapters/role-agents/` — 11 specialist sub-agent roles (pack 17)
- `platforms/` — Claude Code / Codex / OpenCode / Cline / Cursor / Antigravity
- `learning/` (+ `deep-dives/`), `knowledge/` — beginner-first curriculum
- `configs/`, `schemas/` — machine-readable scope/engagement/tool policy
- `scripts/` — 14 tested, stdlib-only Python helpers (offline/dry-run first)
- `examples/` — fictional end-to-end findings (incl. IDOR, SSRF, race)
- `references/`, `tools/`, `workspace/`

Environment target: Windows 11, Python 3.14.x+. All pack text in English.
