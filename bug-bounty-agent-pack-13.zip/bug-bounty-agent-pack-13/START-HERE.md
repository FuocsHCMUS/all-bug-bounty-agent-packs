# START HERE — Bug Bounty Agent Pack v21

You (the human) do this once. Takes ~10 minutes.

## 1. Pick your agent tool and copy the adapter

- **Claude Code:** copy the pack folder into your project; Claude Code
  reads `AGENTS.md` natively. Optionally also copy
  `platforms/claude-code/.claude/skills/bug-bounty/SKILL.md`.
- **Codex:** root `AGENTS.md` is already the format Codex wants.
- **OpenCode:** copy `platforms/opencode/.opencode/agent/bug-bounty.md`
  + `opencode.json.example` → `opencode.json`.
- **Cline:** copy `platforms/cline/.muserules`.
- **Cursor:** copy `platforms/cursor/.cursor/rules/*.mdc` (4 rules).
- **Antigravity:** copy `platforms/antigravity/.agent/` (rules + workflows).

Whichever you pick: the adapter's first instruction is "read the root
`AGENTS.md` in full" — that file is the real pack.

## 2. Set up Python helpers (optional, 2 minutes)

Windows 11, Python 3.14.x+:

```powershell
cd bug-bounty-agent-pack-21\scripts
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt   # stdlib-first; mostly a formality
.venv\Scripts\python scope_guard.py --help
```

All scripts are stdlib-only and offline/dry-run by default where they
could touch a network.

## 3. Start a hunt

Tell your agent: **"Start a hunt"** and give it a program (name or
HackerOne/Bugcrowd URL). It will refuse to test anything until the scope
intake (`templates/00-scope-intake.md`) is filled from the program page —
that refusal is a feature: it's what keeps reports valid.

Create your two test accounts (A and B) on the target when the agent
asks. You — not the agent — submit the final report.

## 4. What you get back per hunt

A validated (or honestly killed) set of hypotheses, a submission-ready
report draft, a posture analysis (what the company does well / must
improve / where the risk is), and beginner-first learning notes with
flashcards — so every hunt makes you better at Cyber/Sec/Pentest/SOC,
not just richer in reports.
