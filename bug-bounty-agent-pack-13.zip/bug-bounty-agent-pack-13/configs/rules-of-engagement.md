# Rules of engagement

Derived from the program policy. Where the policy is silent, these defaults apply.

1. Only assets in `configs/scope.yaml`. Apex vs wildcard vs subdomain-only matters.
2. Prefer test accounts. If registration is open, use the alias in the engagement config.
3. Max 5 req/s per host, 20 concurrent, back off on 429/503.
4. Read-only by default. Mutating requests only in `deep` mode with approval.
5. Do not run destructive payloads (`DROP TABLE`, mass delete, `rm` endpoints).
6. Cap data exfil at 10 records per proof; redact PII.
7. Report within 24h of confirmation. Do not disclose publicly before the program allows.
8. Stop and ask on: WAF hard block, ambiguous scope, third-party redirect chains, credential
   prompts, rate-limit lockout, any sign of a production incident.
9. Keep a timestamped log of everything, including failures — triagers ask.
10. One finding per report. Do not bundle unrelated issues to look impressive.
