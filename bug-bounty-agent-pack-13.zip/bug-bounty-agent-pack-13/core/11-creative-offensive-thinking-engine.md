# Core 11 — Creative Offensive Thinking Engine (new in v21)

Goal: make creativity a *procedure*, not a mood. Run these generators
whenever a surface looks "probably fine" — that is exactly where
non-obvious bugs live.

## The 7 generators

1. **Assumption inventory.** For one feature, write 10 things the
   developers must be assuming. Each assumption is a test case.
   Example shapes: "the ID in this URL is mine", "this step happens
   after payment", "only the mobile app calls this endpoint",
   "this webhook really comes from Stripe", "the cache key includes
   the cookie", "the second parser sees what the first parser saw".
2. **Parser differential hunt.** Draw the parsing chain for one input.
   Anywhere two parsers disagree (encoding, length, header folding,
   duplicate keys, content-type sniffing) is a candidate. Playbooks
   17 + granular/http-desync, granular/cache-poisoning.
3. **Trust-boundary walk.** Follow one request across every hop and ask
   at each hop: *what did this hop trust without checking?*
4. **State-machine abuse.** Sketch the flow as states/transitions.
   Attack the diagram: skip, replay, reorder, parallelise (races),
   abandon-and-resume, downgrade to a legacy state.
5. **Primitive → chain.** Never ask "is this reportable alone?" first.
   Ask "what does this primitive buy an attacker?" Log it in the chain
   canvas even if it is only an info leak today. Playbook 20.
6. **Feature-as-weapon.** For each product feature (share, export,
   import, invite, preview, embed, template, AI assistant), ask how it
   can be aimed at another user, another tenant, or the platform itself.
7. **Negative space.** Send what's missing: no signature, no CSRF token,
   no auth header, empty/null/duplicate fields, wrong content type,
   the *other* account's token on *this* account's object.

## Session protocol (45–90 min)

1. Pick ONE surface. Write the assumption inventory (10 min, no testing).
2. Generate ≥15 hypotheses into the Ledger; rank by (impact × likelihood)
   ÷ effort. Star the 3 weirdest — weird is where competition isn't.
3. Test in ranked order, minimum proof, own accounts. Kill or confirm
   each with evidence; update the Ledger live.
4. For every confirmed primitive, spend 10 min only on chaining before
   writing anything up.
5. Close with: what surprised me? what did I get wrong? → learning notes
   + technique card (`templates/08`).

## What creativity is NOT

- Running a bigger scanner wordlist.
- Repeating a failed payload louder (more requests, more threads).
- Testing out of scope "just to see". Scope is the board; the game is
  won on the board.
- Copying a writeup's payload without understanding its precondition.

## Sources of new ideas (feed the engine weekly)

Disclosed reports on the program itself → patch diffs of the stack's
CVEs → CTF writeups for the *shape* of the trick → the app's own JS,
mobile client, changelogs, and API version history (v1 endpoints that
never died are a classic). Workflow 03 + workflow 04 operationalise this.
