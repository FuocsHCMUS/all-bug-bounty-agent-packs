# Start here — the ground floor

Read in order. Each file assumes only the previous one.

## What actually happens when you open a URL

You type a name. Your machine needs an IP, so it asks a resolver (DNS). It gets an IP, opens
a TCP connection to port 443, negotiates TLS, sends an HTTP request, and gets bytes back.

- **IP address** — the numeric address of a machine on a network.
- **Port** — a number that picks which program on that machine gets the bytes. 443 = HTTPS.
- **DNS** — the phone book. `A` record = IPv4, `AAAA` = IPv6, `CNAME` = alias, `MX` = mail,
  `TXT` = arbitrary text (SPF, DKIM, verification tokens).
- **TCP** — reliable, ordered byte stream. Three-way handshake: SYN, SYN-ACK, ACK.
- **TLS** — encryption plus proof that the server owns the name. The certificate is the proof.

Why a hunter cares: every one of those steps is a place where a name can be pointed
somewhere it should not be. A dangling CNAME is a subdomain takeover. A misissued cert leaks
names via CT logs. A resolver that answers differently for internal callers is SSRF fuel.

## The trust boundary idea

A trust boundary is a line where the data's guarantees change. Browser to server. Public
zone to internal network. Tenant A to tenant B. User to admin. Almost every bug is a place
where the code assumed the boundary was enforced and it was not.

When you look at a system, list its boundaries first. That list is your test plan.

## Authn vs authz

- **Authentication** — who are you.
- **Authorization** — what may you do.

They fail differently. Authn bugs let you become someone (or no one). Authz bugs let a
legitimate someone do a forbidden thing. Authz bugs are more common, quieter, and pay better,
because the request looks normal.

## Encoding

Data travels through layers, and each layer may encode it. `%2e%2e%2f` is `../` after URL
decoding. `&lt;` is `<` after HTML decoding. A bug often lives where two layers disagree
about how many times to decode. That disagreement is the whole basis of path traversal,
XSS filter bypass, and request smuggling.

## Where to go next

`01-http.md`, `02-dns-and-tls.md`, `03-authn-authz.md`, `04-vuln-classes.md`,
`05-cve-cvss-cwe.md`, `06-tooling.md`, `07-report-writing.md`.
