# HTTP — the protocol you are actually attacking

HTTP is a text request/response protocol. A request is a method, a path, a version, headers,
then an optional body.

```
GET /v2/invoices/1001 HTTP/1.1
Host: api.example.com
Cookie: session=abc
Accept: application/json
```

The server answers with a status, headers, and a body.

## The parts that matter

- **Method** — `GET` (read), `POST` (create), `PUT`/`PATCH` (replace/modify), `DELETE`.
  Servers often forget to check the method, so `PUT` on a read route can write.
- **Status** — 200 ok, 301/302 redirect, 401 unauthenticated, 403 authenticated but denied,
  404 not found, 500 crashed. A 403 where you expected 404 tells you the object exists.
- **Headers** — `Host` picks the virtual host. `Cookie` carries the session. `Content-Type`
  tells the parser what to expect. `X-Forwarded-*` is a lie the client can usually set.
- **Body** — JSON, form, multipart, XML, or a file.

## Two parsers, one request

Every hop parses the same bytes: CDN, WAF, load balancer, app server, framework. If they
disagree, you can hide a second request or a second parameter.

- `Content-Length` vs `Transfer-Encoding: chunked` disagreeing -> request smuggling.
- Duplicate keys (`?a=1&a=2`, `{"a":1,"a":2}`) -> whichever parser wins decides auth.
- `Host` differs from the SNI -> routing confusion, cache poisoning, reset-link poisoning.

## Cookies

`Domain` (which hosts get it), `Path`, `Secure`, `HttpOnly`, `SameSite`. A cookie scoped to
`.example.com` is sent to every subdomain — which is why one subdomain takeover can steal a
session.

## HTTP/2 and HTTP/3

Binary framing, multiplexed streams, header compression. H2 hides `Content-Length` games
better but adds its own: header downgrade, pseudo-header abuse, stream-state desync
("single-packet attack" for racing many requests in one RTT).

## Practice

`curl -v` until the output stops being noise. Then `mitmproxy` to read real traffic. Then
write a raw request by hand and send it with `nc` or a Python socket — that is when you stop
being a form-filler and start being a tester.
