# Vulnerability classes, from the mechanism up

Each entry: the mechanism, then the test, then the impact shape.

## Injection

Untrusted data reaches an interpreter that gives it meaning.

- **SQL** — data becomes query syntax. `'` breaks the string. Impact: read/write the DB.
- **NoSQL** — operator objects (`{"$ne":null}`) become logic. Impact: auth bypass, read.
- **Template (SSTI)** — data is compiled. `{{7*7}}` -> 49. Impact: often RCE.
- **Command** — data reaches a shell. `;id`, `$(id)`, `|id`. Impact: RCE.
- **XPath/LDAP** — data becomes a filter. Impact: auth bypass, directory read.

The universal test: send a character the parser treats specially, watch for an error or a
behavior change, then build from the error.

## SSRF

The server fetches a URL you choose. Impact depends on reach: internal services, cloud
metadata, admin panels, `file://`.

Test: any URL field. Point it at your listener first to confirm the fetch, then inward.

## XXE

XML with an external entity. `<!ENTITY x SYSTEM "file:///etc/passwd">`. Impact: file read,
SSRF, sometimes RCE via expect or a Java gadget. Test every XML-accepting endpoint, including
SVG, DOCX, XLSX and SOAP.

## Deserialization

Bytes become objects, and object construction runs code (magic methods, readObject).
Impact: usually RCE. Test by finding the magic bytes: `AC ED` (Java), `O:8:` (PHP),
`gASV` (Python pickle).

## Access control

Covered in `03`. The highest-yield class.

## Business logic

The code is correct; the rules are wrong. Negative quantity, coupon stacking, refund after
capture, quota reset, race on redeem. Impact: money, entitlement, data.

Test by reading the intended flow, then violating each step's assumption.

## Client side

- **XSS** — data becomes script. Reflected, stored, DOM. Impact: session/token theft, actions
  as the victim.
- **CSRF** — the browser attaches the cookie automatically. Impact: state change.
- **CORS** — `Access-Control-Allow-Origin` too permissive plus credentials. Impact: cross-origin
  read of authenticated data.
- **postMessage** — no origin check. Impact: token relay, actions.

## Crypto and secrets

Hardcoded keys, ECB, static IV, weak reset tokens, secrets in JS or git history. Impact: ATO,
forgery, data decryption.

## Infrastructure

Subdomain takeover, exposed buckets, CI leaks, default creds on admin panels.

## How to think about a class

Ask: what does the code assume about this input? What happens if that assumption is false?
What is the worst thing the false assumption unlocks? Then find the cheapest way to falsify it.
