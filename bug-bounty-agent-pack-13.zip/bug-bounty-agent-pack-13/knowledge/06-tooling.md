# Tooling and shell, from zero

## PowerShell essentials

```powershell
Get-ChildItem              # ls
Set-Location workspace     # cd
Get-Content file.txt       # cat
Select-String -Pattern x   # grep
Get-Content log | Select-Object -Last 50
$env:PATH += ";$PWD\workspace\tools-bin"
```

## curl

```powershell
curl.exe -s -D - -o NUL "https://api.example.com/v2/invoices/1001" -H "Cookie: session=..."
```

`-D -` prints response headers to stdout, `-o NUL` discards the body. Always quote URLs with
`&` in PowerShell, or it splits them.

## Python 3.14 on Windows 11

```powershell
py -3.14 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -U pip
```

Never install into the global interpreter. Keep scripts in `scripts/`, run them with the venv
python. `urllib` and `json` cover most recon; `requests` only when you need sessions.

## Tool roles

| Stage | Tool | What it does |
|---|---|---|
| subdomains | subfinder, crt.sh, chaos | passive name collection |
| resolve | dnsx | mass resolution |
| probe | httpx | status, title, tech, TLS |
| crawl | katana, gau | URL and JS harvest |
| fuzz | ffuf | content and parameter discovery |
| scan | nuclei | template checks |
| screenshots | gowitness | visual triage |
| API | Postman, curl | manual precision |
| proxy | Burp CE, Caido, mitmproxy | intercept and replay |

## Where tools fail

Scanners match signatures. They miss logic, chained authz, and anything needing two accounts.
Use them for coverage, then think. A `nuclei` hit is a lead, not a finding.

## Portable install pattern

Download the release binary into `workspace\tools-bin\`, add that dir to `$env:PATH` for the
session, run it. Nothing is installed. Delete the folder and it is gone.
