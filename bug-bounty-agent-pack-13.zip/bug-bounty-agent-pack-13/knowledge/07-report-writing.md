# Writing a report that gets paid

## The three readers

1. The triager — wants scope, repro, impact, fast.
2. The engineer — wants the exact request and the root cause.
3. The manager — wants the number: how many records, how much money, which customers.

Write for all three in one document. Summary for the triager, steps for the engineer, impact
in data terms for the manager.

## Structure that works

1. **Title** — `[Class] on [asset] allows [impact]`. Never "IDOR in API".
2. **Summary** — three lines: mechanism, asset, consequence.
3. **Preconditions** — accounts, roles, config. Honest.
4. **Steps** — numbered, exact, from a clean session, with the request inline.
5. **Evidence** — fenced raw request and response. Redact PII, keep the shape.
6. **Impact** — whose data, how much, what it enables.
7. **CVSS + CWE** — justified.
8. **Remediation** — specific and testable.
9. **Notes** — variants, related endpoints, escalation path.

## Sentences to delete

- "An attacker could potentially..."  -> say what you did.
- "It is recommended to..."  -> say what to change.
- "Critical vulnerability!!!"  -> the CVSS says it.
- "As we all know..."  -> start at the fact.

## Redaction

Keep the first and last characters, mask the middle: `sk_live_4f...9a`. Keep IDs intact when
the ID is the proof. Never paste a full PII record.

## The self-triage checklist

In scope? Reproducible twice? Not a duplicate? Real impact? Would a stranger succeed from this
document alone? If any answer is no, fix it before submitting.
