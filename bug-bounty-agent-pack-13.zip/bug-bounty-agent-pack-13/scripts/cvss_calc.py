"""CVSS 3.1 base score calculator.  python scripts/cvss.py AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N"""
import sys

W = {
    "AV": {"N": .85, "A": .62, "L": .55, "P": .2},
    "AC": {"L": .77, "H": .44},
    "PR": {"U": {"N": .85, "L": .62, "H": .27},
           "C": {"N": .85, "L": .68, "H": .5}},
    "UI": {"N": .85, "R": .62},
    "CIA": {"H": .56, "L": .22, "N": 0},
}


def score(vec: str) -> tuple:
    m = dict(p.split(":") for p in vec.strip().split("/") if ":" in p)
    for k in ("AV", "AC", "PR", "UI", "S", "C", "I", "A"):
        if k not in m:
            raise ValueError(f"missing {k}")
    scope = m["S"]
    iss = 1 - (1 - W["CIA"][m["C"]]) * (1 - W["CIA"][m["I"]]) * (1 - W["CIA"][m["A"]])
    if scope == "U":
        imp = 6.42 * iss
    else:
        imp = 7.52 * (iss - .029) - 3.25 * (iss - .02) ** 15
    exp = (8.22 * W["AV"][m["AV"]] * W["AC"][m["AC"]]
           * W["PR"][scope][m["PR"]] * W["UI"][m["UI"]])
    if imp <= 0:
        return 0.0, "None"
    base = min((1.08 if scope == "C" else 1.0) * (imp + exp), 10)
    import math
    base = math.ceil(base * 10) / 10
    band = ("None" if base == 0 else "Low" if base < 4 else
            "Medium" if base < 7 else "High" if base < 9 else "Critical")
    return base, band


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    v = sys.argv[1]
    s, b = score(v)
    print(f"CVSS:3.1/{v}")
    print(f"base={s} ({b})")
