# Expansions — Pack 16 Consolidated Edition (new, on top of the v20 list below)

Added in this consolidation, beyond the operator's brief and beyond
everything listed in the v20 expansions below:

C1. **Provenance-complete merge of packs 17–20** with a one-canonical-copy
    deduplication rule (`MERGE-NOTES.md`): pack 20 canonical; pack 17 and
    pack 19 material grafted as labelled supplements; pack 18 noted as
    already absorbed into pack 20, its CLAUDE.md shim deliberately dropped.
C2. **Creative Offensive Thinking Engine** (`docs/14`, AGENTS.md §15):
    seven named generators (assumption inversion, parser differentials,
    trust boundaries, state-machine/time, identity confusion, primitives
    over bug names, second-order/feature interaction) plus an
    invent-then-kill loop and a timed creative-session protocol.
C3. **Minimal ROE explainer** (`docs/15`): separates unlimited ideation,
    research and local development (no permission, ever) from the seven
    execution lines the bounty programs themselves enforce.
C4. **Role-agent architecture** from pack 17 (11 specialist agents) and
    role prompts from pack 19, subordinated to one canonical AGENTS.md
    instead of competing orchestrators.
C5. **Machine-checkable hunt state**: pack 17's JSON schemas for scope,
    hypothesis and finding (`schemas/`).
C6. **Hypothesis Ledger promoted** to template 16 and a mandatory step
    of the creative loop (from pack 19).
C7. **Offline tool layer** from pack 17 (JWT inspector, CVSS 3.1
    calculator, response differ, parameter miner) — with pack 17's two
    active-traffic tools deliberately excluded and the decision logged.
C8. **Preservation guarantee**: the previous Pack 16 (merge of 10–15)
    is kept untouched as `bug-bounty-agent-pack-16-v1-merge-10-15` in
    the workspace; this edition replaces the name, not the history.

---

# Expansions — ideas added beyond the operator's brief

The operator's original request (paraphrased, it has stayed stable across
packs 12–20): build a super agent prompt pack in its own folder
(`bug-bounty-agent-pack-20` for this version), in **English**, with
`AGENTS.md` / `SKILL.md` and adapters for **Claude Code** (AGENTS.md
canonical — Claude Code reads AGENTS.md now, so v20 ships **no `CLAUDE.md` at all**),
**Codex, OpenCode, Cline, Cursor, Antigravity**; agents that can hunt on
HackerOne / Bugcrowd-style programs; autonomous research — finding related
**CVEs** and checking whether a target is vulnerable, mining
**writeups / CTF techniques** and related material; creatively developing
stronger, more sophisticated pentest/exploit techniques to find bugs and
report them **to the operator, who submits to companies himself** so fixes
land fast; after any finding, a detailed **security posture analysis**
(what the company does well / needs to improve / risks / high-risk areas)
plus notes that **teach a cybersecurity student from first principles** —
root concepts first, comprehensive, beginner-friendly — across
Cyber / Security / Pentest / SOC; a clear approval rule (ask before
running scripts/tools or downloading — **except portable, no-install
tools/repos cloned into the current workspace, and venv pip installs,
which are pre-approved**); **MCP / plugins / skills always ask first**;
**Python 3.14.x+ on Windows 11**; long, thick, clear and detailed;
everything **zipped and delivered**; and if the author expands the brief,
**report exactly which ideas were expanded**.

Everything below is expansion *beyond* that brief. Nothing in the brief
was dropped or weakened in any version; expansions only add structure,
safety, or depth.

---

## A. Carried forward from packs 12–15 (foundation expansions)

1. **Three-tier approval protocol (A/B/C)** with a copy-paste Tier B ask
   format — turns "ask me first" into an enforceable, auditable rule.
2. **Scope intake as a hard gate** with safe-harbor / prohibited-technique /
   stop-condition fields — no scope document, no testing, ever.
3. **Safe starter scripts with guardrails in code** (scope-checked,
   dry-run-first, rate-limited) instead of bare tool recommendations.
4. **Hypothesis backlog + experiment-log discipline**, negatives kept —
   ruled-out areas are knowledge, not wasted time.
5. **Security Posture Analysis as a formal template** with
   Observed / Inferred / Guessed labelling, so maturity claims stay honest.
6. **Foundations curriculum + glossary** so teaching is a map the student
   climbs, not only per-finding explanations.
7. **Modern surface playbooks from the start:** API/GraphQL, business
   logic/races, cloud, mobile, AI/LLM.
8. **Adapters shaped to each tool's native mechanics** (Antigravity
   workflows, split Cursor rules, OpenCode dedicated agent, Cline rules).
9. **A worked fictional example end-to-end** so a beginner sees the whole
   shape of a hunt before doing one.
10. **Report QA + pre-flight checklists and platform report variants**
    (HackerOne style, Bugcrowd VRT, Intigriti, YesWeHack).
11. **Evidence discipline:** originals vs shareable copies, SHA-256
    logging, redaction rules.

## B. Added in v18 (kept in v20)

12. **Threat-model-first hunting (Phase 0.5)** — crown jewels, actors,
    trust boundaries, invariants, abuse stories before any testing
    (AGENTS.md §12, template 12, core 07). Seniors threat-model first;
    students who learn this early find bugs that matter.
13. **A workflows/ layer** — executable step-by-step routes between the
    AGENTS.md map and the playbooks, so agents execute instead of improvise.
14. **Two-account rule (A/B identities)** — explicit scope law; the safest
    way to prove access-control, IDOR/BOLA, race and logic bugs.
15. **SOC / detection-engineering lens everywhere** — detection
    opportunities required in every posture analysis; dedicated SOC
    learning file. Hunting teaches defending at the same time.
16. **Client-side/browser playbook (13) + deserialization / prototype
    pollution / supply-chain playbook (14)** — high-value modern classes
    the brief never named.
17. **Disclosure / retest / duplicate playbook (16) + log template** —
    real hunts continue after submission; most packs pretend they end there.
18. **Spaced-repetition learning system** — flashcards + retention
    checklist generated from every finding's learning notes.
19. **Three extra Python helpers in v18** — `headers_check.py`,
    `tech_fingerprint.py`, `inventory.py` (stdlib-only, tested).
20. **Portable tool catalog with tier labels** — agents stop guessing
    which tools are pre-approved vs ask-first.
21. **Chain canvas template (Mermaid)** — visual exploit-chain planning.
22. **Fictional worked examples for CVE matching and for chaining.**
23. **Metrics section (AGENTS.md §13)** — quality = real impact, near-zero
    false positives, and operator learning — never report count.
24. **START-HERE.md** — a 10-minute human onboarding page, separate from
    the agent-facing README.

## C. NEW IN V20 — expansions added in this version

25. **NEW IN V20 — Playbook 17: WebSocket/realtime & HTTP request
    smuggling / cache.** The brief said "web vulnerabilities" generally;
    it never named realtime protocols or smuggling. Modern apps are
    realtime (chat, live data, collaboration) and sit behind layered
    proxies/CDNs — exactly where smuggling and cache bugs hide. *Why it
    helps:* gives Joshua two of the highest-impact, least-duplicated
    classes on current programs, taught as state machines and parser
    differentials rather than payload lists.
26. **NEW IN V20 — AGENTS.md §14: an extra safety gate for smuggling/cache.**
    No earlier pack needed a technique-specific gate. Smuggling/cache
    probes are uniquely able to affect *other* users when they fail, so
    v20 adds: mandatory safety checklist, program-prohibition check,
    self-only proof design (unguessable keys, benign markers), one-probe-
    at-a-time rule, and a "learn it in labs first" default. *Why it helps:*
    Joshua can learn an advanced class without it ever becoming a risk to
    a real service — the pack teaches restraint as a senior skill.
27. **NEW IN V20 — Playbook 18: OAuth / OIDC / Passkeys deep dive.**
    Playbook 04 covered auth generally; v20 goes protocol-deep:
    authorization-code + PKCE, legacy flows, redirect URI logic, token
    lifecycle, OIDC validation, WebAuthn/passkey ceremonies, account
    linking. *Why it helps:* identity is where critical account-takeover
    bugs live on mature programs, and it is the class beginners most
    often test shallowly (one request) instead of as a sequence.
28. **NEW IN V20 — Playbook 19: Serverless & edge.** Functions, edge
    workers, gateways, event triggers, presigned URLs, per-function IAM.
    The brief's "cloud" (playbook 09) assumed servers; much of 2026's
    attack surface has none. *Why it helps:* teaches Joshua to threat-
    model the function + trigger + role as the unit, a mental model that
    transfers to all cloud work and SOC cloud-log reading.
29. **NEW IN V20 — Playbook 20: Bug chaining at scale + Workflow 10 +
    Template 15.** v18 introduced chaining as a canvas for one chain;
    v20 makes it a program-wide discipline: inventory every validated
    primitive, graph the joins, climb impact ladders deliberately.
    *Why it helps:* this is the single biggest severity multiplier in
    real hunting — three "lows" that chain are one critical — and the
    brief asked for "sophisticated techniques" without naming the
    mechanism; chaining *is* that mechanism.
30. **NEW IN V20 — Workflows 08 & 09.** 08 (OSINT & autonomous research
    sweep) formalises the brief's "agents research on their own" into a
    repeatable, people-free, read-only sweep. 09 (realtime / smuggling /
    cache deep-dive) is the gated executable route for playbook 17.
    *Why it helps:* research stops being ad-hoc Googling; dangerous
    testing stops being improvisation.
31. **NEW IN V20 — Core 08: Autonomous agent ops & memory.** Session
    memory, handoffs, long-hunt state, anti-loop/anti-drift rules.
    The brief assumed an agent; v20 governs *how the agent itself works*
    across sessions. *Why it helps:* multi-week hunts stop losing
    negative results, ruled-out hypotheses and approval state between
    sessions — the most common failure of AI-assisted hunting.
32. **NEW IN V20 — Core 09: Data handling & OPSEC hygiene.** Per-program
    compartmentation, evidence retention, what never leaves the machine,
    secret handling at scale (expands AGENTS.md §9). *Why it helps:*
    a student handling real vulnerability data early needs professional
    habits before he needs more techniques.
33. **NEW IN V20 — Core 10: Detection & purple-team lens.** Every attack
    step gets a testable detection hypothesis; posture analyses gain a
    purple-team handover section. *Why it helps:* doubles the learning
    value of every hunt for a future SOC analyst/pentester, and produces
    the defender-friendly reports triagers and security teams love.
34. **NEW IN V20 — Learning 07: Cryptography from zero.** Hashing,
    encryption, signatures, TLS, JWT internals — from first principles.
    *Why it helps:* crypto-adjacent findings (token forgery confusion,
    JWT misuse, TLS mistakes in playbooks 17–18) are un-teachable without
    it, and "crypto" is the foundation gap students hit hardest.
35. **NEW IN V20 — Learning 08: OS basics — Linux & Windows for pentest.**
    Users, permissions, processes, services, shells, logs on both OSes.
    *Why it helps:* every server-side bug lands on an operating system;
    Joshua's Windows 11 daily driver plus Linux targets both get covered,
    which also feeds SOC log literacy.
36. **NEW IN V20 — Learning 09: Career roadmap SOC → Pentest.** Skills
    map, lab milestones, portfolio building from hunts, honest notes on
    certifications. *Why it helps:* connects each hunt to a direction —
    the pack stops being only a tool and becomes a study programme.
37. **NEW IN V20 — Templates 13 & 14.** Identity flow map (OAuth/OIDC/
    passkey sequences drawn before they're tested) and realtime &
    smuggling/cache test log (per-probe, gate-aware). *Why it helps:*
    sequence bugs need sequence-shaped notes; gated probes need
    gate-shaped logs. Free-form notes fail both.
38. **NEW IN V20 — Checklists: AI-agent preflight + smuggling/cache
    safety.** The preflight verifies the *agent* (scope file present,
    memory loaded, approvals known) before it verifies the target.
    *Why it helps:* most agent mistakes are setup mistakes; a 2-minute
    preflight prevents the expensive kind.
39. **NEW IN V20 — Scripts `har_analyzer.py`, `js_extract.py`,
    `evidence_hash.py` (10 total).** Offline-first: mine HAR captures and
    JS bundles the target already sent you (Tier A, zero target traffic),
    and hash evidence mechanically. *Why it helps:* the highest-value
    recon is often already on disk; and evidence integrity becomes a
    habit, not a hope.
40. **NEW IN V20 — Cursor 4th rule (`30-creative-research-and-chaining.mdc`)
    + Antigravity `/osint-sweep` and `/chain-sprint` workflows.** Platform
    parity for the new material: creative/chaining discipline is now
    always-loaded in Cursor, and the two most reusable v20 routes are
    one slash-command away in Antigravity. *Why it helps:* expansions
    that live only in the root file get forgotten by adapters; these don't.
41. **NEW IN V20 — Playbook map in AGENTS.md §11 + §14 cross-references
    in SKILL.md.** A one-glance index so no agent (or student) has to
    memorise 20 playbooks to find the right one. *Why it helps:* packs
    fail by being un-navigable at exactly the moment they're needed.

---

*Reporting note for the operator: items 25–41 are the expansions to report
in the delivery message for pack 20, grouped as: new playbooks 17–20,
workflows 08–10, core 08–10, learning 07–09, templates 13–15, two new
checklists, three new scripts, the §14 safety gate, and the Cursor /
Antigravity adapter additions.*
