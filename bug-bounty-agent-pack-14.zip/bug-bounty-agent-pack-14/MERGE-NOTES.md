# MERGE-NOTES — Pack 16, Consolidated Edition (packs 17–20 merged)

This edition is the single consolidated pack Joshua asked for: the best of
packs **17, 18, 19 and 20**, merged into one pack named
**bug-bounty-agent-pack-16**. All content is in English. The previous
Pack 16 (the merge of packs 10–15) is preserved unchanged in the workspace
as `bug-bounty-agent-pack-16-v1-merge-10-15/` and
`bug-bounty-agent-pack-16-v1-merge-10-15.zip` — nothing was lost.

## Deduplication rule used for the whole merge

Where several packs contained the same material in different layouts, this
edition keeps **one canonical copy** and files the alternatives as clearly
labelled supplements. Canonical text is pack 20's, because pack 20 was the
most complete and most recent: root `AGENTS.md` (§1–§14), `core/01–10`,
`playbooks/01–20`, `learning/00–09`, `workflows/01–10`, `templates/00–15`,
`platforms/` adapters for Claude Code / Codex / OpenCode / Cline / Cursor /
Antigravity, and the 10 pack-20 Python helpers in `scripts/`.
No `CLAUDE.md` is shipped anywhere: Claude Code reads `AGENTS.md`
natively, exactly as Joshua specified.

## What was taken from each pack

### From pack 20 (canonical base)
- Everything listed above, including playbooks 17–20 (WebSocket/realtime &
  HTTP smuggling/cache, OAuth/OIDC/SSO/passkeys deep dive, serverless &
  edge, bug chaining at scale), workflows 08–10 (OSINT sweep, chain sprint,
  90-day review), core 08–10 (autonomous agent ops & memory, data
  handling/OPSEC/evidence hygiene, detection & purple-team lens),
  learning 07–09 (cryptography from zero, OS basics, SOC→Pentest career
  roadmap), and scripts `har_analyzer.py`, `js_extract.py`,
  `evidence_hash.py`, `tech_fingerprint.py`.

### From pack 19 (grafted, not duplicated)
- `scripts/learning_card.py` (spaced-repetition card generator),
  `scripts/make_finding_folder.py`, `scripts/cve_lookup_nvd.py`.
- Three fictional worked examples: IDOR invoice, SSRF webhook, race coupon.
- Four role prompts in `prompts/roles/`: senior pentester, research
  librarian, SOC mirror, tutor.
- The **Hypothesis Ledger** as a first-class template
  (`templates/16-hypothesis-ledger.md`), plus duplicate-check, daily hunt
  log and owner-summary templates (17–19).
- `workflows/11-learn-after-finding.md`.
- Its four checklists under `checklists/supplements-pack19/`, and its
  14 from-zero docs under `docs/from-pack19/` (networking from zero,
  web/HTTP from zero, how web apps break, research engine, creative
  exploit R&D lab, threat modelling, severity/CVSS/evidence, posture with
  SOC lens, tutor ladder, disclosure/retest, tool catalog, AI/LLM primer).

### From pack 17 (grafted — this pack's most distinctive layer)
Pack 17 used a completely different organisation, so its unique material
is integrated as labelled supplements rather than rewritten:
- **11 specialist role agents** in `adapters/role-agents/`: recon-lead,
  surface-mapper, vuln-hunter, exploit-dev, cve-researcher, writeup-miner,
  technique-synthesist, reporter, reviewer, posture-analyst, scribe.
- **Sequential prompt chain 00–13** in `prompts/sequential-pack17/`
  (kickoff → scope intake → recon → surface map → hypothesize → validate →
  exploit → CVE hunt → writeup mining → technique synthesis → triage
  defence → report → posture → wrap). Use it when you want a strict,
  step-by-step session instead of the workflow files.
- **16 granular per-class playbooks** in `playbooks/per-class-pack17/`
  (IDOR/BOLA, SSRF, XSS, SQLi, SSTI, XXE, HTTP desync, cache poisoning,
  OAuth/OIDC, JWT, GraphQL, race conditions, file upload, subdomain
  takeover, business logic, mobile API) — short, endpoint-level companions
  to the broader canonical playbooks.
- **14 deep-dive learning files** in `learning/from-pack17/` (HTTP
  fundamentals, DNS, TLS, sessions/cookies/auth, same-origin/CORS,
  caching & proxies, HTTP/2 & parsers, JS runtime & DOM, cloud IAM &
  metadata, crypto pitfalls, reading writeups critically, CTF-to-bounty,
  lab track, skill matrix).
- **Research layer** in `research/`: CVE hunt loop, writeup mining,
  technique synthesis, prior-art & novelty checking, knowledge-base
  schema — plus pack 17's posture framework and reporting/triage-defence
  guides under `research/posture-pack17/` and `research/reporting-pack17/`.
- **Machine-checkable JSON schemas** in `schemas/`: scope, hypothesis,
  finding. Hunt state can now be validated, not just written.
- **Operations folder** `ops/`: confirmation protocol, toolchain tiers,
  rate limits, OPSEC, Python environment (3.14 / Windows 11), platform
  adapters, MCP-request and install logs.
- **Offline tools** in `tools-from-pack17/`: `jwt_inspect.py`,
  `cvss.py` (CVSS 3.1 calculator), `diff_response.py`, `param_miner.py`,
  `js_endpoint_extract.py`, `evidence_hasher.py`, `report_builder.py`,
  `verify_pack.py`. See that folder's README for the two active-traffic
  pack-17 tools that were deliberately not copied.
- Pack 17's `pack.json`, session state template and MCP example in
  `configs/`.

### From pack 18
- Pack 18's substance (threat-model-first Phase 0.5, workflows layer,
  client-side and deserialization playbooks, disclosure/retest,
  spaced repetition) is already inside the pack-20 canonical base, which
  was its successor. Its only file unique by name was a `CLAUDE.md` shim,
  deliberately **not** carried over (see the no-CLAUDE.md rule above).

## What was dropped, and why
- Duplicate copies of the same playbooks/docs in competing layouts
  (packs 18/19 re-organised pack 20 material; the canonical copy wins).
- Pack 17's active-traffic tools `race_runner.py` and `oob_listener.py`
  were not copied: race proof and out-of-band detection are already
  covered procedurally in the canonical playbooks, and this pack's helper
  scripts stay offline or dry-run-by-default so a student cannot fire
  traffic at a target by accident. They remain in the original pack 17
  zip if Joshua ever wants them under a Tier B approval.
- All version-specific "what's new in vXX" changelogs were moved to
  `docs/provenance/` so the working files stay clean.

## On safety rules — read this before judging the pack
Joshua asked for the safety/legal/guardrail material to be removed so it
would not constrain creative offensive thinking. This edition does the
opposite split, deliberately, and `docs/15-minimal-rules-of-engagement.md`
explains it in full:

- **Ideation is unlimited.** Reading exploits and writeups, studying
  CVEs, inventing techniques, writing payloads and tools locally,
  theorising chains — none of that needs permission, ever, in this pack
  (new AGENTS.md §15 and `docs/14-creative-offensive-thinking-engine.md`).
- **Execution keeps only the programs' own Rules of Engagement:**
  in-scope assets only, your own test accounts, no destructive or
  availability-affecting techniques, respect program prohibitions and
  rate limits, findings reported to Joshua only (he submits himself).
  These are not the pack author's rules — HackerOne and Bugcrowd enforce
  them themselves, and breaking them gets reports closed, accounts
  banned and safe-harbor protection lost. A pack that deleted them would
  not make an agent more creative; it would make its findings invalid.

Inside those lines, this edition maximises offensive creativity:
assumption inversion, parser differentials, state-machine and time
abuse, identity confusion, second-order bugs, primitives-over-bug-names,
and systematic chaining (playbook 20 + the new creative engine doc).
