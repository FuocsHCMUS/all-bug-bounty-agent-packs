# Bug Bounty Super Agent Prompt Pack — Pack 16, Consolidated Edition (merges packs 17–20)

A complete, platform-agnostic prompt pack that turns a coding agent
(Claude Code, Codex, OpenCode, Cline, Cursor, Antigravity, or any agent that
reads `AGENTS.md`) into a **disciplined, senior-level bug bounty research
partner** — and a patient teacher for a cybersecurity student.

> **Golden rule:** Only test assets that are **explicitly in scope** of a
> public bug bounty / VDP program, a written engagement, or a lab/CTF you own.
> When in doubt: stop, check the program page, ask the human operator.
> **New humans: read `START-HERE.md` first (10 minutes).**


> **Consolidated Edition note:** This pack merges packs 17, 18, 19 and 20
> into one. Canonical instructions are pack 20's `AGENTS.md` §1–§14 plus
> new §15–§16; pack 17's role agents, sequential prompts, per-class
> playbooks, schemas, research and ops layers, and pack 19's hypothesis
> ledger, role prompts and learning scripts are grafted in as labelled
> supplements. Read `MERGE-NOTES.md` first for the full provenance map,
> `docs/14-creative-offensive-thinking-engine.md` for the creativity
> method, and `docs/15-minimal-rules-of-engagement.md` for why the pack
> keeps only the programs' own seven rules of engagement.

---

## 1. What this pack does

1. **Hunt methodically** on HackerOne, Bugcrowd, Intigriti, YesWeHack and
   self-hosted programs — scope → **threat model** → recon → mapping →
   hypothesis → minimal proof → validation → report → retest.
2. **Research autonomously (read-only):** CVE / advisory / KEV research,
   fingerprint-to-CVE matching, OSINT research sweeps, mining disclosed
   reports, writeups and CTF solutions for transferable techniques, and
   offline mining of HAR captures and JavaScript bundles the target
   already shipped to your browser.
3. **Think creatively — and chain at scale:** chain low-severity issues,
   invert developer assumptions, abuse state machines and parser
   differentials, design novel test cases — and, in v20, systematically
   combine validated primitives across a whole program into high-impact
   chains (playbook 20). Always inside scope and program rules.
4. **Cover the modern surface deeply:** WebSocket/realtime channels and
   HTTP request smuggling/cache behaviour (playbook 17, extra safety
   gate), OAuth/OIDC/passkey identity flows (playbook 18), and
   serverless/edge architectures (playbook 19) join the v18 coverage of
   web, API, cloud, mobile, AI/LLM, client-side and supply-chain classes.
5. **Analyse like a consultant:** after every finding (and every hunt), produce
   a Security Posture Analysis — what the company does well, what needs
   improvement, what is risky / high-risk, detection opportunities for their
   SOC, and what it teaches about Pentest / SOC / Blue Team work — now with
   a purple-team lens (core 10): detections phrased as testable hypotheses.
6. **Teach from first principles:** every concept explained bottom-up —
   networking and HTTP first, then the vulnerability, then exploitation,
   detection and defence — with exercises and spaced-repetition flashcards.
   v20 adds cryptography from zero, OS basics (Linux & Windows) for pentest,
   and a SOC → Pentest career roadmap (learning 07–09).
7. **Run the agent itself professionally:** an AI-agent preflight checklist,
   explicit agent memory/handoff discipline (core 08), and data-handling /
   OPSEC hygiene rules (core 09) keep long, multi-session hunts coherent
   and evidence trustworthy (SHA-256 manifests via `evidence_hash.py`).

## 2. Quick start

See `START-HERE.md`. Short version: copy the adapter for your tool, fill the
scope intake for ONE program, paste `prompts/01-start-a-hunt.md`, and let the
agent threat-model before it tests anything.

## 3. Which files go where

| Tool | Copy to project root | Notes |
|---|---|---|
| **Claude Code** | root `AGENTS.md` (primary); optionally `platforms/claude-code/.claude/skills/bug-bounty/SKILL.md` → `.claude/skills/bug-bounty/` | Claude Code reads `AGENTS.md` directly — **there is no `CLAUDE.md` in v20** (removed: AGENTS.md is natively supported). |
| **Codex (OpenAI)** | root `AGENTS.md`; optionally `platforms/codex/config.toml.example` | Codex is `AGENTS.md`-native. |
| **OpenCode** | root `AGENTS.md`; `platforms/opencode/opencode.json.example`; `.opencode/agent/bug-bounty.md` | Dedicated `bug-bounty` agent defined. |
| **Cline** | `platforms/cline/.muserules` + root `AGENTS.md` | Keep both; recent Cline respects AGENTS.md too. |
| **Cursor** | `platforms/cursor/.cursor/rules/*.mdc` → `.cursor/rules/` + root `AGENTS.md` | Split rules: core, safety, research/reporting, **creative research & chaining (NEW v20, 4 rules total)**. |
| **Antigravity** | `platforms/antigravity/.agent/rules/*.md`, `.agent/workflows/*.md`, `GEMINI.md` | Rules = always-on; Workflows = slash-invoked. **v20 adds `/osint-sweep` and `/chain-sprint` workflows (7 total).** |
| **Anything else** | root `AGENTS.md` + `SKILL.md` | Canonical content lives there; adapters re-point to it. |

## 4. Folder map

```
AGENTS.md            Canonical instructions for every agent (§1–§14)
SKILL.md             Skill definition: triggers, workflow, playbook/core maps, outputs
START-HERE.md        10-minute human onboarding
README.md            This file
EXPANSIONS.md        Ideas added beyond the original request, and why
CHANGELOG-vs-pack18.md  What changed since pack 18 (v18 notes: CHANGELOG-vs-pack15.md)
core/                01 persona · 02 approval protocol · 03 workflow/evidence ·
                     04 ethics · 05 hypothesis & creative engine · 06 teaching ·
                     07 threat modeling · 08 agent ops & memory [NEW v20] ·
                     09 data handling & OPSEC [NEW v20] ·
                     10 detection & purple-team lens [NEW v20]
platforms/           Per-tool adapters (Claude Code, Codex, OpenCode, Cline, Cursor, Antigravity)
playbooks/           01 recon · 02 web · 03 API · 04 auth · 05 business logic ·
                     06 CVE intel · 07 writeup mining · 08 creative R&D ·
                     09 cloud · 10 mobile · 11 AI/LLM · 12 validation (→15) ·
                     13 client-side · 14 deser/PP/supply-chain ·
                     15 validation & CVSS · 16 disclosure/retest ·
                     17 WebSocket/realtime & smuggling/cache [NEW v20] ·
                     18 OAuth/OIDC/Passkeys [NEW v20] ·
                     19 serverless & edge [NEW v20] ·
                     20 bug chaining at scale [NEW v20]
workflows/           10 executable step-by-step routes: 01 start-a-hunt ·
                     02 CVE sweep · 03 writeup mining · 04 creative chain lab ·
                     05 validate & report · 06 posture & teach-back ·
                     07 weekly review & retest ·
                     08 OSINT & autonomous research sweep [NEW v20] ·
                     09 realtime/smuggling/cache deep-dive [NEW v20, gated] ·
                     10 chain-at-scale sprint [NEW v20]
learning/            00 how to teach · 01 foundations curriculum · 02 glossary ·
                     03 networking from zero · 04 web/HTTP from zero ·
                     05 SOC lens · 06 safe lab roadmap ·
                     07 cryptography from zero [NEW v20] ·
                     08 OS basics Linux/Windows for pentest [NEW v20] ·
                     09 career roadmap SOC → Pentest [NEW v20]
templates/           00 scope intake · 01 dossier · 02 hypotheses · 03 report ·
                     04 platform variants · 05 posture · 06 learning notes ·
                     07 CVE match · 08 technique card · 10 chain canvas ·
                     11 retest log · 12 threat model ·
                     13 identity flow map [NEW v20] ·
                     14 realtime & smuggling/cache test log [NEW v20] ·
                     15 chain-at-scale canvas [NEW v20]
checklists/          Preflight, scope gate, recon/testing, exploit safety,
                     report QA, learning retention +
                     AI-agent preflight [NEW v20] +
                     smuggling & cache safety [NEW v20]
prompts/             Copy-paste kick-off prompts (8)
scripts/             10 safe Python helpers (stdlib-first, Windows 11, Python 3.14+):
                     scope_guard, headers_check, tech_fingerprint, cve_lookup,
                     http_probe, inventory, make_hunt +
                     har_analyzer, js_extract, evidence_hash [NEW v20]
references/          Trusted sources, CVE/advisory sources, writeup/CTF sources
examples/            Fictional worked examples: finding, CVE match, chain
tools/               Portable tools/repos cloned HERE + tool catalog (gitignored content)
workspace/           Per-target working notes HERE (one subfolder per program)
```

## 5. Environment assumptions

- Operator machine: **Windows 11**, **Python 3.14.x+**, PowerShell + Git Bash/WSL.
- `pip install` inside a project venv and cloning **portable, no-install**
  tools/repos into the current workspace `./tools/` are **pre-approved (Tier A)**.
- Running anything **against a target**, system-wide installs, and installing
  **MCP servers / plugins / skills** require the operator's explicit OK (Tier B).
- The operator **submits reports himself**; agents draft and hand over.
  Full protocol: `AGENTS.md` §4, `core/02-approval-protocol.md`.
- Smuggling/cache testing carries one more gate on top: `AGENTS.md` §14 +
  `checklists/smuggling-and-cache-safety.md`. No exceptions, no shortcuts.

## 6. Safety & legality in one paragraph

Bug bounty is *authorised* testing under a program's rules — not a licence to
attack the internet. Respect scope, rate limits, and prohibited techniques
(usually: no DoS, no social engineering, no accessing other users' real data
beyond minimum proof, no persistence, no pivoting). Stop and ask the human
when a test could affect real users, production data, or availability.
When a program and this pack conflict, **the program wins**.

## 7. Version

Pack **v20** — English edition. Superset of v18 and v19 (see
`CHANGELOG-vs-pack18.md`). Standalone; no dependency on earlier packs.
