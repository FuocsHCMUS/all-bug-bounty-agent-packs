# START HERE — Bug Bounty Agent Pack v20

You (the human) do this once. Takes ~10 minutes.

## 1. Pick your agent tool and copy the adapter

| Your tool | Copy this | Where it goes |
|---|---|---|
| Claude Code | Root `AGENTS.md` + `SKILL.md` | Project root. Claude Code reads `AGENTS.md` directly; there is no `CLAUDE.md` in v20 — it is not needed anymore. Optionally copy `platforms/claude-code/.claude/` into your project for the skill format. |
| Codex | `platforms/codex/AGENTS.md` + `config.toml.example` | Project root (rename example to `config.toml` if you use it) |
| OpenCode | `platforms/opencode/` | `.opencode/agent/bug-bounty.md` + `opencode.json` from the example |
| Cline | `platforms/cline/.muserules` | Project root as `.muserules` |
| Cursor | `platforms/cursor/.cursor/rules/*.mdc` (4 rules in v20) | `.cursor/rules/` in your project |
| Antigravity | `platforms/antigravity/.agent/` + `GEMINI.md` | `.agent/` in your workspace + `GEMINI.md` at root. v20 adds `/osint-sweep` and `/chain-sprint` workflows. |

Every adapter points back to the root `AGENTS.md`. That file is the law.
You never need to edit six copies — edit the root, adapters follow.

## 2. Open your first hunt

1. In your agent, paste the prompt from `prompts/01-start-a-hunt.md`.
2. Give it ONE program (HackerOne/Bugcrowd page URL) you are signed up for.
3. The agent must fill `templates/00-scope-intake.md` and
   `templates/12-threat-model.md` BEFORE any testing, and run
   `checklists/ai-agent-preflight.md` (new in v20) at the start of every
   session. If it tries to test first, stop it — that is the pack working wrong.
4. Approve/deny Tier B requests as they come (see `AGENTS.md` §4).

## 3. Know the three rules that protect you

- **No scope doc, no testing.** Ever.
- **Your two test accounts only.** Never touch real users' data to "prove" a bug.
- **You submit reports yourself.** The agent drafts; you read, you submit.

One more in v20: **smuggling/cache probes are special.** They can affect
other users when they go wrong, so they need the extra gate in
`AGENTS.md` §14 + `checklists/smuggling-and-cache-safety.md`, and you
learn them in labs first. If an agent proposes one casually, say no.

## 4. After your first finding (or first clean hunt)

Demand both outputs — they are mandatory in this pack:
`posture-analysis.md` (what the company does well / badly, risks, SOC view,
purple-team detection hypotheses) and `learning-notes.md` (the concept from
zero, the bug, the fix, exercises). If the agent skips them, point it at
`AGENTS.md` §8.

## 5. Grow — learning paths (expanded in v20)

Foundations, in the order a beginner should climb them:

1. `learning/03-networking-from-zero.md` — packets, DNS, TCP, TLS handshake.
2. `learning/04-web-and-http-from-zero.md` — requests, cookies, sessions, CORS.
3. `learning/07-cryptography-from-zero.md` **[NEW v20]** — hashing vs
   encryption vs signatures, TLS properly, and how JWTs actually work, so
   crypto-adjacent bugs (playbook 18) stop looking like magic.
4. `learning/08-os-basics-linux-and-windows-for-pentest.md` **[NEW v20]** —
   users, permissions, processes, shells and logs on both operating
   systems; the ground every serverless/cloud lesson (playbook 19) stands on.
5. `learning/01-foundations-curriculum.md` + `learning/05-soc-lens.md` —
   the full curriculum and the defender's view of everything above.
6. `learning/09-career-and-skill-roadmap-soc-to-pentest.md` **[NEW v20]** — where
   this is all heading: skills map from SOC analyst to pentester, lab
   milestones, and how each hunt in this pack builds portfolio evidence.

Hunting growth, once the basics hold:

- Weekly: run `workflows/07-weekly-review-and-retest.md`.
- Before a new program: `workflows/08-osint-and-attack-surface-discovery.md`.
- Stuck for ideas: `workflows/04-creative-chain-lab.md`, then
  `workflows/10-90-day-review-and-skill-gap-plan.md` when you hold 2+ small bugs.
- New stack on a target: `workflows/02-cve-sweep.md`.
- Identity-heavy target (SSO, "Sign in with…", passkeys):
  `playbooks/18-oauth-oidc-sso-and-passkeys-deep-dive.md` + `templates/13-evidence-manifest.md`.
- Realtime app (chat, live dashboards, trading, games):
  `playbooks/17-websocket-realtime-and-http-smuggling-cache.md` — realtime half
  freely, smuggling/cache half only through the §14 gate.
- Want to learn a class deeply: `learning/01-foundations-curriculum.md`.
