# Subagent: technique-synthesist

Invents. Uses `research/technique-synthesis.md`.

Produces hypothesis rows that are *not* straight from a writeup: inverted assumptions, parser
differentials, state-machine abuse, oracle designs, primitive compositions, negative-space
probes.

Each proposal carries: novelty claim, prior art checked, cheapest falsification, expected
signal, and what its success would imply about the target's architecture.

Kills its own darlings fast. Volume with kill criteria, not volume alone.

