# Checklist — AI Agent Preflight (before ANY autonomous session)

Run this before an autonomous or semi-autonomous hunting session starts —
before the first request, tool run, or research claim is used. This list
checks the *agent*, not the target: most autonomous-session failures are
not technique failures, they are setup failures (no scope, stale state,
assumed approvals). Companion files: Core 08 (agent operations & memory),
Core 02 (approval protocol), `checklists/preflight-safety.md` (target-side
safety — run both; neither replaces the other).

If any **STOP** item fails: do read-only reconciliation work only, fix the
gap, and re-run this list. Do not "start and fix it on the way."

---

## A. Identity, mode & session framing

- [ ] I know which program/target this session is for — one target, named:
- [ ] I know the session's single goal, stated in one sentence:
- [ ] I know the session type: ☐ research-only ☐ recon ☐ testing
      ☐ validation/reporting ☐ retest — and the phases I may *not* enter:
- [ ] I have a time box / request budget for this session: …
- [ ] I know how the operator will be updated (heartbeat at phase changes,
      summary block at close — AGENTS.md §10)

## B. Scope loaded — STOP items

- [ ] **STOP** — Scope intake (`templates/00-scope-intake.md`) for THIS
      program exists, is complete, and I have re-read it *this session*
- [ ] **STOP** — I can state, without looking: the in-scope assets, the
      out-of-scope assets, and the prohibited techniques for this program
- [ ] **STOP** — Rate limits / automation rules for this program are
      known and written in the intake — not assumed from another program
- [ ] Test-account rules known (A/B accounts, `+alias`/header requirements)
- [ ] Disclosure/reporting channel known (and: the operator submits, not me)
- [ ] Scope ambiguities listed — each one is either resolved or the asset/
      technique it touches is excluded from today's plan:

## C. Approvals clear — STOP items

- [ ] **STOP** — I know which of today's planned actions are Tier A
      (pre-approved), which are Tier B (ask first), which are Tier C (never)
      — per Core 02 / AGENTS.md §4, not from habit
- [ ] **STOP** — Tier B approvals already obtained are written in
      `approvals-log.md` with date + exact scope of the approval.
      Approvals I cannot find written down **do not exist**
- [ ] Tier B requests still needed are drafted (what / why / target & rate /
      expected noise / how to stop) and will be asked *once, clearly*,
      before — not during — the run they cover
- [ ] No approval is being stretched: a yes for target X / tool Y / Tuesday
      is not a yes for anything else
- [ ] System-wide installs, MCP servers, plugins, skills, browser
      extensions needed today: ☐ none ☐ listed for operator to install himself

## D. State files exist & are current

- [ ] `hunt-state.md` exists and its "Last updated" is from the previous
      session's close-out (if not: reconcile before testing — Core 08 §4.2)
- [ ] I have read: current phase, confirmed findings, *candidate* findings
      (with ladder levels — Core 08 §8), top open hypotheses, blockers
- [ ] `experiment-log.md` exists; I know the last EXP number and will
      continue numbering from it (never reuse a number)
- [ ] Do-not-repeat list reviewed — I will not blindly re-run closed tests
- [ ] `hypothesis-backlog.md` reviewed; today's queue item is chosen and
      its question is statable in one sentence
- [ ] `evidence-log.md` / evidence manifest (Template 13) exists or will be
      created at first capture — and the `evidence/originals/` +
      `evidence/shareable/` folders exist
- [ ] Research log (Template 14) exists if research claims will be used today
- [ ] Contradictions between state files found? ☐ No ☐ Yes — reconciled
      against raw evidence before proceeding (lowest-level record wins)

## E. Tools, scripts & environment

- [ ] Every tool/script I plan to run today: I have read it (or its docs)
      and can say what it sends, at what rate, and how to stop it
- [ ] Tools live where the rules say: portable tools under the workspace
      `tools/` folder, logged in `tools/TOOLS-LOG.md` (URL + version/commit)
- [ ] Python work uses the hunt venv (Python 3.14, operator's Windows 11);
      missing libraries go in the venv (`pip install` there is Tier A) —
      nothing is being installed system-wide by me
- [ ] Tool configs checked against THIS program's limits (rate, headers,
      research identifier, scope file loaded into any guard/scanner config)
- [ ] Dry-run / safe mode used first wherever the tool offers it
- [ ] Kill procedure known for every long-running tool (how I stop it *now*)

## F. Data handling ready (Core 09)

- [ ] Test data markers for this hunt known and in use (obviously-test data)
- [ ] I know where secrets go if I find them: type + last 4 in notes,
      full value (if unavoidable) in `evidence/originals/` only
- [ ] No credentials/tokens pasted in my plan, notes, or scripts (scripts
      read env vars / operator-managed config only)
- [ ] Redaction workflow ready for anything shareable (body / headers /
      URL / filename / metadata — all five)
- [ ] I know the accident playbook: over-access, found compromise, or a
      leak → stop, note facts, tell the operator the same session

## G. Stop conditions & escalation

- [ ] **STOP** — Stop conditions for this session are written down:
      production instability, real users' data appearing, WAF/IDS
      escalation, company contact, scope uncertainty, approval expiry
- [ ] I know the critical-finding rule: pause, minimal evidence, escalate
      to the operator — no "exploring a bit more to be sure"
- [ ] Extra gates checked for today's classes: smuggling/cache →
      `checklists/smuggling-and-cache-safety.md` completed *first*
- [ ] If the session is a retest: original proof + program's fix notes
      loaded, and retest scope = the fix, not a fresh free hunt

## H. Opening statement (say it, don't just tick it)

Before the first action, state to the operator, in this order:

1. Program + in-scope set (one line) and key out-of-scope items
2. Session goal + phase + time/request budget
3. Approvals in hand (Tier B items, with dates) and approvals still needed
4. Last confirmed result from the state file + today's next action
5. Any blocker, ambiguity, or stale-state issue found by this checklist

If line 4 cannot be stated, the session starts with reading, not testing.

Preflight run by: … Date/time (+TZ): … Result: ☐ GO ☐ NO-GO — gaps:
