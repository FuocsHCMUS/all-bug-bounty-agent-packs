# Checklist — Smuggling & Cache Safety (extra gates, mandatory)

HTTP request smuggling and cache poisoning/deception are different in kind
from most web bugs: **a failed or sloppy test can affect other people's
traffic.** A desynchronised connection or a poisoned cache entry is shared
infrastructure — the next "victim" of your test could be a real user who
never consented to be in your experiment. That is why this class carries
gates *on top of* the normal scope and approval rules (AGENTS.md §2/§4,
Core 04, `checklists/preflight-safety.md`). All gates must pass, in order.
Any single failure = this class is closed for today.

Beginner note: if you cannot yet explain, in plain words, (1) how a
front-end/back-end pair can disagree about where one request ends and the
next begins (smuggling), and (2) how a shared cache decides what to store
and who to serve it to (poisoning/deception) — you are not ready to test
either live. Study first (Learning 04, PortSwigger Academy labs in a lab
environment), and file what you learned. The operator is a student;
learning this class safely in labs *is* progress.

---

## Gate 0 — Competence & preparation

- [ ] I can explain both bug classes from first principles, out loud,
      including *why third parties can be harmed*
- [ ] I have completed lab exercises for this class (which labs, when —
      recorded in learning notes): …
- [ ] I have read the current primary research for the specific variant I
      intend to test, logged in the research log (Template 14) at
      Corroborated or better — not just a summary or a payload list
- [ ] I can name the exact difference my test predicts: baseline behaviour
      vs expected behaviour if vulnerable — in one sentence each

## Gate 1 — Program permission (explicit, not implied)

- [ ] The program's rules have been re-read *for this class specifically*:
      smuggling / cache / "techniques affecting other users" are
      ☐ explicitly allowed ☐ silent (see next box) ☐ prohibited → STOP
- [ ] If the rules are silent or ambiguous: the operator has asked the
      program (Tier B — the operator sends) **or** the decision is recorded
      as "do not test this class on this program." Silence is not consent
      for shared-infrastructure techniques
- [ ] Program rate limits, test windows, and any CDN/cache-provider
      boundaries are known (is the cache even the *target company's* to
      authorise, or a third party's? If third-party rules apply, they pass too)
- [ ] Scope intake updated to record this class's permission status + date

## Gate 2 — Tier B approval for THIS test design

- [ ] A specific Tier B approval exists for smuggling/cache testing on
      this target, this session — what / why / target & rate / expected
      noise / how to stop (Core 02 format), logged in `approvals-log.md`
- [ ] The approval covers the *exact* variant and endpoint set planned.
      A generic "cache testing OK" does not cover a new variant invented
      mid-session — that is a new approval
- [ ] The operator understands, from my explanation, the third-party risk
      in plain language — not just the technique name

## Gate 3 — Self-only proof design (the heart of this checklist)

Design the test so that even if it *works perfectly*, only you can be affected:

- [ ] **Unique, unguessable test URLs/keys:** every cache test uses a
      unique path/key that no real user will ever request (long random
      suffix, logged). Never test on the homepage, login page, popular
      assets, or any URL real traffic uses
- [ ] **Benign markers only:** the "poison" is a harmless, identifiable
      marker (a comment/string/header reflection you recognise) — never a
      script that executes for others, never a redirect to a third-party
      site, never content a real user could act on
- [ ] **Timing/observation before injection:** where a timing-based or
      other non-destructive differential can establish the signal first,
      it runs first. Response-splitting / stored proofs are the *last*
      step, not the opening move
- [ ] **Smuggling probes are single, manual, and logged:** one probe =
      one experiment-log entry, written *before* sending, with predicted
      result and stop condition. No loops, no fuzzers, no scanners,
      no parallel probes — ever, for this class, under this pack
- [ ] **Blast radius stated in writing:** "If this works / goes wrong,
      who else could see an effect, for how long?" If the honest answer
      is "unknown," the design is not finished
- [ ] **Expiry considered:** any cache entry I might create should expire
      quickly by design (short TTL paths, throwaway keys). If the target
      caches indefinitely and I cannot control expiry, escalate the design
      to the operator before — not after — the probe

## Gate 4 — Environment checks (just before sending)

- [ ] Baseline captured for the exact test URL (status, key headers,
      cache-status headers — e.g. hit/miss/age indicators — timing),
      logged as its own EXP entry
- [ ] I know how to recognise a cache hit vs miss on *this* target, and
      I have verified that recognition on a harmless self-request first
- [ ] Current time, test window, and rate budget confirmed; one probe
      does not become twenty "just to be sure" probes
- [ ] Monitoring mindset set: what will I watch *during* the probe
      (error rates on my own requests, unexpected responses, any sign of
      another session's behaviour bleeding into mine)
- [ ] Evidence capture ready (Core 09 / Template 13) — including capturing
      the *cleanup verification* in Gate 5, not just the exciting part

## Gate 5 — Stop conditions (pre-written, non-negotiable)

**Stop immediately, mid-plan if necessary, if any of these occur:**

- [ ] (acknowledged) A response appears that belongs to — or could belong
      to — another user/session (foreign data, someone else's request
      reflected, unexplained session behaviour)
- [ ] (acknowledged) Errors, latency, or instability spike on the target
      beyond my own requests (possible desync affecting the shared pool)
- [ ] (acknowledged) My marker appears on any URL other than my unique
      test URL, or persists beyond its expected expiry
- [ ] (acknowledged) WAF/IDS escalation, company contact, or any request
      to stop (AGENTS.md §2.6 — as always)
- [ ] (acknowledged) I no longer understand what the target is doing.
      Confusion is a stop condition for shared-infrastructure testing

On any stop: no further probes "to confirm." Preserve evidence, note the
time and exact observations, tell the **operator first**, then complete
the experiment log. Whether/how to notify the program is the operator's
decision, made promptly (Core 09 §8 thinking applies).

## Gate 6 — Cleanup & verification (same session, always)

- [ ] Verified my test cache entries have expired or been purged (how:
      re-request after TTL / program's purge route if provided / recorded
      as "expires at approximately …" with the evidence for that estimate)
- [ ] Verified no marker is reachable on any shared/popular URL (check
      list written before testing, checked now, results logged)
- [ ] Test objects/data created during the session deleted or listed for
      the program, per program expectations (Core 09 §3)
- [ ] Experiment log complete for *every* probe sent — count of probes in
      the log equals count of probes actually sent: ☐ reconciled
- [ ] Session summary to the operator explicitly states: probes sent,
      third-party effects observed (or "none observed" — an observation,
      worded as one), cleanup status, residual risk if any

## Sign-off

- Target / program: … Endpoints in design: …
- Variant(s) approved: …
- Checklist completed by: … Date/time (+TZ): …
- Operator Tier B approval reference (approvals-log date/line): …
- Final decision: ☐ GO (all gates passed) ☐ NO-GO — gate that closed it: …
