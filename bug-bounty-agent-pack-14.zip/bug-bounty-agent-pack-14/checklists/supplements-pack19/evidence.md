# Checklist: Evidence Quality

- [ ] UTC timestamps and account labels on every artefact
- [ ] Full request/response pairs (redacted) for the key steps
- [ ] Reproduction works from a clean session using only the written steps
- [ ] Proven / indicated / speculative labels are accurate
- [ ] Screenshots/recordings support, but do not replace, request/response evidence
- [ ] Secrets and third-party data redacted before anything leaves the hunt folder
