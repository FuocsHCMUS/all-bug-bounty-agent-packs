# Checklist: Posture Analysis Completeness

- [ ] Strengths are observation-based, not generic praise
- [ ] The enabling gap is named precisely (missing check / wrong assumption)
- [ ] Systemic-vs-isolated judgement backed by sibling tests
- [ ] Risk register has likelihood, impact, population, data at risk
- [ ] Detection section: logs, anomalous sequence, SIEM idea in words, false positives
- [ ] Recommendations: fix, retrospective hunt, one defence-in-depth item
