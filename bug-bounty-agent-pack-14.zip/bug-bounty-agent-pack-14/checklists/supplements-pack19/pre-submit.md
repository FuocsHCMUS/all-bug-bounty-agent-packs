# Checklist: Pre-Submit (Joshua's pack review)

- [ ] Finding report complete: summary, preconditions, steps, impact, root cause, remediation
- [ ] CVSS vector present with assumptions stated; no unproven chain credit
- [ ] Duplicate check attached and current
- [ ] Posture analysis attached (strengths, gaps, risk, SOC detection)
- [ ] Learning note attached (first-principles ladder + self-checks)
- [ ] One-paragraph paste-ready summary for Joshua at the top
- [ ] Nothing has been sent to the company by the agent — confirmed
