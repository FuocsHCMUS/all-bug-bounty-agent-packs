# Checklist: Recon Quality

- [ ] Passive sources exhausted before active probing
- [ ] Every host classified in-scope / out / unknown with evidence
- [ ] Fingerprints recorded with confidence levels
- [ ] JS/mobile artefacts mined for routes and versions
- [ ] Inventory saved by scripts/inventory.py and reviewed by a human (you)
