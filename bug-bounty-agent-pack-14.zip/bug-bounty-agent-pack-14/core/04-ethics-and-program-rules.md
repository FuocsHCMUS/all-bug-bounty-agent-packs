# Core 04 — Ethics, Law & Program Rules Cheat-Sheet

## Why this matters (teach it, don't just cite it)
Authorisation is the entire legal difference between research and computer
crime (e.g. US CFAA, UK Computer Misuse Act, EU equivalents, Vietnam's
Cybersecurity Law for local context). A bug bounty program is a conditional
permission slip: its scope and rules *are* the permission. Outside them,
you are unauthorised — full stop.

## Reading a program page like a lawyer (Phase 0 checklist)
- Safe harbor: present? conditional on what behaviours?
- Scope table: domains/apps/APIs; wildcard semantics; excluded subdomains;
  third-party-hosted assets; newly acquired companies (usually excluded).
- Prohibited: commonly DoS, automated scanning (some programs!), social
  engineering, physical, accessing others' data, public disclosure before fix.
- Testing rules: required headers/email aliases, test accounts, rate limits,
  time windows, data-retention/deletion duties after testing.
- Rewards & severity: how they score (CVSS? internal), duplicate policy,
  first-to-report, known-issue lists — check before investing hours.
- Disclosure policy: coordinated timeline, "do not disclose" clauses.

## Platform differences (verify on the day — policies change)
- **HackerOne:** program brief + scope tab are authoritative; use
  `X-HackerOne-Research: <username>` if requested; reports are private by default.
- **Bugcrowd:** brief + "target groups", VRT for severity expectations.
- **Intigriti / YesWeHack:** strict scope tiers; check "out of scope" text carefully.
- **Self-hosted / VDP:** often no bounty and narrower safe harbor — read twice.

## Grey-area protocol
Found something just outside scope that looks serious (e.g. a leaking bucket
named like the company)? Stop. Do not dig. Report *the pointer* through the
program ("I noticed X while in scope; I did not access it — is it yours/in
scope?") and let them extend authorisation in writing if they want it tested.

## Data you touch
Minimum proof, then stop. Delete test data you created when the program asks.
Never keep real personal data after the session; note its deletion in the log.
