# Core 08 — Autonomous Agent Operations & Memory

Long hunts break agents in predictable ways: context fills up, notes drift,
yesterday's "fact" turns out to be a guess, and a half-finished test gets
repeated — or worse, reported as finished. This file is the operating system
for staying trustworthy across hours, days, and restarts.

Read it together with: `core/02-approval-protocol.md` (what you may do),
`core/03-workflow-and-evidence.md` (how tests are logged), and
`checklists/ai-agent-preflight.md` (before every autonomous session).

---

## 1. First principles: why agents need external memory

### 1.1 Your context window is not memory

Think of the context window as a desk, not a filing cabinet. Everything on
the desk is visible right now; everything else might as well not exist.
When the desk fills up, older papers fall off — silently. You will not
notice the moment a scope detail, a negative result, or an approval
condition falls off the desk.

**Rule:** If it matters after this session, it must live in a file.
Files are the memory. Conversation is only the cache.

### 1.2 Three kinds of things you "know" — never mix them

| Kind | Example | Where it may live |
|---|---|---|
| **Observed** | "EXP-041: account B got `403` on `/api/invoices/8812`" | Experiment log + evidence |
| **Inferred** | "Authorisation is probably enforced in middleware" | Notes, labelled *Inferred* |
| **Guessed / recalled** | "This framework usually has an admin debug route" | Hypothesis backlog only |

Most agent failures in bug bounty are category errors: a guess gets written
down without its label, gets re-read later as an observation, and ends up
in a report. Labelling is not bureaucracy. It is the whole defence.

### 1.3 The operator is the authority, files are the record

Joshua (the operator) decides scope, approvals, and submission. Files record
what was decided. If a file and the operator disagree, the operator wins —
and you update the file in the same session, noting what changed and when.

---

## 2. Hunt state files: the minimum set

Every hunt folder keeps these files current. If one is missing, creating it
is your first task — before any testing.

| File | Purpose | Updated when |
|---|---|---|
| `scope-intake.md` | Signed-off scope, rules, rate limits, stop conditions | Scope changes, never silently |
| `hunt-state.md` | Where the hunt is *right now* (see §3) | End of every work block |
| `experiment-log.md` | One entry per test, including negatives | During testing, not after |
| `hypothesis-backlog.md` | Ranked hypotheses with status | Ideas arrive / get tested |
| `evidence-log.md` + `evidence/` | Proof files and their SHA-256 hashes | Same session as capture |
| `findings/` | One folder per candidate finding | On confirmation only |
| `session-notes.md` | Running narrative, decisions, dead ends | As you go |
| `approvals-log.md` | Tier B approvals: what, when, exact wording/scope | When approval is given |
| `research-log.md` | External claims and verification status (Template 14) | When research is used |

Do not invent parallel copies (`hunt-state-v2-final.md`). One canonical file
per purpose. Duplicated state is how contradictions are born.

---

## 3. The `hunt-state.md` file: your restart point

This is the single most important operational file. Any agent — including
you after a context reset — should be able to read it in two minutes and
continue safely.

```markdown
# Hunt State — <program / target>
Last updated: <YYYY-MM-DD HH:MM, timezone>

## Scope snapshot
In scope: <one line> | Out of scope highlights: <one line>
Rate limit / test window: <…> | Active approvals: <Tier B items, with dates>

## Current phase
<Recon / Mapping / Hypothesis / Testing / Validation / Reporting>

## Confirmed findings
- F-01 <title> — status: <drafted / operator-reviewed / submitted by operator>

## Candidate (unconfirmed) findings
- C-01 <title> — what proof is still missing: <…>

## Last 5 experiments
- EXP-### <one-line result> (full detail in experiment-log.md)

## Open hypotheses (top 5 only, ranked)
- H-### <hypothesis> — next test: <…>

## Blockers & questions for the operator
- <… or "none">

## Next action (single, concrete)
<The very next thing to do, small enough to start immediately>

## Do-not-repeat list
- <Tests already run and closed, with EXP numbers — see §6>
```

**Discipline:** update `hunt-state.md` at the end of every work block
(roughly every 30–60 minutes of work, and always before stopping).
A hunt whose state file is stale is a hunt that must pause and reconcile
before any new active testing.

---

## 4. Context compaction survival

Compaction (automatic summarisation when context fills) is lossy. Assume it
*will* happen mid-hunt and design for it.

### 4.1 Write for the agent who has forgotten everything

- State facts fully, once, in files — never rely on "as discussed earlier."
- Use stable IDs everywhere: `EXP-041`, `H-12`, `F-03`, file paths, hashes.
  IDs survive compaction; prose descriptions blur.
- Put the *why* next to the *what*: "Skipped GraphQL introspection re-test —
  already negative in EXP-038" survives better than "skipped, see notes."

### 4.2 The compaction checklist (run when you suspect a reset)

1. Re-read `scope-intake.md` and `hunt-state.md` before doing anything.
2. Re-read `approvals-log.md`. Approvals you cannot find written down
   **do not exist**. Ask again rather than assume.
3. Check the experiment log's last entry number; continue numbering from it.
4. Re-state, in your first message after resuming: scope, current phase,
   last confirmed result, and next action. If you cannot state them, you
   are not ready to test — you are ready to read.

### 4.3 Never store the only copy in chat

Chat transcripts are the worst place for: credentials or tokens, full
unredacted evidence, approval wording, and scope documents. Copy them into
the hunt folder (with the handling rules in Core 09) the moment they appear.

---

## 5. Sub-task decomposition: how to split a hunt

A hunt is too big to hold in one thought. Decompose it into sub-tasks that
each have: **one question, one method, one definition of done.**

### 5.1 Good vs bad sub-tasks

| Bad (vague, unbounded) | Good (testable, bounded) |
|---|---|
| "Test the API for IDOR" | "For endpoints in `api-map.md` §2, swap object IDs between accounts A/B; log each result as an EXP entry" |
| "Research this stack" | "List CVEs for `<product> <version>` from NVD/GHSA; fill a Template 07 sheet per candidate" |
| "Look for XSS" | "Test the 6 reflected parameters in EXP queue Q3 for context-appropriate encoding, one variable at a time" |

### 5.2 The work queue

Keep a simple ordered queue in `hunt-state.md` or the backlog:

```
[ ] Q-01 …   [>] Q-02 in progress   [x] Q-03 done (EXP-…)
[!] Q-04 blocked — needs operator approval for <specific thing>
```

Rules:

- One item in progress at a time per agent. Parallel threads are where
  evidence gets crossed between targets.
- If a sub-task grows a sub-task, write the child down; do not just chase it.
  Rabbit holes are logged, then ranked, then chosen — never drifted into.
- A sub-task is *done* when its result is in the experiment log, not when
  you "feel" you tested it.

### 5.3 Delegating to sub-agents (when the platform supports it)

- Give each sub-agent a self-contained brief: scope excerpt, the single
  question, allowed methods, approval tier, output format, stop conditions.
- Sub-agents never inherit approvals by implication. State them explicitly.
- Fold sub-agent output back yourself: check its evidence, re-label guesses,
  merge into the canonical logs. Unreviewed sub-agent output is a *claim*,
  not a result (see §8).

---

## 6. Experiment log discipline (operational rules)

Core 03 defines the entry format. These are the behavioural rules:

1. **Log before you conclude.** Write the EXP entry while the response is
   in front of you, not from memory at session end.
2. **One variable at a time.** If you changed two things, you ran a muddle,
   not an experiment. Split it or mark it *Inconclusive — confounded*.
3. **Negatives are entries too.** "No result" without an entry will be
   re-tested later, wasting the target's patience and your time — and on a
   rate-limited program, wasting budget is a real cost.
4. **Maintain the do-not-repeat list.** Closed tests, with EXP numbers and
   the condition that would justify re-testing (new version, new role,
   new endpoint behaviour). Re-test only when that condition is met, and
   say so in the new entry.
5. **Numbers never get reused.** A deleted entry keeps its number as a
   tombstone: "EXP-052 — void, duplicate of EXP-049."

---

## 7. Stop, research, or test? Decision rules

The expensive failure modes are testing when you should be reading, and
reading forever to avoid testing. Use these triggers.

### Stop testing and research when:

- You cannot explain, in plain words, what the feature *should* do.
  (You cannot spot a broken rule you never understood.)
- Two consecutive experiments are *Inconclusive* for the same reason.
- A result surprises you and contradicts your mental model of the stack.
- You are about to use a technique you have only seen in a summary —
  go read the primary writeup/research first (see Template 14).
- The behaviour touches a class with shared-infrastructure risk
  (cache, smuggling, races on shared resources) — read
  `checklists/smuggling-and-cache-safety.md` before proceeding.

### Stop researching and test when:

- You have a falsifiable hypothesis: a predicted difference between a
  baseline request and one changed request.
- Research starts repeating itself (third source saying the same thing).
- The remaining unknown can only be answered by the target's behaviour,
  and the test is in scope, approved, and low-risk.

### Stop everything and ask the operator when:

- Scope is ambiguous for the asset or technique in front of you.
- A test could affect real users, shared caches, or other tenants.
- You found data that looks like a real user's, beyond minimal proof.
- You found a possible critical (e.g. unauthenticated RCE, mass data
  exposure). Pause, preserve minimal evidence, escalate — do not "explore
  a bit more to be sure." See Core 04 and Core 09.
- Approvals are unclear, expired, or were given for a different target.

### Time-boxing

Set a soft box per hypothesis (e.g. "90 minutes or 25 requests, then
review"). When the box ends: record what was learned, re-rank the backlog,
and *choose* the next step out loud. Sunk cost is not evidence a bug is near.

---

## 8. Avoiding hallucinated findings (self-QA)

Language models produce fluent, confident, wrong text. In bug bounty that
failure has a name — an invalid report — and it costs the operator real
reputation with programs. Treat your own output as untrusted until checked.

### 8.1 The five classic hallucinations

1. **Invented endpoint/parameter:** "the API also exposes `/admin/export`"
   — did a response actually show that, or did the pattern feel likely?
2. **Invented version:** fingerprint banner misread or "remembered."
   Versions come from observed output, quoted, or they are *Inferred*.
3. **Invented CVE match:** a CVE "for this product" whose affected-version
   range was never checked against the observed version (Template 07 exists
   precisely to force this check).
4. **Upgraded result:** a `500` error becomes "likely SQL injection";
   a reflected string becomes "stored XSS." The label must match the proof.
5. **Borrowed evidence:** detail from a writeup of a *different* target
   quietly merged into this target's notes.

### 8.2 The confirmation ladder — findings climb it, never skip it

```
Level 0  Idea            (backlog only)
Level 1  Signal          (anomalous response — EXP entry, marked Signal)
Level 2  Reproduced      (same result, fresh run, baseline contrast shown)
Level 3  Impact shown    (minimal, safe proof of the claimed impact)
Level 4  Report-ready    (independent re-check passed, §8.3)
```

Only Level 3+ may be called a *finding*. Levels 0–2 are *candidates*, and
must be named that way to the operator. Never let a summary, filename, or
heading promote a candidate silently ("xss-finding.md" for a Level 1 signal
is a small lie that compounds).

### 8.3 Self-QA before anything is called confirmed

- [ ] Can I point to the exact EXP entry and evidence file (with hash)?
- [ ] Is there a baseline? (What does correct behaviour look like, observed?)
- [ ] Did I reproduce it at least twice, ideally from a clean state?
- [ ] Have I stated the *weakest* honest label for this result — and used it?
- [ ] What else could explain this response? Have I ruled the top alternative
      out, or written it down as an open caveat?
- [ ] Are all versions, CVEs, and quotes traceable to a source I actually
      opened (Template 14), not to memory?
- [ ] Would this still be true if I deleted my narrative and kept only the
      raw request/response? If not, the narrative is doing the proving — stop.

### 8.4 Language hygiene

Banned without evidence: "clearly vulnerable", "trivially exploitable",
"full compromise", "all users affected". Required instead: counts you
actually observed ("3 of 3 test objects"), conditions you actually needed,
and explicit unknowns. Precision is the senior skill here.

---

## 9. Memory hygiene across days

- **Daily close-out (10 minutes):** update `hunt-state.md`, file stray notes
  into the canonical logs, hash any unhashed evidence, list tomorrow's
  single next action.
- **Weekly:** run the weekly review (Template 15). Archive dead hypotheses
  to a `closed/` section with the reason — do not delete them; a future
  version bump may revive one, and the *reason* is the valuable part.
- **Contradiction protocol:** when two files disagree, stop and reconcile
  against raw evidence (the lowest-level record wins: raw response >
  experiment log > summary > chat). Fix the losing file and note the fix.
- **Secrets never enter long-term notes.** If a token or password lands in
  a log by accident, follow Core 09 §7 (contain, redact, tell the operator).

---

## 10. Worked rhythm of a good autonomous session

1. Preflight checklist → scope and approvals re-stated out loud.
2. Read `hunt-state.md`; pick the queue's top item; state its question.
3. Work in blocks; EXP entries as you go; state file updated per block.
4. Research detours logged in Template 14 *before* their claims are used.
5. Candidates climb the confirmation ladder; nothing skips levels.
6. Close-out: state file, evidence hashes, summary block to the operator —
   findings / posture / learning / open hypotheses / best next step.

An agent that follows this file is slower in the first hour and dramatically
faster — and safer — by the third day. That trade is the point.
