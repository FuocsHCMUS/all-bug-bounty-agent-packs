# Core 09 — Data Handling, OPSEC & Evidence Hygiene

Bug bounty puts other people's data within your reach — on purpose, inside
a scope, under rules. How you handle what you touch is the difference
between a trusted researcher and a liability. This file is the handling
standard for every agent using this pack.

It applies alongside: Core 04 (ethics & program rules), Core 03 (evidence
format), and Template 13 (evidence manifest). Where a program's own rules
are stricter than this file, the program wins. Where this file is stricter,
this file wins.

---

## 1. First principles

### 1.1 Data minimisation is the master rule

**Access the least data, for the shortest time, that proves the point.**

A broken access control is proven by opening *your own second test
account's* object, or — if the program allows it and no test object exists —
by reading the smallest possible fragment of one object and stopping.
It is never proven by downloading a database, listing every user, or
"checking how widespread it is" across hundreds of records. Breadth is the
target's incident-response problem, not your evidence.

Ask, before every access: *"If this exact action appeared in the company's
logs tomorrow, would it read as careful research?"* If not, shrink it.

### 1.2 The three data classes in a hunt

| Class | Examples | Handling |
|---|---|---|
| **Yours** | Test-account data you created, your own requests | Normal notes OK |
| **Proof fragments** | One foreign object ID + minimal field proving access | Originals only, redacted copies for sharing (§4–§5) |
| **Never collect** | Bulk user data, password hashes of real users, payment data, private messages, health data | Do not access, download, or retain. If encountered: stop, §8 |

### 1.3 OPSEC, honestly defined

For a legitimate, authorised hunter, OPSEC is not about hiding from the
target — programs *want* attributable research traffic (research headers,
declared accounts, stable IPs where required). Your OPSEC duties are:

- **Protect credentials and evidence** from third parties (§2, §6).
- **Keep test traffic attributable to you** where the program asks for it,
  so defenders don't waste an incident on your work — and so your work is
  distinguishable from a real attacker's.
- **Protect the operator's accounts**: no credential reuse, no testing from
  personal accounts the program didn't authorise, no storing program
  credentials in chat, notes, scripts, or screenshots.

Hiding your identity *from the program* to evade its rules (ban evasion,
multi-accounting against policy, masking prohibited automation) is a rules
violation, not OPSEC. Never do it.

---

## 2. Credentials, tokens, and secrets

### 2.1 Your own test credentials

- Test accounts only, created for the program, with unique passwords.
- Passwords/tokens live in the operator's password manager — never in hunt
  files, scripts, screenshots, shell history notes, or chat.
- In notes, refer to accounts by label ("Account A / B") and, where needed,
  a non-secret identifier (test username). Never paste a live token to
  "show your work" — the request line with the header redacted (§4) plus
  the response is the work.
- Scripts read credentials from environment variables or a local,
  git-ignored config the operator created — never hardcoded. If you write
  a script that needs a token, write the `os.environ[...]` version and tell
  the operator what variable to set.

### 2.2 Secrets you *find* (the target's or users')

Leaked API keys, tokens in JS bundles, credentials in responses, signed
URLs, `.env` content exposed by a bug — handle as follows:

1. **Minimise capture.** Record: type of secret, where it was exposed
   (endpoint/file), and enough to prove it is real — conventionally the
   first/last few characters only in notes (e.g. `AKIA…7F3K`). The full
   value, if capture is unavoidable for proof, goes only into
   `evidence/originals/` (§5).
2. **Do not use found credentials** to log in, call paid APIs, or expand
   access — unless the program's scope *explicitly* covers that step and
   the operator has approved it (Tier B). Proving exposure is the finding;
   using the key is a new action with new risk.
3. **Do not validate third-party keys against the third party** (e.g. don't
   test a leaked cloud key against the cloud provider) without explicit
   operator approval — that traffic is outside the program's authority.
4. **Report promptly and recommend rotation.** A found secret stays valid
   until rotated; your report should say so plainly, and your notes should
   remind the operator until the program confirms rotation/closure.
5. **Never** paste a found secret into external tools, AI services, public
   scanners, URL shorteners, or "hash checker" sites. Any of those is a
   disclosure.

### 2.3 Session material in evidence

Cookies, JWTs, and session IDs in captured requests are credentials while
valid. The redaction rules in §4 apply to your *own* sessions too —
shareable evidence never carries a live session token.

---

## 3. Test data discipline

- Create test data that is **obviously test data**: names like
  `bb-test-a-2026`, unique marker strings the program can find and purge,
  and the research header/identifier where the program provides one.
- Markers help defenders separate your artefacts from real attacks and make
  cleanup possible. Use one consistent marker per hunt; log it in the
  scope intake.
- Never use real people's names, emails, phone numbers, or photos as test
  data. Never use data scraped from elsewhere as "realistic" filler.
- Upload tests: use harmless, self-created files. A file that proves an
  upload flaw must not itself be malware, a real webshell with offensive
  capability beyond the program's rules, or third-party copyrighted content.
  Follow the program's proof-of-concept limits exactly.
- Clean up after yourself where the program expects it (delete test
  objects, close test orders) — and log what you deleted and what,
  deliberately, you left for the program to inspect, with IDs.

---

## 4. Redaction standard

Every piece of evidence exists in two forms (Core 03): the **original**
(local only) and the **shareable** (redacted). Redaction is done on a copy,
never on the original.

### 4.1 Always redact in shareable copies

- Passwords, tokens, API keys, session cookies, `Authorization` headers
- Real users' names, emails, phone numbers, addresses, IDs of any kind
- Payment/financial details, precise geolocation, IP addresses of real
  users (your own test IPs: follow program preference; default redact)
- Internal hostnames/IPs *not* needed to understand the bug — if the
  internal name *is* the bug (e.g. SSRF reached it), keep the minimum that
  proves it and flag it to the operator before sharing

### 4.2 Redact consistently, or don't bother

Redacting a name in the screenshot but leaving it in the URL, the JSON
response, and the filename is not redaction — it is decoration.
Checklist per shareable file:

- [ ] Body/content checked
- [ ] Headers checked
- [ ] URL and query string checked
- [ ] Filename and folder path checked
- [ ] Metadata checked (image EXIF, document author fields, PDF properties)
- [ ] The same value searched across the *whole* report package

Use opaque replacements that preserve meaning: `[REDACTED-EMAIL]`,
`user-id …4821 (test account B)`. Keep a private redaction map only if
reproducibility needs it — stored with the originals, never shared.

### 4.3 Redaction is not anonymisation theatre

If a "redacted" record is still identifiable from context (unique job title
+ small company + timestamp), it is identifiable. Say so to the operator
and minimise further rather than pretending the black bar solved it.

---

## 5. Evidence integrity: hashing and storage

Evidence that can't be shown to be untampered is weak evidence — in a
dispute about what happened and when, hashes and timestamps are your
credibility.

### 5.1 At capture time, for every evidence file

1. Save to `evidence/originals/` with a structured name:
   `EXP-041_2026-11-03T14-22-05+07-00_idor-b-on-a.http` (experiment ID,
   timestamp with timezone, short slug).
2. Record in the manifest (Template 13): filename, SHA-256 hash, size,
   capture tool + version, capturing account, related EXP/finding ID.
3. Never edit an original after hashing. Need an annotated version?
   Make a copy, name it `…_ANNOTATED`, hash and log it separately.

On Windows/PowerShell: `Get-FileHash -Algorithm SHA256 <file>`.
On any OS with Python: `python -c "import hashlib,sys;print(hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest())" <file>`.

### 5.2 Storage rules

- Originals stay on the operator's machine, in the hunt workspace. No
  public links, no third-party file hosts, no pasting into chats or tickets
  outside the program's own reporting channel — without Tier B approval
  naming the destination.
- Do not commit evidence (either copy) to a public git repository. If the
  workspace is a repo, `evidence/` is git-ignored by default; check before
  any push, every time.
- Backups: encrypted, operator-controlled storage only. If the operator
  has no backup setup, say so once — evidence loss is a risk to record,
  not a problem to solve by uploading it somewhere convenient.
- Screenshots/video follow the same rules as text evidence. A screenshot
  is a data leak with pixels if it shows another user's data, your own
  tokens, browser tabs, notifications, or desktop content — crop and review
  before saving, not after sharing.

### 5.3 Screenshots: capture discipline

- Capture the smallest region that proves the point; full-screen by
  exception, with a reason.
- Pause and clear notifications; close unrelated tabs/windows first.
- Prefer the target's own UI showing test-account data over any view that
  includes real-user data.
- For multi-step bugs, a short screen recording beats ten screenshots —
  one file, one hash, one manifest entry, clearer story.

---

## 6. Safe sharing with the operator (and only the operator)

The agent reports findings **to Joshua only**. Joshua submits reports to
companies himself. The agent never submits, emails, or messages a program
directly (see AGENTS.md and Core 04).

When handing material to the operator:

- Default package: the draft report (shareable evidence only), the posture
  notes, and the manifest. Originals are *referenced* by hash, not attached,
  unless the operator asks for a specific file.
- Flag explicitly: "This package contains proof fragments from a foreign
  test object" / "This draft references a found secret (type + last 4 only)".
  Surprises about sensitivity are how accidents happen.
- If a file is too sensitive for the current channel, say so and stop —
  name the file and its class, don't send it "just this once."
- After the operator submits: record the submission (platform, date,
  report ID *as given by the operator*) in the disclosure log
  (Template 11). Do not chase the program yourself for status.

---

## 7. Retention and cleanup

Evidence is a liability with a shelf life. Keep it deliberately.

| Moment | Action |
|---|---|
| During hunt | Originals + shareables, hashed, in hunt folder only |
| Report submitted by operator | Keep originals until the program closes the report |
| Report closed / program confirms fix + secret rotation | Ask operator: archive (encrypted, offline) or delete originals? Default recommendation: delete proof fragments of foreign data; keep the redacted report, logs, and hashes |
| Hunt abandoned | Same decision, at the weekly review — never let folders rot unreviewed |
| Accidental secret/PII in a log/chat | §8.3 — contain immediately, don't wait for a review |

Deletion means deletion: remove the file, empty the obvious copies
(downloads folder, temp exports, editor backups), and note the deletion
(date, what class of data, by whose decision) in the hunt log. The hash
may stay — a hash of a deleted file proves what existed without keeping it.

Never keep "souvenir" data: no trophy screenshots of other users' data,
no keeping found credentials "for the portfolio." Portfolio material is
always the redacted, test-account version (see Learning 09).

---

## 8. Incident playbook: when handling goes wrong

### 8.1 You accessed more real-user data than intended

Stop the test. Do not page further "to understand the extent." Note:
endpoint, time, approximate count *observed on screen* (don't go count it
properly), and what you did with it (nothing / saved — say which). Tell the
operator the same session. Whether and how to disclose to the program is
the operator's call, made promptly — most programs reward fast honesty
about accidental over-access and punish silent breadth.

### 8.2 You suspect the target is actually compromised by someone else

Real webshells, other attackers' artefacts, data that looks like an active
breach: stop testing that area, preserve minimal proof (screenshot + hash),
escalate to the operator immediately. This is no longer a bug hunt; do not
investigate the third party, and never interact with their artefacts.

### 8.3 A secret or PII leaked into the wrong place

(e.g. pasted into a shared note, an external tool, or an unredacted file
that was shared.)

1. Note exactly what, where, and when — facts, not minimising language.
2. Remove/replace the copy you control; rotate any credential of *yours*
   that was exposed; if it's the *target's* secret, the operator should
   notify the program promptly so they can rotate.
3. Tell the operator in the same session, in plain words.
4. Write the cause into the hunt log so the process, not just the file,
   gets fixed.

### 8.4 Your own machine/tooling is the risk

Suspicious tool download, a repo that behaved oddly, a script you ran
without reading: stop, disconnect the tool from credentials, tell the
operator what ran and when. Tools are Tier-gated (Core 02) precisely so
this stays rare — and reading before running is your job, not a courtesy.

---

## 9. One-page summary (tape this to every hunt)

1. Least data, shortest time, that proves the point.
2. Test data is obviously test data; real people are never test data.
3. Secrets: type + last 4 in notes; full value, if unavoidable, in
   originals only; never use, never paste elsewhere; recommend rotation.
4. Two copies: originals (local, hashed, unedited) and shareables
   (redacted everywhere — body, headers, URL, filename, metadata).
5. Hash at capture (SHA-256), log in Template 13, same session.
6. Report to the operator only. The operator submits.
7. Keep evidence until closure, then delete or archive by decision —
   and write the decision down.
8. Accidents: stop, note facts, tell the operator the same session.
