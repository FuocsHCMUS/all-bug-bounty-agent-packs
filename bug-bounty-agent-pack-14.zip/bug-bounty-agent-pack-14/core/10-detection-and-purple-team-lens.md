# Core 10 — Detection & Purple-Team Lens

Every finding in this pack is written twice: once as an attack (how it
breaks) and once as a detection problem (how a defender could have seen
it). This file defines the second writing. It deepens `learning/05-soc-lens.md`
from "awareness" into a working method.

Why it matters for the operator: Joshua studies SOC alongside pentest.
A hunter who can say *"here is the bug, and here is the log line that
should have caught me"* is doing purple-team work — the combined
red + blue practice companies increasingly hire for.

---

## 1. First principles: what "detection" actually means

### 1.1 An attack is a sequence of observable events

No attack is invisible magic. Each step touches a system, and touched
systems *can* record something:

```
Attacker action → system processes it → (maybe) a log/telemetry record
                                        → (maybe) an alert fires
                                        → (maybe) a human responds
```

Detection fails at any arrow: nothing logged, logged but not collected,
collected but no rule, rule fires but nobody looks. When you write the
detection section of a posture analysis, name *which arrow* you have
evidence about — and label the rest as inference (see §7).

Key vocabulary, from zero:

- **Telemetry** — the raw records a system emits: logs, metrics, traces,
  network flows, cloud audit events.
- **Log** — a timestamped record of one event ("user X did Y, result Z").
- **SIEM** — the system that collects logs centrally and runs alert rules
  over them (Security Information and Event Management).
- **Alert / detection rule** — a query + threshold that turns matching
  logs into something a human reviews.
- **False positive / false negative** — an alert on benign activity /
  a real attack that produced no alert. Every rule trades these off.
- **TTPs** — tactics, techniques, procedures: *how* an attacker operates,
  as opposed to *indicators* (a specific IP/hash) which change trivially.

### 1.2 You can only reason about telemetry you understand

For each test you run, before you run it, answer in one line:
*"If the target logged perfectly, where would this action appear?"*
If you cannot answer, that gap is itself a learning task (Learning 03/04/08)
— and your detection notes for that test must be labelled *Guessed*.

---

## 2. The telemetry map: where attacks leave traces

| Layer | Typical records | Bug classes most visible here |
|---|---|---|
| CDN / edge | Request logs, cache hits/misses, edge rules fired | Cache poisoning/deception, smuggling (partially), scanning |
| WAF | Rule matches, blocked/allowed verdicts, payloads (sometimes sampled) | Injection attempts, XSS payloads, CVE exploit strings |
| Load balancer / reverse proxy | Status codes, backend chosen, timing | Smuggling (front/back disagreement), SSRF egress (if proxy logs it) |
| Web / app server | Access log (method, path, status, user agent, authenticated user), error log | IDOR/BOLA, auth bypass, business-logic abuse, error-based signals |
| Application audit log | Business events: "invoice viewed", "role changed", "export run" | Privilege escalation, mass assignment, workflow abuse — *if the app bothers to log semantics, not just HTTP* |
| Auth system / IdP | Login success/failure, MFA events, token issuance, password resets | Credential stuffing, token abuse, reset-flow flaws, session issues |
| Database | Query logs (rarely full), slow-query log, audit of sensitive tables | SQLi (via its effects), data exfiltration volume |
| Cloud control plane | API audit trail (e.g. who created a key, changed a bucket policy) | SSRF → metadata → credential use, cloud misconfiguration exploitation |
| Egress / network | Proxy logs, DNS queries, flow logs | SSRF, data exfiltration, C2-style callbacks from your test payloads |
| Endpoint (EDR) | Process/file/registry events on servers & workstations | RCE follow-on actions, dropped files — mostly beyond web bug bounty, know it exists |
| Client side | CSP reports, browser telemetry (rare) | XSS/DOM bugs — usually the blindest layer (see §6) |

**Exercise the pack expects:** for each playbook you use, keep a personal
copy of this table annotated with what *this target* visibly did (blocked?
challenged? silent?) — observed reactions only.

---

## 3. MITRE ATT&CK, from zero — and its limits here

### 3.1 What it is

MITRE ATT&CK is a public knowledge base that organises attacker behaviour
into **tactics** (the *why*: e.g. Initial Access, Persistence, Exfiltration)
and **techniques** (the *how*: e.g. *Exploit Public-Facing Application*,
*Valid Accounts*, *Steal Web Session Cookie*), each with a stable ID
(e.g. `T1190`, `T1078`, `T1539` — verify the current ID/name on the ATT&CK
site when you use one; editions change).

Think of it as a shared vocabulary: instead of every analyst inventing
words for "they logged in with stolen creds," everyone says *Valid
Accounts* and means the same thing.

### 3.2 How to use it in this pack (and how not to)

**Do:**

- Map the *finding's exploitation path* to 1–3 techniques, in the posture
  analysis, e.g.: "Initial Access via *Exploit Public-Facing Application*
  (the vulnerable upload endpoint), then *Valid Accounts* using the
  hijacked session." One or two honest mappings beat a wall of IDs.
- Use the mapping to ask the detection question: "For technique X, what
  telemetry does ATT&CK's own page list as data sources?" — a grounded
  starting point for §4, not a guess.
- Map *your own testing behaviour* too: recon looks like recon to a SOC
  whether a researcher or a criminal does it. That is why declared test
  accounts, research headers, and scope discipline (Core 04/09) matter.

**Do not:**

- Spray technique IDs to look senior. An unmapped finding with a precise
  log-based detection idea is worth more than five decorative IDs.
- Force web bugs into ill-fitting techniques. Some bug classes (e.g. a
  pure business-logic discount flaw) have no clean ATT&CK home; say
  "no direct ATT&CK technique — closest is …" and move on.
- Treat ATT&CK as a severity or completeness score. It is a dictionary,
  not a grade.

### 3.3 Neighbouring frameworks, one line each

- **MITRE D3FEND** — the defensive counterpart: countermeasures organised
  against ATT&CK techniques. Useful when writing "how to fix/detect."
- **OWASP ASVS / Top 10** — what the *application* should do; ATT&CK is
  what the *attacker* does. Posture analysis cites both, for different jobs.
- **Cyber Kill Chain** — an older, simpler 7-stage attack sequence model.
  Fine as a storytelling scaffold; ATT&CK is the working vocabulary.

---

## 4. Writing a detection idea (the pack's standard format)

For every confirmed finding (and major candidate), the posture analysis
includes at least one detection idea in this shape:

```markdown
### Detection idea — <finding ID / title>
- Attack step it catches: <the specific, observable step — not "the hack">
- Telemetry needed: <log source + the exact fields that must exist>
- Rule logic (plain language): <e.g. "same authenticated user requests
  ≥20 distinct invoice IDs in 5 min AND ≥30% return 403/404">
- Baseline question: <what normal behaviour looks like, and how a
  defender would learn it — the hardest part, say so if unknown>
- Expected false positives: <who triggers this innocently, and how
  an analyst would triage them>
- What it misses: <the slower/quieter variant that evades this rule>
- ATT&CK mapping (optional): <tactic / technique, verified name+ID>
- Confidence: Observed / Inferred / Guessed — and what evidence would
  raise it
```

Rules of honesty for this section:

1. **You cannot know their SIEM.** You did not see their rules, their log
   retention, or their staffing. Never write "the company has no
   detection." Write: "during testing, no visible response (block,
   challenge, lockout) was observed" — an *observation* — and label any
   claim about internal tooling as *Inferred/Guessed*.
2. **A rule nobody can tune is a homework assignment, not a detection.**
   If your logic would fire 500 times a day on normal users, say so and
   propose the tuning (allow-list, threshold from baseline, correlation
   with a second signal).
3. **Name the missing field.** Half of real detection engineering is
   discovering the log doesn't record the object ID / actor / tenant.
   "This detection is impossible until the app logs `object_owner_id`
   alongside `requesting_user_id`" is a senior-level, valuable sentence.

---

## 5. Sigma-style thinking (conceptual — no tooling required)

**Sigma** is an open, vendor-neutral format for writing detection rules
as structured text (YAML): *here is the log source, here are the field
conditions that match, here is the level*. Defenders convert one Sigma
rule into whatever SIEM query language they actually run. You do not need
to produce production Sigma in this pack — you need to *think* in its
shape, because the shape forces precision:

```yaml
# ILLUSTRATIVE SKETCH ONLY — structure, not a deployable rule
title: One User Enumerating Many Foreign Object IDs
logsource: { product: webserver / application access log }
detection:
  selection:
    http_status: [403, 404]
  condition: selection | count(object_id) by user > 20 within 5m
level: medium
falsepositives: [support staff tooling, broken client retry loops]
```

What the shape teaches a beginner:

- **Selection** = "what one event looks like" (fields, values).
- **Condition + aggregation** = "what *pattern* of events is suspicious"
  (count, distinct count, timeframe, grouping field). Most interesting
  detections live in the aggregation, not the single event — one `403`
  is nothing; forty distinct IDs in five minutes is a story.
- **False positives are part of the rule**, written down at birth, not
  discovered in production at 3 a.m.

If you later study SOC seriously, writing real Sigma for your own test
lab (Learning 06) is one of the highest-value exercises in this pack:
replay your own attack traffic, write the rule, watch it fire.

---

## 6. Blind spots: say them out loud

A posture analysis that only lists detections is marketing. Include the
gaps — they are often the most useful part for the company *and* for
your learning.

Recurring blind spots in web bug bounty:

- **Client-side bugs (DOM XSS, postMessage abuse):** the malicious action
  happens in a victim's browser. Server logs may show nothing unusual at
  all. Levers: Content-Security-Policy with reporting, careful telemetry
  the app deliberately ships, user reports. Detection confidence here is
  honestly *low* — write that.
- **Business-logic abuse that uses only valid requests:** each request is
  legitimate; only the *sequence/rate/combination* is abusive. Needs
  application audit logs with business semantics — which many apps don't
  emit. Your detection idea must start with "first, log X."
- **Low-and-slow anything:** thresholds are tuned for noisy attackers.
  A patient attacker under every threshold is a known, named limitation —
  mitigations are correlation over long windows and anomaly baselining,
  both expensive. Don't pretend a threshold rule solves it.
- **Encrypted/encoded payloads and WAF sampling:** if the WAF only samples
  or the app logs truncate bodies, the payload that mattered may simply
  not be recorded anywhere.
- **Third-party / SaaS layers:** telemetry may live with a vendor the
  company can't query in real time. Note the boundary when a finding
  crosses one.

---

## 7. Feeding posture analysis (the loop, end to end)

Per finding, in Template 05 / the report's SOC section:

1. **Attack path in 3–5 steps**, each step one observable action.
2. **Per step:** which layer (§2) should record it, which fields.
3. **Observed reactions:** blocks, challenges, lockouts, rate-limit
   responses, support emails — facts only, with EXP numbers.
4. **One detection idea** in the §4 format, per major finding.
5. **ATT&CK mapping:** 1–3 techniques, verified, or "no clean mapping."
6. **Blind spot statement:** what would *not* have been seen, honestly.
7. **Fix vs detect balance:** prevention (fix the bug class) always
   outranks detection; detection is the safety net for the next variant.
   Say which is which in your recommendations — a company that only
   detects a bug class it could have prevented has the priority backwards,
   and a hunter who only recommends detection has missed the point too.

Labelling discipline (applies to this whole file's output):
**Observed** = you saw the log/reaction or the target showed it to you.
**Inferred** = reasoned from fingerprints, docs, or behaviour.
**Guessed** = plausible, unverified. All three are allowed. Lying about
which one you have is not.

---

## 8. Purple-team exercises for the operator (beginner-safe, lab only)

Do these in your own lab (Learning 06), never against a program target —
a target is for scoped testing, not for detection experiments.

1. **Replay yourself.** Run a deliberately vulnerable local app, perform
   one IDOR and one failed-login burst against it, then find both in the
   app's own logs. Write down the exact fields you used.
2. **Rule it.** Turn exercise 1 into a §4-format detection idea, then a
   Sigma-shaped sketch. Note every assumption about "normal" traffic.
3. **Break your own rule.** Repeat the attack slowly, with varied IDs and
   timing. Record what evaded the rule. This is the "What it misses"
   field — learned by doing, not by guessing.
4. **Map it.** Find the ATT&CK technique(s) for your attack on the official
   site; read the listed data sources; compare with the logs you actually
   had. Write the gap down in your learning notes (Template 06).

Four exercises, one loop: attack → observe → detect → evade → understand.
That loop *is* purple teaming, at every level of seniority.
