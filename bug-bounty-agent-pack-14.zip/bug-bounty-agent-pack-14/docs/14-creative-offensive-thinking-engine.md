# 14 — Creative Offensive Thinking Engine

New in the Pack 16 Consolidated Edition. This is the pack's answer to
"think like a real hacker / pentester / red teamer" — as a repeatable
method, not a mood. The rule of the whole engine:

> **Ideation is unlimited. Execution is disciplined.**
> Think of anything. Research anything. Build and test anything *locally
> or in a lab*. Send against a live target only what is inside that
> program's scope and rules, on your own accounts, at minimum impact.

Creativity that skips the second sentence produces bans, not bounties.
Creativity that skips the first produces scanner noise, not findings.

## The seven generators

Run a target through all seven. Each generator outputs *hypotheses*,
which go into the Hypothesis Ledger (`templates/16-hypothesis-ledger.md`).

### 1. Assumption inversion
List everything the application assumes, then break one assumption at a
time: IDs are unguessable · steps happen in order · the client is honest ·
prices/roles/flags from the client can be trusted · a webhook really came
from the provider · a file is what its extension says · "internal" headers
only come from inside · time only moves forward · one account = one human.
Most serious bugs are a single false assumption with a request attached.

### 2. Parser differentials
Two components parse the same input differently — that gap is a bug
waiting for a payload: CDN vs origin, WAF vs app, URL parsers, JSON vs
form encoding, duplicate parameters/headers, HTTP/1 vs HTTP/2
downgrading, Unicode/normalisation, multipart boundaries, XML parsers,
JWT libraries. Draw the parse chain for every interesting request
(browser → CDN → WAF → LB → app framework → ORM → DB) and ask at each
hop: *what does this layer think this bytes mean, and does the next
layer agree?* (Deep material: `learning/from-pack17/http2-and-parsers.md`,
`learning/from-pack17/caching-and-proxies.md`, playbook 17.)

### 3. Trust-boundary mapping
For every request: who trusts whom, and what crosses unchecked? Tenants,
roles, services, queues, workers, third-party integrations, mobile app vs
backend. A check that exists on one side of a boundary and is *assumed*
on the other is the classic access-control bug.

### 4. State-machine & time abuse
Draw the states, then try every illegal transition: skip a step, replay a
step, run two steps at once (race/TOCTOU), use an expired-but-accepted
token, go backwards, act in the wrong state, exploit timezones, ordering,
negative/zero/overflow amounts, currency and unit confusion. Endpoints
are nouns; bugs live in the verbs between states. (Playbooks 05,
`playbooks/per-class-pack17/race-condition.md`.)

### 5. Identity confusion
Tenant mixing, account linking, SSO/OAuth flow mixing, session fixation
and rotation gaps, role claims inside tokens, "login with X" merging the
wrong accounts, password-reset tokens that survive changes. Identity
bugs are sequence bugs — test whole flows, never single requests
(playbook 18, `playbooks/per-class-pack17/oauth-oidc.md`, `jwt.md`).

### 6. Primitives over bug names
Stop hunting named vulnerabilities; hunt *primitives*: "I can read an
object I shouldn't", "I can make the server fetch a URL", "I can store
content that renders in an admin's browser", "I can skip a payment
state". A primitive is a building block. Keep a primitive inventory per
target and a chain graph (`templates/10-chain-canvas.md`, playbook 20):
info leak → token → account action → money/trust impact. Chains are
where "lows" become criticals — and where creative hunters separate
from checklist hunters.

### 7. Second-order & feature interaction
Where does this input *go later*? Stored values rendered in another
context, exports, emails, PDFs, admin panels, mobile sync, webhooks,
search indexes, logs a human reads. And: what happens when feature A
meets feature B (sharing × export, coupons × refunds, invites × roles)?
Feature-interaction bugs are the least duplicated because scanners and
checklists cannot see them — only a human-style model of the product can.

## The invent-then-kill loop

For every generated hypothesis, in the Ledger:
1. **Invent** — state it as a falsifiable sentence: "If I do X to Y,
   then Z happens, which breaks invariant I."
2. **Prior-art check** — has this pattern been disclosed before?
   (`research/prior-art-and-novelty.md`, writeup mining.) Known pattern
   on a new surface is good; exact known bug on this target is a
   duplicate — check first, test second.
3. **Kill it on paper** — argue, as the developer, why it cannot work.
   The assumption your counter-argument relies on is usually the thing
   to test.
4. **Smallest live test** — one variable, own accounts, logged,
   minimum impact (AGENTS.md §6). 
5. **Verdict** — Confirmed / Ruled out / Blocked (why). Ruled-out
   hypotheses are kept: they are the map of what the company does well,
   and they feed the posture analysis.

## Timed creative sessions (use `prompts/04-creative-session.md`)
- 25 min: generators 1–3 on one feature, Ledger entries only, no testing.
- 25 min: generators 4–7, primitive inventory update, chain sketches.
- 10 min: rank by (impact × plausibility) ÷ cost, pick the top 3,
  write each one's smallest test and stop condition.
Novel techniques are *developed* here and in labs
(`learning/06-safe-lab-roadmap.md`) — a live target is where a developed
technique gets one careful proof, never where it gets debugged.

## What "sophisticated" actually means
Not a longer payload list. It means: a model of the system (threat
model, state machines, parse chains, trust boundaries) precise enough
that you can predict where the developers' model differs from reality —
and test exactly that difference, once, cleanly, with evidence a
triager can reproduce in minutes.
