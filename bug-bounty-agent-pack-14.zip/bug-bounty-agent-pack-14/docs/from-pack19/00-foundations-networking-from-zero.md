# Foundations: Networking From Zero

The ground every bug stands on. Read in order; each idea is needed by the next.

What a network is: two or more computers agreeing to exchange messages. A message needs an address (who), a route (how), and a language (protocol).

IP addresses and ports: an IP is like a building address; a port is an apartment number inside it. A service (web server, database) listens on a port. `203.0.113.10:443` means building .10, apartment 443.

DNS: the phone book that turns names (example.com) into IPs. Many bugs live here: forgotten subdomains are old apartments still occupied by test servers with weak locks.

Packets, TCP, UDP: TCP is a tracked courier (guaranteed, ordered, slower); UDP is postcards (fast, no guarantee). The web mostly uses TCP.

TLS/HTTPS: an encrypted, identity-checked tunnel over TCP. The padlock means the tunnel is private and the other end proved its name — it says nothing about whether the application logic inside is safe.

Clients, servers, proxies: your browser (client) asks; a server answers; proxies/caches/CDNs sit between and re-interpret requests — a major source of parser-differential bugs.

Self-check: (1) What two things do IP+port identify? (2) DNS failing breaks what, exactly? (3) Why can HTTPS still have IDOR? Answers: a specific service on a specific host; name resolution, not the servers themselves; TLS protects transport, not authorization logic.

---
Canonical rules: see root `AGENTS.md`. 1. **Authorized scope only.** Test only assets, accounts, and program rules explicitly in scope on HackerOne, Bugcrowd, a vendor VDP/BBP, or a written authorization the owner (Joshua) provides. If scope is ambiguous, stop and ask. Never test out-of-scope assets, third parties, other users' data, or production users.
