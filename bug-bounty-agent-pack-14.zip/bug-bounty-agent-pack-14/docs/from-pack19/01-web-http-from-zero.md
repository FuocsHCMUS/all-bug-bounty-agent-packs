# Foundations: The Web and HTTP From Zero

How a single click becomes requests, responses, sessions, and — sometimes — a vulnerability.

Anatomy of a request: method (GET/POST/PUT/DELETE), path, headers (metadata), cookies, body. Anatomy of a response: status code, headers, body. Learn to read both raw — tooling hides the very details bugs live in.

Statelessness and sessions: HTTP forgets you between requests, so apps hand you a session cookie/token. Whoever presents it is believed to be you. Session bugs = that belief failing (fixation, leakage, no expiry, no binding).

Cookies in depth: HttpOnly (not readable by JS), Secure (HTTPS only), SameSite (cross-site sending rules), scope (Domain/Path). A missing flag is a weakness; it becomes a vulnerability when chained with an attacker capability.

Same-origin policy & CORS: the browser's rulebook for which page may read which response. CORS is the server's permission slip that relaxes it — miswritten slips leak authenticated data cross-origin.

Rendering pipeline: HTML parsed, JS executed, DOM built. XSS is attacker JS running inside this pipeline with the victim's origin privileges.

APIs: the same HTTP, but machine-to-machine, usually JSON, authenticated by tokens/API keys. Most modern bug bounty value lives here, not in pretty pages.

Self-check: Why does stealing a session cookie equal stealing the account (until expiry/revocation)? Because the server identifies the presenter of the token, not the human.

---
Canonical rules: see root `AGENTS.md`. 1. **Authorized scope only.** Test only assets, accounts, and program rules explicitly in scope on HackerOne, Bugcrowd, a vendor VDP/BBP, or a written authorization the owner (Joshua) provides. If scope is ambiguous, stop and ask. Never test out-of-scope assets, third parties, other users' data, or production users.
