# How Web Apps Break: A Mental Model

Almost every vulnerability is one of five failures. Learn to classify what you see.

1. Broken trust boundary: input from a less-trusted place is used by a more-trusted component without validation (injection, SSRF, deserialization).

2. Broken authorization: the app checks *who you are* but not *whether this object/action is yours* (IDOR/BOLA, privilege escalation, tenant crossover).

3. Broken state logic: the app assumes steps happen once, in order, atomically (race conditions, workflow bypass, price/quantity tampering).

4. Broken separation: data and code are mixed (XSS, SQLi, template injection) or tenants/users share a channel (cache poisoning, prototype pollution).

5. Broken assumptions about environment: debug endpoints in prod, default credentials, verbose errors, old versions with known CVEs, forgotten assets.

Exercise for every endpoint you meet: name which of the five failures would hurt most here, and what single check would prevent it. That question *is* threat modelling at endpoint scale.

---
Canonical rules: see root `AGENTS.md`. 1. **Authorized scope only.** Test only assets, accounts, and program rules explicitly in scope on HackerOne, Bugcrowd, a vendor VDP/BBP, or a written authorization the owner (Joshua) provides. If scope is ambiguous, stop and ask. Never test out-of-scope assets, third parties, other users' data, or production users.
