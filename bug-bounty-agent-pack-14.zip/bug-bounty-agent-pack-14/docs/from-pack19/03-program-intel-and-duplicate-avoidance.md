# Program Intel and Duplicate Avoidance

Winning hunters research the program as hard as the target.

Read the policy twice: scope, exclusions, safe harbor, automation rules, reward table, SLAs. Screenshot/archive it in the hunt folder — policies change.

Map the program's history: disclosed reports (HackerOne Hacktivity, Bugcrowd Disclosure), the classes already found repeatedly are (a) proven valuable and (b) heavily hunted — differentiate by testing *variants and neighbours*, not copies.

Known-issues lists and 'informative/duplicate' patterns tell you the triage bar: what evidence, impact, and novelty this program demands.

Fingerprint the business: a fintech's crown jewels are money movement and KYC data; a SaaS's are tenant isolation; a consumer app's are account takeover and privacy. Test where the business bleeds.

Duplicate discipline: before deep testing, search disclosed reports for your exact endpoint+class. During testing, keep hypotheses specific enough that a duplicate is still informative (new root cause, new chain link, broader scope).

Time-boxing: allocate hunt time by surface value (docs/11... no — by threat model ranking), and log dead ends; a logged dead end is an asset, it stops future you re-testing it.

---
Canonical rules: see root `AGENTS.md`. 1. **Authorized scope only.** Test only assets, accounts, and program rules explicitly in scope on HackerOne, Bugcrowd, a vendor VDP/BBP, or a written authorization the owner (Joshua) provides. If scope is ambiguous, stop and ask. Never test out-of-scope assets, third parties, other users' data, or production users.
