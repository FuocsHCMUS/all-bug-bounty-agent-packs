# Threat Modelling (Phase 0.5)

Fifteen to forty-five minutes that decide whether a hunt is focused or random.

Draw the actors: anonymous visitor, free user, paying user, tenant admin, platform admin, partner/API client, service-to-service identity, webhook sender. Note what each *should* be able to do.

Draw the boundaries: browser<->API, tenant<->tenant, user<->admin tooling, app<->cloud metadata/third parties, free<->paid. Bugs are boundary crossings that should not happen.

List crown jewels: money movement, password/email change, PII at scale, tenant data, admin actions, signing keys/tokens, audit logs themselves.

Score surfaces: Impact (1-5) x Plausibility (1-5) x Novelty for this program (1-5). Test the top 5 first. Re-score after recon — the model is a living document.

Write abuse stories in one sentence each: 'As a free user, I export another tenant's invoices by changing the tenant id in the export URL.' Each abuse story becomes a hypothesis-ledger entry verbatim.

---
Canonical rules: see root `AGENTS.md`. 1. **Authorized scope only.** Test only assets, accounts, and program rules explicitly in scope on HackerOne, Bugcrowd, a vendor VDP/BBP, or a written authorization the owner (Joshua) provides. If scope is ambiguous, stop and ask. Never test out-of-scope assets, third parties, other users' data, or production users.
