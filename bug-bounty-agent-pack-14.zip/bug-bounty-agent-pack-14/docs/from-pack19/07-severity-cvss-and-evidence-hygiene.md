# Severity, CVSS, and Evidence Hygiene

Honest ratings and clean evidence are a hunter's reputation.

CVSS honestly: score the *proven* impact, on the *proven* scope, with the *actual* preconditions. State the vector and each assumption. If the program uses its own scale, map to theirs and show both.

The proven/indicated/speculative ladder: proven = reproduced end-to-end on your accounts; indicated = strong partial evidence, one link unverified (say which); speculative = plausible, untested or untestable safely (goes in notes, not in a submission).

Evidence kit per finding: UTC timestamps, account labels (A/B), full redacted request/response pairs, before/after state, a minimal PoC description a triager can replay in under 5 minutes, and a short screen recording only if it clarifies (never as the sole evidence).

Redaction: tokens, cookies, real names/emails, and any third-party data are removed *before* anything leaves the hunt folder. Keep an unredacted copy only locally, only if needed, and note its existence.

Anti-inflation checklist: no chaining credit for unproven links; no 'could lead to' without a demonstrated path; self-only impact rated as self-only; missing-header findings need a demonstrated attacker capability to matter.

---
Canonical rules: see root `AGENTS.md`. 1. **Authorized scope only.** Test only assets, accounts, and program rules explicitly in scope on HackerOne, Bugcrowd, a vendor VDP/BBP, or a written authorization the owner (Joshua) provides. If scope is ambiguous, stop and ask. Never test out-of-scope assets, third parties, other users' data, or production users.
