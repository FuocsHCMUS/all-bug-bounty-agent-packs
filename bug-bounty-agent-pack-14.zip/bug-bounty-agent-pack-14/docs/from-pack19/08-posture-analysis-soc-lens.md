# Posture Analysis: The SOC Lens

After the bug: what this company is good at, where it is exposed, and how a defender would see you.

Structure (full template in templates/posture-analysis.md): strengths observed; the specific gap; systemic-or-isolated judgement with evidence (sibling endpoints tested); risk register entries; detection design; response recommendations.

Detection design method: for your own attack, list (a) the network/HTTP fingerprint, (b) the auth/account events, (c) the sequence that is anomalous vs normal users, (d) a SIEM detection idea in plain words ('alert when one account requests >N distinct object IDs of another tenant within M minutes'), (e) expected false positives and how to tune them.

Think like the blue team you want to become: every offensive technique in this pack has a mirror detection. Writing both sides is how a student becomes a SOC-capable pentester instead of a payload copier.

Fairness rules: credit controls you actually observed (blocked payloads, short-lived tokens, audit trails that caught your test), never invent weaknesses you did not test, and label estimates as estimates.

---
Canonical rules: see root `AGENTS.md`. 1. **Authorized scope only.** Test only assets, accounts, and program rules explicitly in scope on HackerOne, Bugcrowd, a vendor VDP/BBP, or a written authorization the owner (Joshua) provides. If scope is ambiguous, stop and ask. Never test out-of-scope assets, third parties, other users' data, or production users.
