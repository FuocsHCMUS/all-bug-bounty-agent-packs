# The Tutor Ladder: Beginner to Operator

How this pack teaches while it hunts — and how Joshua should study with it.

Rung 0 Foundations: networking (docs/00) and HTTP (docs/01) until the self-checks are easy.

Rung 1 Guided reading: for each finding, read its learning note's concept ladder bottom-up; do the self-check questions out loud before revealing answers.

Rung 2 Replication in a lab: rebuild the bug class in a deliberately vulnerable local/practice app (e.g. a Web Security Academy lab or a local Docker lab — Tier B approval if installing). Never practise on real targets.

Rung 3 Variation: change one condition of the lab bug (different parser, added check) and predict whether the technique survives. Prediction before testing is where understanding forms.

Rung 4 Detection mirror: write the SOC detection for the technique before reading the posture note's version; compare.

Rung 5 Teach-back: explain the concept in 5 sentences as if to a friend. Gaps in the explanation are the study list for next session. Spaced repetition: revisit cards at 1 day / 1 week / 1 month (scripts/learning_card.py generates them).

---
Canonical rules: see root `AGENTS.md`. 1. **Authorized scope only.** Test only assets, accounts, and program rules explicitly in scope on HackerOne, Bugcrowd, a vendor VDP/BBP, or a written authorization the owner (Joshua) provides. If scope is ambiguous, stop and ask. Never test out-of-scope assets, third parties, other users' data, or production users.
