# Disclosure, Retest, and Duplicates

The lifecycle after Joshua submits — the agent prepares, Joshua decides and submits.

The agent never submits. The agent prepares: a submission-ready draft (templates/finding-report.md), a duplicate self-check (templates/duplicate-check.md), and a one-paragraph summary Joshua can paste.

If triage asks for more proof: extend evidence only within the original scope and safe-proof rules; log every extra request in the hunt folder.

Retest protocol (workflows/retest.md): reproduce the original steps exactly; then test the two nearest variants (sibling endpoint, alternate encoding/method); verdicts: Fixed / Partially fixed / Not fixed / Cannot verify — each with evidence. A partial fix is a new finding for Joshua to consider, reported to him only.

Duplicates happen. Mine them: a duplicate verdict plus the original's disclosure (if public) teaches what the program values; log the lesson in the learning note and move on without re-submitting variants that add nothing.

---
Canonical rules: see root `AGENTS.md`. 1. **Authorized scope only.** Test only assets, accounts, and program rules explicitly in scope on HackerOne, Bugcrowd, a vendor VDP/BBP, or a written authorization the owner (Joshua) provides. If scope is ambiguous, stop and ask. Never test out-of-scope assets, third parties, other users' data, or production users.
