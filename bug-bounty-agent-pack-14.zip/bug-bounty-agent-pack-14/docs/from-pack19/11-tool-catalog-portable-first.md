# Tool Catalog: Portable-First

What to reach for, in approval order. Prefer understanding + small scripts over heavy scanners.

Tier A (pre-approved, workspace only): this pack's scripts; git clones of public research repos; portable binaries dropped in the workspace; Python venv + pip; curl; a local intercepting proxy *portable* build if Joshua already has it — otherwise Tier B.

Tier B (ask Joshua): anything installed system-wide on Windows, Burp Suite / proxy installs, Nmap/ZAP installs, packet drivers (Npcap), Docker Desktop, and all MCP servers / agent plugins / extra skills.

Research tools (no target contact): NVD API (scripts/cve_lookup_nvd.py), advisory databases, search engines, CTF archives. These never need target scope, only accuracy and citations.

A scanner is not a strategy: automated scanning only where the program explicitly allows it, at polite rates, after manual understanding. Several programs ban it outright — the policy you archived in Phase 0 decides.

Record every tool in the hunt log: name, source, version, why, and what it touched.

---
Canonical rules: see root `AGENTS.md`. 1. **Authorized scope only.** Test only assets, accounts, and program rules explicitly in scope on HackerOne, Bugcrowd, a vendor VDP/BBP, or a written authorization the owner (Joshua) provides. If scope is ambiguous, stop and ask. Never test out-of-scope assets, third parties, other users' data, or production users.
