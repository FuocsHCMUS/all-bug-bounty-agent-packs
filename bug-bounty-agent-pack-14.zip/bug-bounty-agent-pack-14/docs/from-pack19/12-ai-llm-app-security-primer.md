# AI / LLM App Security Primer

Modern programs increasingly include AI features; their bug classes rhyme with classic ones.

Map the system: user prompt -> system prompt/context -> retrieval (documents, tools) -> model -> actions/output. Trust boundaries sit between every arrow.

Prompt injection is the new injection: untrusted content (a document, a webpage, another user's message) carrying instructions the model obeys. Direct (your own prompt) matters less than indirect (planted content a victim's assistant later reads).

Excessive agency: an assistant with tools (email, tickets, code, payments) turns a text bug into an action bug. Test what the agent may *do*, with your own accounts only.

Data leakage: system prompts, other tenants' retrieved documents, and training-adjacent data exposed via retrieval or completion. Tenant separation in the vector store is the IDOR of AI apps.

Classic bugs still apply around the AI: the APIs, auth, uploads, and billing of AI products are ordinary web surface — hunt them with the ordinary playbooks first.

---
Canonical rules: see root `AGENTS.md`. 1. **Authorized scope only.** Test only assets, accounts, and program rules explicitly in scope on HackerOne, Bugcrowd, a vendor VDP/BBP, or a written authorization the owner (Joshua) provides. If scope is ambiguous, stop and ask. Never test out-of-scope assets, third parties, other users' data, or production users.
