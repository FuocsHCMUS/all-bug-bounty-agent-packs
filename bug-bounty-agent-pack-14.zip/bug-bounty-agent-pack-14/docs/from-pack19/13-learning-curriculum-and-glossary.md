# Learning Curriculum and Glossary

A 12-week self-study spine that pairs with hunting, plus the words you will meet.

Weeks 1-2: Networking from zero (docs/00) + capture your own traffic in a lab and label every layer.

Weeks 3-4: HTTP/web from zero (docs/01) + read raw requests/responses for every site you test.

Weeks 5-6: The five failure families (docs/02) + one lab per family.

Weeks 7-8: Auth, sessions, and authorization playbooks; two-account testing drills in labs.

Weeks 9-10: Injection, SSRF, and parser differentials; the Research Engine applied to 3 public CVEs (read the patch diffs).

Weeks 11-12: Posture + SOC lens: write detections for everything you found; build a tiny log-review habit.

Glossary (first-use definitions used across the pack): Asset — anything in scope. Oracle — an observable signal that answers a yes/no question about the target. Primitive — a small reusable attacker capability (e.g. 'read one arbitrary file'). Chain — primitives composed so the output of one feeds the next. Tenant — one customer organisation whose data must be isolated from others. BOLA/IDOR — accessing another user's object by changing its identifier. SSRF — tricking the server into making requests for you. XSS — attacker script running in a victim's browser under the site's origin. CSRF — a victim's browser being tricked into sending an authenticated request. CVSS — a standard scoring system for vulnerability severity. SIEM — the defender's log-collection and alerting platform. Threat model — a structured list of actors, boundaries, and valuable things, used to prioritise testing.

---
Canonical rules: see root `AGENTS.md`. 1. **Authorized scope only.** Test only assets, accounts, and program rules explicitly in scope on HackerOne, Bugcrowd, a vendor VDP/BBP, or a written authorization the owner (Joshua) provides. If scope is ambiguous, stop and ask. Never test out-of-scope assets, third parties, other users' data, or production users.
