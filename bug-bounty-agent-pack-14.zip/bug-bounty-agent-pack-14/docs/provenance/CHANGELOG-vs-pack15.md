# Changelog — Pack 18 vs Pack 15

Pack 18 is a superset of pack 15. Everything from pack 15 is kept and
carried forward; the items below are new or materially expanded.

## New in v18
1. **Threat-model-first phase (Phase 0.5)** — `AGENTS.md` §12,
   `templates/12-threat-model.md`, `core/07-threat-modeling-and-abuse-stories.md`.
   Crown jewels, actors, trust boundaries, invariants, abuse stories.
2. **`workflows/` layer (7 files)** — executable step-by-step routes that sit
   between the AGENTS.md map and the playbooks: start-a-hunt, CVE sweep,
   writeup-mining sprint, creative chain lab, validate-and-report,
   posture-and-teach-back, weekly review & retest.
3. **Playbook 13 — Client-side & Browser Security** — DOM XSS, postMessage,
   CORS deep-dive, CSP bypass thinking, DOM clobbering, XS-Leaks, cache issues.
4. **Playbook 14 — Deserialization, Prototype Pollution & Supply Chain** —
   Java/Python/PHP/.NET deserialization, JS prototype pollution (client+server),
   dependency confusion, CI/CD and package-registry angles (in-scope only).
5. **Playbook 16 — Disclosure, Retest & Duplicates** — report lifecycle,
   duplicate handling, fix verification + regression variants, disclosure etiquette.
6. **Playbook 15** — validation & impact expanded with CVSS 3.1/4.0 guidance,
   severity negotiation language, and "impact ladder" (prove one rung higher,
   safely).
7. **Core 05 — Hypothesis & Creative Engine** and **Core 06 — Teaching
   Protocol** promoted from scattered notes into standalone core files.
8. **Learning expansion** — `learning/03-networking-from-zero.md`,
   `learning/04-web-and-http-from-zero.md`, `learning/05-soc-lens.md`
   (defender translation + detection ideas), `learning/06-safe-lab-roadmap.md`.
   Glossary expanded (02) with v18 terms.
9. **Checklists** — scope-gate, exploit-safety, learning-retention
   (spaced repetition + flashcard format) added to the original three.
10. **Templates** — threat model (12), chain canvas in Mermaid (10),
    retest & disclosure log (11), asset inventory (renumbered into 02 set).
11. **Prompts** — threat-model session (07) and retest session (08) added.
12. **References** — dedicated CVE/advisory source list and writeup/CTF
    source list, split out from the single trusted-sources file.
13. **Examples** — fictional CVE-match walkthrough and fictional chain
    walkthrough added to the end-to-end finding example.
14. **Scripts** — `headers_check.py`, `tech_fingerprint.py`, `inventory.py`
    added (all stdlib-only, tested on Python 3.14). Pack now ships 7 helpers.
15. **Tools catalog** — `tools/tool-catalog.md`: portable tools by job,
    each marked Tier A (portable, clone into workspace) or Tier B (install/ask).

## Changed
- `AGENTS.md` rewritten and expanded (13 sections): two-account rule made
  explicit (§2.7), operator-submits-reports rule made explicit (§4 Tier B),
  differentials & state-machine doctrine (§6), detection opportunities
  required in posture analysis (§8), pack-expansion disclosure rule (§10),
  metrics section (§13).
- `SKILL.md` updated with playbook map, workflows, and new script list.
- `README.md` rewritten for v18 structure.
- Claude Code guidance clarified everywhere: **AGENTS.md is canonical,
  CLAUDE.md is only a shim** — no duplicated instructions to drift apart.
