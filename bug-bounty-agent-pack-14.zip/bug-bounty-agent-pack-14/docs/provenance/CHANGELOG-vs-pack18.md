# Changelog — Pack 20 vs Pack 18

Pack 20 is a superset of pack 18. Everything from pack 18 is kept and
carried forward unchanged in spirit — scope law (§2), the 3-tier approval
protocol (§4), threat-model-first hunting (§12), the two-account rule,
minimum-impact proof, posture analysis + learning notes after every
finding, and "the operator submits reports himself" all survive verbatim
in intent. The items below are new or materially expanded in v20.
`CHANGELOG-vs-pack15.md` (the v15 → v18 diff) is kept untouched for history.

## New in v20

### Playbooks (16 → 20)
1. **Playbook 17 — WebSocket / Realtime & HTTP Request Smuggling / Cache.**
   WebSocket handshake vs per-message authorisation, subscription and
   presence abuse, cross-site WebSocket hijacking thinking, realtime
   rate/ordering races; CL.TE / TE.CL and modern smuggling variants,
   parser differentials between front-end and back-end, cache poisoning
   and cache deception. Ships with an **extra safety gate** (AGENTS.md
   §14, checklist below) because failed probes can affect other users.
2. **Playbook 18 — OAuth / OIDC / Passkeys Deep Dive.** Splits identity
   out of playbook 04's general auth coverage: authorization-code flow
   step-by-step, PKCE downgrade/confusion, `state`/`nonce` failures,
   redirect URI parsing mismatches, token leakage via referer/logs/
   open redirects, refresh-token rotation and reuse, OIDC discovery and
   `id_token` signature/claims validation, hybrid/implicit legacy flows,
   account linking and SSO email-trust bugs, WebAuthn/passkey ceremony
   analysis (challenge, origin, RP ID, attestation vs assertion).
3. **Playbook 19 — Serverless & Edge.** Cloud functions (Lambda-style),
   edge workers, API gateways, event/S3/queue triggers, presigned URLs,
   per-function IAM over-privilege, environment-variable and cold-start
   shared-state leakage, function URL vs gateway auth differentials,
   log/observability gaps specific to ephemeral compute.
4. **Playbook 20 — Bug Chaining at Scale.** Program-wide primitive
   inventory, chain graphs, impact ladders for 3+ primitives, ordering
   chains by (impact × reliability), knowing when *not* to chain
   (duplicate risk, program chain rules). Extends playbook 08 and the
   v18 chain canvas from one chain to a discipline.

### Workflows (7 → 10)
5. **Workflow 08 — OSINT & Autonomous Research Sweep.** Structured
   read-only sweep: company/product footprint, docs and API references,
   public repos and status pages, historical scope and disclosed-report
   patterns. Explicitly people-free and social-engineering-free.
6. **Workflow 09 — Realtime / Smuggling / Cache Deep-Dive.** The gated
   executable route for playbook 17; refuses to start without the
   smuggling/cache safety checklist and a Tier B approval naming the
   exact probes.
7. **Workflow 10 — Chain-at-Scale Sprint.** Timed sprint that inventories
   all validated primitives in a program, graphs candidate joins, and
   produces one chain canvas (template 15) per credible chain.

### Core (7 → 10)
8. **Core 08 — Autonomous Agent Ops & Memory.** Session memory files,
   handoff summaries, long-hunt state, preserving negative results,
   anti-loop and anti-drift rules, when an agent must stop and summarise
   instead of continuing to act.
9. **Core 09 — Data Handling & OPSEC Hygiene.** Per-program
   compartmentation, evidence retention and deletion, secret handling,
   redaction at scale, what never leaves the operator's machine.
   Expands AGENTS.md §9 from a paragraph into a procedure.
10. **Core 10 — Detection & Purple-Team Lens.** Turns the v18 SOC lens
    into testable detection hypotheses per attack step, purple-team
    exercise design from real findings, and defender handover notes in
    every posture analysis.

### Learning (00–06 → 00–09)
11. **Learning 07 — Cryptography From Zero.** Hashing vs encryption vs
    signatures vs MACs, symmetric/asymmetric primitives, TLS 1.2/1.3
    handshake honestly explained, certificates, JWT structure and its
    classic failure modes — the minimum to reason about playbooks 17–18.
12. **Learning 08 — OS Basics: Linux & Windows for Pentest.** Users and
    permissions, processes and services, shells, filesystems, and where
    the logs live on both operating systems; mapped to what a pentester
    touches and what a SOC analyst reads.
13. **Learning 09 — Career Roadmap: SOC → Pentest.** Skills map with
    milestones, lab portfolio built from this pack's hunts, honest
    certification guidance, and how to evidence skill without oversharing
    confidential findings.

### Templates (00–12 → 00–15, gap at 09 as before)
14. **Template 13 — Identity Flow Map.** Sequence table/diagram for
    OAuth/OIDC/passkey flows: each step, each parameter, who validates
    what — filled passively before any active identity testing.
15. **Template 14 — Realtime & Smuggling / Cache Test Log.** Per-probe
    log with gate fields (checklist done? approval reference? self-only
    key? cleanup verified?) for playbook 17 work.
16. **Template 15 — Chain-at-Scale Canvas.** Multi-primitive chain
    planner (extends template 10): primitive inventory, join conditions,
    impact ladder, failure points, reporting strategy.

### Checklists (6 → 8)
17. **Checklist — AI-Agent Preflight.** Verifies the agent itself before
    a session: scope file present and current, hunt memory loaded,
    approval state known, evidence log initialised, correct playbook read.
18. **Checklist — Smuggling & Cache Safety.** Mandatory companion to
    AGENTS.md §14: program-prohibition check, self-only proof design,
    benign markers, single-probe discipline, cleanup verification,
    stop conditions.

### Scripts (7 → 10, all stdlib-first, tested on Python 3.14)
19. **`har_analyzer.py`** — offline: HAR capture → de-duplicated
    endpoint/parameter inventory, auth-header and content-type summary
    for the surface map. Tier A (works on your own captures only).
20. **`js_extract.py`** — offline: JavaScript bundle(s) → URLs, API
    paths, route names and interesting strings (keys are *reported as
    locations*, never exfiltrated — they belong to the target's bundle
    you already hold). Tier A.
21. **`evidence_hash.py`** — offline: SHA-256 manifest (`SHA256SUMS`)
    for an evidence folder, referenced from the evidence log. Tier A.

### Platform adapters
22. **Cursor:** 4th rule added —
    `platforms/cursor/.cursor/rules/30-creative-research-and-chaining.mdc`
    (creative R&D, writeup mining discipline, chaining at scale, gated
    classes). Cursor now ships 4 rules.
23. **Antigravity:** two workflows added —
    `.agent/workflows/osint-sweep.md` (`/osint-sweep`) and
    `.agent/workflows/chain-sprint.md` (`/chain-sprint`), in the same
    style as the existing five. Antigravity now ships 7 workflows.
24. **Claude Code / OpenCode adapter READMEs:** version references
    bumped to v20; guidance updated (AGENTS.md canonical; CLAUDE.md
    removed entirely in v20 — Claude Code reads AGENTS.md natively,
    per the operator's note; pack-19 made the same change).

## Changed
- `AGENTS.md` expanded from 13 to **14 sections**: new "What's new in
  v20" block, playbook references widened to 01–20, workflow list
  extended to 01–10, new §11 playbook map, new §14 smuggling/cache
  safety gate, §5 gains identity-research and offline-artefact-mining
  pipelines, §6 gains realtime/identity/serverless doctrine bullets,
  §8 posture analysis gains the purple-team requirement, §9 evidence
  gains mechanical hashing via `evidence_hash.py`.
- `SKILL.md` frontmatter and body updated: new trigger topics
  (WebSocket/realtime, smuggling/cache with gate note, OAuth/OIDC/
  passkeys, serverless/edge, chaining at scale, OSINT sweep), playbook
  map 17–20, core map 08–10, outputs and scripts lists updated (10 scripts,
  templates 13–15).
- `README.md` rewritten for the v20 structure (20 playbooks, 10
  workflows, 10 core, learning 00–09, templates 00–15, 8 checklists,
  10 scripts, Cursor 4 rules, Antigravity 7 workflows).
- `START-HERE.md` updated to v20 with a staged foundations path that
  inserts cryptography (07) and OS basics (08) before advanced hunting,
  and the career roadmap (09) as the long-view document.
- `EXPANSIONS.md` rewritten: original brief restated, pack 12–15 and
  v18 expansions summarised, and 17 new v20 expansions (items 25–41)
  each marked **NEW IN V20** with the learning/hunting reason for it.
- Claude Code guidance strengthened everywhere: **AGENTS.md is canonical
  and v20 ships no CLAUDE.md at all** — Claude Code reads AGENTS.md
  natively, so there is a single source of truth and nothing to drift.

## Not changed (deliberately)
- Approval tiers, scope law, rate discipline, stop conditions, and the
  operator-submits rule are identical to v18. v20 adds capability and
  one *stricter* gate (§14); it loosens nothing.

## Note on pack-19

Pack-19 was built in parallel on the same day (119 files, hypothesis-ledger
emphasis, also no CLAUDE.md). Pack-20 is a superset in scope: its hypothesis
backlog discipline (templates/02 + core/08 experiment-log discipline) covers
the ledger idea, and v20 adds the realtime/identity/serverless/chaining
playbooks, purple-team core, and offline HAR/JS/evidence tooling that
pack-19 does not have. If you used pack-19, migrate by copying your
`workspace/<program-slug>/` folders into pack-20 unchanged — all template
numbers 00-12 are identical.
