# Fictional Example: IDOR on Invoices (fully worked)

> ALL names, domains, and data below are fictional, invented for teaching. Any resemblance is coincidence.

Setup: ShopLite (fictional SaaS) lets Account A download invoice PDFs at GET /api/invoices/{id}/pdf. In the threat model, 'tenant isolation' is a crown-jewel boundary; the abuse story reads: 'As Tenant A, I download Tenant B's invoice by changing the invoice id.'

Hypothesis + oracle: Proven if B's canary invoice (created in B's tenant, containing the unique marker ACME-CANARY-123) is returned to A's session; disproven if the API returns 403/404 consistently across id formats.

Research pass: the CVE loop finds nothing relevant (custom code, no component CVE) — recorded as a negative. A disclosed-report technique card ('parent checked, child not checked') suggests also testing the nested path /api/tenants/{B}/invoices/{id} after the direct path.

Safe test: A requests B's canary invoice id only (learned from B's own session). Result (fictional): 200 + PDF containing the marker. One variable changed; no other tenants touched; volume = 2 requests.

Severity: High (confidential financial documents across tenants; CVSS-style reasoning stated with assumptions). Root cause: the endpoint authenticated the session but never checked invoice.tenant == session.tenant.

Posture sketch: Strengths — short session lifetime observed; TLS/HSTS correct; the *list* endpoint was correctly tenant-filtered (isolated mistake, not systemic ignorance). Gap — object-level authorization missing on the download path; sibling audit found the same pattern in 1 of 6 tested download endpoints (systemic within downloads). Detection — alert when one session requests invoice IDs belonging to >1 tenant; false positives: support staff tooling (separate role, allowlist it).

Learning-note sketch: roots in order — client/server, IP/port, DNS, TCP, TLS, HTTP request, cookie/session, object ID, tenant; analogy: a hotel keycard (session) that opens the gym (authenticated area) but should not open another guest's room (object) — the download endpoint checked the keycard, not the room.

Use this as the shape of a finished piece of work: hypothesis, oracle, research, safe proof, honest severity, posture with detection, and a first-principles learning sketch.
