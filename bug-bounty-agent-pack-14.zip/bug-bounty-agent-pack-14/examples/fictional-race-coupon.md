# Fictional Example: Race Condition on a One-Time Coupon (fully worked)

> ALL names, domains, and data below are fictional, invented for teaching.

Setup: MealBox (fictional) issues a one-time 20% coupon. The state machine says redeem is check-then-mark-used. Abuse story: 'I redeem the same coupon on two parallel checkouts and both succeed.'

Hypothesis + oracle: Proven if two near-simultaneous redemption requests (single-digit concurrency, Joshua's own coupon and carts) both return the discount and the coupon shows two uses; disproven if the second consistently fails with 'already used'.

Research pass: writeup mining yields a technique card on read-then-write races and last-byte synchronisation of parallel requests; CVE loop: not applicable (logic flaw) — recorded honestly rather than forced.

Safe test (fictional result): 5 parallel requests -> 3 succeed. Minimal concurrency, Joshua's own low-value coupon, carts abandoned afterwards, objects cleaned up.

Severity: Medium (bounded by coupon value/velocity; stated plainly, not inflated to 'unlimited money' — per-account coupon issuance limits cap the real impact, and the report says so). Root cause: redemption check and mark-used are not atomic; no unique constraint/lock.

Posture sketch: Strengths — coupon issuance is rate-limited per account (caps abuse). Gap — no idempotency/atomic claim on redemption; siblings: gift-card redemption shows the same pattern in a code-review sense but was NOT tested (labelled speculative, excluded from the submission, noted for Joshua to consider as a separate authorised test). Detection — same coupon ID succeeding >1 time is a perfect, zero-false-positive alert; also monitor parallel same-account checkout bursts.

Learning-note sketch: roots — request/response, state, database row, transaction/atomicity explained as 'both things happen or neither does'; race explained as two people walking through a door marked 'one at a time' at the exact same moment; analogy mapped back to check-then-act in code.

Use this as the shape of a finished piece of work: hypothesis, oracle, research, safe proof, honest severity, posture with detection, and a first-principles learning sketch.
