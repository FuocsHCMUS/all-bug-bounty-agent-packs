# Fictional Example: SSRF in a Webhook Tester (fully worked)

> ALL names, domains, and data below are fictional, invented for teaching.

Setup: HookLab (fictional) lets users 'test a webhook' by entering a URL the server then POSTs to. Threat model: the server sits inside a cloud VPC; SSRF here could reach internal services — crown-jewel boundary is server<->internal network.

Hypothesis + oracle: Proven (lowest rung) if the server makes a request to Joshua's own controlled endpoint with HookLab's expected payload and source characteristics; internal-reach rung proven only by the minimal differentiator, then STOP.

Research pass: CVE loop on the fingerprinted fetcher library finds a URL-parser advisory; technique card from a CTF writeup covers redirect-based filter bypass (validate-then-fetch follows a redirect to a different host). Both recorded with citations (fictional placeholders in this example's folder copy — replace with real citations in real hunts).

Safe test: first, Joshua's endpoint directly (passes, as designed). Then his endpoint replies with a redirect to a second path *on his own endpoint* — the server follows it, proving validation and fetching disagree. Only then, a single request toward a link-local metadata-style address is simulated in the *lab writeup*, and the example stops: in a real hunt that rung means minimal evidence + immediate escalation to Joshua.

Severity: High if internal reach is proven; Medium for the redirect differential alone — the fictional report says exactly that, splitting the two claims.

Posture sketch: Strengths — initial URL allowlist existed and blocked naive internal IPs. Gap — validation happened on the pre-redirect URL only (check/use mismatch). Detection — egress logs: server fetching unusual destinations, redirect chains in webhook tests, metadata-shaped paths; false positives: legitimate customer webhooks on odd ports (tune by destination reputation, not by port alone).

Learning-note sketch: roots — what a URL is (scheme/host/port/path), DNS resolution, redirects (3xx), who 'the server' is vs 'your browser'; analogy: asking a receptionist to deliver a letter — you write one address on the envelope the receptionist checks, but the letter inside redirects delivery elsewhere. Map back: validation reads the envelope; the fetcher follows the contents.

Use this as the shape of a finished piece of work: hypothesis, oracle, research, safe proof, honest severity, posture with detection, and a first-principles learning sketch.
