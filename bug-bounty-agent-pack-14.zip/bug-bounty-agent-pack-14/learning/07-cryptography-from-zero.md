# Learning 07 — Cryptography From Zero (for hunters, not mathematicians)

Cryptography ("crypto") is the maths that keeps secrets secret and proves
things weren't changed. You do not need to *invent* crypto to hunt bugs —
you need to recognise when a program *uses it wrong*. This file builds the
concepts from the floor up, then maps each one to the bug-bounty mistakes
you will actually meet.

Golden rule, learn it now: **never design your own crypto, and be deeply
suspicious of any app that appears to have done so.** Correct use of
standard, boring crypto is good security. Novel crypto in a web app is a
finding waiting for a hunter.

---

## 1. Three different jobs — encoding, encryption, hashing

Beginners mix these up because all three turn readable text into gibberish-
looking text. They do completely different jobs:

| | Job | Reversible? | Key? | Example |
|---|---|---|---|---|
| **Encoding** | *Represent* data in another format | Yes, by anyone — it's a public recipe | No | Base64, URL-encoding, hex |
| **Encryption** | *Hide* data so only a key-holder can read it | Yes, **with the key** | Yes | AES-GCM, ChaCha20-Poly1305 |
| **Hashing** | *Fingerprint* data; prove it didn't change | **No** — one-way by design | No (but see §5) | SHA-256, bcrypt (specialised) |

### 1.1 Encoding is not security

Base64 turns `hello` into `aGVsbG8=`. Anyone can reverse it in one second —
it exists so binary data can travel through text-only systems (emails,
URLs, JSON). **Bug-bounty consequence:** "the token is Base64, so it's
protected" is false, and "the app Base64-encodes the user ID in the cookie —
decoding it reveals a plain, changeable ID" is a classic first finding.
Always decode what you meet (Base64, hex, URL-encoding) and *look*.

### 1.2 Encryption: a locked box

Encryption = plaintext + key → ciphertext; ciphertext + same/right key →
plaintext. Two families:

- **Symmetric** — one shared secret key locks and unlocks (AES). Fast;
  the hard problem is *both sides need the key, and nobody else may get it*.
- **Asymmetric / public-key** — a matched pair: a **public key** anyone may
  know, and a **private key** only the owner holds. What the public key
  locks, only the private key opens (and vice versa for signatures, §4).
  Slower; solves the sharing problem. TLS (§3) uses both: asymmetric crypto
  to agree a fresh symmetric key, symmetric crypto for the actual traffic.

Words you will meet: **IV / nonce** — a random, never-reused value mixed
into each encryption so encrypting the same plaintext twice gives
different ciphertext. Reused nonces and fixed IVs are real bugs (§6).

### 1.3 Hashing: a fingerprint that can't be un-fingerprinted

A hash function takes any input and produces a fixed-size fingerprint
(SHA-256 → 64 hex characters). Properties that matter:

- **Deterministic:** same input → same fingerprint, always.
- **One-way:** given the fingerprint, you cannot compute the input back.
  (You can only *guess* inputs and compare — which is why weak passwords
  fall, §5.)
- **Avalanche:** change one letter of the input and the fingerprint is
  unrecognisably different.
- **Collision-resistant (good hashes):** nobody can find two different
  inputs with the same fingerprint. MD5 and SHA-1 have failed this in
  practice — seeing them "protecting" anything important is a smell.

Hashes prove *integrity* ("this file/message is unchanged") and, in a
specialised form, store passwords (§5). A hash is **not** encryption:
there is no key and no "decrypt."

---

## 2. Signatures and MACs: proving "really from them, unchanged"

- **MAC (Message Authentication Code)** — a tag computed from a message +
  a *shared secret key* (e.g. HMAC-SHA256). Anyone with the key can make
  or check tags; anyone without it can do neither. Used for API request
  signing and signed cookies.
- **Digital signature** — the asymmetric version: the *private* key signs,
  anyone with the *public* key verifies. Used for software updates, JWTs
  (§4), certificates (§3).

Both answer the same question — *"did this really come from the holder of
the key, untouched?"* — which is called **authenticity + integrity**.
Encryption alone does **not** guarantee it: some encryption modes let an
attacker flip bits in ciphertext and predictably change the plaintext
without ever knowing the key. That's why modern practice is **authenticated
encryption** (e.g. AES-**GCM**, where GCM adds the tag) — secrecy and
tamper-proofing together. When reading about a target: "encrypted" without
"authenticated" is a question to ask, not a comfort.

---

## 3. TLS: the padlock, simplified

TLS (what makes HTTPS) combines everything above in one handshake.
Simplified to the ideas that matter for hunting:

1. **Hello + certificate.** Your browser says hello; the server presents a
   **certificate** — essentially an ID card containing the server's public
   key, signed by a **Certificate Authority (CA)** your browser already
   trusts. This signature is how you know the public key really belongs
   to `example.com` and not to an impostor.
2. **Key agreement.** Using asymmetric crypto, browser and server jointly
   create a brand-new **session key** that eavesdroppers can't derive,
   even though the conversation so far happened in public.
3. **Symmetric traffic.** All real data now flows encrypted (and
   authenticated) with that session key — fast, private, tamper-evident.
4. **Forward secrecy** (modern TLS): the session key is temporary, so
   stealing the server's private key *later* doesn't unlock recordings of
   *past* sessions.

Hunter's takeaways: mixed-content and missing-HTTPS flaws weaken step 3;
certificate problems weaken step 1's identity check; and most "TLS bugs"
in bug bounty are actually *configuration* bugs — old protocol versions,
weak cipher suites, HSTS missing (see `scripts/headers_check.py` thinking),
certificates for the wrong hostname on a forgotten subdomain.

---

## 4. JWT anatomy: a signed (not encrypted!) name tag

A JSON Web Token is the badge format half the web uses for sessions/APIs.
It has three Base64url-encoded parts joined by dots — decode one yourself
and this section becomes obvious:

```
HEADER . PAYLOAD . SIGNATURE
```

- **Header:** metadata — crucially `alg`, the algorithm used to sign
  (e.g. `HS256` = HMAC with a shared secret; `RS256` = RSA signature), and
  sometimes `kid` (which key) or `jku`/`x5u` (where to fetch the key!).
- **Payload:** the *claims* — plain JSON, readable by **anyone**:
  `sub` (who), `exp` (expiry), `iat`, roles/scopes. **Encoded, not
  encrypted** (§1.1). Never put secrets in a JWT payload.
- **Signature:** a MAC/signature (§2) over `header.payload`, so any edit
  to the claims *should* invalidate the token — if the server verifies
  correctly. The entire security of a JWT is the verification step.

Classic JWT mistakes hunters test for (scoped, test accounts only):

| Mistake | Idea in one line |
|---|---|
| `alg: none` accepted | Token edited to claim "no signature" — and a broken verifier agrees |
| Algorithm confusion | Server tricked into verifying an RS256 token with HMAC, using the *public* key as the HMAC secret |
| Weak HMAC secret | Short/guessable secret → offline brute-force of the signature, then forge any claims |
| `kid` / `jku` abuse | Attacker-controlled key reference: path traversal to a known file, or pointing the server at an attacker-hosted key |
| Missing `exp` check | Expired tokens accepted forever; logout doesn't invalidate |
| Claims trusted without verification | Any of the above's lazy cousin: decode-and-trust |

Method: change **one** thing (one claim, or the alg), keep everything else
identical, compare responses against the untouched baseline — the pack's
one-variable rule (Core 03) was made for exactly this.

---

## 5. Password storage: why "encrypted passwords" is a red flag

A well-built site never stores your actual password — it stores a
**slow, salted password hash** and compares hashes at login:

- **Salt** — a random value stored per user, mixed into the hash. It makes
  two users with the password `hunter2` have different stored values, and
  kills precomputed "rainbow tables" of common passwords.
- **Slow / memory-hard functions** — bcrypt, scrypt, Argon2 (the modern
  first choice). They are deliberately expensive, because the attacker's
  only route is guessing: hash each guess and compare. If each guess costs
  real time/memory, billions of guesses stop being cheap. A *fast* hash
  (MD5, SHA-1, raw SHA-256) for passwords is a genuine weakness — GPUs
  try billions per second.
- **Pepper** (optional extra): a site-wide secret kept *outside* the
  database, so a database-only leak doesn't enable guessing at all.

So, in reports and posture notes: passwords should be **hashed (slowly,
salted)**, never **encrypted** (reversible = anyone with the key recovers
every password) and never, ever plaintext. What you can observe as a
black-box hunter is limited — password-reset behaviour, policy, breach
responses — label storage claims *Inferred* unless the target itself
exposes them (e.g. in a leak *it* shows you — then stop and escalate per
Core 09; do not go cracking real users' hashes).

---

## 6. Common crypto misuse in bug bounty (the field guide)

| Misuse | Why it's broken, plainly | Where you meet it |
|---|---|---|
| Predictable tokens | Reset/invite/session tokens from time, counters, or weak randomness can be guessed | Password reset, invite links, "unsubscribe" tokens |
| ECB mode (AES-ECB) | ECB encrypts identical blocks identically — patterns in the plaintext show through in the ciphertext (the famous "ECB penguin" image stays recognisable) | Legacy APIs, encrypted blobs/cookies |
| Fixed / zero IV, reused nonce | Same input → same output; leaks equality, and in some modes destroys security entirely | Custom cookie/file encryption |
| Encryption without a MAC | Ciphertext can be tampered with predictably (§2) | Encrypted cookies, client-side "secure" storage |
| Padding oracle (concept) | Server reveals "padding OK?" vs "padding bad" via different errors/timing; patient attackers decrypt byte-by-byte | Old CBC-mode APIs — recognise the *shape*, study before testing |
| Hardcoded keys/secrets | Key shipped in JS/mobile app → everyone has the "secret" | Signed requests, "encrypted" client data |
| Rolling your own | Home-made token formats, custom "encryption" (XOR with a repeating key is a classic) | Small tools, IoT-ish panels, CTF-flavoured real apps |
| Weak/obsolete primitives | MD5/SHA-1 for integrity or passwords, DES/RC4, short RSA keys | Older stacks, forgotten subdomains |
| Token comparison flaws | Early-exit string compare → timing leaks; or tokens checked loosely (`==` type juggling in some stacks) | API keys, webhook signatures |
| Secrets in tokens | JWT payloads / signed URLs carrying data the user shouldn't read | §4 — decode everything |

For each: the beginner move is not "exploit it" — it is (1) name the
misuse, (2) build the smallest safe proof with test accounts, (3) explain
the fix (the standard primitive, used the standard way).

---

## 7. Randomness: the quiet foundation

Tokens, salts, IVs, session IDs, reset links — all security-critical
values must come from a **cryptographically secure random generator**
(CSPRNG: `secrets` in Python, `crypto.getRandomValues` in browsers,
`SecureRandom` in Java). Ordinary "random" functions (Python's `random`,
JavaScript's `Math.random`) are built for simulations and games: their
future outputs are predictable from past outputs. **Hunter's reflex:**
any security value that looks sequential, time-shaped (decodes to a
timestamp?), short, or low-variety across samples is worth a hypothesis.
Collect samples from your *own* test accounts only, and analyse offline.

---

## 8. Exercises (lab / test accounts only)

1. **Decode hunt.** Take a JWT from your own test session. Split it,
   Base64url-decode header and payload. Name every claim. State in one
   sentence exactly what the signature is protecting.
2. **Hash intuition.** In Python: hash `password`, `Password`, and
   `password ` (trailing space) with SHA-256. Observe the avalanche
   effect. Then hash a file before/after a one-byte change — this is how
   the evidence hashing in Core 09 works, and now you know *why*.
3. **Salt demo.** Hash the same password twice with a password-hashing
   library and two different salts. Confirm: different outputs, both
   verify. Write three lines on why a database leak is still bad — but
   far less bad — when this is done right.
4. **Spot the misuse.** In a deliberately vulnerable training app
   (Learning 06), find one item from the §6 table. Write it up using
   Template 08 (technique card): misuse, proof, fix.
5. **TLS read.** Pick a site you use daily; view its certificate in the
   browser. Identify: hostname(s), issuer (CA), expiry. Then check a
   test target's headers with the pack's scripts and note how HSTS
   relates to §3.

## 9. What to learn next

Authenticated encryption modes in one more layer of depth (GCM vs CBC
history) → key management basics (why keys in code/repos are the #1
real-world failure) → your first full writeup on one §6 misuse, read
*after* attempting Exercise 4 (research protocol: Template 14).
