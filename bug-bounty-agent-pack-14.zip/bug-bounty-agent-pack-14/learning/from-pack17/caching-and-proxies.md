# Primer: Caching and proxies

**Why.** The cache is a shared memory in front of the app. Poison it and you poison everyone.

## Layers
Browser cache -> CDN edge -> reverse proxy -> app. Each has a key (what it varies on) and a
TTL.

## Key concepts
- **Keyed input**: part of the cache key (usually method + path + some query).
- **Unkeyed input**: reaches the origin but is not in the key — the poison vector.
- **`Vary`**: tells caches which headers matter. Missing `Vary` on a reflected header is a bug.
- **Cache deception**: a keyed input the origin ignores, so a private page gets cached publicly.

## Practical
`X-Cache: HIT/MISS`, `CF-Cache-Status`, `Age`. Send a marker header, then a clean request, and
look for the marker. For deception, append `?x.css` or `;.css` to a private page and fetch it
logged out.

