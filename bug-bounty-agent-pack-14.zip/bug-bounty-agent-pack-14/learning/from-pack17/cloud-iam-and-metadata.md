# Primer: Cloud IAM and metadata

**Why.** SSRF becomes critical the moment it reaches a metadata service.

## Metadata endpoints
`http://169.254.169.254/latest/meta-data/` (AWS), with `iam/security-credentials/<role>` for
temporary keys. GCP needs `Metadata-Flavor: Google` and uses
`http://metadata.google.internal/computeMetadata/v1/`. Azure uses
`http://169.254.169.254/metadata/instance?api-version=...` with `Metadata: true`.

## Why it matters
Temporary credentials inherit the instance role. That role is usually over-permissive:
S3 read, sometimes `s3:PutObject`, occasionally `iam:*`. A stolen role is often the whole account.

## What to do with a hit
1. Record the role name and the policy if listed.
2. Prove one read (`aws s3 ls` with the keys, or a signed `GET`).
3. Do not enumerate everything; one convincing read is the report.
4. Note the expiry — short-lived keys still prove the class.

## Practical
Also test `169.254.170.2` (ECS task role) and IPv6 `[fd00:ec2::254]`.

