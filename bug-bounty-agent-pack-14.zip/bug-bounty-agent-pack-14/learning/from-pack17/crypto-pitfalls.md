# Primer: Crypto pitfalls you will actually meet

**Why.** Not to break crypto, but to spot misuse.

## Families
- **Encoding vs encryption**: base64 is not protection. JWT payloads are readable.
- **Weak randomness**: `Math.random`, timestamp seeds, `rand()` for tokens and reset links.
- **ECB mode**: identical plaintext blocks produce identical ciphertext blocks — visible
  structure, and cut-and-paste attacks.
- **Padding oracles**: distinguishable padding errors leak plaintext.
- **Fixed IV / nonce reuse**: same key + IV = XOR of plaintexts.
- **Hash without salt**, MD5/SHA1 for passwords, fast hashes for password storage.
- **Comparison timing**: `==` on secrets leaks length and prefix.
- **Client-side crypto**: keys shipped in JS, "encryption" that the client also decrypts.

## Practical
1. Decode every blob you see; if it is base64, read it.
2. Look for a repeated 16-byte block pattern (ECB) in any hex output.
3. Check reset-token length and charset; try to predict the next one.
4. Check whether the same IV repeats across two encryptions.

