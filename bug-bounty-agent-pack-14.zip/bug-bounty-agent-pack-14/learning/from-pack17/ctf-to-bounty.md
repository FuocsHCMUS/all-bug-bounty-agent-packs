# Primer: CTF to bug bounty translation

**Why.** CTF skills transfer, but the scoring is inverted.

## What transfers
Parser knowledge, source review, exploit chains, tooling fluency, patience.

## What does not
- CTF targets are designed to be solvable; production is designed to be boring.
- CTF gives you source; you get a black box and a JS bundle.
- CTF rewards the cleverest path; bounty rewards the *reportable* path with a clean impact.
- CTF flags are binary; triage is judgement.

## Translation table
| CTF habit | Bounty habit |
|---|---|
| Chase the intended path | Chase the cheapest real impact |
| One target until solved | Time-box per hypothesis, breadth first |
| Full exploit chain | Minimal PoC that proves the gain |
| Ignore duplicates | Check the disclosed corpus before testing |
| Ignore the UI | The UI is where the business rules live |

## The one rule
If you cannot explain the impact in one sentence to a product manager, it is not reportable yet.

