# Primer: DNS and namespaces

**Why first.** Scope, recon and takeover all live here.

## Records
`A` (v4), `AAAA` (v6), `CNAME` (alias), `MX` (mail), `TXT` (proof/verification), `NS`
(delegation), `SOA` (authority), `SRV`, `CAA`.

`CNAME` is the takeover primitive: it points a name at a provider's resource. If the provider
lets anyone claim that resource name, the name is hijackable.

## Hierarchy
Root `.` -> TLD -> registrable domain -> subdomain. Delegation happens at `NS`. Wildcards
(`*.example.com`) answer for any unmatched label.

## Practical
- `nslookup`, `dig`, `host`; `Resolve-DnsName` on Windows.
- Certificate transparency (`crt.sh`) is a passive subdomain goldmine: every cert ever issued.
- `dnsx`/`subfinder` for bulk; passive first.
- Always resolve before probing: a CNAME to a third party is a scope question.

## Habit
For every host: does it resolve, to what, and is the final target still in scope?

