# Primer: HTTP fundamentals

**Why first.** Every web bug is a disagreement about a message. You cannot see the
disagreement until you can read the message exactly.

## The message
```
METHOD /path?query HTTP/1.1
Header: value
Header2: value

body
```
Request line, headers, blank line, body. The blank line is structural — it separates headers
from body, and desync bugs live in who counts what.

## Terms
- **Method**: `GET` (read, should be safe), `HEAD` (headers only), `POST` (submit), `PUT`
  (replace), `PATCH` (partial), `DELETE`, `OPTIONS` (capabilities).
- **Status class**: 2xx success, 3xx redirect, 4xx client error, 5xx server error. 401 vs 403:
  not authenticated vs authenticated but forbidden. 404 can hide 403 deliberately.
- **Header**: metadata. `Host` picks the site on a shared IP — a huge attack surface.
  `Cookie` carries session state. `Authorization` carries tokens. `Content-Type` tells the
  parser how to read the body. `Content-Length` and `Transfer-Encoding` frame it.
- **Cookie attributes**: `Secure`, `HttpOnly`, `SameSite`, `Domain`, `Path`, `Expires`.
- **Idempotency**: repeating a `GET`/`PUT`/`DELETE` should not change the result; repeating a
  `POST` may. Broken idempotency is a bug class.

## What to practise
1. Read a request in DevTools and name every part.
2. `curl -v` the same request; compare.
3. Replay it with one header changed and predict the response before you send.
4. Capture a redirect chain and explain who chose each hop.

## The habit
Before every test, say what the message is and which field you are changing. One field.

