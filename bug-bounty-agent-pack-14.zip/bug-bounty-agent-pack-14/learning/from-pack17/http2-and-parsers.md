# Primer: HTTP/2 and parser differentials

**Why.** Most sophisticated bugs are two parsers disagreeing about the same bytes.

## HTTP/2 in one paragraph
Binary framing, multiplexed streams, HPACK header compression, `:authority` instead of `Host`.
Proxies downgrade h2 to h1.1 at the origin — and the downgrade is where framing assumptions
diverge.

## Parser differential families
- Framing: `Content-Length` vs `Transfer-Encoding` (desync).
- Path: `//`, `/./`, `/../`, `%2f`, `;`, backslash, unicode normalisation.
- Header: duplicate names, whitespace before colon, obs-fold, case.
- Body: JSON duplicate keys, `__proto__`, numeric vs string, charset tricks.
- URL: userinfo `@`, fragment `#`, IDN homoglyphs, trailing dot.

## Practical
Send the *same* semantic request through each layer and compare what arrives: client -> proxy
-> origin. Differences are hypotheses.

## Habit
Whenever two components touch the same bytes, ask which one is authoritative and what happens
if they disagree.

