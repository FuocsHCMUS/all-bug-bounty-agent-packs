# Primer: JavaScript runtime and the DOM

**Why.** Client-side bugs need you to know which sink executes what.

## Sources and sinks
Sources: `location`, `document.referrer`, `postMessage`, `localStorage`, `window.name`, API
responses. Sinks: `innerHTML`, `outerHTML`, `document.write`, `eval`, `Function`,
`setTimeout(string)`, `srcdoc`, `href="javascript:"`, `insertAdjacentHTML`.

## Framework escapes
React escapes by default except `dangerouslySetInnerHTML`. Angular sanitises except
`bypassSecurityTrust*`. Vue needs `v-html`. Alpine `x-html`. Every bypass is an explicit opt-out.

## Prototype pollution
`obj["__proto__"]["x"]=1` pollutes every object. Reachable via recursive merge, `JSON.parse` of
untrusted input with a merge, query-string parsers, and some template engines. Sink gadgets
turn it into XSS or RCE.

## Practical
In DevTools: `getEventListeners(window)` for message handlers, search bundles for
`postMessage`, `innerHTML`, `eval`. Then trace whether any source reaches them unvalidated.

