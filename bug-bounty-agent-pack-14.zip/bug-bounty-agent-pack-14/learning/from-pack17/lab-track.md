# Lab track (self-study, ordered)

Do these in order. Each maps to pack material; each ends with a written note in
`workspace/_learning/`.

1. **HTTP** — PortSwigger Web Security Academy: HTTP fundamentals, Burp basics. Note: message
   anatomy. (`http-fundamentals.md`)
2. **AuthN/AuthZ** — Academy: authentication, access control. Note: three authz layers.
   (`sessions-cookies-authn-authz.md`)
3. **IDOR** — Academy labs 1-4, then a real program's public reports. (`playbooks/idor-bola.md`)
4. **Injection basics** — SQLi, then XSS contexts. Note: parser contexts.
5. **SSRF + metadata** — Academy SSRF, then a cloud lab. (`playbooks/ssrf.md`)
6. **Client-side** — DOM XSS, CORS, postMessage. (`same-origin-cors.md`, `js-runtime-and-dom.md`)
7. **Desync + cache** — Academy request smuggling and cache poisoning. (`http2-and-parsers.md`)
8. **Business logic** — Academy logic labs; write the rule you broke each time.
9. **Recon discipline** — HTB/THM easy boxes, passive-first only.
10. **Report writing** — rewrite three of your own notes into the template; have the reviewer
    subagent attack them.

Track progress in `learning/skill-matrix.md`. One lab is not competence; three reports in a
class is.

