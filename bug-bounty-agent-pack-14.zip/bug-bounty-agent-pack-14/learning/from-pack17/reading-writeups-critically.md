# Primer: Reading writeups critically

**Why.** Copying payloads is how you waste a session. Extracting preconditions is how you win.

## Read in three passes
1. **Skim for the primitive**: what did the bug actually break? One sentence.
2. **Extract preconditions**: a bullet list of everything that had to be true. Framework,
   version, config, feature enabled, user role, a specific header, a race window.
3. **Only then** look at the payload, and ask which of those preconditions the payload depends on.

## Score the source
- Does it name a version and a fix commit? Better.
- Does it explain *why* the fix works? Best.
- Is it a vendor advisory (reliable), a conference talk (usually good), a blog with no repro
  (unreliable), a "top 10 payloads" listicle (noise)?

## Translate
For each precondition, write: "on the target, this would be true if ___". Then test the
cheapest one. If two preconditions fail, drop the source.

## Anti-pattern
Reading ten writeups in a class and testing zero. The loop is read -> precondition -> test.

