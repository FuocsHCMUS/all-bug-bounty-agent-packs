# Primer: Same-origin policy, CORS, postMessage

**Why.** These are the rules that decide whether your payload can read data.

## SOP
Origin = scheme + host + port. Scripts may not read cross-origin responses by default. They
may still *send* requests (which is why CSRF exists) and embed resources.

## CORS
The server opts in with `Access-Control-Allow-Origin`. `*` is fine for public data; with
credentials it must echo a specific origin, and `Access-Control-Allow-Credentials: true`
makes it dangerous. Bugs: origin reflection with credentials, `null` origin trust, regex
matching that accepts `evil-example.com`, subdomain trust where a subdomain is takeoverable.

## postMessage
`window.postMessage(data, targetOrigin)`. Bug when `targetOrigin` is `*` with sensitive data,
or when the receiver does not check `event.origin` and acts on the payload.

## Practical
1. Send `Origin: https://evil.com`, watch `ACAO` and `ACAC`.
2. Try `null`, `https://evil.example.com`, `https://example.com.evil.com`.
3. In the console, find `addEventListener("message"` handlers and check the origin test.

