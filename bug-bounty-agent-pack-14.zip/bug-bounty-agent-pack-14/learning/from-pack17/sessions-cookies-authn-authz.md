# Primer: Sessions, authentication, authorization

**Why.** Most high-severity bugs are authorization bugs, and you cannot find them without
separating the two words.

## Definitions
- **Authentication (authN)**: proving who you are. Password, OTP, passkey, certificate.
- **Authorization (authZ)**: deciding what that identity may do.
- **Session**: server-side state keyed by an identifier in a cookie or token.

## Where authZ lives
Three layers: per-function (may this role call this endpoint), per-object (may this subject
touch this row), per-field (may this subject see this column). Bugs are almost always a
missing object or field check.

## Session mechanics
`Set-Cookie` with `HttpOnly` (JS cannot read), `Secure` (TLS only), `SameSite` (cross-site
sending). Rotation on login prevents fixation. Logout must invalidate server-side.

## Practical
1. Two accounts, two browsers, one shared table of objects.
2. For each object: whose is it, and can the other account reach it?
3. Repeat with the role dropped one level and one level up.

## Habit
Never say "authenticated" when you mean "authorized". The distinction is the bug.

