# Skill matrix

Rate 0-3 (0 none, 1 read, 2 lab, 3 reportable). Update monthly.

| Area | Level | Evidence | Next step |
|---|---|---|---|
| HTTP message anatomy | | | |
| DNS / namespaces | | | |
| TLS / certs | | | |
| AuthN vs authZ | | | |
| IDOR / BOLA | | | |
| SQLi | | | |
| XSS (all contexts) | | | |
| SSRF | | | |
| SSTI | | | |
| XXE | | | |
| Desync | | | |
| Cache poisoning | | | |
| OAuth / JWT | | | |
| GraphQL | | | |
| Race conditions | | | |
| Business logic | | | |
| Recon | | | |
| Report writing | | | |
| Triage defence | | | |

Rule: you may claim a level only with a link to the note, lab, or report that proves it.

