# Primer: TLS and certificates

**Why.** Certificates are identity claims, and mis-issuance is a real bug class.

## Mechanics
Handshake: client hello -> server hello + certificate -> key exchange -> encrypted records.
The certificate binds a name to a key, signed by a CA the client trusts.

## Attack-relevant facts
- SAN lists leak names — including internal ones.
- Expired or mismatched certs on a subdomain are a finding (usually low).
- Weak TLS versions/ciphers on a payment path are low but reportable.
- Pinning in mobile apps means you need Frida or a patched client to intercept.

## Practical
`openssl s_client -connect host:443 -servername host`, or `nmap --script ssl-enum-ciphers`.
Read the SAN list — it is free reconnaissance.

## Habit
Grab the cert on every new host. It tells you siblings you did not know about.

