# Confirmation protocol

Expanded from `AGENTS.md` §3. The point is that the operator stays in control of footprint,
cost and blast radius without being asked about trivia.

## Decision test

Ask three questions in order:

1. Can it break something, cost money, or leave a trace on the target? -> ASK
2. Does it install, register, or persist outside `workspace/`? -> ASK
3. Is it reversible with a single command and zero target impact? -> GO

## ASK block

```
ASK: <one line, imperative>
Why: <decision it unblocks>
Cmd:
  <exact commands, copy-pasteable, venv-qualified>
Footprint: <n requests | MB | accounts | $>
Reversible: <yes: how | no: why acceptable>
Fallback: <what we do if the operator says no>
```

Always offer a fallback. "Then we stop" is rarely the best fallback.

## Standing approvals (do not re-ask)

- venv pip installs for the current session's declared need
- portable clone into `workspace/tools/vendor`
- SecLists-style wordlist fetch, subset <=5k lines
- GET/HEAD probing at or under 5 req/s
- writing any workspace artefact
- reading public research material

## Approval expiry

An approval covers the named command class for the session and the named target only. New
host, new class, or new day: re-ask. If the operator says "just go for recon", that is not
approval for fuzzing.

## When the operator is away

Queue ASKs in `notes/pending.md` and continue with GO-only work. Never self-approve an ASK.

