# Install log

Append one row per install or clone. Tier from `toolchain-tiers.md`.

| Date | Tier | Tool | Why | Location | Approved |
|---|---|---|---|---|---|
| | | | | | |

