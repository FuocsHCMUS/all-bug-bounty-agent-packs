# MCP and plugin requests

Queue here, then send the ASK block.

| Need | Server | Why | Risk |
|---|---|---|---|
| Browser automation with devtools | playwright MCP | client-side flows, DOM oracles | medium: real browser, session handling |
| Arbitrary fetch with header control | fetch MCP | raw request replay | low |
| Persistent memory across sessions | memory MCP | technique index | low |
| Burp-driven replay | Burp MCP | proxy-native testing | medium: needs Burp running |

Install command goes in the ASK block; `.mcp/mcp.example.json` holds a starting config.

