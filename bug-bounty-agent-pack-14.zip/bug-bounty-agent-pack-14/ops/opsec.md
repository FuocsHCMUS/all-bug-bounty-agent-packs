# Opsec

- Separate browser profile per program; no personal logins in the test profile.
- Disable extensions that rewrite traffic; verify with a clean request.
- Tag every request with a header if the program allows it: `X-BB-Researcher: <handle>`.
- Keep a per-program egress note (VPN/proxy exit, ASN) — some programs whitelist.
- Never reuse target-issued API keys across programs.
- Redact `Authorization`, cookies and tokens in reports; keep raw copies in `evidence/private/`.
- Screenshots: crop to the relevant region, include the URL bar and a visible timestamp.
- No public tweeting about an unfixed bug without approval.

