# Platform adapters

`AGENTS.md` is canonical. Adapters exist only so a platform that will not read it still gets
the non-negotiables.

| Platform | Loads | Adapter | Caveat |
|---|---|---|---|
| ClaudeCode | AGENTS.md, skills | `.claude/skills/...`, `.claude/settings.json` | settings.json is an example; merge, don't overwrite |
| Codex | AGENTS.md | none | keep AGENTS.md at repo root |
| opencode | AGENTS.md, opencode.json | permission map | verify permission keys against your version |
| Cline | `.clinerules/` | two rule files | Cline may also read AGENTS.md; keep both in sync |
| Cursor | `.cursor/rules/*.mdc` | core + reporting | `alwaysApply` only on core to save context |
| Antigravity | AGENTS.md, `.agent/rules/` | artifact overlay | AGENTS.md support varies by build — if absent, rules dir carries it |

Sync rule: if you edit AGENTS.md §1-6, mirror the change into `.clinerules/00-core.md` and
`.cursor/rules/00-core.mdc` in the same commit.

Windows note: no symlinks by default; these are real copies, keep them short.

