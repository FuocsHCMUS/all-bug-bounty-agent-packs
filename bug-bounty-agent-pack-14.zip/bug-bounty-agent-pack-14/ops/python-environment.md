# Python environment (Windows 11, 3.14+)

## Setup

```
py -3.14 -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r tools\requirements-optional.txt
```

Always invoke `.venv\Scripts\python.exe`, never bare `python` (PATH order is unpredictable).

## Rules

- Stdlib first. A dependency must save more time than the wheel-hunting it costs.
- Python 3.14 is new: check for cp314 wheels before choosing a package; prefer pure-python.
  If only a source build exists and it needs a compiler, propose an alternative instead.
- Pin versions in `tools/requirements-optional.txt` once something is used in anger.
- Never `pip install` globally without ASK; never `--break-system-packages`.
- `__pycache__` stays out of evidence.

## Script conventions

`argparse` with `--help`, JSON/JSONL out, exit 2 on usage error, exit 3 on scope violation,
no prompts, no globals, `main()`, safe to re-run, outputs under `workspace/`.

## Known-good stdlib patterns

- `ssl.create_default_context()` with `check_hostname=False` for CT-harvesting probes;
  record the certificate anyway.
- `http.client` for raw control (malformed paths, duplicate headers) where `urllib` normalises.
- `asyncio` + `Barrier` for race harnesses.
- `socketserver` for the OOB listener.

