# Rate limits and load discipline

Default: 5 req/s per host, 2 req/s on auth endpoints, concurrency <=10.

Adaptive: on 429/503, halve and honour `Retry-After`. On two consecutive 5xx, pause 30s and
note it. Never retry a 5xx more than twice.

Budget per hypothesis: 50 requests before you reassess. Per endpoint: 500 before moving on.

Time-of-day: prefer the target's off-peak for fuzzing; note the local timezone in `state.json`.

Wordlist discipline: <=5k lines for a first pass; derive the second pass from the first
pass's 200/30x hits; never run a 100k list blind.

Auth: create at most two accounts unless the bug needs more, and ask before the third.

