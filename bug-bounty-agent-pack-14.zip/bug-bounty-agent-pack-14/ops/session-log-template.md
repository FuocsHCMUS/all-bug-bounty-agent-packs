# Session log — <program> — <date>

Phase at start: / Phase at end:
Duration: / Requests sent (est):

## What was tested
-

## Results
- confirmed:
- killed:
- blocked + reason:

## Decisions and why
-

## Open hypotheses
| id | claim | next cheapest test |

## Blockers
-

## Pending confirmations
-

## Next three actions
1.
2.
3.

