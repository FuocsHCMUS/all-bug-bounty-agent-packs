# Toolchain tiers

Tier 0 stdlib script (GO) — Tier 1 portable vendor clone (GO) — Tier 2 installed tool (ASK) —
Tier 3 MCP/plugin (ASK) — Tier 4 paid service (ASK).

## Tier 1 candidates (portable, no installer)

`ffuf`, `nuclei`, `httpx`, `subfinder`, `dnsx`, `katana`, `gau`, `waybackurls`, `amass` (single
binary), `jwt_tool`, `paramspider`, `LinkFinder`, `SecretFinder`, `arjun`, `graphw00f`,
`smuggler`, `h2cSmuggler`, `interactsh-client`, `trufflehog`, `gitleaks`, `gf` + patterns,
SecLists subsets.

Clone into `workspace/<program>/tools/vendor/`, run from there, never add to PATH.

## Tier 2 (ASK)

Burp Suite / Caido, Wireshark, Docker Desktop, WSL, mitmproxy, Postman, sqlmap, nmap (needs
Npcap), Ghidra, Frida.

## Tier 3 (ASK)

MCP: fetch, playwright, filesystem, git, memory, sqlite. Plugins: browser devtools bridges,
Burp MCP, nuclei MCP.

## Tier 4 (ASK)

Paid proxies/residential egress, cloud sandboxes, API credits for LLM-assisted fuzzing,
Collaborator-style OOB SaaS when the program forbids self-hosted callbacks.

## Selection rule

Write one line of justification before climbing a tier. If tier 1 solves it in under ten
minutes, tier 2 is procrastination.

