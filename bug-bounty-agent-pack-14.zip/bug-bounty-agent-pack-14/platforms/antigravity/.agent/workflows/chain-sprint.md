# Workflow: /chain-sprint
Run `workflows/10-90-day-review-and-skill-gap-plan.md` (playbook 20) for the current
program. Precondition: at least **two validated primitives** exist for
this program — a chain is built from proven bugs, never from suspicions.
If fewer than two exist, say so and suggest `/cve-sweep` or a creative
session (workflows/04) instead.
1. Inventory: list every validated finding/primitive for the program in
   `templates/15-weekly-hunt-journal.md` — for each: asset, bug class,
   preconditions, what it **gives** (read / write / token / execution /
   information / foothold) and what it **needs** to fire.
2. Join: draw the candidate chains — link A gives what link B needs.
   Use differentials you already own (Account A/B, two tenants, two
   roles) as the test rig. Note chains the *program rules* disallow or
   cap (check the scope intake) before investing in them.
3. Rank: score each candidate chain by impact if complete × reliability
   of the weakest link × cost to prove safely. Pick ONE chain for this
   sprint; park the rest in the hypothesis backlog (templates/02).
4. Prove link by link: re-validate each link alone (playbook 15), then
   the full chain end-to-end, smallest possible demonstration, your own
   accounts/objects only — minimum-impact proof (AGENTS.md §2) applies
   to the whole chain, not just each link. Every active step is Tier B;
   group the approval ask into one message first. If any link touches
   smuggling/cache, the §14 gate and its checklist apply to that link.
5. Report strategy (operator decides): one chained report vs separate
   reports — draft the chained version with `templates/03`, showing each
   link's individual impact and the combined impact honestly (CVSS as
   support, playbook 15). The operator submits; you never do (§4 Tier B).
6. Close the sprint per AGENTS.md §8: posture analysis (templates/05)
   with purple-team detection hypotheses (core 10) — chains are where
   detection matters most, because each link alone may look benign —
   and learning notes (templates/06) that rebuild the chain one link at
   a time from first principles, plus 3–5 flashcards.
