# Workflow: /osint-sweep
Run `workflows/08-osint-and-attack-surface-discovery.md` for the current
program. Everything here is **read-only and Tier A** — no target traffic
beyond fetching public pages a normal visitor would load, no social
engineering, no people-targeting, ever (AGENTS.md §2, §4 Tier C).
1. Confirm the scope intake (`templates/00-scope-intake.md`) exists and
   note the program slug; create/refresh `workspace/<program-slug>/osint/`.
   If there is no scope file yet, run `/start-hunt` step 1 first.
2. Company & product footprint: official site, product pages, pricing/
   plan tiers (feature gates = authorisation boundaries), status page,
   changelog/release notes, public roadmap. Record *what changed recently*
   — new features are under-tested features.
3. Technical footprint (passive only): public docs and API references,
   developer portals, help centres, public GitHub/GitLab orgs (read code
   and READMEs; note exposed config *patterns*, never collect secrets —
   if you stumble on a live-looking credential, stop, do not test it,
   and tell the operator immediately), mobile app store listings,
   certificate-transparency names **only as leads** — a name is not scope
   until the program page says so.
4. Research memory: disclosed reports for this program (HackerOne/Bugcrowd
   hacktivity), writeups naming this stack (playbooks/07), CVE pre-sweep
   for fingerprinted tech (playbooks/06) — file technique cards
   (templates/08) and CVE match sheets (templates/07) as you go.
5. Offline artefacts: if the operator has browsed the target, offer to run
   `scripts/har_analyzer.py` on the HAR and `scripts/js_extract.py` on
   saved JS bundles (Tier A, local files) and merge the endpoint inventory
   into the target dossier (templates/01).
6. Deliverable: an OSINT summary in the dossier — footprint map, recent
   changes, 5–10 *sourced* leads (each: claim, source URL, why it might
   matter, which playbook would test it), and a refreshed hypothesis
   backlog (templates/02). Mark every lead Confirmed / Likely /
   Speculative. Stop and review with the operator before any active
   step — active testing is Tier B and belongs to `/start-hunt`.
