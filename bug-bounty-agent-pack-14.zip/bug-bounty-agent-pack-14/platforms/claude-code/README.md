# Claude Code setup — pack v20

Modern Claude Code reads **`AGENTS.md`** natively — that is the primary file.
Setup:
Pack version: **v20** (AGENTS.md is canonical — see its "What's new in v20"
block for playbooks 17–20, workflows 08–10, core 08–10, learning 07–09,
templates 13–15, the two new checklists, and the 10-script set).

1. Copy the pack root `AGENTS.md`, `SKILL.md` (optional) and the shared folders
   (`core/ playbooks/ workflows/ learning/ templates/ checklists/ prompts/
   scripts/ references/ examples/`) into your project root.
2. Install the skill: copy `.claude/skills/bug-bounty/SKILL.md` from this folder
   into your project's `.claude/skills/bug-bounty/SKILL.md`.
3. There is **no root `CLAUDE.md`** in v20 — Claude Code reads `AGENTS.md`
   natively, so no shim is kept. (Older packs shipped a 1-line shim that
   points to `AGENTS.md`. Do not maintain instructions in two places.
4. Optional MCP servers (Burp, browser, search) are **Tier B**: the agent must
   name the server and why; you install it, the agent never self-installs.
   Suggested starting point: no MCP at all — the playbooks work with
   browser + terminal + your proxy of choice.
5. Permissions tip: allow file writes inside the project and `git clone` into
   `./tools/`; keep network tools against targets behind your approval.
