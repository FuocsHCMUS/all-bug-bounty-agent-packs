# Cursor / Cline setup — pack v20
- Cursor: copy `.cursor/rules/*.mdc` into your project's `.cursor/rules/`
  and keep pack root `AGENTS.md` at project root (Cursor reads it too).
  v20 ships **4 rules**: `00-bug-bounty-core`, `10-safety-and-approvals`,
  `20-research-and-reporting`, and the new
  `30-creative-research-and-chaining` (creative R&D, chaining at scale,
  and the gated playbook 17–19 classes).
- Cline: copy `.muserules` to your project root (or split it into a
  `.muserules/` folder if you prefer per-topic files — keep the approval
  rules in an always-loaded file).
Both adapters are thin: canonical instructions stay in root `AGENTS.md`.