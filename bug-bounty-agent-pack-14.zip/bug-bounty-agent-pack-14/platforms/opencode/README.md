# OpenCode setup — pack v20
Copy pack root `AGENTS.md` to your project root (OpenCode loads it
automatically; v20 adds playbooks 17–20, workflows 08–10, core 08–10,
learning 07–09, templates 13–15, two new checklists, 10 scripts, and the
AGENTS.md §14 smuggling/cache safety gate), copy
`.opencode/agent/bug-bounty.md` into your project's `.opencode/agent/`,
and — only after reviewing it yourself — copy `opencode.json.example`
to `opencode.json`. Adding MCP servers in that config is operator-only
(Tier B rule in AGENTS.md §4).