# Playbook 17 — WebSocket, Realtime, HTTP Request Smuggling & Web Cache Attacks

> **Scope & safety reminder (read first):** This playbook contains two very
> different risk families. WebSocket/realtime testing on your **own two test
> accounts** is usually low-impact. HTTP request smuggling and cache poisoning
> are **shared-infrastructure** bugs: a single test can affect *other users'*
> requests. Many programs **explicitly prohibit** smuggling/cache-poisoning
> tests, or allow them only on staging. Check `templates/00-scope-intake.md`
> first: if the program does not clearly allow these techniques, **do not run
> them against the target** — study them in a local lab (PortSwigger Web
> Security Academy labs, your own Docker stack) and log them as research only.
> Every active test in §§6–7 is **Tier B** (ask the operator first, in the
> `core/02-approval-protocol.md` format). When in doubt, stop.

---

## 0. Prerequisites

Before using this playbook you should have:

- [ ] Completed scope intake (`templates/00-scope-intake.md`) — including the
      program's stance on smuggling, cache testing, and automated tools.
- [ ] Account A and Account B created and logged (AGENTS.md §2.7 two-account rule).
- [ ] Read `learning/04-web-and-http-from-zero.md` (HTTP request/response anatomy).
- [ ] A proxy you control for observation (e.g. Burp Suite Community / OWASP ZAP,
      portable install into `./tools/` = Tier A; running it against a target = Tier B).
- [ ] A local lab target you own for smuggling practice. Never "learn" smuggling
      on a production bounty target.
- [ ] Output templates ready: finding → `templates/03-finding-report.md`,
      chain primitive → `templates/10-chain-canvas.md`,
      posture → `templates/05-posture-analysis.md`,
      learning → `templates/06-learning-notes.md`.

---

## 1. First principles — why any of this exists

### 1.1 HTTP is just text (or frames) over a connection

A beginner model that is actually correct: your browser opens a TCP/TLS
connection and sends text like:

```
GET /profile HTTP/1.1
Host: example.com
Cookie: session=...
```

The server reads bytes until it decides "this request is complete", answers,
then reads the *next* request on the same connection (**keep-alive / connection
reuse**). Modern stacks are not one server — the request usually passes through
a chain:

```
Browser → CDN / cache → load balancer / reverse proxy (front-end)
        → application server (back-end) → database / internal services
```

Each hop must agree on **where one request ends and the next begins**. That
agreement is the entire smuggling problem (§5). Each hop that *stores*
responses to serve later is the entire cache problem (§7).

Key headers that decide request length in HTTP/1.1:

- `Content-Length: N` — "the body is exactly N bytes."
- `Transfer-Encoding: chunked` — "the body arrives in labelled chunks and ends
  with a `0`-sized chunk."

If both are present, or one is disguised, two servers in the chain can disagree.
Disagreement = one server leaves leftover bytes in the connection buffer, and
those bytes become the **start of the next victim's request**. That is request
smuggling in one sentence.

### 1.2 HTTP/2 changed the framing, not the risk

HTTP/2 is binary and uses explicit frame lengths, so classic CL.TE ambiguity
mostly disappears *inside* HTTP/2. The risk moves to **translation points**:
when a front-end speaks HTTP/2 to the browser but **downgrades** to HTTP/1.1
to talk to the back-end, it must convert headers into HTTP/1.1 text. If an
attacker-controlled HTTP/2 header value contains characters that become a
smuggled header or body in HTTP/1.1, the old bug returns through the new door.
You only need this *concept* to hunt safely; the lab is where you practise it.

### 1.3 Realtime is HTTP that never ends

- **WebSocket:** starts as a normal HTTP `GET` with `Upgrade: websocket`,
  the server replies `101 Switching Protocols`, and the connection becomes a
  bidirectional pipe of *messages* (frames). After the handshake, there are
  usually **no per-message HTTP headers** — so any authorisation the server
  checked only at handshake time can go stale.
- **Server-Sent Events (SSE):** a normal HTTP response that never finishes;
  the server pushes `data: ...` lines. One-way (server → client).
- **Socket.IO:** a library *on top of* WebSocket/polling with its own concepts:
  namespaces, rooms, events. "Room" membership is an access-control decision.
- **gRPC-web:** RPC calls tunnelled over HTTP from the browser to a proxy
  (e.g. Envoy) that translates to gRPC back-ends. Method names and protobuf
  payloads replace URLs/JSON, but the server must still check *who may call
  which method on which object* — the same BOLA problem in new clothes.

**The unifying invariant:** *Every message is a request. The server must
authenticate and authorise every message, not just the connection.*

---

## 2. Map the realtime surface (passive + own-session only)

1. Browse the app as Account A doing normal work. In your proxy/devtools note:
   - `wss://` / `ws://` URLs, SSE endpoints (`Content-Type: text/event-stream`),
     Socket.IO endpoints (`/socket.io/?EIO=...`), gRPC-web paths (`/package.Service/Method`).
   - The handshake request: what authenticates it? Cookie? `Authorization`
     header? Token in the URL query string? A ticket fetched from a REST call?
2. Record one full normal message flow per feature: sent message JSON, received
   messages, and which REST action (if any) mirrors it.
3. Check the boring, high-value facts:
   - Is `ws://` (cleartext) accepted anywhere, or only `wss://`?
   - Is the `Origin` header checked on the handshake? (If not, see CSWSH, §3.1.)
   - Does the handshake token expire? Does logout kill the socket?
   - Are messages documented anywhere (JS bundle, mobile app, public docs)?
     Mine the JS bundle for event names — event names *are* the API surface.
4. Write the surface into the target dossier (`templates/01-target-dossier.md`)
   and add hypotheses to `templates/02-hypothesis-backlog.md`.

> Tier note: steps 1–4 use only your own normal sessions = the observation is
> Tier A research. The moment you send a *crafted* message, that is Tier B.

---

## 3. WebSocket & realtime testing methodology

Work one hypothesis at a time. Baseline first: capture the legitimate message,
then change **exactly one thing**.

### 3.1 Cross-Site WebSocket Hijacking (CSWSH)

- **Idea:** if the handshake authenticates by cookie only and never checks
  `Origin`, any website the victim visits can open a socket *as the victim*
  (the browser helpfully attaches cookies) and read/write in their session.
- **Safe proof:** build a tiny local HTML page you control that opens the
  socket and displays messages **from your own Account A session only**.
  Screenshot the page receiving your own data. Never involve another person.
- **Fix to suggest:** check `Origin` against an allowlist on the handshake
  and/or require an unguessable, non-cookie token (CSRF-token equivalent).

### 3.2 Per-message authorisation (the #1 realtime bug class)

For **each** message type, test with the standard differentials:

| Test | How | Bug looks like |
|---|---|---|
| Cross-account object access | As B, send A's object/channel ID in a subscribe/read/send message | B receives or modifies A's data |
| Role escalation | As a low-role user, replay an admin-only message captured from docs/JS | Action succeeds |
| Channel/room join | Join a private room/channel ID you were never invited to (use A's room, from B) | B silently receives the stream |
| Field injection | Add fields the UI never sends: `role`, `user_id`, `price`, `tenant_id`, `is_admin` | Server trusts the client-supplied field (mass assignment over WS) |
| Identity spoofing | Change the `from`/`sender_id` field in a chat/support message | Message appears from another user or from "Support" |

- Socket.IO specifics: test namespace access (`/admin` namespace as a normal
  user), room joins by guessing/emitting `join` events with A's identifiers,
  and events found in the JS bundle that the UI for your role never exposes.
- SSE specifics: SSE is read-only, so hunt for **IDOR on the stream URL**
  (`/events?user_id=A` fetched as B) and for streams that leak other tenants'
  notifications because filtering happens client-side.
- gRPC-web specifics: enumerate method names from JS stubs; test each method
  for the same BOLA/field-level checks as REST (Playbook 03). Treat an
  unauthenticated metadata/header difference as a lead, not a finding.

### 3.3 Authentication lifecycle bugs

1. Open a socket as Account A. Then, in a normal browser tab: log out, change
   the password, or have an "admin" (your second test role) disable Account A.
2. Keep sending messages on the **old** socket. If they still work minutes
   later, the socket outlives the session — impact depends on what the socket
   can do; state it precisely, do not inflate.
3. Token-in-URL check: tokens in `wss://...?token=` leak via logs, proxies,
   and `Referer`-like paths. Note it as a hardening issue chained to impact,
   rarely a standalone report.

### 3.4 Message injection & second-order effects

- Send messages containing markup, template syntax, and oversized/oddly-typed
  values **to your own Account B inbox/view** and observe how B's client and
  any admin/support console render them. Stored XSS delivered over WS is still
  stored XSS — the socket is just the delivery van (see Playbook 13).
- Type confusion: send a string where the server expects a number/object/array
  (and vice versa). Crashes are *not* the goal — a 500 that reveals a stack
  trace or a skipped validation branch is the interesting result. Stop at the
  first anomaly; do not fuzz a production socket without explicit Tier B scope.
- Rate/ordering: realtime actions (bids, reactions, "claim" buttons) often skip
  the rate limits and race protections the REST twin has. Test gently, own
  accounts only, and cross-reference Playbook 05 (races/business logic).

### 3.5 Safe proof rules for realtime

- ✅ Prove with A ↔ B only. Your marker message, your marker object.
- ✅ One crafted message per hypothesis; capture request/response pair.
- ✅ For CSWSH, the victim is always *you* (your browser, your account).
- ❌ Never join real users' rooms/channels, never read a real stream of
  other people's events, never inject content a real user will see.
- ❌ No message flooding, no connection exhaustion, no "how many sockets can
  I open" tests — that is DoS, Tier C unless a program explicitly allows it.

---

## 4. Interlude — parser differentials, the mental model for §§5–7

A **parser differential** = two components read the same bytes and reach
different conclusions about meaning. Smuggling is a differential about
*request boundaries*. Cache poisoning is a differential about *"is this
response safe to store and reuse for someone else?"* Cache deception is a
differential about *"is this private page actually a static file?"*

Whenever you see a chain (CDN → proxy → app), ask three questions:

1. Which component decides the request length / the cache key / the file type?
2. Does the next component decide it the *same* way?
3. Can I control the input where they disagree?

Write your answers in the hypothesis backlog before sending anything active.

---

## 5. HTTP request smuggling — concepts & safe methodology

**⚠️ Highest-caution section in this pack.** Smuggling desynchronises a
*shared* connection pool: a malformed test can poison the next stranger's
request. Rules before technique:

- Confirm the program **explicitly** allows smuggling tests, on **which**
  assets (staging strongly preferred). Record the wording in the scope file.
- Use only the **timing-based, non-destructive detection** in Step 1 first.
- Use a dedicated test path/your own accounts for any confirmation; use the
  smallest payload that proves desync; **stop immediately** on proof.
- Never attempt to capture, redirect, or store another user's request.
  Proving "the back-end can be made to treat my leftover bytes as a prefix"
  using **only your own follow-up request** is the maximum proof needed.

### 5.1 The classic variants (know the names, recognise the shapes)

| Variant | Front-end honours | Back-end honours | Leftover becomes |
|---|---|---|---|
| **CL.TE** | `Content-Length` | `Transfer-Encoding` | Smuggled prefix |
| **TE.CL** | `Transfer-Encoding` | `Content-Length` | Smuggled prefix |
| **TE obfuscations** | one server ignores a disguised TE header | the other honours it | Same as above |

Common TE obfuscations that create disagreement (for *recognition* and lab
study): duplicate TE headers, whitespace/underscore variants
(`Transfer-Encoding :`, `Transfer_Encoding`), TE combined with other tokens,
vertical-tab/form-feed separators, TE in a folded/continuation line. The point
for a hunter is not memorising tricks — it is knowing *why* they work: one
parser is strict (RFC-shaped), the other is lenient (or vice versa).

### 5.2 Step-by-step (safe order — do not skip ahead)

1. **Fingerprint the chain (Tier A research).** Headers (`Via`, `Server`,
   CDN headers), error-page styles, and public tech docs. One server or two?
   Which CDN/proxy? Which app server? Log in the dossier.
2. **Timing-based detection (Tier B ask #1).** Specialised tooling (e.g. the
   well-known "HTTP Request Smuggler" Burp extension / `smuggler.py`-style
   scripts) sends *paired* probes designed so a vulnerable chain shows a
   measurable **delay** (the back-end waits for body bytes that never complete
   a request) while a healthy chain answers immediately. A delay differential
   is a *lead*, not a finding — it touches no other user's data.
3. **Harmless confirmation (Tier B ask #2, separate approval).** If timing
   suggests desync, confirm by smuggling a prefix that only affects **your
   own next request** (e.g. your follow-up request to a harmless path returns
   an anomalous status/redirect caused by your prefix). Capture both of your
   requests. Then stop. Do not escalate to victim interaction.
4. **HTTP/2 angle (conceptual on real targets, practical in lab).** If the
   edge accepts HTTP/2, note downgrade points (edge speaks h2, origin h1).
   Test only header-hygiene basics on real targets; full h2 smuggling
   experiments belong in your lab unless the program invites them.
5. **Write it up honestly.** Impact language: "an attacker positioned to send
   requests through the same front-end could desynchronise connections and
   potentially poison subsequent requests" — mark unproven escalation steps
   as *potential*, attach the timing/confirmation evidence you actually have.

### 5.3 Common false positives (smuggling)

- "Delay" caused by a slow endpoint, cold start, or rate limiting — re-run
  the control probe; a real desync differential is repeatable and probe-specific.
- Scanner "smuggling" alerts based on a single ambiguous response — never
  report tool output alone (AGENTS.md §6).
- WAF/CDN normalisation changing between your two probes (different edge node,
  different route). Pin down *which* host/path reproduces before claiming.
- Your proxy re-writing TE/CL between you and the target, creating the
  differential *in your own tooling*. Verify raw bytes at the wire level.

---

## 6. Web cache poisoning — methodology

**Idea:** if you can make the cache store a response containing *your* input
under a key that *other visitors* will be served, one request reaches everyone.

### 6.1 Concepts a beginner must own

- **Cache key:** the fields the cache uses to decide "same request" — usually
  method + host + path (+ sometimes selected headers/cookies/query params).
- **Unkeyed input:** anything that changes the *response* but is **not** in
  the cache key (classic examples: `X-Forwarded-Host`, `X-Original-URL`,
  odd headers, certain query params). Unkeyed input reflected in the response
  is the poisoning primitive.
- **Cache buster:** a unique query string (e.g. `?cb=random123`) you add so
  your experiments poison only *your unique URL variant*, never the real
  page real users load. **This is mandatory safety technique, not a nicety.**

### 6.2 Step-by-step

1. **Find cacheable responses (own browsing).** Look for `Age`,
   `X-Cache: HIT`, `CF-Cache-Status`, `Cache-Control` headers; re-request a
   static-looking asset and watch `Age` increase.
2. **Map the key (Tier B).** With a cache buster on your test URL, vary one
   input at a time (header, cookie, param) and see what changes the stored
   response vs. what creates a separate entry.
3. **Hunt unkeyed reflection.** Send a harmless unique marker via a candidate
   unkeyed header; fetch the URL *without* that header (fresh client, still
   with your buster); if your marker is served back, you have a poisoning
   primitive **on your busted URL only**.
4. **Assess real impact without causing it.** Impact = (is the *real*,
   unbusted URL keyed the same way?) × (is the reflected marker capable of
   harm — e.g. injected into a script URL, a redirect, or HTML?). Reason it
   in the report; do **not** poison the real URL to "prove" reach.
5. **Parameter cloaking / fat GET / delimiter tricks** — study in the lab;
   on real targets limit yourself to the marker method in Step 3.

### 6.3 Safe proof rules (cache)

- ✅ Cache buster on **every** experimental request. No exceptions.
- ✅ Marker = unique nonsense string, never executable script on a shared URL.
- ✅ Purge/expire awareness: note the TTL; tell the operator if your busted
  entry could linger and how it is keyed so it cannot affect real users.
- ❌ Never poison a production URL other users load. Never store XSS for
  real visitors. That crosses from research into harming third parties (Tier C).

---

## 7. Web cache deception — methodology

**Idea (the mirror image):** trick the cache into storing *your private page*
as if it were a public static file, then read it back unauthenticated.

- Classic shape: `/account/profile` is private, but
  `/account/profile/nonexistent.css` (or `;foo.css`, `%0a`-style delimiters)
  makes the *cache* see "static file → cache it" while the *app* still
  renders the private page.
- **Safe proof:** use **Account A's own private-but-harmless page** (a profile
  field containing a unique marker you set). Request the deceptive URL as A,
  then request the same URL **logged out**. If your marker is served
  unauthenticated from cache, proof is complete — with your data only.
- ❌ Never attempt this against a URL pattern that would expose another
  user's page. Your own marker page is the only permitted victim.
- Fix to suggest: cache by content type/auth state, never cache responses
  with `Set-Cookie`/authenticated content, honour `Cache-Control: private,
  no-store` on account pages at the CDN layer too.

---

## 8. Common false positives (realtime + cache, general)

- WebSocket "no auth" that is actually a public, unauthenticated-by-design
  feed containing no private data — check the *data*, not just the handshake.
- CORS-style panic on WS: a missing `Origin` check is only CSWSH if cookie
  auth is ambient *and* the socket exposes sensitive read/write capability.
- Cache headers present but `Vary`/keying actually correct; your "poisoning"
  only ever served your own busted variant back to you.
- SSE/WS disconnect/reconnect quirks mistaken for auth bypass — re-test after
  a full token expiry window before claiming a lifecycle bug.
- Smuggling timing noise (§5.3). When the differential is not reproducible
  three times in a row, the verdict is *Speculative*, not *Confirmed*.

---

## 9. Detection & SOC lens

Ask for every test: *what would the defender see?* (See `learning/05-soc-lens.md`.)

- **Realtime:** handshake logs without per-message audit trails are the norm —
  recommend: log message type + actor + object ID (not payloads), alert on
  cross-tenant room joins, impossible message rates, and admin-event names
  from non-admin roles. A socket that stays valid after password change should
  page someone in a mature SOC.
- **Smuggling:** front-end vs back-end request-count mismatches, TE/CL anomaly
  alerts, and 400/501 spikes at the back-end are the classic tells. Most CDNs
  emit parse-error telemetry that nobody alerts on — note that gap in the
  posture analysis.
- **Cache:** alert on sudden `Age`/HIT-ratio changes for dynamic paths,
  cache entries created for responses containing `Set-Cookie`, and unkeyed-
  header reflection seen in WAF logs.
- In `templates/05-posture-analysis.md`, always add 2–3 concrete detection
  ideas for the class you tested, even for a negative result.

---

## 10. Learning path (do these in order)

1. `learning/04-web-and-http-from-zero.md` — HTTP anatomy, headers, keep-alive.
2. `learning/03-networking-from-zero.md` — TCP connections, why reuse exists.
3. `learning/05-soc-lens.md` — how proxy/CDN logs become detections.
4. Lab (Tier A, local only): PortSwigger Web Security Academy — WebSocket,
   request smuggling, and cache poisoning lab tracks, in that order.
5. After any finding here: complete `templates/06-learning-notes.md` with
   3 self-check questions (e.g. "In CL.TE, which server reads which header,
   and where do the leftover bytes go?") and 3–5 flashcards
   (`checklists/learning-retention.md`).

## 11. Outputs for this playbook

- Finding (any family) → `templates/03-finding-report.md`
  (platform variant: `templates/04-platform-report-variants.md`).
- A primitive that is real but not yet impactful (e.g. CSWSH needing a
  delivery page, unkeyed reflection without a harmful sink) →
  `templates/10-chain-canvas.md` + hand off to Playbook 20.
- Always → `templates/05-posture-analysis.md` + `templates/06-learning-notes.md`.
- Smuggling/cache work additionally requires: the program's permission wording
  quoted in the scope file, and your cache-buster/timing evidence in the
  append-only `evidence-log.md`.
