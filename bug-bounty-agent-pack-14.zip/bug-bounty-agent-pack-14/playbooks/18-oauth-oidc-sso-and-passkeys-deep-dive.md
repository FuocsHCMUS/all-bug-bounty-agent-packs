# Playbook 18 — OAuth 2.0, OpenID Connect, SSO/SAML & Passkeys Deep Dive

> **Scope reminder:** Identity bugs are account-takeover bugs. Test **only**
> with Account A and Account B, both owned by the operator, plus identity
> providers (IdPs) you control (your own Google/Microsoft test accounts, a
> free-tier Okta/Auth0 developer tenant you created, or a local mock IdP).
> Never link, unlink, or hijack a real person's account. Never complete a
> login flow as a stranger. Any active flow manipulation is **Tier B**
> (ask first, `core/02-approval-protocol.md` format). Capturing your own
> normal login flows through your proxy for study is Tier A research.
> If a flow involves a third-party IdP that is **not** in scope, you may
> study *your side* of the integration only — the IdP itself is not a target.

---

## 0. Prerequisites

- [ ] Scope intake done (`templates/00-scope-intake.md`); identity providers,
      social-login options, and enterprise SSO listed as in/out of scope.
- [ ] Account A and Account B at the target, each with a **distinct** email
      at an IdP you control (e.g. `you+a@example.com`, `you+b@example.com`).
- [ ] At least two browser profiles / containers so A's and B's sessions
      never bleed into each other. Most false positives in this playbook are
      "I was already logged in as the other account."
- [ ] Proxy logging on for your own sessions; a scratch folder for flow maps.
- [ ] Read first: `learning/04-web-and-http-from-zero.md` (redirects, cookies),
      and §1 below before touching any parameter.
- [ ] Output templates: flow map working notes in the target dossier
      (`templates/01-target-dossier.md`), finding →
      `templates/03-finding-report.md`, posture →
      `templates/05-posture-analysis.md`, learning →
      `templates/06-learning-notes.md`, chain primitive →
      `templates/10-chain-canvas.md`.

---

## 1. First principles — tokens, trust, and "who says you are you?"

### 1.1 Authentication vs authorisation (never blur these)

- **Authentication (authN):** *Who are you?* — password, passkey, IdP login.
- **Authorisation (authZ):** *What may you do?* — roles, scopes, ownership.

OAuth 2.0 is, strictly, an **authorisation** framework: it lets a client get
limited permission to act. OpenID Connect (OIDC) adds the missing
**authentication** layer on top. Half the bugs in this playbook are a system
treating an authorisation artefact as if it proved identity — or vice versa.

### 1.2 The four actors (draw them for every flow)

1. **Resource Owner** — the user (Account A).
2. **Client** — the app asking for access (the target's web/mobile app).
3. **Authorisation Server / Identity Provider (IdP)** — Google, Microsoft,
   Okta, the target's own auth service. It *authenticates* the user and
   *issues* tokens.
4. **Resource Server** — the API that accepts tokens and serves data.

**Trust rule:** a token is only as trustworthy as (a) who issued it,
(b) who it was issued *to* (audience), and (c) proof the presenter is its
rightful holder. Every check you will test in §3 is one of those three.

### 1.3 The token zoo (know what each object *is*)

| Artefact | What it is | Beginner analogy | Must be checked |
|---|---|---|---|
| Authorisation `code` | Short-lived, single-use ticket from the IdP, delivered via redirect | Coat-check ticket | Single-use, expires fast, bound to the client + redirect URI + PKCE verifier |
| `access_token` | Bearer token for the API. Whoever holds it, uses it | Cash | Expiry, scope, audience; treat leaks as compromise |
| `refresh_token` | Long-lived token that mints new access tokens | The safe-deposit key | Rotation, revocation on logout/password change, binding |
| `id_token` (OIDC) | A **JWT**: header.payload.signature, signed by the IdP, stating *who logged in* | A sealed, signed letter | Signature, `iss`, `aud`, `exp`, `nonce` (see §4) |
| `state` (OAuth param) | Random value the client generates before redirecting away, verified on return | A nonce that defeats login CSRF | Present, random, verified, tied to the session |
| `nonce` (OIDC param) | Random value bound into the `id_token` | Same idea, inside the token | Client sent it *and* verifies it matches the token claim |
| PKCE `code_verifier` / `code_challenge` | A secret the client keeps; only its hash travels in the first leg | A password split in two halves | Challenge sent first, verifier required at token exchange, `S256` not `plain` |

### 1.4 Why redirects are the dangerous part

OAuth moves the user **browser → IdP → browser → client callback**. Data
(`code`, sometimes tokens) travels through URLs — visible in history, logs,
and `Referer` headers, and steerable if the callback address is not strictly
controlled. That is why `redirect_uri` validation (§3.2) is historically the
single highest-yield check in this entire playbook.

### 1.5 JWT in 60 seconds (enough to test `id_token`s)

A JWT is `base64(header).base64(payload).signature`. Anyone can *read* the
payload — it is encoded, not encrypted. Trust comes only from **verifying
the signature** with the IdP's public keys (`jwks_uri` from discovery) and
checking the claims. Classic failures: accepting `alg: none`, accepting a
token signed with a different key/algorithm than expected, never checking
`aud` (so a token minted for *another app* works here), never checking `exp`.
Full method: Playbook 04 §auth + §4 below. Never brute-force signing keys on
a real target — algorithm/audience confusion with **tokens you legitimately
own** is the in-scope test.

---

## 2. Map the identity surface first (passive, own accounts)

Do this before altering a single parameter. Identity bugs are **sequence**
bugs; you cannot see them one request at a time (AGENTS.md §6, v20).

1. **Inventory every way in:** password login, each social button, "Continue
   with SSO", magic links, passkeys, API keys, mobile login. Note them in
   the dossier with the IdP and tenant for each.
2. **Capture one clean flow per method** (A only): the full redirect chain,
   every parameter, every cookie set, the callback, the token call (if
   visible), and the first authenticated request. Save as your *baseline*.
3. **Fetch the public discovery documents** (read-only, Tier A):
   `/.well-known/openid-configuration` on the IdP/issuer, and the target's
   own if it *is* an issuer. Record: `issuer`, `authorization_endpoint`,
   `token_endpoint`, `jwks_uri`, `userinfo_endpoint`, supported grants,
   `scopes_supported`, PKCE methods (`code_challenge_methods_supported`).
4. **Draw the flow map** in the dossier: actors, order, what each step
   carries, where `state`/`nonce`/PKCE appear (or don't). Gaps in the
   drawing are your hypothesis list.
5. **Account-linking map:** where can an identity be attached/detached
   (settings → connected accounts, "link Google", invite-accept flows,
   email-change flow)? Linking is where separate safe flows combine into
   takeover (§6).

---

## 3. OAuth 2.0 testing methodology

Work flow-by-flow. Baseline → change **one** parameter → complete (or abort)
the flow as A/B → record the result. Keep a two-column log: *change* / *effect*.

### 3.1 Flow identification & legacy flows

- Which flow is it? **Authorisation code** (code in callback, exchanged
  back-channel) is the modern default. **Implicit** (tokens directly in the
  callback fragment) and **hybrid** variants are legacy — still found,
  especially in old SPA/mobile integrations. Note any flow delivering an
  `access_token` in a URL as a hardening finding on its own.
- Can you *force* a weaker flow? Parameters like `response_type=token` or
  `response_type=id_token` accepted when the app normally uses `code` =
  flow-downgrade hypothesis. Test with your own account only.
- Mobile/deep-link variant: does the app register a custom scheme
  (`app://callback`) that **any** installed app could also claim? Record as
  a design note; hands-on proof belongs to Playbook 10 (mobile).

### 3.2 `redirect_uri` validation — test exhaustively, prove minimally

The IdP (and the client, for its own callbacks) must match `redirect_uri`
**exactly** against a pre-registered list. Try, one at a time, against your
own login:

1. Completely different origin you control (`https://your-marker.example`) —
   if a `code` lands there, that alone is the finding. Stop; do not redeem
   anyone else's code (you only ever have your own).
2. Subdomain tricks: unregistered subdomain of an allowed host, allowed host
   as a subdomain of yours (`allowed.example.your-marker.example`).
3. Path tricks on an allowed origin: `../` traversal, trailing slash,
   missing/extra path segment, open-redirect-on-the-allowed-origin chained
   onward (note as a chain: open redirect + OAuth, see Playbook 20).
4. Parameter/fragment tricks: extra query params, `//` protocol-relative
   values, `@` userinfo confusion (`https://allowed@attacker`), backslashes,
   URL-encoding and case variations the validator might normalise differently
   than the browser does (parser differential — Playbook 17 §4 model).
5. `localhost`/private values accepted in production (leftover dev URIs).

**Safe proof:** a screenshot/log showing *your own* authorisation code (or a
harmless `state`-only error response) delivered to a redirect target you
control. Redact the code value. That is complete proof — nothing further.

### 3.3 `state`, login CSRF & session fixation

- **Missing/unverified `state`:** start a flow in Browser-B context, capture
  the callback URL, and (in your second profile, logged in as *you*) see if
  visiting it binds/logs-in the wrong session. This is **login CSRF**: the
  victim ends up logged in *as the attacker*. Prove only A↔B (B ends up in
  A's account in B's browser profile). Never involve a third person.
- **Predictable/static `state`:** same value across flows/users = broken,
  even if "checked". Record two baselines as evidence.
- **Session not rotated:** session cookie identical before login and after
  the callback = session-fixation surface; note with the `state` results.

### 3.4 PKCE

- Is a `code_challenge` sent on the authorise leg? Is `code_challenge_method`
  `S256` (good) or `plain` / absent (weak)?
- At the token exchange (where you can observe/replay your **own** exchange):
  is the exchange accepted **without** `code_verifier`, or with a *wrong*
  verifier? Either = PKCE not enforced server-side, i.e. decorative.
- Is the challenge bound to the same browser session that started the flow,
  or can A's code + B's verifier mix? Cross-session mixing is the bug.

### 3.5 Code & token lifecycle

- **Code replay:** redeem your own code **twice**. Second redemption must
  fail. If it succeeds, check whether the second redemption also revokes /
  still issues fresh tokens — and stop there.
- **Code mixing:** A's code presented with B's client credentials / from B's
  session. Must fail.
- **Expiry:** keep your own code 10–15 minutes, then redeem. Must fail.
- **Refresh-token rotation & revocation:** refresh once (old token must die
  if rotation is claimed), then log out / change password and try the
  surviving refresh token. A refresh token that survives a password change
  is a persistence bug — high value, prove with your own account only.
- **Scope escalation:** at exchange or refresh, request a scope you were
  not granted (`scope=admin`, another API's scope). Granted > requested is
  a finding; an error is the healthy baseline.
- **Token audience confusion:** if the same IdP serves several in-scope
  apps, does App 1's access token work at App 2's API? (Both must be in
  scope; otherwise stop and report the *observation* only.)

### 3.6 Client-side storage & leakage (bridge to Playbook 13)

- Tokens in `localStorage`/`sessionStorage` (readable by any XSS) vs
  `HttpOnly` cookies; tokens in URLs (history/logs/`Referer`); verbose
  callback error pages echoing codes. Each is a *multiplier*, reported
  chained to impact or as hardening — not inflated standalone.

---

## 4. OIDC-specific checks

1. **`id_token` claim validation** — using tokens issued to **you**, test
   whether the client accepts a token when you can legitimately produce a
   variant (e.g. via your own developer IdP tenant configured as a login
   option): wrong `aud` (token for a different client), wrong `iss`
   (look-alike issuer), expired `exp`, mismatched `nonce`. A client that
   accepts a foreign-issuer token you minted in your own tenant is a
   critical, cleanly provable finding — and the *only* safe way to test
   signature/claim handling. **Never** forge tokens against an IdP you do
   not control beyond replaying your own unmodified/claim-variant tokens.
2. **`nonce` absent or unverified:** start two flows; swap the callbacks.
   If the client accepts the `id_token` from flow 1 in flow 2's session,
   the replay protection is missing.
3. **Discovery trust:** does the client fetch discovery/JWKS from a URL the
   attacker can influence (e.g. issuer taken from a user-supplied "enter
   your workspace domain" field)? Issuer-by-input = federation confusion (§5).
4. **`userinfo` vs `id_token` mismatch:** profile claims taken from an
   endpoint that returns data for a *different* subject than the token's
   `sub` (test only across A/B). The `sub` claim — not email — is the
   stable identity key; flag any app keying accounts by **unverified email**
   (feeds §6).

---

## 5. SSO, SAML & tenant confusion

### 5.1 Mental model in one paragraph

In enterprise SSO the **tenant** (company workspace) asserts "this person
belongs to us" via its IdP, and the app must check *both* "is this assertion
valid?" *and* "is this IdP the IdP **for this tenant**?" Confusion bugs live
in the second check: any-tenant IdP accepted for every tenant, domain-based
routing that trusts the email domain without verifying IdP ownership, or
just-in-time (JIT) provisioning that creates accounts in the *wrong* tenant.

### 5.2 SAML checks (when SAML is in scope)

- Capture your own SAML response (it is XML + a signature over assertions).
  Concepts to verify from the outside, with your own tenant/IdP only:
  unsigned or partially-signed assertions accepted? `AudienceRestriction`
  ignored (assertion minted for another service accepted here)? Assertion
  replay (same assertion submitted twice / after expiry)? XML Signature
  Wrapping is a **lab technique** — study it locally; on a real target limit
  yourself to replay/audience/expiry differentials you can produce with your
  own IdP tenant, Tier B, one submission each.
- NameID by email + email change at the IdP = account confusion; map it,
  prove only A↔B if both sides are yours.

### 5.3 Tenant-confusion test matrix

| Question | Safe test (all identities yours) |
|---|---|
| Can Tenant-1's IdP log me into Tenant-2? | Your dev IdP configured for workspace A; attempt SSO entry to workspace B |
| Is routing by email domain alone? | B's email domain typed at A's SSO start; observe which IdP/tenant is selected |
| Does JIT provisioning land in the right tenant? | First-ever SSO login with your IdP user; record which workspace the account was created in |
| Does an invite bypass SSO enforcement? | Invite B by email into an SSO-enforced workspace; can B set a password and skip SSO? |
| Is SCIM/deprovisioning honoured? | Disable your user at your IdP; does the target session/access actually end? |

### 5.4 SSO enforcement bypasses (very high yield)

- Password login still enabled after "SSO required" is switched on.
- API/mobile login paths that never got the SSO rule.
- Password-reset flow that quietly re-enables password auth for an SSO user.
- "Backdoor" admin/local accounts created during migration. Observe and
  reason; test only paths reachable with your own tenant admin test account.

---

## 6. Account linking & takeover chains

Linking bugs turn a *low* bug into **account takeover (ATO)**. Map every
link/unlink/change operation, then test:

1. **Link without re-authentication:** can a session link an IdP identity
   without password/passkey confirmation? Combined with *any* session-level
   bug (XSS, CSRF), that is persistent ATO. Prove A-only: link your second
   IdP identity to A with no re-auth prompt; report the missing step-up.
2. **Linking collision:** link IdP-identity-X to A, then try to link the
   *same* identity to B. The system must refuse or safely transfer — silently
   attaching X to both, or moving it without warning, is the bug.
3. **Pre-account takeover (pre-hijacking):** create a target account with
   B's email *before* B ever signs up; later B signs up via SSO with that
   email. Does B inherit your pre-created account (with your password still
   valid / your recovery email still attached)? Both accounts are yours;
   the sequence is the proof.
4. **Unverified-email merging:** sign up with password using an email you
   have **not** verified, then SSO-login with the same email verified at
   the IdP. Auto-merge = the unverified side may have pre-claimed the account.
5. **Email-change → identity drift:** change email on A to B's email (or to
   an IdP email), then SSO as B. Watch which account you land in.
6. **Dangerous unlink:** unlinking the *last* login method, or unlinking
   without re-auth, locking out or orphaning accounts — report as integrity/
   availability impact, honestly scoped.

Record every chain on `templates/10-chain-canvas.md` and escalate via
Playbook 20. A linking bug with no reachable trigger is a primitive, not a
critical — say so.

---

## 7. WebAuthn / passkeys — testing boundaries

### 7.1 The ceremony, from first principles

Passkeys replace "something you know" with "something you hold that can
sign". Two ceremonies, both challenge–response:

- **Registration:** server sends a random **challenge** + user info →
  authenticator creates a key pair → the **private key never leaves** the
  device/secure enclave → server stores the **public key** + credential ID.
- **Authentication:** server sends a fresh challenge → authenticator signs
  it → server verifies the signature with the stored public key, checks the
  challenge matches, the **origin (RP ID)** matches, and the signature
  counter/behaviour is sane.

Because the credential is bound to the RP ID (domain), a passkey for
`example.com` cannot be replayed at `evil-example.com` — phishing resistance
is *structural*, which is why your tests target the **server's checks and
the flows around the ceremony**, not the cryptography.

### 7.2 What to test (server-side logic only)

- **Challenge hygiene:** challenge reused across attempts? Predictable?
  Accepted after long expiry? Accepted for the *other* ceremony or the
  other account's session?
- **Session binding:** start registration in A's session, finish it with a
  response generated in B's context (both yours) — must fail.
- **Origin/RP checks:** responses generated for a subdomain or look-alike
  RP ID accepted by the production RP? (Only with credentials you own on
  test origins you control.)
- **Step-up gaps:** passkey *enrolment* or *deletion* without existing
  strong auth = enrol-your-key persistence. Can a password-only session add
  a passkey? Can it *remove* the victim-side protections (here: A/B only)?
- **Fallback honesty:** "passkey required" accounts that still fall back to
  a 6-digit email code with no rate limit have the *code's* security, not
  the passkey's. Assess the fallback, not the headline.
- **Account recovery:** recovery flows are the soft underbelly of passkey
  deployments — map them fully (Playbook 04 applies).
- **Cross-device / synced passkeys & attestation:** note whether attestation
  is required/verified; absence is usually an accepted design choice, not a
  finding — do not report "no attestation" as a vulnerability.

### 7.3 Hard boundaries (do not cross)

- ❌ No attacks on authenticators, platform key stores, or other people's
  devices; no extracting or cloning credentials. Ever.
- ❌ No social engineering a "passkey prompt" onto a real user.
- ❌ Do not claim crypto breaks. Your findings will be *logic* findings:
  challenge, binding, enrolment, fallback, recovery. That is where the
  real-world bugs are, and it is plenty.

---

## 8. Safe proof rules (whole playbook)

- ✅ A↔B only; every IdP identity involved is yours; clean browser profiles.
- ✅ Redact codes/tokens in evidence (show structure: first/last 4 chars,
  claims with values masked) — a full live token in a report is a leak.
- ✅ One altered parameter per run; complete the flow; log the outcome.
- ✅ For ATO claims, the proof screenshot is: *B's browser session operating
  A's account* (or vice versa), with account-identifying markers you set
  beforehand (display name "TEST-A-MARKER").
- ❌ Never redeem, store, or forward a code/token that is not yours.
- ❌ No credential stuffing, no password spraying, no IdP brute force.
- ❌ Do not disable your own MFA and then claim the target "has no MFA" —
  distinguish *your settings* from *system enforcement* honestly.

---

## 9. Common false positives

- "Missing `state`" where the client uses PKCE + a server-side session-bound
  transaction and genuinely is not login-CSRF-able — attempt the §3.3 swap
  before claiming; an absent parameter with a compensating control is at
  most an informational hardening note.
- Redirect-URI "bypass" that lands on an error page **without** a code/token
  and without leaking `Referer` — no artefact delivered, no finding.
- Your browser was still logged in at the IdP as the other test account —
  the #1 source of fake "tenant confusion". Re-run in fresh profiles.
- `id_token` accepted past `exp` in a *clock-skew* window of a minute or
  two — standard leeway, not a bug. Test with genuinely stale tokens.
- Social-login account merge that is **documented, verified-email-only**
  behaviour — read the product docs before reporting intended design.
- Passkey "bypass" that is actually the documented password fallback working
  as configured for *your* account tier.

---

## 10. Detection & SOC lens

Identity telemetry is the richest in any SOC — ask what the target's would show
(see `learning/05-soc-lens.md`):

- Log and alert on: code redemption from a different IP/session than issuance,
  refresh-token reuse (theft signal — reuse of a rotated token should kill
  the whole token family), `redirect_uri` mismatch errors in bursts,
  SSO logins where IdP tenant ≠ workspace tenant, passkey enrolment events
  (rare, high-signal — alert on enrolment + immediate sensitive action).
- A mature IdP integration surfaces `amr`/`acr` claims (how the user
  authenticated). Note in posture whether step-up (passkey/MFA) is *verified*
  for sensitive actions or merely *assumed* from login time.
- Detection ideas to write into `templates/05-posture-analysis.md`:
  (1) alert on one `sub` authenticating via two different IdPs in 24h after
  a linking change; (2) alert on refresh-token use after password change;
  (3) dashboard of failed `state`/`nonce` validations — near-zero in health,
  spiky under attack.

---

## 11. Learning path

1. `learning/04-web-and-http-from-zero.md` — redirects, cookies, sessions.
2. Rebuild one flow by hand: perform a code+PKCE login in your proxy and
   label all 9 steps in the dossier before re-reading §3.
3. Lab: PortSwigger Academy OAuth labs; a free developer IdP tenant with
   two test apps for §4 audience/issuer experiments (all yours, Tier A).
4. `learning/05-soc-lens.md` — identity logs and detection thinking.
5. After any finding: `templates/06-learning-notes.md` with self-checks
   such as "Explain, without notes: what does PKCE stop, and what does it
   *not* stop?" plus 3–5 flashcards (`checklists/learning-retention.md`).

## 12. Outputs for this playbook

- Any confirmed flow bug → `templates/03-finding-report.md`
  (or `templates/04-platform-report-variants.md` for platform taxonomies —
  Bugcrowd VRT has explicit OAuth/SSO categories; use them).
- Flow maps & baselines → target dossier (`templates/01-target-dossier.md`).
- Primitives awaiting a trigger (link-without-reauth, weak fallback) →
  `templates/10-chain-canvas.md` → Playbook 20.
- Always → `templates/05-posture-analysis.md` + `templates/06-learning-notes.md`.
