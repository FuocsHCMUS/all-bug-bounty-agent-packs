# Playbook 19 — Serverless, Edge & Modern Infrastructure

> **Scope reminder:** Modern infra blurs the line between "the app" and "the
> cloud account behind it". In bug bounty, **only the assets the program
> lists are in scope** — a cloud bucket, function URL, or CI artefact that
> merely *looks* like it belongs to the company is out of scope until the
> program says otherwise. Record every infra asset in
> `templates/00-scope-intake.md` before testing it. Research in this playbook
> (reading public docs, public repos, exposed-file *observations* from your
> own in-scope requests) is Tier A. Any active probing of infra endpoints is
> **Tier B**. Never use a discovered credential, never enter a cloud console,
> never call cloud metadata or management APIs beyond the single in-scope
> proof described in §7 — leaked-credential *use* is a line most programs
> draw at "report it, don't use it". When in doubt: screenshot, redact, stop.

---

## 0. Prerequisites

- [ ] Scope intake done, with infra assets explicitly listed: domains,
      function URLs, storage buckets, CDN distributions, repos — each marked
      in-scope / out-of-scope / unknown. Unknown = do not test.
- [ ] Account A and Account B ready (most infra bugs still prove as A-vs-B
      data access in the end).
- [ ] Read first: Playbook 09 (cloud & infra / SSRF), Playbook 01 (recon),
      `learning/03-networking-from-zero.md`, `learning/04-web-and-http-from-zero.md`.
- [ ] A notes page in the target dossier (`templates/01-target-dossier.md`)
      for the infra map in §2, and `templates/02-hypothesis-backlog.md`.
- [ ] Output templates: finding → `templates/03-finding-report.md`,
      CVE/config match → `templates/07-cve-match.md`, posture →
      `templates/05-posture-analysis.md`, learning →
      `templates/06-learning-notes.md`, primitive → `templates/10-chain-canvas.md`.

---

## 1. First principles — what changed when servers disappeared

### 1.1 The beginner model

Old model: a company rents a computer (a server), it runs all day, your
request arrives, code runs, answer returns. New model, piece by piece:

- **Serverless function** (AWS Lambda, Azure Functions, Google Cloud
  Functions/Run, Vercel/Netlify Functions): no always-on server. The provider
  keeps your code on a shelf; when an **event** happens (an HTTP request, a
  file uploaded, a timer, a queue message), it spins up a small container,
  runs *one function*, then freezes or destroys it. You pay per run.
  **Security consequence:** the unit of security is no longer "the server".
  It is **function + trigger + identity (IAM role) + environment** — exactly
  the AGENTS.md §6 v20 rule. Two functions in the same app can have wildly
  different power.
- **Edge worker / CDN function** (Cloudflare Workers, Lambda@Edge,
  Fastly Compute, Vercel Edge): code that runs in the CDN's data centres,
  *before* the request reaches the origin — rewriting URLs, checking tokens,
  serving cached/custom responses. **Consequence:** security checks may live
  at the edge, in the origin, in both, or — in the buggy case — in neither,
  because each team assumed the other layer checked.
- **API gateway:** the front desk for functions: routes paths to functions,
  (sometimes) checks API keys/JWTs, rate-limits. Gateway authorisation and
  function authorisation are separate decisions that must agree.
- **Object storage** (S3, GCS, Azure Blob): files in "buckets/containers"
  addressed by URL, with their own permission system (bucket policies, ACLs,
  signed URLs) that is **independent of the app's login system**. The classic
  bug class of this whole era lives in that independence.
- **Infrastructure as Code (IaC):** the infra is *described in files*
  (Terraform, CloudFormation, Pulumi, SAM, `serverless.yml`, GitHub Actions
  workflows). Whoever can read the files can read the architecture — and
  sometimes the mistakes — without sending a single packet.
- **CI/CD:** the pipeline (GitHub Actions, GitLab CI, etc.) that builds and
  deploys code, holding the most powerful credentials in the company (cloud
  keys, deploy tokens) while executing code influenced by pull requests.

### 1.2 The five questions that replace "what server is it?"

For every modern-infra surface, ask:

1. **What triggers it?** (HTTP? upload? queue? schedule? webhook?)
2. **What identity does it run as?** (IAM role / service account — what else
   could that identity do if the function were tricked?)
3. **What does it trust?** (headers the gateway was supposed to strip?
   filenames? event fields? environment variables?)
4. **What state does it share?** (`/tmp`, global variables, caches — serverless
   containers are *reused* across invocations, sometimes across users.)
5. **What does it leak?** (errors, timing, headers, source maps, public files?)

Write the answers in the dossier. Unanswered questions are hypotheses.

### 1.3 IAM in 30 seconds (enough to reason, not to administer)

Cloud **IAM** (Identity & Access Management) decides which identity may do
which action on which resource. A function gets a **role**: a bundle of
permissions. The decade-long pattern: a function that only needs "read one
bucket" gets "read/write *all* storage" because it was faster to grant.
You never need to *use* excess privilege to report it — you need evidence
the *path* to it exists (see §7 safe validation).

---

## 2. Build the infra map (passive first)

1. **Fingerprint the delivery chain** from your own normal browsing:
   response headers (`Server`, `X-Amz-*`, `X-Vercel-*`, `CF-Ray`,
   `X-Azure-*`, `X-Goog-*`), error pages, and `scripts/headers_check.py` /
   `scripts/tech_fingerprint.py` output (Tier A offline analysis; running
   them against a target is Tier B per AGENTS.md §4).
2. **Inventory function-style URLs:** `*.lambda-url.*`, `*.cloudfunctions.net`,
   `*.azurewebsites.net`, `*.vercel.app`, `*.netlify.app`,
   `*.workers.dev`, API-gateway hostnames — **then check each against the
   scope file**. Dev/staging deployments of the same code are famous bug
   sources *and* famous scope traps; if it is not listed, it is not yours.
3. **Map storage the app itself reveals:** image/file URLs in pages and API
   responses point at buckets. Record bucket name, region/host, path style,
   and whether URLs are signed (query params like `X-Amz-Signature`,
   `Signature=`, expiry timestamps) or plain.
4. **Read the public paper trail (Tier A):** company engineering blogs,
   public GitHub org, status pages, job ads (stack hints), docs. Note IaC
   and workflow files **only in public repos** (see §6 boundaries).
5. **Draw it:** browser → CDN/edge → gateway → function → storage/DB/queue,
   with the identity at each hop. This drawing *is* your threat model input
   (`templates/12-threat-model.md`).

---

## 3. Serverless function testing methodology

One function, one hypothesis at a time. Baseline with a normal request first.

### 3.1 Trigger confusion & event injection

- Functions triggered by **non-HTTP events** (uploads, queues, webhooks)
  often validate less than HTTP endpoints, because "only our system sends
  those events". If you can influence an event field through a normal
  in-scope feature (a filename, a profile field, a webhook payload from a
  service you control), you may control input a privileged function trusts.
  Test with marker values in your own objects only; watch your own results.
- **Filename/path as code path:** upload processors that build shell commands,
  storage keys, or extraction paths from filenames → test traversal sequences
  and odd extensions on **your own uploads** (Playbook 02/09 overlap).
- **Webhook receivers running as functions:** signature verification present?
  Replay of your own webhook event accepted twice? Cross-reference
  Playbook 03 (API) and Playbook 05 (business logic / races).

### 3.2 Cold start, warm reuse & shared state

- A reused ("warm") container keeps global variables and `/tmp` between
  invocations. Bugs: per-user data cached in a global and served to the next
  user; temp files with predictable names colliding across users.
- Safe test: as A, cause a distinctive marker value to be processed; as B,
  immediately request the analogous operation and look for A's marker in
  B's output. Marker only, own accounts only. A single crossover is proof;
  do not repeat at scale.

### 3.3 Environment & error leakage

- Verbose errors revealing environment variable *names*, file paths,
  framework debug pages, stack traces with cloud ARNs/account IDs.
- Deliberately malformed input (wrong content type, missing field) on **your
  own** requests is the gentle way to trigger error paths — one request per
  hypothesis, no fuzzing loops without a Tier B plan.
- If a response ever contains an actual secret value: stop, redact in notes,
  record only its type/length/prefix pattern, and escalate to the operator
  immediately (AGENTS.md §2.3). Do not test whether it "works".

### 3.4 Function-level authorisation gaps

- Gateway checks a JWT, but the **function URL itself** (direct invoke URL)
  is public and checks nothing → same function, two doors, one unlocked.
  Prove with your own account's harmless object via both doors.
- Method/path normalisation differences between gateway and function
  (trailing slash, case, encoded segments) — the parser-differential model
  from Playbook 17 §4 applies here too.
- Per-function differences: the "admin export" function deployed beside the
  public one, sharing a route prefix, missing the check its sibling has.
  Differentials between sibling functions are gold (AGENTS.md §6).

### 3.5 Timeouts, retries & idempotency (business-logic bridge)

Functions time out; gateways retry; queues redeliver. Result: the same
payment/claim/vote processed twice unless the code uses idempotency keys.
Test gently with your own low-value objects, Playbook 05 rules, and stop at
the first duplicate effect.

---

## 4. Edge & CDN configuration

1. **Cache posture at the edge:** does the CDN cache authenticated/API
   responses? (`CF-Cache-Status`, `Age` on private endpoints.) Full method
   in Playbook 17 §§6–7 — including its safety gate. This playbook only
   *maps*; Playbook 17 *tests*.
2. **Header trust:** origins that trust `X-Forwarded-For`,
   `X-Forwarded-Host`, or a "secret" edge header (`X-Origin-Verify`-style)
   which is also accepted when sent **directly to the origin** by anyone
   who finds the origin hostname. If the origin is in scope, one request
   with/without the header, your account only, proves the differential.
3. **Edge auth vs origin auth:** JWT checked at edge but not re-checked at
   origin (or the reverse), geo/allowlist rules that exist only at one layer.
4. **Stale/placeholder deployments:** default worker pages, debug routes,
   preview deployments with weaker auth — record, scope-check, then test
   only if listed.
5. **Request smuggling note:** edge↔origin is exactly the two-parser chain
   of Playbook 17 §5. Do not improvise smuggling here; follow Playbook 17
   and its checklist gate or stay in the lab.

---

## 5. Object storage — the careful method

1. **Signed vs unsigned:** fetch your **own** file's URL logged-out. Public
   by design (marketing assets) is not a finding; *private* user files
   (invoices, uploads, backups) served unsigned are.
2. **Signed-URL hygiene (your own URLs only):** expiry length (days/weeks?),
   scope (one object or a whole prefix?), `PUT` allowed where only `GET`
   was intended (an *upload* URL that also lets you overwrite — test only
   by re-uploading your own harmless marker file), signature surviving a
   path change to a sibling object of **Account B** (A↔B differential —
   if it returns B's private file, stop after the first byte/metadata proof
   per program rules and report).
3. **Listing:** does the bucket allow anonymous listing (`GET /` on the
   bucket returning keys)? Check only buckets the program lists, with a
   single request. Listing someone else's bucket because the name was
   guessable is out-of-scope testing — do not.
4. **Upload-side bugs:** content-type sniffing on stored files (stored XSS
   via SVG/HTML upload, Playbook 13), overwrite of another user's object by
   predictable key, public ACL applied by the upload function regardless of
   the app's privacy setting ("private" post, public file).
5. **Never:** download bulk content, enumerate keys, or fetch real users'
   files. One of your own marker objects (or B's, with B being yours) is
   always sufficient proof.

---

## 6. IaC & CI/CD — read-only research discipline

This section is **research only** in bug bounty. You read what is public;
you never trigger, modify, or interact with a pipeline.

### 6.1 What to look for in public repos (Tier A)

- **IaC misconfiguration patterns:** storage buckets declared public,
  `0.0.0.0/0` ingress on sensitive ports, wildcard IAM (`Action: "*"`),
  functions with admin roles, secrets passed as plain-text variables,
  state files (`*.tfstate`) committed with real values inside.
- **GitHub Actions risks (recognise & report, never exploit):**
  - `pull_request_target` workflows that check out PR code — the classic
    privileged-context-executes-untrusted-code pattern.
  - Third-party actions pinned by tag instead of commit SHA (a moved tag =
    silent code change in a privileged job).
  - Secrets echoed into logs, or available to workflows triggered by forks.
  - Self-hosted runners on public repos.
- **Exposed-file patterns in web roots you already legitimately fetched:**
  `.git/` presence, `.env` — **if** a single in-scope request for such a
  path is within program rules. Many programs count this as allowed recon;
  some prohibit it. Scope file decides. If a file returns real secrets:
  §3.3 rule — stop, redact, report, never authenticate with them.

### 6.2 Reporting infra findings honestly

A public IaC file showing a wildcard policy is a **configuration risk**,
not proof the deployed account matches the file. Language: "the public
repository declares X; if deployed as written, impact would be Y" and label
the verdict *Likely / Speculative* per AGENTS.md §10 unless you have an
in-scope behavioural proof. Triagers reward that honesty.

---

## 7. Safe validation rules (whole playbook)

- ✅ Proof = your marker object, your A/B accounts, one request, headers or
  first bytes — never bulk data, never a working credential, never a console.
- ✅ For "excessive IAM role" claims, evidence is indirect by design:
  function behaviour + public IaC/docs + error metadata. State it as a
  risk chain; do not attempt privilege-escalation calls against cloud APIs.
- ✅ Container/Kubernetes surface **only if explicitly in scope**: a public
  dashboard/kubelet-style endpoint is proved by its unauthenticated response
  header/banner to a single `GET`, nothing more. No pod listing, no exec,
  no secret reads. Most programs exclude this surface — default is skip.
- ❌ Never use leaked keys/tokens, never open cloud consoles, never create
  persistence (no new keys, users, functions, or buckets in their account).
- ❌ No port scanning of cloud ranges, no bucket brute-forcing, no subdomain
  takeover claims without the program's explicit takeover policy — a
  dangling DNS record is an *observation* until the program invites proof.

---

## 8. Common false positives

- `*.vercel.app` / `*.netlify.app` / `workers.dev` preview that is the
  *developer's own public demo*, unrelated to the bounty program's assets.
- "Public bucket" containing deliberately public assets; check the *data
  class*, not the ACL alone.
- Signed URL with a long expiry that is documented product behaviour for
  share-links — read the docs, test scope-of-signature instead.
- Security headers "missing" on a function URL that is not user-facing —
  headers findings are weak currency; chain or drop.
- IaC examples (`variables.tf` defaults, `example/` folders, test fixtures)
  mistaken for production configuration.
- Cloud error messages that reveal a *product's* account ID you already
  knew from the scope page — information, not a finding.

---

## 9. Detection & SOC lens

Modern infra has superb logs that few teams wire to alerts
(`learning/05-soc-lens.md`):

- **CloudTrail / audit logs:** every API call by every role. Detection
  ideas: alert on a *function role* calling APIs outside its baseline
  (a read-one-bucket role suddenly listing storage = compromise signal).
- **Function logs:** cold-start anomalies, error spikes after deploys,
  env-var names in stack traces leaving the account in a bug report.
- **Storage access logs:** anonymous `GET`s against private prefixes,
  signed-URL use from two countries in an hour, sudden `PUT` volume.
- **CI/CD:** workflow-file changes in PRs, new third-party actions,
  secret-access by fork-triggered runs — all loggable, rarely alerted.
- Write 2–3 of these, matched to what you actually tested, into
  `templates/05-posture-analysis.md` as testable detection hypotheses
  (per AGENTS.md §8 v20 purple-team framing).

---

## 10. Learning path

1. `learning/03-networking-from-zero.md` — DNS, TLS, who-resolves-what.
2. `learning/04-web-and-http-from-zero.md` — headers, caching, redirects.
3. Playbook 09 (cloud & SSRF) → then re-read §1.2's five questions.
4. Lab (Tier A, your own free-tier cloud account): deploy one function +
   one bucket, grant it too much IAM on purpose, then fix it. Doing this
   once teaches more than reading about it ten times
   (`learning/06-safe-lab-roadmap.md`).
5. `learning/05-soc-lens.md` — audit-log thinking for §9.
6. After any finding: `templates/06-learning-notes.md` + 3–5 flashcards
   (`checklists/learning-retention.md`), e.g. "Function + trigger + IAM
   role + environment = the unit of testing. Why?"

## 11. Outputs for this playbook

- Behavioural finding (storage, function auth, header trust) →
  `templates/03-finding-report.md` / `templates/04-platform-report-variants.md`.
- Config/IaC observation → `templates/07-cve-match.md` style sheet adapted
  as a *config match* (declared config, evidence, safe-verification result,
  verdict), or a clearly-labelled section of the posture analysis.
- Excess-privilege / chaining material → `templates/10-chain-canvas.md`
  → Playbook 20.
- Always → `templates/05-posture-analysis.md` + `templates/06-learning-notes.md`,
  with the infra map (§2) filed in the target dossier.
