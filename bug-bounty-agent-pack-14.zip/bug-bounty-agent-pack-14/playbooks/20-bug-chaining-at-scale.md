# Playbook 20 — Bug Chaining at Scale: From Primitives to Critical Impact

> **Scope reminder:** A chain is only valid if **every link is in scope**
> and every step obeys AGENTS.md §2 and the Tier protocol. Chaining never
> launders an out-of-scope step into an in-scope one, and never justifies
> a prohibited technique ("I needed it for the chain" changes nothing).
> Prove chains with Account A / Account B only, minimum impact at every
> step. A chain you have only *imagined* is a hypothesis; a chain you have
> *demonstrated link-by-link* is a finding. This playbook exists to move
> you honestly from the first state to the second — or to a clean "no".

---

## 0. Prerequisites

- [ ] At least one full hunt's worth of single-bug work on the target
      (Playbooks 01–05 at minimum), OR a set of primitives imported from
      earlier sessions with their evidence still available.
- [ ] The threat model (`templates/12-threat-model.md`) — chains aim at
      crown jewels; without it you are collecting curiosities.
- [ ] Working canvas: `templates/10-chain-canvas.md` (per-chain) plus a
      single primitive inventory page in the hunt workspace (see §2).
- [ ] Output templates: chain finding → `templates/03-finding-report.md`
      (one report for the chain, links documented inside), posture →
      `templates/05-posture-analysis.md`, learning →
      `templates/06-learning-notes.md`.
- [ ] Read first: Playbook 08 (creative R&D), Playbook 12/15 (validation
      & severity), `core/05-hypothesis-and-creative-engine.md`.

---

## 1. First principles — what a "primitive" actually is

### 1.1 Bugs vs primitives vs findings (definitions that keep you honest)

- A **bug** is a deviation: the system does something its designers did
  not intend. (A reflected value, a missing check, a verbose error.)
- A **primitive** is a bug expressed as a *capability* an attacker gains,
  stated without drama: "**read** one object belonging to another user",
  "**write** a value the UI never exposes", "**cause** the server to fetch
  a URL I choose (once, GET only)", "**make** a victim's browser visit a
  URL with their session attached".
  If you cannot state the capability in that flat form, you do not yet
  understand the bug well enough to chain it.
- A **finding** is a bug (or chain) with demonstrated, honestly-scoped
  **impact**: data actually reachable, action actually performable, money
  or trust actually movable — proved at minimum scale with your accounts.
- A **chain** is primitives composed so the *output capability* of one is
  the *input requirement* of the next, ending at impact none of them had
  alone. Composition is the whole skill: senior hunters are not people who
  know more payloads; they are people who see joins.

### 1.2 Why systems fall to chains (the root pattern)

Each component is reviewed in isolation and passes: the open redirect is
"just a redirect", the OAuth flow is "standard", the export is
"authenticated". The failure lives **between** components, in assumptions:
*Team OAuth assumed any redirect on our domain is safe; Team Web shipped an
open redirect on that domain.* Nobody lied; the join was never reviewed.
Your job is to be the first person who reviews the joins — systematically,
which is what "at scale" means in this playbook's title: not more targets,
but **all the joins among what you already found** on one target.

### 1.3 The impact ladder (climb one rung at a time, prove each)

```
Rung 0  Anomaly            (something odd — a note, not a bug yet)
Rung 1  Primitive          (flat capability statement, §1.1)
Rung 2  Useful primitive   (capability + a target: whose data / which action)
Rung 3  Demonstrated harm  (A↔B proof: B's data read, A's state changed)
Rung 4  Scaled harm        (any user / any tenant / admin tier — reasoned
                            from the mechanism, proved at minimum scale)
Rung 5  Crown-jewel harm   (money moved, full ATO, tenant-wide export,
                            privileged action — the threat model's jewels)
```

Report the highest rung you **demonstrated**, describe higher rungs as
*reasoned potential* with the mechanism stated, and never present a
reasoned rung as a demonstrated one (Playbook 15 governs severity honesty).

---

## 2. Step 1 — Build the primitive inventory

Before hunting for new bugs, freeze and inventory what you have. Create
`workspace/<program-slug>/primitive-inventory.md` with one row per item:

| # | Primitive (flat capability) | Preconditions | Gives (output) | Needs (input) | Evidence | Status |
|---|---|---|---|---|---|---|
| P1 | Read any invoice PDF by ID (BOLA) | Logged-in free account | Another user's invoice data | An invoice ID | finding-02 link | Confirmed |
| P2 | Server fetches a URL I supply (SSRF, GET) | Admin-import feature, paid acct | Internal HTTP response (headers) | A reachable internal URL | lab notes | Likely |
| P3 | Open redirect on login return URL | None (unauthenticated) | Victim browser lands on my URL, from a trusted link | A victim click | finding-05 link | Confirmed |
| P4 | Stored HTML in support-ticket subject | Any account | Markup rendered in staff console | Staff views ticket | screenshot | Speculative |

Rules for the inventory:

- **Include the embarrassing small stuff:** self-XSS, verbose errors,
  weak rate limits, info leaks, "informational" closures. Chains are built
  from exactly the bugs triage called too small — that is their ecological
  niche. Mark duplicates/informational items *as such*; they still count
  as primitives for composition, honestly labelled.
- **Include negatives that are actually capabilities of the system:**
  "password reset tokens don't expire for 24h" is a system fact that can
  complete a chain even though it is not, alone, a report.
- **Status discipline:** Confirmed / Likely / Speculative (AGENTS.md §10).
  Speculative primitives may be *drawn* on the canvas but a chain with a
  speculative link is a hypothesis, priced accordingly in §5.
- Review sources: finding folders, the hypothesis backlog
  (`templates/02-hypothesis-backlog.md` — the "ruled out, but…" entries),
  technique cards (`templates/08-technique-card.md`), and posture notes.

---

## 3. Step 2 — Draw the chain canvas

Use `templates/10-chain-canvas.md` per candidate chain. The method:

1. **Start from the jewel, work backwards.** Pick one crown jewel from the
   threat model ("export all tenant data", "take over an admin account",
   "move money"). Ask: *what capability would directly achieve this?*
   Then: *which primitive gives that capability — or gives the capability
   that gives it?* Backwards chaining prevents wandering.
2. **Also scan forwards.** For each strong primitive, ask the five
   join questions:
   - Does its output become **input** somewhere more privileged?
   - Does it change **who** the next step acts as (identity join)?
   - Does it change **where** code runs (browser → staff console → server)?
   - Does it remove a **precondition** of another primitive (auth, a click,
     an ID, a token, a time window)?
   - Does it **scale** another primitive (one object → any object → export)?
3. **Draw nodes and labelled edges.** Edge labels are verbs with conditions:
   `P3 --(victim clicks emailed link)--> P7`. An edge you cannot label with
   a concrete mechanism is a wish, not an edge. Delete it or demote it to
   a research question.
4. **Annotate every node** with: status, whose account it needs, user
   interaction needed (none / one click / victim is admin), and noise
   (requests, detectability — feeds the SOC section later).
5. **Keep canvases small.** A chain you cannot draw on one page with ≤7
   nodes is two chains or a fantasy. Split it.

---

## 4. The escalation pattern library (learn these shapes)

These are *patterns* — check your inventory against each shape. Every
example is described for A/B-account proof only.

### 4.1 IDOR/BOLA + export or bulk feature → mass exposure

One-object read is a medium. The same missing check on the **export,
report, print, share, or API-list** twin turns it into "every record".
Pattern move: for every confirmed single-object primitive, re-test its
bulk siblings before anything cleverer. (Playbook 03 §exports.)

### 4.2 XSS + missing CSRF/step-up → action as victim

Stored/reflected XSS alone proves script execution. The escalation is
*what the script can do*: fetch the account-settings page, read the CSRF
token from the DOM (if it is DOM-readable), and perform the sensitive
action (email change, API-key creation, passkey enrolment per Playbook 18
§6) — i.e. "CSRF with extra steps", working even where CSRF tokens exist,
because XSS is *inside* the origin. Prove on B-as-victim clicking/viewing
A's payload in your lab-style A/B setup only.

### 4.3 Open redirect + OAuth → code/token theft

Playbook 18 §3.2's chain: strict redirect-URI list points at the app's own
domain; an open redirect **on that domain** forwards the callback — code
included — to the attacker. Each piece alone triages low; together, ATO.
The general shape: *trust-anchored flow + any steering primitive on the
trusted origin*.

### 4.4 SSRF + cloud metadata + over-privileged role → cloud compromise path

The canonical server-side ladder (Playbooks 09 + 19): SSRF reaches the
instance metadata service → temporary credentials for the machine role →
role is broader than the app needs → storage/account impact. **Proof
discipline is strictest here:** most programs want the metadata *response
for the instance's own non-secret fields* (or even just the SSRF reaching
an internal marker) as the maximum proof, and **forbid using credentials**.
Obey the program; describe the role-breadth rung from public/IaC/behavioural
evidence, labelled as reasoned potential (Playbook 19 §7).

### 4.5 Self-XSS + login CSRF (or a delivery primitive) → stored attack on others

Self-XSS is "informational" until a second primitive *delivers* it into
someone else's session: login CSRF (Playbook 18 §3.3), an admin
impersonation/preview feature, a shared-device flow, or a postMessage
handler (Playbook 13). The lesson generalises: **delivery is a primitive**.

### 4.6 Low-privilege write + privileged reader → privilege escalation

Your input, rendered/executed in a *more privileged context*: support
ticket → staff console XSS; filename → admin import parser; markdown →
internal docs tool; webhook payload → ops dashboard. Always ask of every
write primitive: *who or what reads this, with what privilege, in what
renderer?* Second-order/stored chains are slow (the reader must act) —
log them, trigger them only among your own test roles.

### 4.7 Rate-limit / enumeration + weak reset or OTP → ATO

An enumeration oracle (which emails exist) + a reset/OTP flow with a
generous attempt budget + long token lifetime (an inventory "system fact",
§2) compose into practical ATO. Test budgets gently on your own accounts
(Playbook 04/05 rules); the *composition* is argued from measured numbers,
not from actually brute-forcing anything.

### 4.8 Cache/realtime multipliers

A stored primitive gains reach when delivery is shared: cache poisoning
serves your stored content to everyone (Playbook 17, safety-gated),
a realtime channel pushes it into live sessions (Playbook 17 §3.4).
Treat these as **reach multipliers** on the canvas, drawn last, gated hardest.

### 4.9 Information leak + anything → precondition removal

Leaked IDs unlock BOLA testing; leaked internal hostnames unlock SSRF;
leaked stack traces unlock CVE matching (Playbook 06); leaked reset-token
*format/length* prices an OTP attack. Never dismiss a leak until you have
asked: *which other primitive was missing exactly this?*

---

## 5. Step 3 — Prioritise with the chain matrix

Score each drawn chain 1–3 per axis; work the board top-down:

| Axis | 3 (best) | 1 (worst) |
|---|---|---|
| Weakest-link status | All Confirmed | Contains a Speculative link |
| Interaction needed | None | Victim must be an admin doing something rare |
| Accounts needed | Unauthenticated / free A only | Paid + admin test roles you lack |
| Impact rung reached (§1.3) | 4–5 | 2 |
| Test cost / noise | Few requests, own objects | Many requests, shared infra, gated playbook |
| Duplicate risk | Novel join for this program | The famous chain everyone reports |

- Chains scoring high on impact but containing a speculative link get a
  **single-link validation task**, not a full chain test: prove or kill
  the weak link first (cheapest falsification, `core/05` doctrine).
- Re-score after every hunt session; the inventory is a living document.

---

## 6. Step 4 — Validate the chain end-to-end (safely)

1. **Re-prove each link fresh**, in one session, in order, A/B only.
   Primitives decay (fixes, config drift); a chain is only as current as
   its oldest re-proof. Log timestamps per link.
2. **Then run the composition once**, exactly as drawn, capturing evidence
   at each hand-off (the artefact one link produces visibly feeding the
   next: the redirected URL carrying the code; the fetched token used in
   the settings change). Hand-off evidence is what convinces triagers.
3. **Minimum-impact end state:** land on *your own* B account's data /
   A's account taken over *by your own B session* / a marker object.
   The moment the end-state is demonstrated once, stop. Do not iterate
   "to see how far it goes" against anything real.
4. **If a link fails:** record precisely where and why (this is a valuable
   negative — it tells the posture analysis a control *exists* at that
   join), update statuses, and return to §5. Never quietly substitute a
   riskier technique to force the chain through.

---

## 7. When NOT to chain (read twice)

- **When a link is out of scope or prohibited.** Stop. (Header of this playbook.)
- **When the "chain" is severity theatre.** Concatenating three
  informationals that still end at "attacker learns a version number" is
  one informational with a long introduction. If the end rung (§1.3) did
  not actually rise, report the best single bug honestly and move on.
- **When a single bug already reaches the jewel.** Report it clean and
  simple; a needless chain adds reproduction steps, triage time, and
  duplicate risk. Elegance is a short proof.
- **When proving the join needs a real victim, real data, or shared-infra
  risk** (un-gated smuggling/cache work, a staff member actually clicking).
  Argue that join from mechanism, label it reasoned potential, and let
  the program decide if it wants a supervised proof.
- **When you are chaining to rescue a dead session.** "No findings today"
  plus creative chaining is how speculative epics get written. The
  inventory-and-matrix discipline (§§2, 5) exists to tell you, kindly,
  that today's correct output is a solid negative result + posture notes.

---

## 8. Reporting a chain (so triage can follow it)

Use **one** report (`templates/03-finding-report.md`) for the chain:

- **Title:** end impact first — "Account takeover via open redirect +
  OAuth code interception", not "Three low issues".
- **Structure:** (1) impact summary in business terms; (2) the primitives,
  each in 3–5 lines with its own mini-proof; (3) the composition, numbered,
  with hand-off evidence; (4) honest severity: demonstrated rung +
  reasoned potential, CVSS scored for the **chain's** impact with the
  interaction preconditions reflected in the metrics (Playbook 15);
  (5) fixes **per link** — and note the cheapest single fix that breaks
  the chain (defenders love this; it is usually one link's one-line check).
- Attach the completed canvas (`templates/10-chain-canvas.md`) as an
  appendix. Run `checklists/report-qa.md`. Operator submits (Tier B).

---

## 9. Common false positives & self-deceptions

- **The phantom link:** "and then the attacker could…" with no mechanism.
  If the edge has no verb, there is no chain (§3.3).
- **Double-counting one bug:** the same missing check appearing in two
  endpoints is one primitive with two instances, not a two-link chain.
- **Interaction laundering:** quietly assuming an admin will open the
  malicious ticket *and* be on the vulnerable page *and*… — multiply the
  real probabilities; if the story needs three coincidences, say so.
- **Version-decay:** chaining to a primitive from a three-month-old session
  that has since been fixed. Re-proof is §6.1, not optional.
- **Assuming the privileged reader exists:** "support staff surely view
  this in a browser" — verify the reader/context among your test roles
  or label the link Speculative.

---

## 10. Detection & SOC lens

Chains are a defender's blind spot for the same reason they are an
attacker's strength: **each step is below an alert threshold; only the
sequence is malicious.**

- Detection idea class: **correlation over time** — one identity touching
  an enumeration oracle, then a reset flow, then a settings change inside
  N minutes is a story no single log line tells. Write detections as
  sequences in `templates/05-posture-analysis.md`.
- For each chain you report, name the **cheapest detection link** (the
  noisiest step) and the **cheapest prevention link** (the easiest fix) —
  they are rarely the same link, and giving both is senior-level work.
- Note in posture which links produced *any* visible telemetry during your
  A/B proof (rate-limit trip? email alert? session kill?) — that is real
  purple-team evidence (AGENTS.md §8, `core/10` in v20 terms: detection as
  a testable hypothesis per link).

---

## 11. Learning path

1. Playbook 08 (creative R&D) — the single-bug idea engine feeding §2.
2. `core/05-hypothesis-and-creative-engine.md` — falsification discipline.
3. Rebuild §4.3 and §4.4 from memory on a blank canvas; then check against
   the text. Gaps = study list.
4. Study 3 disclosed chain reports for programs you follow (Playbook 07
   mining) and extract *their* canvases into `templates/08-technique-card.md`.
5. `learning/05-soc-lens.md` for §10's correlation thinking.
6. After any chain work: `templates/06-learning-notes.md` — self-checks
   like "State P1–P3 of my last chain as flat capabilities. Which edge
   label was weakest, and how did I test it?" + 3–5 flashcards.

## 12. Outputs for this playbook

- Primitive inventory → `workspace/<program-slug>/primitive-inventory.md`.
- Each candidate chain → `templates/10-chain-canvas.md`.
- Validated chain → single finding report, `templates/03-finding-report.md`
  (platform variant `templates/04-…` as needed).
- Dead chains & failed links → hypothesis backlog notes + posture material
  (they are evidence of working controls at the joins).
- Always → `templates/05-posture-analysis.md` + `templates/06-learning-notes.md`.
  Run chains as a team via `workflows/09-bug-chain-sprint.md` and
  `prompts/10-chain-sprint.md`.
