# Playbook: Business logic

## 0. Concept ladder
1. Logic bugs are violations of the *business rule*, not of a parser.
2. Find the rule, then find the states the rule forgot: negative, zero, fractional, overflow,
   reorder, replay, partial completion, currency and rounding.
3. The oracle is usually money, entitlement, or sequence.

## 1. Probes
1. Quantity: negative, zero, huge, fractional, `1e3`, unicode digits.
2. Price and currency: client-supplied price, currency swap, rounding, coupon stacking.
3. Sequence: skip a step, repeat a step, reorder steps, resume after cancel.
4. Entitlement: downgrade then use paid features, trial reset, seat count.
5. Refund/withdraw: refund more than paid, refund twice, withdraw after transfer.
6. Time: expired coupon, extended trial, timezone edges, DST.
7. Multi-actor: two users acting on one resource concurrently.

## 2. Pitfalls
Not reading the terms page — the rule is written there. Testing on a sandbox where the money
is fake and behaviour differs.

