# Playbook: Web cache poisoning / deception

## 0. Concept ladder
1. A cache keys on some inputs and ignores others.
2. Anything unkeyed that reaches the response is poisonable.
3. Unkeyed inputs: most headers, some query params, cookies, body on some CDNs.
4. Deception is the inverse: keyed inputs that the origin ignores, so a poisoned copy lands in
   a *victim's* cache slot.

## 1. Signals
CDN headers (`X-Cache`, `CF-Cache-Status`, `Age`), static-looking paths that reflect headers,
`X-Forwarded-Host`/`X-Forwarded-Scheme` reflection, error pages, redirects.

## 2. Probes
1. Confirm cacheability: two requests, watch `Age`/`X-Cache` and body stability.
2. Header reflection: `X-Forwarded-Host`, `X-Host`, `X-Forwarded-Scheme`, `X-Original-URL`.
3. Cache-key analysis: add a junk param, see if the hit ratio changes.
4. Poison with a harmless marker, then request clean and look for it.
5. Deception: `?utm=`, `?callback=`, path normalisation, `;` params.

## 3. Pitfalls
Poisoning your own browser cache. Testing a path that is not cached. Ignoring `Vary`.

