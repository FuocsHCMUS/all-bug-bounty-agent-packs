# Playbook: File upload

## 0. Concept ladder
1. Uploads cross a trust boundary: bytes you control land in their storage and are later served.
2. Three questions: what is validated, where is it stored, how is it served.
3. Bypasses target the validation (extension, MIME, magic bytes), the storage (path, name), and
   the serving (Content-Type, disposition, same-origin).

## 1. Probes
1. Extension matrix: `.php`, `.phtml`, `.php5`, `.jsp`, `.aspx`, `.svg`, `.html`, `.shtml`,
   double extension `.jpg.php`, trailing dot/space, `%00`, case variation.
2. Content-Type and magic-byte mismatch.
3. Filename injection: `../`, long names, unicode, `;` params.
4. SVG: script inside, external entity, `xlink:href` to internal.
5. Where is it served from — same origin (XSS/RCE) or a separate bucket (usually lower)?
6. Archive uploads: zip slip, nested zip.

## 2. Pitfalls
Uploading a shell to a host with no interpreter. Forgetting that the CDN sets
`Content-Disposition: attachment`.

