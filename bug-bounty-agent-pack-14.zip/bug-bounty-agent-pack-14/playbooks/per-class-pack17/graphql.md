# Playbook: GraphQL

## 0. Concept ladder
1. GraphQL is one endpoint with a typed schema; the client picks fields.
2. Authorization must be per-field and per-node, and often is not.
3. Introspection is a map; batching and aliases are amplifiers; depth is a DoS lever.

## 1. Probes
1. Introspection on: full schema dump, then diff against the UI's operations.
2. Field-level authz: query private fields on a public node.
3. Node id decoding (`base64("User:123")`) and cross-tenant fetch.
4. Alias batching for brute force and for id enumeration.
5. Array/`null` coercion type confusion on ids.
6. Depth/cost limits: nested 15 levels, then a 500-alias query.
7. Deprecated fields — often unaudited.
8. `__typename` to find interfaces and unions with different resolvers.

## 2. Pitfalls
Introspection disabled but suggestions still leak (`"Did you mean"`). Field-level authz tested
with an admin token only.

