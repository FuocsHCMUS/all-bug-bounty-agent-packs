# Playbook: HTTP desync (CL.TE / TE.CL / TE.TE)

## 0. Concept ladder
1. A request is framed by `Content-Length` and/or `Transfer-Encoding`.
2. Front-end and back-end may frame the same bytes differently.
3. The gap leaves leftover bytes in the socket, which prefix the *next* request.
4. Consequence: request smuggling, cache poisoning, auth bypass, queue poisoning.

## 1. Preconditions
A proxy/CDN in front of an origin, keep-alive, and a disagreement about TE handling.

## 2. Probes (ask before running — this class is disruptive)
1. Timing probe: a request that hangs on the back-end but not the front-end.
2. CL.TE: `Content-Length` small, `Transfer-Encoding: chunked` with a smuggled prefix.
3. TE.CL: the inverse.
4. TE obfuscation matrix: `Transfer-Encoding: xchunked`, `Transfer-Encoding : chunked`,
   duplicate TE headers, `\n` vs `\r\n` in the chunk size line.
5. Confirmation with a canary request that should hit the poisoned socket.

## 3. Impact
Hit the next user's request, poison the cache, bypass front-end auth. Critical when it reaches
other tenants.

## 4. Pitfalls
Testing with a client that normalises. Reusing a socket after a failed probe. Forgetting that
HTTP/2 front-ends downgrade to 1.1 at the back-end.

