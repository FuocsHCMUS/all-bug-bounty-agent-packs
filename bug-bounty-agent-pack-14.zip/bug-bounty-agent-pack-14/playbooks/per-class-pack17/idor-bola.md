# Playbook: IDOR / BOLA

## 0. Concept ladder (beginner)
1. An *object* is a row, file or record the app stores.
2. *Identity* is who the request claims to be (session, token, mTLS).
3. *Authentication* proves identity; *authorization* decides what that identity may touch.
4. Authorization has three homes: per-object (row-level), per-function (endpoint-level),
   per-field. IDOR is a missing per-object check.
5. The bug exists because the server trusts the identifier in the request instead of deriving
   the owner from the session.

## 1. Correct behaviour
Server resolves `object -> owner` and compares with `session -> subject`, or scopes the query
by tenant. 404 vs 403 choice is cosmetic; the leak is the bug.

## 2. Signals
Sequential/guessable ids, UUIDv1, base64 `{"id":123}`, ids in paths *and* bodies, GraphQL
`node(id:)`, `?account=`, export/download endpoints, bulk endpoints, `/api/v2` siblings that
lost the check, "shared with me" features.

## 3. Probes (cheap -> expensive)
1. Two accounts, same object id, swap the session only.
2. Swap id only, keep session: +1, -1, and a far-away id.
3. Swap id *type*: numeric -> uuid, uuid -> email, id -> slug.
4. Move the id between locations: path -> body -> header -> query.
5. Method and version swap: `GET` -> `PUT`/`DELETE`/`PATCH`, v1 -> v2.
6. Bulk and export paths, CSV/PDF renderers, webhook replays.
7. Nested objects: child id with parent id from another tenant.
8. GraphQL: `node`, `edges`, alias batching, `@include` on private fields.

## 4. False positives
Public objects, objects shared by design, 403 on the object but 200 on a public projection,
CDN-cached pages that ignore the session.

## 5. Impact
Read (PII, invoices, tokens), write (profile takeover, price change), delete. Severity rises
with data sensitivity and with cross-tenant reach. Mass-enumerable ids plus PII is usually
high or critical.

## 6. Report notes
Show both accounts side by side. Prove ownership of the object by the victim. State the
enumeration surface (how many ids, how fast).

## 7. Pitfalls
Only testing your own second account inside the same tenant. Not checking the write path.
Assuming UUID means safe.

