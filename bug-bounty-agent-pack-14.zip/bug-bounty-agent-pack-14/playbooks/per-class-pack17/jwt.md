# Playbook: JWT

## 0. Concept ladder
1. A JWT is `header.payload.signature`, base64url, not encrypted.
2. The server must decide *which* algorithm and *which* key to trust.
3. Bugs live in that decision: `alg:none`, HS256 with the public key as secret, `kid` injection,
   `jku`/`x5u` pointing at your host, missing `aud`/`iss`/`exp` checks, claim type confusion.

## 1. Probes (use `tools/jwt_inspect.py` first)
1. Decode and read claims; note `alg`, `kid`, `jku`, `aud`, `iss`, `exp`.
2. `alg:none` with signature stripped.
3. HS256 <-> RS256 confusion: sign with the public key as HMAC secret.
4. Weak HMAC secret from a short list.
5. `kid` traversal (`../../dev/null`), `kid` SQLi, `kid` path to a known file.
6. `jku`/`x5u` to your listener.
7. Claim abuse: `sub`, `role`, `tenant`, `email_verified`, `is_admin`, integer vs string.

## 2. Pitfalls
Server validates signature but not claims. Multiple token types with different rules.
Refresh-token path with weaker validation than access-token path.

