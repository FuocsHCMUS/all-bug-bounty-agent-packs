# Playbook: Mobile / API-only surface

## 0. Concept ladder
1. A mobile app is a client you fully control; its API is the real target.
2. Static keys, hidden endpoints and client-side checks are all visible after unpacking.
3. Server-side enforcement is the only enforcement; anything the app checks is a hint.

## 1. Probes
1. Pull the APK/IPA; `strings`, unzip, look for base URLs, API keys, feature flags, staging
   hosts, certificate pinning config.
2. `apktool`/`jadx` for endpoint and param extraction; compare to the web surface.
3. Auth flows: token lifetime, refresh rotation, device binding, logout invalidation.
4. Old API versions reachable from the app but not the web.
5. Deep links / custom schemes -> parameter injection into webviews.
6. `X-Client-Version`, `X-Platform` gates: do older versions skip checks?

## 2. Pitfalls
Pinning blocking interception (needs Frida, ask). Testing only the latest app version.

