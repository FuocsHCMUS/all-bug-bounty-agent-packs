# Playbook: OAuth 2.0 / OIDC

## 0. Concept ladder
1. OAuth delegates access; OIDC adds identity. Both are redirect dances with codes and tokens.
2. The security hinges on `redirect_uri` matching, `state` binding, PKCE, and audience checks.
3. Common bugs: loose redirect matching, missing `state`, code injection, implicit-flow token
   leak, `id_token` audience confusion, account linking without verification.

## 1. Probes
1. `redirect_uri` matrix: exact, prefix, subdomain, `@`, `//evil`, `?x=`, path traversal,
   `#fragment`, unicode dots, `localhost`.
2. `state` absent or unvalidated -> login CSRF.
3. Code replay and code swap between clients.
4. `response_mode=form_post` and `web_message` handling.
5. Implicit: token in fragment leaked via `postMessage` wildcard.
6. Account linking: register at the IdP with the victim's email, does it merge?
7. Scope upgrade: request extra scope at the authorize step.

## 2. Impact
Full account takeover via linking, or token theft.

## 3. Pitfalls
Testing only your own client. Missing that the `redirect_uri` is validated server-side at the
token step, not the authorize step.

