# Playbook: Race conditions

## 0. Concept ladder
1. Check-then-act is two steps; the window between them is the bug.
2. Classic shapes: redeem coupon, withdraw, transfer, vote, invite, claim username, apply
   referral, one-time token, rate-limit counter.
3. Single-packet attack (HTTP/2) collapses the window; parallel sockets approximate it.

## 1. Probes (ask first)
1. Identify the check-then-act pair and the resource it protects.
2. Send N identical requests in one barrier (`tools/race_runner.py`), N=20 first.
3. Look for: balance below zero, two resources for one token, count above the limit.
4. Try mixed pairs: redeem+refund, transfer out twice, apply+withdraw.
5. Verify state after the burst, not just the responses.

## 2. Pitfalls
Sequential retries that hide the window. Missing the DB uniqueness constraint that saves them.
Assuming a lock exists because the UI disables the button.

