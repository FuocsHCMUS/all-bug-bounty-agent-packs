# Playbook: SQLi

## 0. Concept ladder
1. SQL is code; data becomes code when concatenated into the query string.
2. Parameterisation binds data as data. Escaping is a weaker, context-dependent substitute.
3. The bug lives where a value reaches the parser: `WHERE`, `ORDER BY`, `LIMIT`, identifiers,
   JSON paths, `LIKE`, array `IN (...)`.
4. ORMs do not save you: raw fragments, `order`, `having`, dynamic column names do not bind.

## 1. Signals
Numeric ids, sort/filter params, `?order=`, `?col=`, pagination `limit/offset`, search with
`LIKE`, date ranges, GraphQL args mapped to SQL, report builders.

## 2. Probes
1. Boolean pair: `' AND 1=1-- -` vs `' AND 1=2-- -`; compare body and status.
2. Arithmetic: `2-1` vs `2` on numeric params.
3. String break: `'`, `"`, `\` -> error text or 500.
4. Order-by position: `ORDER BY 1`, `ORDER BY 99` -> error at the boundary.
5. Time: `SLEEP(3)` / `pg_sleep(3)` / `WAITFOR DELAY`.
6. DBMS fingerprint from error strings, then dialect-specific confirmation.
7. Blind: boolean over many requests, then time-based if the body is stable.
8. Second-order: store the payload, trigger the report/export that re-parses it.

## 3. Escalation
`UNION` with matching column count and types; then read `version()`, schema, and one table you
can prove is sensitive. Stacked queries only if the driver allows.

## 4. False positives
Reflected `'` in HTML without a query. WAF block pages. Cached responses masking the difference.

## 5. Pitfalls
Testing `ORDER BY` with a string. Forgetting `-- -` spacing. Not checking whether the app is
read-only on that replica.

