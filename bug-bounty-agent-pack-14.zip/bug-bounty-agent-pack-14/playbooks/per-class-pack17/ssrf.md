# Playbook: SSRF

## 0. Concept ladder
1. A URL is a request the *server* makes, not the browser.
2. The server sits in a network you cannot reach: loopback, private ranges, metadata, control
   planes.
3. Any feature that fetches a URL is a proxy: importers, webhooks, avatars, PDF renderers,
   previews, RSS, OAuth callbacks, image resizers.
4. Filters usually check the *string*; the resolver decides the *address*. That gap is the bug.

## 1. Signals
`url=`, `image=`, `webhook=`, `callback=`, `feed=`, `import=`, `pdf=`, `?src=`, SVG/HTML
import, "fetch from URL" buttons, WSDL/SOAP, SSO metadata URLs.

## 2. Probes
1. External listener first: does it call out at all? Note method, headers, UA, timing.
2. Scheme matrix: `http`, `https`, `file`, `gopher`, `dict`, `ftp`, `ldap`.
3. Address matrix: `127.0.0.1`, `[::1]`, `0.0.0.0`, `169.254.169.254`, `metadata.google.internal`,
   decimal/octal/hex forms, `127.1`, `0x7f000001`, `2130706433`.
4. Redirect chain: your host 302 -> internal target (defeats allowlists that check once).
5. DNS rebinding: TTL 0 record flipping public -> private.
6. Host-header tricks: `internal@evil`, `evil#@internal`, trailing dot, IDN.
7. Port sweep on loopback: 22, 80, 443, 3000, 5000, 6379, 8080, 8500, 9200, 11211.
8. Read responses through the feature (image render, PDF text, error strings).

## 3. Impact
Metadata credentials -> cloud takeover; internal admin panels; Redis/Memcached writes; port
scanning; in some stacks full RCE via gopher + Redis or FastCGI.

## 4. False positives
Blind callbacks that only prove DNS, not fetch. Image proxies that fetch via a third party.
Allowlisted CDNs that resolve to a shared IP.

## 5. Pitfalls
Sending the payload where the app expects a file upload. Forgetting that PDF renderers may
resolve relative URLs from the document, not the server.

