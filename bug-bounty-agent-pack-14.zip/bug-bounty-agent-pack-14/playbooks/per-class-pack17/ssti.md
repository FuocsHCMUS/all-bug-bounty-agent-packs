# Playbook: SSTI

## 0. Concept ladder
1. A template engine compiles text into code with placeholders.
2. If user text reaches the *template source* (not just a variable), it is compiled.
3. Engines: Jinja2/Twig (`{{ }}`), Freemarker (`${ }`, `<#assign>`), Velocity, Smarty,
   ERB, Handlebars, Thymeleaf, Pebble, Mako.
4. Detection is arithmetic; exploitation is object-graph walking to `os`/`Runtime`.

## 1. Signals
Email/PDF/notification templates, "custom message" features, invoice headers, name fields
rendered into PDFs, CMS blocks, GraphQL template args.

## 2. Probes
1. `${7*7}`, `{{7*7}}`, `#{7*7}`, `%{7*7}`, `<%= 7*7 %>`, `{7*7}` — look for `49`.
2. Engine confirmation via distinctive syntax errors.
3. Math deeper: `{{7*'7'}}` gives `7777777` on Jinja2, `49` on Twig — a cheap discriminator.
4. Object graph: `{{self}}`, `{{config}}`, `${T(java.lang.Runtime)}`, `<#assign x="freemarker.template.utility.Execute"?new()>`.
5. Sandbox escape only after plain SSTI is proven.

## 3. Impact
Often RCE. Without RCE it is still file read, secret disclosure, or SSRF from inside.

## 4. Pitfalls
Client-side templating (Handlebars in the browser) is not SSTI — check where rendering happens.
Escaped output that looks like a template but is rendered twice.

