# Playbook: Subdomain takeover

## 0. Concept ladder
1. A DNS record points at a provider resource that no longer exists.
2. The provider lets anyone claim that resource name.
3. Whoever claims it serves content under the victim's origin — cookies, CSP, CORS included.

## 1. Probes
1. From the asset list, take CNAMEs to SaaS: `*.s3.amazonaws.com`, `*.herokuapp.com`,
   `*.github.io`, `*.azurewebsites.net`, `*.cloudfront.net`, `*.readme.io`, `*.surge.sh`.
2. Fetch the host: provider "no such app" page is the signal.
3. Confirm claimability without claiming (check the provider's naming rules).
4. Note cookie scope and whether the parent sets `domain=.example.com`.

## 2. Pitfalls
A record that still resolves to a live app. Wildcard DNS that hides the dangling record.
Provider pages that 404 but are not claimable.

