# Playbook: XSS

## 0. Concept ladder
1. HTML is a parser with context: text, attribute, URL, script, CSS, comment, JSON-in-script.
2. Escaping is context-specific; a generic escaper is wrong in at least four of those contexts.
3. The browser trusts whatever parses; the server's intent is irrelevant.
4. Sinks matter more than sources: `innerHTML`, `document.write`, `eval`, `srcdoc`, `href=javascript:`.

## 1. Contexts to test
Reflected: search, error, redirect `next=`, 404 path echo. Stored: profile, comments, filenames,
imported CSV, markdown, PDF-to-HTML. DOM: hash routers, `postMessage` handlers, `location`
readers. Attribute: `value="..."`, `href`, `srcset`, `style`.

## 2. Probes
1. Context fingerprint: `x'"><svg/onload=alert(1)>` and read where it lands.
2. Per context: text -> `<img src=x onerror=alert(1)>`; attribute -> `" onmouseover="`;
   URL -> `javascript:alert(1)`; script -> `'-alert(1)-'`; CSS -> `background:url(javascript:)`.
3. Filter probing: which chars survive, is it entity-encoded, is it a sanitizer (DOMPurify
   version, `mXSS` shapes, `<math><mtext>`).
4. Framework sinks: Angular `{{ }}` and `[innerHTML]`, React `dangerouslySetInnerHTML`,
   Vue `v-html`, Alpine `x-html`.
5. Stored: place payload, then view from a different account and a different browser profile.

## 3. Impact
Session theft (httpOnly?), CSRF bypass, keylogging, wallet drain, admin action. Self-XSS only
counts with a delivery story.

## 4. False positives
Payload in a `<textarea>` that never renders. `alert` blocked but execution real. Sanitizer
present but version-vulnerable — verify, don't assume.

## 5. Pitfalls
Testing only Chrome. Missing the CSP that makes it low. Forgetting the mobile webview.

