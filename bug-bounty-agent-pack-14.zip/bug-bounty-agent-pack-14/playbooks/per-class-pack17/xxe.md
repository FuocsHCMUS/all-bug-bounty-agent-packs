# Playbook: XXE

## 0. Concept ladder
1. XML can declare an external entity; the parser resolves it.
2. Resolution means file read, SSRF, or denial of service depending on the entity.
3. Modern defaults vary by parser and version; "it's Java, so it's vulnerable" is wrong.
4. JSON-only APIs often still accept XML on a sibling endpoint or via `Content-Type` swap.

## 1. Signals
SOAP, SAML, RSS/Atom import, Office/ODS upload, SVG upload, `Content-Type: application/xml`,
`.xml`/`.xsl`/`.docx` uploads, sitemap importers.

## 2. Probes
1. `Content-Type: application/xml` on a JSON endpoint, valid minimal XML body.
2. Classic file read with an external entity, echo it through an error field.
3. Blind OOB via parameter entity + your listener (for parsers that will not echo).
4. SSRF entity to metadata.
5. Billion laughs only after the basics; note memory.
6. XInclude where the root element is fixed: `<xi:include href="file:///etc/passwd"/>`.

## 3. Pitfalls
Doctype stripped by a WAF. Parser resolves but discards. OOXML needs the entity inside
`document.xml`, and the zip must stay valid.

