# Prompt 09 — OSINT Sweep (copy-paste)

Use to run Workflow 08 (OSINT & Attack Surface Discovery) on a new or
ongoing hunt. Replace the <…> fields, paste the whole block, and let the
agent work Tier A (read-only) until it reaches the Tier B handoff.

---
Using this pack's AGENTS.md (read §§2, 4, 5 first), run an OSINT and
attack-surface discovery sweep for:

- Program: <program name> on <HackerOne / Bugcrowd / other platform>
- Program URL: <official program URL>
- Known in-scope roots: <e.g. example.com, api.example.com — or "unknown,
  extract from the program page">
- Hunt mode: <NEW HUNT — full sweep / REFRESH — 30-minute delta sweep
  against the map in workspace/<program-slug>/>

Rules for this sweep (do not negotiate them with yourself):

1. READ-ONLY ONLY. This is Tier A research. Do not port-scan, probe,
   fuzz, brute-force, or send crafted requests to any asset. Normal
   public browsing, public records (Certificate Transparency, public
   search indexes, public code/docs), and offline analysis of files I
   legitimately received as a visitor are in. Everything else you
   discover becomes a labelled candidate and a Tier B proposal — not
   an action.
2. NO PEOPLE OSINT. No employee profiling, no personal data, no breach
   dumps or credential corpora, no contacting anyone. Technical and
   corporate surface only. If a source crosses that line, close it and
   note that you did.
3. SCOPE LABELS ON EVERYTHING. Every asset you list gets exactly one
   label: In scope / Out of scope / Unknown — sourced from the official
   program page, never from resemblance. Unknown assets are never
   tested, in this sweep or by implication.

Do the work in this order (Workflow 08):

A. Anchor (first-party sources)
   - Read the program page in full; complete or update
     templates/00-scope-intake.md and read the scope sets back to me.
   - Map the company's public graph: product/pricing tiers, trust and
     security pages, status page components, developer docs, API
     reference, help centre, and the last ~90 days of changelogs.
     Recent features get flagged — fresh code is fresh surface.

B. Passive technical footprint
   - Certificate Transparency + public search-index review for the
     in-scope roots: subdomains, staging/dev/legacy/regional hosts.
   - Build the candidate surface table: hostname → scope label →
     guessed role → evidence source. Guesses are labelled guesses.

C. Code & shipped artefacts (offline analysis only)
   - Public repos/orgs: product code if open, SDKs, docs repos, IaC.
     Read under Playbook 19 §6 discipline (patterns, not exploitation).
   - From my own normal browsing of in-scope apps: save the JS bundle
     list and run scripts/js_extract.py OFFLINE on downloaded bundles;
     if I provide a HAR of my own session, run scripts/har_analyzer.py
     OFFLINE on it. File outputs in workspace/<program-slug>/.

D. Fingerprint & CVE pre-sweep
   - Assemble the fingerprint list (frameworks, servers, CDN, auth
     provider, key libraries, with the evidence for each).
   - For versioned components, run the Playbook 06 pipeline
     (scripts/cve_lookup.py; NVD / vendor / GHSA / CISA KEV) and open a
     templates/07-cve-match.md sheet per plausible match. Verdict at
     this stage is Speculative at best — nothing is verified yet.
   - Pull 3–5 relevant disclosed reports/writeups into
     templates/08-technique-card.md cards. Patterns, not payloads.

E. Identity, infra & realtime seeds (observation only)
   - Login/SSO/passkey surface per Playbook 18 §2; storage/CDN/function
     hostnames the app reveals per Playbook 19 §2; any wss/SSE/Socket.IO
     endpoints visible in docs/bundles per Playbook 17 §2.

Then assemble and hand off:

4. Merge A–E into the target dossier (templates/01-target-dossier.md)
   as ONE attack-surface map: asset → scope → role → auth model →
   crown-jewel proximity → applicable playbook(s) → cheapest first test.
5. Draft the threat model (templates/12-threat-model.md) and a ranked
   hypothesis backlog (templates/02-hypothesis-backlog.md, 10–20 items,
   each naming its playbook).
6. Report back to me in ONE message:
   - Scope summary, with every Unknown asset listed for my ruling;
   - The top 5 rows of the surface map and why they rank there;
   - The top 5 hypotheses;
   - Any CVE sheet with a credible verification path;
   - Your grouped Tier B proposals (active recon first) in the core/02
     ask format — then STOP and wait for my approval.
7. Teach as you go, in English, from first principles: when you use a
   term I may not know (CT log, fingerprint, sub-processor, cache key),
   define it in one plain sentence the first time it appears.
---

*After this prompt:* approvals lead into Workflow 01 Phase 2+ (active
recon) or straight to Phase 5 testing. For a REFRESH run, the agent
should diff against the previous map and report only deltas + anything
whose scope label changed.
