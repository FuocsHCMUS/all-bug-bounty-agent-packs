# Prompt 10 — Chain Sprint (copy-paste)

Use to run Workflow 09 (Bug Chain Sprint) + Playbook 20 on a program
where you already have single bugs, duplicates, informationals, or
strong "system facts" that might compose into real impact. Replace the
<…> fields and paste the whole block.

---
Using this pack's AGENTS.md (read §§2, 4, 6, 8 first) and Playbook 20,
run a bug-chaining sprint for:

- Program: <program name> (<platform>)
- Hunt workspace: workspace/<program-slug>/
- Session goal: <e.g. "find one ATO path" / "escalate the invoice BOLA
  to tenant-wide impact" / "open — best chain the inventory supports">
- Timebox: <2–4 hours>

Non-negotiable rules for this sprint:

1. EVERY LINK IN SCOPE. A chain never launders an out-of-scope asset or
   a prohibited technique into legitimacy. If the only path through
   uses one, the chain dies on paper and you tell me why.
2. A/B ONLY, MINIMUM IMPACT. All proof uses Account A and Account B
   (both mine), my own objects, and marker values. The end state of any
   proof is my B session acting on my A account/data — demonstrated
   once, then stop.
3. HONEST RUNGS. Use Playbook 20 §1.3's impact ladder. Report the rung
   you DEMONSTRATED; describe higher rungs as reasoned potential with
   the mechanism stated. No severity theatre: if the end rung did not
   rise, say so and we report the best single bug instead.
4. NO NEW-BUG HUNTING. Ideas for new single bugs go into the backlog
   parking lot in one line each. This session validates joins only.

Work in this order (Workflow 09):

A. Inventory (before any creativity)
   - Build/refresh workspace/<program-slug>/primitive-inventory.md per
     Playbook 20 §2: every finding, duplicate, informational, and
     system fact (token lifetimes, rate budgets, rendering contexts,
     who-reads-what) as a FLAT capability statement — "read one object
     belonging to another user", never "critical IDOR!!".
   - Each row: preconditions, gives, needs, evidence link, status
     (Confirmed / Likely / Speculative). Flag Confirmed items older
     than 30 days as RE-PROOF NEEDED.
   - Heartbeat to me: inventory size, 3 strongest primitives, 3 most
     promising system facts.

B. Generate candidates (three passes, all on paper)
   - BACKWARDS from each crown jewel in templates/12-threat-model.md:
     what capability achieves it, which primitive gives that,
     recursively (Playbook 20 §3.1).
   - FORWARDS from each strong primitive using the five join questions:
     input-join, identity-join, context-join, precondition-removal,
     scaler (Playbook 20 §3.2).
   - PATTERN pass against Playbook 20 §4: IDOR+export · XSS+sensitive
     action · open redirect+OAuth · SSRF+metadata+role ·
     self-XSS+delivery · low-privilege write+privileged reader ·
     enumeration+reset/OTP budget · cache/realtime multipliers ·
     info leak as precondition-removal. One verdict line per pattern.
   - Draw survivors on templates/10-chain-canvas.md. Every edge gets a
     verb and a condition. Unlabelled edges get deleted. Max 7 nodes.

C. Score & select
   - Score survivors with the Playbook 20 §5 matrix (weakest-link
     status, interaction needed, accounts needed, impact rung, test
     cost/noise, duplicate risk).
   - Pick Chain #1 (highest score) and Chain #2 (highest impact with
     exactly one speculative link). Present both to me in ≤5 lines
     each: the path in words, demonstrated vs reasoned rung, proof cost.

D. Gate, then validate weakest-first
   - Write the cheapest falsification test for every Speculative/Likely
     link in the selected chains, plus fresh re-proofs for stale links.
   - Send me ONE grouped Tier B ask in the core/02 format (what / why /
     targets & rate ≤1 rps / expected noise / stop conditions) and
     WAIT for my yes. A yes covers exactly those runs.
   - After approval: re-prove links fresh in order, then run each
     composition ONCE, capturing evidence at every hand-off (the
     artefact one link produces visibly feeding the next). Abort a
     chain at its first dead link and record the control you found
     there — that negative is a deliverable, not a failure.

E. Report & teach
   - Each proved chain = ONE report (templates/03-finding-report.md,
     Playbook 20 §8 structure: impact first, primitives in brief,
     numbered composition, per-link fixes, the single cheapest fix
     that breaks the chain). Canvas attached as appendix. Run
     checklists/report-qa.md. I submit it myself — you draft only.
   - Each killed chain = one backlog entry: dead link, control
     discovered, revival condition.
   - Update templates/05-posture-analysis.md with the joins view
     (which boundaries held, which assumed the other side checked) and
     one sequence-correlation detection idea per attempted chain.
   - Update templates/06-learning-notes.md: each attempted chain's
     pattern explained from first principles, one self-check question
     per pattern, 3–5 flashcards filed.
   - Close with the standard heartbeat: chains proved / killed (why),
     inventory deltas, parked canvases, single best next action.

Teach as you go, in English. Define chaining terms on first use
(primitive, hand-off, rung) in one plain sentence each. If you expand
this brief with ideas of your own, list them at the end, per AGENTS.md §10.
---

*Before this prompt works:* you need primitives. With an empty
inventory the correct output is "inventory empty — return to Playbooks
01–05", and a good agent says exactly that instead of inventing a chain.
*Feeds from:* a Playbook 17 session often produces the delivery/reach
primitives this sprint consumes — see prompts/11-smuggling-and-cache-session.md.
