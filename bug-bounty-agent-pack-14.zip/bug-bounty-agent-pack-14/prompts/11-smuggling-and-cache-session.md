# Prompt 11 — Smuggling, Cache & Realtime Session (copy-paste)

Use for a Playbook 17 deep-dive session: WebSocket/realtime testing,
and — only if the safety gate below passes — HTTP request smuggling and
web cache work. Replace the <…> fields and paste the whole block. This
prompt is deliberately the most gated in the pack; that is the point.

---
Using this pack's AGENTS.md (read §§2, 4, 14 first — §14 is the extra
safety gate for this exact session) and Playbook 17, run a realtime /
smuggling / cache session for:

- Program: <program name> (<platform>)
- In-scope assets for this session: <exact hostnames/paths from the
  scope file — no wildcards in your head, only what the program wrote>
- Session focus: <REALTIME ONLY / CACHE ONLY / SMUGGLING (lab-verified
  experience, see gate) / FULL — gate decides what actually runs>
- Hunt workspace: workspace/<program-slug>/

## PART 0 — The gate (do this before ANY testing, report it to me)

1. Quote, verbatim, what the program rules say about: request smuggling,
   cache poisoning/deception, and "techniques that may affect other
   users". File the quotes in the scope intake. Outcomes:
   - Program PROHIBITS smuggling/cache work → those halves are CLOSED
     for this session. Realtime testing (my accounts only) may proceed.
     Tell me plainly and do not argue with the rules.
   - Program is SILENT/UNCLEAR → smuggling/cache stay closed; propose
     the exact question I should send the program (Tier B — I send it),
     and proceed with realtime + passive cache observation only.
   - Program EXPLICITLY ALLOWS it (note staging vs production) →
     proceed to step 2 for the allowed half only.
2. Confirm the pack's smuggling/cache safety checklist
   (checklists/smuggling-and-cache-safety.md, if present in this pack
   version) is completed and filed; if it is absent, apply AGENTS.md
   §14 + Playbook 17 §§5–7 rules directly and say that you did.
3. Confirm my lab status: if I have not completed the PortSwigger
   smuggling/cache labs, your default recommendation is LAB FIRST —
   run this session as realtime + teaching, and set the lab plan.
   I may overrule in writing; record my decision either way.

## PART 1 — Realtime (WebSocket / SSE / Socket.IO / gRPC-web)

4. Map first, from my own normal Account A/B sessions (Tier A
   observation): handshake URLs, auth mechanism (cookie / header /
   ticket / token-in-URL), Origin checking, message/event catalogue
   mined from JS bundles and docs. File in the target dossier.
5. Give me the per-message test plan from Playbook 17 §3 as a table —
   cross-account objects, room/channel joins, role-escalation events,
   field injection (role/user_id/tenant_id), sender spoofing, auth
   lifecycle (logout / password change / disable while socket lives) —
   each as its own falsifiable hypothesis, A/B accounts only.
6. Send ONE Tier B ask (core/02 format) for the crafted-message runs
   and WAIT. After approval: baseline first, one variable per message,
   one crafted message per hypothesis, CSWSH proof only with my own
   browser as the "victim". No flooding, no connection exhaustion,
   no joining real users' rooms — ever.

## PART 2 — Cache (only if Part 0 opened it)

7. Start passive: cache headers, Age/HIT behaviour on my own browsing;
   map the cache key with a UNIQUE CACHE BUSTER on every experimental
   URL (Playbook 17 §6.1 — no buster, no request, no exceptions).
8. Poisoning method is marker-only: a unique nonsense string via one
   candidate unkeyed input at a time, re-fetched without the input on
   the busted URL. NEVER poison a real, unbusted production URL.
   NEVER store executable content for other visitors.
9. Deception method is self-only: my Account A marker page, deceptive
   suffix, re-fetched logged out. My data is the only data involved.
10. Tier B ask (separate from Part 1's) before the first active cache
    probe, stating buster discipline, TTL awareness, and cleanup.

## PART 3 — Smuggling (only if Part 0 opened it AND lab gate passed)

11. Detection is TIMING-BASED FIRST (Playbook 17 §5.2 step 2): paired,
    non-destructive probes only, designed to affect no other user's
    request. A delay differential is a LEAD, not a finding — require it
    reproducible 3× against its control before saying even "Likely".
12. Any confirmation is a SEPARATE Tier B ask, afterwards, using only
    the self-only design: my smuggled prefix affecting only MY OWN next
    request. Never attempt to capture, redirect, or store another
    user's request. One probe, then stop and think (AGENTS.md §14.4).
13. Immediate stop conditions (any one): another user's traffic appears
    affected, production instability, program/WAF escalation message,
    or my "stop" — then preserve evidence and report to me FIRST.

## PART 4 — Close-out (always, whatever Parts 1–3 ran)

14. Findings → templates/03-finding-report.md (QA via
    checklists/report-qa.md; I submit). Primitives without standalone
    impact → templates/10-chain-canvas.md for the next chain sprint
    (prompts/10-chain-sprint.md).
15. Update templates/05-posture-analysis.md: per family tested, what the
    defender's telemetry would show (per-message audit gaps, front/back
    request-count mismatch, cache-key design) as 2–3 testable detection
    hypotheses. Update templates/06-learning-notes.md from first
    principles: request boundaries, cache keys, per-message auth —
    with self-check questions and 3–5 flashcards.
16. Final heartbeat: gate outcome (what was opened/closed and why),
    what ran, what was proved/killed, evidence locations, cleanup
    confirmation, single best next action. List any ideas you added
    beyond this brief, per AGENTS.md §10.

Teach throughout, in English, beginner-first: define front-end/back-end,
cache key, unkeyed input, desync, and handshake the first time each
appears — one plain sentence each, then the deep version.
---

*Reality check before pasting:* if the honest answer to Part 0 is
"closed", this prompt still earns its keep — a realtime-only session
plus a lab plan is the correct professional outcome, and forcing the
smuggling half onto a program that forbids it is how hunters get banned.
