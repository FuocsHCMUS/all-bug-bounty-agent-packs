# 00 — Kickoff

```
Read AGENTS.md and SKILL.md in full. Then:

1. Confirm the pack is intact: list the top-level dirs and say what each is for.
2. State the phase order and the GO/ASK/STOP rules in your own words, in <=10 lines.
3. State your default rate ceiling and your evidence standard.
4. Tell me the three things you need from me before the first packet.
5. Ask which program we are working.

Do not send any request yet. Do not install anything.
```

