# 01 — Scope intake

```
Program URL: <url>
Handle / enrolled account: <handle>
Scope text (verbatim):

<allow list, deny list, ports, wildcard semantics, out-of-scope notes>

Rules to honour: <rate limit, required header, forbidden test classes, disclosure terms>

Build workspace/<slug>/scope.json using schemas/scope.schema.json. Then:
- restate the scope back to me as allow / deny / ambiguous
- list every ambiguity and your proposed reading
- list what you will NOT touch
- set state.json to phase=INTAKE, enrolled=true

No packets until I confirm the interpretation.
```

