# 02 — Passive recon

```
Scope is confirmed. Run phase 2 passive-only:

- certificate transparency, archive.org CDX, DNS datasets, GitHub, ASN/netblock
- classify each asset static | app | api | admin | infra | third-party
- write surface.jsonl with source and first_seen
- dedupe by resolved host
- flag admin/internal/staging/CI/monitoring/cloud-bucket shaped assets

No active requests. When done: asset count by class, the ten most interesting, and which
active probes you want approved.
```

