# 03 — Surface map

```
Approved hosts: <list>. Map phase:

- crawl, extract routes and params, mine JS bundles
- build the role matrix: anon / user A / user B / elevated
- enumerate object ids and their types
- list upload paths, integrations, money paths, admin surfaces
- write notes/trust-boundaries.md: what does the server appear to trust, and why

Every endpoint gets a role row or an explicit "not interesting because…".
Report the top ten boundary candidates ranked by (impact x likelihood) / cost.
```

