# 04 — Hypothesise

```
From the boundary list, write >=10 hypotheses into hypotheses.jsonl:
{id, endpoint, class, claim, cheapest test, kill criterion, expected signal, cost}

Rules: one variable per test, falsifiable, cheapest first. Mix classes: at least three authz,
two injection, two state-machine, two parser/integration, one business-logic.

Then rank and show me the top five. Do not test yet.
```

