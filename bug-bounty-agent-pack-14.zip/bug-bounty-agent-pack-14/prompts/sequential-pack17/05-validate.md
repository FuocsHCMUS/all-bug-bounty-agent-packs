# 05 — Validate

```
Take hypothesis <id>. Restate the claim and the differential pair. Send the cheapest test.
Record raw request and response in findings/<id>/.

Then either:
- kill it with the reason, or
- confirm it and show the second independent method you will use.

One hypothesis at a time. Update the ledger after each.
```

