# 08 — Mine writeups

```
Topic: <class or product>. Run research/writeup-mining.md.

For each source: primitive, preconditions, detection signal, payload shape, why it worked,
what would break it. Then test each precondition against the target.

Cite everything. Emit hypotheses only for preconditions that actually hold.
```

