# 09 — Invent

```
Run research/technique-synthesis.md against <feature/boundary>.

Give me five hypotheses that are not lifted from a writeup. For each: the assumption you
inverted, prior art checked, cheapest falsification, expected signal, and what success would
imply about their architecture.

Label novelty honestly: new-to-target / new-to-class / possibly new-to-public.
```

