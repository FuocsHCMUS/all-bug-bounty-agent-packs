# 10 — Triage defence

```
Draft the report for <id> from reporting/report-template.md, then attack it as the triager:

- list every likely objection (informational, by design, duplicate, needs interaction,
  self-XSS, already known)
- answer each with evidence from the capture
- propose the severity you expect them to assign and defend yours with the impact narrative
- flag anything that needs a stronger impact proof before submission
```

