# 12 — Posture and lesson

```
Run posture/analysis-framework.md for <id>:
- control class that failed, SDLC phase, maturity level, blast radius
- compensating controls, what they do well, top three fixes in order
- detection engineering: what log or rule would have caught this
- concept ladder: five rungs from first principles to this bug, each with a one-line exercise

Write posture/F-<id>.md. Assume I am a beginner: define every term at first use.
```

