# 13 — Wrap

```
End of session. Update session-log.md, state.json, hypotheses.jsonl.

Give me: phase reached, confirmed/killed/blocked counts, open hypotheses with next cheapest
test, blockers, pending confirmations, and the next three actions.

Then list what you learned about this target's security posture in five bullets.
```

