# References — Modern Sources, 2024–2026 (categories, trust, how to find)

This is a *map of source categories*, not a link dump. Link dumps rot,
get typosquatted, and teach clicking instead of judging. For each category:
what it is for, how to find the genuine one, and how far to trust it.
Every source you actually use in a hunt gets logged and graded in the
research log (Template 14) — this file starts that judgement, it doesn't
replace it.

Rules that apply to the whole file:

- **Prefer primary sources.** The advisory, the CVE record, the original
  research post — over every summary, thread, video, or AI answer about it.
- **Verify the domain out-of-band the first time** (search the organisation's
  name, check you landed on the well-known domain, bookmark *that*). Never
  follow a "security resource" link from an untrusted post to a login page.
- **No invented URLs.** Only long-established, well-known domains are named
  below. If you are not sure of a domain, search for the organisation by
  name instead of guessing an address — a guessed URL that resolves is a
  phishing lesson waiting to happen.
- **Dates matter.** Techniques and affected versions move fast in
  2024–2026 (especially AI/LLM-app and identity research). Record the
  publication date of everything you rely on; prefer the newest primary
  revision and note when a source predates a major patch.

---

## 1. Primary vulnerability intelligence

### CISA Known Exploited Vulnerabilities (KEV) — cisa.gov
- **What for:** the short list of CVEs *confirmed exploited in the wild*.
  In triage terms: "attackers already use this." Highest-priority input
  to CVE prioritisation in this pack.
- **Find it:** search "CISA KEV catalog" → the cisa.gov catalogue page /
  downloadable feed.
- **Trust:** high, for the fact of exploitation. KEV says nothing about
  *your* target's exposure — matching is still Template 07's job.

### NVD (National Vulnerability Database) — nvd.nist.gov
- **What for:** the canonical CVE record — description, CVSS, references,
  affected product/version data (CPEs).
- **Trust:** high for the record itself; enrichment (scores, version data)
  can lag or be disputed — cross-check the vendor advisory when it matters.

### GHSA (GitHub Security Advisories / Advisory Database)
- **What for:** vulnerabilities in open-source packages and ecosystems
  (npm, PyPI, Maven…), often with the *fixed version* and the vulnerable
  code range stated precisely — gold for dependency/supply-chain hunts.
- **Find it:** GitHub's advisory database (searchable from GitHub itself).
- **Trust:** high; frequently maintained by the project's own maintainers.

### Vendor security advisories & PSIRT blogs
- **What for:** the affected versions, preconditions, and fix guidance
  *from the maker* — the primary source every summary summarises.
- **Find it:** "<vendor> security advisories" / "<vendor> PSIRT" from the
  vendor's own domain.
- **Trust:** highest for scope-of-impact; read critically anyway — vendors
  occasionally minimise. Note wording, don't inherit conclusions blindly.

### Exploit-DB & public PoC repositories
- **What for:** understanding exploitation mechanics and preconditions.
- **Trust & safety:** mixed by nature. Reading is research; *running* a
  PoC is a Tier B action under this pack, in scope, once, minimally —
  and public PoCs can be booby-trapped. Read code before running anything,
  prefer well-known authors/repos, run in the lab first.

## 2. Research & learning — the craft sources

### PortSwigger Research & Web Security Academy — portswigger.net
- **What for:** (a) Academy: the structured, lab-backed curriculum for web
  vulnerability classes — this pack's default "learn it from zero" route;
  (b) Research: original, primary research (smuggling, cache, parser
  differentials and more) that *defines* several modern bug classes.
- **Trust:** high — it is a primary source for its own research. Still log
  dates: Academy guidance tracks current browser/server behaviour.

### HackTricks
- **What for:** a vast community wiki of techniques (web, cloud, privesc,
  AD…) — best used as an *index of ideas to verify*, with checklists for
  "what else exists in this class."
- **Find it:** search "HackTricks" by name; verify you are on the
  long-standing book/wiki site, not a copy.
- **Trust:** medium — uneven, community-edited, occasionally stale. Never
  the sole source for a claim that reaches a report (Template 14 ladder).

### PayloadsAllTheThings
- **What for:** payload and bypass *catalogues* per vulnerability class —
  raw material for building a test, and a map of how much variation a class has.
- **Find it:** the well-known GitHub repository of that name.
- **Trust:** medium — a catalogue, not an explanation. Understand *why* a
  payload works (from Academy/research) before using any of it, and adapt
  to benign, self-only proofs under this pack's rules.

### ProjectDiscovery blog & open-source tooling write-ups
- **What for:** modern recon/scanning methodology, template-based
  detection thinking, and research on newly disclosed issues at scale.
- **Trust:** good for method; remember the publisher also sells tooling —
  separate the technique (verifiable) from the product framing (marketing).

### Individual researcher blogs & conference talks
- **What for:** the frontier — novel classes appear here years before
  curricula. Talks from established security conferences and long-running
  researcher blogs are where Playbook 08 (creative R&D) feeds.
- **Trust:** per-author, per-claim. A famous name raises prior confidence;
  it never replaces verification, and talk demos are edited performances —
  preconditions hide in the Q&A and the paper, so find the paper.

## 3. Platform & disclosure sources

### HackerOne — hackerone.com (Hacktivity, disclosed reports, docs)
- **What for:** disclosed reports = real, triaged, real-world findings —
  the single best corpus for "what do companies actually pay for and why."
  Platform docs define program mechanics and policy baselines.
- **Trust:** high for the report's existence/outcome; individual report
  *quality varies* — a paid report proves impact there, not transferability here.

### Bugcrowd — bugcrowd.com (disclosures, Vulnerability Rating Taxonomy)
- **What for:** disclosed findings plus the VRT — a shared severity/
  priority vocabulary useful when drafting Bugcrowd-style reports
  (Template 04).
- **Trust:** as HackerOne above. The VRT is a *prioritisation guide*,
  not a law — individual programs override it.

### Other platforms (Intigriti, YesWeHack, Synack, and national/regional platforms)
- **What for:** same roles — disclosures, taxonomies, program rules —
  each with its own norms. The transferable skill is reading *the specific
  program's* page as the law for that hunt (Core 04), not platform habit.

## 4. Vendor & big-tech security blogs

### Google / Alphabet security research (Project Zero, Google Security Blog)
- **What for:** deep primary research (browser, Android, exploitation
  mitigations) and large-scale abuse/defence lessons. Project Zero's
  write-ups are masterclasses in evidence discipline — read them for
  *method* even when the target class isn't yours.
- **Trust:** high as primary research. Difficulty is high; use Template 14
  to extract the one transferable claim rather than "understanding it all."

### Microsoft, Apple, Meta, Amazon/AWS, Cloudflare (vendor security blogs)
- **What for:** how the platforms you test *on* are defended and broken:
  identity (Microsoft), web platform (Google/Apple/Meta engineering),
  edge/cache behaviour (Cloudflare), cloud (AWS) — plus their advisories.
- **Trust:** high for their own platforms' behaviour; remember each is
  also a narrator with interests — primary for facts, labelled for framing.

### Cloud provider security documentation (AWS / Azure / GCP)
- **What for:** the *documented* behaviour your SSRF/IAM/serverless
  hypotheses must match — shared-responsibility models, metadata-service
  design, IAM policy semantics.
- **Trust:** highest for intended behaviour. Bugs live in the gap between
  documented and actual — which is why you cite the doc, then test the gap.

## 5. CTF & writeup ecosystem

### CTFtime — ctftime.org
- **What for:** the calendar and archive of CTF competitions, team
  rankings, and links to writeups. Your route to *timed, legal, hard*
  practice and to the writeup corpus Playbook 07 mines.
- **Trust:** high as an index. Writeups themselves: per-author (below).

### CTF writeups (team blogs, GitHub collections, CTFtime links)
- **What for:** transferable *primitives* — parser quirks, crypto-misuse
  patterns, race windows — in a form you can re-implement in a lab.
- **Trust:** medium. CTF targets are deliberately fragile; extract the
  developer-assumption lesson (Template 08), never assume the trick
  transfers to production unchanged. That transfer is a hypothesis.

### Disclosed-report & writeup aggregators (newsletters, "top reports" lists)
- **What for:** discovery — finding the primary writeup worth reading.
- **Trust:** low-to-medium *as sources*; fine as indexes. Always land on,
  read, and cite the original (Template 14 §5 exists because of this row).

## 6. Detection & defence sources (feed Core 10)

### MITRE ATT&CK — attack.mitre.org
- **What for:** the shared TTP vocabulary + per-technique data sources —
  the starting point for every detection idea's telemetry question.
- **Trust:** high; verify technique names/IDs at the site at time of use
  (editions change), per Core 10 §3.

### Sigma community rules & detection-engineering writing
- **What for:** real, reviewable detection logic to *read* — the fastest
  way to learn what a buildable rule looks like (Core 10 §5).
- **Find it:** the Sigma project's well-known GitHub organisation.
- **Trust:** good as worked examples; production-fit is always local
  (baselines differ) — which is itself the lesson.

### CISA / national-CERT advisories & guidance
- **What for:** defender-side priorities, hardening baselines, and
  incident lessons that make posture recommendations (Template 05)
  concrete and citable.
- **Trust:** high for guidance; written for broad audiences, so adapt —
  don't copy-paste — to the specific target's context.

## 7. AI/LLM-era sources (2024–2026 growth area — extra scepticism)

- **What exists:** vendor AI-security blogs, OWASP's LLM/AI project
  materials (search OWASP by name for the current LLM Top 10 / GenAI
  resources), and a flood of low-quality generated content riding the topic.
- **What for:** threat vocabulary for AI-app hunts (Playbook 11) —
  prompt-injection classes, agent-tool abuse, data-leakage patterns.
- **Trust:** lowest default of any section here. The field is new, hype
  is monetised, and AI-generated "research" citing itself is common.
  Rule: an AI-security claim needs a *primary* demonstration (a paper,
  a vendor advisory, a reproducible lab) or it stays Unverified in
  Template 14, usable only as a hypothesis prompt.

## 8. How to keep this file alive

- At each weekly review (Template 15): add sources that earned trust,
  demote sources that misled you — with the Template 14 evidence for both.
- Retire nothing silently: a source that was good in 2024 and stale by
  2026 gets a dated note, not a deletion. Your future self needs the history.
- If a category above ever points you somewhere that asks for credentials,
  payment, or a download before showing content — stop. None of the
  categories above need that to *read* them, and the detour is not worth
  the risk. Tell the operator; find the primary source by another route.
