# Knowledge base schema

`workspace/<program>/notes/techniques.md` — one block per technique you meet.

```
### <short name>
source: <url | own>
primitive: <one line>
preconditions: <bullets>
signal: <what confirms it>
status on target: untested | holds | fails | confirmed
delta from prior art: <if any>
```

Rules: a technique with `status: fails` stays in the file with the reason — it is the map of
their hardening. Prune only at wrap-up, and only if the reason is recorded.

Cross-program: promote reusable primitives to `workspace/_kb/techniques.md` and drop
target-specific detail.

