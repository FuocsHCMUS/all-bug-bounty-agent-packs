# Posture analysis framework

Run for every finding. Output goes to `posture/F-xxx.md`. Audience: the operator, a student.
Goal: they can explain the root cause from first principles and see where in the org it lives.

## 1. Control class that failed
Pick from: preventive, detective, corrective. Then the specific control: input validation,
output encoding, object-level authz, session binding, secret management, dependency patching,
config baseline, logging, alerting, review gate, test coverage.

## 2. SDLC phase where it should have been caught
Requirements -> design -> implementation -> review -> test -> deploy -> runtime detection.
Name the phase and the artefact that would have caught it (a threat-model line, a lint rule, a
test case, a scanner gate, a runtime rule).

## 3. Maturity ladder (0-5)
0 absent, 1 ad hoc, 2 documented, 3 enforced, 4 measured, 5 optimised. Rate the *specific*
control, not the company. Justify with what you observed, and note if the sample is thin.

## 4. Blast radius if repeated
One endpoint, one service, one tenant boundary, the whole product, the supply chain. Reason
from the architecture you mapped, not from this one bug.

## 5. Compensating controls observed
WAF rules, short token TTL, read-only DB user, network segmentation, audit logging. These
explain why the bug is not worse and belong in the report's remediation section.

## 6. What they do well (evidence only)
e.g. consistent 404 on foreign ids elsewhere, strict CSP, per-request nonce, good cache-key
hygiene. Name the control and the observation. No generic praise.

## 7. Top three fixes, ordered
Cheapest-to-adopt and highest-leverage first. Each with the class it closes and the regression
test that proves it stays closed.

## 8. Detection engineering
What log line, metric or rule would have caught this at runtime? Write the pseudo-rule. Note
whether the data is even collected.

## 9. Concept ladder for the operator
Five rungs, each one sentence, each with a one-line exercise:
```
rung 1: <most basic true statement>
rung 2: <the mechanism it implies>
rung 3: <where the assumption appears>
rung 4: <what breaks when it is missing>
rung 5: <this bug, named>
```
Define every term at first use. No hand-waving.

## 10. Honesty box
Sample size, what you did not test, where you might be wrong.

