# Building concept ladders

A ladder takes a beginner from a true, boring statement to the bug, in five rungs, without a
single unexplained term.

## Rules
1. Rung 1 is uncontroversial and concrete. "A row in a database is a record the app owns."
2. Each rung adds exactly one mechanism.
3. Rung 5 is the bug, named precisely, and maps to the finding.
4. Every rung has an exercise the operator can do in five minutes.
5. No rung may contain a word introduced later.

## Example (IDOR)
1. An invoice is a row the app stores with an owner column.
2. The app loads a row by the id in your request.
3. The load must also compare that row's owner to your session.
4. If it compares only sometimes, the missing comparison is the bug.
5. On `/api/invoices/{id}` the comparison is absent for `GET`, so any session reads any invoice.
   Exercise: swap two ids between two accounts and diff the bodies.

## Example (SSRF)
1. Some features make the server fetch a URL you supply.
2. The server can reach addresses you cannot: loopback, private ranges, metadata.
3. Filters usually validate the string, the resolver picks the address.
4. A string that passes the filter but resolves internally is the bypass.
5. A redirect to `169.254.169.254` on the avatar importer returns role credentials.
   Exercise: point the importer at your own listener and read the User-Agent it sends.

## Failure modes
Too abstract at rung 1. A rung that is a definition instead of a mechanism. A rung 5 that is
vague ("authz is broken"). Exercises that need paid tools.

