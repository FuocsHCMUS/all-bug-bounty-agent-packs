# Posture note — F-xxx

Finding: / Severity:
Control class: / SDLC phase:
Maturity (0-5) + justification:
Blast radius if repeated:
Compensating controls:
What they do well (evidence):
Top three fixes:
1.
2.
3.
Detection: <pseudo-rule> | data collected? yes/no
Sample limits / where I might be wrong:

## Concept ladder
1.
2.
3.
4.
5.

## Operator exercises
-

