# Prior art and novelty

## Why
"Novel" is a claim. Unchecked, it makes you look naive in a report.

## Check in this order
1. Program's disclosed reports for the same class.
2. The vendor's own changelog and advisories.
3. NVD / GitHub advisories for the product.
4. A targeted search for the primitive, not the payload.
5. Conference archives (Black Hat, DEF CON, OWASP, PortSwigger research).

## Labels
- `new-to-target`: not in their disclosed corpus. Common, still valuable.
- `new-to-class`: a variant of a known primitive. Fine, describe the delta.
- `possibly-new`: no prior art found. Needs a paragraph on why the delta matters.

## Reporting a possibly-new technique
Include: the base primitive, the delta, why the base defence does not cover the delta, and the
minimal repro. Never lead with "novel" — lead with impact.

## After the report
If it lands, write it up properly for the operator's portfolio (with permission). That is how a
student builds a reputation that is not "I ran nuclei".

