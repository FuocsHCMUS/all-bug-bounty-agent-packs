# Comms and disclosure

## With the program
- One thread per finding. No new findings buried in replies.
- Answer triager questions within a day, briefly, with evidence.
- Ask before testing anything they flag as fragile.
- Accept scope narrowing without argument.

## With the company (direct programs)
Same rules, plus: name a single technical contact, keep UTC timestamps, and never CC a
marketing address with raw PoC.

## Disclosure
Default to the program's policy. If silent, ask. Coordinate a date before publishing. Credit
the team that fixed it, not just yourself. Publish only after the fix is deployed or the window
has passed.

## Boundaries
- Do not post a PoC while the bug is open unless the program allows it.
- Do not name a customer in a screenshot without redacting.
- Do not imply the company was negligent; describe the control that was missing.

