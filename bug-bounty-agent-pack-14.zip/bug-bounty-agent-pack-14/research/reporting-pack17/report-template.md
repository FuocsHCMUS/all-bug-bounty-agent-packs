# <Class> in <asset> allows <impact>

## Summary
Two or three sentences: what, where, who can do it, what they gain. No preamble.

## Severity
`CVSS:3.1/AV:../AC:../PR:../UI:../S:../C:../I:../A:..` -> score, band.
One line on why the band is right, referencing the impact below.

## Affected asset
URL, method, parameter, role required, environment. Exact and minimal.

## Preconditions
Bullets. If any is unusual, say how an attacker reaches it.

## Reproduction
1. Numbered, from a clean session.
2. Include the raw request in a fenced block.
3. State the expected vs observed difference.

## Evidence
- `req.txt`, `res.txt`, hashes, timestamps
- screenshots cropped to the relevant region, URL visible
- any OOB callback log

## Impact
Technical: what is read, written, executed, or spent.
Business: whose data, how many records, what a customer notices, regulatory angle if real.

## Root cause
The exact missing check, in one paragraph, at the level of the code path. If you saw the
framework, name the safe API that should have been used.

## Remediation
Short term: the patch that stops it today.
Long term: the control that stops the class (middleware, lint rule, test, type, gateway policy).

## Detection
What to alert on. A log field, a metric, a rule sketch.

## References
Advisories, docs, sibling findings.

## Timeline
Discovered / reported / triaged / fixed / retested — with dates and UTC times.

