# Severity guide

Use CVSS 3.1 as the baseline (`tools/cvss.py`), then sanity-check against program precedent.

## Anchors
- **Critical**: unauth RCE, mass PII, auth bypass to any account, cloud takeover via metadata.
- **High**: cross-tenant read of sensitive data, stored XSS in an admin context, SQLi with
  write, SSRF to internal admin with impact.
- **Medium**: single-tenant IDOR with PII, reflected XSS with a real delivery path, blind SSRF
  with proven internal reach, logic bug with money impact but bounded.
- **Low**: missing headers, verbose errors, expired cert, open redirect alone, blind SSRF to
  DNS only.
- **Informational**: best-practice gaps with no exploitable path.

## Common downgrades and how to argue
- Self-XSS -> show the paste-free path.
- Reflected XSS -> show the link, and whether the app is an admin console.
- Blind SSRF -> prove internal reach with a distinguishable response or timing.
- IDOR on non-sensitive data -> show the *volume* and the field sensitivity.
- Missing rate limit -> show the practical yield in a fixed time.

## Consistency check
Read your vector back against the narrative. `AV:N` with "requires local access" is wrong.
`C:H` with "returns a username" is wrong. Fix the vector or the claim.

## Never
Round up for attention. Inflate with a chain you did not test. Copy a score from a similar
report without re-deriving.

