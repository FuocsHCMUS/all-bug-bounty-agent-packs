# Triage defence

Triage is a human under load deciding whether to spend engineering time. Your job is to make
"yes" cheap.

## Anticipate the downgrade
| Objection | Pre-empt with |
|---|---|
| "Informational" | A named control that failed and a concrete gain |
| "By design" | The docs or UI that promise the opposite |
| "Duplicate" | Search the disclosed corpus first; state what is different |
| "Needs user interaction" | The delivery vector, and its realism |
| "Self-XSS" | The paste-free path, or the social step made explicit |
| "Already known internally" | The version/build that shows it is not fixed |
| "Low because no PII" | What non-PII still buys (tokens, actions, money) |
| "Can't reproduce" | Exact steps, exact role, exact headers, clean-session replay |

## Writing for the triager
- First line is the impact, not the backstory.
- Every claim has a capture within one screen of it.
- No hedging words. "Returns" not "may return".
- One finding, one report.
- State what you did *not* test so they know the edges.

## Escalation
Ask for reconsideration once, with new evidence. Never argue about CVSS; argue about impact.
If a program marks it informational, accept it, fix the report for next time, and move on.

## What loses reports
Wall-of-text PoCs, screenshots without URLs, "as an attacker could potentially", a severity
that contradicts the narrative, and asking the triager to do the reproduction.

