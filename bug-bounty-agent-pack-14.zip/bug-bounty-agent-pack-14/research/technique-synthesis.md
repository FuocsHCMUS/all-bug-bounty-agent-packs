# Technique synthesis

Purpose: produce hypotheses that are not in any writeup.

## The abstraction ladder
Move up to move sideways:

```
payload -> primitive -> precondition -> assumption -> design decision
```
A bug is always an unmet assumption. Go up until you find the assumption, then look for other
places the same assumption is made.

## Operators

1. **Assumption inversion** — "the server assumes X". Write the opposite. What if the header is
   absent, duplicated, both values, a different case, an array, a null?
2. **Parser differential** — two components read the same bytes. Client vs proxy vs origin vs
   queue vs renderer. Find the field where they disagree.
3. **State-machine abuse** — enumerate legal transitions, then the illegal ones: skip, repeat,
   reorder, interleave, resume-after-cancel, act as a stale actor.
4. **Oracle design** — when the response is opaque, build a side channel: timing, size, ordering,
   error class, second-order effect, notification, cache state.
5. **Primitive composition** — A gives read, B gives write, C gives execution. Chain the halves.
6. **Negative space** — test what the docs say is impossible: the deprecated endpoint, the old
   version, the mobile client, the internal header, the "not supported" method.
7. **Type and shape confusion** — string vs int, array vs scalar, object vs null, unicode
   normalisation, duplicate JSON keys.
8. **Scope creep by design** — shared components, multi-tenant edges, "trusted partner" paths,
   admin impersonation features.
9. **Timing and ordering** — the window between check and act; the order of validation steps.
10. **Semantic gaps** — the rule is enforced in the UI, in the client, in a cron job, or in a
    report — but not on the write path.

## Novelty gate
Before writing a hypothesis: is this a known class with a new coat? Search once. Label
`new-to-target` / `new-to-class` / `possibly-new`. Only the last needs a prior-art paragraph.

## Hypothesis row (extra fields)
```
assumption_inverted:
prior_art: <checked | none found | same class as X>
cheapest_falsification:
implied_architecture: <what success would tell us>
novelty: new-to-target | new-to-class | possibly-new
```

## Discipline
Five sharp hypotheses beat twenty vague ones. Every one carries a kill criterion. Kill your
favourites first — they are the ones you are least able to judge.

