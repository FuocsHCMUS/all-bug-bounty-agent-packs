# Writeup mining

Purpose: convert public knowledge into target-specific hypotheses.

## Source order
1. Vendor advisories and fix commits (most reliable — the diff tells you the bug).
2. Conference whitepapers and slides.
3. Program-disclosed reports (HackerOne/Bugcrowd disclosure, huntr).
4. Maintainer blogs with repro.
5. CTF writeups — for primitives, not for targets.
6. Listicles — last, and only for payload shapes.

## Extraction template (one per source)
```
source: <url>
primitive: <the broken assumption, one line>
preconditions: <bullets — framework, version, config, role, header, timing>
detection signal: <what you would see if it works>
payload shape: <shape, not the literal>
why it worked: <mechanism>
what breaks it: <fixes, WAFs, versions>
```

## Translation gate
For each precondition: "on this target, true if ___". Test the cheapest. Two failures = drop.

## Novelty note
If the primitive is generic (e.g. "parser disagreement on duplicate headers"), you are not
copying — you are applying. Say so honestly.

## Anti-patterns
Saving links without extraction. Reading a class for an hour with no test. Trusting a 2019
payload against a 2026 stack without checking the underlying behaviour still exists.

