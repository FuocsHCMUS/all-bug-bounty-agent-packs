#!/usr/bin/env python3
"""cve_lookup_nvd.py — Query the public NVD API (v2.0) for CVEs by keyword.
This contacts NVD (a research source), never the target. Respect NVD rate limits:
without an API key the public limit is low — keep queries few and specific.
Usage: python cve_lookup_nvd.py --keyword "apache http server 2.4.49" [--api-key KEY] [--limit 10]
Stdlib only. The optional key can also come from the NVD_API_KEY env var."""
import argparse, json, os, sys, urllib.parse, urllib.request

def main():
    ap = argparse.ArgumentParser(description="Look up CVEs on NVD by keyword.")
    ap.add_argument("--keyword", required=True, help="e.g. product + version")
    ap.add_argument("--api-key", default=os.environ.get("NVD_API_KEY", ""))
    ap.add_argument("--limit", type=int, default=10)
    a = ap.parse_args()
    q = urllib.parse.urlencode({"keywordSearch": a.keyword, "resultsPerPage": min(a.limit, 50)})
    req = urllib.request.Request(f"https://services.nvd.nist.gov/rest/json/cves/2.0?{q}",
                                 headers={"User-Agent": "bb19-cve-lookup/1.0"})
    if a.api_key:
        req.add_header("apiKey", a.api_key)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.load(r)
    except Exception as e:
        print(f"NVD query failed: {e}")
        print("Fallback: search NVD/vendor advisories in a browser and record them in templates/cve-match.md.")
        return 1
    vulns = data.get("vulnerabilities", [])
    print(f"NVD results for '{a.keyword}': {len(vulns)} shown")
    for v in vulns:
        cve = v.get("cve", {})
        desc = next((d["value"] for d in cve.get("descriptions", []) if d.get("lang") == "en"), "")[:200]
        print(f"  {cve.get('id', '?')}  published={cve.get('published', '?')[:10]}  {desc}")
    print("Record matches in templates/cve-match.md — affected range and a SAFE differentiator, not a PoC.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
