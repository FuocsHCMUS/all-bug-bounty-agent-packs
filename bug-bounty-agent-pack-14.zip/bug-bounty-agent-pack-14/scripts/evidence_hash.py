#!/usr/bin/env python3
"""evidence_hash.py — SHA-256 evidence manifest: create and verify.

Offline only — makes NO network requests. Hashes every file in a folder
(recursively by default) and writes a manifest so that later you can
prove an evidence file has not changed since you captured it:

  - Create:  hash the folder -> manifest CSV (default) or Markdown,
    one row per file: relative filename, size in bytes, SHA-256,
    and the UTC timestamp when the manifest was made.
  - Verify:  ``--verify <manifest>`` re-hashes the folder and compares
    against that manifest, reporting OK / MISMATCH / MISSING per file
    and flagging files present now that were not in the manifest.
    Exit code 0 = everything matches, 2 = any mismatch/missing/extra
    or a usage error.

The manifest file itself is always excluded from hashing (otherwise it
could never match its own contents). Keep originals in the target's
local ``evidence/`` folder and share only hashes + redacted copies
(see AGENTS.md section 9).

Stdlib only. Python 3.14+ (Windows 11 friendly).

Usage:
    py -3.14 evidence_hash.py evidence\\
    py -3.14 evidence_hash.py evidence\\ --manifest evidence\\manifest.md --format md
    py -3.14 evidence_hash.py evidence\\ --verify evidence\\manifest.csv
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import sys
from datetime import datetime, timezone
from pathlib import Path

CHUNK = 1024 * 1024  # 1 MiB — stream big captures instead of loading them


def sha256_of(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while chunk := fh.read(CHUNK):
            digest.update(chunk)
    return digest.hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def collect(folder: Path, exclude: set[Path], recursive: bool) -> list[Path]:
    candidates = folder.rglob("*") if recursive else folder.glob("*")
    files = [
        p for p in candidates
        if p.is_file() and p.resolve() not in exclude
    ]
    return sorted(files, key=lambda p: p.relative_to(folder).as_posix().lower())


def build_rows(folder: Path, files: list[Path], stamp: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for f in files:
        rows.append({
            "filename": f.relative_to(folder).as_posix(),
            "size_bytes": str(f.stat().st_size),
            "sha256": sha256_of(f),
            "hashed_at_utc": stamp,
        })
    return rows


def render_csv(rows: list[dict[str, str]]) -> str:
    buf = io.StringIO(newline="")
    writer = csv.DictWriter(
        buf, fieldnames=["filename", "size_bytes", "sha256", "hashed_at_utc"]
    )
    writer.writeheader()
    writer.writerows(rows)
    return buf.getvalue()


def render_md(rows: list[dict[str, str]], folder: Path, stamp: str) -> str:
    lines = [
        "# Evidence Manifest",
        "",
        f"Folder: `{folder}`  ",
        f"Created (UTC): {stamp}  ",
        f"Files: {len(rows)}",
        "",
        "| Filename | Size (bytes) | SHA-256 | Hashed at (UTC) |",
        "|---|---:|---|---|",
    ]
    for r in rows:
        name = r["filename"].replace("|", "\\|")
        lines.append(
            f"| {name} | {r['size_bytes']} | `{r['sha256']}` | {r['hashed_at_utc']} |"
        )
    lines.append("")
    lines.append("Verify with: `py -3.14 evidence_hash.py <folder> --verify <this file>`")
    return "\n".join(lines) + "\n"


def parse_manifest(path: Path) -> dict[str, tuple[str, str]]:
    """Return {filename: (size, sha256)} from a CSV or Markdown manifest."""
    text = path.read_text(encoding="utf-8", errors="replace")
    result: dict[str, tuple[str, str]] = {}
    if path.suffix.lower() == ".md" or text.lstrip().startswith("#"):
        for line in text.splitlines():
            line = line.strip()
            if not line.startswith("|") or "---" in line or "Filename" in line:
                continue
            cells = [c.strip().strip("`") for c in line.strip("|").split("|")]
            if len(cells) >= 3 and cells[2]:
                result[cells[0].replace("\\|", "|")] = (cells[1], cells[2].lower())
        return result
    for row in csv.DictReader(io.StringIO(text)):
        name = (row.get("filename") or "").strip()
        if name:
            result[name] = (
                (row.get("size_bytes") or "").strip(),
                (row.get("sha256") or "").strip().lower(),
            )
    return result


def do_verify(folder: Path, manifest: Path, recursive: bool) -> int:
    if not manifest.exists():
        print(f"ERROR: manifest not found: {manifest}", file=sys.stderr)
        return 2
    expected = parse_manifest(manifest)
    if not expected:
        print("ERROR: no rows parsed from manifest.", file=sys.stderr)
        return 2
    files = collect(folder, {manifest.resolve()}, recursive)
    current = {
        f.relative_to(folder).as_posix(): (str(f.stat().st_size), sha256_of(f))
        for f in files
    }
    ok = True
    for name in sorted(expected):
        size, digest = expected[name]
        if name not in current:
            print(f"MISSING   {name}")
            ok = False
        elif current[name] != (size, digest):
            print(f"MISMATCH  {name} (size and/or SHA-256 differ)")
            ok = False
        else:
            print(f"OK        {name}")
    for name in sorted(set(current) - set(expected)):
        print(f"EXTRA     {name} (present now, not in manifest)")
        ok = False
    print("")
    print("VERIFY PASSED: all files match the manifest." if ok
          else "VERIFY FAILED: see MISMATCH / MISSING / EXTRA rows above.")
    return 0 if ok else 2


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Create or verify a SHA-256 evidence manifest for a folder (offline)."
    )
    ap.add_argument("folder", type=Path, help="Folder whose files should be hashed")
    ap.add_argument("--manifest", type=Path,
                    help="Manifest path to write (default: <folder>/evidence-manifest.csv)")
    ap.add_argument("--format", choices=("csv", "md"), default=None,
                    help="Manifest format (default: csv, or md if --manifest ends in .md)")
    ap.add_argument("--verify", type=Path, metavar="MANIFEST",
                    help="Verify the folder against this existing manifest instead")
    ap.add_argument("--no-recursive", action="store_true",
                    help="Only hash files directly in the folder (default: recursive)")
    args = ap.parse_args(argv)

    if not args.folder.is_dir():
        print(f"ERROR: not a folder: {args.folder}", file=sys.stderr)
        return 2
    recursive = not args.no_recursive

    if args.verify:
        return do_verify(args.folder, args.verify, recursive)

    fmt = args.format or ("md" if args.manifest and args.manifest.suffix.lower() == ".md"
                          else "csv")
    manifest = args.manifest or (args.folder / f"evidence-manifest.{fmt}")
    stamp = utc_now()
    files = collect(args.folder, {manifest.resolve()}, recursive)
    if not files:
        print(f"ERROR: no files found in {args.folder}", file=sys.stderr)
        return 2
    rows = build_rows(args.folder, files, stamp)
    content = render_md(rows, args.folder, stamp) if fmt == "md" else render_csv(rows)
    manifest.write_text(content, encoding="utf-8", newline="")
    print(f"Wrote {manifest} ({len(rows)} files, format={fmt})")
    for r in rows:
        print(f"  {r['sha256'][:16]}...  {r['size_bytes']:>10}  {r['filename']}")
    print("Keep this manifest with the evidence log; re-run with --verify to prove integrity.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
