#!/usr/bin/env python3
"""har_analyzer.py — offline analysis of a browser-exported HAR file.

OFFLINE ONLY — this tool makes NO network requests, ever. It reads a
``.har`` file (JSON) that the operator exported from their *own* browser
(DevTools -> Network -> Export HAR) and summarises it locally.

What it reports:
  - unique hosts, paths, methods and status codes
  - interesting entries worth a second look:
      * requests carrying auth-like headers (header NAMES only — values
        are never read into the report, never printed)
      * 4xx / 5xx responses
      * JSON API responses
      * query / path parameters that look like object IDs (numeric,
        UUID, or long hex) — parameter names and value *shape* only,
        never the value itself

Redaction by design: header values, cookie values, query-string values,
request bodies and response bodies are never printed. If you need the
raw values, open the HAR yourself in a local viewer — do not paste a
raw HAR into a chat or report (it usually contains session tokens).

Stdlib only. Python 3.14+ (Windows 11 friendly).

Usage:
    py -3.14 har_analyzer.py capture.har
    py -3.14 har_analyzer.py capture.har --out har-summary.txt
    py -3.14 har_analyzer.py capture.har --json har-summary.json
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse, parse_qsl

AUTH_HEADER_NAMES = {
    "authorization", "cookie", "x-api-key", "x-auth-token",
    "x-access-token", "x-csrf-token", "x-xsrf-token", "proxy-authorization",
}
UUID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)
ID_PARAM_RE = re.compile(r"(^|[_-])(id|uid|uuid|guid|user|account|tenant|org|"
                         r"project|order|invoice|file|doc|object)([_-]|$)", re.I)


def value_shape(value: str) -> str | None:
    """Classify a value's *shape* only. The value itself is never returned."""
    if UUID_RE.match(value):
        return "uuid"
    if value.isdigit() and len(value) >= 1:
        return "numeric"
    if re.fullmatch(r"[0-9a-fA-F]{16,}", value):
        return "long-hex"
    return None


def id_like_params(url: str) -> list[str]:
    """Return descriptions like 'userId (numeric)' — names + shapes only."""
    parsed = urlparse(url)
    found: list[str] = []
    # Query-string parameters.
    for name, val in parse_qsl(parsed.query, keep_blank_values=True):
        shape = value_shape(val)
        if shape or ID_PARAM_RE.search(name):
            found.append(f"{name} ({shape or 'id-like name'})")
    # Path segments that look like IDs (segment value itself is not shown).
    for seg in parsed.path.split("/"):
        shape = value_shape(seg)
        if shape:
            found.append(f"<path segment> ({shape})")
    return found


def analyse(har: dict) -> str:
    entries = ((har.get("log") or {}).get("entries") or [])
    hosts: Counter[str] = Counter()
    statuses: Counter[str] = Counter()
    methods: Counter[str] = Counter()
    paths: set[str] = set()
    interesting: list[str] = []

    for idx, entry in enumerate(entries, start=1):
        req = entry.get("request") or {}
        resp = entry.get("response") or {}
        url = req.get("url") or ""
        parsed = urlparse(url)
        host = parsed.hostname or "(unknown host)"
        method = (req.get("method") or "?").upper()
        status = resp.get("status")
        mime = ((resp.get("content") or {}).get("mimeType") or "").lower()

        hosts[host] += 1
        methods[method] += 1
        statuses[str(status) if status is not None else "?"] += 1
        if parsed.path:
            paths.add(f"{method} {host}{parsed.path}")

        flags: list[str] = []
        header_names = {
            (h.get("name") or "").lower()
            for h in (req.get("headers") or [])
            if isinstance(h, dict)
        }
        auth_present = sorted(header_names & AUTH_HEADER_NAMES)
        if auth_present:
            # Names only — values are deliberately never touched here.
            flags.append(f"auth headers present: {', '.join(auth_present)} (values redacted)")
        if isinstance(status, int) and status >= 400:
            flags.append(f"error status {status}")
        if "json" in mime:
            flags.append(f"JSON response ({mime})")
        params = id_like_params(url)
        if params:
            flags.append(f"possible ID params: {', '.join(params)}")

        if flags:
            interesting.append(
                f"#{idx} {method} {host}{parsed.path or '/'} -> {status} :: "
                + "; ".join(flags)
            )

    out: list[str] = []
    out.append("== HAR summary (offline, values redacted by design) ==")
    out.append(f"Entries: {len(entries)}")
    out.append("")
    out.append("== Hosts ==")
    out += [f"{h}: {c}" for h, c in hosts.most_common()] or ["(none)"]
    out.append("")
    out.append("== Methods ==")
    out += [f"{m}: {c}" for m, c in methods.most_common()] or ["(none)"]
    out.append("")
    out.append("== Status codes ==")
    out += [f"{s}: {c}" for s, c in sorted(statuses.items())] or ["(none)"]
    out.append("")
    out.append(f"== Unique method+host+path ({len(paths)}) ==")
    out += sorted(paths) or ["(none)"]
    out.append("")
    out.append(f"== Interesting entries ({len(interesting)}) ==")
    out += interesting or ["(none flagged)"]
    out.append("")
    out.append("Notes:")
    out.append("- Auth flags list header NAMES only; values were never printed.")
    out.append("- ID flags show parameter names and value shapes only, not values.")
    out.append("- A flag is a lead for manual review, not a finding. Check scope")
    out.append("  and the two-account rule (AGENTS.md section 2) before testing.")
    return "\n".join(out) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Analyse a .har file offline (no network, values redacted)."
    )
    ap.add_argument("har", type=Path, help="Path to the .har file to analyse")
    ap.add_argument("--out", type=Path, help="Write the text report here instead of stdout")
    ap.add_argument("--json", type=Path, dest="json_out",
                    help="Also write a machine-readable JSON summary here")
    args = ap.parse_args(argv)

    if not args.har.exists():
        print(f"ERROR: not found: {args.har}", file=sys.stderr)
        return 2
    try:
        har = json.loads(args.har.read_text(encoding="utf-8", errors="replace"))
    except json.JSONDecodeError as exc:
        print(f"ERROR: not valid JSON (is this a real .har file?): {exc}", file=sys.stderr)
        return 2
    if not isinstance(har, dict) or "log" not in har:
        print("ERROR: no top-level 'log' object — not a HAR file?", file=sys.stderr)
        return 2

    report = analyse(har)
    if args.out:
        args.out.write_text(report, encoding="utf-8")
        print(f"Wrote {args.out}")
    else:
        print(report, end="")

    if args.json_out:
        entries = ((har.get("log") or {}).get("entries") or [])
        summary = {"entries": len(entries), "report": report}
        args.json_out.write_text(json.dumps(summary, indent=2), encoding="utf-8")
        print(f"Wrote {args.json_out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
