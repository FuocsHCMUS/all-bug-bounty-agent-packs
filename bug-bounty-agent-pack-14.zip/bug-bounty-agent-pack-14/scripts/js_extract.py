#!/usr/bin/env python3
"""js_extract.py — extract URLs / paths / API endpoints from JavaScript.

OFFLINE by default: reads local .js file(s) (or a directory, searched
recursively for *.js) and pulls out, with regular expressions:

  - absolute URLs (http/https)
  - API-looking paths (/api/..., /v1/..., /graphql, ...)
  - other absolute paths ("/something/...")
  - fetch() / axios / XMLHttpRequest string arguments
  - source-map references (//# sourceMappingURL=...)

Results are de-duplicated and sorted. Extraction is a *lead generator*:
a string in a bundle is not proof an endpoint exists, is reachable, or
is in scope. Verify by hand, in scope, before any testing.

Optional URL mode follows the http_probe.py pattern in this pack:
  - DRY-RUN by default: ``--url`` alone prints what *would* be fetched
    and sends nothing.
  - A real fetch requires ``--live`` explicitly, sends exactly ONE GET,
    and prints a clear warning first. Running it against a bug-bounty
    target is Tier B (operator approval + scope check first).

Stdlib only. Python 3.14+ (Windows 11 friendly).

Usage:
    py -3.14 js_extract.py app.js
    py -3.14 js_extract.py bundle.js vendor.js --out endpoints.txt
    py -3.14 js_extract.py .\\static\\js\\
    py -3.14 js_extract.py --url https://example.com/app.js          # dry-run
    py -3.14 js_extract.py --url https://example.com/app.js --live   # 1 GET
"""
from __future__ import annotations

import argparse
import re
import sys
import urllib.request
import urllib.error
from pathlib import Path

URL_RE = re.compile(r"""https?://[^\s"'`<>\)\]]+""")
SOURCEMAP_RE = re.compile(r"""sourceMappingURL=([^\s*]+)""")
API_PATH_RE = re.compile(
    r"""["'`](/(?:api|graphql|rest|v\d+|auth|oauth|admin|internal)"""
    r"""[A-Za-z0-9_\-./?=&%{}:$]*)["'`]"""
)
GENERIC_PATH_RE = re.compile(r"""["'`](/(?:[A-Za-z0-9_\-]+/)+[A-Za-z0-9_\-./]*)["'`]""")
CALL_RE = re.compile(
    r"""(?:fetch|axios(?:\.(?:get|post|put|patch|delete))?|XMLHttpRequest)"""
    r"""\s*\(\s*["'`]([^"'`]{1,300})["'`]"""
)
# XMLHttpRequest.open("GET", "/path") — the URL is the *second* argument.
OPEN_RE = re.compile(
    r"""\.open\s*\(\s*["'`][A-Z]+["'`]\s*,\s*["'`]([^"'`]{1,300})["'`]"""
)
HTTP_METHODS = {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}


def extract(text: str) -> dict[str, set[str]]:
    """Return {category: set(values)} extracted from one JS text blob."""
    found: dict[str, set[str]] = {
        "absolute-url": set(),
        "api-path": set(),
        "path": set(),
        "call-target": set(),
        "source-map": set(),
    }
    for m in URL_RE.findall(text):
        found["absolute-url"].add(m.rstrip(".,;"))
    for m in SOURCEMAP_RE.findall(text):
        found["source-map"].add(m.strip())
    for m in API_PATH_RE.findall(text):
        found["api-path"].add(m)
    for m in GENERIC_PATH_RE.findall(text):
        # Keep generic paths separate unless they are already API paths.
        if m not in found["api-path"]:
            found["path"].add(m)
    for m in CALL_RE.findall(text):
        if m.upper() not in HTTP_METHODS:
            found["call-target"].add(m)
    for m in OPEN_RE.findall(text):
        found["call-target"].add(m)
    return found


def merge_into(total: dict[str, set[str]], extra: dict[str, set[str]]) -> None:
    for key, values in extra.items():
        total.setdefault(key, set()).update(values)


def render(total: dict[str, set[str]], sources: list[str]) -> str:
    lines: list[str] = ["== JS extraction (de-duplicated) =="]
    lines.append("Sources: " + (", ".join(sources) if sources else "(none)"))
    grand = 0
    for category in ("absolute-url", "api-path", "path", "call-target", "source-map"):
        values = sorted(total.get(category, set()))
        grand += len(values)
        lines.append("")
        lines.append(f"-- {category} ({len(values)}) --")
        lines += values or ["(none)"]
    lines.append("")
    lines.append(f"Total unique strings: {grand}")
    lines.append("Reminder: extracted strings are LEADS, not live endpoints.")
    lines.append("Confirm scope and existence manually before testing anything.")
    return "\n".join(lines) + "\n"


def collect_files(paths: list[Path]) -> list[Path]:
    files: list[Path] = []
    for p in paths:
        if p.is_dir():
            files += sorted(p.rglob("*.js"))
        elif p.is_file():
            files.append(p)
        else:
            print(f"WARNING: skipping missing path: {p}", file=sys.stderr)
    return files


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Extract URLs/paths/endpoints from local JS files (offline by default)."
    )
    ap.add_argument("paths", nargs="*", type=Path,
                    help="Local .js file(s) or a directory (searched recursively)")
    ap.add_argument("--url", help="A JS URL to fetch instead (dry-run unless --live)")
    ap.add_argument("--live", action="store_true",
                    help="Actually fetch --url (ONE GET). Default without it: dry-run")
    ap.add_argument("--out", type=Path, help="Write the report here instead of stdout")
    ap.add_argument("--timeout", type=float, default=10.0)
    args = ap.parse_args(argv)

    total: dict[str, set[str]] = {}
    sources: list[str] = []

    if args.url:
        if args.paths:
            print("ERROR: use either local paths or --url, not both.", file=sys.stderr)
            return 2
        if not args.url.startswith(("http://", "https://")):
            print("ERROR: --url must start with http:// or https://", file=sys.stderr)
            return 2
        if not args.live:
            print("DRY-RUN (no request sent). Would fetch:")
            print(f"  GET {args.url}")
            print("Re-run with --live after Tier B approval + scope check")
            print("(see AGENTS.md section 4). WARNING: --live sends a real request.")
            return 0
        print(f"WARNING: --live mode — sending ONE GET to {args.url}", file=sys.stderr)
        req = urllib.request.Request(
            args.url, headers={"User-Agent": "js-extract/20 (single request)"}
        )
        try:
            with urllib.request.urlopen(req, timeout=args.timeout) as resp:
                text = resp.read(5_000_000).decode("utf-8", errors="replace")
        except urllib.error.URLError as exc:
            print(f"ERROR: request failed: {exc}", file=sys.stderr)
            return 1
        merge_into(total, extract(text))
        sources.append(args.url)
    else:
        if not args.paths:
            print("ERROR: give local .js file(s)/a directory, or --url.", file=sys.stderr)
            return 2
        files = collect_files(args.paths)
        if not files:
            print("ERROR: no .js files found in the given path(s).", file=sys.stderr)
            return 2
        for f in files:
            merge_into(total, extract(f.read_text(encoding="utf-8", errors="replace")))
            sources.append(str(f))

    report = render(total, sources)
    if args.out:
        args.out.write_text(report, encoding="utf-8")
        print(f"Wrote {args.out}")
    else:
        print(report, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
