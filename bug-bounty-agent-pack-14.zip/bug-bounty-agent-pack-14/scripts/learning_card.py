#!/usr/bin/env python3
"""learning_card.py — Generate spaced-repetition review cards for a concept.
Prints (and optionally appends to a file) a card with the concept, a prompt
question, the SOC-mirror prompt, and review dates at +1 day / +1 week / +1 month.
Usage: python learning_card.py --concept "IDOR / BOLA" --question "Why is an unguessable UUID not authorization?" [--out cards.md]
Stdlib only. No network."""
import argparse, datetime

def main():
    ap = argparse.ArgumentParser(description="Create a spaced-repetition learning card.")
    ap.add_argument("--concept", required=True)
    ap.add_argument("--question", required=True, help="The core self-check question for this concept")
    ap.add_argument("--out", default="")
    a = ap.parse_args()
    today = datetime.date.today()
    reviews = ", ".join((today + datetime.timedelta(days=d)).isoformat() for d in (1, 7, 30))
    card = (f"## Card: {a.concept}\n"
            f"- Q: {a.question}\n"
            f"- SOC mirror: How would a defender detect exploitation of this concept in logs?\n"
            f"- Teach-back: explain it in 5 jargon-free sentences.\n"
            f"- Created: {today.isoformat()}  |  Review on: {reviews}\n")
    print(card)
    if a.out:
        with open(a.out, "a", encoding="utf-8") as f:
            f.write(card + "\n")
        print(f"Appended to {a.out}")

if __name__ == "__main__":
    main()
