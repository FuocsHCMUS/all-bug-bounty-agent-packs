#!/usr/bin/env python3
"""make_finding_folder.py — Scaffold one finding's report-pack folder inside a hunt.
Usage: python make_finding_folder.py --hunt hunts/2026-11-03-example-api.example.com --title "IDOR on invoice download"
Creates findings/<slug>/ with finding-report, duplicate-check, and retest-log stubs.
Stdlib only. No network."""
import argparse, pathlib, re

STUBS = {
    "finding-report.md": "# Finding Report\nTemplate: ../../../templates/finding-report.md\nRemember: this goes to Joshua only — he submits.\n",
    "duplicate-check.md": "# Duplicate Self-Check\nTemplate: ../../../templates/duplicate-check.md\n",
    "retest-log.md": "# Retest Log\nTemplate: ../../../templates/retest-log.md\n",
}

def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-") or "finding"

def main():
    ap = argparse.ArgumentParser(description="Scaffold a finding report-pack folder.")
    ap.add_argument("--hunt", required=True)
    ap.add_argument("--title", required=True)
    a = ap.parse_args()
    folder = pathlib.Path(a.hunt) / "findings" / slug(a.title)
    folder.mkdir(parents=True, exist_ok=True)
    for name, text in STUBS.items():
        (folder / name).write_text(text, encoding="utf-8")
    print(f"Created finding folder: {folder}")

if __name__ == "__main__":
    main()
