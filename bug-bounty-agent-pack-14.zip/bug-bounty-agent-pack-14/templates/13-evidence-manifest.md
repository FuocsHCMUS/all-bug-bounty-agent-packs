# Template 13 — Evidence Manifest: <program / target> — <hunt or finding ID>

One manifest per hunt (or per finding, for large hunts). Created at first
capture, updated the *same session* as every new evidence file — never
reconstructed from memory later (Core 09 §5). The manifest is what makes
evidence verifiable: if a file is not in this table, it is not evidence.

> Note on numbering in pack v20: check `AGENTS.md` §11 / the pack index —
> if your pack build assigns Template 13 to another form, keep this file's
> *content* and renumber with the operator rather than deleting it.

---

## 1. Manifest metadata

| Field | Value |
|---|---|
| Program / target | |
| Hunt folder (local path) | |
| Manifest owner (agent + operator) | |
| Created (date, time, timezone) | |
| Last updated | |
| Related scope intake (file + date signed off) | |
| Evidence root folder | `evidence/` (originals in `evidence/originals/`, shareables in `evidence/shareable/`) |
| Hash algorithm | SHA-256 (default; note any exception) |
| Retention decision (Core 09 §7) | Keep until: … / Delete after closure: … / TBD at weekly review |

## 2. How hashes were produced

Tool + version used for hashing (fill in honestly — reproducibility is the point):

| Item | Value |
|---|---|
| Tool (e.g. `Get-FileHash`, `sha256sum`, Python `hashlib` script, `scripts/…`) | |
| Version / command line used | |
| Machine / OS (e.g. Windows 11, PowerShell …) | |
| Verified by (re-hash check: who/when, second tool?) | |

Hashing commands (reference):

```powershell
# Windows / PowerShell
Get-FileHash -Algorithm SHA256 <file>
```

```bash
# Linux / macOS
sha256sum <file>
```

## 3. Evidence inventory (one row per file — originals)

| # | Filename (in `originals/`) | SHA-256 (full) | Size (bytes) | Captured (date/time + TZ) | Capture tool + version | Capturing account (A/B/anon) | Related EXP / Finding ID | Content in one line |
|---|---|---|---|---|---|---|---|---|
| E-001 | | | | | | | EXP- / F- | |
| E-002 | | | | | | | EXP- / F- | |
| E-003 | | | | | | | EXP- / F- | |

Rules for this table:

- Hash the file **at capture time**, before any annotation or copying.
- Never edit an original after hashing. An annotated version is a *new*
  row, with `Derived from: E-00X` noted in §5.
- A hash mismatch on re-check = stop: note it in §6, do not "fix" the
  hash silently. The mismatch *is* information (file changed — by whom?).

## 4. Redaction & shareable copies

| Original # | Shareable filename (in `shareable/`) | SHA-256 of shareable | What was redacted (categories, not values) | Redaction checked (body / headers / URL / filename / metadata — all five?) | Checked by + date |
|---|---|---|---|---|---|
| E-001 | | | e.g. session cookie, Account B email, internal hostname | ☐ body ☐ headers ☐ URL ☐ filename ☐ metadata | |
| E-002 | | | | ☐ body ☐ headers ☐ URL ☐ filename ☐ metadata | |

Redaction categories to consider every time (Core 09 §4): passwords,
tokens/API keys, session cookies & `Authorization` headers, real-user
names/emails/phones/IDs, payment data, precise locations, real-user IPs,
internal names not needed to understand the bug.

- Private redaction map kept? ☐ No ☐ Yes — location (with originals only):
- Any record still identifiable from context despite redaction? ☐ No
  ☐ Yes — which row, and how was it minimised further / flagged to operator:

## 5. Derived & annotated files

| File | Derived from (E-#) | What was changed (crop, highlight, annotation, format conversion) | SHA-256 | Purpose (report figure / operator review / …) |
|---|---|---|---|---|
| | | | | |

## 6. Integrity & custody log

Every move, copy, share, or incident — in order. "Nothing happened" needs
no entry; *everything that did* needs one.

| Date/time + TZ | Event (created / hashed / copied to … / shared with operator / attached to draft report / hash re-verified ✓ / mismatch ⚠ / deleted per retention) | File(s) (E-#) | By whom | Notes |
|---|---|---|---|---|
| | | | | |

Sharing reminder: the agent hands material **to the operator only**; the
operator submits to the program. Record the operator's submission details
(platform, date, report ID as given by the operator) in the disclosure
log (Template 11), not here.

## 7. Screenshots & recordings supplement

| E-# | Type (screenshot / video) | Region captured (smallest proving region?) | Pre-capture check done? (notifications cleared, unrelated tabs closed, no real-user data in frame) | Cropping applied (derived file #) |
|---|---|---|---|---|
| | | | ☐ Yes ☐ No — explain: | |

## 8. Secrets & foreign-data flags (values NEVER go in this manifest)

| E-# | Contains found secret? (type + last 4 only) | Contains foreign / real-user data fragment? (type + approx. count only) | Operator notified (date) | Rotation / program response noted? |
|---|---|---|---|---|
| | ☐ No ☐ Yes: | ☐ No ☐ Yes: | | |

## 9. End-of-hunt verification (all boxes before the hunt closes)

- [ ] Every file in `evidence/originals/` appears in §3 (and vice versa)
- [ ] Every file in `evidence/shareable/` appears in §4 (and vice versa)
- [ ] All hashes re-verified in one pass; result + date logged in §6
- [ ] No live credentials/tokens in any shareable file (searched, not eyeballed)
- [ ] No evidence stored outside the hunt folder (chat, temp, third-party hosts checked)
- [ ] Retention decision in §1 filled in and actioned or scheduled
- [ ] Manifest itself stored in the hunt folder (not only in chat)

Manifest completed by: … Date: …
Operator reviewed: ☐ Yes — date: … ☐ Not yet
