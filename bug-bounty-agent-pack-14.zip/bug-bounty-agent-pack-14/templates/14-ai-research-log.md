# Template 14 — AI Research Log: <hunt / topic>

Research feeds hunts — and research is where confident nonsense enters a
hunt disguised as fact. This log is the anti-hallucination control for
*all* external knowledge used in a hunt, whether it came from a web page,
a writeup, a book, or an AI assistant's own "memory" (including this
agent's). If a claim influenced a test, a CVE match, or a report, it gets
a row here with its verification status — or it doesn't get used.

> Note on numbering in pack v20: check `AGENTS.md` §11 / the pack index —
> if your pack build assigns Template 14 to another form, keep this file's
> *content* and renumber with the operator rather than deleting it.

---

## 1. Log metadata

| Field | Value |
|---|---|
| Hunt / program | |
| Researcher (agent / operator / both) | |
| Date range covered | |
| Linked files (hypothesis backlog, CVE match sheets, technique cards) | |

## 2. The verification ladder (use these words exactly)

| Status | Meaning | May be used for |
|---|---|---|
| **Unverified** | Heard/read once, or recalled by an AI — not checked | Generating a hypothesis only |
| **Single-source** | Found stated in one source you actually opened | Planning a low-risk test |
| **Corroborated** | Two independent sources agree (not two copies of one post) | Testing; citing in notes with sources named |
| **Primary-verified** | Checked against the primary source itself (vendor advisory, NVD entry, the CVE record, the actual paper/code) | CVE matches, report citations |
| **Tested-here** | Your own experiment on *this* target confirmed/denied it | Findings (via the confirmation ladder, Core 08 §8) |
| **Refuted** | Checked and found wrong / not applicable here — keep the row! | Preventing re-research; the do-not-repeat list |

An AI assistant's fluent answer — including a summary an agent produced
from its own training — starts at **Unverified** by definition, no matter
how confident it sounds. Fluency is not a source.

## 3. Research entries (one row per question)

### R-001 — <research question, in question form>

- **Question:** (e.g. "Is `<product> 4.2.x` affected by CVE-YYYY-NNNNN,
  and under what configuration?")
- **Why it matters to this hunt:** (which hypothesis / decision depends on it)
- **Sources actually opened:** (title + publisher/site + date accessed;
  no source = no entry — "from memory" is recorded as *AI recall, unverified*)
  1.
  2.
- **Claims extracted:** (number them; one claim per line, in plain words)
  1.
  2.
- **Verification status (per claim, if they differ):**
- **How verified:** (what you compared — version range vs observed banner,
  advisory text vs blog summary, PoC preconditions vs target config…)
- **Conflicts between sources:** (or "none found") — and how resolved:
- **How used in the hunt:** (hypothesis H-…, CVE match sheet …, EXP-…,
  technique card …, or "not used — parked, reason: …")
- **Residual uncertainty:** (what is still unknown after researching)
- **Date / researcher:**

### R-002 — <next question>
(Copy the block above. Empty template blocks are fine; invented filler is not.)

## 4. Source-quality notes (fill in as you learn each source)

Judging a source is a skill. Record what you learn so the next hunt starts smarter.

| Source | Type (primary / vendor / research blog / writeup / CTF / aggregator / AI output) | Strengths observed | Weaknesses / failure modes observed | Trust for what? |
|---|---|---|---|---|
| | | | | |

Standing guidance (see `references/modern-sources-2024-2026.md`):

- **Primary beats secondary:** the vendor advisory / CVE record / original
  research post outranks every summary of it — including video summaries
  and AI summaries.
- **A writeup proves it happened *there, then*.** Transferring it *here*
  is a hypothesis, not a conclusion.
- **Aggregators and AI answers are indexes, not evidence.** Follow them
  to the primary source, then cite the primary source.
- **Check the date and the version.** A 2021 technique against a 2026
  patched stack is history — useful history, labelled as such.

## 5. AI-specific honesty checks (run before any AI-derived claim is used)

- [ ] Is this claim traceable to a source a human/agent actually *opened*
      in this hunt — not just to an AI's say-so?
- [ ] Have identifiers been copied exactly (CVE numbers, version strings,
      product names, URLs) from the source — not retyped from memory?
- [ ] Does the claim survive the "show me" test: can I point to the page,
      section, or experiment that establishes it?
- [ ] If two AI outputs agreed, did they agree because both are right —
      or because both repeat the same popular summary? (Agreement between
      AIs is **not** corroboration under §2.)
- [ ] Is anything here suspiciously perfect — a CVE that fits *too*
      neatly, a version that matches *too* conveniently? Double-check
      those first; wishful matching is the classic failure.
- [ ] Have Refuted rows been kept, so the next session doesn't re-walk
      this dead end?

## 6. Claims that reached a report (audit trail)

Only **Primary-verified** or **Tested-here** claims may appear as facts
in a report to a company. List them here before the report is drafted.

| Claim (short) | R-# | Status | Where it appears in the draft report | Primary source (as cited in the report) |
|---|---|---|---|---|
| | | | | |

If a claim can't fill this table, it leaves the report — or is rewritten
as an explicitly labelled hypothesis for the operator, outside the report.

## 7. Session close-out

- Questions opened this session: … / Closed (status reached): …
- Claims promoted to Primary-verified / Tested-here: …
- Claims refuted (celebrate these — a refuted claim is a saved invalid report): …
- Biggest remaining uncertainty for this hunt: …
- Next research question to open: …
