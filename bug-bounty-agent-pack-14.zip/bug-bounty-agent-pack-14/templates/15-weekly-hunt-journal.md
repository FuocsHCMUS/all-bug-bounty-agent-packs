# Template 15 — Weekly Hunt Journal: Week of <YYYY-MM-DD> — <operator>

One journal per week, filled in at the weekly review (30 minutes — see
Learning 09 §7 and Workflow 07). The journal is the pack's long-term
memory at human scale: hunts produce experiment logs; weeks produce
*judgement*. Negatives, dead ends, and "I learned I was wrong" entries are
first-class content here — a journal with only wins is a journal that is lying.

> Note on numbering in pack v20: check `AGENTS.md` §11 / the pack index —
> if your pack build assigns Template 15 to another form, keep this file's
> *content* and renumber with the operator rather than deleting it.

---

## 1. Week at a glance

| Field | Value |
|---|---|
| Week (Mon–Sun dates) | |
| Program(s) / target(s) worked | |
| Total hunt time (honest estimate) | |
| Lab / study time | |
| Sessions held (hunt / lab / reading / review) | |
| Pack workflows used (01–10) | |
| Preflight checklists completed? | ☐ Every session ☐ Some ☐ None — why: |

## 2. Hypotheses tested (the scoreboard that matters)

| H-# | Hypothesis (one line) | Result: Confirmed / Negative / Inconclusive / Parked | EXP range | Time spent | What decided it (evidence, not vibes) |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |

Counts: Tested: … Confirmed: … Ruled out: … Inconclusive: …

Reading the counts honestly:

- Many **negatives** with clean logs = a good week. You bought certainty.
- Many **inconclusives** = a method problem (no baseline? two variables?
  wrong tool?). Name it in §6 — don't just "try harder."
- Zero tested = a research/planning week. Fine occasionally; two in a
  row means the queue needs re-ranking (Core 08 §7).

## 3. Findings & candidates

| ID | Title | Ladder level (Core 08 §8: 1 Signal / 2 Reproduced / 3 Impact shown / 4 Report-ready) | Status (drafted / with operator / submitted by operator / triaged / duplicate / closed) | Next action + date |
|---|---|---|---|---|
| | | | | |

- Reports the operator submitted this week (IDs as given by the operator):
- Program responses received (accept / duplicate / needs-more-info — and
  what each one teaches about research or reporting quality):

## 4. Negatives & dead ends worth remembering

For each: what was ruled out, the evidence, and the condition that would
justify re-testing (new version, new role, new surface). These rows feed
the do-not-repeat lists in each hunt's state file.

| Area / technique | Ruled out by (EXP / source) | Re-test only if… |
|---|---|---|
| | | |

## 5. Research & learning

- Research log entries opened/closed (Template 14 R-#s):
- Claims refuted this week (and the invalid work they prevented):
- Writeups / research read — and the *one* transferable pattern from each
  (technique card filed? Template 08 #):
- New concepts met: (term → where it's filed: glossary / learning note)
- Learning notes completed (Template 06, per finding or topic):
- Posture analyses completed or updated (Template 05, per target):

## 6. Mistakes, close calls & process fixes

Be specific and kind to yourself; this section is how the process improves.

| What happened | Class (scope / approval / evidence / labelling / technique / time) | Rule or checklist it maps to | Fix adopted (file changed? habit? checklist item added?) |
|---|---|---|---|
| | | | |

- Any over-access, secret/PII handling, or stop-condition events this
  week (Core 09 §8)? ☐ None ☐ Yes — logged where, operator actions taken:
- Approvals: Tier B requests made / granted / declined — and anything
  that *should* have been asked but wasn't:

## 7. Defender / SOC thread (keep the purple habit weekly)

- One attack I ran (lab or target) and its detection idea (Core 10 §4) —
  in three lines:
- One log I actually looked at this week, and what "normal" looked like:
- ATT&CK mappings practised (technique names/IDs, verified?): 

## 8. Spaced repetition & skills

- **Flashcards due at week start:** … **Cleared:** … **Overdue carried:** …
- New cards filed this week (count + domains): …
- Cards converted from mistakes (§6) — the most valuable cards you own: …
- Skills matrix movement (Learning 09 §3): any rating changed? Evidence:
- Self-check questions failed this week (from learning notes) → re-study plan:

## 9. Energy, time & honesty box

- What actually consumed the time (vs the plan)? …
- Rabbit hole of the week — what triggered it, when did you notice,
  what will catch it earlier next time? …
- One thing I believed on Monday that I no longer believe on Sunday: …
- Confidence check: am I labelling candidates vs findings honestly?
  Any summary I wrote this week that overstates the evidence? Fix it here: …

## 10. Next week plan (small, ranked, realistic)

**Single priority:** …

| # | Planned work (workflow / hypothesis / lab / reading) | Target / program | Time box | Definition of done |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |

- Retests / disclosure follow-ups due next week (Template 11):
- Approvals I'll need to request (Tier B) — drafted already? ☐
- Flashcards due next week (opening count): …
- One deliberate *non*-goal (what I am choosing NOT to chase, and why): …

Journal completed on: … Reviewed with agent: ☐ Hunt state files updated
to match this journal: ☐ (Core 08 §9 — contradictions reconciled now,
not discovered mid-hunt next week.)
