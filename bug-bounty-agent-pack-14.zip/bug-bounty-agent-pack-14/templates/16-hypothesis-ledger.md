# Template: Hypothesis Ledger

| # | Hypothesis (Because X trusts Y, doing Z should expose W) | Oracle (proven if / disproven if) | Research links (CVE/writeup cards) | Status | Evidence |

|---|---|---|---|---|---|

Status values: untested / testing / proven / disproven / parked (needs precondition). Negative results stay in the ledger forever — they are knowledge.
