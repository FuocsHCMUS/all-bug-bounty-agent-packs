# Template: Duplicate Self-Check

## Exact endpoint + class searched in: program disclosed reports / Hacktivity / Bugcrowd disclosures / known-issues list (links + dates searched):

## Nearest matches and how this finding differs (root cause / scope / chain / impact):

If it might be a duplicate: what extra value does this version add, honestly?

## Decision: submit-ready / hold for more differentiation / drop:
