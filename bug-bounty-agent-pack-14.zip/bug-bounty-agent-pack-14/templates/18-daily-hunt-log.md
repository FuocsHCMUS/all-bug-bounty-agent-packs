# Template: Daily Hunt Log

## Date / program / hunt folder:

## Surfaces tested (with hypothesis numbers):

## Results: proven / indicated / disproven / parked — one line each:

## Tools used (name, source, Tier A/B, why):

## Test objects created and cleaned up:

## Time spent vs plan; top surface for next session:

## One thing learned today (feeds the learning note):
