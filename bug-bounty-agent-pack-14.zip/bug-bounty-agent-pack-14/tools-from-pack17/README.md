# Tools from Pack 17 — offline helpers only

Copied from pack 17's `tools/` because they are **offline / local-file**
helpers, consistent with this pack's rule that helper scripts are
offline or dry-run-by-default:

| Tool | What it does | Input |
|---|---|---|
| `jwt_inspect.py` | Decode a JWT, audit claims/header, optionally test a small built-in weak-HMAC list or a wordlist you supply | a token you own |
| `cvss.py` | CVSS 3.1 base score from a vector string | a vector |
| `diff_response.py` | Diff two saved HTTP responses (great for A/B account differentials) | two local files |
| `param_miner.py` | Mine parameter names from local files / wordlists | local files |
| `js_endpoint_extract.py` | Extract endpoints/routes from a saved JS bundle | a local file |
| `evidence_hasher.py` | SHA-256 hashes for evidence files | local files |
| `report_builder.py` | Assemble a report draft from local notes | local files |

Also dropped: pack 17's `verify_pack.py` — it validates pack 17's own
folder layout and fails on any other, so in this edition it is replaced
by the root `VERIFICATION.md` test record.

Not copied, deliberately: pack 17's `race_runner.py` (live request
bursts) and `oob_listener.py` (callback listener). Race proof and
out-of-band detection are covered procedurally in playbooks 05/08 and
`playbooks/per-class-pack17/`; if the operator wants those two scripts,
they are in the original pack 17 zip and can be added under a Tier B
approval (AGENTS.md §4). `scope_guard.py`, `http_probe.py` and
`cve_lookup.py` were also not copied — the canonical, tested versions
live in `scripts/`.
