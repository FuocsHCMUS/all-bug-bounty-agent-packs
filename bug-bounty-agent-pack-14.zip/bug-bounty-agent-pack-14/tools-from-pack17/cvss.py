#!/usr/bin/env python3
"""CVSS 3.1 base score from a vector string."""
from __future__ import annotations
import argparse, sys

W = {
 "AV": {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.2},
 "AC": {"L": 0.77, "H": 0.44},
 "PR": {"N": 0.85, "L": {"U": 0.62, "C": 0.68}, "H": {"U": 0.27, "C": 0.5}},
 "UI": {"N": 0.85, "R": 0.62},
 "C": {"H": 0.56, "L": 0.22, "N": 0.0},
 "I": {"H": 0.56, "L": 0.22, "N": 0.0},
 "A": {"H": 0.56, "L": 0.22, "N": 0.0},
}

def band(s: float) -> str:
    return "none" if s == 0 else "low" if s < 4 else "medium" if s < 7 else "high" if s < 9 else "critical"

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("vector")
    a = ap.parse_args()
    parts = dict(p.split(":") for p in a.vector.replace("CVSS:3.1/", "").split("/") if ":" in p)
    for k in ("AV", "AC", "PR", "UI", "S", "C", "I", "A"):
        if k not in parts: print("missing", k); return 2
    scope = parts["S"]
    pr = W["PR"][parts["PR"]][scope] if isinstance(W["PR"][parts["PR"]], dict) else W["PR"][parts["PR"]]
    iss = 1 - (1 - W["C"][parts["C"]]) * (1 - W["I"][parts["I"]]) * (1 - W["A"][parts["A"]])
    if scope == "U":
        impact = 6.42 * iss
    else:
        impact = 7.52 * (iss - 0.029) - 3.25 * (iss - 0.02) ** 15
    expl = 8.22 * W["AV"][parts["AV"]] * W["AC"][parts["AC"]] * pr * W["UI"][parts["UI"]]
    score = 0.0 if impact <= 0 else (min(impact + expl, 10) if scope == "U" else min(1.08 * (impact + expl), 10))
    score = round(score * 10) / 10
    print(f"{a.vector} -> {score} ({band(score)})")
    return 0

if __name__ == "__main__":
    sys.exit(main())

