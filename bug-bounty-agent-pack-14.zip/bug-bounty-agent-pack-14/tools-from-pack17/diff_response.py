#!/usr/bin/env python3
"""Differential diff of two saved responses or two URLs with different auth."""
from __future__ import annotations
import argparse, difflib, json, sys, urllib.request
from pathlib import Path

def load(spec: str, header: str | None) -> tuple[str, str]:
    if spec.startswith("http"):
        h = {"User-Agent": "bb-pack/17"}
        if header:
            k, _, v = header.partition(":"); h[k.strip()] = v.strip()
        req = urllib.request.Request(spec, headers=h)
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                return str(r.status), r.read().decode("utf-8", "replace")
        except Exception as e:
            body = getattr(e, "read", lambda: b"")() or b""
            return str(getattr(e, "code", 0)), body.decode("utf-8", "replace")
    p = Path(spec)
    text = p.read_text(encoding="utf-8", errors="replace")
    if text.startswith("HTTP/"):
        head, _, body = text.partition("\n\n")
        return head.split()[1] if len(head.split()) > 1 else "0", body
    return "file", text

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("a"); ap.add_argument("b")
    ap.add_argument("--header-a"); ap.add_argument("--header-b")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    sa, ba = load(a.a, a.header_a); sb, bb = load(a.b, a.header_b)
    ratio = difflib.SequenceMatcher(None, ba, bb).ratio()
    diff = list(difflib.unified_diff(ba.splitlines(), bb.splitlines(), "A", "B", n=2, lineterm=""))
    flags = []
    if sa == sb and ratio > 0.97: flags.append("near-identical: possible missing authz check")
    if sa != sb and ratio > 0.97: flags.append("status differs but body same: check response headers")
    if sa == sb and ratio < 0.5: flags.append("same status, very different body: possible data leak")
    res = {"status_a": sa, "status_b": sb, "len_a": len(ba), "len_b": len(bb),
           "similarity": round(ratio, 4), "flags": flags, "diff": diff[:400]}
    if a.json:
        print(json.dumps(res, indent=2))
    else:
        print(f"A: {sa} {len(ba)}B  B: {sb} {len(bb)}B  similarity {ratio:.3f}")
        for f in flags: print("FLAG:", f)
        print("\n".join(diff[:200]))
    return 0

if __name__ == "__main__":
    sys.exit(main())

