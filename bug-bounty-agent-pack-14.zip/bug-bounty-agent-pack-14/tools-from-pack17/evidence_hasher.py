#!/usr/bin/env python3
"""sha256 manifest for an evidence dir; verify mode."""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path

def digest(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""): h.update(chunk)
    return h.hexdigest()

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("dir")
    ap.add_argument("--verify", action="store_true")
    a = ap.parse_args()
    d = Path(a.dir)
    man = d / "manifest.sha256"
    if a.verify:
        if not man.exists(): print("no manifest"); return 2
        bad = 0
        for line in man.read_text(encoding="utf-8").splitlines():
            h, _, rel = line.partition("  ")
            p = d / rel
            if not p.exists() or digest(p) != h:
                print("MISMATCH", rel); bad += 1
        print("verified" if not bad else f"{bad} mismatched"); return 1 if bad else 0
    rows = []
    for p in sorted(d.rglob("*")):
        if p.is_file() and p != man:
            rows.append(f"{digest(p)}  {p.relative_to(d).as_posix()}")
    man.write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(json.dumps({"files": len(rows), "manifest": str(man)}))
    return 0

if __name__ == "__main__":
    sys.exit(main())

