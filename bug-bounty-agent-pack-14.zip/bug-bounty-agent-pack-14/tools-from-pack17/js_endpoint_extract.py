#!/usr/bin/env python3
"""Extract endpoints, params and secret-shaped strings from JS files."""
from __future__ import annotations
import argparse, json, re, sys, urllib.request
from pathlib import Path

PATTERNS = {
    "path": re.compile(r"""["'`](/(?:api|v\d|graphql|rest|internal|admin)[A-Za-z0-9_\-./{}$:]*)["'`]"""),
    "abs_url": re.compile(r"""["'`](https?://[A-Za-z0-9_.\-:]+[A-Za-z0-9_\-./?=&%{}]*)["'`]"""),
    "param": re.compile(r"""[?&]([A-Za-z_][A-Za-z0-9_]{1,30})="""),
    "fetch": re.compile(r"""fetch\(\s*["'`]([^"'`]+)["'`]"""),
    "axios": re.compile(r"""axios\.(?:get|post|put|delete|patch)\(\s*["'`]([^"'`]+)["'`]"""),
    "s3": re.compile(r"""([a-z0-9.\-]+\.s3[.\-][a-z0-9\-]*\.amazonaws\.com)"""),
    "aws_key": re.compile(r"""\b(AKIA|ASIA)[A-Z0-9]{16}\b"""),
    "google_api": re.compile(r"""AIza[0-9A-Za-z_\-]{35}"""),
    "firebase": re.compile(r"""([a-z0-9\-]+\.firebaseio\.com|[a-z0-9\-]+\.firebaseapp\.com)"""),
    "jwt": re.compile(r"""eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{5,}"""),
    "bearer": re.compile(r"""[Bb]earer\s+([A-Za-z0-9._\-]{16,})"""),
    "graphql": re.compile(r"""(query|mutation)\s+([A-Za-z0-9_]+)"""),
    "sourceless": re.compile(r"""sourceMappingURL=([^\s*]+)"""),
}

def load(src: str) -> str:
    if src.startswith("http"):
        req = urllib.request.Request(src, headers={"User-Agent": "bb-pack/17"})
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.read().decode("utf-8", "replace")
    return Path(src).read_text(encoding="utf-8", errors="replace")

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    result: dict[str, set[str]] = {k: set() for k in PATTERNS}
    for src in a.inp:
        try:
            text = load(src)
        except Exception as e:
            print("skip", src, e); continue
        for name, rx in PATTERNS.items():
            for m in rx.finditer(text):
                val = m.group(m.lastindex) if m.lastindex else m.group(0)
                result[name].add(val)
    out = {k: sorted(v) for k, v in result.items() if v}
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(out, indent=2), encoding="utf-8")
    for k, v in out.items():
        print(f"{k}: {len(v)}")
    print("wrote", a.out)
    return 0

if __name__ == "__main__":
    sys.exit(main())

