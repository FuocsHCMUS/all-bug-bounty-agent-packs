#!/usr/bin/env python3
"""Decode a JWT, audit claims, optionally test a weak HMAC secret. Stdlib."""
from __future__ import annotations
import argparse, base64, hashlib, hmac, json, sys

WEAK = ["secret", "password", "changeme", "jwt", "key", "123456", "admin", "test",
        "supersecret", "your-256-bit-secret", "s3cr3t", "jwtsecret"]

def b64d(seg: str) -> bytes:
    seg += "=" * (-len(seg) % 4)
    return base64.urlsafe_b64decode(seg)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("token")
    ap.add_argument("--wordlist")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    parts = a.token.split(".")
    if len(parts) != 3:
        print("not a JWT (expected 3 segments)"); return 2
    try:
        header = json.loads(b64d(parts[0])); payload = json.loads(b64d(parts[1]))
    except Exception as e:
        print("decode failed:", e); return 2
    findings = []
    alg = str(header.get("alg", ""))
    if alg.lower() == "none": findings.append("alg=none present; try stripping the signature")
    if alg.startswith("HS"):
        words = WEAK + ([w.strip() for w in open(a.wordlist, encoding="utf-8", errors="replace")] if a.wordlist else [])
        signing_input = (parts[0] + "." + parts[1]).encode()
        for w in words:
            if not w: continue
            sig = base64.urlsafe_b64encode(hmac.new(w.encode(), signing_input, hashlib.sha256).digest()).rstrip(b"=").decode()
            if hmac.compare_digest(sig, parts[2]):
                findings.append(f"WEAK HMAC SECRET: {w!r}"); break
    if "kid" in header: findings.append(f"kid={header['kid']!r} -> try traversal / SQLi / known file")
    if "jku" in header or "x5u" in header: findings.append("jku/x5u present -> point at your host")
    for c in ("exp", "nbf", "iat", "aud", "iss"):
        if c not in payload: findings.append(f"missing claim: {c}")
    if str(payload.get("email_verified")).lower() in ("false", "0"): findings.append("email_verified false")
    for k in ("role", "roles", "admin", "is_admin", "tenant", "tenant_id", "scope"):
        if k in payload: findings.append(f"privilege-shaped claim: {k}={payload[k]!r}")
    if a.json:
        print(json.dumps({"header": header, "payload": payload, "findings": findings}, indent=2))
    else:
        print("HEADER ", json.dumps(header))
        print("PAYLOAD", json.dumps(payload, indent=2))
        print("---")
        for f in findings or ["no obvious issue"]: print("*", f)
    return 0

if __name__ == "__main__":
    sys.exit(main())

