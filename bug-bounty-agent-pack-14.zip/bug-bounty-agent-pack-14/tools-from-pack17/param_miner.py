#!/usr/bin/env python3
"""Rank parameter candidates from HTML/JS/HAR for fuzzing."""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path

RX = re.compile(r"""[?&"']([A-Za-z_][A-Za-z0-9_\-]{1,40})(?:=|["'])""")
HINTS = {
    "redirect": ["redirect", "next", "return", "url", "callback", "continue", "dest", "goto", "target"],
    "file": ["file", "path", "doc", "download", "upload", "attachment", "template", "include"],
    "id": ["id", "uid", "user", "account", "tenant", "org", "invoice", "order", "pid", "uuid", "slug"],
    "token": ["token", "key", "sig", "hash", "nonce", "jwt", "session", "auth"],
    "query": ["q", "search", "filter", "sort", "order", "col", "dir", "limit", "offset", "page"],
    "money": ["price", "amount", "qty", "quantity", "total", "discount", "coupon", "currency"],
    "format": ["format", "type", "mode", "view", "lang", "locale", "debug", "test"],
}

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--min", type=int, default=2)
    a = ap.parse_args()
    counts: dict[str, int] = {}
    for src in a.inp:
        p = Path(src)
        text = p.read_text(encoding="utf-8", errors="replace")
        if p.suffix == ".har":
            try:
                text = json.dumps(json.loads(text))
            except Exception:
                pass
        for m in RX.finditer(text):
            name = m.group(1).lower()
            counts[name] = counts.get(name, 0) + 1
    ranked = []
    for name, n in counts.items():
        if n < a.min: continue
        cats = [c for c, ws in HINTS.items() if any(w in name for w in ws)]
        ranked.append({"param": name, "hits": n, "classes": cats, "score": n * (1 + 2 * len(cats))})
    ranked.sort(key=lambda r: -r["score"])
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(ranked, indent=2), encoding="utf-8")
    for r in ranked[:40]:
        print(f"{r['score']:>4} {r['param']:<28} {','.join(r['classes'])}")
    print("wrote", a.out, len(ranked), "candidates")
    return 0

if __name__ == "__main__":
    sys.exit(main())

