#!/usr/bin/env python3
"""Render markdown reports from findings.json using reporting/report-template.md."""
from __future__ import annotations
import argparse, json, subprocess, sys
from pathlib import Path

SECTIONS = ["summary", "severity", "asset", "preconditions", "reproduction", "evidence",
            "impact", "root_cause", "remediation", "detection", "references"]

def score(vector: str) -> str:
    here = Path(__file__).resolve().parent
    r = subprocess.run([sys.executable, str(here / "cvss.py"), vector], capture_output=True, text=True)
    return r.stdout.strip().split("-> ")[-1] if r.returncode == 0 else "n/a"

def render(f: dict) -> str:
    out = [f"# {f['title']}", ""]
    for s in SECTIONS:
        v = f.get(s)
        if v is None: continue
        out.append(f"## {s.replace('_', ' ').title()}")
        if s == "severity":
            out.append(f"`{f['cvss']}` -> {score(f['cvss'])}")
        elif isinstance(v, list):
            out += [f"- {x}" for x in v]
        else:
            out.append(str(v))
        out.append("")
    return "\n".join(out)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--findings", required=True)
    ap.add_argument("--out-dir", required=True)
    a = ap.parse_args()
    data = json.loads(Path(a.findings).read_text(encoding="utf-8"))
    if isinstance(data, dict): data = [data]
    od = Path(a.out_dir); od.mkdir(parents=True, exist_ok=True)
    for f in data:
        p = od / f"{f['id']}.md"
        p.write_text(render(f), encoding="utf-8")
        print("wrote", p)
    return 0

if __name__ == "__main__":
    sys.exit(main())

