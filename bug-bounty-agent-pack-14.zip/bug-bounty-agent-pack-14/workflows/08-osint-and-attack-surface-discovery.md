# Workflow 08 — OSINT & Attack Surface Discovery

**Purpose:** Before (and alongside) any active testing, build the most
complete possible picture of the target from **public, read-only sources
only** — then convert that picture into a scoped, ranked surface map and
hypothesis backlog. This workflow is Tier A by design: if a step requires
touching the target beyond normal public browsing, it stops and becomes a
Tier B ask for Workflow 01 / Phase 5.

**Timebox:** 90–180 minutes for a new program; 30-minute refresh variant
in §9. **Inputs:** program name + URL. **Outputs:** OSINT dossier section,
attack-surface map, fingerprint/CVE pre-sweep, hypothesis seeds.

> **Hard boundaries:** OSINT here means *technical and corporate* public
> information. **No** social engineering, **no** contacting employees,
> **no** harvesting personal data about individuals, **no** credential
> dumps / breach-corpus lookups of real people's passwords, **no** logging
> in anywhere except your own test accounts. If a source crosses into
> personal data about non-public individuals, close it and note why.

---

## 0. Preflight

1. [ ] Run `checklists/ai-agent-preflight.md` if present (agent setup,
       scope state, evidence log). Otherwise apply AGENTS.md §2/§4 manually.
2. [ ] Confirm the scope file exists or will be created in Step 1 —
       OSINT *discovers candidate* assets; only the program page *confirms*
       them as in scope. Label every discovered asset
       **In scope / Out of scope / Unknown** throughout. Unknown is never
       tested in this workflow.

## 1. Anchor on first-party sources (30 min)

3. [ ] Program page (HackerOne/Bugcrowd/other) read in full: scope table,
       exclusions, safe harbour, disclosure policy, known-issues / hall of
       fame hints. File into `templates/00-scope-intake.md`.
4. [ ] Company site graph: main site, product pages, pricing/tiers (tier
       differences = authorisation hypotheses), trust/security page,
       status page (component names = architecture map), legal/DPA page
       (sub-processor list = third-party surface, for awareness only).
5. [ ] Documentation universe: developer docs, API reference, help centre,
       changelog/release notes (recent features = fresh code = fresh bugs),
       public roadmap. Bookmark the API reference; extract every documented
       endpoint family into the dossier skeleton.

## 2. Technical footprint — passive DNS & certificates (20 min)

6. [ ] Certificate Transparency review (e.g. crt.sh-style public logs) for
       the in-scope root domains: list subdomains found. CT logs are
       public records — reading them touches nothing of the target's.
7. [ ] Passive DNS / public search indexes already collected by third
       parties (search-engine `site:` queries, public recon datasets) to
       add: staging/dev hostnames, regional hosts, legacy hosts, API hosts.
8. [ ] For every hostname: mark scope status, guess its role (app / API /
       docs / auth / static / mail-irrelevant), and park it in the
       dossier's surface table. **Do not resolve-scan, port-scan, or probe
       the list in this workflow** — liveness checks are active recon
       (Playbook 01, Tier B).

## 3. Code & artefact footprint (25 min)

9. [ ] Public code presence: GitHub/GitLab orgs and repos (product code if
       open-source, SDKs, example apps, docs repos, IaC — read per
       Playbook 19 §6 discipline). Note: repo names of *internal-looking*
       projects mentioned in issues/blogs; do not attempt access to
       anything non-public.
10. [ ] Shipped artefacts from your own normal browsing of in-scope apps:
        save the JS bundle list; run `scripts/js_extract.py` offline on
        bundles you downloaded as a normal visitor (Tier A) → routes,
        endpoints, feature flags, commented-out features.
11. [ ] Export one HAR of a normal Account-A session (your own traffic);
        run `scripts/har_analyzer.py` offline → endpoint/parameter/auth
        inventory. File both outputs in the hunt workspace.
12. [ ] Mobile artefacts *if* mobile is in scope: store listings, version
        history, privacy labels, linked developer docs. (Hands-on mobile
        work is Playbook 10, separately gated.)

## 4. Fingerprint & CVE pre-sweep (20 min)

13. [ ] Assemble the fingerprint list: frameworks, servers, CDN, auth
        provider, notable libraries (from headers of pages you legitimately
        loaded, JS bundles, docs, job ads). Use `scripts/tech_fingerprint.py`
        / `scripts/headers_check.py` outputs where already collected.
14. [ ] For each fingerprinted component with a version: run the Playbook 06
        pipeline — NVD / vendor advisory / GHSA / CISA KEV via
        `scripts/cve_lookup.py` — and open a `templates/07-cve-match.md`
        sheet per plausible match with verdict *Speculative* (nothing is
        verified yet; that is Phase 5 work, Tier B).
15. [ ] Check the program's disclosed reports + your writeup sources
        (`references/writeup-and-ctf-sources.md`) for this stack: 3–5
        technique cards (`templates/08-technique-card.md`) maximum.

## 5. Identity & infra surface notes (15 min)

16. [ ] Identity map seed (Playbook 18 §2): login methods visible publicly,
        SSO/IdP hints (docs for "SAML setup" reveal tenant model), passkey
        support claims, API-key docs. No flow manipulation in this workflow.
17. [ ] Infra map seed (Playbook 19 §2): storage/CDN/function hostnames the
        app itself reveals, public IaC patterns from §3.9, status-page
        component names from §1.4.
18. [ ] Realtime seed (Playbook 17 §2): note any `wss://`/SSE/Socket.IO
        endpoints visible in bundles/docs — observation only.

## 6. Assemble the attack-surface map (20 min)

19. [ ] Merge §§1–5 into the target dossier (`templates/01-target-dossier.md`)
        as one surface table: asset → scope status → role → auth model →
        crown-jewel proximity → playbook(s) that apply → cheapest first test.
20. [ ] Threat-model pass (20 min, `templates/12-threat-model.md`): crown
        jewels, actors, trust boundaries, invariants, abuse stories — now
        informed by a real map instead of guesses.
21. [ ] Convert abuse stories + CVE sheets + technique cards into the
        hypothesis backlog (`templates/02-hypothesis-backlog.md`), scored
        per `core/05`. Aim: 10–20 hypotheses, each naming its playbook.

## 7. Handoff to the operator (one message)

22. [ ] Present: (a) scope summary incl. every **Unknown** asset needing a
        ruling; (b) the surface map's top 5 rows; (c) top 5 hypotheses;
        (d) any CVE match rated above Speculative-with-a-path; (e) grouped
        Tier B asks (active recon first, in `core/02` format). Then wait.
23. [ ] File everything, hash the evidence folder if originals were saved
        (`scripts/evidence_hash.py` where available), and close with the
        standard heartbeat: findings (none expected — this is research),
        posture highlights so far, next single best action.

## 8. Quality bar & failure modes

- Every asset has a scope label; every CVE has a sheet; every claim has a
  source URL or artefact path. "I recall the stack uses X" is not OSINT.
- Finding nothing is a valid output: a thin public footprint is itself a
  posture observation (good OPSEC) — record it as such.
- Timebox discipline: if §3 code review is eating the clock, cap it and
  note the repos unreviewed. Breadth first; depth belongs to Phase 5.

## 9. Refresh variant (30 min, for ongoing hunts)

Re-run §1.5 changelogs, §2 for *new* subdomains only, §4.14 for new CVEs
against the existing fingerprint list, and §5.16–18 for newly shipped
features. Diff against the last map; promote deltas into the backlog;
note the sweep in Workflow 07's weekly review. Kick this off any time
with `prompts/09-osint-sweep.md`.
