# Workflow 09 — Bug Chain Sprint

**Purpose:** Take a hunt that already has validated (or nearly validated)
single bugs and systematically find the **joins** between them, following
Playbook 20 end-to-end: inventory → canvas → prioritise → validate weakest
link → prove one chain (or honestly prove none exists yet).

**Timebox:** One focused session of 2–4 hours. Chains reward fresh eyes —
do not run this at the end of a long testing day. **Inputs:** finding
folders, hypothesis backlog, threat model for one program. **Outputs:**
primitive inventory, scored chain canvases, at most 1–2 chain reports
ready for operator submission, plus posture/learning updates.

> **Gates:** Every link must be in scope (Playbook 20 header). Active
> validation of any link is **Tier B** — group the asks in Step 5 and get
> one approval per validation run. Links from gated playbooks (17
> smuggling/cache, 18 identity ATO, 19 credential-adjacent infra) inherit
> those playbooks' extra gates; if a gate cannot be satisfied, the chain
> is argued on paper and labelled *reasoned potential*, never forced.

---

## 0. Preflight

1. [ ] Confirm: scope file current, Account A/B healthy, threat model
       (`templates/12-threat-model.md`) exists. No threat model → spend
       20 minutes writing one first; chaining without crown jewels is
       stamp-collecting.
2. [ ] Gather materials into one view: all finding folders for the program,
       `templates/02-hypothesis-backlog.md`, technique cards
       (`templates/08-technique-card.md`), prior posture analysis,
       any earlier `templates/10-chain-canvas.md` drafts.
3. [ ] Set the session rule aloud (to the operator): *"Today we validate
       joins, we do not hunt new single bugs. New-bug ideas go in the
       backlog parking lot (§8), they do not derail the sprint."*

## 1. Build the primitive inventory (30–45 min)

4. [ ] Create/refresh `workspace/<program-slug>/primitive-inventory.md`
       exactly per Playbook 20 §2: flat capability statements, preconditions,
       gives/needs, evidence link, Confirmed/Likely/Speculative status.
5. [ ] Sweep the backlog and old sessions for the easily-forgotten rows:
       duplicates, informationals, "system facts" (token lifetimes, rate
       budgets, rendering contexts, who-reads-what facts).
6. [ ] For each Confirmed primitive older than 30 days, flag **re-proof
       needed** — it cannot carry a chain until refreshed (Playbook 20 §6.1).
7. [ ] Checkpoint to operator: inventory size, the 3 strongest primitives,
       the 3 most promising "system facts". (Short heartbeat, keep moving.)

## 2. Generate candidate chains (45 min)

8. [ ] **Backwards pass:** for each crown jewel in the threat model, run
       Playbook 20 §3.1 — what capability achieves it, which primitive
       gives that, recursively — and draft a canvas per plausible route.
9. [ ] **Forwards pass:** for each strong primitive, ask the five join
       questions (Playbook 20 §3.2): input-join, identity-join, context-join,
       precondition-removal, scaler. Draft canvases for anything with at
       least one *labelled, mechanistic* edge.
10. [ ] **Pattern pass:** check the inventory against every shape in
        Playbook 20 §4 (IDOR+export, XSS+action, redirect+OAuth,
        SSRF+metadata+role, self-XSS+delivery, low-write+privileged-reader,
        enumeration+reset budget, cache/realtime multipliers, leak+unlock).
        One line per pattern: *applies / doesn't apply / missing one link*.
11. [ ] Kill ruthlessly: delete phantom edges (no verb), merge double-counted
        single bugs, split any canvas over 7 nodes. Typical yield: 3–6
        surviving candidate chains. Fewer is fine; zero is a result.

## 3. Score & select (15 min)

12. [ ] Score survivors on the Playbook 20 §5 matrix (weakest-link status,
        interaction, accounts, impact rung, test cost/noise, duplicate risk).
13. [ ] Select: **Chain #1** = highest score. **Chain #2** = highest impact
        among chains whose only weakness is one Speculative link (that link
        becomes a standalone validation task). Everything else is parked
        with its canvas filed — parked, not deleted.
14. [ ] Present the selection to the operator with, per chain: the drawing
        in words (5 lines max), the demonstrated rung vs reasoned rung,
        and what proof will cost in requests/accounts/time.

## 4. Validate the weakest links first (45–60 min)

15. [ ] For Chain #2's speculative link (and any *Likely* link in Chain #1):
        write the cheapest falsification test (one hypothesis, one variable,
        `core/05` doctrine) and add it to the Tier B batch in Step 5.
16. [ ] Pre-write, for every validation run: the exact requests, the A/B
        roles, the stop conditions (AGENTS.md §2.6 plus chain-specific:
        "stop if the hand-off artefact does not appear"), and the evidence
        to capture at each hand-off (Playbook 20 §6.2).
17. [ ] Also pre-write the **negative-result plan**: what a failed link
        teaches (which control exists at that join) and where it gets
        recorded (backlog + posture draft). A sprint that can only "succeed"
        is a biased sprint.

## 5. Tier B gate (one grouped ask)

18. [ ] Send ONE message in `core/02-approval-protocol.md` format covering:
        what (each validation run, named by chain + link), why, targets &
        rates (default ≤1 rps, own accounts/objects only), expected
        noise/impact, and how each run stops. **Wait for the operator's yes.**
        A yes covers these runs only.

## 6. Execute & prove (45–60 min)

19. [ ] Re-prove Chain #1's links fresh, in order (Playbook 20 §6.1);
        log timestamps; abort the chain (not the session) at the first
        dead link and switch to the §4.17 negative-result plan.
20. [ ] Run the composition **once**, capturing hand-off evidence at every
        edge. Land on the minimum-impact end state (your B session vs your
        A account / your marker object). Stop at first demonstration.
21. [ ] Repeat §6.19–20 for Chain #2 only if its weak link validated.
        Maximum two chain proofs per sprint — depth over breadth.
22. [ ] Clean up test artefacts you created (uploaded files, tickets,
        linked identities) where the program expects it; note cleanup in
        the evidence log.

## 7. Report & teach (30 min)

23. [ ] For each proved chain: ONE report per Playbook 20 §8
        (`templates/03-finding-report.md`, canvas attached as appendix),
        through `checklists/report-qa.md`. Operator submits — Tier B.
24. [ ] For each failed chain: one backlog entry with the dead link, the
        control discovered, and the condition that would revive the chain
        ("if a delivery primitive for the self-XSS is ever found, revisit").
25. [ ] Update `templates/05-posture-analysis.md`: add the joins view —
        which trust boundaries held, which assumed the other side checked,
        plus one sequence-correlation detection idea per chain attempted
        (Playbook 20 §10).
26. [ ] Update `templates/06-learning-notes.md` + flashcards: the pattern
        (§4 shape) behind each attempted chain, explained from first
        principles, with one self-check question per pattern.
27. [ ] Close with the standard heartbeat: chains proved / chains killed
        (and why), inventory deltas, parked canvases, single best next action.

## 8. Parking lot & anti-patterns

- New single-bug ideas spotted mid-sprint → backlog, one line each, no testing.
- Never extend a chain live beyond the approved drawing "to see what
  happens" — new edges mean a new canvas and a new Tier B ask.
- Never run this workflow on a program with zero validated primitives and
  call the output chains — the honest output then is "inventory empty;
  return to Playbooks 01–05", said plainly in the heartbeat.
- Kick this workflow off any time with `prompts/10-chain-sprint.md`.
  For the realtime/smuggling/cache session that often *feeds* this sprint,
  see `prompts/11-smuggling-and-cache-session.md` and Playbook 17.
