# Workflow 10 — 90-Day Review & Skill-Gap Plan

**Purpose:** Every ~90 days (or ~40–60 hunt hours, whichever comes first),
stop hunting long enough to answer three questions with evidence:
*What did I actually find and learn? Where are my skill gaps, measured —
not vibes? What exactly will the next 90 days practise, in what order?*
This workflow produces a written review and a concrete, dated study +
hunting plan. It extends Workflow 07 (weekly review) — weekly keeps a
hunt honest; quarterly keeps a *career* honest.

**Timebox:** Half a day, split into two sittings (§§1–3, then §§4–6).
**Inputs:** all hunt workspaces, learning notes, flashcard records, report
outcomes for the quarter. **Outputs:** 90-day review document, skill-gap
matrix, next-90-days plan with weekly milestones — all filed in the
current hunt workspace root (or a dedicated `reviews/` folder).

> **Tone rule:** this is a training review, not a performance review.
> The operator is a student building fundamentals (see `learning/01`,
> `learning/09` career roadmap where present). Measure generously but
> honestly: a quarter of solid negatives + deep learning notes can be a
> better quarter than two lucky duplicates.

---

## Sitting 1 — Evidence before opinions

## 1. Assemble the quarter's record (45 min)

1. [ ] List every hunt: program, dates, hours (estimate honestly), phases
       reached, playbooks used. One row per hunt in a table.
2. [ ] List every report: title, severity claimed, outcome (accepted /
       duplicate / informational / N/A / still open), bounty if any,
       days-to-triage. Attach the report- QA verdicts
       (`checklists/report-qa.md`) — were the claims calibrated?
3. [ ] List every *validated negative*: hypotheses tested and ruled out,
       per hunt. (AGENTS.md §13 counts these as first-class output.)
4. [ ] Collect the learning artefacts: learning notes
       (`templates/06-learning-notes.md`) written, flashcards created vs
       reviewed vs due/overdue (`checklists/learning-retention.md`),
       self-check questions answered from memory in weekly reviews.

## 2. Compute the honest metrics (30 min)

5. [ ] Rates: hypotheses → validated findings; findings → accepted reports;
       duplicates as a share of submissions (research quality signal, see
       Playbook 06/16); false positives submitted (target: ~zero —
       investigate every exception by name).
6. [ ] Coverage: which playbooks (01–20) were actually exercised? Which
       bug classes produced findings vs which produced only attempts?
       Draw the 20-playbook grid and shade it — the white space *is* the
       skill-gap map's first draft.
7. [ ] Time shape: hours by phase (recon / testing / validation /
       reporting / learning). Flag the two classic distortions: recon
       that never ends, and learning notes skipped under time pressure.
8. [ ] Detection lens audit: for how many findings did the posture
       analysis (`templates/05`) include a testable detection hypothesis
       (AGENTS.md §8)? For how many hunts is there *any* evidence a
       control fired? SOC skill grows exactly here.

## 3. Re-test yourself (60 min — no notes, no pack open)

9. [ ] From the quarter's flashcards and self-check questions, sample
       15–20 across foundations: networking (`learning/03`), HTTP/web
       (`learning/04`), auth/tokens (Playbook 18 §1), cloud/serverless
       (Playbook 19 §1), one chain drawn from memory (Playbook 20 §3).
       Answer in writing, from memory. Grade kindly, mark precisely.
10. [ ] Practical spot-check: re-prove, in a **lab** (Tier A), one
        technique you reported this quarter (e.g. a BOLA sequence against
        a local vulnerable app, an OAuth flow in your own dev IdP tenant).
        Can your hands still do what your reports say you did?
11. [ ] Record every miss verbatim in a `shaky-concepts` list — phrased
        as the *fundamental* that is shaky ("I cannot yet explain how a
        CDN cache key is built"), never as a vague topic ("caching").

## Sitting 2 — Gaps, plan, commitments

## 4. Build the skill-gap matrix (45 min)

12. [ ] Rate each row **0 = untouched, 1 = can follow a playbook,
        2 = can hunt it independently, 3 = can teach it from first
        principles** — with one evidence pointer per rating (a finding,
        a note, a lab, or "no evidence yet"):
        Foundations: networking · HTTP/web · Linux/Windows basics ·
        scripting (Python) · cryptography literacy.
        Hunting: recon/OSINT (PB 01, WF 08) · core web classes (PB 02) ·
        API/GraphQL (PB 03) · auth/session (PB 04) · business logic/races
        (PB 05) · CVE matching (PB 06) · writeup mining (PB 07) ·
        creative R&D (PB 08) · cloud/SSRF (PB 09) · mobile (PB 10) ·
        AI/LLM apps (PB 11) · client-side (PB 13) · deserialisation/supply
        chain (PB 14) · realtime/smuggling/cache (PB 17) · OAuth/OIDC/
        passkeys (PB 18) · serverless/edge (PB 19) · chaining (PB 20).
        Professional: validation/CVSS honesty (PB 15) · reporting &
        disclosure (PB 16) · posture/SOC analysis · threat modelling.
13. [ ] Pick **at most three** priority gaps, by this rule: (impact on
        the hunts you actually do) × (how foundational it is) ÷ (hours
        to move it one level). Three gaps, not ten — a plan with ten
        priorities has none.
14. [ ] For each priority gap, name the *root* below it: e.g. "smuggling
        is shaky" → root is "HTTP request parsing is shaky" →
        `learning/04` + PortSwigger labs before any live Playbook 17 work
        (AGENTS.md §14's lab-first rule applies to the plan itself).

## 5. Write the next-90-days plan (45 min)

15. [ ] Structure per priority gap: **Learn** (specific files/labs, in
        order) → **Lab** (one hands-on exercise with a pass condition) →
        **Hunt** (one real-program application, scoped + Tier-B-planned)
        → **Prove** (the artefact that shows the level moved: a note a
        beginner could learn from, a validated finding, or a clean,
        well-documented negative).
16. [ ] Lay it out as 12 weekly milestones (one line each, falsifiable:
        "complete PortSwigger smuggling labs 1–5 and write the learning
        note", not "get better at smuggling"). Leave weeks 4, 8, 12
        lighter — review/retest weeks running Workflow 07.
17. [ ] Schedule balance explicitly: hunting hours vs study hours
        (a student default that works: ~60/40), the programs in rotation,
        and one *stretch* target (a program or class one level above
        current comfort) named in writing.
18. [ ] Add the maintenance lines: flashcard reviews stay current,
        weekly Workflow 07 continues, CVE/writeup mining (Workflows
        02/03) at least twice in the quarter, one full Workflow 08 OSINT
        refresh and one Workflow 09 chain sprint booked by name.

## 6. Close the review (30 min)

19. [ ] Write the 90-day review document (2–4 pages): quarter in numbers
        (§2), best finding and *why it was good work*, worst mistake and
        its root cause, the three priority gaps with evidence, the
        12-week plan, and one paragraph of honest posture: what kind of
        hunter this quarter's evidence says you are becoming.
20. [ ] Operator conversation: walk through §§4–5 together; the operator
        may re-rank the three gaps — his goals govern (`learning/09`
        roadmap alignment). Record any changes in the document.
21. [ ] File everything, update MEMORY-worthy facts only via the normal
        memory route (do not edit memory files directly), and set the
        next review's trigger (date or hunt-hour count) in the plan.
22. [ ] End with the standard heartbeat: review location, the three gaps
        in one line each, week 1's milestone, and the single best next
        action (which is almost always: start week 1).

## Anti-patterns

- **Bounty-count as the scoreboard.** Rejected by AGENTS.md §13; this
  workflow measures validated learning and calibrated reporting instead.
- **Gap inflation.** Rating everything 0–1 to feel thorough produces a
  plan that practises nothing. Evidence pointers (§4.12) prevent this.
- **Plan without labs.** Reading about passkeys is not a passkey skill;
  every gap needs its hands-on exercise (§5.15).
- **Skipping Sitting 1.** A plan written from impressions will practise
  what you *enjoy*, not what you *lack*. Evidence first, always.
- Re-run cadence: quarterly, or early if you change focus (new job target,
  new program type, a first critical) — the trigger is written in §6.21.
