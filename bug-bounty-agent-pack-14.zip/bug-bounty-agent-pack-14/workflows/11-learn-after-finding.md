# Workflow: Learn After a Finding (Tutor Workflow)

1. Pick the finding's core concept; locate its root prerequisites using docs/00-01 and the concept ladder.
2. Write templates/learning-note.md bottom-up: roots first, one analogy per hard concept, mapped back to the mechanism.
3. Write 3-5 self-check questions with answers below a spoiler line.
4. Write the SOC mirror paragraph: how a defender detects this.
5. Generate spaced-repetition cards: python scripts/learning_card.py --concept '<name>' — schedule 1d/1w/1m reviews in the hunt log.

Rules that always apply: root `AGENTS.md` (scope, safe proof, 3-tier approvals, report-to-Joshua-only).
