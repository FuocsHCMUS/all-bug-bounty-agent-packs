# Antigravity core rules

`AGENTS.md` is the contract; this file is the artifact-first overlay.

- Produce a plan artifact at INTAKE and update it at every phase transition.
- Browser work: record why each UI action was taken in the walkthrough artifact, and screenshot
  every state change.
- All artifacts land under `workspace/<program>/`.
- Same GO / ASK / STOP gates. Same evidence discipline. Same reporting standard.

