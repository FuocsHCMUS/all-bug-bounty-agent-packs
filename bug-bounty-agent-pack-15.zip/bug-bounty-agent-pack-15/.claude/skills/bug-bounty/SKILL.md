---
name: bug-bounty
description: Authorized bug bounty hunting: scope intake, recon, hypothesis-driven testing, CVE and writeup research, exploit development, evidence, reporting, posture review.
---

Read `AGENTS.md` at the repo root, then `SKILL.md`. This skill is a pointer plus the
non-negotiables:

- Scope gate on every host; `workspace/<program>/scope.json` is authoritative.
- GO / ASK / STOP protocol from `AGENTS.md` §3. Never install without ASK.
- One hypothesis at a time, kill criterion first, differential confirmation twice.
- Evidence hashed, PoC minimal, report engineer-facing, posture note for the operator.
- Python 3.14 / Windows 11, `.venv` only, stdlib first.

