# Core rules (Cline)

Mirror of `AGENTS.md` §1-6. Read the original before deviating.

- Scope gate on every request. `workspace/<program>/scope.json` allow/deny wins.
- GO: workspace edits, portable clones, venv pip, stdlib scripts, passive recon, low-rate probing.
- ASK: installers, MCP, plugins, mutations, heavy fuzzing, disruptive tests, submission.
- STOP: scope doubt, possible critical, PII, degradation.
- Differential confirmation twice; one hypothesis at a time; kill criteria first.
- Evidence hashed; PoC minimal; report engineer-facing; posture note for the student.
- Python 3.14 / Windows 11; `.venv` only; stdlib before packages.

When you need a tool that is not present, propose the lowest tier that solves it and wait.

