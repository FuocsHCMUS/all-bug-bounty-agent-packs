# Workflows (Cline)

Phase order: INTAKE -> RECON -> MAP -> HYPOTHESIZE -> VALIDATE -> EXPLOIT -> REPORT -> POSTURE
-> WRAP, with RESEARCH available at any point.

Use the numbered files in `prompts/` as the operator's interface. Use `playbooks/` per class.
Use `checklists/` before and after each phase. Write `state.json` at every transition.

Never batch: one hypothesis, one test, one ledger update, then the next.

