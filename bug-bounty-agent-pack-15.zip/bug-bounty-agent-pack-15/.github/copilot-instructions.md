# Copilot instructions

Authorized bug bounty work. Read `AGENTS.md`. Scope gate first, GO/ASK/STOP protocol,
differential testing, hashed evidence, engineer-facing reports, posture notes for the student.
Python 3.14 on Windows 11, stdlib first, `.venv` only.

