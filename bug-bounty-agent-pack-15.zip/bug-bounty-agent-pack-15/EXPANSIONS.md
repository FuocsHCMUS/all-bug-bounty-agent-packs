# EXPANSIONS — Ideas Added Beyond the Original Brief (v23)

Per the operator's standing preference, every expansion beyond the merge
brief is listed here:

1. **Content-hash provenance, not filename guessing.** Every file in packs
   17/18/19 was hash-compared against pack-20 before grafting. This proved
   pack-18 was already fully absorbed into pack-20 — so v23 spends zero
   space duplicating it, and the claim is checkable, not asserted.
2. **Hypothesis Ledger promoted to a hard gate** (AGENTS.md §15 +
   checklist). In pack-19 it was a template; in v23 no non-trivial testing
   starts without claim + primitive + kill criterion + differential plan.
3. **Creative Offensive Thinking Engine as a core doc** (`core/11`):
   7 named generators (assumption inversion, parser differentials,
   state-machine abuse, second-order, differential accounts,
   primitives-over-names, invent-then-kill) plus a timed 90-minute session
   protocol — creativity as a repeatable procedure, not a mood.
4. **Invent-then-kill workflow** (`workflows/11`) operationalises the
   engine with timeboxes and a graduation path into chaining.
5. **Guardrail de-duplication, honestly labelled.** Instead of pretending
   to "remove safety", v23 removed the *repetition* (dozens of restated
   chapters across the source packs) and consolidated the platforms' own
   Rules of Engagement into one lean gate (§17 + `core/12`), with the
   reasoning written down: unlimited thinking/research/local development;
   scoped execution — because HackerOne/Bugcrowd enforce scope themselves
   and out-of-scope work gets findings rejected and accounts banned.
6. **Three playbook granularities kept and mapped** (numbered workflow
   playbooks / by-class / per-vuln) with AGENTS.md §18 explaining when to
   use which, instead of silently overwriting near-duplicates.
7. **Machine-readable contracts**: pack-17's JSON schemas for scope,
   hypothesis and finding were kept and wired to the ledger (§15), so
   other agents/tools can validate hunt state.
8. **Root drop-in adapters restored** from pack-17 (.cursor/.clinerules/
   .agent/.claude/.github/.mcp at pack root) alongside pack-20's
   `platforms/` tree and pack-19's `adapters/` tree — three install
   styles, one canonical AGENTS.md.
9. **Active-testing tools re-included with their gate stated**: pack-17's
   race_runner and oob_listener return (earlier merges dropped them),
   documented as operator-approved, in-scope, own-accounts tools under §4.
10. **`tools/verify_pack23.py`** — a stdlib verifier for this exact layout,
    replacing pack-17's dropped layout-specific verifier.
