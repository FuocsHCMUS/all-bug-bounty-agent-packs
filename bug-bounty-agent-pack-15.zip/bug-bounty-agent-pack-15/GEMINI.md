# GEMINI.md / Antigravity entry

Read `AGENTS.md` (contract) and `SKILL.md` (method). Artifacts belong in
`workspace/<program>/`; Antigravity artifact panes should point at `workspace/reports`.

Antigravity-specific: keep the plan artifact updated at phase transitions, and put the
browser-automation rationale in the walkthrough artifact so the operator can audit what the
agent did in the UI.

