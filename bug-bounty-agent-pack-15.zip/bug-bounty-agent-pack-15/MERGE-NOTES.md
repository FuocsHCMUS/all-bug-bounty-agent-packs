# MERGE NOTES — How Pack 23 Was Built

Pack 23 is a merge of the four packs uploaded for this build — **17, 18, 19,
20** — which themselves consolidate packs 10–16. Method: content-hash diff
of every file in 17/18/19 against pack-20, then grafting of everything
unique, then new v23 authoring.

## Provenance

| Source | Role in v23 | What was taken |
|---|---|---|
| **Pack 20** (137 files) | **Canonical base** | AGENTS.md §§1–14, core 01–10, numbered playbooks 01–20 (incl. WebSocket/smuggling/cache, OAuth/OIDC/passkeys, serverless/edge, chaining at scale), workflows 01–10, learning 00–09 (incl. crypto + OS basics + career roadmap), platforms/ adapters for all 6 tools, templates 00–15, scripts (10 helpers incl. har_analyzer, js_extract, evidence_hash), references incl. modern sources 2024–2026 |
| **Pack 19** (119 files) | **Tutor + ledger layer** | docs/ 00–13, adapters/ (second full adapter layout), prompts/roles (senior-pentester, research-librarian, soc-mirror, tutor), templates/named (incl. **Hypothesis Ledger**, owner-summary, daily-hunt-log, duplicate-check, writeup-mining), workflows/named (incl. learn-after-finding), playbooks/by-class (18), checklists evidence/posture/pre-submit/recon, scripts cve_lookup_nvd + learning_card + make_finding_folder, 3 fictional examples (IDOR invoice, SSRF webhook, race coupon) |
| **Pack 17** (131 files) | **Role-agent + deep-dive layer** | agents/ (11 role agents), prompts/sequential 00–13, playbooks/per-vuln (16 granular), learning/deep-dives (15 topics: caching/proxies, cloud IAM, crypto pitfalls, DNS, HTTP/2 & parsers, JS runtime/DOM, same-origin/CORS, sessions, TLS…), research/ (CVE loop, writeup mining, prior-art & novelty, KB schema), posture/ framework, reporting/ (severity guide, triage defense), ops/, schemas/ (scope/hypothesis/finding JSON), root drop-in adapters (.agent/.claude/.clinerules/.cursor/.github/.mcp, opencode.json, GEMINI.md, QUICKSTART.md), unique tools (jwt_inspect, cvss, diff_response, param_miner, js_endpoint_extract, evidence_hasher, report_builder, bootstrap, race_runner, oob_listener) |
| **Pack 18** (108 files) | **Verified absorbed** | Content-hash check: every substantive file in pack-18 is byte-identical to a file already in pack-20 (only README/meta files differ). Nothing unique was lost; pack-20 *was* pack-18's successor. Its threat-model-first Phase 0.5, retest workflow and learning-retention checklist all live on in the base layer. |

## Deliberately dropped / de-duplicated
- **CLAUDE.md** (present in 17/18): dropped — Claude Code reads AGENTS.md
  natively now, per the operator's standing note.
- **Duplicate scripts**: pack-17's cve_lookup/http_probe/scope_guard and
  pack-19's headers_check/http_probe/inventory/make_hunt/scope_guard/
  tech_fingerprint duplicate the pack-20 `scripts/` versions (kept).
  Pack-17's layout-specific `verify_pack.py` dropped; replaced by
  `tools/verify_pack23.py` written for this layout.
- **Repeated safety chapters**: the source packs restated scope/safety
  rules in dozens of files. v23 consolidates them into AGENTS.md §2 + §14
  + §17 and `core/12-roe-as-enabler.md`. No rule that a platform itself
  enforces was removed; every *duplicate restatement* was. Ideation,
  research and local development are explicitly unlimited (§16).

## New in v23 (authored for this merge)
- AGENTS.md §§15–18 (Hypothesis Ledger mandate, Creative Engine summary,
  lean RoE gate, layer map)
- `core/11-creative-offensive-thinking-engine.md` (7 generators + session protocol)
- `core/12-roe-as-enabler.md`
- `workflows/11-invent-then-kill.md`
- `checklists/hypothesis-ledger-gate.md`
- `tools/verify_pack23.py`, this file, `EXPANSIONS.md`, new `README.md`
