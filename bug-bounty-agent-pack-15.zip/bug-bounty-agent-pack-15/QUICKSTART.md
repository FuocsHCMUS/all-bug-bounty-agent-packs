# Quickstart

```
1. py -3.14 -m venv .venv
2. .venv\Scripts\python.exe -m pip install -r tools\requirements-optional.txt   (optional)
3. .venv\Scripts\python.exe tools\verify_pack.py
4. Open prompts/00-kickoff.md and paste it to your agent.
5. prompts/01-scope-intake.md -> paste program URL and scope text.
6. prompts/02-recon.md -> passive only.
```

If the agent starts probing before `scope.json` exists, stop it and point at AGENTS.md §1.

