# Bug Bounty Agent Pack 23 — Merged Super Agent Pack

The merged successor to packs **17 + 18 + 19 + 20** (which consolidate
10–16). One canonical instruction file, every adapter, three playbook
layers, a mandatory hypothesis ledger, a creative offensive thinking
engine, a full research system (CVE / writeups / CTF), post-finding
posture analysis + beginner-first teaching, and 24 tested Python helpers.
All in English. Built for Python 3.14+ on Windows 11 (helpers are
stdlib-only and cross-platform).

## Start in 5 minutes
1. Read `START-HERE.md` and copy the adapter for your tool
   (Claude Code / Codex / OpenCode / Cline / Cursor / Antigravity) —
   or just copy the pack root: it also carries root drop-in adapters.
2. The agent reads `AGENTS.md` (canonical; §18 maps every layer).
3. First hunt: `workflows/01-start-a-hunt.md`, ledger first (§15).

## What's inside
- **Canonical:** `AGENTS.md` §§1–18, `SKILL.md`, `core/01–12`
- **Playbooks:** numbered 01–20 · `by-class/` (18) · `per-vuln/` (16)
- **Workflows:** 01–11 + `named/` set (incl. learn-after-finding)
- **Agents & prompts:** `agents/` (11 roles) · `prompts/sequential/` 00–13 ·
  `prompts/roles/` (senior pentester, research librarian, SOC mirror, tutor)
- **Learning:** curriculum 00–09 · `deep-dives/` (15) · `docs/` 00–13 ·
  glossary, SOC lens, safe-lab roadmap
- **Research:** CVE loop, writeup/CTF mining, technique synthesis,
  prior-art & novelty, knowledge-base schema (`research/`, `schemas/`)
- **Templates & checklists:** scope intake, threat model, hypothesis
  ledger, chain canvas, finding report, posture analysis, learning notes,
  retest log, evidence manifest + preflight/scope/exploit/report gates
- **Tools:** `scripts/` + `tools/` — 24 stdlib-only Python helpers (13 + 11)
  (scope guard, CVE lookup, header/tech checks, HAR analysis, JS endpoint
  extraction, JWT inspection, CVSS, response diffing, parameter mining,
  evidence hashing, race runner, OOB listener, report builder…)
- **Examples:** fictional end-to-end findings (IDOR, SSRF, race, chain, CVE match)

## Operating shape (the short version)
Think without a ceiling — invent, research, build locally, chain
primitives (§16 Creative Engine). Execute inside the program's published
scope, on your own accounts, with minimal proof (§17 — the platforms'
own rules, stated once). Report to Joshua; Joshua submits. After every
finding: posture analysis + a from-first-principles lesson (§8).

Provenance & merge decisions: `MERGE-NOTES.md` · Expansions: `EXPANSIONS.md`
