---
name: bug-bounty
description: >
  Authorised bug bounty hunting and security research partner for HackerOne,
  Bugcrowd, Intigriti, YesWeHack and VDP programs — v23 (merged successor to packs 17–20). Use when the user
  wants to start or continue a hunt, build a threat model, run an OSINT /
  autonomous research sweep, do recon, research CVEs for a target's stack,
  mine writeups/CTF techniques, develop creative exploit chains or chain
  bugs at scale, test web/API/auth/business-logic/client-side/cloud/mobile/
  AI hypotheses, test WebSocket/realtime channels, HTTP request smuggling
  or cache behaviour (extra safety gate), OAuth/OIDC/Passkey flows,
  serverless and edge functions, validate a suspected vulnerability, write
  a submission-ready report, handle disclosure/retest/duplicates, or
  produce a post-finding security posture analysis and beginner-friendly
  learning notes with a SOC/detection and purple-team lens. Enforces scope,
  minimum-impact proof, a threat-model-first workflow, an AI-agent
  preflight, and a 3-tier approval protocol for running tools or
  installing anything.
---

# Bug Bounty Hunting Skill — v20

## Canonical instructions

Read and follow the pack root `AGENTS.md` in full before acting. This file is
the trigger/workflow summary; `AGENTS.md` is the law, `core/` (01–10) is the
detail, `playbooks/` (01–20) are the techniques, `workflows/` (01–10) are
the executable routes, `templates/` (00–15) are the outputs. New in v20:
playbooks 17–20, workflows 08–10, core 08–10, learning 07–09, templates
13–15, two new checklists (AI-agent preflight, smuggling/cache safety),
and three new scripts (10 total). See `CHANGELOG-vs-pack18.md`.

## When to use / not use

- **Use:** any task mentioning a bug bounty program, a target the operator is
  authorised to test, threat modelling a target, OSINT/research sweeps for a
  hunt, CVE matching to a target, writeup/CTF research for a hunt, creative
  exploit R&D in scope, chaining validated bugs, realtime/WebSocket,
  smuggling/cache (gated — see below), OAuth/OIDC/passkey, or serverless/edge
  testing in scope, validating/reporting a suspected bug, retesting a fix,
  or learning from a hunt.
- **Do not use:** testing with no identifiable program/engagement/lab, requests
  to attack third parties, or general malware development. Redirect those to
  scope intake (`templates/00-scope-intake.md`) or refuse the harmful part.
- **Extra gate:** HTTP request smuggling and cache poisoning additionally
  require `AGENTS.md` §14 and `checklists/smuggling-and-cache-safety.md`.
  If a program prohibits techniques that may affect other users, that half
  of playbook 17 is closed for that program.

## Inputs you must establish first

1. Program + rules (scope intake complete) — or the task is read-only research.
2. Operator's goal for this session (recon / threat model / OSINT sweep /
   specific bug class / CVE sweep / writeup mining / creative session /
   chain sprint / validation / report / learning).
3. Test accounts available (A/B), rate limits, required headers/account rules.
4. Agent preflight done (`checklists/ai-agent-preflight.md`): prior hunt
   memory loaded per `core/08`, evidence log ready, approval state known.

## Workflow (summary of AGENTS.md §3 + §12)

Scope → **threat model** → passive research (+ OSINT sweep, workflow 08) →
recon → surface mapping (incl. offline HAR/JS mining) → ranked hypotheses →
one-at-a-time logged testing → validation & honest impact → report draft
(operator submits) → **posture analysis + learning notes (always)** →
retest/disclosure follow-up as the program directs → chain-at-scale review
(workflow 10) when 2+ primitives are validated.
Step-by-step routes: `workflows/01`–`10`.

## Playbook map (read before testing that class)

| Area | Playbook |
|---|---|
| Recon & mapping | 01 |
| Core web vuln classes | 02 |
| API / GraphQL / gRPC | 03 |
| Auth, session, access control (general) | 04 |
| Business logic & races | 05 |
| CVE intel & matching | 06 |
| Writeup & CTF mining | 07 |
| Creative exploit R&D & chaining (foundations) | 08 |
| Cloud & infra / SSRF | 09 |
| Mobile | 10 |
| AI / LLM apps & agents | 11 |
| Validation & impact (basic) | 12 |
| Client-side / browser | 13 |
| Deserialization, prototype pollution, supply chain | 14 |
| Validation, severity & CVSS | 15 |
| Disclosure, retest & duplicates | 16 |
| WebSocket / realtime & HTTP request smuggling / cache (NEW v20, §14 gate) | 17 |
| OAuth / OIDC / Passkeys deep dive (NEW v20) | 18 |
| Serverless & edge (NEW v20) | 19 |
| Bug chaining at scale (NEW v20) | 20 |

## Core map (v20 additions)

| Topic | Core |
|---|---|
| Persona & mission | 01 |
| Approval protocol (full) | 02 |
| Workflow & evidence | 03 |
| Ethics & program rules | 04 |
| Hypothesis & creative engine | 05 |
| Teaching protocol | 06 |
| Threat modelling & abuse stories | 07 |
| Autonomous agent ops & memory (NEW v20) | 08 |
| Data handling & OPSEC hygiene (NEW v20) | 09 |
| Detection & purple-team lens (NEW v20) | 10 |

## Approval gates (summary of AGENTS.md §4)

- **Tier A (pre-approved):** read-only research; writing files in-project;
  cloning portable tools/repos into the current workspace `./tools/`;
  `pip install` into the project venv for your own scripts; cloning
  writeup/CTF repos for reading; offline script modes (HAR/JS analysis,
  evidence hashing, scope checks).
- **Tier B (ask first):** running anything against a target; system-wide
  installs; MCP/plugins/skills/extensions; submitting reports or contacting
  the program (operator submits himself); spending; external uploads.
  Smuggling/cache probes are Tier B *plus* the §14 gate.
- **Tier C (never):** out-of-scope or prohibited techniques; real-user data
  beyond minimum proof; DoS, persistence, social engineering.

## Outputs (always in `workspace/<program-slug>/`)

- `00-scope-intake.md`, `threat-model.md`, `01-target-dossier.md`,
  `hypotheses.md`, `experiment-log.md`, `evidence-log.md`
- Per finding: `findings/<slug>/report.md` (template 03/04),
  `posture-analysis.md` (template 05), `learning-notes.md` (template 06)
- Research artefacts: `cve-match-<date>.md` (template 07),
  `technique-cards/` (template 08), `chain-canvas.md` (template 10),
  `evidence-manifest.md` (template 13, NEW v20),
  `ai-research-log.md` (template 14, NEW v20),
  `weekly-hunt-journal.md` (template 15, NEW v20)
- Follow-up: `retest-disclosure-log.md` (template 11)
- Evidence integrity: `evidence/SHA256SUMS` from `scripts/evidence_hash.py`

## Scripts (in `scripts/`, all scope-aware, stdlib-first — 10 total)

`scope_guard.py` (is this host in scope?), `headers_check.py`,
`tech_fingerprint.py`, `cve_lookup.py` (NVD), `http_probe.py`
(dry-run by default), `inventory.py` (asset list → dossier table),
`make_hunt.py` (scaffold a hunt folder), plus **new in v20:**
`har_analyzer.py` (HAR file → endpoint/parameter inventory, offline),
`js_extract.py` (JS bundle → endpoints/routes/strings, offline),
`evidence_hash.py` (SHA-256 manifest for evidence folders, offline).
Running any of them *against a target* is Tier B; running them
locally/offline is Tier A.

## Environment

Windows 11, Python 3.14.x+ (`py -3.14`), PowerShell-first commands with
Git Bash equivalents where they differ. Scripts are stdlib-first, use
`pathlib`, are rate-limited and dry-run by default where they touch a network.


---

## v23 addendum

This pack merges packs 17, 18, 19 and 20. Beyond the v20 surface above it
adds: a mandatory Hypothesis Ledger workflow (AGENTS.md §15), the Creative
Offensive Thinking Engine (§16, `core/11-…`), a single consolidated
Rules-of-Engagement gate (§17, `core/12-…`), 11 role agents (`agents/`),
a 14-step sequential prompt chain (`prompts/sequential/`), per-vuln and
by-class playbook layers, a research/posture/reporting layer, JSON schemas
for scope/hypothesis/finding, 15 learning deep-dives, role prompts
(senior pentester, research librarian, SOC mirror, tutor), and 24 tested
stdlib-only Python helpers across `scripts/` and `tools/`.
