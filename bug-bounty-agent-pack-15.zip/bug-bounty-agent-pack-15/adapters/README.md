# Adapters
This adapter is a thin pointer. The canonical instructions live in the pack root `AGENTS.md` — read and follow that file in full. If anything here conflicts with it, `AGENTS.md` wins.

Pick exactly one adapter folder for your tool and copy its contents into your project root (preserving subfolders like `.cursor/rules/`). Keep the pack's `docs/`, `playbooks/`, `workflows/`, `checklists/`, `templates/`, and `scripts/` folders alongside it — adapters reference them by relative path.
