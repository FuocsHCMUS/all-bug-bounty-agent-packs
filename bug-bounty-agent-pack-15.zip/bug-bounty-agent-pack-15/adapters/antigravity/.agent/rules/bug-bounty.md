# Antigravity rules — Bug Bounty Pack 19
This adapter is a thin pointer. The canonical instructions live in the pack root `AGENTS.md` — read and follow that file in full. If anything here conflicts with it, `AGENTS.md` wins.

Authoritative text: pack root `AGENTS.md`. Workflows in `.agent/workflows/` implement its Phase 0-7 loop. Tier B approvals (system installs, MCP/plugins/skills) require Joshua's explicit confirmation.
