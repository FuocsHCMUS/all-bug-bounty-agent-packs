---
description: Full hunt: intake -> threat model -> inventory -> hypotheses -> research -> safe testing -> report pack to Joshua.
---
# /hunt
Full hunt: intake -> threat model -> inventory -> hypotheses -> research -> safe testing -> report pack to Joshua.
Follow the corresponding pack workflow under `workflows/` and the canonical `AGENTS.md`. Deliverables go to Joshua only.
