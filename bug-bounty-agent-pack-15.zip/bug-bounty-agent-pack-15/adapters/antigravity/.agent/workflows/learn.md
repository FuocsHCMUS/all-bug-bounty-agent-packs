---
description: Write the beginner-first learning note + spaced-repetition cards for a finding or session.
---
# /learn
Write the beginner-first learning note + spaced-repetition cards for a finding or session.
Follow the corresponding pack workflow under `workflows/` and the canonical `AGENTS.md`. Deliverables go to Joshua only.
