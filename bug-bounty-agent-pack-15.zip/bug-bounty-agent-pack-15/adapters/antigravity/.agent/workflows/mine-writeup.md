---
description: Mine a disclosed report / writeup / CTF solution into a reusable technique card.
---
# /mine-writeup
Mine a disclosed report / writeup / CTF solution into a reusable technique card.
Follow the corresponding pack workflow under `workflows/` and the canonical `AGENTS.md`. Deliverables go to Joshua only.
