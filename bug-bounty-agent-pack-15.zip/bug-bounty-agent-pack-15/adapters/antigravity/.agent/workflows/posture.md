---
description: Write the posture analysis (strengths, gaps, risk register, SOC detection) for a finding.
---
# /posture
Write the posture analysis (strengths, gaps, risk register, SOC detection) for a finding.
Follow the corresponding pack workflow under `workflows/` and the canonical `AGENTS.md`. Deliverables go to Joshua only.
