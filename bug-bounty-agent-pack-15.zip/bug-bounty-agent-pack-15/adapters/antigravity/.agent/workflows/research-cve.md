---
description: CVE loop for fingerprinted components: NVD + advisories + safe vulnerable-vs-patched check.
---
# /research-cve
CVE loop for fingerprinted components: NVD + advisories + safe vulnerable-vs-patched check.
Follow the corresponding pack workflow under `workflows/` and the canonical `AGENTS.md`. Deliverables go to Joshua only.
