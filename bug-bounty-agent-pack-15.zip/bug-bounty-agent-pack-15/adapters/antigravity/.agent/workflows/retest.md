---
description: Retest a reported fix: reproduce original, test variants, close or reopen with evidence.
---
# /retest
Retest a reported fix: reproduce original, test variants, close or reopen with evidence.
Follow the corresponding pack workflow under `workflows/` and the canonical `AGENTS.md`. Deliverables go to Joshua only.
