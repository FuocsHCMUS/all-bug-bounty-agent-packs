# Antigravity adapter
Copy `.agent/rules/` + `.agent/workflows/` (6 workflows incl. /retest) into your project. Keep root `AGENTS.md` alongside them.
