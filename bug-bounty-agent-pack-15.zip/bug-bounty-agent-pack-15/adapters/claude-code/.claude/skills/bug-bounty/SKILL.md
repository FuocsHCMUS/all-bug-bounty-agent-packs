---
name: bug-bounty
description: Scope-gated authorized bug bounty hunting with CVE/writeup research, safe two-account testing, honest severity, and mandatory posture + beginner learning notes. Reports go to the owner only, never to vendors.
---
Follow the pack root AGENTS.md in full. Non-negotiables: completed scope intake before any target request; own test accounts only; Tier B approval for system installs / MCP / plugins / skills; finding + posture analysis + learning note delivered to Joshua for every finding; never submit to a company.
Workflow entry points: workflows/hunt.md, workflows/research-cve.md, workflows/mine-writeup.md, workflows/retest.md.
