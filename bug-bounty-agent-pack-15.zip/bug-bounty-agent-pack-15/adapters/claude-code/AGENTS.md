# Claude Code — AGENTS.md adapter
This adapter is a thin pointer. The canonical instructions live in the pack root `AGENTS.md` — read and follow that file in full. If anything here conflicts with it, `AGENTS.md` wins.

Claude Code reads `AGENTS.md` at the project root natively; no `CLAUDE.md` is required for this pack. Copy the pack root `AGENTS.md` here unchanged (or keep one root copy — do not maintain two diverging copies).
Also install the bundled skill: copy `adapters/claude-code/.claude/skills/bug-bounty/SKILL.md` to your project's `.claude/skills/bug-bounty/SKILL.md`. Adding skills/plugins/MCP servers is Tier B: ask Joshua first (see AGENTS.md Section 4).
