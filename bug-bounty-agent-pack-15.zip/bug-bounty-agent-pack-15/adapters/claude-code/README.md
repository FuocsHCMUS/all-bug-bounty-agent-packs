# Claude Code adapter
Copy `AGENTS.md` (root, canonical) + `.claude/skills/bug-bounty/SKILL.md` into your project. No CLAUDE.md shim is shipped in pack 19.
