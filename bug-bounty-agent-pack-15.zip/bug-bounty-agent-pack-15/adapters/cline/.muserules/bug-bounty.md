# Cline rules — Bug Bounty Pack 19
This adapter is a thin pointer. The canonical instructions live in the pack root `AGENTS.md` — read and follow that file in full. If anything here conflicts with it, `AGENTS.md` wins.

Full instructions: pack root `AGENTS.md`. Cline-specific conduct: ask before any terminal command that installs software system-wide, adds MCP servers, or leaves the workspace folder (Tier B). Portable clones and venv pip installs inside the workspace are pre-approved (Tier A). Never submit reports to vendors; deliver to Joshua.
