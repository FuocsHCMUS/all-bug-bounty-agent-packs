# Cline adapter
Copy `.muserules/bug-bounty.md` into your project root (Cline reads `.muserules/`). Keep root `AGENTS.md` alongside it.
