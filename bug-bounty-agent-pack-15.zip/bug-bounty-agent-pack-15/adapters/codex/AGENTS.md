# Codex — AGENTS.md adapter
This adapter is a thin pointer. The canonical instructions live in the pack root `AGENTS.md` — read and follow that file in full. If anything here conflicts with it, `AGENTS.md` wins.

Codex reads `AGENTS.md` at the repo root. Use the pack root `AGENTS.md` unchanged. Keep sandbox/approval settings conservative: workspace-write only, network only for in-scope targets and research sources.
