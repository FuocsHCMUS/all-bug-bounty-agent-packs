# Codex adapter
Root `AGENTS.md` is the instruction file. `config.toml.example` is illustrative, not auto-applied.
