# Cursor adapter
Copy `.cursor/rules/*.mdc` (4 split rules: core/safety, research, testing/evidence, posture/tutor) into your project. Keep root `AGENTS.md` alongside them.
