# OpenCode — AGENTS.md adapter
This adapter is a thin pointer. The canonical instructions live in the pack root `AGENTS.md` — read and follow that file in full. If anything here conflicts with it, `AGENTS.md` wins.

OpenCode reads `AGENTS.md`. Additionally, this pack ships a dedicated agent definition at `.opencode/agent/bug-bounty.md` — copy the `.opencode/` folder too.
