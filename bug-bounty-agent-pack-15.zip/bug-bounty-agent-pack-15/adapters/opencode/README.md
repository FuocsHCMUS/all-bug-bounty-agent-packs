# OpenCode adapter
Copy `AGENTS.md` + `.opencode/agent/bug-bounty.md`. `opencode.json.example` is illustrative.
