# Evidence checklist

- [ ] Raw request saved verbatim (`req.txt`)
- [ ] Raw response saved verbatim (`res.txt`), body not truncated
- [ ] UTC timestamp on both
- [ ] SHA-256 of both in `evidence/manifest.sha256`
- [ ] Second, independent confirmation captured
- [ ] Screenshots cropped, URL visible, timestamp visible
- [ ] Secrets copied to `evidence/private/` and redacted in the report
- [ ] OOB callback logs saved if used
- [ ] `evidence_hasher.py verify` passes before submission

