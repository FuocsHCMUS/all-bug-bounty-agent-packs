# Per-endpoint checklist

- [ ] Host in scope, verified by the tool not by memory
- [ ] Auth state recorded (anon / A / B / elevated)
- [ ] Method, params and body shape noted
- [ ] Role matrix row exists for this endpoint
- [ ] Trust boundary identified
- [ ] Two hypotheses written, with kill criteria
- [ ] Response compared against a baseline
- [ ] Timing and size recorded for later diffing
- [ ] Any 5xx noted
- [ ] Result written to the ledger before moving on

