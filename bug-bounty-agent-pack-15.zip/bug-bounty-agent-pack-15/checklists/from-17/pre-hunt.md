# Pre-hunt checklist

- [ ] Enrolled in the program, account verified
- [ ] Scope read twice; `scope.json` written and confirmed
- [ ] Deny list understood (including third-party SaaS and CDNs)
- [ ] Rate ceiling and required header recorded in `state.json`
- [ ] Disclosure and duplicate policy read
- [ ] Test accounts created (max two)
- [ ] Separate browser profile, extensions off
- [ ] Disclosed-report corpus skimmed for the target
- [ ] Workspace dirs created
- [ ] `.venv` present if scripts will be used

