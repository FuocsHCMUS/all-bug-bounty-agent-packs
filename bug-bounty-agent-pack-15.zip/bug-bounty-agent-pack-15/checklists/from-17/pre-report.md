# Pre-report checklist

- [ ] Reproduces from a clean session, third party could follow it
- [ ] Scope proof included (the host is in the allow list)
- [ ] Minimal PoC, least privilege
- [ ] Impact stated in one sentence, then in business terms
- [ ] CVSS vector matches the narrative
- [ ] Root cause names the missing check
- [ ] Short- and long-term remediation
- [ ] Evidence hashed, secrets redacted
- [ ] Duplicate search done, delta stated
- [ ] Reviewer subagent passed all dimensions
- [ ] Posture note written
- [ ] Operator approved

