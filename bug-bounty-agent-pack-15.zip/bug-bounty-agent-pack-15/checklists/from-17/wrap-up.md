# Wrap-up checklist

- [ ] Session log complete
- [ ] `state.json` phase and next actions set
- [ ] Ledger consistent, no orphan ids
- [ ] Confirmed findings have reports and posture notes
- [ ] Killed hypotheses have reasons
- [ ] Install log updated
- [ ] Pending confirmations queued in `notes/pending.md`
- [ ] Cost tally (requests, accounts, money)
- [ ] Techniques promoted to `workspace/_kb` if reusable

