# Checklist — Hypothesis Ledger Gate (v23)

Before any non-trivial testing session:
- [ ] Ledger file created from `templates/named/hypothesis-ledger.md`
- [ ] Every planned test traces to a ledger entry (claim + primitive)
- [ ] Every entry has a kill criterion written *before* testing
- [ ] Every entry has a differential plan (two states to compare)
- [ ] Chain potential noted, even for low-severity primitives
- [ ] Scope confirmed for every asset the entries touch (AGENTS.md §2)

After the session:
- [ ] Each entry marked confirmed / killed / parked, with evidence links
- [ ] Killed entries record *why* (the observation that killed them)
- [ ] Survivors handed to the chain canvas / validation playbook
- [ ] New assumptions discovered are added as fresh entries
