# Core 11 — Creative Offensive Thinking Engine

The playbooks teach what is known. This engine produces what is not in any
playbook yet — the sophisticated techniques a target's own team has probably
not modelled. It is a disciplined creativity protocol, not random fuzzing.

## The 7 generators

### 1. Assumption inversion
Every control rests on assumptions. Enumerate them ruthlessly:
- "IDs are unguessable" / "this token is checked on every route"
- "the frontend validates it" / "only admins reach this code path"
- "this webhook really comes from the payment provider"
- "step 3 always runs after step 2" / "this value can't be negative / zero / huge"
For each assumption: *what if the opposite were true, and what is the cheapest
test that would show it?* Write each inversion as a ledger hypothesis.

### 2. Parser differentials
Bugs breed where two parsers disagree: CDN vs origin, WAF vs framework,
framework router vs URL library, JSON parser A vs B (duplicate keys, huge
numbers, Unicode), multipart parsers, XML parsers, JWT libraries, price/tax
rounding in two services. Feed both parsers the same malformed input and diff
the interpretations. `tools/diff_response.py` exists for the response side.

### 3. State-machine abuse
Model the flow (checkout, onboarding, password reset, KYC, invite, refund)
as states + transitions. Then: skip a state, repeat a transition, run two
transitions in parallel (see races), resume an expired state, enter from a
deep link mid-flow, mix states between two accounts. The transition nobody
drew on the whiteboard is where the money is.

### 4. Second-order everything
Ask of every stored value: *where else is this rendered, parsed, executed,
or trusted?* Profile fields → admin panel, support tool, PDF invoice, email
template, mobile app, data export, LLM prompt. Test at the sink, not the source.

### 5. Differential accounts
Two browsers, two accounts, two roles, two tenants, requests in lockstep,
diff everything (status, body, timing, headers). Authorisation and tenancy
bugs are invisible from a single account and obvious in a diff.

### 6. Primitives over bug names
Stop asking "is there an XSS here?" Start asking "what capability would be
valuable here — cross-tenant read, unsigned state acceptance, a confused
deputy that calls internal APIs with my input, a cache key I control?" Hunt
the capability; name the class afterwards, in the report.

### 7. Invent-then-kill
Timed session (see `workflows/11-invent-then-kill.md`): invent the wildest
plausible attack for the surface, write it up as a ledger entry with a kill
criterion, then spend a small fixed budget trying to *disprove* it. Survivors
graduate to full testing. Most will die cheaply — that is the point: the
engine converts imagination into a ranked, falsifiable queue.

## Session protocol (90 minutes)
1. (15') Surface recap: read the dossier + threat model, list trust boundaries.
2. (30') Run generators 1–4, fill the ledger (aim: 10+ hypotheses).
3. (15') Rank by (impact × plausibility) ÷ test cost. Kill-criterion each.
4. (30') Cheap kills first. Record results in the ledger, confirmed or killed.
5. Survivors → chain canvas (`templates/10-chain-canvas.md`) → Playbook 20.

## Anti-patterns
- Fuzzing without a hypothesis (noise, rate-limit burn, nothing learned).
- Naming a bug before proving the primitive ("possible IDOR" with no second account).
- Falling in love: ignoring your own kill criterion when it fires.
- Testing only where the feature *enters*, never where the data *lands*.
