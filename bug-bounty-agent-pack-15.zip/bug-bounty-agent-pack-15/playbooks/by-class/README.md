# Playbooks (18)
- `recon-and-scope.md` — Recon & Scope Discipline
- `auth-and-session.md` — Authentication & Session
- `idor-bola-authorization.md` — IDOR / BOLA & Authorization
- `business-logic-and-race.md` — Business Logic & Race Conditions
- `xss.md` — Cross-Site Scripting (XSS)
- `sqli-and-injection.md` — SQL & General Injection
- `ssrf.md` — Server-Side Request Forgery (SSRF)
- `api-graphql-websocket.md` — API, GraphQL & WebSocket Security
- `file-upload-and-download.md` — File Upload & Download
- `oauth-sso-and-jwt.md` — OAuth, SSO & JWT
- `cache-and-host-header.md` — Cache, CDN & Host-Header Attacks
- `client-side-browser.md` — Client-Side & Browser Security
- `deserialization-proto-pollution-supply-chain.md` — Deserialization, Prototype Pollution & Supply Chain
- `cloud-and-saas.md` — Cloud & SaaS Misconfiguration
- `mobile-backend.md` — Mobile App Backends
- `ai-llm-apps.md` — AI / LLM Application Testing
- `cve-hunting.md` — CVE Hunting Playbook
- `validation-and-retest.md` — Validation, Chaining & Retest
Every playbook assumes the root AGENTS.md loop: intake -> threat model -> hypotheses -> research -> safe testing -> validation -> report pack to Joshua.
