# Playbook: AI / LLM Application Testing

Prompt injection, retrieval leakage, and excessive agency — tested like any other trust boundary.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Inventory the AI system: inputs (chat, uploaded docs, connected accounts), retrieval sources and their tenant separation, tools/actions the agent can take, outputs and where they render (XSS via markdown/HTML rendering is common).
- Indirect prompt injection: plant an instruction in *your own* document/content that your own assistant session later processes, showing it followed planted instructions over the user's. Scale claims stop there — no planting content for other users.
- Cross-tenant retrieval: ask questions whose answers could only come from another tenant's documents — using canary documents you planted in Tenant B, queried from Tenant A (both Joshua's).
- Agency tests: with your own connected test accounts, check whether the assistant will perform irreversible/privileged actions on a text instruction from untrusted content; confirmation UX is a control — note if it exists and works.

## Watch for (high-signal variants)
- System-prompt extraction rated honestly: interesting, usually low severity unless it yields secrets/keys or enables the above.
- Token/cost abuse: demonstrate mechanism at tiny scale only.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Prompt-injecting shared/public content, making the agent act on real accounts/data, or cost/DoS-scale generation.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
