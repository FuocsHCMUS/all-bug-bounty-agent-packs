# Playbook: API, GraphQL & WebSocket Security

The modern surface: same HTTP, more structure, more authorization seams.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- REST: per-endpoint authorization matrix (role x verb x object ownership), mass assignment (extra fields in create/update bodies), pagination/filter leaks, versioned-endpoint drift (v1 forgotten, v2 fixed).
- GraphQL: introspection in prod (a finding only with demonstrated data access beyond authorization), field-level authorization gaps (the query is allowed, the *field* is not), batching/alias amplification, nested-query cost, mutations reached via GET/caches.
- WebSockets: authentication at handshake vs per-message, channel/topic subscription authorization, messages that assume the official client already validated them.
- Mobile APIs: same endpoints, often older versions, weaker pinning assumptions, extra debug fields. Compare web vs mobile responses field-by-field.

## Watch for (high-signal variants)
- GraphQL persisted queries / gateway allowlists that the REST twin does not share.
- API keys in JS/mobile bundles that carry more privilege than the UI suggests.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Load/cost attacks (deep GraphQL DoS, batch floods). Demonstrate the mechanism with a handful of requests, never at damaging scale.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
