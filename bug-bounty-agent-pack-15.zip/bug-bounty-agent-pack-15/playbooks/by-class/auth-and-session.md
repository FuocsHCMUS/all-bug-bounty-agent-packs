# Playbook: Authentication & Session

Login, MFA, password reset, and the tokens that stand in for a person.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Password reset flow: token entropy, expiry, single-use, host-header poisoning of reset links, token leakage via referer/logs, reset not invalidating sessions.
- Session lifecycle: fixation, rotation on login/privilege change, logout actually invalidating server-side, remember-me tokens, concurrent-session handling.
- MFA: bypass via response tampering, backup-code brute force (rate limits?), MFA state carried in a cookie the client controls, downgrade paths (email link that skips MFA).

## Watch for (high-signal variants)
- Reset tokens that stay valid after a second reset request, or after password change.
- OAuth-only accounts with a legacy password endpoint still alive.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Attempting credential attacks against real accounts. Own test accounts and program-provided credentials only; no password spraying, ever.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
