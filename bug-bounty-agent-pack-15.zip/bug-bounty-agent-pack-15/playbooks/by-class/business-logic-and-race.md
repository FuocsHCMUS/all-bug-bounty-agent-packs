# Playbook: Business Logic & Race Conditions

Bugs in what the app *means*, not how it parses — and in what happens twice at once.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Model the money/state machine: cart->pay->fulfil, trial->paid, request->approve->execute. At each arrow ask: can I skip, repeat, reverse, or do it in parallel?
- Races: coupon/discount applied concurrently, balance spend in parallel requests, one-time actions (claim, vote, redeem) fired simultaneously, limit checks that read-then-write without locking. Use your own accounts/objects and tiny concurrency.
- Negative/overflow/rounding: quantities, prices, refunds to a different instrument, currency confusion, coupon stacking across campaigns.

## Watch for (high-signal variants)
- TOCTOU on file-scan-then-serve and approve-then-download flows.
- Step-skipping: calling step 3's API directly with step 2's expected state forged client-side.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Any test that could create real financial effects beyond your own test accounts/balances, or load resembling DoS. Keep concurrency minimal (single-digit parallel requests).

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
