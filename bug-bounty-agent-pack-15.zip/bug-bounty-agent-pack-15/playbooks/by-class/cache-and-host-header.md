# Playbook: Cache, CDN & Host-Header Attacks

Shared caches remember responses — sometimes the wrong ones, for everyone.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Cache-key audit: which request parts key the cache (path? query? headers? cookies?) vs which parts change the response. A response that varies by an unkeyed input is a poisoning candidate.
- Web cache deception: path confusion that makes a private page look like a static asset to the cache (test only on your own account's pages, with your own canary data).
- Host-header trust: password-reset link poisoning, cache keyed by host, internal routing that trusts X-Forwarded-* headers from the internet.
- Prove poisoning only with a harmless marker on a URL you control the impact of, and purge/expire it afterwards. If a poisoned entry could serve real users, use a unique obscure path and Joshua's approval first.

## Watch for (high-signal variants)
- Fat GET / parameter cloaking differentials between CDN and origin.
- Age/Debug headers (X-Cache, CF-Cache-Status) as your oracle for hit/miss.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Poisoning shared entries on popular paths or anything that would serve altered content to real users.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
