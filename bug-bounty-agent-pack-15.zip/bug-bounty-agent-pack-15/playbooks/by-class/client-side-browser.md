# Playbook: Client-Side & Browser Security

Bugs that live in JS, the DOM, postMessage, and browser state.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- postMessage: listeners without origin checks, senders using '*' with sensitive payloads. Trace one message end-to-end before claiming impact.
- DOM clobbering and prototype pollution *client-side*: where untrusted keys merge into objects (query parsers, config merges, analytics) and later gate a security decision.
- Client-side-only 'security': paywalls, role checks, and validation that exist only in JS — the API accepting the raw action is the real finding; document both layers.
- Storage audit: tokens in localStorage (readable by any XSS), sensitive data cached by service workers, logout that clears the UI but not storage.

## Watch for (high-signal variants)
- Clickjacking where the missing frame protection meets a state-changing one-click action (prove on your own account/pages).
- Open redirects chained into OAuth/token theft — the redirect alone is low; the chain is the finding.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Building phishing-style PoCs hosted for real users. Self-contained local PoC pages against your own accounts only.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
