# Playbook: Cloud & SaaS Misconfiguration

Public buckets, exposed dashboards, and SaaS tenants configured into openness.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Public storage: buckets/blobs linked from in-scope apps, tested for anonymous read/write with a canary object you create and delete. Distinguish 'public by design' (CDN assets) from 'public by mistake' (backups, exports, user files).
- Exposed services in scope: dashboards, metrics, debug/management endpoints reachable without auth — prove with the landing/status response, do not browse other people's data inside.
- SaaS posture: the target's own public sharing settings (documents, boards, forms) where the program includes them; default-public new resources are the finding pattern.
- Metadata/SSRF overlap is covered in the SSRF playbook — in cloud targets it is the first chain to rule in or out, with the same stop rules.

## Watch for (high-signal variants)
- Signed URLs with prefix-wide scope or decade-long expiry, found in the app's own flows.
- Tenant discovery via predictable tenant slugs combined with weak tenant-level auth.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Downloading bucket contents, opening real documents, or enumerating tenants' data. Existence + your canary = proof.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
