# Playbook: Deserialization, Prototype Pollution & Supply Chain

When data rebuilds objects — whoever controls the data controls the object graph.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Server deserialization: identify formats (Java/PHP/.NET/Python pickle-style, custom JSON-to-object mappers) and the trust boundary the bytes cross. Prove with a benign gadget-free marker (a property that visibly changes behaviour on your own object) before any deeper claim.
- Prototype pollution: merge/assign endpoints and query parsers; pollute a property that changes a security decision on *your own* test object/session, and verify the pollution is server-side and persistent vs reflected noise.
- Supply chain (defensive testing only): dependency confusion concepts in the target's *public* build artefacts, exposed lockfiles/source maps revealing exact versions for the CVE loop, typosquat-adjacent findings reported as intel notes to Joshua.
- Source maps and JS bundles: mine them for routes, keys, and comments — then verify every suspected secret is actually valid *and* in-scope before calling it a finding (most are publishable keys by design).

## Watch for (high-signal variants)
- JSON duplicate-key and type-juggling differentials between the JSON parser and the business logic.
- Pollution via GraphQL variable coercion or multipart field names.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Executing gadget chains / RCE payloads beyond a benign, reversible marker on your own objects; publishing or using leaked real secrets.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
