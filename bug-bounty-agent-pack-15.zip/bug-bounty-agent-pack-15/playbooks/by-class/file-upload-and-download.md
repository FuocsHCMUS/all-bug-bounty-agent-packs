# Playbook: File Upload & Download

Files are code, content, and paths — all three views must be tested.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Upload checks: extension/MIME/content mismatch, double extensions, stored location predictability, serving with attacker-controlled content-type (stored XSS via file), zip/tar path traversal on extraction, image-parser CVEs (feed fingerprints into the CVE loop).
- Download checks: path traversal in file parameters, signed-URL scope (one object vs prefix), expiry, download endpoints that skip object authorization because 'the link is the security'.
- Prove with inert canary files (unique marker text) uploaded as A, accessed as B/anonymous. No executable content on shared/production paths beyond what the feature itself allows for your account.

## Watch for (high-signal variants)
- Race between upload-scan and first-serve.
- Transcoding/preview pipelines that render file content in privileged contexts (thumbnails in admin queues).

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Uploading anything malicious, webshells on real systems, or files that other real users would execute/download.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
