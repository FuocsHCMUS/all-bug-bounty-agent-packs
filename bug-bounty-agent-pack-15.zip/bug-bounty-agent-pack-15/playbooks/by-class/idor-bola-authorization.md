# Playbook: IDOR / BOLA & Authorization

The highest-value classic: the app authenticates you, then forgets to authorize the object.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Build an object map as Account A: every ID type (numeric, UUID, slug, composite tenant+object). Then, as A, request B's objects — IDs learned only from B's own session (never guessed real users).
- Vary the delivery channel: path, query, body, header, GraphQL argument, websocket message, export/download job, signed URL generation.
- Check all verbs: read is the start — test update, delete, share, and export on B's object with A's token (on disposable objects B created for this).
- UUIDs are not authorization: unguessable IDs still leak via lists, emails, logs, referers, and sibling endpoints.

## Watch for (high-signal variants)
- Nested resources where the parent is checked but the child is not (/teams/{mine}/invoices/{theirs}).
- Batch endpoints that authorize the first item only.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Enumerating or accessing real users' objects. Two-account method only; stop at the first proof with B's canary object.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
