# Playbook: Mobile App Backends

The API behind the app: older, chattier, and often less checked than the web API.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Compare surfaces: capture (in a lab, on Joshua's device/accounts, with Tier B approval for tooling installs) or statically review the app you are given for endpoints, versions, keys, and feature flags absent from web.
- Backend drift: deprecated endpoints still live, debug/staging base URLs shipped in production builds, certificate pinning present but the API itself unauthenticated for sensitive calls.
- Device-trust assumptions: actions the server allows because 'only the app can call this' — the server must authorize anyway; test the call shape with your own token outside the app.
- Local storage findings (tokens in plaintext stores) are rated honestly: they need device access, so impact framing must say so.

## Watch for (high-signal variants)
- Deep links / universal links that carry tokens or route into authenticated actions without checks.
- Push-notification payloads leaking sensitive content to lock screens — usually informational; say so.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Testing on devices/accounts that are not Joshua's; intercepting other users' traffic.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
