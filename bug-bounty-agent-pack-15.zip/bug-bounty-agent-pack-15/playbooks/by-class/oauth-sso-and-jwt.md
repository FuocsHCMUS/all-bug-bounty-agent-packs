# Playbook: OAuth, SSO & JWT

Delegated login: many parties, many redirects, many places for trust to leak.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- OAuth flow audit: redirect_uri matching strictness, state (CSRF on the flow), PKCE presence, code reuse/expiry, token leakage via referer/fragments, account linking that trusts an email claim.
- SAML/OIDC: audience/issuer validation, signature stripping/confusion concepts, email-domain auto-join and auto-provisioning edge cases, IdP-initiated flows the SP did not expect.
- JWT handling: algorithm confusion concepts, kid/jku header trust, weak/known secrets on *test* tokens, tokens accepted across audiences/tenants, sensitive data trusted client-side (roles in an unsigned-readable payload the server fails to verify).
- Prove with your own IdP/test tenant and your own accounts wherever the program allows; a token you minted against a test tenant is the cleanest proof.

## Watch for (high-signal variants)
- Login CSRF and OAuth account pre-hijacking (registering the email first via a classic path).
- Cross-tenant token replay in multi-tenant SaaS SSO.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Touching a real organisation's SSO tenant or real employee accounts. Test tenants and Joshua's accounts only.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
