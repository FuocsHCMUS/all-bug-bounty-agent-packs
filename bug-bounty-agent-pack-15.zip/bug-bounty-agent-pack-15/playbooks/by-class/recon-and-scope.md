# Playbook: Recon & Scope Discipline

Knowing exactly what you may touch, and mapping it without touching what you may not.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Passive first: program scope page, certificate-transparency logs, public DNS, search-engine caches, the target's own docs/changelog/status pages, JS bundle names. No packets to questionable assets.
- Classify every discovered host: in-scope / out-of-scope / unknown(=treat as out). Record the evidence for each classification in the inventory.
- Fingerprint gently: one normal request per host, headers + tech (scripts/headers_check.py, tech_fingerprint.py). Version data feeds the CVE loop immediately.

## Watch for (high-signal variants)
- A subdomain that resolves to a third-party SaaS (support desk, status page) — usually out of scope even if the name matches; verify before any test.
- Staging/dev hosts in scope are gold (weaker controls) and dangerous (real data copies) — safe-proof rules apply double.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Accessing/logging a third-party or out-of-scope host beyond passive public data.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
