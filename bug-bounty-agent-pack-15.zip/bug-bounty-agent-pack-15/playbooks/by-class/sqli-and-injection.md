# Playbook: SQL & General Injection

Data reaching an interpreter (SQL, NoSQL, LDAP, template, OS command) as code.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Start with error/oracle discipline: single quote differentials, boolean pairs (true/false conditions that change the response), and time oracles only at minimal, polite delays.
- NoSQL and ORM layers did not kill injection — operator injection in JSON bodies (e.g. query operators smuggled as values) and ORDER BY / sort parameters are modern hotspots.
- Template injection (SSTI): arithmetic probes in every rendering context (emails, PDFs, names, import templates) — identify the engine from its error/arithmetic behaviour before any deeper test.
- Prove with read-only, minimal evidence: database name/version or a boolean oracle demonstration. Extracting real data is prohibited; your own planted rows are the proof target.

## Watch for (high-signal variants)
- Second-order injection: stored input later concatenated into a query by a reporting/export job.
- Blind injection where the only oracle is an email/webhook side effect to your own endpoint.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Data extraction beyond a minimal proof, write queries, stacked queries, or anything that modifies/deletes data.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
