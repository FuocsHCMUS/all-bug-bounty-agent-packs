# Playbook: Server-Side Request Forgery (SSRF)

Making the server fetch what you choose — turning its network position into yours.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Find fetchers: URL import, webhook testers, image/avatar fetch, PDF generators, link unfurlers, SSO/metadata discovery, file-from-URL features.
- Filter bypass thinking: the filter sees a string; the fetcher resolves a URL. Differentials — redirects, DNS rebinding concepts, alternate IP notations, URL parser quirks, allowlist suffix confusion — live between those two views. Test against *your own* controlled endpoint first to learn what the server actually requested (method, headers, source).
- Impact ladder (prove the lowest rung that matters): server can reach your endpoint -> server leaks internal-only response -> cloud metadata exposure. Stop as soon as a rung is proven; metadata credentials are a stop-and-report event, not a playground.

## Watch for (high-signal variants)
- Blind SSRF where only timing/DNS callbacks to your resolver reveal the request.
- SSRF in webhook *destinations* validated at creation but not at delivery time.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Fetching real internal services beyond the minimal differentiator request, using any obtained credentials, or scanning internal networks.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
