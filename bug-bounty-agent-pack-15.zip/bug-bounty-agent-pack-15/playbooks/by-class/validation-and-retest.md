# Playbook: Validation, Chaining & Retest

Turning a suspicion into a submission-grade finding — and later, verifying the fix.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Reproduce from zero: clean browser/session, written steps, no reliance on state you forgot you created. If it does not reproduce twice, it is not ready.
- Minimise then maximise: smallest PoC that proves the primitive; then, separately, the honest impact exploration (how far does the primitive reach — still only with your own accounts/objects).
- Chain review: for each proposed link, demand its own evidence. Remove unproven links or downgrade the report to the proven subset.
- Duplicate self-check (templates/duplicate-check.md) and severity calibration (docs/07) happen here, before Joshua ever sees a 'ready' label.
- Retest (after Joshua reports a fix): original steps verbatim, then two nearest variants; verdict + evidence per workflows/retest.md.

## Watch for (high-signal variants)
- A fix that blocks the exact payload but not the primitive (encoding/method/sibling) — a legitimate, valuable retest finding for Joshua.
- Regression windows: fixes deployed to web but not mobile API (or vice versa).

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Retesting before Joshua confirms the company says it is fixed, or expanding a retest into a new hunt without a fresh scope check.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
