# Playbook: Cross-Site Scripting (XSS)

Your markup/script executing in a victim's browser, under the site's origin.

## Before you start
- Scope intake complete and this surface explicitly in scope (root `AGENTS.md` Sections 1-2).
- Hypotheses written in the ledger, each with an oracle (the signal that proves/disproves it).
- Research Engine pass done for this class: at least one CVE/advisory check and one writeup/technique card reviewed (`docs/04-research-engine-cve-writeup-ctf.md`).

## Core checks
- Classify the sink: reflected, stored, DOM. The stored + admin-viewed combination is the classic bounty-grade path (support tickets, profile fields, filenames, imported data).
- Map the context precisely: HTML body, attribute, JS string, URL, JSON-in-HTML — the payload shape is dictated by the context and the escaping the app actually applies (verify, don't assume).
- Prove safely: execute a harmless marker (e.g. set document.title or a canary element) in *your own* browser/session context, or a victim account you control. No cookie theft from real users — demonstrate capability, not loot.

## Watch for (high-signal variants)
- mXSS via HTML sanitizers and rich-text editors; SVG/MathML namespaces are frequent differential sources.
- Second-order XSS in emails/PDFs/admin exports — test where your stored input is *later* rendered.

## Safe proof standard for this class
Prove the primitive on Joshua's own accounts/objects with the smallest reversible test. Label the result proven / indicated / speculative. Evidence per `docs/07-severity-cvss-and-evidence-hygiene.md`.

## STOP — do not do this
Delivering payloads to real users or storing payloads in places real staff/users will trigger outside a controlled proof. Coordinate timing with Joshua for staff-facing stored proofs.

## After testing (mandatory)
- Update the hypothesis ledger with outcomes, including negatives.
- If a finding emerged: finding report + posture analysis (SOC detection for this class) + beginner learning note, all to Joshua only.
- Add any new reusable technique to a technique card.
