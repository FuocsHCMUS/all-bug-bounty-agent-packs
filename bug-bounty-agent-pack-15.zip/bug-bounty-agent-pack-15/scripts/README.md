# Scripts — Safe Starter Tools (Windows 11, Python 3.14.x+)

All scripts are **standard-library only** (no pip installs needed to start),
scope-aware, and polite by design. They are aids, not scanners.
All 10 were compile-checked and smoke-tested on CPython (stdlib-only, so
they run unchanged on the operator's Python 3.14 / Windows 11).

| Script | What it does | Touches a target? |
|---|---|---|
| `scope_guard.py` | Offline check: is this host in my scope allowlist? | No — pure local logic |
| `cve_lookup.py` | NVD API lookup by CVE ID / keyword → match-sheet summary | No — only nvd.nist.gov |
| `http_probe.py` | Status + headers + redirects for a few URLs; **dry-run by default**, `--run` requires `--scope` | Only with `--run` + scope file |
| `make_hunt.py` | Scaffolds `workspace/<program-slug>/` from the templates | No — local files only |
| `headers_check.py` *(NEW v18)* | One GET → security-header + cookie-flag report with plain-English explanations | Yes — 1 request; Tier B vs a target |
| `tech_fingerprint.py` *(NEW v18)* | One GET (or `--file` offline) → tech/version signals for the CVE pipeline | Yes — 1 request; Tier B vs a target. `--file` mode is offline |
| `inventory.py` *(NEW v18)* | Asset list file → de-duplicated Markdown inventory table, flags out-of-scope-pattern rows | No — pure local logic |
| `har_analyzer.py` *(NEW v20)* | Offline HAR analysis: unique hosts/paths/statuses, flags auth-header names (values never printed), 4xx/5xx, JSON APIs, ID-like params | No — offline only, never makes network calls |
| `js_extract.py` *(NEW v20)* | Extract URLs/paths/API endpoints/source-maps from local JS file(s)/directory; `--url` is dry-run by default, `--live` (1 GET) required for a real fetch | No for local files / dry-run; only with `--url --live` |
| `evidence_hash.py` *(NEW v20)* | SHA-256 manifest (CSV/Markdown: filename, size, hash, UTC timestamp) for an evidence folder; `--verify` re-checks a manifest | No — pure local logic |

## New in v20 — quick start

```powershell
# 1) Summarise a HAR you exported from YOUR OWN browser (values redacted)
py -3.14 har_analyzer.py capture.har
py -3.14 har_analyzer.py capture.har --out har-summary.txt

# 2) Mine a local JS bundle for endpoint leads (offline)
py -3.14 js_extract.py app.js
py -3.14 js_extract.py .\static\js\ --out endpoints.txt
py -3.14 js_extract.py --url https://example.com/app.js          # dry-run, sends nothing
py -3.14 js_extract.py --url https://example.com/app.js --live   # ONE GET — Tier B, scope first

# 3) Freeze evidence integrity, then prove it later
py -3.14 evidence_hash.py evidence\
py -3.14 evidence_hash.py evidence\ --manifest evidence\manifest.md --format md
py -3.14 evidence_hash.py evidence\ --verify evidence\evidence-manifest.csv
```

## Setup
```powershell
cd bug-bounty-agent-pack-20\scripts
py -3.14 -m venv .venv
.venv\Scripts\Activate.ps1
# nothing to install for the starters; if a future script needs a library:
# pip install <lib>  then  pip freeze > requirements.txt
```
Git Bash equivalents: `source .venv/Scripts/activate`.

## Rules baked in (mirrors AGENTS.md §4)
- Running any script that sends traffic to a target is a **Tier B** action:
  operator approves the exact hosts/rate first. Offline modes are Tier A.
- Any new script the agent writes follows the same pattern: dry-run default,
  scope check before traffic, ≤1 rps default, GET/HEAD unless justified,
  no destructive verbs, results logged to the experiment log.
- `requirements.txt` exists for future dependencies; pin exact versions.
- `har_analyzer.py` redacts by design: it prints header **names** only and
  parameter names/value-shapes only — never header, cookie, or param values.
  A raw HAR usually contains session tokens; never share one unredacted.
