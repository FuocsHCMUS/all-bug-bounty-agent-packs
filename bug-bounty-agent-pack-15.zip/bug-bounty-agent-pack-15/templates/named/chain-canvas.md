# Template: Chain Canvas

## Chain name / goal:

## Link 1 — primitive, evidence, what it yields:

## Link 2 — primitive, evidence, what it yields:

## Link 3 — primitive, evidence, what it yields:

## Unproven links (must be empty before submission, or the chain is reported as its proven subset):

## Combined impact vs single-link impact (honest delta):
