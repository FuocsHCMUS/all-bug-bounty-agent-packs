# Template: Finding Report — for Joshua (he submits)

## Title:

## Program / asset / class / severity + CVSS vector (assumptions stated):

Status: proven / indicated (delete one; speculative findings do not use this template)

## Summary (plain English, 3-5 sentences):

## Preconditions & accounts used (Joshua's test accounts only):

## Steps to reproduce (numbered, clean-session, minimal):

## Evidence (redacted request/response pairs, timestamps UTC):

## Impact (attacker gain, scale, effort):

## Root cause (the exact failed assumption / missing check):

## Remediation (specific fix + one defence-in-depth item):

## Duplicate self-check summary & link:
