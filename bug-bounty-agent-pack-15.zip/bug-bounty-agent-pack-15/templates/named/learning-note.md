# Template: Learning Note (Beginner-First)

## The finding in one sentence:

## ROOT CONCEPTS (dependency order — packets/DNS/TCP/TLS/HTTP/session/object, only those this bug needs; 1-3 plain sentences each):

## THE MECHANISM (how the app was supposed to work):

## THE BUG (exactly which assumption/check failed, mapped onto the mechanism):

## ONE ANALOGY (then map it back to the real mechanism, part by part):

## CONCEPT LADDER: prerequisites -> this concept -> what it unlocks next:

## SOC MIRROR (how a defender sees/detects this):

## SELF-CHECK (3-5 questions; answers below the spoiler line):

--- answers below ---

## SPACED REPETITION: cards made? review dates (+1d/+1w/+1m):
