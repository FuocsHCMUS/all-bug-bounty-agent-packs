# Template: Posture Analysis (SOC Lens)

## Product/company context in 2-3 sentences:

## Doing well (each item tied to an observation during testing):

## Needs improvement (the enabling gap + neighbouring gaps of the same family):

## Systemic or isolated? Evidence (sibling endpoints tested):

## Risk register: likelihood / impact / affected population / data & actions at risk:

## Detection: log sources; the anomalous sequence; a SIEM detection idea in plain words; expected false positives & tuning:

## Response recommendations: fix, retrospective hunt, rotations/audits to run:

## Confidence & limits of this analysis (what was not tested):
