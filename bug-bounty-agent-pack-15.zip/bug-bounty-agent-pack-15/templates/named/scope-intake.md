# Template: Scope Intake

## Program name / platform / policy URL / date archived:

## In-scope assets (exact):

## Out-of-scope assets (exact):

## Prohibited techniques / automation & rate rules:

## Safe harbor & disclosure terms:

## Reward / severity notes and known-issues link:

Test accounts (labels only, no passwords): A= , B= , other=

## Ambiguities and how each was resolved:

## Threat-model link:
