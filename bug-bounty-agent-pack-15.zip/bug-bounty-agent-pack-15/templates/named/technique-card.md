# Template: Technique Card (from writeups/CTF/disclosures)

## Technique name & primitive (one line):

## Source: title + URL + date:

## Preconditions (each mapped to how you'd observe it on a target):

## Oracle (the signal that proves it worked):

## Payload/request shape (understood, not copy-pasted blindly):

## Detection footprint (what this looks like in logs):

## Failure modes (when this technique cannot work):

## Variants & graph links (needs: / yields:):
