# Template: Threat Model (Phase 0.5)

## Product in one paragraph (what it does, who pays, why it matters):

## Actors and what each should be allowed to do:

## Trust boundaries (draw/list them):

## Crown-jewel data and actions:

## Abuse stories (one sentence each — these become hypotheses):

## Surface scores (Impact x Plausibility x Novelty) and top-5 test order:

## Assumption inventory (5 things the app assumes; one test per assumption):
