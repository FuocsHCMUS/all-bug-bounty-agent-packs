# Template: Writeup Mining Notes

## Source: title + URL + author + date:

## The bug in my own words (no copying):

## The one transferable idea:

## What the author tried that failed (often the most valuable part):

## Preconditions checklist for reuse:

Where in my current/recent hunts could this apply? (specific surfaces)

## Technique card created? link:
