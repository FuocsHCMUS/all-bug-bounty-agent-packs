# Tools

## v23 note — pack-17 tools live here
This folder also carries pack-17's tools: `jwt_inspect.py`, `cvss.py`,
`diff_response.py`, `param_miner.py`, `js_endpoint_extract.py`,
`evidence_hasher.py`, `report_builder.py`, `bootstrap.py` (offline /
local helpers), plus the active-testing pair `race_runner.py` and
`oob_listener.py`. Active tools follow AGENTS.md §4/§17: operator
approval first, in-scope targets only, your own accounts only, smallest
useful request volume. Verify the whole pack with `verify_pack23.py`.
