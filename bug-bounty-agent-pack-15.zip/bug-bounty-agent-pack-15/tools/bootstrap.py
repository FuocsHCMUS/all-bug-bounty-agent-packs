#!/usr/bin/env python3
"""Create .venv with py -3.14 and optionally install optional deps (venv only)."""
from __future__ import annotations
import argparse, subprocess, sys
from pathlib import Path

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--install", action="store_true", help="pip install -r requirements-optional.txt inside the venv")
    a = ap.parse_args()
    root = Path(__file__).resolve().parent.parent
    venv = root / ".venv"
    py = venv / "Scripts" / "python.exe"
    if not py.exists():
        print("creating venv ->", venv)
        r = subprocess.run(["py", "-3.14", "-m", "venv", str(venv)])
        if r.returncode:
            print("venv creation failed; check py -3.14")
            return 1
    subprocess.run([str(py), "-m", "pip", "install", "--upgrade", "pip"], check=False)
    if a.install:
        req = root / "tools" / "requirements-optional.txt"
        print("installing optional deps (venv only)")
        r = subprocess.run([str(py), "-m", "pip", "install", "-r", str(req)])
        if r.returncode:
            print("some deps failed on 3.14; core scripts are stdlib-only")
    print("interpreter:", py)
    print("done. log it in ops/install-log.md")
    return 0

if __name__ == "__main__":
    sys.exit(main())

