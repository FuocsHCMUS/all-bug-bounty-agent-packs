#!/usr/bin/env python3
"""HTTP + DNS callback listener for blind SSRF/XXE. Local only."""
from __future__ import annotations
import argparse, json, socketserver, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

LOG: list[dict] = []

def record(kind: str, addr: tuple, detail: str) -> None:
    row = {"t": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "kind": kind, "src": addr[0], "detail": detail}
    LOG.append(row); print(json.dumps(row), flush=True)

class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def _h(self, method: str):
        record("http", self.client_address, f"{method} {self.path} UA={self.headers.get('User-Agent','')}")
        body = b"ok"
        self.send_response(200); self.send_header("Content-Length", str(len(body)))
        self.send_header("Content-Type", "text/plain"); self.end_headers(); self.wfile.write(body)
    def do_GET(self): self._h("GET")
    def do_POST(self): self._h("POST")
    def log_message(self, *a): pass

class DNS(socketserver.BaseRequestHandler):
    def handle(self):
        data, sock = self.request
        try:
            q = data[12:]
            labels, i = [], 0
            while i < len(q) and q[i]:
                n = q[i]; labels.append(q[i+1:i+1+n].decode("utf-8", "replace")); i += n + 1
            record("dns", self.client_address, ".".join(labels))
            tid = data[:2]
            resp = tid + b"\x81\x80" + b"\x00\x01\x00\x01\x00\x00\x00\x00" + q[:i+1] + b"\x00\x00\x01\x00\x01"
            resp += b"\xc0\x0c" + b"\x00\x01\x00\x01" + b"\x00\x00\x00\x3c" + b"\x00\x04" + b"\x7f\x00\x00\x01"
            sock.sendto(resp, self.client_address)
        except Exception:
            pass

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--http-port", type=int, default=8080)
    ap.add_argument("--dns-port", type=int, default=5353)
    ap.add_argument("--out")
    a = ap.parse_args()
    print(f"HTTP payload: http://<your-ip>:{a.http_port}/x")
    print(f"DNS  payload: x.<your-ip>.nip.io  (or run on udp/53)")
    threading.Thread(target=lambda: ThreadingHTTPServer(("0.0.0.0", a.http_port), H).serve_forever(), daemon=True).start()
    socketserver.ThreadingUDPServer.allow_reuse_address = True
    srv = socketserver.ThreadingUDPServer(("0.0.0.0", a.dns_port), DNS)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt:
        if a.out:
            open(a.out, "w", encoding="utf-8").write(json.dumps(LOG, indent=2))
            print("wrote", a.out)
    return 0

if __name__ == "__main__":
    sys.exit(main())

