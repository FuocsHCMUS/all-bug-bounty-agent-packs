#!/usr/bin/env python3
"""Barrier-synchronised request burst for race conditions. asyncio, stdlib."""
from __future__ import annotations
import argparse, asyncio, json, ssl, sys, time
from pathlib import Path

async def one(host: str, port: int, raw: bytes, barrier: asyncio.Barrier, tls: bool, idx: int) -> dict:
    ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
    reader, writer = await asyncio.open_connection(host, port, ssl=ctx if tls else None, server_hostname=host if tls else None)
    await barrier.wait()
    t0 = time.monotonic()
    writer.write(raw); await writer.drain()
    try:
        data = await asyncio.wait_for(reader.read(65536), timeout=15)
    except asyncio.TimeoutError:
        data = b"<timeout>"
    writer.close()
    return {"i": idx, "ms": round((time.monotonic() - t0) * 1000), "len": len(data),
            "head": data.split(b"\r\n\r\n")[0][:300].decode("utf-8", "replace"),
            "body": data.split(b"\r\n\r\n", 1)[-1][:200].decode("utf-8", "replace")}

def build(method: str, path: str, host: str, headers: list[str], body: str) -> bytes:
    lines = [f"{method} {path} HTTP/1.1", f"Host: {host}"]
    lines += headers
    if body:
        lines.append(f"Content-Length: {len(body.encode())}")
        lines.append("Connection: close")
        return ("\r\n".join(lines) + "\r\n\r\n" + body).encode()
    lines.append("Connection: close")
    return ("\r\n".join(lines) + "\r\n\r\n").encode()

async def run(a) -> list[dict]:
    host = a.host; tls = a.tls or a.url.startswith("https://")
    port = a.port or (443 if tls else 80)
    path = a.path or "/"
    raw = build(a.method, path, host, a.header or [], a.body or "")
    barrier = asyncio.Barrier(a.n)
    return await asyncio.gather(*[one(host, port, raw, barrier, tls, i) for i in range(a.n)])

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", required=True)
    ap.add_argument("--url", default="")
    ap.add_argument("--path", default="/")
    ap.add_argument("--port", type=int)
    ap.add_argument("--method", default="POST")
    ap.add_argument("--header", action="append")
    ap.add_argument("--body", default="")
    ap.add_argument("--n", type=int, default=20)
    ap.add_argument("--out")
    a = ap.parse_args()
    rows = asyncio.run(run(a))
    codes: dict[str, int] = {}
    for r in rows:
        first = r["head"].split("\r\n")[0] if r["head"] else "?"
        codes[first] = codes.get(first, 0) + 1
    print("status distribution:")
    for k, v in sorted(codes.items(), key=lambda x: -x[1]): print(f"  {v:>3}  {k}")
    lens = {r["len"] for r in rows}
    if len(lens) > 1: print("distinct lengths:", sorted(lens), "-> inspect for partial success")
    if a.out:
        Path(a.out).write_text(json.dumps(rows, indent=2), encoding="utf-8"); print("wrote", a.out)
    return 0

if __name__ == "__main__":
    sys.exit(main())

