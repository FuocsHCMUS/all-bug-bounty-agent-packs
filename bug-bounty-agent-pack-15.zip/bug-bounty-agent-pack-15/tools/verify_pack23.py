#!/usr/bin/env python3
"""Verify bug-bounty-agent-pack-23 layout: required files exist, JSON parses,
and every Python helper compiles. Stdlib only."""
from __future__ import annotations
import json, pathlib, py_compile, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
REQUIRED = [
    "AGENTS.md", "SKILL.md", "README.md", "START-HERE.md", "MERGE-NOTES.md",
    "EXPANSIONS.md", "VERSION",
    "core/11-creative-offensive-thinking-engine.md", "core/12-roe-as-enabler.md",
    "workflows/11-invent-then-kill.md", "checklists/hypothesis-ledger-gate.md",
    "templates/named/hypothesis-ledger.md", "schemas/scope.schema.json",
    "schemas/hypothesis.schema.json", "schemas/finding.schema.json",
    "agents/vuln-hunter.md", "prompts/sequential/00-kickoff.md",
    "prompts/roles/senior-pentester.md", "docs/00-foundations-networking-from-zero.md",
    "playbooks/20-bug-chaining-at-scale.md", "playbooks/by-class/ssrf.md",
    "playbooks/per-vuln/ssrf.md", "learning/deep-dives/http2-and-parsers.md",
    "research/cve-hunt-loop.md", "posture/analysis-framework.md",
    "reporting/severity-guide.md", "ops/toolchain-tiers.md",
]

def main() -> int:
    bad = 0
    for rel in REQUIRED:
        if not (ROOT / rel).exists():
            print("MISSING:", rel); bad += 1
    for p in sorted(ROOT.rglob("*.json")):
        try: json.loads(p.read_text(encoding="utf-8"))
        except Exception as e: print("BAD JSON:", p.relative_to(ROOT), e); bad += 1
    pys = [p for p in ROOT.rglob("*.py")]
    for p in pys:
        try: py_compile.compile(str(p), doraise=True)
        except Exception as e: print("BAD PY:", p.relative_to(ROOT), e); bad += 1
    total = sum(1 for p in ROOT.rglob("*") if p.is_file())
    print(f"files={total} python_helpers={len(pys)} problems={bad}")
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main())
