# Workflow 11 — Invent-Then-Kill Session

Purpose: generate novel attack hypotheses for a surface that standard
playbooks have exhausted, then falsify them cheaply before spending real
test budget. Method source: `core/11-creative-offensive-thinking-engine.md`.

## Steps
1. **Pick one surface** (one feature, one API family, one flow). Narrow wins.
2. **Recap (15 min):** dossier, threat model, trust boundaries, data flows.
3. **Invent (30 min):** run generators 1–4 (assumption inversion, parser
   differentials, state-machine abuse, second-order). Minimum 10 ledger
   entries, each with claim, primitive, kill criterion, differential plan.
   Wild is good — the kill step exists to filter.
4. **Rank (15 min):** score (impact × plausibility) ÷ cost. Top 5 advance.
5. **Kill (30 min):** cheapest falsifying test per hypothesis, in-scope,
   own accounts. Update the ledger: killed (why), parked (what's missing),
   or survived.
6. **Graduate survivors:** chain canvas → hypothesis-led testing →
   validation playbook → report + posture + learning notes (mandatory,
   AGENTS.md §8).
7. **Log the session** in the weekly hunt journal, including the killed
   ideas — a killed exotic idea, with its kill evidence, is reusable
   knowledge for every future target with the same stack.
