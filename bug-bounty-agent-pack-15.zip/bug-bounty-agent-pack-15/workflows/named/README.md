# Workflows (8)
- `hunt.md` — Hunt — Full Operating Loop
- `research-cve.md` — Research: CVE Loop
- `mine-writeup.md` — Mine a Writeup / Disclosed Report / CTF Solution
- `scope-intake.md` — Scope Intake Gate
- `report-pack.md` — Build the Report Pack for Joshua
- `posture.md` — Posture Analysis
- `learn-after-finding.md` — Learn After a Finding (Tutor Workflow)
- `retest.md` — Retest a Reported Fix
