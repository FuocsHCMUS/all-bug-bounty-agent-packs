# Workflow: Hunt — Full Operating Loop

1. Complete templates/scope-intake.md; archive the program policy.
2. Phase 0.5 threat model: actors, boundaries, crown jewels, abuse stories, scored surfaces.
3. Create the hunt folder: python scripts/make_hunt.py --program <name> --target <asset>.
4. Passive inventory -> scripts/inventory.py; fingerprint -> headers_check + tech_fingerprint.
5. Write hypotheses (abuse stories verbatim) in the ledger with oracles.
6. Research Engine pass per hypothesis (CVE loop + one writeup/CTF technique card minimum).
7. Safe testing in score order, two-account rule, one variable at a time, lab notebook on.
8. Validation: reproduce twice, duplicate check, honest CVSS, chain-link audit.
9. Deliver to Joshua: finding report(s) + posture analysis + learning note. State clearly if nothing was found and what was ruled out.
10. Clean up test objects; close the hunt log with next-surface suggestions.

Rules that always apply: root `AGENTS.md` (scope, safe proof, 3-tier approvals, report-to-Joshua-only).
