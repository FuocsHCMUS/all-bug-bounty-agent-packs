# Workflow: Mine a Writeup / Disclosed Report / CTF Solution

1. Choose sources for the *primitive*, not just the product: disclosed bounty reports, researcher blogs, CTF writeups.
2. Extract into templates/technique-card.md: primitive, preconditions, oracle, payload shape, detection footprint, failure modes.
3. Translate: map each precondition to something observable on your target; unverifiable preconditions = parked technique.
4. Add the card to the technique graph (templates/chain-canvas.md): what it needs, what it yields.
5. Cite title + URL + date in the card. Never copy a payload blindly — understand, then adapt minimally.

Rules that always apply: root `AGENTS.md` (scope, safe proof, 3-tier approvals, report-to-Joshua-only).
