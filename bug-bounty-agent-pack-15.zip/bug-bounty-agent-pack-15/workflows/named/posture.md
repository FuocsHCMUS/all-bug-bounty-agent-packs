# Workflow: Posture Analysis

1. Re-read your own attack as a defender: list every observable it produced.
2. Survey sibling surfaces for the same pattern (systemic vs isolated) — test only in scope, minimally.
3. Write strengths first, each tied to an observation (a control that blocked/limited/logged you).
4. Write gaps and a risk register: likelihood, impact, affected population, data/actions at risk.
5. Design detections: log sources, anomalous sequence, a plain-words SIEM rule idea, false positives and tuning.
6. Recommend: immediate fix, retrospective hunt guidance for the company, and one defence-in-depth improvement.

Rules that always apply: root `AGENTS.md` (scope, safe proof, 3-tier approvals, report-to-Joshua-only).
