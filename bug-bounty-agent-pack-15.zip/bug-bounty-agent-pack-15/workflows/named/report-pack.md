# Workflow: Build the Report Pack for Joshua

1. Assemble the finding report (templates/finding-report.md) with proven/indicated labels and redacted evidence.
2. Run templates/duplicate-check.md; attach its result.
3. Write the posture analysis (strengths, gap, systemic judgement, risk register, SOC detection + false positives).
4. Write the learning note from first principles with concept ladder and self-check questions.
5. Final read-through as a triager: can this be reproduced in 5 minutes? Is severity defensible? Is anything speculative labelled?
6. Deliver the pack to Joshua with a 3-line summary. Do NOT submit anywhere.

Rules that always apply: root `AGENTS.md` (scope, safe proof, 3-tier approvals, report-to-Joshua-only).
