# Workflow: Research: CVE Loop

1. List fingerprinted components with versions and confidence.
2. For each: NVD query (scripts/cve_lookup_nvd.py --vendor/--keyword), vendor advisory, GitHub advisory.
3. Record in templates/cve-match.md: affected range, target in/out of range, config preconditions, exploit maturity.
4. Design the safe differentiator (vulnerable vs patched response) before any target request.
5. Test differentiators minimally; verdict Affected / Not affected / Indeterminate with evidence.
6. Feed sibling-pattern ideas from the patch diff into the hypothesis ledger.

Rules that always apply: root `AGENTS.md` (scope, safe proof, 3-tier approvals, report-to-Joshua-only).
