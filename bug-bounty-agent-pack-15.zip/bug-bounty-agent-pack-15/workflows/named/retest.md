# Workflow: Retest a Reported Fix

1. Confirm with Joshua that the company reports a fix (or a new version shipped). Without that, do not retest.
2. Re-run the original reproduction steps verbatim against the fixed build; record each step's result.
3. Test the two nearest variants: sibling endpoint and alternate encoding/method/channel.
4. Verdict per item: Fixed / Partially fixed / Not fixed / Cannot verify — with fresh evidence.
5. If partially/not fixed: prepare a concise update pack for Joshua (original report reference + delta evidence). He decides and submits.
6. Update posture + learning notes: what the fix tells you about the company's engineering (credit good fixes explicitly).

Rules that always apply: root `AGENTS.md` (scope, safe proof, 3-tier approvals, report-to-Joshua-only).
