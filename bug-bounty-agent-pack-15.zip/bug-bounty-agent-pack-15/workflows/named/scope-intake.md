# Workflow: Scope Intake Gate

1. Open the program page; read the full policy, not the summary.
2. Fill templates/scope-intake.md completely: assets in/out, prohibited techniques, automation rules, safe harbor, reward/severity notes.
3. List ambiguities; resolve them by treating as out-of-scope or asking Joshua. Record decisions.
4. Confirm test accounts exist (A/B minimum). No accounts + auth-required surface = plan account creation with Joshua first.
5. Gate: Joshua can see the completed intake before any active testing begins.

Rules that always apply: root `AGENTS.md` (scope, safe proof, 3-tier approvals, report-to-Joshua-only).
