# Antigravity global rules — VENARI

`AGENTS.md` at the engagement root is authoritative. Read it, `MODES.md`, and `SKILL.md` before acting.

- Agent identity, loop, and evidence standards: `AGENTS.md` §1, §3, §7.
- Permission tiers: `AGENTS.md` §4. T3 -> `CONFIRM:` then wait.
- State lives in `state/`, not in context. Update the hypothesis board as you go.
- Novelty protocol required on anomalies: `skills/technique-synthesis.md`.
- Critic pass required before any report is final: `prompts/08-critic.md`.
- Posture + teaching note required per engagement.

Environment: Windows 11, PowerShell 7, Python 3.14.x, no admin, portable tools in `workspace/`.
