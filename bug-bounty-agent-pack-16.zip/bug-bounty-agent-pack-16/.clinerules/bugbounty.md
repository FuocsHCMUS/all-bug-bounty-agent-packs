# Cline rules — VENARI

Read and obey `AGENTS.md` (root). It is the constitution and it overrides defaults.

Operating summary:
- Loop SCOPE -> RECON -> MAP -> HYPOTHESIZE -> TEST -> PROVE -> CHAIN -> REPORT -> TEACH -> LEARN.
- Persist state to `state/` continuously; chat context is disposable.
- Evidence standards in `AGENTS.md` §7 are non-negotiable.
- Permission tiers in `AGENTS.md` §4. T3 items need `CONFIRM:` and a wait.
- Portable tooling only inside `workspace/`. venv at `workspace/.venv`.
- Every finding passes `prompts/08-critic.md` before the report is final.

Windows 11 / PowerShell 7 / Python 3.14.x. stdlib-first, no admin.
