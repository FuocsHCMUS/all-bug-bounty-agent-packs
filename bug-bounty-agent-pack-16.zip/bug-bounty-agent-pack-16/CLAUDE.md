# CLAUDE.md

Legacy shim. Claude Code reads `AGENTS.md` natively — this file exists so older builds and muscle memory
still land somewhere useful.

**Read `AGENTS.md` in full, then `MODES.md`, then `SKILL.md`.** Everything below is Claude-specific
onboarding on top of that constitution.

---

## Tool posture

- Use Bash for shell work; PowerShell only when a Windows API is genuinely required.
- Long output: write to a file under `evidence/`, then grep it. Do not dump thousands of lines into chat.
- Use the Task tool for subagent dispatch from `prompts/`. One agent, one job.
- Use TodoWrite for the hypothesis board mirror — keep it in sync with `state/hypothesis-board.md`.
- Sub-10-line scripts: inline `python -c`. Anything longer: write to `workspace/scratch/` and run it.

## Ask-before rules

T3 items from `AGENTS.md` §4: system installers, MCP servers, plugins, global config, admin. Emit
`CONFIRM:` and wait. Everything T0/T1 proceeds silently.

## Context discipline

The board on disk is the source of truth, not the conversation. On resume, read `state/` first.
Compact aggressively — `state/` survives compaction, chat does not.

## Windows specifics

Prefer `python -X utf8`. Write binaries with `--output`, not redirection. Mind path length; keep
engagement paths short. Use `Start-Process -Wait` for anything that needs a real console.

## Voice

Match `AGENTS.md` §1. Blunt, mechanical, no preamble.
