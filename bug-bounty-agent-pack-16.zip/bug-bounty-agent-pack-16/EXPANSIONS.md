# Expansions beyond the original brief

Everything added that the brief did not ask for, and why.

1. **Named persona (VENARI).** A named identity with an explicit stance changes output voice and
   attention allocation far more than "act as a pentester". §1 of `AGENTS.md`.
2. **Autonomy modes.** `MODES.md` with HUNT / RECON / STUDY / REPORT-ONLY / TEACH. Lets the same pack
   serve a live engagement, a quiet research day, and a study session without re-prompting.
3. **Four-tier permission protocol.** The brief said "ask before running things". Turned into tiers so
   the agent does not ask about trivia: T0/T1 silent, T2 announce, T3 confirm. §4 of `AGENTS.md`.
4. **Subagent roster with a mandatory critic.** Nine roles in `prompts/`, including an adversarial
   critic that plays the triager trying to close the bug. Nothing ships uncritiqued.
5. **Hypothesis board as a file.** Cards with claim, why-plausible, test, kills-if, cost. Moves the
   reasoning out of chat and into durable, ranked, falsifiable state.
6. **Coverage map with a negative log.** Discovery is measured, including the negatives, so blank
   regions are visible instead of assumed.
7. **Technique synthesis protocol.** Five mechanical steps: describe the deviation, enumerate the
   developer's assumptions, break the cheapest, generate semantic/structural/encoding mutations, run all
   three. Explicit novelty requirement rather than "be creative".
8. **Technique card corpus.** `skills/techniques/` with a template and an index by parser class, so
   knowledge compounds across sessions instead of evaporating.
9. **CVE pipeline with reachability gating.** Fingerprint -> NVD/OSV/GHSA -> patch diff -> reachability.
   Reachability is required before a version match becomes a finding.
10. **Patch-diff-first exploitation.** Read the fixing commit and write the PoC from the diff, not from
    a blog post. Blog posts are wrong about details; diffs are not.
11. **Writeup and CTF de-abstraction.** A six-question extraction protocol plus a CTF-to-production
    adaptation table, so reading produces mechanisms rather than payloads.
12. **Eight-axis posture framework.** Inventory, identity, input handling, crypto, detection, SDLC,
    cloud, disclosure — with evidence required per rating, and a mandatory "what they do well" section.
13. **Root-cause descent.** symptom -> proximate -> design -> process -> organisational, with an
    explicit instruction to stop at speculation. Used both offensively (search strategy) and
    defensively (fix quality).
14. **Twelve-week root-cause-first curriculum.** Physical layer upward, one lab per week, ending in
    detection and evasion. `learning/`.
15. **SOC and detection track.** Every offensive technique gets a matching detection section, including
    what is structurally invisible. Teaches the half of security that most offensive material omits.
16. **Evidence standard per finding.** `repro.sh`, `repro.py`, `raw/`, `artifacts/`, `impact.md`,
    `chain.md`, `fix.md`. Raw bytes over prose, one variable per step, two identities, 20-sample timing.
17. **Three-level remediation.** Immediate, class-wide, detection. Forces the report to be useful past
    the single instance.
18. **Dedup gate with a pre-submission checklist.** Assume it is already reported; prove otherwise.
19. **Severity anchored to impact sentences.** Score only after `impact.md` exists, plus an explicit
    downgrade table for the common inflation patterns.
20. **Chain-before-report rule.** No report leaves the directory without `chain.md`, even if the answer
    is "none identified".
21. **Portable-by-default toolchain.** Everything clones into `workspace/`, venv at `workspace/.venv`,
    `pip install` free. `bootstrap.ps1` + `Makefile` for the baseline.
22. **Windows 11 / Python 3.14 specifics.** `python -X utf8`, `--output` over redirection, path length,
    CRLF in payload files, no `distutils`.
23. **Per-client adapters.** `CLAUDE.md`, `.cursor/rules/`, `.clinerules/`, `.agent/rules/`,
    `opencode.json`, `codex/config.toml` — all funnelling to one constitution so behaviour does not
    drift by editor.
24. **`state/blocked.md`.** An explicit place for what waits on the user, so the agent does not silently
    stall or silently assume an approval.
25. **Session close ritual.** Board resolution, coverage statuses, session note, tool log, and a
    three-item report. Engagements become resumable by a cold context.
26. **Anti-pattern list.** The specific failure modes of LLM hunting — scanner-first, "potential"
    language, self-XSS reports, payload copying without a parser target.
27. **Definition of done.** Explicit, per finding and per engagement, so the agent cannot declare
    victory early.
