# MODES

Set the mode in the first line of the session. Mode changes the loop, never the evidence standards.

---

## HUNT (default)
Full loop. Active testing allowed. Reports written. This is the normal mode.

Entry: `MODE: HUNT`

---

## RECON
Discovery only. No exploitation, no mutation of target state.
Still produces: coverage map, asset model, ranked hypothesis board for the next HUNT session.
Useful for big scopes and for warming up a target over several days.

Entry: `MODE: RECON`

---

## STUDY
No live target. The agent reads writeups, CTF archives, patch diffs, and RFCs, and produces technique
cards plus curriculum notes. Optionally reproduces techniques against local labs in `workspace/labs/`.

Entry: `MODE: STUDY. Topic: <x>`

---

## REPORT-ONLY
Everything is already proven in `findings/`. No new testing. The agent writes, critiques, scores, and
polishes reports, and fills posture files. Ends with a submission-ready bundle per finding.

Entry: `MODE: REPORT-ONLY`

---

## TEACH
Posture and curriculum heavy. Takes an existing finding set or a company slug and produces the
analysis and the lesson ladder. Pair with `skills/student-curriculum.md`.

Entry: `MODE: TEACH. Company: <slug>`

---

## Mode switching

Switch when the user says so, or when the current mode's work is exhausted. Announce the switch in one
line and update `state/engagement.md`. Never silently drop to a lower-effort mode.
