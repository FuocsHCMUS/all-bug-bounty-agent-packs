# VENARI — Bug Bounty Agent Pack (v16)

A complete operating system for autonomous, offensive-grade bug bounty hunting, driven by a coding agent
(Claude Code, Codex, opencode, Cline, Cursor, Antigravity) inside a single working directory.

VENARI is the agent's name. Latin: *to hunt*. It is a persona, not a mascot — it changes how the model
allocates attention, writes, and decides.

---

## 1. What this pack actually is

This is not a checklist dump. It is a **loop engine**:

```
SCOPE -> RECON -> MAP -> HYPOTHESIZE -> TEST -> PROVE -> CHAIN -> REPORT -> TEACH -> LEARN -> (repeat)
```

Every directory below implements one segment of that loop. The pack is designed so that a competent
model running it behaves like a senior offensive security engineer on their third year of full-time
bug bounty, not like a scanner wrapper.

Three things separate this pack from a normal prompt:

1. **Evidence discipline.** Nothing is a finding until it is reproducible from a shell.
2. **Technique synthesis.** The agent is required to *invent*, not just recall. There is a dedicated
   protocol for deriving new primitives from observed behaviour.
3. **Dual output.** Every engagement produces (a) findings the user can disclose, and (b) a written
   security-posture analysis plus teaching notes so the user actually levels up.

---

## 2. File map

| Path | Role |
|---|---|
| `AGENTS.md` | Master constitution. Read first, always. |
| `SKILL.md` | The core hunting skill. The method. |
| `MODES.md` | Operating modes (HUNT / RECON / STUDY / REPORT-ONLY). |
| `skills/` | Deep per-domain skills: recon, web, API, auth, cloud, mobile, exploit-dev, synthesis, CVE research, writeup ingestion, reporting, triage, posture, curriculum, orchestration. |
| `prompts/` | Drop-in role prompts for subagents. |
| `playbooks/` | Per-vulnerability-class attack methodology. |
| `templates/` | Report bodies, PoC skeleton, posture report, note formats. |
| `scripts/` | Python helpers, stdlib-first, Python 3.14 / Windows 11 safe. |
| `state/` | Live engagement state. The agent's working memory on disk. |
| `notes/` | Human-readable notes, including per-company posture files. |
| `learning/` | Root-cause-first curriculum for a student coming from zero. |
| `workspace/` | Everything portable gets cloned/downloaded here. Never outside. |
| `.cursor/rules/`, `.clinerules/`, `.agent/rules/`, `opencode.json`, `CLAUDE.md`, `.codex/` | Per-client adapters. |
| `EXPANSIONS.md` | Everything added beyond the original brief. |

---

## 3. Quick start

1. Unzip so that `AGENTS.md` sits at the root of an empty directory. That directory is the engagement root.
2. Open that directory in your agent of choice.
3. Say: `MODE: HUNT. Read AGENTS.md, then SKILL.md. Program: <name>. Scope file: state/scope.json.`
4. Fill `state/scope.json` (or paste the raw program brief and let the agent parse it into that file).
5. Let it run. Approve tool installs as it asks. Watch `state/hypothesis-board.md` — that is the brain.

Per-client specifics:

- **Claude Code** — reads `AGENTS.md` natively; `CLAUDE.md` exists only as a legacy shim.
- **Codex** — reads `AGENTS.md` natively. `codex/config.toml` sets sandbox + approval defaults.
- **opencode** — reads `AGENTS.md`; `opencode.json` wires instructions and permissions.
- **Cline** — reads `.clinerules/`. `.clinerules/bugbounty.md` points back to `AGENTS.md`.
- **Cursor** — `.cursor/rules/bugbounty.mdc` (always-on rule) plus `AGENTS.md`.
- **Antigravity** — `.agent/rules/global.md` plus `AGENTS.md`.

All adapters funnel to the same constitution. There is exactly one source of truth.

---

## 4. The permission protocol in one paragraph

The agent asks before anything that touches the system or the network beyond passive reads.
Portable, no-install tools (repos, single-file binaries, wordlists) get cloned straight into
`workspace/` without asking. `pip install` into a local venv needs no ceremony. System-wide installers,
package managers, MCP servers, plugins, and anything that changes global config get an explicit
`CONFIRM:` line first. Full tiers in `AGENTS.md` §4.

---

## 5. Environment assumptions

Windows 11, PowerShell 7, Python 3.14.x, no admin assumption. Scripts are stdlib-first, then
`requests`/`httpx` in a venv at `workspace/.venv`. POSIX-only tooling runs through WSL or a portable
build. If something needs admin, the agent says so and stops.

---

## 6. What "done" looks like

An engagement is done when every live hypothesis has a verdict, every finding has a reproduction path
and a written impact, the coverage map has no unexplained blank regions, and the posture file plus the
teaching notes are filled in. Not before.
