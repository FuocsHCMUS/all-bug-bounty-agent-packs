# SKILL.md — The Hunt

The master method. Read after `AGENTS.md`. Phase skills in `skills/` go deeper; this file is the spine.

---

## 1. Framing

A bug bounty target is a machine for converting input into state, built by people under deadline.
Every one of those conversions is a trust boundary. Your job is to find the conversion where the
developer trusted something they should not have.

You are not looking for "vulnerabilities". You are looking for:

- input that reaches a parser it was not written for
- state that can be reached out of order
- identity that can be asserted rather than proven
- data that crosses a tenant or role line without a check
- a component whose version implies a known break

---

## 2. SCOPE

1. Read the brief twice. Extract: in-scope assets, out-of-scope, wildcard rules, rate limits, account
   requirements, prohibited techniques, disclosure terms.
2. Write `state/scope.json`:

```json
{
  "program": "",
  "platform": "",
  "in_scope": [{"asset": "", "type": "web|api|mobile|host|cidr|repo", "notes": ""}],
  "out_of_scope": [],
  "rules": {"rate_limit": "", "accounts": "", "prohibited": [], "wildcard": false},
  "rewards": {"min": 0, "max": 0, "currency": ""},
  "deadline": ""
}
```

3. Write the scope summary into `state/engagement.md` in your own words. Ambiguity goes in a
   `QUESTIONS:` block — resolve it before deep testing, not after.
4. Note the reward table. It tells you where the program's own attention is, and therefore where their
   testing is thinnest.

---

## 3. RECON

Passive first, always.

Passive: crt.sh and CT logs, DNS history, `amass passive`, GitHub org dorking, JS from public CDN
builds, job posts (stack hints), mobile store listings, Wayback, Shodan/Censys fingerprints,
`security.txt`, docs portals, status pages, subdomain wordlists against passive sources.

Active: resolve, probe, screenshot, `httpx -tech-detect`, `nuclei -tags tech`, favicon hashes, TLS SAN
enumeration, vhost brute force, directory and file discovery, parameter mining from archived URLs.

For each host record: scheme, status, title, tech stack, TLS issuer, redirect chain, auth surface,
interesting headers, and a one-line "why this is interesting".

Recon output rules:
- One line per asset in `state/coverage-map.md`, with a status column.
- Screenshot everything before it changes.
- Collect JS aggressively: `js-beautify` into `workspace/targets/<slug>/js/`, then grep for endpoints,
  keys, feature flags, internal hostnames, and `// TODO`.
- Anything that resolves but is not in scope gets parked with a note.

Stop recon when new hosts stop producing new tech stacks. Not when a timer expires.

---

## 4. MAP

Build `state/asset-model.md`. This is the document that makes you dangerous.

Per asset: purpose, framework, auth model, session mechanism, roles, data owned, data reachable,
upstream dependencies, trust boundaries crossed, and — critically — **which assets share a session**.

Then draw the graph. Identity flows are the highest-value edges. A token minted on host A accepted on
host B is a boundary worth attacking. A shared cookie across a marketing site and an admin panel is a
gift.

Identify the crown jewels: admin panels, billing, export endpoints, webhooks, SSO, internal API docs,
GraphQL introspection, file storage, and anything with "internal" in the hostname.

---

## 5. HYPOTHESIZE

Rank hypotheses by `value x probability / cost`. Value is reward-table position times chain potential.

Good hypothesis shape:

```
H-014 | IDOR | api.example.com | GET /v2/invoices/{id}
claim: invoice id is sequential and unbound to tenant, so tenant B can read tenant A invoices
why-plausible: ids in my own account are 1002341..1002347; no UUID; response has no tenant field
test: create two tenants, request the other's id with tenant A session
kills-if: 403 with tenant mismatch error, or ids are per-tenant sequential
cost: 2 accounts, 4 requests
```

Bad hypotheses: "test for XSS", "check SSRF". Name the endpoint and the exact request.

Aim for 15-40 live cards. A board with 4 cards is a board that has not looked hard enough.

---

## 6. TEST

Order by cost. Cheapest discriminating request first.

Techniques:
- Baseline, then one mutation. Diff. Always.
- Two identities, always, for anything access-control shaped.
- Replay every authenticated request with: no auth, other user's auth, expired auth, downgraded role,
  and a malformed auth header.
- Move parameters between body, query, path, header, and JSON depth. Parsers disagree.
- Change content types. `application/json` to `form`, `xml`, `multipart`, `text/plain`. Watch which
  one the framework still binds.
- Duplicate keys, duplicate parameters, array-wrapping a scalar, and scalar-ing an array.
- Unicode, overlong UTF-8, case folding, path normalisation, trailing dot/space/slash, `..;/`.
- Race the state machine: same request N times in parallel with distinct side effects.
- Interrupt mid-flow: skip steps, replay an old step, jump ahead, go back after completion.
- Watch for differential behaviour in errors, timing, length, headers, and cache keys.

Every test result goes in the board immediately, with the request line and a one-line observation.

---

## 7. PROVE

Minimise. Remove every header, param, and step that is not load-bearing. The minimal reproduction is
the finding.

Then: reproduce from a fresh session, then from a second account. Capture raw. Write `repro.sh`.
Comment it for a reader who has never seen the target.

If minimisation makes it stop working, you had a chain, not a bug. Note both.

---

## 8. CHAIN

For every confirmed finding, answer in `chain.md`:

- What does this give me? (data, token, code path, position)
- What can that be spent on?
- Does it bypass a control that would otherwise stop the next step?
- Can it be made persistent? Silent? Automated at scale?
- What is the worst realistic end state?

Standard chain shapes to check: info-leak -> auth bypass; SSRF -> metadata -> credentials -> cloud
takeover; XSS -> CSRF-token read -> privileged action; IDOR -> PII -> account recovery; open redirect ->
OAuth code theft; cache poison -> mass XSS; prototype pollution -> gadget -> RCE; subdomain takeover ->
cookie scope -> session theft.

Then re-score. Most criticals are two mediums wearing a trenchcoat.

---

## 9. REPORT

Use `templates/report-*.md`. Structure that works:

1. Title: `Class in Component — one-line consequence`
2. Summary: 3 sentences, no jargon, readable by a PM
3. Steps to reproduce: numbered, exact, copy-pasteable
4. Evidence: raw request/response, artifacts
5. Impact: the attacker sentence, blast radius, scale
6. Root cause: the code-level or design-level reason
7. Remediation: specific fix plus the class-wide fix
8. Chain: what else this enables
9. Notes: preconditions, limits, what you did not test

Send through `critic` first. Fix everything it raises or rebut it in the report.

---

## 10. TEACH

Two files per engagement, minimum.

`notes/company/<slug>/posture.md` — eight axes, evidence per axis, rating, and what it implies.
`learning/notes/<date>-<slug>.md` — root cause, concept ladder from physical layer up, local lab.

Be specific and be fair. Name what they do well. A posture file that only criticises is useless to a
student, because it teaches nothing about what good looks like.

---

## 11. LEARN

Anything that surprised you becomes a technique card in `skills/techniques/`. Include: target class,
mechanism, why it works, detection difficulty, and the variation that would generalise it.

Anything that generalises gets promoted into the relevant `playbooks/` file with a `SOURCE:` line.

---

## 12. Session close

1. Resolve every open card: confirmed, dead, or parked with a reason.
2. Update coverage map statuses.
3. Write `notes/sessions/<date>.md`: what was tried, what worked, what to do next.
4. Update `workspace/TOOLS.md` with anything installed.
5. Report to the user: findings count by severity, the three most interesting observations, and the
   recommended next session focus.
