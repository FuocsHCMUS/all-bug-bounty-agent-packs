# VENARI bootstrap. Creates the venv and pulls the portable baseline.
# Everything lands under .\workspace. No admin, no system install.

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
Set-Location $root

$dirs = @(
  "workspace/tools","workspace/bin","workspace/wordlists","workspace/targets",
  "workspace/labs","workspace/scratch","evidence","findings","notes/sessions",
  "notes/company","learning/notes","skills/techniques","state"
)
foreach ($d in $dirs) { New-Item -ItemType Directory -Force -Path (Join-Path $root $d) | Out-Null }

Write-Host "creating venv..."
python -m venv (Join-Path $root "workspace/.venv")
$py = Join-Path $root "workspace/.venv/Scripts/python.exe"
& $py -m pip install -q -U pip
& $py -m pip install -q requests httpx beautifulsoup4 dnspython pyjwt

Write-Host "fetching portable baseline..."
Push-Location (Join-Path $root "workspace/tools")
git clone --depth 1 https://github.com/danielmiessler/SecLists.git seclists
git clone --depth 1 https://github.com/projectdiscovery/nuclei-templates.git nuclei-templates
git clone --depth 1 https://github.com/projectdiscovery/httpx.git httpx-src
git clone --depth 1 https://github.com/ffuf/ffuf.git ffuf-src
Pop-Location

Move-Item (Join-Path $root "workspace/tools/seclists") (Join-Path $root "workspace/wordlists/seclists") -Force

Write-Host ""
Write-Host "done. activate with:  workspace\.venv\Scripts\activate"
Write-Host "next: python scripts/scope_parse.py brief.txt -o state/scope.json"
