# Roadmap — zero to operator

Twelve weeks, bottom-up. Each week: read, lab, write one note, then attack the same class on a live
target. Do not skip the ladder — the later weeks are only legible if the earlier ones are solid.

| Week | Layer | Focus | Lab |
|---|---|---|---|
| 1 | Physical/Link | NICs, MAC, ARP, switching, broadcast domains | Wireshark capture of your own ARP traffic |
| 2 | Network | IP, subnetting, routing, NAT, ICMP, fragmentation | `ping`, `traceroute`, packet capture of a fragmented ping |
| 3 | Transport | TCP handshake, states, sequence numbers, UDP, port scanning | `tcpdump` a full handshake; nmap a local VM |
| 4 | TLS | Handshake, certs, chain of trust, interception | mitmproxy against your own Flask app |
| 5 | HTTP | Methods, headers, cookies, caching, proxies | Build and break a Flask app with Burp |
| 6 | Parsers | URL, multipart, JSON, XML, path normalisation | Write a deliberately broken parser, then break it |
| 7 | Auth | Sessions, tokens, JWT, OAuth, roles | Hand-roll a JWT login and break it |
| 8 | Access control | Tenancy, RBAC, IDOR, batch endpoints | Two-user Flask app with a deliberate BOLA |
| 9 | Injection | SQL, command, template, LDAP | Juice Shop + a hand-written SSTI target |
| 10 | Client side | DOM, XSS, CORS, CSRF, postMessage | PortSwigger Academy XSS labs |
| 11 | Cloud | Metadata, buckets, IAM, takeover | LocalStack + a misconfigured bucket |
| 12 | Detection | Log sources, rule writing, evasion | Write Sigma rules for weeks 8-11, then evade them |

Then: bug bounty on a real program, low-hanging scopes first, with `MODE: HUNT`.

## Rules

- One note per week in `learning/notes/`, root cause first.
- If a week's lab does not work, the week is not done.
- Read the RFC for anything you break. RFCs are the ground truth about what a parser must accept.
