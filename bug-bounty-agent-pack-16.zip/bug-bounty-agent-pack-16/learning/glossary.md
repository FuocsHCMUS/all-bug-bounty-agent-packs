# Glossary

Plain-language, mechanism-first. Add to it every session.

**ACAO** — `Access-Control-Allow-Origin` response header; decides which origin may read the response.

**ARP** — protocol mapping IP to MAC inside a broadcast domain; unauthenticated.

**ASN** — Autonomous System Number; identifies a network operator, useful for scoping by ownership.

**BOLA** — Broken Object Level Authorisation; the object exists and you can reach it, but nobody checked
whether *you* may. The API-flavoured name for IDOR.

**Chain** — two or more findings composed so the combined impact exceeds either alone.

**CL.TE / TE.CL** — smuggling classes named by which side honours which framing header.

**CNAME** — DNS alias. Dangling CNAMEs are the substrate of subdomain takeover.

**CVSS** — scoring framework; a vector string of exploitability and impact metrics. Anchors, does not
decide.

**Dangling record** — a DNS record pointing at a resource nobody owns any more.

**Deserialisation** — turning bytes back into objects; often reaches constructors and gadgets.

**Differential** — behaviour that differs between two requests; the core signal of the whole discipline.

**Gadget** — an existing code path abused as a step in a chain, usually for code execution.

**IDOR** — Insecure Direct Object Reference; see BOLA.

**IMDS** — cloud instance metadata service at `169.254.169.254`; hands out credentials.

**JARM** — TLS server fingerprint, like a favicon hash for TLS.

**JWT** — signed JSON token. `alg`, `kid`, `jku`, `x5u` are the interesting fields.

**Open redirect** — a redirect whose destination you control; a chain ingredient, rarely a finding alone.

**Prototype pollution** — writing into `Object.prototype` so later reads inherit your value.

**Rebinding** — a DNS name that resolves to a public IP first, then a private one, defeating allowlists.

**Sink / source** — where tainted data lands / where it enters. The whole of taint analysis.

**Smuggling** — hiding a second request inside the framing of the first.

**SSRF** — the server makes a request on your behalf.

**Stored / reflected / DOM** — where the payload lives: persisted, echoed, or executed by client JS.

**Takeover** — claiming an abandoned third-party resource a DNS record still points at.

**TOCTOU** — time-of-check to time-of-use; the check and the effect see different state.

**Trust boundary** — a place where data crosses from lower to higher privilege; the only place bugs live.

**Vary** — response header listing the request headers that are part of the cache key.

**VRT** — Bugcrowd's Vulnerability Rating Taxonomy; the severity vocabulary on that platform.

**WAF** — web application firewall; a parser that disagrees with the origin, therefore a target.
