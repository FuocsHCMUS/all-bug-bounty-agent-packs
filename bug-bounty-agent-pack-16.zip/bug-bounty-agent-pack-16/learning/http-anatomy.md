# HTTP anatomy

Read this before any web testing. It is the layer everything else sits on.

---

## 1. The message

```
GET /path?q=1 HTTP/1.1        <- request line: method, target, version
Host: example.com             <- required in 1.1
Header: value                 <- zero or more
                              <- empty line: end of head
body                          <- optional, framing depends on headers
```

The target is a string until something parses it. That parsing is where bugs live.

## 2. Framing

`Content-Length` gives a byte count. `Transfer-Encoding: chunked` gives a chunk stream. Both present is
a disagreement, and disagreement is smuggling. Chunk format: hex size, CRLF, data, CRLF, then `0` CRLF CRLF.

## 3. Methods

Safe: `GET`, `HEAD`, `OPTIONS`. Not safe: `POST`, `PUT`, `PATCH`, `DELETE`. `HEAD` returns headers only —
useful for leaking what `GET` hides. `OPTIONS` reveals `Allow`.

## 4. Status classes

1xx informational, 2xx success, 3xx redirect, 4xx client, 5xx server. `401` means identity missing, `403`
means identity present but insufficient. The gap between `401` and `403` on adjacent paths is an
existence oracle.

## 5. Headers that matter

`Host` (routing), `Authorization`, `Cookie`, `Origin`/`Referer` (origin checks), `X-Forwarded-*`
(proxy trust), `Content-Type` (which binder runs), `Accept` (which serialiser runs), `Vary` (cache key),
`Cache-Control`, `Set-Cookie` flags.

## 6. Cookies

`name=value; Domain=; Path=; Secure; HttpOnly; SameSite`. `Domain=.example.com` makes the cookie readable
by every subdomain — which is why subdomain takeover matters. `SameSite` is the CSRF control; `None`
requires `Secure`.

## 7. Parsing disagreements to know

- `Content-Length` duplicates with different values
- header name with a space before the colon
- obs-fold (header continued on the next line with leading whitespace)
- absolute-form target: `GET http://internal/ HTTP/1.1`
- `%2f` vs `/` in the path, `..;/`, overlong UTF-8 in the path
- charset in `Content-Type` changing the body decoder
- `multipart` boundary with quotes, `filename*=` RFC 5987

## 8. Why this matters

Every one of the above has produced a real bug bounty payout. Not because they are exotic, but because
two components in the chain parsed them differently. Learn the layer, then look for the second parser.
