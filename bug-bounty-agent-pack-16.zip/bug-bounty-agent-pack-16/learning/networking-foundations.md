# Networking foundations

From the wire up, because every higher bug sits on this.

---

## 1. The wire

A NIC converts frames to signals. Ethernet frames carry a destination MAC, source MAC, ethertype, payload,
and a checksum. A switch learns MAC-to-port and forwards. A hub repeats to every port. In a broadcast
domain, everyone sees broadcast frames — ARP is a broadcast.

## 2. ARP and L2 trust

ARP resolves IP to MAC with no authentication. Anyone can answer "that IP is me". That is ARP spoofing,
and it is why L2 is a trust boundary. Gratuitous ARP announces a mapping unprompted.

## 3. IP

An IP packet has a source, a destination, a TTL, a protocol, and options. Routers decrement TTL and
forward by longest-prefix match. Private ranges: `10/8`, `172.16/12`, `192.168/16`, `127/8`, `169.254/16`
(link-local — this is why cloud metadata is `169.254.169.254`).

Fragmentation splits packets; reassembly is a parser, and reassembly bugs are a real class.

## 4. TCP

Three-way handshake: SYN, SYN-ACK, ACK. Sequence numbers make it a stream. `RST` tears down. States:
`LISTEN`, `SYN_SENT`, `ESTABLISHED`, `FIN_WAIT`, `TIME_WAIT`. Half-open scans send SYN and never ACK —
that is what `-sS` does. A full connect scan completes the handshake.

TCP is stateful, which means state machines can be raced and desynchronised. That is the basis of
smuggling at the application layer.

## 5. UDP

Connectionless, no ordering, no guarantee. DNS, QUIC, and most real-time protocols. Spoofing is trivial
because there is no handshake — which is why DNS amplification works.

## 6. Ports and services

0-1023 well known, 1024-49151 registered, above that ephemeral. A port open is a service; a service is a
parser; a parser is a target. `nmap -sV` fingerprints by behaviour, not by banner alone.

## 7. NAT

Rewrites addresses at a boundary. Breaks inbound connections, creates traversal problems, and makes
"internal vs external" a real distinction that SSRF crosses.

## 8. Reading a capture

Wireshark filter `tcp.port == 8080`, follow stream, look at the request line. In bug bounty, captures
matter for timing, retransmission, and proving a race.

## 9. Lab

`tcpdump -i any -w cap.pcap 'tcp port 80'` against your own server, then read it in Wireshark. Then ARP
spoof a local VM and watch the traffic move.
