# Root-cause-first thinking

The method behind every note in this pack.

---

## 1. Why symptom-first fails

"Missing authorisation check on `/invoices/{id}`" is a symptom. Learn it and you have learned one endpoint.
Learn *why* the check was missing — the route was added by a different team, the ORM fetch happens in a
middleware that runs before the policy layer, the policy is registered by decorator and the decorator was
omitted — and you can predict where else it is missing.

## 2. The descent

symptom -> proximate cause -> design cause -> process cause -> organisational cause.

- **Proximate**: the literal line that is wrong.
- **Design**: the structural choice that made the wrong line easy to write.
- **Process**: the missing review, test, or gate that would have caught it.
- **Organisational**: the team split, deadline, or ownership gap behind the process.

Stop when the next step would be speculation, and say so.

## 3. Applying it offensively

The design cause tells you where else to look. If authorisation is per-route and manually registered,
enumerate every route and diff the registrations. If the policy is a middleware that runs after the
fetch, look for every handler that fetches before the middleware.

Root cause is a search strategy, not just a report section.

## 4. Applying it defensively

Design causes are fixable at scale; symptoms are not. The good remediation addresses the design cause:
a central policy layer, a route-registration test, a schema-driven binder with one validator.

## 5. Practising

Take a public disclosed report. Read the fix. Ask what design choice made the bug possible, and what
class-wide change would have prevented it. Then find three other places in the same product where the
same design choice appears.
