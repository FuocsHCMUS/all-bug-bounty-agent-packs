# SOC and detection

Offence without detection knowledge is half the skill.

---

## 1. What a SOC does

Collects logs, normalises them, correlates, alerts, triages, escalates, contains. The analyst sees
*events*, not requests. Your job as a hunter is to understand what your traffic looks like in that
pipeline — and what does not appear at all.

## 2. Log sources

Web server access logs, WAF logs, proxy logs, auth logs, EDR, DNS logs, cloud audit trails
(CloudTrail, GCP Audit, Azure Activity), Kubernetes audit, application logs, database audit.

## 3. Rule shape

Sigma rule: `logsource` (product, service, category), `detection` (selection + condition), `level`,
`falsepositives`. Good rules key on structure, not on a literal payload string. A rule for
`/\.\./` false-positives constantly; a rule for a path that decodes to a traversal after one pass is better.

## 4. What is usually invisible

- Single-request IDOR reads (no error, no anomaly)
- Logic bugs (all requests valid)
- Slow enumeration under the rate limit
- Reads from an IP that is already allowlisted
- Anything that reuses a legitimate token

## 5. Evasion, conceptually

Stay under thresholds, spread across IPs, mimic the client (headers, ordering, TLS fingerprint), avoid
error-generating payloads, use the same session, and prefer the endpoint with no logging. Each of these
is a detection-control gap you can name in a report.

## 6. Lab

Write Sigma rules for weeks 8-11 of the roadmap. Then run your own attacks and count alerts. Then change
the attack until the count is zero, and write down what you changed.

## 7. Why it makes you better

A finding with "and here is the rule that would have caught it" is worth more to the program, and the
detection section is what separates a report from a scan dump.
