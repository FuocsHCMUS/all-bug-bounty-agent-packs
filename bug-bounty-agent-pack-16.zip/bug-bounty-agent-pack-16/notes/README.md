# Notes layout

- `notes/sessions/<date>.md` — per session: tried, worked, next.
- `notes/company/<slug>/posture.md` — eight-axis posture analysis, appended across engagements.
- `notes/company/<slug>/surface.md` — durable asset knowledge for that company.
- `notes/dups.md` — known duplicates with links, so future sessions skip them.
- `notes/ideas.md` — unranked sparks that are not yet hypotheses.

Nothing here is a finding. Findings live in `findings/`.
