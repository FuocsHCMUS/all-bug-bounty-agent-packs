# Playbook: access control

Two identities, always. Never a modified token alone.

---

## Test matrix

For every object endpoint, run all cells:

| Actor | Action | Expect |
|---|---|---|
| owner | read/write | 200 |
| other tenant | read | 403 |
| other tenant | write | 403 |
| other role (lower) | read | 403 |
| no auth | read | 401 |
| expired auth | read | 401 |
| other tenant, wrong method | read | 403 |

Any deviation is a card.

## Identifier shapes

Sequential int, UUIDv1, short hash, base64 of `type:id`, ULID, slug, composite path.
Nested paths where only the parent is authorised: `/org/{a}/members/{b}`.
Batch: `ids=1,2,3` with only the first authorised.
Export/report endpoints with weaker checks than the detail endpoint.
GraphQL node lookup by global id.

## Header and context trust

- `X-Org-Id`, `X-Tenant`, `X-User-Id` trusted over the session
- `X-Forwarded-*` influencing authorisation
- JWT claim trusted where the DB is authoritative (role change not reflected)
- path prefix routing: `/api/v1/admin/` vs `/api/v1/` on the same handler

## Method and verb

- `GET` guarded, `PUT`/`PATCH`/`DELETE` not
- `HEAD` leaking headers the GET blocks
- `_method=PUT` override
- `OPTIONS` revealing routes

## Rules

- Record both raw responses side by side; the diff is the evidence.
- A 403 with different body length between existing and non-existing resources is an enumeration leak.
- Test after logout and after role change.
