# Playbook: client-side

The browser is the boundary. The DOM is the sink.

---

## 1. DOM XSS

Trace sources into sinks:

sources: `location.href`, `location.hash`, `location.search`, `document.referrer`, `postMessage`,
`window.name`, `localStorage`, `IndexedDB`, fetched JSON.
sinks: `innerHTML`, `outerHTML`, `insertAdjacentHTML`, `document.write`, `eval`, `Function`,
`setTimeout(str)`, `jQuery.html/append`, `srcdoc`, `href` with `javascript:`, Angular `[innerHTML]`,
React `dangerouslySetInnerHTML`, Vue `v-html`.

Then: sanitizer version check, mutation XSS, prototype pollution to reach a sink, framework-specific
template injection (`{{constructor.constructor('...')()}}`).

## 2. postMessage

- `addEventListener('message')` without origin check
- `targetOrigin: '*'` carrying a token or a URL
- handler that writes `event.data` into a sink
- nested iframe relay chains

## 3. CORS

- `Access-Control-Allow-Origin` reflecting `Origin` with `Allow-Credentials: true`
- `null` origin accepted
- subdomain regex bypass: `target.com.evil.com`, `eviltarget.com`, `target.com.evil`
- `Access-Control-Allow-Headers` wide, preflight cache long
- reading authenticated JSON cross-origin = account data exfil

## 4. CSRF

- token not bound to session, or not validated on all verbs
- JSON endpoints accepting `text/plain` form bodies
- `SameSite=None` without other protection
- token in a GET-reachable page, read via CORS
- login CSRF, logout CSRF, email-change CSRF
- method override on a GET

## 5. Clickjacking and UI redress

- state-changing pages without `frame-ancestors`
- double-framing, `X-Frame-Options` `ALLOW-FROM` (dead), frame busting bypass
- drag-and-drop and clipboard-based redress

## 6. Third-party

- `document.domain` relaxation
- JSONP endpoints
- OAuth implicit flow, `postMessage` token passing
- widget embeds with a permissive CSP

## 7. Rules

- Prove execution in a real browser, on the real origin.
- For CORS, prove the data read, not just the headers.
- For CSRF, prove the state change, not just the request.
