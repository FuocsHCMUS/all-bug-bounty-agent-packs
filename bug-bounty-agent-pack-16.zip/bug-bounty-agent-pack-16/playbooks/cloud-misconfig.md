# Playbook: cloud misconfiguration

Read-only first, always. List, then read, then write.

---

## 1. Storage

- bucket name permutations from the org, product, and environment names
- list (`?list-type=2`), object read, ACL read (`?acl`), website index, versioning, logging
- `x-amz-bucket-region`, `x-amz-account-id` from the response headers
- GCS `storage/v1/b/<bucket>/o`, Azure `?restype=container&comp=list`
- signed URL parameter analysis: expiry, method scope, IP binding
- write proof: PUT a small text object, then GET it back, then clean up

## 2. Compute and orchestration

- kubelet `:10250/pods`, `:10255`, anonymous auth, dashboard, `/metrics`
- Docker API `:2375/containers/json`
- ECS task metadata `169.254.170.2/v2/metadata`
- Cloud Run / App Engine metadata headers
- Jenkins `/script`, `/asynchPeople`, `/credentials`

## 3. Data services exposed

Elasticsearch `/_cat/indices?v`, `/_search?size=1`, Mongo `:27017` handshake, Redis `:6379` `INFO`,
RabbitMQ management `:15672`, Prometheus `/targets`, Grafana `/api/datasources`, Consul `/v1/catalog`,
etcd `/v2/keys`.

## 4. Identity misconfiguration

- over-broad instance role reachable from SSRF
- `iam/security-credentials/` returns a role name, then the credentials
- trust policy allowing `*` principal
- long-lived access keys in JS or repos
- OIDC trust with a wildcard subject

## 5. DNS and takeover

Dangling CNAME to S3/GitHub Pages/Heroku/Azure/Netlify/Surge/Shopify/Zendesk, unclaimed NS delegation,
dead MX, `Domain=.parent` cookie to convert takeover into session theft.

## 6. Rules

- List before read, read before write.
- Screenshot the unclaimed-resource page as takeover evidence.
- Never leave test objects behind; note what you created and delete it.
