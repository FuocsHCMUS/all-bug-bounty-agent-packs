# Playbook: protocol-level bugs

Cache, smuggling, and parser disagreement live below the app.

---

## 1. Cache poisoning

Signals: CDN, `X-Cache`, `Age`, `CF-Cache-Status`, `Vary` absent, reflected unkeyed inputs.

Check whether these are keyed: `X-Forwarded-Host`, `X-Host`, `X-Forwarded-Scheme`, `X-Original-URL`,
`X-Rewrite-URL`, `Forwarded`, cookies not in `Vary`, query params not in the cache key.

Then: unkeyed header reflected into a redirect, a script src, or a link -> cache it -> mass impact.
Also: cache deception (`/account/profile.css`), cache key normalisation, `Vary: *` absence, cache
poisoning of a 404 with an XSS body.

## 2. Request smuggling

Only where a proxy and origin disagree on framing. Variants: `CL.TE`, `TE.CL`, `TE.TE` obfuscation,
`Content-Length` duplicates with differing values, chunk size extensions, `Transfer-Encoding: xchunked`,
space before colon, `\r\n` in the header name, HTTP/2 downgrade with `content-length` injection.

Detection: timing probe (a smuggled request that hangs the backend), then a differential probe against a
second endpoint only you request.

## 3. Host header

- `X-Forwarded-Host` reflected into a password reset link -> token theft
- host override reaching a virtual host with different auth
- `Host: internal` and `X-Forwarded-For` combinations
- absolute-form request line `GET http://internal/ HTTP/1.1`

## 4. HTTP/2 and HTTP/3 specifics

- h2c upgrade, `:authority` vs `Host` mismatch, header injection via `\n` in h2 values
- pseudo-header smuggling, `TE: trailers`
- connection coalescing and certificate scope

## 5. WebSocket

- auth on upgrade only, not on frames
- origin check absent -> cross-site WS hijack
- message-type confusion, oversized frames, binary vs text

## 6. Rules

- Never test smuggling on a program that forbids it without noting it.
- Always have a unique canary path so you know your request landed where you think.
- Cache tests need a unique cache-buster, then a second request without it.
