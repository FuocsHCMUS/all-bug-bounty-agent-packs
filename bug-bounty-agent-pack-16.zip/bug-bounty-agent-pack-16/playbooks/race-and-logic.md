# Playbook: race conditions and business logic

Logic bugs need the state machine, not a payload.

---

## 1. Model the state machine

Enumerate states and transitions: created -> verified -> active -> cancelled -> refunded. Note which
transitions have a check and which have a side effect. The gap between check and effect is the bug.

## 2. Single-packet / barrier races

- same request N times in parallel with a barrier, not with `sleep`
- different requests that share a resource: redeem + redeem, apply-coupon + checkout, withdraw + withdraw
- limit bypass: N parallel redemptions of a one-time token
- double-spend: two balance consumers, one balance
- vote/like/referral farming
- TOCTOU on file write then read
- partial refund, negative quantity, quantity 0, float precision

Detect with distinct side effects per request (different idempotency keys, distinct user agents), then
count the results server-side.

## 3. Sequencing

- skip a step: go straight to the final endpoint
- replay an old step after completion
- jump backwards: re-verify after activating
- two tabs, interleaved
- expired token still accepted at step 3
- state transition after cancel

## 4. Value manipulation

- negative, zero, fractional, huge, scientific notation
- currency swap, rounding direction, tax after discount
- client-computed totals trusted
- unit mismatch (minor vs major units)
- quantity vs stock race
- free trial restart via email case change, plus-addressing, unicode normalisation

## 5. Trial and entitlement

- expiry checked at issue but not at use
- plan downgrade leaves features active
- invite seat limit not enforced on accept
- soft-deleted objects still actionable

## 6. Rules

- Always produce the server-side artefact (two rows, two credits, two emails).
- Video or it did not happen.
- Model before you fire.
