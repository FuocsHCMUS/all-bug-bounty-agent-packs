# Playbook: supply chain and dependencies

You inherit everything your target installs.

---

## 1. Manifest hunting

`package.json`, `package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`, `composer.json`, `Gemfile.lock`,
`requirements.txt`, `go.sum`, `pom.xml`, `packages.config`, `*.csproj`, `Dockerfile`.

Leaks: private registry URLs, internal package names, `file:` and `git+ssh:` deps, versions pinned to a
vulnerable range, `.npmrc` with a token.

## 2. Dependency confusion

Internal package names on a public registry, scoped or unscoped. Check whether the public name is
unclaimed and whether the installer prefers the higher version. Scope scope-takeover: an unclaimed
`@org/` scope.

## 3. Typosquat surface

Lookalike names near their real deps, `postinstall` scripts, deprecated packages still imported,
abandoned transitive deps.

## 4. CDN and script inclusion

- unpinned third-party script (`<script src="//cdn/.../latest.js">`)
- missing SRI on a script from a CDN you could control or that has a takeover path
- JSONP from a third party carrying session data
- `postMessage` from an embedded widget trusted blindly

## 5. Repo and CI exposure

- public repo with `.github/workflows` showing deploy commands, secrets names, environments
- `pull_request_target` with checkout of untrusted code
- self-hosted runner labels
- artifact and cache poisoning paths
- leaked `.env` in a build output directory

## 6. Rules

- Report the reachable consequence, not the manifest entry.
- A vulnerable dep with no reachable code path is informational — say so.
- Check the changelog for the fix version before claiming exploitability.
