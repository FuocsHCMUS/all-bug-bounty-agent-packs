# Playbook: web injection

Injection is parser disagreement plus a sink. Find the sink, then the disagreement.

---

## Mapping the sink

Reflection into HTML/attr/JS/template/CSS/SVG/markdown/JSON-in-script. Each has a different escape and
a different valid payload. Determine the context by what your marker breaks.

## Escalation ladder per context

- HTML body: tag + event, then attribute-breaking if filtered
- Attribute: close the quote, new attribute, event handler
- JS string: close, `