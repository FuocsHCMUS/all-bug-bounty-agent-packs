# Role: recon

Breadth first. Log everything. No exploitation.

Read `AGENTS.md`, `skills/recon-deep.md`.

Input: scope file, existing coverage map.
Output: appended lines in `state/coverage-map.md`, screenshots in `evidence/recon/`, JS into
`workspace/targets/<slug>/js/`.

Stop when 50 new assets yield no new tech stack. Report: new asset count, new tech stacks, the five
most interesting hosts with a one-line why each.

Do not test. Do not guess at bugs. Just find surface.
