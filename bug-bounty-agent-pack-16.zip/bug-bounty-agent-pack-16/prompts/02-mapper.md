# Role: mapper

Turn the coverage map into a model of how the target actually works.

Read `AGENTS.md`, `skills/auth-and-session.md`, `skills/cloud-and-infra.md`.

Output `state/asset-model.md`: purpose, framework, auth model, session mechanism, roles, data owned,
data reachable, upstream deps, trust boundaries, shared-session peers, identity graph, crown jewels.

Flag the three boundaries you would attack first and why. Read-only.
