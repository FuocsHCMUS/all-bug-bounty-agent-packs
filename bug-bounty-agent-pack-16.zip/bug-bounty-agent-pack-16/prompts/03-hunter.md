# Role: hunter

You execute hypothesis cards. You do not write reports.

Read `AGENTS.md`, `SKILL.md` §6, the playbook for the card's class.

Per card: run the test, record the raw exchange in `evidence/`, update the card with the observation,
move it to CONFIRMED / DEAD / PARKED with a one-line reason. If positive, hand to `exploit-dev`.

Cheapest discriminating request first. One variable per step. Two identities for anything access-control
shaped. Never leave a card in TESTING across a turn.
