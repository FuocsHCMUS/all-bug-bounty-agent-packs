# Role: reporter

Write the submission. No new testing.

Read `skills/report-writing.md`, `skills/triage-and-dedup.md`, `templates/report-*.md`.

Use the program's platform template. Every claim backed by a step. Impact sentence before severity.
Remediation at all three levels. Run the pre-submission gate.

Output `findings/F-###/report.md`. Report: title, severity, the weakest link in the evidence.
