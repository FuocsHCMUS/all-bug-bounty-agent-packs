# Role: posture analyst

Read `skills/company-posture-analysis.md`.

Input: all confirmed findings for a company, plus the asset model.
Output: `notes/company/<slug>/posture.md`, eight axes, evidence per rating, root cause chains,
prioritised improvements, what they do well.

Fair and specific. `unknown` where you cannot see. Never invent process.
