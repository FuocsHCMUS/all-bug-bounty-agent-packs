#!/usr/bin/env python3
"""CORS misconfiguration audit. Flags reflective ACAO with credentials.

    python scripts/cors_audit.py https://api.example.com/x --origins origins.txt
"""
import argparse
import sys
import urllib.request

DEFAULT_ORIGINS = ["https://evil.com", "null", "https://example.com.evil.com",
                   "https://evilexample.com", "http://example.com"]


def check(url, origin):
    r = urllib.request.Request(url, headers={"Origin": origin, "User-Agent": "venari-cors/1.0"})
    try:
        with urllib.request.urlopen(r, timeout=12) as resp:
            h = resp.headers
            return resp.status, h.get("access-control-allow-origin"), h.get("access-control-allow-credentials")
    except urllib.error.HTTPError as e:
        return e.code, e.headers.get("access-control-allow-origin"), e.headers.get("access-control-allow-credentials")
    except Exception as e:
        return type(e).__name__, None, None


def main():
    p = argparse.ArgumentParser()
    p.add_argument("url")
    p.add_argument("--origins")
    a = p.parse_args()

    origins = [l.strip() for l in open(a.origins, encoding="utf-8") if l.strip()] if a.origins else DEFAULT_ORIGINS
    hits = 0
    for o in origins:
        st, acao, acac = check(a.url, o)
        flag = ""
        if acao == o and (acac or "").lower() == "true":
            flag = "  <== REFLECTED + CREDENTIALS"
            hits += 1
        elif acao == o:
            flag = "  <-- reflected"
        print(f"{str(st):>4} acao={acao} acac={acac}{flag}")
    print(f"\n{hits} high-signal origin(s).")
    return 0 if hits else 1


if __name__ == "__main__":
    sys.exit(main())
