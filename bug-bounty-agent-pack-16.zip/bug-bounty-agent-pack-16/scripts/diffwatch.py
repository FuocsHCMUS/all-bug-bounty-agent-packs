#!/usr/bin/env python3
"""Re-request a list of URLs and diff against a stored baseline. Catches drift and fixes."""
import argparse
import hashlib
import json
import os
import sys
import urllib.request


def fetch(url):
    r = urllib.request.Request(url, headers={"User-Agent": "venari-diff/1.0"})
    try:
        with urllib.request.urlopen(r, timeout=15) as resp:
            b = resp.read()
            return resp.status, len(b), hashlib.sha256(b).hexdigest()[:16]
    except urllib.error.HTTPError as e:
        return e.code, 0, hashlib.sha256(e.read()).hexdigest()[:16]
    except Exception as e:
        return type(e).__name__, 0, ""


def main():
    p = argparse.ArgumentParser()
    p.add_argument("urls")
    p.add_argument("--store", default="state/diffwatch.json")
    a = p.parse_args()

    urls = [l.strip() for l in open(a.urls, encoding="utf-8") if l.strip()]
    old = json.load(open(a.store, encoding="utf-8")) if os.path.exists(a.store) else {}
    new, changed = {}, 0
    for u in urls:
        st, ln, h = fetch(u)
        new[u] = {"status": st, "len": ln, "hash": h}
        prev = old.get(u)
        if prev and (prev["hash"] != h or prev["status"] != st):
            print(f"CHANGED {u}  {prev['status']}/{prev['len']} -> {st}/{ln}")
            changed += 1
        elif not prev:
            print(f"NEW     {u}  {st}/{ln}")
    json.dump(new, open(a.store, "w", encoding="utf-8"), indent=2)
    print(f"\n{changed} change(s). baseline at {a.store}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
