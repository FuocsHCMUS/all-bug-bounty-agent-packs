#!/usr/bin/env python3
"""Scaffold the next findings/F-### directory with the evidence standard in place."""
import argparse
import pathlib
import sys

FILES = {
    "report.md": "# F-### — title\n\n## Summary\n\n## Steps to reproduce\n\n1.\n\n## Evidence\n\n## Impact\n\n## Root cause\n\n## Remediation\n\n## Chain\n\n## Notes\n",
    "impact.md": "# Impact\n\nAttacker with ___ can ___, yielding ___ for ___, without ___.\n\nBlast radius:\nScale:\nPreconditions:\n",
    "chain.md": "# Chain\n\nUnlocks:\nUnlocked by:\nEnd state:\n",
    "fix.md": "# Fix\n\nRoot cause:\nImmediate:\nClass-wide:\nDetection:\n",
    "repro.sh": "#!/usr/bin/env bash\nset -euo pipefail\n",
    "repro.py": "#!/usr/bin/env python3\n",
}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", default="findings")
    p.add_argument("--title", default="")
    a = p.parse_args()

    root = pathlib.Path(a.root)
    root.mkdir(parents=True, exist_ok=True)
    n = max([int(d.name.split("-")[1]) for d in root.glob("F-*") if d.name.split("-")[1].isdigit()] or [0]) + 1
    d = root / f"F-{n:03d}"
    d.mkdir(exist_ok=True)
    (d / "raw").mkdir(exist_ok=True)
    (d / "artifacts").mkdir(exist_ok=True)
    for name, body in FILES.items():
        f = d / name
        f.write_text(body.replace("F-###", f"F-{n:03d}").replace("title", a.title or "title"), encoding="utf-8")
    print(d)
    return 0


if __name__ == "__main__":
    sys.exit(main())
