#!/usr/bin/env python3
"""Decode a JWT and list structural weaknesses. No signature verification by design."""
import base64
import json
import sys


def d(part):
    return json.loads(base64.urlsafe_b64decode(part + "=" * (-len(part) % 4)))


def main():
    if len(sys.argv) < 2:
        print("usage: jwt_peek.py <jwt>")
        return 2
    tok = sys.argv[1].strip()
    parts = tok.split(".")
    if len(parts) != 3:
        print("not a JWT")
        return 2
    h, p = d(parts[0]), d(parts[1])
    print("header:", json.dumps(h, indent=2))
    print("payload:", json.dumps(p, indent=2))
    notes = []
    if h.get("alg", "").lower() == "none":
        notes.append("alg=none — try stripping the signature")
    if h.get("alg", "").startswith("HS"):
        notes.append("HMAC — try hashcat -m 16500 with rockyou, and RS/HS confusion")
    if "kid" in h:
        notes.append(f"kid present ({h['kid']}) — try traversal and SQLi")
    for k in ("jku", "x5u", "jwk"):
        if k in h:
            notes.append(f"{k} present — host your own key set")
    for k in ("exp", "nbf", "aud", "iss"):
        if k not in p:
            notes.append(f"claim '{k}' missing — check whether it is enforced")
    if "role" in p or "admin" in json.dumps(p).lower():
        notes.append("authorisation claims in payload — test tampering and stale claims")
    print("\nleads:")
    for n in notes:
        print(" -", n)
    return 0


if __name__ == "__main__":
    sys.exit(main())
