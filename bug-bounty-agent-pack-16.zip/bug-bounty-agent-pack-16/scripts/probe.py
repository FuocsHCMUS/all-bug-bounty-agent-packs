#!/usr/bin/env python3
"""Concurrent HTTP probe: status, title, length, server, tech hints.

    python scripts/probe.py hosts.txt -c 20 --json out.json
"""
import argparse
import concurrent.futures as cf
import json
import re
import sys
import urllib.error
import urllib.request

UA = "venari-probe/1.0"
TITLE = re.compile(r"<title[^>]*>(.*?)</title>", re.I | re.S)
TECH = {
    "wp-content": "wordpress", "drupal": "drupal", "react": "react", "ng-version": "angular",
    "__next_data__": "nextjs", "laravel_session": "laravel", "jsessionid": "java",
    "x-powered-by: php": "php", "x-aspnet": "aspnet", "grafana": "grafana", "jenkins": "jenkins",
}


def probe(host):
    url = host if host.startswith("http") else f"https://{host}"
    r = urllib.request.Request(url, headers={"User-Agent": UA})
    out = {"host": host, "url": url, "status": None, "len": 0, "title": "", "server": "", "tech": []}
    try:
        with urllib.request.urlopen(r, timeout=12) as resp:
            body = resp.read(200_000).decode("utf-8", "replace")
            out.update(status=resp.status, len=len(body), server=resp.headers.get("server", ""))
            m = TITLE.search(body)
            out["title"] = (m.group(1).strip()[:120] if m else "")
            blob = (body.lower()[:50_000] + str(resp.headers).lower())
            out["tech"] = [v for k, v in TECH.items() if k in blob]
    except urllib.error.HTTPError as e:
        out["status"] = e.code
        out["server"] = e.headers.get("server", "")
    except Exception as e:
        out["status"] = type(e).__name__
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("hosts")
    p.add_argument("-c", "--concurrency", type=int, default=15)
    p.add_argument("--json")
    a = p.parse_args()

    hosts = [l.strip() for l in open(a.hosts, encoding="utf-8") if l.strip() and not l.startswith("#")]
    rows = []
    with cf.ThreadPoolExecutor(max_workers=a.concurrency) as ex:
        for row in ex.map(probe, hosts):
            rows.append(row)
            print(f"{str(row['status']):>4} {row['len']:>7} {row['host'][:60]:<60} {row['title'][:40]}")

    if a.json:
        json.dump(rows, open(a.json, "w", encoding="utf-8"), indent=2)
    print(f"\n{len(rows)} hosts. interesting = 200/401/403 with a title or a tech hint.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
