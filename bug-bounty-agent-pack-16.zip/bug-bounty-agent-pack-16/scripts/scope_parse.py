#!/usr/bin/env python3
"""Parse a pasted program brief into state/scope.json. Heuristic, then human-reviewed.

    python scripts/scope_parse.py brief.txt -o state/scope.json
"""
import argparse
import json
import re
import sys

ASSET = re.compile(r"\b((?:[a-z0-9*][a-z0-9*\-.]*\.)+[a-z]{2,}|https?://\S+|\d+\.\d+\.\d+\.\d+(?:/\d+)?)\b", re.I)
SECTION = re.compile(r"^\s*(in[- ]scope|out[- ]of[- ]scope|rules?|prohibited|rate limit)\s*:?\s*$", re.I)


def classify(line):
    low = line.lower()
    if "android" in low or "ios" in low or ".apk" in low or ".ipa" in low:
        return "mobile"
    if low.startswith("http"):
        return "web"
    if "/" in line and re.match(r"^\d+\.\d+\.\d+\.\d+/\d+", line.strip()):
        return "cidr"
    if "github.com" in low or "gitlab.com" in low:
        return "repo"
    return "host"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("brief")
    p.add_argument("-o", "--out", default="state/scope.json")
    p.add_argument("--program", default="")
    a = p.parse_args()

    scope = {"program": a.program, "platform": "", "in_scope": [], "out_of_scope": [],
             "rules": {"rate_limit": "", "accounts": "", "prohibited": [], "wildcard": False},
             "rewards": {"min": 0, "max": 0, "currency": ""}, "deadline": ""}

    current = "in_scope"
    for raw in open(a.brief, encoding="utf-8", errors="replace"):
        line = raw.strip()
        if not line:
            continue
        m = SECTION.match(line)
        if m:
            tag = m.group(1).lower()
            current = "out_of_scope" if "out" in tag else ("in_scope" if "in" in tag else current)
            continue
        if current == "out_of_scope":
            for hit in ASSET.findall(line):
                scope["out_of_scope"].append({"asset": hit.rstrip(".,)"), "notes": ""})
            continue
        for hit in ASSET.findall(line):
            scope["in_scope"].append({"asset": hit.rstrip(".,)"), "type": classify(hit), "notes": ""})
        if "wildcard" in line.lower() or line.strip().startswith("*."):
            scope["rules"]["wildcard"] = True
        if "rate limit" in line.lower():
            scope["rules"]["rate_limit"] = line

    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(scope, f, indent=2)
    print(f"in={len(scope['in_scope'])} out={len(scope['out_of_scope'])} -> {a.out}")
    print("REVIEW BY HAND before hunting. Heuristics mislabel.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
