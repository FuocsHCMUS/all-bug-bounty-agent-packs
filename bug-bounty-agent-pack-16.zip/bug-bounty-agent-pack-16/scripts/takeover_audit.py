#!/usr/bin/env python3
"""Dangling-CNAME subdomain takeover triage. Heuristic: dangling target + provider fingerprint."""
import argparse
import re
import socket
import sys

PROVIDERS = {
    "amazonaws.com": ["NoSuchBucket", "does not exist"],
    "github.io": ["There isn't a GitHub Pages site here"],
    "herokuapp.com": ["No such app", "heroku | no such app"],
    "azurewebsites.net": ["404 Web Site not found"],
    "cloudapp.azure.com": ["404"],
    "netlify.app": ["Not Found - Request ID"],
    "surge.sh": ["project not found"],
    "readme.io": ["Project doesnt exist"],
    "zendesk.com": ["Help Center Closed"],
    "shopify.com": ["Sorry, this shop is currently unavailable"],
    "fastly.net": ["Fastly error: unknown domain"],
}


def cname(host):
    try:
        return socket.gethostbyname_ex(host)[0]
    except Exception:
        return ""


def main():
    p = argparse.ArgumentParser()
    p.add_argument("hosts")
    a = p.parse_args()

    hits = 0
    for host in (l.strip() for l in open(a.hosts, encoding="utf-8") if l.strip()):
        cn = cname(host)
        for prov, sigs in PROVIDERS.items():
            if prov in cn:
                print(f"{host} -> {cn}  [provider {prov}] — check signature manually, then claim")
                hits += 1
                break
    print(f"\n{hits} provider-pointing candidate(s).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
