# Skill: API and GraphQL hunting

APIs lie about their own contract. The schema says one thing, the binder does another.

---

## 1. Contract discovery

- OpenAPI/Swagger at common paths; then diff the documented fields against what the binder accepts
- Postman collections, SDKs, and client apps as the real contract
- GraphQL introspection (disable-check first, then field-suggestion brute force via `Did you mean`)
- `OPTIONS` and `Allow` headers, then method substitution
- Version archaeology: `/v1/` beside `/v2/`, deprecated endpoints still live and unpatched
- Shadow fields: documented `email`, undocumented `email_verified`, `role`, `tenant_id`, `is_admin`

## 2. Mass assignment

Add fields the UI never sends: `role`, `is_admin`, `verified`, `plan`, `credits`, `tenant_id`,
`permissions[]`, `created_at`, `id`. Nested object depth matters — a nested `profile.role` is often
bound by a different, lazier serialiser.

## 3. BOLA / IDOR

The number one API bug. Two accounts, swap every identifier.

- sequential integers, UUIDv1 (time-ordered), short hashes, base64 of `type:id`
- identifiers in path, query, body, header, and GraphQL variables
- nested resource paths where only the parent is checked: `/org/{a}/members/{b}`
- batch endpoints: `ids=1,2,3` where only the first is authorised
- GraphQL node lookups by global id

## 4. GraphQL specifics

- introspection -> full type map -> every mutation with every argument
- field-level authz: query a field the UI hides (`User.password_hash`, `InternalNote`)
- alias-based batching to bypass rate limits and race state
- nested depth and recursive fragments for DoS
- `@include`/`@skip` on auth-relevant fields
- subscription auth: does the WS handshake check the same claims as HTTP
- mutation over GET if enabled
- error verbosity: `errors[].extensions.exception.stacktrace`

## 5. Auth model probing

- token in query string accepted where header expected
- `X-HTTP-Method-Override`, `_method=`
- JWT: `alg:none`, HS/RS confusion, `kid` traversal, weak HMAC secret, no `exp` enforcement,
  `aud`/`iss` unchecked, `jku`/`x5u` pointing at your host
- OAuth: `redirect_uri` path confusion, `state` missing, implicit flow, PKCE downgrade, scope upgrade
- API keys in URLs, in logs, in error traces, in mobile binaries

## 6. Rate and quota

- per-endpoint vs per-account limits; header-only enforcement
- `X-Forwarded-For` rotation
- batching as a multiplier
- cost analysis on GraphQL: one query, huge work

## 7. Rules

- Two identities minimum, for every single endpoint.
- Documented field list is a floor, never a ceiling.
- Version diff: a fix in v2 is a hint at the bug in v1.
