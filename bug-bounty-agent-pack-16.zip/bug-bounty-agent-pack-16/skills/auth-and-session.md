# Skill: auth, session, identity

Identity is the highest-value boundary. Most criticals live here.

---

## 1. Session mechanics

- Where is the session? cookie, header, JWT, signed URL, device fingerprint
- Flags: `HttpOnly`, `Secure`, `SameSite`, `Path`, `Domain`. A wide `Domain` is a subdomain-takeover chain.
- Rotation on login, on privilege change, on logout. No rotation = fixation.
- Logout actually invalidates server-side, or only clears the cookie
- Concurrent sessions, session listing, remote revoke
- Cookie tossing from a sibling subdomain
- Session lifetime and idle timeout

## 2. Password and recovery

- reset token: length, entropy, predictability, expiry, single-use, bound to user, bound to email
- host header injection into reset links
- reset token leak via Referer
- email change without re-auth
- MFA: bypass by response manipulation, by code reuse, by missing rate limit, by backup-code path,
  by "remember this device" cookie, by switching to a weaker second factor
- MFA enrollment on an already-compromised session
- password policy bypass via API (no policy on the API path)

## 3. OAuth / OIDC

- `redirect_uri`: path traversal, suffix match, subdomain of a registered host, `@` tricks, open
  redirect on the client, localhost wildcard, `redirect_uri` case sensitivity
- missing or unvalidated `state` -> login CSRF / account linking
- code reuse, code in Referer, long-lived code
- implicit flow token in fragment
- scope upgrade on refresh, refresh token rotation absent
- `id_token` `aud`/`azp` confusion, `email_verified` trust, `nonce` missing
- account linking by unverified email -> pre-hijack
- pre-registration takeover: register with victim email before they sign up via SSO

## 4. JWT deep

- `alg: none` variants, case (`None`, `NONE`)
- HS256 signed with the RSA public key
- `kid` path traversal and SQL injection
- `jku`/`x5u` -> host your own JWKS
- `jwk` header embedded key trust
- claim confusion: `sub` vs `user_id`, `role` array vs string
- missing `exp`/`nbf` enforcement, clock skew abuse
- `aud` list vs string
- weak secret: `hashcat -m 16500`

## 5. Access control models

- vertical: user -> admin, support -> superadmin
- horizontal: tenant A -> tenant B
- context: org member -> org owner
- inherited: project role -> workspace role
- implicit: `X-Org-Id` header trusted over the session
- forced browsing to admin routes; route guards are client-side only
- HTTP method downgrade: `POST` guarded, `PUT`/`PATCH` not
- batch/export endpoints with weaker checks than detail endpoints

## 6. Rules

- Always test with the *real* second account, never a modified token alone.
- Test after logout. Test after role change. Test after email change.
- Test the API path even when the UI blocks it.
- A 403 that differs in body or timing between existing and non-existing resources is a leak.
