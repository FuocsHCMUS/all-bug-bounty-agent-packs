# Skill: cloud and infrastructure

Misconfiguration is the default state. Version is the vulnerability.

---

## 1. Buckets and storage

- permutations: `target`, `target-dev`, `target-backup`, `target-assets`, `target-prod`, `target-logs`
- `s3.amazonaws.com/<bucket>`, `/<bucket>.s3.amazonaws.com`, regional endpoints
- `storage.googleapis.com/<bucket>`, `<bucket>.blob.core.windows.net`
- list, read, write, ACL read, website index, versioning
- read the `x-amz-` headers on every response for the account id
- signed URL params: expiry, `IP` binding, path scope

## 2. SSRF to metadata

- `169.254.169.254/latest/meta-data/`, `iam/security-credentials/`
- IMDSv1 vs v2: v2 needs `X-aws-ec2-metadata-token`, so check whether the fetcher forwards headers
- GCP: `metadata.google.internal/computeMetadata/v1/` with `Metadata-Flavor: Google`
- Azure: `169.254.169.254/metadata/instance?api-version=...` with `Metadata: true`
- redirect to metadata, DNS rebinding to bypass allowlists, `0.0.0.0`, `[::]`, decimal IP, octal IP
- protocol smuggling: `gopher://`, `dict://`, `file://`, `ftp://`, `ldap://`
- CRLF in the URL to inject a second request into the inner HTTP client

## 3. Infrastructure exposure

- Kubernetes: `:10250` kubelet, `:10255` read-only, `/pods`, `/metrics`, anonymous auth, dashboard
- Docker API `:2375`/`:2376`
- Jenkins `/script`, `/manage`, `/asynchPeople`
- Grafana, Prometheus `/targets`, Kibana, RabbitMQ, Elasticsearch `/_cat/indices`
- Consul, etcd, Nomad
- `.git/config`, `.env`, `docker-compose.yml`, `terraform.tfstate`, `id_rsa`
- `/.well-known/` oddities, `/server-status`, `/nginx_status`

## 4. Subdomain takeover

- dangling CNAME to S3, GitHub Pages, Heroku, Azure, Fastly, Shopify, Zendesk, Surge, Netlify
- verify by the provider's unclaimed-resource error page, then actually claim it
- NS delegation to a dead provider
- MX to a dead host
- cookie `Domain=.target.com` + takeover = session theft from the parent

## 5. TLS and DNS

- expired, self-signed, wrong-hostname, wildcard misissue
- SANs revealing internal names
- zone transfer, NSEC walking, `ANY` queries
- dangling records, CAA absence, DMARC `p=none`

## 6. Rules

- Read-only first: list before you write.
- Metadata before RCE. Credentials before shells.
- Always screenshot the provider's "unclaimed" page as takeover proof.
