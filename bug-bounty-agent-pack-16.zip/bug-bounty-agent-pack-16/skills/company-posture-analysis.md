# Skill: company security posture analysis

The finding is one instance. The posture is the pattern. Analyse the pattern.

---

## 1. Purpose

For the user: a real, structured read on how a company does security, so they learn what good and bad
look like in practice. For the company: actionable, non-hostile signal beyond the single bug.

Write to `notes/company/<slug>/posture.md`. One file per company, appended across engagements.

## 2. The eight axes

Rate each `strong` / `adequate` / `thin` / `absent` / `unknown`. Evidence required for every rating — a
rating without evidence is `unknown`.

1. **Asset inventory & exposure** — do they know what they own? Shadow IT, dangling records, staging in
   production DNS, forgotten panels.
2. **Identity & access control** — centralised authz, tenant isolation, role model, session lifecycle,
   MFA coverage.
3. **Input handling & framework hygiene** — validation layer, binder consistency, output encoding,
   dependency currency.
4. **Cryptography & secrets** — TLS config, key management, secret sprawl in JS/binaries/repos, JWT
   design.
5. **Logging, detection & response** — can they see it? Alert latency, whether your noise triggered
   anything, `security.txt`, bug bounty responsiveness.
6. **SDLC & release engineering** — patch cadence, changelog transparency, canary and rollback, whether
   fixes are class-wide or instance-only.
7. **Cloud & infrastructure configuration** — metadata hardening, bucket policy, network segmentation,
   IaC.
8. **Disclosure & communication** — scope clarity, triage speed, remediation follow-through, whether
   they credit researchers.

## 3. Root cause analysis

For each finding, walk down:

symptom -> proximate cause -> design cause -> process cause -> organisational cause.

Stop when the next step would be speculation, and say where you stopped. The process cause is the
useful one for the student; the organisational cause is the useful one for the company.

## 4. What good looks like

Always name at least two things they do well, specifically. "Good TLS" is not specific. "HSTS preload
with a 2-year max-age across all apex and www hosts, and no mixed content in the checkout flow" is.

## 5. Risk framing

Per axis: what is exposed today, what a single additional bug would unlock, and the realistic worst
case at their scale. Separate *current risk* from *latent risk*.

## 6. Deliverable shape

- Executive read: five lines, no jargon
- Axis table with ratings and evidence
- Findings mapped to axes
- Root cause chains
- Prioritised improvement list, effort-tagged
- What they do well
- Open questions for the next engagement

## 7. Rules

- Fair, not flattering, not hostile.
- Evidence per rating or the rating is `unknown`.
- Never invent an internal process you cannot see — mark inference as inference.
