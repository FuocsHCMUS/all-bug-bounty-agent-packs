# Skill: mobile and thick clients

The client ships the secrets. The server trusts the client.

---

## 1. Acquisition

- APK from Play/APKMirror; IPA via Apple Configurator or a decrypted store
- `apktool d`, `jadx -d`, `unzip` for assets and native libs
- Electron: `app.asar` -> `asar extract`
- Thick client: strings, resource extraction, `.NET` decompile, `monodis`

## 2. What to grep for

- API base URLs, staging hosts, internal hostnames
- hardcoded keys, HMAC secrets, signing salts, `Bearer` literals
- Firebase URLs and rules, S3 bucket names, Twilio/Stripe/SendGrid keys
- certificate pinning config, root detection logic, `Debug.isDebuggerConnected`
- deep link schemes and their handlers
- WebView settings: `setJavaScriptEnabled`, `addJavascriptInterface`, `setAllowFileAccess`
- exported components in `AndroidManifest.xml`: activities, services, receivers, providers
- `content://` providers with path traversal
- iOS URL schemes, universal links, `WKWebView` message handlers

## 3. Traffic

- system proxy + user CA, then bypass pinning (Frida script or a repackaged APK)
- if the app trusts user CAs on API 24+, proxy works out of the box
- certificate transparency for the mobile API hosts
- replay captured mobile requests against the web API — mobile often hits a weaker, unrate-limited path
- version header pinning: old app versions often still work

## 4. Client-side trust

- server accepts client-computed values: price, discount, role, tier, signature
- signature computed over a subset of fields (field injection)
- offline mode queues writes that are replayed without revalidation
- deep link -> authenticated WebView -> token in URL
- `javascript:` in a deep link parameter

## 5. Rules

- Mobile is a shortcut to the API, not a separate target.
- Decompile before you proxy.
- Old versions in the wild are unpatched by definition.
