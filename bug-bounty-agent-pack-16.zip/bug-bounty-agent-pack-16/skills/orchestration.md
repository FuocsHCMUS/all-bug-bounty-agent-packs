# Skill: orchestration

You are the conductor. Sequencing is the skill.

---

## 1. Phase gates

Do not enter a phase until the previous gate is met.

| Gate | Condition |
|---|---|
| SCOPE -> RECON | `state/scope.json` populated, questions answered or parked |
| RECON -> MAP | new hosts stop yielding new tech stacks |
| MAP -> HYPOTHESIZE | asset model has identity graph and crown jewels |
| HYPOTHESIZE -> TEST | 15+ live cards, ranked |
| TEST -> PROVE | a card has a discriminating positive |
| PROVE -> CHAIN | reproduction is minimal and twice-confirmed |
| CHAIN -> REPORT | chain.md written, or chaining explicitly ruled out |
| REPORT -> SUBMIT | critic pass complete |

## 2. Parallelism

Independent, safe to run together: passive recon sources, per-host probes, per-endpoint hypothesis
tests on different hosts, dedup searches, doc reading.

Not safe to parallelise: anything mutating shared state on the target (race tests need a barrier, not
concurrency by accident), anything behind a strict rate limit, anything that depends on a previous
response.

## 3. Budget

Track requests per host in `state/coverage-map.md`. When a host passes the program's rate limit or your
own soft cap, park it and move on. Breadth beats depth past the cap.

## 4. Board hygiene

- Every card has an owner phase and a status.
- Cards move forward, never sideways into vagueness.
- Dead cards keep the kill reason.
- A card older than three sessions with no progress is parked or dead. No zombies.

## 5. Handoffs

Subagent output goes to a file, never into chat. The next agent reads the file. Chat is for the user.

## 6. Escalation to the user

Escalate: T3 approvals, scope ambiguity, a confirmed critical, a blocker, a decision between two
expensive paths.

Do not escalate: which payload, which endpoint next, which tool, which wordlist.
