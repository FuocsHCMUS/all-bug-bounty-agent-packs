# Skill: deep recon

Breadth first, then depth on the interesting 5%.

---

## 1. Passive

- CT logs: crt.sh, certspotter, `curl 'https://crt.sh/?q=%25.target.com&output=json'` -> SANs
- DNS history: SecurityTrails, ViewDNS, `dnsdumpster`
- `amass enum -passive -d target.com`
- GitHub: org repos, `org:target "api_key"`, commit history for scrubbed secrets, CI configs, IaC
- Public JS from CDN builds and source maps; Wayback for old bundles
- Job posts (stack), status pages (subdomains), `security.txt`, docs and help portals
- Shodan/Censys for cert and favicon fingerprints
- Mobile app store listings, decompiled APK strings

Record every host with its source. Sources tell you how the program thinks about exposure.

## 2. Active

- Resolve, then probe with `httpx -tech-detect -status-code -title -favicon -jarm`
- Screenshot before anything changes
- vhost brute force against each IP: `ffuf -H "Host: FUZZ.target.com"`
- TLS SAN enumeration on every live cert
- Directory and file discovery with a tech-matched wordlist, not a generic one
- Parameter mining from archived URLs, JS, and form sources
- S3/GCS/Azure bucket permutations on the org name
- GraphQL endpoint discovery: `/graphql`, `/api/graphql`, `/v1/graphql`, `?query=`

## 3. JS mining

Beautify into `workspace/targets/<slug>/js/`, then:

- endpoint regex: `["'`](/api/[^"'`]+)["'`]`
- keys: `(api[_-]?key|token|secret|bearer)\s*[:=]`
- feature flags and role strings
- internal hostnames, `*.internal`, `*.corp`, staging hosts
- `// TODO`, `FIXME`, `HACK`
- source maps: append `.map`, then recover original paths

Every endpoint found becomes a card, not a note.

## 4. Signals worth chasing

- different Server/tech on the same parent domain
- 401 vs 403 on adjacent paths (existence leak)
- staging, dev, uat, test, qa, old, legacy, beta, admin, internal prefixes
- favicon hash collisions with known products
- `.git/`, `.svn/`, `backup.zip`, `db.sql`, `Dockerfile`, `docker-compose.yml`
- Swagger/OpenAPI at `/swagger-ui.html`, `/openapi.json`, `/api-docs`
- Actuator, `/metrics`, `/health`, `/debug`, `/env`

## 5. Rules

- Depth on 5%, breadth on 95%. Never invert.
- New tech stack = new playbook, not a new scan.
- Log the negative: "no vhosts on 10.0.0.5" is coverage.
