# Skill: report writing

The report is the product. A perfect bug with a bad report pays nothing.

---

## 1. Voice

Past tense for what you did. Present tense for what is broken. No adjectives without content. No
"it is recommended that" — write "fix X by Y". No apologies, no hedging, no narrative of your journey.

## 2. Structure

Use `templates/report-bugcrowd.md` or `templates/report-hackerone.md`. Never improvise the structure.

1. Title: `Class in Component — one-line consequence`
2. Summary: three sentences. What, where, so what. A PM must understand it.
3. Steps: numbered, exact, from a clean state, with the account roles named
4. Evidence: raw request/response pairs, artifacts
5. Impact: attacker sentence, blast radius, scale, preconditions
6. Root cause: the code or design reason, as specific as you can be
7. Remediation: the fix, plus the class-wide fix
8. Chain: what this unlocks
9. Notes: limits, untested edges, environment

## 3. Impact writing

Template: "An attacker with <position> can <action>, which yields <outcome> for <population>, without
<the control that should stop them>."

Fill it. If a slot is weak, the severity drops. Then quantify: how many records, how many tenants, how
fast, how silently.

## 4. Severity calibration

Anchor to the program's taxonomy. Then sanity-check against the reward table — if the table pays $300
for it, do not argue critical without a chain.

Write the CVSS vector only when the program asks, and only after the impact sentence exists.

## 5. Remediation quality

Three levels, always:
- **Immediate**: the smallest change that kills this instance
- **Class**: the systemic fix (central authorisation layer, shared binder validation, framework upgrade)
- **Detection**: what to log or alert on to catch the next instance

## 6. Title patterns that work

- `IDOR in /v2/invoices allows cross-tenant invoice read`
- `SSRF via webhook URL reaches EC2 metadata, yields role credentials`
- `Stored XSS in support macros executes in admin context`
- `OAuth redirect_uri suffix match enables code theft and ATO`

Bad: `XSS found`, `Security issue in API`, `Possible SSRF`.

## 7. Rules

- Every claim in the report must be backed by a step.
- Screenshots supplement raw bytes; they never replace them.
- Redact only real secrets, and say you redacted them.
- Read it once as a triager who wants to close it. Fix what they would attack.
