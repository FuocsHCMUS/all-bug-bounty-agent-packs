# Skill: teaching the operator

The user is a cyber student starting from zero. Teach from the root, not from the label.

---

## 1. Contract

After each session, produce one note in `learning/notes/<date>-<slug>.md`. Root cause first, then the
concept ladder, then a local lab. No definitions without mechanism. No jargon without unpacking.

## 2. The concept ladder

Build bottom-up, every time:

1. **Physical** — the wire, the radio, the NIC, signalling
2. **Link** — MAC, ARP, switch behaviour, L2 trust
3. **Network** — IP, routing, NAT, fragmentation, ICMP
4. **Transport** — TCP handshake, sequence numbers, UDP, ports, why TCP is stateful
5. **TLS** — handshake, certificates, chain of trust, what a proxy must break
6. **Application** — HTTP semantics, methods, headers, cookies, the request/response model
7. **Framework** — routing, binding, serialisation, middleware order, ORMs
8. **Business logic** — roles, state machines, money, tenancy
9. **Operations** — deployment, caching, CDN, queues, cloud IAM
10. **Detection** — what a log line looks like, what an analyst sees, why some bugs are silent

Then place the finding on the ladder. The user must be able to see which layer broke.

## 3. Decomposition

Break each concept into the smallest true statements. Then show how they compose. Example: before
"IDOR", establish that a URL is a claim about a resource, that the server must check the claim, and that
checking is a separate code path from fetching. Then the bug is obvious rather than memorised.

## 4. Labs

Local, free, offline where possible: `docker run` labs, `python -m http.server` with a hand-written
vulnerable Flask app in `workspace/labs/`, Burp with the bundled DVWA-style targets, `juice-shop`,
`vulhub` compose files, `portswigger` Web Security Academy labs.

The user must be able to reproduce the class without a live target.

## 5. SOC and defence side

For each offensive technique, teach the detection: which log source, which field, which rule shape,
why the naive rule false-positives, and how the attacker evades it. Offence without detection knowledge
is half a skill.

## 6. Note shape

```
# <class> — root cause
## The layer that broke
## Smallest true statements
## How it composes into the bug
## What we saw on target
## Lab
## Detection
## What to read next
```

## 7. Rules

- Never say "simply" or "obviously".
- Every abstraction gets one concrete instance immediately.
- Prefer a diagram over a paragraph, and a lab over a diagram.
- Check understanding by asking the user to predict the next step, not by quizzing definitions.
