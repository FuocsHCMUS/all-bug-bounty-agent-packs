# Skill: technique synthesis

Recall finds the known. Derivation finds the bounty. Run this on every anomaly.

---

## 1. The premise

Every bug is a broken assumption. The assumptions are visible if you read the behaviour mechanically
instead of matching it against a payload list. Payload lists are other people's assumptions about
other people's code.

## 2. Procedure

**Step 1 — Describe the deviation.**
Exactly what happened, in terms of bytes and state. "The endpoint returned 200 with an empty body when
the ID was `0`" not "looks weird".

**Step 2 — Enumerate the developer's assumptions.**
For that to happen, they must have believed: the ID is always positive; the ID is always numeric; the
record always exists; the client always sends it; the proxy always normalises it; the ORM always binds
it as a string. List at least five. Write them down.

**Step 3 — Pick the cheapest to break.**
Cost = requests + accounts + knowledge. The assumption that costs one request wins.

**Step 4 — Generate three mutations.**
One **semantic** (breaks the meaning: `-1`, `0`, `1e3`, `true`, `null`), one **structural** (breaks the
shape: array, object, nested, duplicate key, empty), one **encoding** (breaks the parse: overlong,
UTF-16, `%00`, case, unicode homoglyph, chunked). Always all three — the point is coverage of the
parser space, not a lucky guess.

**Step 5 — Run all three.** Record what each produced. Even all-negative results are a card.

## 3. Divergence hunting

The highest-yield synthesis source is disagreement between two components. Probe systematically:

- send a request that both a proxy and an origin must parse, and vary one parse-relevant byte
- compare what the WAF allows vs what the origin accepts
- compare the mobile binder vs the web binder for the same endpoint
- compare `PUT` vs `POST` vs `PATCH` validation on the same object
- compare the documented schema vs the accepted schema

Where they disagree, a request exists that means two things. That is a bug.

## 4. Generalisation

After a hit, ask:

- Which other endpoints share this parser? (grep the JS, the schema, the route table)
- Which other roles reach the same code?
- Which other content types does the same binder handle?
- Does the primitive compose with something already on the board?

Then promote it: write a technique card and, if it generalises, add a `SOURCE:`-tagged entry to the
right `playbooks/` file.

## 5. Technique card format

`skills/techniques/T-###.md`:

```
class:
asset:
mechanism: <why it works, mechanically>
input: <the exact bytes>
result: <observed>
novelty: known / variant / new
generalises-to: <other endpoints or parsers>
next-mutation: <what to try next>
```

## 6. Discipline

- Novel does not mean good. A clever bug with no impact is still informational.
- Always check whether it is already public before claiming novelty.
- A failed mutation is a data point, not a wasted request.
