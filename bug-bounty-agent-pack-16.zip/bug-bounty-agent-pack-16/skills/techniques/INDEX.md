# Technique index

Grouped by the boundary that breaks. Grep this before inventing from scratch.

## Path and routing normalisation
## Query and body binding
## Content-type and charset
## Auth and token parsing
## Cache key construction
## Template engines
## Serialisation formats
## File handling and archives
## Cloud metadata and network fetchers
## DNS and delegation
## Client-side sinks
