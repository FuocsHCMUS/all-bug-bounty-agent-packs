# Skill: triage and dedup

Assume it is already reported. Prove otherwise before you write.

---

## 1. Dedup sources

- program's disclosed report list and hacktivity
- `site:hackerone.com "<target>"`, `site:bugcrowd.com "<target>"`
- the target's changelog, security page, and release notes
- GitHub issues and PRs on the target's repos
- public writeups, YouTube, conference archives
- CT log dates — a new host is less likely to be covered

## 2. Novelty test

1. Search the exact endpoint and parameter.
2. Search the class plus the product.
3. Check whether the behaviour is documented as intended.
4. Check the changelog for a recent fix in this area — if fixed, the bug is a regression, which is
   still valid but needs the regression angle.

If you find a matching report, keep going: your version is a variant, an escalation, or a chain. Note
the difference explicitly in the report.

## 3. Duplicate handling

- Never abandon a dup — escalate it. Add a chain step the original lacks.
- If truly identical, file it anyway with the new detail; partial credit and reputation exist.
- Record dups in `notes/dups.md` with the original link, so future sessions skip it.

## 4. Pre-submission gate

- [ ] reproduced twice, two accounts or two sessions
- [ ] impact sentence written
- [ ] dedup searches done, results noted
- [ ] critic pass complete, all points answered
- [ ] out-of-scope components confirmed in scope
- [ ] third-party data redacted
- [ ] repro script runs from clean state on a fresh shell

## 5. Rules

- A dup filed with a chain is worth more than a novel informational.
- Do not pad. Triagers notice.
