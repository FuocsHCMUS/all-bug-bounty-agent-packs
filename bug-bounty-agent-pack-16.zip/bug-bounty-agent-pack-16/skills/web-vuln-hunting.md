# Skill: web application hunting

The parser is the attack surface. Every input crosses a boundary between two components that disagree.

---

## 1. Where to look first

- Anything that reflects input into HTML, attribute, JS, or a template
- Anything that builds a query, a path, a command, or a URL from input
- Anything that deserialises, imports, or evaluates
- Anything that renders a document (PDF, CSV, image, office file)
- Anything with a file parameter
- Anything with a `url=`, `next=`, `callback=`, `redirect=`, `webhook=`, `feed=`, `import=`
- Rich text, markdown, and WYSIWYG editors
- Bulk import, CSV upload, and anything "export"

## 2. Parser disagreement

Two parsers, one string. Find where they diverge.

- path normalisation: `/a/../b`, `/a/%2e%2e/b`, `/a/..;/b`, `/a/.%2e/b`, backslash on Windows stacks
- trailing dot, space, slash, `%00`, `%09`, `%0d%0a`
- case: `Content-Type: Application/JSON`, `Bearer` vs `bearer`, header name casing
- duplicate keys: `{"a":1,"a":2}`, `?a=1&a=2`, duplicate `Content-Length`
- type juggling: `"1"` vs `1`, `[1]` vs `1`, `{"0":...}`, `true` vs `"true"`
- encoding: UTF-16, overlong UTF-8, `\u0000`, HTML entities, double URL-encoding
- whitespace: leading/trailing, tab vs space, non-breaking space in numbers
- charset parameters, multipart boundaries with quotes, `filename*=` vs `filename=`

Differential behaviour between the front proxy and the backend is a finding by itself.

## 3. Injection

**SQL** — boolean and time differentials, `ORDER BY` position, `LIMIT` in Postgres, `--` vs `#` comments,
stacked queries only where the driver allows, second-order via stored values, `LIKE` wildcard abuse.
Always test the same param in a header and in a cookie.

**NoSQL** — `{"$ne":null}`, `{"$gt":""}`, `{"$regex":"^a"}`, `$where`, array injection where the
framework coerces, `$in` with a nested object.

**Command** — `;`, `|`, `&&`, `$( )`, backtick, newline, `%0a` in a header value, argument injection
(`--foo=`), wildcard expansion, `-` prefix swallowing.

**Template (SSTI)** — arithmetic probe `{{7*7}}`, `${7*7}`, `<%= 7*7 %>`, `#{7*7}`, then engine-specific
escaping to reach the object tree. Blind via timing with a large loop.

**LDAP/XPath** — `*)(|(cn=*`, `') or '1'='1`, wildcard behaviour on user enumeration.

**Expression/EL** — `@`, `T()`, `Runtime`, `getClass()`, bean access.

## 4. Client side

- XSS: context is everything. HTML body, attribute, JS string, JS template, URL, CSS, SVG, markdown,
  JSON embedded in script. Match the escape, not the payload.
- DOM XSS: trace `location.*` into `innerHTML`, `eval`, `document.write`, `jQuery.html`,
  `postMessage` handlers without origin checks.
- Prototype pollution: `__proto__`, `constructor[prototype]`, then a gadget that reads the polluted key.
- CSRF: token presence is not protection. Check whether the token is bound to the session, whether it
  is validated on all verbs, whether JSON-only endpoints still accept form posts.
- Clickjacking on anything that changes state and lacks frame-ancestors.
- postMessage with `targetOrigin: "*"` carrying tokens.

## 5. Files

- extension and MIME mismatch, `Content-Type` trust, magic-byte vs extension
- path traversal in filename, in the storage key, in the extraction path
- zip-slip and archive bomb on any "import archive"
- SVG with script, XXE in SVG, XXE in DOCX/XLSX
- polyglot: valid image + valid HTML/PHP/JS
- served-from-same-origin uploads = XSS; served from CDN = usually nothing
- overwrite via predictable storage keys, then a second upload to a shared namespace

## 6. Rules

- Baseline, one mutation, diff. Always.
- Content-type swap before payload escalation.
- If it renders, test every context separately.
- If it stores, test second-order.
- If it parses, feed it malformed structure, not just malicious content.
