# Skill: writeup and CTF ingestion

Read to extract mechanisms, not to copy payloads.

---

## 1. Sources

HackerOne hacktivity and disclosed reports, Bugcrowd disclosures, `pentester.land` weekly, CTF writeup
aggregators, team blogs, conference slides, exploit-db, PoC repos, RFCs and errata, parser source code,
patch commits.

## 2. Extraction protocol

For each writeup, answer:

1. What was the broken assumption?
2. Which parser or component was the boundary?
3. What signal did the author notice first?
4. What was the minimal input?
5. Why did normal defences miss it?
6. What is the generalisable shape, stripped of the target's specifics?

Then write a technique card. A writeup that produces no card was read wrong.

## 3. De-abstraction

Take the shape and re-apply it:

- same parser class, different product
- same signal, different endpoint
- same broken assumption, different feature

Store the abstracted form, not the payload. `{{7*7}}` is not knowledge; "arithmetic probe for template
engines, then engine-specific escape" is.

## 4. CTF vs production

CTF techniques often need adaptation:

- no WAF in the CTF, one in production -> encoding and chunking
- CTF flag is a file, production impact is data -> impact rewrite
- CTF allows noise, production has rate limits -> batching and patience
- CTF source is given, production needs fingerprinting -> version matching first

Note the adaptation in the card. That is the actual skill.

## 5. Corpus discipline

`skills/techniques/` grows. Keep an index in `skills/techniques/INDEX.md` sorted by parser class, so a
future session can grep by boundary rather than by product name.

## 6. Rules

- One writeup, one card, minimum.
- Strip the target's names from the card body.
- Cite the source URL in the card.
- Never assume the writeup is correct — re-derive the mechanism.
