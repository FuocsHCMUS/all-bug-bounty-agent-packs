# Asset model

Per asset: purpose, framework, auth model, session mechanism, roles, data owned, data reachable,
upstream deps, trust boundaries crossed, shared-session peers.

## Identity graph
(who mints, who accepts, who shares cookies)

## Crown jewels

## Notes
