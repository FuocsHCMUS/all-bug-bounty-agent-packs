# Blocked

Anything waiting on the user: T3 approvals, missing accounts, ambiguous scope, credentials.

- [ ] item — since — needs
