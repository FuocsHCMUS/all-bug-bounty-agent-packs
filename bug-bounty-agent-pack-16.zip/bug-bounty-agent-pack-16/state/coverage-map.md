# Coverage map

One line per asset. Status: `new` / `mapped` / `testing` / `covered` / `parked`.

| asset | scheme | status | tech | auth | why interesting | last touched |
|---|---|---|---|---|---|---|

## Parked with reason

## Out of scope but adjacent
