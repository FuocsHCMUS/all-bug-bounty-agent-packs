# Critique log

One block per reviewed finding. The critic must state: what a triager will attack, and the single
weakest link in the evidence.

## F-###
