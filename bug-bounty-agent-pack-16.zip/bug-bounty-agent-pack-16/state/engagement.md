# Engagement

- program:
- platform:
- mode: (unset — ask, then default HUNT)
- started:
- operator:
- reward range:
- deadline:
- rate limit:

## Scope summary in own words

## QUESTIONS (resolve before deep testing)

## Session log index
