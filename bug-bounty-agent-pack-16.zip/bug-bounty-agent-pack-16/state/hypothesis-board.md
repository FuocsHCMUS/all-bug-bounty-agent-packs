# Hypothesis board

Sections: LIVE / TESTING / CONFIRMED / DEAD / PARKED / CHAINS
Card format is in `AGENTS.md` §8. One card, one hypothesis, one line each field.

## LIVE

## TESTING

## CONFIRMED

## DEAD
(keep the kill reason — dead cards are knowledge)

## PARKED

## CHAINS
