# <class> — root cause

## The layer that broke

## Smallest true statements

## How it composes into the bug

## What we saw on target

## Lab

## Detection

## What to read next
