# Security posture — <company> (<slug>)

Engagement: <date> — <program>
Findings reviewed: <count by severity>

## Executive read

<Five lines, no jargon.>

## Axis ratings

| # | Axis | Rating | Evidence |
|---|---|---|---|
| 1 | Asset inventory & exposure | | |
| 2 | Identity & access control | | |
| 3 | Input handling & framework hygiene | | |
| 4 | Cryptography & secrets | | |
| 5 | Logging, detection & response | | |
| 6 | SDLC & release engineering | | |
| 7 | Cloud & infrastructure configuration | | |
| 8 | Disclosure & communication | | |

## Findings mapped to axes

## Root cause chains

## Current risk vs latent risk

## Prioritised improvements

| Priority | Change | Effort | Axis |
|---|---|---|---|

## What they do well

## Open questions for next engagement
