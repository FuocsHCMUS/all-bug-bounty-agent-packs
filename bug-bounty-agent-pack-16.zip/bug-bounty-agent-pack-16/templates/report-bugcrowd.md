# VRT: <vulnerability rating taxonomy path>

## Title
<Class in Component — one-line consequence>

## Description

<Three sentences. What, where, so what.>

## Affected endpoints

```
<METHOD> <path>?<param>
```

## Reproduction

```
1.
2.
3.
```

## Raw evidence

```
<request / response pairs>
```

## Impact

<Attacker sentence + blast radius + scale.>

## Severity justification

<Why this VRT and this priority. Anchor to the program taxonomy.>

## Root cause and fix

Root cause:
Immediate fix:
Class fix:

## Chain potential

## Attachments

## Researcher notes
