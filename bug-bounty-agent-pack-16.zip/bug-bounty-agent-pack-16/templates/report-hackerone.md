# <Class> in <Component> — <one-line consequence>

## Summary

<Three sentences: what is broken, where, and what it yields. A PM must understand it.>

## Affected asset

- Host:
- Endpoint:
- Method:
- Parameter:
- Role required:

## Steps to reproduce

1.
2.
3.

## Evidence

```
<raw request>
```
```
<raw response>
```

Artifacts: `artifacts/`

## Impact

An attacker with <position> can <action>, which yields <outcome> for <population>, without <control>.

Blast radius:
Scale:
Preconditions:
Silent or noisy:

## Root cause

<Code or design level. Be specific.>

## Remediation

Immediate:
Class-wide:
Detection:

## Chain

<What this unlocks, or "none identified".>

## Notes

<Limits, untested edges, redactions.>
