#!/usr/bin/env python3
"""Reproduction skeleton. Fill the TODOs, keep it dependency-light.

    python repro.py --target https://api.example.com --user a@x.t --other b@x.t
"""
import argparse
import json
import sys
import urllib.request


def req(url, method="GET", body=None, headers=None, token=None):
    h = {"User-Agent": "venari-repro/1.0", "Accept": "application/json"}
    h.update(headers or {})
    if token:
        h["Authorization"] = f"Bearer {token}"
    data = json.dumps(body).encode() if body is not None else None
    if data:
        h["Content-Type"] = "application/json"
    r = urllib.request.Request(url, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(r, timeout=20) as resp:
            return resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--target", required=True)
    p.add_argument("--user")
    p.add_argument("--other")
    p.add_argument("--token")
    p.add_argument("--other-token")
    a = p.parse_args()

    base = a.target.rstrip("/")

    # STEP 1 — baseline as the owner
    s1, b1 = req(f"{base}/TODO/1", token=a.token)
    print(f"[1] owner  -> {s1} {len(b1)}B")

    # STEP 2 — the mutation
    s2, b2 = req(f"{base}/TODO/1", token=a.other_token)
    print(f"[2] other  -> {s2} {len(b2)}B")

    # STEP 3 — the discriminator
    ok = s2 == 200 and s1 == 200
    print(f"[*] cross-tenant read: {'YES' if ok else 'NO'}")
    if ok:
        print(b2[:400])
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
