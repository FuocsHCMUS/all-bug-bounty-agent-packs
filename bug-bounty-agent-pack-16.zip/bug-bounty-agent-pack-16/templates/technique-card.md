# T-### — <short name>

class:
asset:
mechanism: <why it works, mechanically>
input:
```
<exact bytes>
```
result:
novelty: known / variant / new
generalises-to:
next-mutation:
source:
