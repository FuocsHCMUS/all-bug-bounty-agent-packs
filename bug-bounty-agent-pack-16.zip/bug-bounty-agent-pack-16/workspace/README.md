# workspace

Everything portable lives here. Nothing installs outside this directory without a `CONFIRM:`.

- `tools/` — cloned repos
- `bin/` — standalone binaries
- `wordlists/` — SecLists and payload lists
- `targets/<slug>/` — per-target artefacts, JS, screenshots, captures
- `labs/` — local vulnerable apps for study mode
- `scratch/` — throwaway scripts
- `.venv/` — Python venv; `pip install` freely into it
- `TOOLS.md` — what is installed, version, why, source

```
python -m venv workspace/.venv
workspace\.venv\Scripts\activate
pip install requests httpx beautifulsoup4 dnspython pyjwt
```
