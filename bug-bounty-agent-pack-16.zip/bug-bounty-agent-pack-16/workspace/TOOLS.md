# Installed tooling

| tool | version | why | source | portable? |
|---|---|---|---|---|
