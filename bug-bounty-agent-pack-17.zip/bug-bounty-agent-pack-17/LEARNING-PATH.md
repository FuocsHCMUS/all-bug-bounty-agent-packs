# CYBERSECURITY LEARNING PATH — FROM ZERO TO BUG BOUNTY HUNTER (v17)

Designed for a cybersecurity student building skills from the ground up.

---

## LEVEL 0: FOUNDATIONS

### How the Internet Works
- **IP Addresses:** Every device has a unique address. IPv4 (192.168.1.1) and IPv6.
- **DNS:** Translates names (google.com) to IP addresses. Phone book of the internet.
- **HTTP/HTTPS:** Protocol for browser-server communication. HTTPS adds encryption (TLS/SSL).
- **TCP/IP Model:** Application → Transport → Internet → Network Access.
- **Ports:** Virtual doors. Web = 80 (HTTP), 443 (HTTPS). Total: 65,535.
- **Client-Server:** Browser (client) sends requests → server sends responses.

### How Web Apps Work
- **Frontend:** HTML/CSS/JS — runs in YOUR browser.
- **Backend:** Python/Java/PHP/Node.js — runs on the SERVER.
- **Database:** MySQL/PostgreSQL/MongoDB — stores data.
- **API:** How components talk. REST uses HTTP methods (GET, POST, PUT, DELETE).
- **Cookies/Sessions:** How websites remember you.
- **Authentication** = proving WHO you are. **Authorization** = what you CAN DO.

### CIA Triad
- **Confidentiality:** Only authorized access (encryption, access controls)
- **Integrity:** Data not tampered with (hashing, signatures)
- **Availability:** Systems accessible when needed (redundancy, DDoS protection)

---

## LEVEL 1: NETWORKING & LINUX

- OSI Model (7 layers), TCP/IP Model (4 layers)
- Protocols: HTTP, HTTPS, DNS, FTP, SSH, SMTP, SNMP
- Subnetting, CIDR, NAT, firewalls, proxies
- Wireshark, Linux CLI (cd, ls, grep, awk, curl, wget, nmap)
- **Practice:** TryHackMe, OverTheWire Bandit, Professor Messer Network+

---

## LEVEL 2: WEB SECURITY FUNDAMENTALS

### OWASP Top 10
1. Broken Access Control | 2. Cryptographic Failures | 3. Injection
4. Insecure Design | 5. Security Misconfiguration | 6. Vulnerable Components
7. Auth Failures | 8. Software Integrity Failures | 9. Logging Failures | 10. SSRF

### Practice Platforms
- **PortSwigger Web Security Academy** (FREE, comprehensive)
- **DVWA** (Damn Vulnerable Web App) | **bWAPP** (100+ vulns)
- **HackTheBox** | **PentesterLab**

---

## LEVEL 3: BUG BOUNTY SKILLS

### Bug Types to Master (in order)
1. IDOR — Easiest, often high impact
2. XSS — Very common, good for learning
3. SSRF — High impact, increasingly common
4. SQLi — Classic, still found everywhere
5. Auth Bypass — High impact
6. Business Logic — Unique per app, hard to automate
7. Race Conditions — Often overlooked
8. SSTI — Often leads to RCE

### Tools to Master
1. **Burp Suite** — Primary weapon
2. **Browser DevTools** — Network, Console, Sources
3. **ffuf** — Fast web fuzzer
4. **Nuclei** — Template-based scanner
5. **Python requests** — Custom scripts

### Resources
- NahamSec, STÖK, InsiderPHD, LiveOverflow (YouTube)
- Hacker101 (hacker101.com) — Free by HackerOne


---

## LEVEL 4: ADVANCED TOPICS

### Advanced Web Attacks
- HTTP Request Smuggling, Cache Poisoning, Prototype Pollution
- WebSocket attacks, GraphQL exploitation
- Deserialization (Java, PHP, Python, .NET)

### Cloud Security
- AWS/Azure/GCP security testing
- Container security (Docker, Kubernetes)
- Serverless security (Lambda, Cloud Functions)

### Mobile Security
- Android/iOS app testing, API extraction, SSL pinning bypass, Frida

### SOC & Blue Team
- Log analysis (SIEM: Splunk, ELK), Incident response
- Threat intelligence, IOC analysis, MITRE ATT&CK framework
- Digital forensics basics

---

## LEVEL 5: CERTIFICATIONS

| Cert | Focus | Difficulty |
|------|-------|------------|
| CompTIA Security+ | Foundations | Beginner |
| eJPT | Penetration Testing | Beginner |
| CEH | Ethical Hacking | Intermediate |
| OSCP | Penetration Testing | Advanced |
| OSWE | Web App Security | Advanced |
| BSCP (PortSwigger) | Web Security | Advanced |
| CRTP | Active Directory | Advanced |

---

## KEY CONCEPTS GLOSSARY

| Term | Meaning |
|------|---------|
| CVE | Common Vulnerabilities and Exposures — unique ID for known vulns |
| CWE | Common Weakness Enumeration — categorization of vuln types |
| CVSS | Common Vulnerability Scoring System — severity rating (0-10) |
| OWASP | Open Web Application Security Project — security standards org |
| MITRE ATT&CK | Framework mapping adversary tactics and techniques |
| PoC | Proof of Concept — demonstration that a vuln is exploitable |
| WAF | Web Application Firewall — filters malicious HTTP traffic |
| SIEM | Security Information and Event Management — log aggregation |
| IOC | Indicator of Compromise — evidence of a breach |
| APT | Advanced Persistent Threat — sophisticated threat actor group |
| RCE | Remote Code Execution — attacker runs code on the server |
| IDOR | Insecure Direct Object Reference — access other users' data |
| SSRF | Server-Side Request Forgery — server makes unintended requests |
| XSS | Cross-Site Scripting — inject scripts into web pages |
| SQLi | SQL Injection — inject SQL commands into database queries |
| CSRF | Cross-Site Request Forgery — trick user into making requests |
| SSTI | Server-Side Template Injection — inject into template engines |
| LFI/RFI | Local/Remote File Inclusion — read/execute arbitrary files |

