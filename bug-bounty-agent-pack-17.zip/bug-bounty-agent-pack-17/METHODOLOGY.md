# BUG BOUNTY METHODOLOGY — COMPREHENSIVE PENTEST & EXPLOIT GUIDE (v17)

This document provides a complete, step-by-step methodology for bug bounty hunting and penetration testing. Combines OWASP Testing Guide, PTES, OSSTMM, and real-world bug bounty hunter techniques.

---

## PHASE 0: TARGET SELECTION

### Where to Find Targets
- **HackerOne:** https://hackerone.com/directory/programs — Filter by "Bounties only"
- **Bugcrowd:** https://bugcrowd.com/programs — Check reward ranges and scope
- **Intigriti:** https://www.intigriti.com/programs — European-focused
- **YesWeHack:** https://yeswehack.com/programs — Growing platform
- **Open Bug Bounty:** https://www.openbugbounty.org/ — XSS/CSRF focused
- **GitHub Security Advisories:** https://github.com/advisories
- **Google VRP:** https://bughunters.google.com/
- **Microsoft MSRC:** https://msrc.microsoft.com/bounty

### Selection Criteria
1. **Reward potential** — Higher rewards but also more competition
2. **Scope breadth** — Wider scope = more attack surface
3. **Technology stack** — Pick tech you know well
4. **Program maturity** — New programs = more low-hanging fruit
5. **Response time** — Fast response = faster payouts
6. **Competition level** — Less popular = less competition

---

## PHASE 1: PASSIVE RECONNAISSANCE

### 1.1. Subdomain Enumeration
```bash
subfinder -d target.com -all -o subdomains.txt
amass enum -passive -d target.com -o amass_subs.txt
cat subdomains.txt amass_subs.txt | sort -u > all_subs.txt
```

### 1.2. DNS & Certificate Transparency
```bash
dig axfr @ns1.target.com target.com
dig target.com ANY
curl -s "https://crt.sh/?q=%.target.com&output=json" | jq -r '.[].name_value' | sort -u
```

### 1.3. Wayback Machine
```bash
curl -s "https://web.archive.org/cdx/search/cdx?url=*.target.com/*&output=text&fl=original&collapse=urlkey" | sort -u > wayback_urls.txt
cat wayback_urls.txt | grep -E "\.(js|json|xml|sql|bak|env|config)" > interesting.txt
```

### 1.4. OSINT
- **GitHub:** Search for `target.com` — API keys, credentials, internal URLs
- **Shodan:** `hostname:target.com` — Exposed services, ports, banners
- **Censys:** Certificates, hosts, services
- **LinkedIn:** Tech stack hints from job postings


---

## PHASE 2: ACTIVE RECONNAISSANCE

### 2.1. Port Scanning
```bash
nmap -sS -T4 --top-ports 1000 target.com -oN nmap_fast.txt
nmap -sS -p- -T4 target.com -oN nmap_full.txt
nmap -sV -sC -p <open_ports> target.com -oN nmap_detailed.txt
```

### 2.2. Content Discovery
```bash
ffuf -u https://target.com/FUZZ -w wordlist.txt -mc 200,301,302,403
ffuf -u https://target.com/api/FUZZ -w api-wordlist.txt
arjun -u https://target.com/page  # Parameter discovery
```

### 2.3. JavaScript Analysis
- Extract JS files from wayback URLs
- Look for: API endpoints, hardcoded secrets, internal URLs, debug flags

### 2.4. Subdomain Takeover
```bash
subjack -w all_subs.txt -t 100 -timeout 30 -o takeover_results.txt
```

---

## PHASE 3: VULNERABILITY TESTING CHECKLIST

### Authentication
- [ ] Default credentials, brute force protection, password reset flow
- [ ] MFA bypass, session management, OAuth/OIDC misconfigs
- [ ] JWT vulns (none algo, key confusion, weak secret)

### Authorization
- [ ] IDOR (horizontal & vertical), forced browsing, BOLA/BFLA
- [ ] Role-based access control bypass, missing function-level access control

### Input Validation
- [ ] SQLi, XSS, Command Injection, SSTI, SSRF, XXE
- [ ] Path Traversal/LFI/RFI, CRLF, LDAP, NoSQL Injection

### Business Logic
- [ ] Price/quantity manipulation, coupon abuse, workflow bypass
- [ ] Rate limiting bypass, currency rounding errors

### File Upload
- [ ] Extension bypass, MIME type bypass, polyglot files
- [ ] Race condition in upload, SVG for XSS/SSRF, ZIP slip

### API-Specific
- [ ] Mass assignment, GraphQL introspection/batching
- [ ] API versioning, CORS misconfiguration, improper error handling

---

## PHASE 4: EXPLOITATION & PoC

### CVSS v3.1 Quick Reference
```
AV: Network(N)/Adjacent(A)/Local(L)/Physical(P)
AC: Low(L)/High(H)
PR: None(N)/Low(L)/High(H)
UI: None(N)/Required(R)
S: Unchanged(U)/Changed(C)
C/I/A: None(N)/Low(L)/High(H)

Example: CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H = 9.8 Critical
```

### PoC Best Practices
1. Minimal impact — demonstrate without causing damage
2. Clear evidence — screenshots, HTTP requests/responses
3. Reproducible — clear steps anyone can follow
4. Impact demonstration — show real-world attacker capability
5. CVSS scoring — include full vector string

---

## PHASE 5: REPORTING

Use `templates/report-template.md`. Key elements:
Title, Severity, CVSS Score, CWE, Description, Steps to Reproduce, Impact, Remediation, References.

