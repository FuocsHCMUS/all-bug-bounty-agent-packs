# 🎯 Bug Bounty Super Agent Pack v17

> **The most comprehensive AI agent prompt pack for autonomous bug bounty hunting, penetration testing, vulnerability research, and offensive security operations.**

Designed for use across **Claude Code, Codex, OpenCode, Cline, Cursor, and Antigravity** IDEs.

---

## 📁 Pack Structure

```
bug-bounty-agent-pack-17/
├── AGENTS.md              # Master system prompt (Claude Code)
├── RULES.md               # Core operational rules
├── SKILL.md               # Technical skill engine & payloads
├── METHODOLOGY.md         # Full pentest methodology (OWASP/PTES)
├── CVE-RESEARCH.md        # CVE research & correlation guide
├── WRITEUP-ANALYSIS.md    # Bug bounty/CTF writeup analysis
├── TOOLKIT.md             # Tools, scripts & resources catalog
├── LEARNING-PATH.md       # Cybersecurity learning roadmap
├── .cursorrules           # Cursor IDE rules
├── CLINE.md               # Cline (VS Code) instructions
├── CODEX.md               # OpenAI Codex instructions
├── OPENCODE.md            # OpenCode instructions
├── ANTIGRAVITY.md         # Antigravity IDE instructions
├── README.md              # This file
├── scripts/
│   ├── recon.py           # Automated recon pipeline
│   ├── vuln_scanner.py    # Multi-vector vulnerability scanner
│   ├── cve_lookup.py      # CVE research & correlation tool
│   ├── js_analyzer.py     # JS file analysis for secrets
│   └── race_condition.py  # Race condition tester
├── templates/
│   └── report-template.md # Bug bounty report template
├── tools/                 # Cloned tools & repos (auto-populated)
├── wordlists/             # Custom wordlists
└── notes/                 # Hunting notes & writeup analyses
```

---

## 🚀 Quick Start

### For Claude Code
Claude Code natively reads `AGENTS.md`. Just open this folder as your workspace.

### For Cursor
The `.cursorrules` file is auto-loaded by Cursor IDE.

### For Cline (VS Code)
Reference `CLINE.md` in your Cline configuration.

### For Codex
Reference `CODEX.md` in your Codex system prompt.

### For OpenCode
Reference `OPENCODE.md` in your OpenCode configuration.

### For Antigravity
Reference `ANTIGRAVITY.md` in your Antigravity IDE setup.

---

## 🛠️ Scripts Usage

```bash
# Recon
python scripts/recon.py --domain target.com --deep

# Vulnerability Scan
python scripts/vuln_scanner.py --url https://target.com --deep

# CVE Lookup
python scripts/cve_lookup.py --keyword "apache 2.4.49"
python scripts/cve_lookup.py --cve CVE-2021-41773
python scripts/cve_lookup.py --recent 30

# JS Analysis
python scripts/js_analyzer.py --url https://target.com/app.js

# Race Condition Test
python scripts/race_condition.py --url https://target.com/api/action --threads 20
```

---

## 📋 Requirements

```bash
pip install requests dnspython rich httpx
```

Python 3.14.x+ on Windows 11.

---

## 🎓 For the Operator

This pack includes a comprehensive **LEARNING-PATH.md** that takes you from zero to bug bounty hunter, covering:
- Internet & networking fundamentals
- Web application security basics
- OWASP Top 10 deep dive
- Bug bounty specific skills
- Advanced topics (cloud, mobile, SOC)
- Certification roadmap

Every finding the agent discovers comes with detailed learning notes explaining the root cause, exploitation mechanics, and remediation — all from first principles.
