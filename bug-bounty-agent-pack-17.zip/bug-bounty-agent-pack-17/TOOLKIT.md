# TOOLKIT — TOOLS, SCRIPTS & RESOURCES (v17)

## 1. ESSENTIAL TOOLS

### Reconnaissance
| Tool | Purpose | Install |
|------|---------|---------|
| subfinder | Subdomain discovery | `go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest` |
| amass | Attack surface mapping | `go install github.com/owasp-amass/amass/v4/...@master` |
| httpx | HTTP probing | `go install github.com/projectdiscovery/httpx/cmd/httpx@latest` |
| nuclei | Vulnerability scanner | `go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest` |
| ffuf | Web fuzzer | `go install github.com/ffuf/ffuf/v2@latest` |
| nmap | Port scanner | System install required (ask operator) |
| whatweb | Tech fingerprinting | `gem install whatweb` or clone repo |
| gau | URL fetching (Wayback+) | `go install github.com/lc/gau/v2/cmd/gau@latest` |
| waybackurls | Wayback Machine URLs | `go install github.com/tomnomnom/waybackurls@latest` |

### Vulnerability Testing
| Tool | Purpose | Install |
|------|---------|---------|
| Burp Suite Community | Web proxy & scanner | Download from portswigger.net (ask operator) |
| sqlmap | SQL injection | `pip install sqlmap` or clone repo |
| dalfox | XSS scanner | `go install github.com/hahwul/dalfox/v2@latest` |
| ssrfmap | SSRF exploitation | `git clone https://github.com/swisskyrepo/SSRFmap` |
| jwt_tool | JWT testing | `git clone https://github.com/ticarpi/jwt_tool` |
| GraphQLmap | GraphQL testing | `git clone https://github.com/swisskyrepo/GraphQLmap` |
| arjun | Parameter discovery | `pip install arjun` |
| ParamSpider | Parameter mining | `pip install paramspider` |

### Exploitation
| Tool | Purpose | Install |
|------|---------|---------|
| PayloadsAllTheThings | Payload reference | `git clone https://github.com/swisskyrepo/PayloadsAllTheThings` |
| SecLists | Wordlists | `git clone https://github.com/danielmiessler/SecLists` |
| CyberChef | Data encoding/decoding | https://gchq.github.io/CyberChef/ (web-based) |
| Hashcat | Password cracking | System install (ask operator) |
| John the Ripper | Password cracking | System install (ask operator) |

### Python Libraries (pip install freely)
```bash
pip install requests httpx aiohttp beautifulsoup4 lxml
pip install pyjwt cryptography pycryptodome
pip install dnspython shodan censys
pip install selenium playwright
pip install rich colorama tabulate
pip install sqlmap arjun paramspider
```

---

## 2. PORTABLE TOOLS (Clone into tools/ directory)

These can be cloned directly without asking:
```bash
cd bug-bounty-agent-pack-17/tools/
git clone https://github.com/swisskyrepo/PayloadsAllTheThings
git clone https://github.com/danielmiessler/SecLists
git clone https://github.com/ticarpi/jwt_tool
git clone https://github.com/swisskyrepo/SSRFmap
git clone https://github.com/swisskyrepo/GraphQLmap
git clone https://github.com/m4ll0k/SecretFinder
git clone https://github.com/GerbenJav);do/LinkFinder
git clone https://github.com/devanshbatham/ParamSpider
git clone https://github.com/s0md3v/Arjun
```

---

## 3. ONLINE TOOLS & SERVICES

| Service | URL | Purpose |
|---------|-----|---------|
| Shodan | https://shodan.io | Internet-wide scanning |
| Censys | https://censys.io | Certificate & host search |
| crt.sh | https://crt.sh | Certificate transparency |
| SecurityTrails | https://securitytrails.com | DNS & domain intelligence |
| VirusTotal | https://virustotal.com | URL/file scanning, passive DNS |
| DNSDumpster | https://dnsdumpster.com | DNS recon |
| Wayback Machine | https://web.archive.org | Historical web pages |
| CyberChef | https://gchq.github.io/CyberChef/ | Data transformation |
| JWT.io | https://jwt.io | JWT debugging |
| Regex101 | https://regex101.com | Regex testing |
| Webhook.site | https://webhook.site | HTTP callback testing |
| Burp Collaborator | Via Burp Suite | OOB interaction testing |

---

## 4. CUSTOM SCRIPTS (in scripts/ directory)

| Script | Purpose |
|--------|---------|
| `recon.py` | Full automated recon pipeline |
| `vuln_scanner.py` | Multi-vector vulnerability scanner |
| `cve_lookup.py` | CVE research and correlation |
| `js_analyzer.py` | JS file analysis for secrets/endpoints |
| `header_checker.py` | Security header analysis |
| `subdomain_takeover.py` | Subdomain takeover checker |
| `race_condition.py` | Race condition tester |
| `report_generator.py` | Bug bounty report generator |

---

## 5. BROWSER EXTENSIONS (Recommend to operator)

- **Wappalyzer** — Technology detection
- **FoxyProxy** — Proxy switching (for Burp)
- **Cookie Editor** — Cookie manipulation
- **HackBar** — Quick payload testing
- **Retire.js** — Vulnerable JS library detection
- **Shodan** — Shodan integration
