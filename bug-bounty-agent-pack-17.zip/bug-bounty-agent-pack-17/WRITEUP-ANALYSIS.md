# WRITEUP & CTF ANALYSIS GUIDE (v17)

## 1. WHERE TO FIND WRITEUPS

### Bug Bounty Writeups
- **HackerOne Hacktivity:** https://hackerone.com/hacktivity — Disclosed reports from real programs
- **Bugcrowd Blog:** https://www.bugcrowd.com/blog/ — Featured researcher writeups
- **Medium / InfoSec Write-ups:** https://infosecwriteups.com/ — Community writeups
- **PortSwigger Research:** https://portswigger.net/research — Advanced web security research
- **Project Zero Blog:** https://googleprojectzero.blogspot.com/ — Google's elite vuln research team
- **Orange Tsai's Blog:** https://blog.orange.tw/ — World-class web security researcher
- **assetnote.io Blog:** https://blog.assetnote.io/ — Attack surface management research
- **Corben Leo's Blog:** https://www.corben.io/ — Bug bounty writeups
- **Sam Curry's Blog:** https://samcurry.net/ — High-impact bug bounty findings

### CTF Writeups
- **CTFtime:** https://ctftime.org/writeups — Aggregated CTF writeups
- **GitHub CTF Writeups:** Search `ctf writeup {category}` on GitHub
- **LiveOverflow YouTube:** https://youtube.com/LiveOverflow — Video explanations
- **John Hammond YouTube:** https://youtube.com/JohnHammond010 — CTF walkthroughs
- **IppSec YouTube:** https://youtube.com/ippsec — HackTheBox walkthroughs

### Security Research Papers
- **IEEE S&P, USENIX Security, CCS, NDSS** — Top academic security conferences
- **arXiv cs.CR:** https://arxiv.org/list/cs.CR/recent — Preprint security papers
- **Black Hat Archives:** https://www.blackhat.com/html/archives.html
- **DEF CON Media:** https://media.defcon.org/

---

## 2. WRITEUP ANALYSIS FRAMEWORK

When reading a writeup, extract these elements:

### Template
```markdown
## Writeup Analysis: [Title]

**Source:** [URL]
**Author:** [Name]
**Target:** [Program/Platform]
**Date:** [Date]

### Vulnerability Details
- **Type:** [CWE-XXX: Name]
- **Severity:** [Critical/High/Medium/Low]
- **CVSS:** [Score]
- **Bounty:** [$Amount]

### Discovery Method
- How was this found? (Fuzzing, code review, manual testing, automated scan)
- What tools were used?
- What made the researcher look at this specific area?

### Root Cause
- Why did this vulnerability exist?
- What assumption did the developers make?
- What security control was missing or broken?

### Exploitation Technique
1. [Step 1]
2. [Step 2]
3. [Step N]

### Bypass Techniques Used
- [Any WAF/filter/security control bypasses]

### Key Takeaways
- What's novel or interesting about this finding?
- What pattern can be generalized?
- Where else could this technique work?

### Applicability to Current Targets
- Can this technique be applied to targets I'm currently hunting?
- What modifications would be needed?
```

---

## 3. TECHNIQUE EXTRACTION PATTERNS

### From XSS Writeups
- New event handlers or HTML elements for XSS
- Novel encoding/obfuscation techniques
- CSP bypass methods
- DOM clobbering techniques
- Mutation XSS (mXSS) patterns

### From SSRF Writeups
- New URL parsing confusion techniques
- DNS rebinding methods
- Protocol smuggling (gopher://, dict://)
- Cloud metadata access patterns
- PDF/image generator SSRF vectors

### From Auth Bypass Writeups
- JWT manipulation techniques
- OAuth flow exploitation
- Session management weaknesses
- Password reset poisoning methods
- MFA bypass techniques

### From Injection Writeups
- New SQLi techniques and WAF bypasses
- SSTI payloads for new template engines
- Command injection in unexpected contexts
- NoSQL injection patterns
- GraphQL injection techniques

---

## 4. KNOWLEDGE BASE STRUCTURE

Organize extracted knowledge in `notes/` folder:

```
notes/
├── writeup-analysis/          # Individual writeup analyses
│   ├── 2024-01-xss-csp-bypass.md
│   ├── 2024-02-ssrf-pdf-generator.md
│   └── ...
├── techniques/                # Generalized techniques
│   ├── xss-bypasses.md
│   ├── ssrf-techniques.md
│   ├── auth-bypass-methods.md
│   └── ...
├── payloads/                  # Collected payloads
│   ├── xss-payloads.txt
│   ├── sqli-payloads.txt
│   └── ...
└── patterns/                  # Attack patterns
    ├── chain-patterns.md
    ├── tech-specific-vulns.md
    └── ...
```

---

## 5. CONTINUOUS LEARNING PROTOCOL

1. **Daily:** Read 2-3 new writeups from HackerOne Hacktivity or InfoSec Write-ups
2. **Weekly:** Analyze 1 advanced research paper or PortSwigger Research post
3. **Monthly:** Participate in 1 CTF competition
4. **Per Hunt:** Document all new techniques discovered
5. **Per Finding:** Write a personal writeup (even if not published)
