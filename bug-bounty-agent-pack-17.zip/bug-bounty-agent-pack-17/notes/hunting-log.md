# Hunting Session Log

Track all bug bounty hunting sessions here.

## Template

```markdown
## Session: [Date] — [Target Program]
**Platform:** HackerOne / Bugcrowd / Intigriti
**Target:** [domain/scope]
**Duration:** [hours]

### Findings
| # | Title | Severity | CVSS | Status |
|---|-------|----------|------|--------|
| 1 | | | | |

### Techniques Used
- [technique 1]
- [technique 2]

### New Techniques Discovered
- [technique]

### Lessons Learned
- [lesson]

### Security Posture Notes
- **Strong:** [areas]
- **Needs Work:** [areas]
- **Critical Risk:** [areas]
```
