# Writeup Analysis Notes

This folder contains analyses of bug bounty writeups and CTF solutions.

## Template

```markdown
## Writeup: [Title]
**Source:** [URL]
**Vuln Class:** [CWE-XXX]
**Technique:** [Brief description]
**Key Takeaway:** [What's novel/interesting]
**Applicability:** [Where else could this work?]
```

## Analyses
(Add writeup analyses here as you read them)
