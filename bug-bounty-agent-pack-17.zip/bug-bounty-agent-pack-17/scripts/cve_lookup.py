#!/usr/bin/env python3
"""
CVE Lookup & Correlation Tool v17
Search NVD for CVEs, correlate with target tech stack, find exploits.
Usage: python cve_lookup.py --keyword "apache 2.4" [--recent 30] [--cve CVE-2021-41773]
Requirements: pip install requests rich
"""
import argparse, json, sys, time
from datetime import datetime, timedelta

try: import requests
except ImportError: import subprocess; subprocess.check_call([sys.executable,"-m","pip","install","requests"]); import requests
try: from rich.console import Console; from rich.table import Table; from rich.panel import Panel
except ImportError: import subprocess; subprocess.check_call([sys.executable,"-m","pip","install","rich"]); from rich.console import Console; from rich.table import Table; from rich.panel import Panel

console = Console()
NVD_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"

def search_nvd(keyword: str = None, cve_id: str = None, days: int = None, limit: int = 50) -> list[dict]:
    """Search NVD for CVEs."""
    params = {"resultsPerPage": min(limit, 2000)}
    if keyword: params["keywordSearch"] = keyword
    if cve_id: params["cveId"] = cve_id
    if days:
        end = datetime.utcnow()
        start = end - timedelta(days=days)
        params["pubStartDate"] = start.strftime("%Y-%m-%dT00:00:00.000")
        params["pubEndDate"] = end.strftime("%Y-%m-%dT23:59:59.999")
    try:
        r = requests.get(NVD_API, params=params, timeout=30)
        if r.status_code == 200:
            results = []
            for vuln in r.json().get("vulnerabilities", []):
                cve = vuln.get("cve", {})
                desc = next((d["value"] for d in cve.get("descriptions",[]) if d.get("lang")=="en"), "")
                score = severity = vector = None
                for k in ["cvssMetricV31","cvssMetricV30"]:
                    if k in cve.get("metrics",{}):
                        cd = cve["metrics"][k][0].get("cvssData",{})
                        score = cd.get("baseScore"); severity = cd.get("baseSeverity")
                        vector = cd.get("vectorString"); break
                refs = [r.get("url","") for r in cve.get("references",[])]
                exploit_refs = [r for r in refs if any(x in r.lower() for x in ["exploit","github.com","packetstorm","0day"])]
                results.append({"id": cve.get("id",""), "description": desc[:200],
                    "cvss": score, "severity": severity, "vector": vector,
                    "published": cve.get("published","")[:10], "refs": refs[:5],
                    "exploit_refs": exploit_refs, "has_exploit": len(exploit_refs) > 0})
            return sorted(results, key=lambda x: x.get("cvss") or 0, reverse=True)
        elif r.status_code == 403:
            console.print("[yellow]Rate limited, waiting 6s...[/yellow]"); time.sleep(6)
            return search_nvd(keyword, cve_id, days, limit)
    except Exception as e: console.print(f"[red]NVD error: {e}[/red]")
    return []

def search_exploitdb(keyword: str) -> list[str]:
    """Generate ExploitDB search URLs."""
    return [f"https://www.exploit-db.com/search?q={keyword.replace(' ','+')}",
            f"https://www.google.com/search?q=site:exploit-db.com+{keyword.replace(' ','+')}"]

def display_results(results: list[dict], title: str = "CVE Results"):
    table = Table(title=title)
    table.add_column("CVE ID", style="cyan", width=18)
    table.add_column("CVSS", style="bold", width=6)
    table.add_column("Severity", width=10)
    table.add_column("Exploit?", width=8)
    table.add_column("Published", width=12)
    table.add_column("Description", width=60)
    for r in results:
        sev_color = {"CRITICAL":"red","HIGH":"yellow","MEDIUM":"blue","LOW":"green"}.get(r.get("severity",""),"white")
        table.add_row(r["id"], str(r.get("cvss","-")), f"[{sev_color}]{r.get('severity','-')}[/{sev_color}]",
            "[red]YES[/red]" if r.get("has_exploit") else "No", r.get("published","-"), r["description"][:60])
    console.print(table)

def main():
    p = argparse.ArgumentParser(description="CVE Lookup v17")
    p.add_argument("--keyword","-k", help="Search keyword (e.g., 'apache 2.4.49')")
    p.add_argument("--cve","-c", help="Specific CVE ID (e.g., CVE-2021-41773)")
    p.add_argument("--recent","-r", type=int, help="Show CVEs from last N days")
    p.add_argument("--limit","-l", type=int, default=20, help="Max results")
    p.add_argument("--output","-o", help="Save results to JSON")
    args = p.parse_args()

    if not any([args.keyword, args.cve, args.recent]):
        p.print_help(); return

    console.print(Panel("[bold green]CVE Lookup Tool v17[/bold green]", title="CVE"))
    results = search_nvd(keyword=args.keyword, cve_id=args.cve, days=args.recent, limit=args.limit)
    if results:
        display_results(results)
        if args.keyword:
            console.print(f"\n[yellow]ExploitDB Search:[/yellow]")
            for url in search_exploitdb(args.keyword): console.print(f"  [cyan]{url}[/cyan]")
        if args.output:
            with open(args.output,"w") as f: json.dump(results,f,indent=2)
            console.print(f"\n[green]Saved: {args.output}[/green]")
    else:
        console.print("[yellow]No results found.[/yellow]")

if __name__ == "__main__":
    main()
