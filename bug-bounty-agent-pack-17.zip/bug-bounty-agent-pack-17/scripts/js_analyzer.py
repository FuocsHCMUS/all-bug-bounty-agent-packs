#!/usr/bin/env python3
"""
JavaScript Analyzer v17 — Extract secrets, endpoints, and sensitive data from JS files.
Usage: python js_analyzer.py --url https://target.com/app.js [--urls-file js_urls.txt]
Requirements: pip install requests rich
"""
import argparse, json, re, sys
from datetime import datetime

try: import requests
except ImportError: import subprocess; subprocess.check_call([sys.executable,"-m","pip","install","requests"]); import requests
try: from rich.console import Console; from rich.table import Table
except ImportError: import subprocess; subprocess.check_call([sys.executable,"-m","pip","install","rich"]); from rich.console import Console; from rich.table import Table

console = Console()

PATTERNS = {
    "AWS Access Key": r'AKIA[0-9A-Z]{16}',
    "AWS Secret Key": r'(?i)aws(.{0,20})?[\'"][0-9a-zA-Z/+]{40}[\'"]',
    "Google API Key": r'AIza[0-9A-Za-z\-_]{35}',
    "GitHub Token": r'gh[pousr]_[A-Za-z0-9_]{36,255}',
    "Slack Token": r'xox[baprs]-[0-9a-zA-Z]{10,48}',
    "JWT Token": r'eyJ[A-Za-z0-9-_]+\.eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+',
    "Private Key": r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----',
    "Generic API Key": r'(?i)(?:api[_-]?key|apikey|api_secret)[\'"\s:=]+[\'"][a-zA-Z0-9]{16,64}[\'"]',
    "Generic Secret": r'(?i)(?:secret|password|passwd|pwd|token)[\'"\s:=]+[\'"][^\'"]{8,64}[\'"]',
    "Authorization Header": r'(?i)(?:authorization|bearer)\s*[:=]\s*[\'"][^\'"]+[\'"]',
    "Internal URL": r'https?://(?:localhost|127\.0\.0\.1|10\.\d+\.\d+\.\d+|172\.(?:1[6-9]|2\d|3[01])\.\d+\.\d+|192\.168\.\d+\.\d+)[^\s\'"]*',
    "API Endpoint": r'[\'"]\/api\/[a-zA-Z0-9/_\-{}]+[\'"]',
    "GraphQL Endpoint": r'[\'"]\/graphql[\'"]',
    "Admin Path": r'[\'"]\/(?:admin|dashboard|internal|debug|management)[^\'"]*[\'"]',
    "Email Address": r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
    "IP Address": r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
    "S3 Bucket": r'[a-zA-Z0-9.-]+\.s3\.amazonaws\.com|s3://[a-zA-Z0-9.-]+',
    "Firebase URL": r'https://[a-zA-Z0-9-]+\.firebaseio\.com',
}

def analyze_js(content: str, source: str = "") -> list[dict]:
    findings = []
    for name, pattern in PATTERNS.items():
        matches = re.findall(pattern, content)
        for match in set(matches):
            match_str = match if isinstance(match, str) else match[0]
            if len(match_str) > 200: match_str = match_str[:200] + "..."
            findings.append({"type": name, "value": match_str, "source": source})
    return findings

def fetch_and_analyze(url: str) -> list[dict]:
    try:
        r = requests.get(url, timeout=30, headers={"User-Agent":"Mozilla/5.0"})
        if r.status_code == 200:
            return analyze_js(r.text, url)
    except Exception as e:
        console.print(f"[red]Error fetching {url}: {e}[/red]")
    return []

def main():
    p = argparse.ArgumentParser(description="JS Analyzer v17")
    p.add_argument("--url","-u", help="Single JS URL to analyze")
    p.add_argument("--urls-file","-f", help="File with JS URLs (one per line)")
    p.add_argument("--output","-o", help="Save results to JSON")
    args = p.parse_args()

    all_findings = []
    urls = []
    if args.url: urls.append(args.url)
    if args.urls_file:
        with open(args.urls_file) as f: urls.extend(line.strip() for line in f if line.strip())

    for url in urls:
        console.print(f"[yellow]Analyzing: {url}[/yellow]")
        findings = fetch_and_analyze(url)
        all_findings.extend(findings)

    if all_findings:
        table = Table(title="JS Analysis Results")
        table.add_column("Type",style="cyan",width=20); table.add_column("Value",width=50)
        table.add_column("Source",width=40)
        for f in all_findings:
            table.add_row(f["type"], f["value"][:50], f["source"][-40:])
        console.print(table)
    console.print(f"\n[bold]Total: {len(all_findings)} findings[/bold]")
    if args.output:
        with open(args.output,"w") as f: json.dump(all_findings,f,indent=2)

if __name__ == "__main__":
    main()
