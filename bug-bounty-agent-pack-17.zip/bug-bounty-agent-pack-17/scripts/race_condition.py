#!/usr/bin/env python3
"""
Race Condition Tester v17 — Test for race conditions in web applications.
Usage: python race_condition.py --url https://target.com/api/apply-coupon --method POST --data '{"coupon":"SAVE50"}' --threads 20
Requirements: pip install requests rich
"""
import argparse, json, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

try: import requests
except ImportError: import subprocess; subprocess.check_call([sys.executable,"-m","pip","install","requests"]); import requests
try: from rich.console import Console; from rich.table import Table
except ImportError: import subprocess; subprocess.check_call([sys.executable,"-m","pip","install","rich"]); from rich.console import Console; from rich.table import Table

console = Console()

def send_request(url, method, headers, data, cookies, request_id):
    """Send a single request and return timing + response info."""
    start = time.perf_counter()
    try:
        if method.upper() == "GET":
            r = requests.get(url, headers=headers, cookies=cookies, timeout=30)
        elif method.upper() == "POST":
            content_type = headers.get("Content-Type", "application/json")
            if "json" in content_type:
                r = requests.post(url, headers=headers, json=json.loads(data) if isinstance(data,str) else data, cookies=cookies, timeout=30)
            else:
                r = requests.post(url, headers=headers, data=data, cookies=cookies, timeout=30)
        elif method.upper() == "PUT":
            r = requests.put(url, headers=headers, json=json.loads(data) if isinstance(data,str) else data, cookies=cookies, timeout=30)
        else:
            r = requests.request(method, url, headers=headers, data=data, cookies=cookies, timeout=30)
        elapsed = time.perf_counter() - start
        return {"id": request_id, "status": r.status_code, "length": len(r.text),
                "time": round(elapsed, 4), "body_preview": r.text[:200], "success": True}
    except Exception as e:
        return {"id": request_id, "error": str(e), "success": False, "time": time.perf_counter()-start}

def main():
    p = argparse.ArgumentParser(description="Race Condition Tester v17")
    p.add_argument("--url","-u", required=True, help="Target URL")
    p.add_argument("--method","-m", default="POST", help="HTTP method")
    p.add_argument("--data","-d", default="{}", help="Request body (JSON)")
    p.add_argument("--header","-H", action="append", default=[], help="Headers (Key: Value)")
    p.add_argument("--cookie","-c", default="", help="Cookie string")
    p.add_argument("--threads","-t", type=int, default=20, help="Concurrent threads")
    p.add_argument("--rounds","-r", type=int, default=1, help="Number of rounds")
    p.add_argument("--output","-o", help="Save results to JSON")
    args = p.parse_args()

    headers = {"User-Agent": "Mozilla/5.0", "Content-Type": "application/json"}
    for h in args.header:
        k, v = h.split(":", 1); headers[k.strip()] = v.strip()
    cookies = {}
    if args.cookie:
        for pair in args.cookie.split(";"):
            if "=" in pair: k,v = pair.strip().split("=",1); cookies[k] = v

    console.print(f"[bold green]Race Condition Tester v17[/bold green]")
    console.print(f"Target: {args.url} | Method: {args.method} | Threads: {args.threads}")

    all_results = []
    for round_num in range(args.rounds):
        console.print(f"\n[yellow]Round {round_num+1}/{args.rounds}...[/yellow]")
        results = []
        with ThreadPoolExecutor(max_workers=args.threads) as executor:
            futures = [executor.submit(send_request, args.url, args.method, headers, args.data, cookies, i)
                      for i in range(args.threads)]
            for f in as_completed(futures):
                results.append(f.result())
        results.sort(key=lambda x: x.get("id",0))
        all_results.extend(results)

        table = Table(title=f"Round {round_num+1} Results")
        table.add_column("#",width=4); table.add_column("Status",width=8)
        table.add_column("Length",width=8); table.add_column("Time(s)",width=8)
        table.add_column("Preview",width=50)
        for r in results:
            if r["success"]:
                table.add_row(str(r["id"]),str(r["status"]),str(r["length"]),str(r["time"]),r.get("body_preview","")[:50])
        console.print(table)

        # Analyze for race condition indicators
        statuses = [r["status"] for r in results if r["success"]]
        lengths = [r["length"] for r in results if r["success"]]
        if len(set(statuses)) > 1:
            console.print("[red][!] DIFFERENT STATUS CODES detected — possible race condition![/red]")
        if len(set(lengths)) > 1:
            console.print("[yellow][!] DIFFERENT RESPONSE LENGTHS — investigate further[/yellow]")
        success_count = sum(1 for s in statuses if s == 200)
        console.print(f"[cyan]Success (200): {success_count}/{len(statuses)}[/cyan]")

    if args.output:
        with open(args.output,"w") as f: json.dump(all_results,f,indent=2)
        console.print(f"[green]Saved: {args.output}[/green]")

if __name__ == "__main__":
    main()
