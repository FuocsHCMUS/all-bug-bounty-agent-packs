#!/usr/bin/env python3
"""
Bug Bounty Recon Automation Pipeline v17
Usage: python recon.py --domain target.com [--output report.json] [--deep]
Requirements: pip install requests dnspython rich
"""
import argparse, json, socket, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

try: import requests
except ImportError: import subprocess; subprocess.check_call([sys.executable,"-m","pip","install","requests"]); import requests
try: from rich.console import Console; from rich.table import Table; from rich.panel import Panel
except ImportError: import subprocess; subprocess.check_call([sys.executable,"-m","pip","install","rich"]); from rich.console import Console; from rich.table import Table; from rich.panel import Panel
try: import dns.resolver
except ImportError: import subprocess; subprocess.check_call([sys.executable,"-m","pip","install","dnspython"]); import dns.resolver

console = Console()

class BugBountyRecon:
    def __init__(self, domain: str, deep: bool = False):
        self.domain = domain.strip().lower()
        self.deep = deep
        self.results = {"domain": self.domain, "timestamp": datetime.utcnow().isoformat(),
            "subdomains": [], "dns_records": {}, "technologies": [], "security_headers": {},
            "missing_headers": [], "wayback_urls": [], "interesting_urls": [],
            "ip_addresses": [], "potential_takeovers": [], "google_dorks": []}
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})

    def run_all(self):
        console.print(Panel(f"[bold green]Bug Bounty Recon v17[/bold green]\nTarget: [cyan]{self.domain}[/cyan]", title="RECON"))
        self.enum_subdomains()
        self.resolve_dns()
        self.check_wayback()
        self.fingerprint_tech()
        self.check_headers()
        self.gen_dorks()
        self.check_takeover()
        if self.deep: self.deep_scan()
        self.print_report()
        return self.results

    def enum_subdomains(self):
        console.print("\n[yellow][*] Enumerating subdomains (crt.sh)...[/yellow]")
        try:
            r = self.session.get(f"https://crt.sh/?q=%.{self.domain}&output=json", timeout=30)
            if r.status_code == 200:
                subs = set()
                for e in r.json():
                    for n in e.get("name_value","").split("\n"):
                        n = n.strip().lower().replace("*.","")
                        if n.endswith(f".{self.domain}") or n == self.domain: subs.add(n)
                self.results["subdomains"] = sorted(subs)
                console.print(f"  [green]Found {len(subs)} subdomains[/green]")
        except Exception as e: console.print(f"  [red]Error: {e}[/red]")

    def resolve_dns(self):
        console.print("\n[yellow][*] Resolving DNS...[/yellow]")
        for rtype in ["A","AAAA","MX","TXT","NS","CNAME","SOA"]:
            try:
                answers = dns.resolver.resolve(self.domain, rtype)
                records = [str(r) for r in answers]
                self.results["dns_records"][rtype] = records
                if rtype == "A": self.results["ip_addresses"] = records
                console.print(f"  [green]{rtype}: {', '.join(records[:3])}{('...' if len(records)>3 else '')}[/green]")
            except Exception: pass

    def check_wayback(self):
        console.print("\n[yellow][*] Querying Wayback Machine...[/yellow]")
        try:
            r = self.session.get(f"https://web.archive.org/cdx/search/cdx?url=*.{self.domain}/*&output=json&fl=original&collapse=urlkey&limit=500", timeout=60)
            if r.status_code == 200:
                data = r.json()
                urls = [row[0] for row in data[1:]] if len(data) > 1 else []
                self.results["wayback_urls"] = urls[:500]
                exts = (".js",".json",".xml",".sql",".bak",".env",".config",".yml",".php",".log",".csv",".zip")
                interesting = [u for u in urls if any(u.lower().endswith(e) for e in exts)]
                self.results["interesting_urls"] = interesting[:100]
                console.print(f"  [green]{len(urls)} URLs, {len(interesting)} interesting[/green]")
        except Exception as e: console.print(f"  [red]Error: {e}[/red]")

    def fingerprint_tech(self):
        console.print("\n[yellow][*] Fingerprinting technologies...[/yellow]")
        for scheme in ["https","http"]:
            try:
                r = self.session.get(f"{scheme}://{self.domain}", timeout=15, allow_redirects=True)
                h, techs = r.headers, []
                if "Server" in h: techs.append(f"Server: {h['Server']}")
                if "X-Powered-By" in h: techs.append(f"X-Powered-By: {h['X-Powered-By']}")
                body = r.text[:5000].lower()
                for name, pattern in [("WordPress","wp-content"),("Next.js","__next"),("React","react"),
                    ("Angular","angular"),("Vue.js","vue"),("Laravel","laravel"),("Django","django")]:
                    if pattern in body: techs.append(f"Framework: {name}")
                self.results["technologies"] = techs
                for t in techs: console.print(f"  [green]{t}[/green]")
                break
            except Exception: continue

    def check_headers(self):
        console.print("\n[yellow][*] Checking security headers...[/yellow]")
        required = ["Content-Security-Policy","X-Frame-Options","X-Content-Type-Options",
            "Strict-Transport-Security","Referrer-Policy","Permissions-Policy"]
        try:
            r = self.session.get(f"https://{self.domain}", timeout=15)
            present, missing = {}, []
            for hdr in required:
                v = r.headers.get(hdr)
                if v: present[hdr] = v
                else: missing.append(hdr)
            self.results["security_headers"] = present
            self.results["missing_headers"] = missing
            for h in missing: console.print(f"  [red]MISSING: {h}[/red]")
            for h in present: console.print(f"  [green]PRESENT: {h}[/green]")
        except Exception as e: console.print(f"  [red]Error: {e}[/red]")

    def gen_dorks(self):
        console.print("\n[yellow][*] Generating Google dorks...[/yellow]")
        d = self.domain
        dorks = [f'site:{d} filetype:sql OR filetype:bak OR filetype:env OR filetype:log',
            f'site:{d} inurl:admin OR inurl:login OR inurl:dashboard',
            f'site:{d} intext:"password" OR intext:"api_key" OR intext:"secret"',
            f'site:{d} inurl:".git" OR inurl:".env" OR inurl:"wp-config"',
            f'site:{d} inurl:api OR inurl:swagger OR inurl:graphql',
            f'site:{d} intitle:"index of"', f'"{d}" site:github.com', f'"{d}" site:pastebin.com']
        self.results["google_dorks"] = dorks

    def check_takeover(self):
        console.print("\n[yellow][*] Checking subdomain takeover...[/yellow]")
        fingerprints = {"github.io":"There isn't a GitHub Pages","herokuapp.com":"no-such-app",
            "amazonaws.com":"NoSuchBucket","azurewebsites.net":"404 Web Site not found",
            "shopify.com":"Sorry, this shop is currently unavailable"}
        potential = []
        for sub in self.results.get("subdomains",[])[:50]:
            try:
                answers = dns.resolver.resolve(sub, "CNAME")
                for rd in answers:
                    cname = str(rd.target).rstrip(".")
                    for svc in fingerprints:
                        if svc in cname:
                            potential.append({"subdomain":sub,"cname":cname,"service":svc})
                            console.print(f"  [red]POTENTIAL: {sub} → {cname}[/red]")
            except Exception: pass
        self.results["potential_takeovers"] = potential

    def deep_scan(self):
        console.print("\n[yellow][*] Deep scanning (resolving all subdomains)...[/yellow]")
        live = []
        def check(sub):
            try: return {"subdomain":sub,"ip":socket.gethostbyname(sub)}
            except: return None
        with ThreadPoolExecutor(max_workers=20) as ex:
            for r in ex.map(check, self.results.get("subdomains",[])[:200]):
                if r: live.append(r)
        console.print(f"  [green]{len(live)} live subdomains[/green]")

    def print_report(self):
        console.print("\n")
        table = Table(title=f"Recon Summary: {self.domain}")
        table.add_column("Category", style="cyan")
        table.add_column("Count", style="green")
        table.add_row("Subdomains", str(len(self.results["subdomains"])))
        table.add_row("Technologies", str(len(self.results["technologies"])))
        table.add_row("Wayback URLs", str(len(self.results["wayback_urls"])))
        table.add_row("Interesting Files", str(len(self.results["interesting_urls"])))
        table.add_row("Missing Headers", str(len(self.results["missing_headers"])))
        table.add_row("Potential Takeovers", str(len(self.results["potential_takeovers"])))
        console.print(table)

    def save(self, path: str):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False)
        console.print(f"\n[green]Saved: {path}[/green]")

def main():
    p = argparse.ArgumentParser(description="Bug Bounty Recon v17")
    p.add_argument("--domain","-d", required=True)
    p.add_argument("--output","-o", default=None)
    p.add_argument("--deep", action="store_true")
    args = p.parse_args()
    recon = BugBountyRecon(args.domain, deep=args.deep)
    recon.run_all()
    out = args.output or f"recon_{args.domain.replace('.','_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    recon.save(out)

if __name__ == "__main__":
    main()


