#!/usr/bin/env python3
"""
Vulnerability Scanner v17 — Multi-vector web vulnerability scanner.
Usage: python vuln_scanner.py --url https://target.com [--deep] [--output results.json]
Requirements: pip install requests rich
"""
import argparse, json, re, sys
from datetime import datetime
from urllib.parse import urlparse, parse_qs

try: import requests
except ImportError: import subprocess; subprocess.check_call([sys.executable,"-m","pip","install","requests"]); import requests
try: from rich.console import Console; from rich.table import Table; from rich.panel import Panel
except ImportError: import subprocess; subprocess.check_call([sys.executable,"-m","pip","install","rich"]); from rich.console import Console; from rich.table import Table; from rich.panel import Panel

console = Console()

class VulnScanner:
    def __init__(self, url: str, deep: bool = False):
        self.base_url = url.rstrip("/")
        self.deep = deep
        self.findings = []
        self.session = requests.Session()
        self.session.headers.update({"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})
        self.session.verify = False
        import urllib3; urllib3.disable_warnings()

    def run(self):
        console.print(Panel(f"[bold green]Vuln Scanner v17[/bold green]\nTarget: [cyan]{self.base_url}[/cyan]"))
        self.check_security_headers()
        self.check_cors()
        self.check_info_disclosure()
        self.check_open_redirect()
        self.check_common_paths()
        if self.deep:
            self.check_xss_reflection()
            self.check_sqli_errors()
        self.print_findings()
        return self.findings

    def add(self, title, severity, desc, cwe=""):
        self.findings.append({"title":title,"severity":severity,"description":desc,"cwe":cwe,
            "url":self.base_url,"timestamp":datetime.utcnow().isoformat()})
        c = {"Critical":"red","High":"yellow","Medium":"blue","Low":"green"}.get(severity,"dim")

    def check_security_headers(self):
        console.print("\n[yellow][*] Security headers...[/yellow]")
        try:
            r = self.session.get(self.base_url, timeout=15)
            for hdr,sev,cwe in [("Content-Security-Policy","Medium","CWE-693"),
                ("X-Frame-Options","Medium","CWE-1021"),("X-Content-Type-Options","Low","CWE-693"),
                ("Strict-Transport-Security","Medium","CWE-319"),("Referrer-Policy","Low","CWE-200")]:
                if hdr not in r.headers: self.add(f"Missing {hdr}",sev,f"{hdr} not set",cwe)
            for ck in r.cookies:
                if not ck.secure: self.add("Cookie Missing Secure","Medium",f"Cookie '{ck.name}'",cwe="CWE-614")
        except Exception as e: console.print(f"  [red]{e}[/red]")

    def check_cors(self):
        console.print("\n[yellow][*] CORS...[/yellow]")
        for origin in ["https://evil.com","null"]:
            try:
                r = self.session.get(self.base_url, headers={"Origin":origin}, timeout=10)
                acao = r.headers.get("Access-Control-Allow-Origin","")
                acac = r.headers.get("Access-Control-Allow-Credentials","")
                if acao == origin or acao == "*":
                    sev = "High" if acac.lower()=="true" else "Medium"
                    self.add("CORS Misconfiguration",sev,f"Origin '{origin}' reflected. ACAO={acao}",cwe="CWE-942")
            except: pass

    def check_info_disclosure(self):
        console.print("\n[yellow][*] Info disclosure...[/yellow]")
        try:
            r = self.session.get(self.base_url, timeout=15)
            for hdr in ["Server","X-Powered-By","X-AspNet-Version"]:
                if hdr in r.headers: self.add(f"Info via {hdr}","Low",f"{hdr}: {r.headers[hdr]}",cwe="CWE-200")
        except: pass

    def check_open_redirect(self):
        console.print("\n[yellow][*] Open redirect...[/yellow]")
        for param in ["url","redirect","next","return","returnUrl","goto","dest","redirect_uri","continue"]:
            try:
                r = self.session.get(f"{self.base_url}?{param}=https://evil.com", timeout=10, allow_redirects=False)
                loc = r.headers.get("Location","")
                if "evil.com" in loc: self.add(f"Open Redirect via '{param}'","Medium",f"Location: {loc}",cwe="CWE-601")
            except: pass

    def check_common_paths(self):
        console.print("\n[yellow][*] Sensitive paths...[/yellow]")
        for path in ["/.env","/.git/config","/.git/HEAD","/robots.txt","/sitemap.xml",
            "/server-status","/api/","/graphql","/swagger.json","/actuator/","/phpinfo.php",
            "/.DS_Store","/wp-admin/","/.svn/entries","/debug/","/trace/"]:
            try:
                r = self.session.get(f"{self.base_url}{path}", timeout=8, allow_redirects=False)
                if r.status_code == 200 and len(r.text) > 50:
                    sev = "Medium" if any(x in path for x in [".git",".env","actuator"]) else "Info"
                    self.add(f"Accessible: {path}",sev,f"HTTP 200, {len(r.text)}B",cwe="CWE-538")
            except: pass

    def check_xss_reflection(self):
        console.print("\n[yellow][*] XSS reflection...[/yellow]")
        canary = 'xss17<>"\'`'
        for p in ["q","search","query","s","id","name","input"]:
            try:
                r = self.session.get(f"{self.base_url}?{p}={canary}", timeout=10)
                if canary in r.text: self.add(f"XSS Reflection in '{p}'","High","Input reflected unencoded",cwe="CWE-79")
            except: pass

    def check_sqli_errors(self):
        console.print("\n[yellow][*] SQLi errors...[/yellow]")
        errors = ["sql syntax","mysql","sqlite","postgresql","unclosed quotation","syntax error"]
        for p in ["id","page","cat","item","product","user"]:
            try:
                r = self.session.get(f"{self.base_url}?{p}=1'", timeout=10)
                body = r.text.lower()
                for err in errors:
                    if err in body:
                        self.add(f"Potential SQLi in '{p}'","Critical",f"Error: '{err}'",cwe="CWE-89"); break
            except: pass

    def print_findings(self):
        console.print("\n")
        table = Table(title="Scan Results")
        table.add_column("Sev",width=10); table.add_column("Title",width=35)
        table.add_column("CWE",width=10); table.add_column("Description",width=45)
        order = {"Critical":0,"High":1,"Medium":2,"Low":3,"Info":4}
        for f in sorted(self.findings, key=lambda x: order.get(x["severity"],5)):
            c = {"Critical":"red","High":"yellow","Medium":"blue","Low":"green"}.get(f["severity"],"dim")
            table.add_row(f"[{c}]{f['severity']}[/{c}]",f["title"],f.get("cwe",""),f["description"][:45])
        console.print(table)
        console.print(f"\n[bold]Total: {len(self.findings)} findings[/bold]")

def main():
    p = argparse.ArgumentParser(description="Vuln Scanner v17")
    p.add_argument("--url","-u", required=True); p.add_argument("--deep", action="store_true")
    p.add_argument("--output","-o"); args = p.parse_args()
    scanner = VulnScanner(args.url, deep=args.deep)
    findings = scanner.run()
    if args.output:
        with open(args.output,"w") as f: json.dump(findings,f,indent=2)
        console.print(f"[green]Saved: {args.output}[/green]")

if __name__ == "__main__":
    main()

