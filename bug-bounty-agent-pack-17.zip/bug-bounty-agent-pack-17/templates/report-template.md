# Bug Bounty Report Template

## Title
[Clear, descriptive vulnerability title — e.g., "Stored XSS in User Profile Bio Field Leading to Account Takeover"]

## Summary
[1-2 sentence summary of the vulnerability and its impact]

## Severity
- **Rating:** [Critical / High / Medium / Low / Informational]
- **CVSS v3.1 Score:** [X.X]
- **CVSS Vector:** [CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H]
- **CWE:** [CWE-XXX: Name]

## Affected Asset
- **URL/Endpoint:** [https://target.com/vulnerable/endpoint]
- **Parameter:** [parameter_name]
- **HTTP Method:** [GET/POST/PUT/DELETE]

## Description
[Detailed description of the vulnerability. Explain:
- What the vulnerability is
- Where it exists in the application
- Why it exists (root cause)
- What security control is missing or broken]

## Steps to Reproduce
1. Navigate to [URL]
2. [Specific action]
3. [Specific action with payload]
4. Observe [result]

### HTTP Request
```http
POST /api/endpoint HTTP/1.1
Host: target.com
Content-Type: application/json
Cookie: session=xxx

{"parameter": "payload_here"}
```

### HTTP Response
```http
HTTP/1.1 200 OK
Content-Type: application/json

{"result": "vulnerable_response"}
```

## Proof of Concept
[Screenshots, video, or detailed evidence showing the vulnerability is exploitable]

## Impact
[Describe the real-world impact:
- What can an attacker achieve?
- How many users are affected?
- What data is at risk?
- What is the business impact?]

### Attack Scenario
1. Attacker [action]
2. Victim [action]
3. Result: [impact — e.g., "Attacker gains full access to victim's account"]

## Remediation
[Specific, actionable fix recommendations:
- What code change is needed?
- What configuration change is needed?
- What security control should be added?]

### Short-term Fix
[Immediate mitigation]

### Long-term Fix
[Proper architectural fix]

## References
- [OWASP Reference](https://owasp.org/...)
- [CWE Reference](https://cwe.mitre.org/data/definitions/XXX.html)
- [Related CVE if applicable]
- [Relevant research/writeup]

---

## Security Posture Notes (Internal — for operator learning)

### What the Company is Doing Well
- [List security controls that are working effectively]

### Areas Needing Improvement
- [List security gaps identified during testing]

### Risk Assessment
| Category | Rating | Notes |
|----------|--------|-------|
| Authentication | [Strong/Adequate/Needs Work/Critical] | [Details] |
| Authorization | | |
| Input Validation | | |
| Security Headers | | |
| API Security | | |
| Error Handling | | |

### Learning Notes
- **Root Cause Concept:** [Explain the fundamental concept behind this vulnerability]
- **How the Exploit Works:** [Step-by-step explanation from basics]
- **Defense in Depth:** [How multiple layers of security could have prevented this]
- **Related Concepts:** [OWASP Top 10 category, MITRE ATT&CK technique, etc.]
