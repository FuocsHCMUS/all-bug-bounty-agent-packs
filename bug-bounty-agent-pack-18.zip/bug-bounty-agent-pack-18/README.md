# Bug Bounty Agent Pack — v18

A self-contained instruction pack that turns coding agents (Claude Code, Codex, opencode, Cursor, Cline, Google Antigravity) into an autonomous, creative bug-bounty hunting team — and simultaneously a personal security school for the operator (a cybersecurity student).

Everything in this pack is written in English. The operator chats in Vietnamese; agents reply to the operator in Vietnamese unless asked otherwise.

---

## What this pack does

1. **Hunts on public bug bounty programs** (HackerOne, Bugcrowd, Intigriti, YesWeHack, Google VRP, Meta, GitHub, Microsoft, and others) under their published, current policies.
2. **Researches automatically**: program scope and policy, CVE intelligence for the target's stack, public writeups and CTF writeups, vendor advisories, and patch diffs.
3. **Develops its own techniques**: not just replaying known bugs — deriving new attack ideas from primitives, parser quirks, spec seams, and framework source code, then validating them in a local lab before touching a target.
4. **Produces submittable reports** the operator can file with the company, plus a **security posture analysis** (what the company does well / needs improvement / at risk / high risk) for every target examined.
5. **Teaches the operator** from the roots up: every concept is explained from first principles so a student new to networking and security can follow everything.

---

## Quick start per agent

| Agent | What to do |
|---|---|
| **Claude Code** (v2.1.277+, Sept 2026) | Reads `AGENTS.md` natively. Open this folder as the project. Say: *"Read AGENTS.md and start a hunting session on [target]."* |
| **Codex** | Reads `AGENTS.md` natively. Same as above. |
| **opencode** | Reads `AGENTS.md` natively. Same as above. |
| **Google Antigravity** | Reads `AGENTS.md` natively (also supports `.agents/rules/*.md`). Same as above. |
| **Cursor** | Copy `agent-configs/cursor-rules.mdc` to `.cursor/rules/bug-bounty.mdc` inside this folder (or your repo root). It points Cursor at `AGENTS.md`. |
| **Cline** | Copy `agent-configs/.clinerules` to the repo root (or merge into your existing `.clinerules`). It points Cline at `AGENTS.md`. |

Any agent that supports custom skills can also load `SKILL.md` as a skill entry point. See `agent-configs/README.md` for details.

---

## The operating loop

Every hunting session follows the same loop. Each workflow file is a complete, standalone procedure.

```
00 target-selection  -> pick a program with a live policy and clear scope
        |
01 recon             -> map the attack surface (passive -> active -> deep)
        |
02 threat-modeling   -> turn the map into ranked, testable hypotheses
        |
03 exploitation      -> run class-by-class playbooks against hypotheses
        |                (loop back to 02 as new surfaces appear)
04 technique-dev     -> R&D lab: derive, lab-test, and document NEW techniques
        |
05 cve-intel         -> check the target's stack against known CVEs / KEV / advisories
        |
06 writeup-mining    -> convert public writeups + CTF writeups into technique cards
        |
07 reporting         -> write the submittable report + posture analysis
        |
08 learning-debrief  -> explain everything to the operator, assign drills, plan next session
```

Workflows 04, 05, and 06 run continuously in the background of any session — they are the research engine that feeds 01–03.

---

## File map

```
bug-bounty-agent-pack-18/
├── AGENTS.md                        # Master instructions — agents read this first
├── SKILL.md                         # Skill-format entry point (invocable as a skill)
├── persona.md                       # The hunter identity: senior offensive security professional
├── rules-of-engagement.md           # Professional ROE — what makes findings valid and payable
├── README.md                        # This file
├── workflows/
│   ├── 00-target-selection.md       # Choosing programs and building a target dossier
│   ├── 01-recon.md                  # Full attack-surface mapping procedure
│   ├── 02-threat-modeling.md        # From attack surface to ranked hypotheses
│   ├── 03-exploitation-playbooks.md # 25+ vulnerability-class playbooks with PoC patterns
│   ├── 04-technique-development.md  # The R&D lab: deriving new offensive techniques
│   ├── 05-cve-intel-research.md     # CVE/NVD/KEV/advisory research workflow + scripts
│   ├── 06-writeup-mining.md         # Turning writeups into reusable technique cards
│   ├── 07-reporting.md              # Report anatomy, CVSS, triage psychology, posture annex
│   └── 08-learning-debrief.md       # Teaching the operator from roots, drills, skill tree
├── knowledge/
│   ├── fundamentals-101.md          # Networking + web security from absolute first principles
│   └── glossary.md                  # ~90 terms, one-line definitions, cross-referenced
├── templates/
│   ├── vulnerability-report-template.md
│   ├── hunting-notes-template.md
│   ├── technique-card-template.md
│   └── finding-ledger.csv
├── prompts/
│   ├── kickoff-prompt.md            # Paste to start a session on a target
│   ├── deep-dive-prompt.md          # Paste to deep-dive one endpoint/feature
│   └── technique-rnd-prompt.md      # Paste to run a pure R&D session
├── scripts/                         # Python 3.14, standard library only
│   ├── README.md
│   ├── cve_lookup.py                # NVD + CISA KEV lookup for a product/version
│   ├── scope_check.py               # Is this host in scope? (wildcard-aware)
│   └── js_secrets.py                # Pull JS files, hunt for keys/tokens/endpoints
└── agent-configs/
    ├── README.md                    # Where to put what, per agent
    ├── cursor-rules.mdc             # Cursor rule file (copy to .cursor/rules/)
    └── .clinerules                  # Cline rules file (copy to repo root)
```

---

## The three rules that override everything

1. **Only hunt what a live, published program policy authorizes.** The policy is the source of truth, read fresh, every time.
2. **Ask the operator before**: installing anything on Windows itself, adding MCP servers / plugins / skills, or creating accounts. **No need to ask**: `pip install` of Python libraries, and `git clone` / downloading small portable tools **into the workspace folder**.
3. **The report is the product.** Undocumented work is lost work. Notes get written every session, no exceptions.

Full operating rules: `rules-of-engagement.md`.

---

## Expansion log

Beyond the original request, this pack adds:

- `rules-of-engagement.md` — reframed as *operational* rules (not generic safety boilerplate) because policy discipline is literally what makes a finding payable and an account survive.
- **Security posture analysis annex** (in `07-reporting.md` and the report template) — every target gets a "does well / needs improvement / at risk / high risk" write-up for the operator's learning.
- `knowledge/` folder — `fundamentals-101.md` (networking + web security from zero) and `glossary.md`, because the operator is a student and asked for root-level explanations.
- `templates/finding-ledger.csv` — a running log of every finding across programs, so patterns and skill gaps become visible over time.
- `scripts/` — three standard-library-only Python tools (no installs needed) with teaching comments.
- `prompts/` — paste-ready kickoff / deep-dive / R&D prompts so any agent can be started in one line.
- `agent-configs/` — per-agent wiring files for Cursor and Cline, which don't read `AGENTS.md` natively.
- The **expansion-reporting directive** in `AGENTS.md`: whenever an agent adds ideas beyond the operator's instructions, it must report exactly what it added at the end.
