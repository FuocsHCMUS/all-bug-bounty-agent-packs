# agent-configs/ — wiring the pack into each agent

Most agents now read `AGENTS.md` natively; only Cursor and Cline need a small
wiring file. Verified against each vendor's docs as of November 2026.

| Agent | Native AGENTS.md? | What to do |
|---|---|---|
| **Claude Code** (v2.1.277+) | Yes — loads it automatically when CLAUDE.md is absent | Nothing. Open this folder as the project and start. |
| **Codex** (OpenAI) | Yes — root-to-leaf merge, 32 KiB default instruction limit | Nothing. Keep `AGENTS.md` concise; details live in workflows/. |
| **opencode** | Yes — global + project discovery | Nothing. Optional: add extra instruction files via `instructions` array in `opencode.json`. |
| **Google Antigravity** | Yes — plus `.agents/rules/*.md` with YAML frontmatter and `@` file references | Nothing required. Optional: copy this README's pattern into `.agents/rules/` if you want per-folder scoping. |
| **Cursor** | Yes — but project rules (.mdc) are more reliable for always-on context | Copy `cursor-rules.mdc` → `<repo-root>/.cursor/rules/bug-bounty.mdc`. |
| **Cline** | Detected, but `.clinerules` is the documented path | Copy `.clinerules` → `<repo-root>/.clinerules` (or merge into your existing file). |

## Setup recipes

### Cursor

```bash
mkdir -p .cursor/rules
cp bug-bounty-agent-pack-18/agent-configs/cursor-rules.mdc .cursor/rules/bug-bounty.mdc
```

The rule is `alwaysApply: true`, so every chat gets the pointer + summary and
Cursor will read the full `AGENTS.md` on demand.

### Cline

```bash
cp bug-bounty-agent-pack-18/agent-configs/.clinerules .clinerules
```

Cline auto-loads `.clinerules` from the workspace root. If you already keep
rules there, merge this file's content into yours.

### Claude Code / Codex / opencode / Antigravity

Open the repo root (the folder that contains `bug-bounty-agent-pack-18/`) so
`AGENTS.md` discovery finds the pack. In Claude Code, if you also keep a
`CLAUDE.md`, add one line to it: `@bug-bounty-agent-pack-18/AGENTS.md` — but
with v2.1.277+ you no longer need CLAUDE.md at all.

## Using the pack as a skill

`SKILL.md` is written in skill format (activation, capabilities, decision
matrix, required output blocks). If your agent supports skills/plugins that
consume a `SKILL.md`, point it at this file; otherwise agents can simply be
told "Read bug-bounty-agent-pack-18/SKILL.md and follow it" — the content is
agent-agnostic.

## Suggested output folders (created on demand by the agent)

```text
notes/       hunting notes + finding ledger (copied from templates/)
targets/     per-program dossiers, attack surface, hypotheses, evidence/
reports/     draft vulnerability reports ready for you to submit
techniques/  technique cards from R&D and writeup mining
workspace/   local labs, cloned portable tools, downloaded artifacts
```
