# Fundamentals 101 — Networking & Web Security from the Roots

This file explains the foundations from zero. Read it before your first hunt; return to it whenever a concept feels shaky. Each section follows the same ladder: the real-world problem → the mechanism that solves it → the trust boundary inside it → how the boundary fails → what a harmless observation looks like.

---

## 1. How two computers find each other

**Problem.** The internet is billions of devices. You cannot address a computer by "the one in the gray building." You need stable, unique addresses.

**Mechanism.** Every device gets an IP address (IPv4 like `203.0.113.7`, IPv6 like `2001:db8::1`). Data travels in packets: small envelopes that carry a piece of data plus source and destination addresses. Routers are mail-sorting offices: they read the destination and forward the packet one hop closer.

**Boundary.** Nothing on the internet checks whether a packet is "allowed" to visit a server. Arriving at an address is like walking up to a shop door: whether you may enter is a separate question.

**Failure mode.** If an address is reachable and a service is listening on a port, anyone may send it traffic. Ports are numbered doors on one machine: 80 and 443 for web, 22 for SSH, 5432 for a database. Security comes from what the service does with the traffic, not from the obscurity of the port.

**Beginner observation.** `ping example.com` shows that name resolution and reachability work. It proves nothing about authorization. A closed ping does not mean "secure," and an open port does not mean "vulnerable."

---

## 2. DNS — the phone book

**Problem.** Humans remember names; machines need numbers.

**Mechanism.** DNS maps names to addresses through a hierarchy: root servers → top-level domains (.com) → authoritative name servers for a domain. A resolver caches answers for a time called TTL. Common records: A (name → IPv4), AAAA (name → IPv6), CNAME (name → another name), MX (mail), TXT (free text, used for verification and security policies like SPF/DMARC), NS (who is authoritative).

**Trust boundary.** Your resolver trusts the authoritative server, and caches trust TTLs. When DNS says `api.example.com → 198.51.100.4`, everyone downstream believes it.

**Failure mode.** Subdomains that no longer have an owner (dangling CNAMEs) can sometimes be claimed by outsiders, after which traffic that still points there trusts the wrong server. Old DNS records, forgotten test hosts, and third-party services that were disconnected are classic leads.

**Observation.** `dig CNAME something.example.com` reveals chains. A record pointing to a decommissioned cloud service is a lead, not a finding, until ownership and impact are proven.

---

## 3. TLS — the sealed envelope

**Problem.** Postal networks have intermediaries. Without protection, anyone on the path can read or alter your mail.

**Mechanism.** TLS wraps traffic in encryption. The handshake verifies the server's certificate (issued by a Certificate Authority that vouches for the name) and establishes session keys. HTTPS is HTTP inside TLS.

**Trust boundary.** You trust: the CA system, the server's key, and the cipher choices. The browser shows a padlock, not a permission slip — encryption protects the path, not the integrity of the application behind it.

**Failure mode.** An application can be perfectly encrypted and perfectly vulnerable. TLS failures (expired certs, weak ciphers, missing HSTS) matter, but they are rarely the interesting bug. Do not confuse transport security with application security.

**Observation.** `curl -I https://example.com` shows the response headers. Look at `strict-transport-security`, `content-security-policy`, and friends as *signals* about the security posture — worth noting in a posture annex, rarely findings by themselves.

---

## 4. HTTP — the conversation

**Problem.** Clients and servers need a shared, simple language for requests and responses.

**Mechanism.** A request has a method (GET, POST, PUT, DELETE...), a path (`/invoices/42`), headers (metadata like `cookie`, `authorization`, `content-type`), and sometimes a body. A response has a status code (2xx success, 3xx redirect, 4xx client error, 5xx server error), headers, and a body. HTTP is stateless: the server remembers nothing between requests, so state is carried in cookies or tokens.

**Trust boundary.** Every header and body value is attacker-controlled input if the client is untrusted. The server must decide what each value means. A path, a header, a JSON field, and a file upload are four different parsers with four different rule books.

**Failure mode.** The client controls everything it sends. A hidden form field, a disabled button, a frontend route guard — none of these are security controls. Only the server's decision is.

**Observation.** Browser DevTools → Network tab shows every request your normal use makes. This is the single most valuable beginner tool: it turns a website into a readable conversation.

---

## 5. Cookies and sessions

**Problem.** HTTP forgot who you are between requests. Logging in on every click is unusable.

**Mechanism.** On login the server issues a session identifier (usually a cookie). The browser automatically attaches it to future requests to that site. Cookie attributes shape its risk: `HttpOnly` hides it from JavaScript, `Secure` restricts it to HTTPS, `SameSite` limits cross-site sending, `Domain`/`Path` set where it applies.

**Trust boundary.** The cookie is a bearer token: whoever presents it, *is* you, as far as the server cares. Theft equals identity. The server must still re-check authorization for every action — a valid session says who you are, not what you may do.

**Failure mode.** Session fixation (forcing a known session on a victim), missing invalidation after password change, and long-lived tokens without rotation are classic classes. Tokens accepted on unintended hosts or paths expand their own blast radius.

**Observation.** Compare cookies before/after login, after logout, and after a password reset on your own test account. Does the session identifier change where policy says it should?

---

## 6. Same-Origin Policy and CORS

**Problem.** One browser tab may host your bank; another may host an attacker's page. JavaScript in the attacker's tab must not read your bank's responses.

**Mechanism.** The Same-Origin Policy (SOP) says a script may only read responses from the same origin (scheme + host + port). CORS is the *relaxation* mechanism: the server can explicitly allow other origins via `access-control-allow-origin` headers.

**Trust boundary.** The origin is the browser's unit of trust. CORS is enforced by the browser *on behalf of the server's stated wishes*.

**Failure mode.** Reflecting an arbitrary `origin` header back with `access-control-allow-origin: <that origin>` plus credentials turns SOP off for everyone. Null-origin or wildcard-with-credentials configurations are other classic seams. Note: many "CORS misconfigurations" are harmless — the impact question is always "can a hostile site read data it should not?"

**Observation.** Send the same request with an unexpected `origin` header from your test account and compare response headers. That contrast is safe and readable.

---

## 7. Authentication vs authorization

**Problem.** Two different questions hide in "am I allowed?" — *who are you?* (authentication) and *what may you do?* (authorization). Systems that answer one and assume the other create the most common serious web bugs.

**Mechanism.** Authentication: password, MFA, SSO, tokens. Authorization: role/permission checks, object ownership checks, tenant isolation. Every request should re-ask authorization server-side.

**Trust boundary.** Authentication state arrives (cookie/token); authorization must be *decided* per action per object.

**Failure mode.** Broken object-level authorization (asking for object 41 when you own 42, and getting it) and broken function-level authorization (calling an admin endpoint as a member) dominate real-world reports. IDOR is the informal name for the first pattern.

**Observation.** Two operator-controlled test accounts, one object, one comparison. This is the safest, highest-yield experiment in all of web testing — it needs no payloads at all.

---

## 8. Tokens: JWT and friends

**Problem.** Servers in clusters do not want to look up every session in one shared database.

**Mechanism.** A JWT is a signed string: `header.payload.signature`, base64-encoded JSON. The signature lets any holder of the key verify integrity without a session store. Claims like `sub` (subject), `exp` (expiry), `aud` (audience), `iss` (issuer) carry identity and scope.

**Trust boundary.** The signature protects *integrity*, not *confidentiality* — anyone can read the payload. And a valid signature only means "issued by the key holder"; the server must still check expiry, audience, and that the claims authorize *this* action.

**Failure mode.** Accepting unsigned tokens (`alg: none`), ignoring `aud`/`iss` so a token from service A works on service B, treating "member" claims as admin truth, and never rotating keys. A base64 blob is not encryption: decode it in DevTools or `base64 -d` and read it.

**Observation.** Decode your own test-account token and inventory its claims. That alone often explains how a system reasons about identity.

---

## 9. Encoding, hashing, encryption — three different tools

**Problem.** These get confused constantly, and the confusion leads to wrong threat models.

**Mechanism.** Encoding (base64, URL-encoding) is a *representation* — reversible, no secret, not protection. Hashing (SHA-256) is a one-way fingerprint — used for integrity and password storage (with salt and a slow algorithm). Encryption protects *confidentiality* with a key — reversible only by key holders; signing protects integrity with a key.

**Boundary.** Any time data changes representation (encoded → decoded, JSON → object, path → file), two parsers now own the same bytes. Security decisions made on one representation can be bypassed by the other.

**Failure mode.** "It's base64, so it's safe" — no. Validation on the encoded form, sink on the decoded form; or a path canonicalized twice; or WAF sees one thing, database sees another. Parser disagreement is one of the deepest recurring themes in this craft.

---

## 10. Injection — when data becomes instructions

**Problem.** Programs mix instructions and data in one channel: SQL is text, HTML is text, shell is text, templates are text. The program must keep its parts separate from the user's parts.

**Mechanism.** Parameterized SQL separates query structure from values. HTML templating with context-aware escaping keeps user text as text. Command APIs with argument arrays avoid shell parsing. In each case, the fix is structural, not "filter bad characters."

**Boundary.** Wherever a string crosses from "data" into "interpreted," injection lives. The many flavors (SQL, command, template, expression, header, path, LDAP, XPath) are one idea wearing different uniforms.

**Failure mode.** Validation at the front door does not help if a different door feeds the sink. Trace source → transformations → sink before believing a control works.

**Beginner lab.** Any intentionally-vulnerable training app (locally installed) demonstrates this safely: craft a benign oracle, e.g. make the app print a fixed marker, proving evaluation, without touching destructive payloads. This pack's workflow 04 builds such labs.

---

## 11. XSS — the browser as the second computer

**Problem.** Browsers execute JavaScript in the origin of the page. If attacker text becomes attacker script in *your* users' browsers, the attacker's code runs with your origin's powers: read the DOM, call authenticated APIs, exfiltrate visible data.

**Mechanism.** XSS classes: *reflected* (input echoed in the response), *stored* (persisted, shown to others), *DOM-based* (client-side code writes untrusted data into dangerous sinks). The defense is output encoding in context (HTML body, attribute, JS string, URL differ) plus a Content-Security-Policy as a second layer.

**Boundary.** The server writes bytes; the browser interprets them in a context. The seam is "which context did the writer assume?"

**Failure mode.** Frameworks auto-escape common cases, so modern XSS tends to live in `dangerouslySetInnerHTML`-style escape hatches, URL/attribute contexts, or rich-text pipelines.

**Professional testing.** A unique inert marker string first (`zzmarkerzz`), inspect where and in what context it lands, then — only if policy allows — a harmless canary that proves execution without stealing anything. Cookies, tokens, and keystrokes are never the deliverable; the rendering context plus impact reasoning is.

---

## 12. SSRF and URL fetchers

**Problem.** Features like "import from URL," "webhook delivery," or "preview this link" make the *server* fetch a URL. From inside the network, the server can reach things outsiders cannot: internal dashboards, cloud metadata services, admin panels.

**Mechanism.** Cloud metadata endpoints (e.g. `169.254.169.254`) hand credentials to instances — historically without auth. SSRF that reaches them can turn a read bug into credential compromise.

**Boundary.** The URL parser, the DNS resolver, and the HTTP client may each see the destination differently (rebinding: resolving to a safe IP for the check, then a private IP for the fetch).

**Professional testing.** In bug bounty, use a collaborator/canary endpoint you control *if the policy allows callbacks*, demonstrate that a fetch occurred, and stop. Never probe internal ranges or metadata on production without explicit program permission; reproduce escalation locally.

---

## 13. Caches, CDNs, and shared responses

**Problem.** Serving every page from origin is slow, so caches store responses keyed by (roughly) URL + headers.

**Mechanism.** The cache key decides what makes a response "different." If the key ignores something that changes meaning (a header identifying the user, a path segment a router normalizes differently), responses can be served to the wrong audience or wrong route.

**Boundary.** Origin logic and cache logic must agree on what a request *means*.

**Failure mode.** Web cache deception (tricking a victim's browser into caching their private page under a guessable URL) and cache poisoning (getting attacker content stored under a popular key) are the famous patterns. Both require careful, polite, authorized testing with canaries — shared pages affect real users.

---

## 14. Race conditions and state machines

**Problem.** Two requests arriving "at the same time" interleave. If a check ("does the user have credits?") and the action ("spend a credit") are separate steps, another request can slip between them: time-of-check to time-of-use (TOCTOU).

**Mechanism.** Databases offer transactions, locks, and unique constraints. Application code must wrap check+action atomically; idempotency keys stop replays.

**Boundary.** The gap between "decision made" and "action applied."

**Failure mode.** Double-spend, double-redeem, duplicate withdrawals. High-impact and delicate: only ever demonstrated on operator-owned test objects with tight bounds, or in a local lab.

---

## 15. OAuth, SSO, and delegated identity

**Problem.** Users should not give your password to every app; apps should not see more than needed.

**Mechanism.** OAuth 2.0 delegates authorization: the app redirects you to the provider, you approve, the provider sends the app a code, the app exchanges it for tokens. OIDC adds identity on top (an ID token). Security rests on exact redirect URI matching, `state` (CSRF for the flow), `nonce` (replay), audience/issuer checks, and correct account-linking logic.

**Boundary.** The redirect is the moment control passes between parties. Every party must verify exactly what it received, from whom, intended for whom.

**Failure mode.** Open redirectors in the allowed redirect list, missing state validation, tokens accepted cross-audience, and "login with X" flows that link an attacker account to a victim's pending signup (pre-account takeover). All testable with two test accounts — no third parties involved.

---

## 16. What a SOC does (and why hunters should care)

**Problem.** Companies must detect abuse in progress, not only prevent it.

**Mechanism.** Logs funnel into a SIEM; detections (rules/analytics) fire alerts; analysts triage; incident response contains and remediates. Indicators of compromise (IoCs) and threat-intel feeds connect events across time.

**Why hunters care.** (1) Your test traffic is visible: stay low-volume and explainable. (2) Findings often include "was this detectable?" — a report that suggests a detection is worth gold. (3) The posture annex in workflow 07 asks exactly the SOC questions: logging, alerting, response readiness.

**Boundary.** Security events cross from application to detection. If nothing logs an authorization failure, prevention is the only line — that is a posture observation.

---

## 17. The hunting mindset, compressed

1. Model before testing: actors, assets, boundaries, intended rules.
2. Every input is attacker-controlled; every security decision must live server-side.
3. The cheapest experiment is a comparison, not a payload.
4. One variable at a time; a safe oracle per hypothesis; stop at proof.
5. Parsers and trust boundaries are where bugs breed; representations are where they hide.
6. A version string is a clue; reachability is the question; a safe check is the answer.
7. Write everything down as if a stranger must reproduce it — because a triager must.
8. Fix, retest, and teach: the loop that turns findings into skill.

---

## 18. A five-minute warm-up lab (no installs)

Open DevTools on any site you own or that explicitly allows study. Pick one request in the Network tab and answer, in writing: What method and path? Which headers carry identity? What does the server's decision appear to be (status + body)? Which part is the boundary? If you changed one value, what rule would you be testing? What response would prove the rule holds, and what response would prove it fails?

Congratulations: that written paragraph is the exact structure of a hypothesis record in workflow 02. Everything advanced in this pack is this loop, applied with more context.
