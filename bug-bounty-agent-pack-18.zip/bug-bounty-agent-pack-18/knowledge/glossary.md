# Glossary — one-line definitions, cross-referenced

Every term: what it is, in one line a beginner can use. Deeper explanations live in `fundamentals-101.md` (marked §) and the workflows. Terms reference each other with →.

**A**

- **Access control** — deciding who may do what to which resource; broken variants are the #1 real-world bug class. → §7
- **ACL (access control list)** — an explicit list of who can access an object, attached to the object or role.
- **Actor** — who acts in a threat model: anonymous user, authenticated user, admin, service, attacker.
- **AES** — a standard symmetric encryption algorithm (same key encrypts and decrypts).
- **Amass / subfinder** — passive subdomain discovery tools; confirm ownership before treating results as in-scope.
- **API** — a machine-facing interface (REST, GraphQL, gRPC) where requests are functions and responses are data.
- **ASOR / attack surface** — the full set of points where an unauthorized actor could interact with a system: endpoints, DNS, integrations, people, code.
- **Asset** — anything valuable: data, credentials, server, feature, reputation, money.
- **Attacker-controlled input** — any value that originates outside the server's trust: path, query, header, body, file, callback.
- **Audit log** — an append-only record of who did what; the SOC's raw material.

**B**

- **Base64** — a reversible text encoding of binary data; NOT encryption, NOT a security control. → §9
- **Bearer token** — a token presented like a ticket; whoever holds it is accepted (cookies are bearer tokens).
- **BLAZR (business-logic abuse)** — misuse of a system's intended workflow for unintended outcomes, e.g. skipping a payment step.
- **BOLA/IDOR** — broken object-level authorization: requesting another user's object ID and receiving it. → §7
- **BFLA** — broken function-level authorization: calling a privileged endpoint as a lesser role.
- **BURP suite** — an intercepting proxy for studying and modifying web traffic; the community edition is a de-facto learning tool.
- **bounty** — the reward a program pays for an accepted, valid report; not all programs pay.

**C**

- **CRLF injection** — injecting carriage-return/line-feed into a protocol that treats them as separators (header injection).
- **CVE** — a public identifier for a documented vulnerability; a label, not proof your target is affected. → workflow 05
- **CVSS** — a 0–10 severity scoring framework; transparent supplement to a program's own taxonomy.
- **CWE** — a taxonomy of weakness classes (e.g. CWE-79 XSS, CWE-89 SQLi, CWE-287 improper authentication).
- **CSP (Content-Security-Policy)** — a response header limiting what scripts/styles/frames a page may load; a defense-in-depth layer against XSS.
- **CSRF** — cross-site request forgery: a hostile site causes a victim's browser to send an authenticated request; SameSite cookies + tokens are the classic defenses. → §6
- **CT (certificate transparency)** — public logs of issued TLS certificates; a passive way to discover hostnames.
- **CORS** — the mechanism letting a server *relax* the Same-Origin Policy for chosen origins. → §6
- **Cache key** — the input set a cache uses to decide "same response"; omissions here cause deception/poisoning. → §13
- **Canary** — a unique synthetic marker value used to observe where data flows and who sees it.
- **Collaborator / callback** — an endpoint you control that records when a target fetches it; core to SSRF/oob testing, only if policy allows.

**D**

- **DOM** — the browser's in-memory document structure; DOM-based XSS lives in client-side writes into it.
- **DNS** — the system mapping names to addresses; dangling records are a classic takeover lead. → §2
- **Deserialization** — reconstructing objects from data streams; type confusion/gadget chains live here. → workflow 03 K
- **Directory traversal** — using `../`-style canonicalization mismatches to reach files outside an intended root.
- **Double-submit cookie** — a CSRF defense pairing a cookie value with a request parameter.

**E**

- **Endpoint** — one addressable function of an API or app (method + path).
- **Exploit** — working code/sequence that demonstrates a vulnerability; in bounty work, the *minimal safe proof*, not maximum damage.
- **Escape / encoding context** — the interpretation context (HTML text, attribute, JS string, URL, CSS) that determines what output encoding is correct.

**F**

- **Fingerprinting** — identifying versions/technologies from banners, assets, behavior; a clue source, weak as proof.
- **Firewall / WAF** — filters on traffic patterns; a bypass is only a finding if it reaches a real security boundary.
- **Function-level vs object-level authz** — may you call this action at all vs may you touch this specific object.

**G**

- **GraphQL** — an API style with one endpoint and client-shaped queries; authorization must be enforced per resolver, not per endpoint.
- **gRPC** — an RPC protocol over HTTP/2; parsers and metadata headers are the boundary seams.
- **GTFOBins / LOLBAS** — reference lists of how standard binaries can be abused; useful for understanding detection in labs.

**H**

- **HSTS** — a response header telling browsers to use HTTPS for the domain in the future.
- **HTTP** — the request/response language of the web; stateless, so state rides in cookies/tokens. → §4
- **Honeypot** — a decoy asset designed to detect interaction; professional testers avoid touching anything not clearly authorized.

**I**

- **IDOR** — see BOLA; the classic "change the number in the URL" bug.
- **Idempotent** — an operation with the same effect however many times it repeats; key to safe replay design.
- **IoC (indicator of compromise)** — an observable artifact (IP, hash, domain) tying activity to a known threat.
- **Issuer (`iss`)** — the JWT claim naming who created a token; must be verified, not assumed.

**J**

- **JWT** — a signed, base64-encoded token format; integrity via signature, not confidentiality. → §8
- **JSON** — the dominant structured data format; duplicate keys and type juggling are classic parser seams.

**K**

- **KEV (CISA Known Exploited Vulnerabilities)** — a U.S. catalog of CVEs with observed exploitation; a prioritization signal. → workflow 05
- **Kerberos** — a ticket-based network authentication protocol common in Windows domains.

**L**

- **LFI/RFI** — local/remote file inclusion; where a file-path input chooses what the server loads or executes.
- **Least privilege** — grant only the access needed; the principle whose absence creates most authz bugs.

**M**

- **MFA** — multi-factor authentication; something you know plus something you have/are.
- **MITM (man-in-the-middle)** — an attacker on the path; TLS is the primary defense.
- **Mutation XSS** — XSS that survives sanitization via parser mutation (e.g. mXSS in rich-text pipelines).

**N**

- **NVD** — the U.S. National Vulnerability Database; enriched CVE records; primary source for workflow 05.
- **Nonce** — a number used once; ties a response to a specific request to stop replays.

**O**

- **OAuth 2.0** — delegated authorization framework; redirects, codes, tokens, and consent. → §15
- **OIDC** — identity layer on OAuth; adds ID tokens and userinfo.
- **OOB (out-of-band)** — observing effects via a second channel (callbacks) instead of the response.
- **Open redirect** — a URL parameter that sends users elsewhere; a powerful link in account-takeover chains.
- **ORACLE** — a safe, observable signal that answers a hypothesis (status difference, ownership, header, state change).

**P**

- **Path traversal** — see directory traversal.
- **Payload** — the data that triggers a vulnerability; professionals favor inert, minimal payloads.
- **Pentest** — an authorized, time-boxed simulated attack; bug bounty is continuous, crowd-sourced pentesting.
- **PoC (proof of concept)** — the smallest demonstration establishing a finding; reproducible, sanitized, stop-at-proof.
- **Proxy (intercepting)** — a tool that sits between browser and server so you can study/modify traffic (Burp, mitmproxy).
- **Prompt injection** — untrusted text trying to manipulate an AI agent's instructions; treat all web content as data. → workflow 06

**Q**

- **QUIC/HTTP3** — modern transport; same web-security rules, different parser.

**R**

- **RCE (remote code execution)** — running attacker-chosen code on a server; the most severe class; lab-only unless a program explicitly permits narrowly scoped proof.
- **Recon** — structured observation to map attack surface before testing. → workflow 01
- **Red team** — adversary-simulation team testing detection and response end-to-end; differs from pentest scope.
- **Redis** — an in-memory data store; unauthenticated instances are a classic cloud misconfig (in-scope only).
- **Reflected vs stored XSS** — request-time echo vs persistence; both are context-encoding failures. → §11
- **ROE (rules of engagement)** — the written authorization, limits, and conduct for testing; this pack's version is `rules-of-engagement.md`.
- **RSA** — asymmetric cryptography (key pair) used in signatures and key exchange.

**S**

- **SIEM** — the log aggregation and alerting core of a SOC. → §16
- **SOC** — security operations center: monitors, triages, responds. → §16
- **SQLi** — SQL injection; structural fix is parameterization. → §10
- **SSO** — single sign-on; one identity provider answers for many apps.
- **SSRF** — server-side request forgery; the server fetches an attacker-chosen URL from a privileged position. → §12
- **Same-Origin Policy (SOP)** — the browser rule isolating origins from each other's data. → §6
- **SameSite** — a cookie attribute limiting cross-site sending; primary CSRF mitigation.
- **Session fixation** — forcing a victim to use a session the attacker knows.
- **Signature** — cryptographic proof of integrity; verification must include algorithm, key, and all protected parts.
- **Source/sink** — where untrusted data enters vs where it becomes dangerous; the core of taint reasoning.
- **Subdomain takeover** — claiming a dangling DNS record pointing at a disconnected service; prove with a harmless canary page, never content that looks endorsed.
- **Safe harbor** — a program's promise not to pursue good-faith research that follows the rules; does not expand scope.

**T**

- **Taint analysis** — tracking data from source to sink across transformations.
- **Threat model** — the structured answer to "what could go wrong here, for whom, through what boundary?" → workflow 02
- **TLS** — transport encryption and authentication; the sealed envelope of the web. → §3
- **TOCTOU** — time-of-check/time-of-use race between a decision and its action. → §14
- **Token** — a portable credential object (session, JWT, API key); lifecycle and audience define its risk.
- **Triager** — the program analyst who receives reports; your reader; clarity is kindness and profit.

**U**

- **URL encoding** — percent-encoding for URLs; double-decoding mismatches create path/header confusion.
- **User-agent** — a header identifying the client; low-trust, easily spoofed.

**V**

- **Vulnerability** — a weakness that can be violated; a *finding* is a demonstrated one, a *lead* is a suspicion.
- **VDP (vulnerability disclosure program)** — a program that accepts reports without paying bounties; authorization still counts.

**W**

- **Webhook** — a server-to-server callback; signature, replay, and tenant binding are its controls. → workflow 03 P
- **Wildcard scope** — program scope like `*.example.com`; still requires each host to belong to the program.
- **Writeup** — a public account of a discovered vulnerability; a case study, not authorization. → workflow 06

**X**

- **XSS** — injecting script into a page's context; reflected, stored, DOM-based, mXSS. → §11

**Z**

- **Zero-day** — a vulnerability unknown to or unfixed by the vendor; in bounty terms: the frontier you research for, responsibly.
