# Deep-Dive Prompt — one endpoint or feature

Paste into the agent mid-session.

---

Deep-dive session. Read `AGENTS.md` and today's `notes/hunting-notes-<date>.md` first.

- Target feature/endpoint: [e.g. "POST /api/v2/teams/:id/invites on app.example.com"]
- Program policy URL: [...]
- My accounts available: [roles, e.g. two test accounts: owner + member]

Do this:

1. Re-verify the feature is in scope (run `scripts/scope_check.py` if unsure). If not, stop and tell me.
2. Build the feature's model: actors, objects, states, intended rules, trust boundaries — in `targets/<slug>/deepdive-<feature>.md`, one section each, beginner-friendly.
3. Write an abuse-case tree (workflow 02 step 2) with at least 8 branches across identity/object/state/input/transport.
4. Convert the top branches into hypothesis records (HYP-xxx) with explicit oracles and validation rungs.
5. Execute only rungs L0–L3 (workflow 03): baseline → one-variable contrast → minimal proof on my own objects. Before any rung-3 request, tell me in one line what you'll send and why it's safe.
6. If anything suggests a parser/representation seam, route it through workflow 04 (local lab first).
7. Produce for each hypothesis: confirmed / weakened / dead end, plus evidence paths. Draft a report for anything confirmed using `templates/vulnerability-report-template.md`.
8. Debrief me: the concept ladder (problem → mechanism → boundary → failure → fix), the skill tree nodes I just practiced, and 1 drill.
9. Log everything in today's notes + ledger, and report expansions explicitly at the end.

Chat in Vietnamese, files in English. New concepts: explain from roots as they appear.
