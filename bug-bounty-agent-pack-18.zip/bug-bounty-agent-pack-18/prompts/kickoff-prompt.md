# Kickoff Prompt — start a hunting session

Paste this into the agent chat (Claude Code, Codex, opencode, Cursor, Cline, or Antigravity) with this pack folder open as the workspace.

---

Read `AGENTS.md`, `SKILL.md`, `persona.md`, and `rules-of-engagement.md` in this pack, then start a bug-bounty hunting session with these parameters:

- Program/target: [paste program URL or name, e.g. "HackerOne program X" or "https://bugcrowd.com/..."]
- Focus areas (optional): [e.g. API authorization, OAuth flows, file features]
- Timebox (optional): [e.g. 60 minutes]
- Learning goal (optional): [e.g. "I want to understand authorization testing deeply"]

Follow this procedure exactly:

1. Run `workflows/00-target-selection.md`: fetch the program policy fresh, build the dossier in `targets/<slug>/dossier.md`, and verify scope with `scripts/scope_check.py`. If the policy is missing or ambiguous, stay research-only and tell me what to confirm.
2. Run `workflows/01-recon.md` within the policy, labeling every observation FACT / INFERENCE / HYPOTHESIS / DEAD END, and write `targets/<slug>/attack-surface.md`.
3. Run `workflows/02-threat-modeling.md` and produce a ranked hypothesis backlog in `targets/<slug>/hypotheses.md`; pick at most three for this timebox and tell me why.
4. For the top hypotheses, follow `workflows/03-exploitation-playbooks.md` with the impact ladder: baseline, one-variable change, safe oracle, stop at proof. Anything above rung 3 on the ladder needs my explicit approval first — ask me in one short message with what/why/risk.
5. Run `workflows/05-cve-intel-research.md` against the observed stack using `scripts/cve_lookup.py` (leads only; verify against primary sources), and `workflows/06-writeup-mining.md` for any relevant public technique, turning each into a technique card in `techniques/`.
6. If a hypothesis is too risky for production, set up a local lab per `workflows/04-technique-development.md` instead (you may `pip install` freely and clone small portable tools into the workspace without asking; system installs, MCP/plugins/skills, and account creations still need my confirmation — propose them as a one-line request).
7. End the session with `workflows/07-reporting.md` (draft report in `reports/` for anything confirmed, plus the security posture annex: does well / needs improvement / at risk / high risk) and `workflows/08-learning-debrief.md` (concept ladder from the roots, drills for me, next-session plan).
8. Update `notes/hunting-notes-<date>.md` and `notes/finding-ledger.csv` as you go, not at the end.
9. Finish by reporting: STATUS / what you found or leads / what you deliberately did not do / any expansions beyond my instructions (list them explicitly) / what you need from me.

Explain new concepts to me from first principles as you go (problem → mechanism → boundary → failure → fix). Keep chat with me in Vietnamese; keep all files and the report in English.
