# scripts/ — stdlib-only Python tools (Python 3.14, Windows 11 friendly)

No third-party dependencies. Run with your normal Python. Every script is
read-only toward targets (small numbers of polite GETs), prints teaching notes,
and never sends discovered secrets anywhere.

| Script | What it does | When to use |
|---|---|---|
| `scope_check.py` | Seatbelt: match a host/URL against your typed scope file | ALWAYS, before first contact with any host (workflow 00) |
| `cve_lookup.py` | NVD + CISA KEV lead lookup for a product/version or single CVE | workflow 05 stack triage |
| `js_secrets.py` | Fetch a page's JS bundles, flag high-signal secrets/hosts/paths | workflow 01 passive recon |

## Examples

```bash
# scope seatbelt (exit code 0 = in scope, 1 = not, 2 = error)
python scope_check.py --scope scope.txt --host app.example.com
python scope_check.py --scope scope.txt --url https://app.example.com/pay/step2
python scope_check.py --scope scope.txt --batch hosts.txt

# CVE leads (results sorted newest-first; NVD keyword search is fuzzy —
# verify every lead against vendor advisories per workflow 05)
python cve_lookup.py --product nginx --version 1.24.0 --limit 15
python cve_lookup.py --product "exchange server" --kev-only
python cve_lookup.py --cve CVE-2024-12345

# JS recon
python js_secrets.py --url https://app.example.com/login --out js-findings.txt
python js_secrets.py --js https://app.example.com/static/main.js
```

## Scope file format (for scope_check.py)

```text
# one pattern per line; # comments; ! negation
app.example.com
*.api.example.com
https://app.example.com/pay
203.0.113.0/24
!staging.example.com
```

## Design rules (keep them for any new script added here)

1. Standard library first; announce any `pip install` in session notes.
2. Read-only toward targets: GETs with a distinct User-Agent, timeout, delay,
   hard input bounds, and a clear stop condition. Nothing state-changing.
3. Findings are LEADS: redacted output, never exfiltrated, never "used".
4. Deterministic and reviewable: a stranger should reproduce your run.
5. Teaching comments in the source — these scripts double as lessons.
