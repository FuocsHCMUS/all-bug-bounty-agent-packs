#!/usr/bin/env python3
"""cve_lookup.py — quick CVE leads for a product/version.

Purpose
    Given a product name (and optionally a version), query the NVD API 2.0 and
    the CISA KEV feed and print a *lead list*. This tool answers "which public
    CVEs mention this product?" — it never answers "is this target vulnerable?"
    (that requires the applicability reasoning in workflows/05).

Security & etiquette
    - Read-only HTTPS GET requests to public government APIs.
    - No API key required (NVD rate-limits anonymous clients; we sleep politely).
    - Standard library only — Python 3.14, no installs needed.
    - Output is leads only; verify against vendor advisories before reporting.

Usage
    python cve_lookup.py --product "nginx" [--version 1.24.0] [--limit 10]
    python cve_lookup.py --product "nginx" --kev-only
    python cve_lookup.py --cve CVE-2024-12345

Exit codes: 0 ok, 2 network/parse error, 3 bad arguments.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

NVD_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
USER_AGENT = "bug-bounty-agent-pack-18/1.0 (research leads; contact: operator)"
TIMEOUT = 30
POLITE_DELAY = 7  # seconds between NVD calls; anonymous quota is small


def http_get_json(url: str) -> dict:
    """GET a URL and parse JSON. Teaches: always set a UA and a timeout."""
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        if resp.status != 200:
            raise RuntimeError(f"HTTP {resp.status} from {url}")
        return json.loads(resp.read().decode("utf-8", errors="replace"))


def version_tuple(v: str) -> tuple:
    """'1.24.0' -> (1, 24, 0) for numeric-ish comparisons; non-numrics sort low."""
    parts = []
    for piece in re.split(r"[.\-+~]", v or ""):
        head = re.match(r"\d+", piece)
        parts.append(int(head.group()) if head else 0)
    return tuple(parts)


def version_in_range(ver: tuple, lo: str, hi: str, lo_inc: bool, hi_inc: bool) -> bool:
    """Check ver against (lo, hi]. NVD gives boundaries per metric version."""
    t_lo, t_hi = version_tuple(lo), version_tuple(hi)
    ok_lo = ver >= t_lo if lo_inc else ver > t_lo
    ok_hi = ver <= t_hi if hi_inc else ver < t_hi
    return ok_lo and ok_hi


def extract_descriptions(cve_item: dict) -> str:
    descs = cve_item.get("descriptions", [])
    for d in descs:
        if d.get("lang") == "en":
            return d.get("value", "")
    return descs[0].get("value", "") if descs else ""


def extract_metrics(cve_item: dict) -> str:
    """Pull the best available CVSS score/vector, preferring 3.1 > 3.0 > 2.0."""
    metrics = cve_item.get("metrics", {})
    for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        if key in metrics and metrics[key]:
            m = metrics[key][0].get("cvssData", {})
            score, vec = m.get("baseScore"), m.get("vectorString")
            if score is not None:
                return f"{score} {vec or ''}".strip()
    return ""


def search_nvd(product: str, version: str | None, limit: int) -> list[dict]:
    params = {"keywordSearch": product, "resultsPerPage": str(min(limit, 50))}
    url = f"{NVD_URL}?{urllib.parse.urlencode(params)}"
    data = http_get_json(url)
    out = []
    for item in data.get("vulnerabilities", []):
        cve = item.get("cve", {})
        cid = cve.get("id", "?")
        descs = extract_descriptions(cve)
        # NVD 2.0 keeps CVSS under cve.metrics; some records only carry it
        # inside containers.cna/adp — try both.
        metrics = extract_metrics(cve) or extract_metrics(cve.get("containers", {}).get("cna", {}))
        # version filtering (best-effort): scan the description for version ranges
        if version:
            # very rough: does the description mention the version at all?
            mentioned = version in descs
            out.append({
                "id": cid, "description": descs, "metrics": metrics,
                "version_mentioned": mentioned,
                "published": cve.get("published", ""),
            })
        else:
            out.append({"id": cid, "description": descs, "metrics": metrics,
                        "version_mentioned": None, "published": cve.get("published", "")})
    # NVD keyword search tends to return oldest-first; newest first is far
    # more useful for lead triage.
    out.sort(key=lambda r: r.get("published") or "", reverse=True)
    return out


def load_kev() -> dict[str, dict]:
    """Return {cve_id: kev_entry} from the CISA KEV JSON feed."""
    data = http_get_json(KEV_URL)
    return {e["cveID"]: e for e in data.get("vulnerabilities", []) if "cveID" in e}


def main() -> int:
    ap = argparse.ArgumentParser(description="CVE lead lookup (NVD + KEV). Leads only, not applicability.")
    ap.add_argument("--product", help="product name to search, e.g. nginx")
    ap.add_argument("--version", help="your observed version, e.g. 1.24.0")
    ap.add_argument("--cve", help="look up one CVE id")
    ap.add_argument("--limit", type=int, default=10, help="max results (1-50)")
    ap.add_argument("--kev-only", action="store_true", help="show only KEV-listed results")
    args = ap.parse_args()

    if not args.product and not args.cve:
        ap.error("provide --product and/or --cve")

    kev: dict[str, dict] = {}
    try:
        kev = load_kev()
        print(f"[i] KEV feed loaded: {len(kev)} known-exploited CVEs")
    except Exception as exc:  # KEV is an enhancement, not a requirement
        print(f"[!] KEV feed unavailable ({exc}); continuing without it", file=sys.stderr)

    if args.cve:
        cid = args.cve.upper()
        entry = kev.get(cid)
        print(f"\n=== {cid} ===")
        print("KEV:", "YES — " + (entry.get("knownRansomwareUse", "?")) if entry else "no")
        try:
            params = {"cveId": cid}
            data = http_get_json(f"{NVD_URL}?{urllib.parse.urlencode(params)}")
            vulns = data.get("vulnerabilities", [])
            if vulns:
                cve = vulns[0].get("cve", {})
                print("published:", cve.get("published"))
                print("description:", extract_descriptions(cve)[:600])
                print("cvss:", extract_metrics(cve))
            else:
                print("no NVD record found")
        except Exception as exc:
            print(f"[!] NVD lookup failed: {exc}", file=sys.stderr)
        return 0

    try:
        results = search_nvd(args.product, args.version, args.limit)
    except urllib.error.HTTPError as exc:
        if exc.code == 403:
            print("[!] NVD rate limit (403). Wait ~30s and retry, or use --cve for single lookups.", file=sys.stderr)
            return 2
        print(f"[!] NVD error: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"[!] lookup failed: {exc}", file=sys.stderr)
        return 2

    if not results:
        print("No results. Try a different product spelling or fewer words.")
        return 0

    print(f"\nLEADS for {args.product!r}"
          + (f" version~{args.version!r}" if args.version else "") + f" (limit {args.limit})\n")
    shown = 0
    for r in results:
        if args.kev_only and r["id"] not in kev:
            continue
        shown += 1
        kev_mark = " *KEV*" if r["id"] in kev else ""
        ver_note = " (version mentioned in text)" if r.get("version_mentioned") else ""
        print(f"- {r['id']}{kev_mark}  cvss: {r['metrics'] or 'n/a'}{ver_note}")
        text = " ".join(r["description"].split())
        print(f"  {text[:280]}{'…' if len(text) > 280 else ''}")
    if shown == 0:
        print("(no KEV-listed leads)")

    print("\n[nb] These are LEADS. Applicability needs: same component, affected range,")
    print("     reachable feature, preconditions, and a safe oracle — see workflows/05.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n[!] interrupted", file=sys.stderr)
        sys.exit(130)
