#!/usr/bin/env python3
"""js_secrets.py — find accidental secrets & interesting strings in JS bundles.

Purpose
    Fetch the JavaScript files linked by a page (or given directly) and hunt
    for high-signal accidental disclosures: API keys, tokens, private
    endpoints, internal hostnames. This is passive/low-impact recon: one GET
    per file, nothing injected, nothing scanned aggressively.

What it looks for (deliberately high-precision to avoid noise):
    - provider key shapes: AWS AKIA, Google AIza, Stripe sk_live/pk_live,
      GitHub ghp_/gho_/github_pat_, Slack xox, SendGrid SG., npm npm_, Twilio SK
    - generic assignments: api_key/token/secret/password = "..."  (flag for review)
    - JWT-shaped strings (ey...~ . ~ . signature)
    - URLs: internal-ish hostnames (dev/staging/vpn/intranet), private IPs
    - absolute API paths worth mapping

Etymology of care:
    - It does NOT brute-force endpoints or send the discovered keys anywhere.
    - A found key is NEVER used. Redact it, note the location, and report
      through the program's channel (workflow 03 section Q).
    - Rate: sequential, small delay, honors robots only as courtesy signal.

Usage
    python js_secrets.py --url https://app.example.com/login
    python js_secrets.py --js https://app.example.com/static/app.js
    python js_secrets.py --url ... --out findings.txt
"""

from __future__ import annotations

import argparse
import html
import re
import sys
import time
import urllib.parse
import urllib.request

USER_AGENT = "Mozilla/5.0 (research-recon; bug-bounty-agent-pack-18)"
TIMEOUT = 20
DELAY = 1.0  # seconds between fetches — be a polite guest

# Provider-shaped secrets: high confidence, low false-positive rate.
PROVIDER_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("aws-access-key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("google-api-key", re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b")),
    ("stripe-live-secret", re.compile(r"\bsk_live_[0-9a-zA-Z]{16,}\b")),
    ("stripe-live-publishable", re.compile(r"\bpk_live_[0-9a-zA-Z]{16,}\b")),
    ("github-classic", re.compile(r"\bgh[pousr]_[0-9A-Za-z]{36,}\b")),
    ("github-finegrained", re.compile(r"\bgithub_pat_[0-9A-Za-z_]{22,}\b")),
    ("slack-token", re.compile(r"\bxox[abposr]-[0-9A-Za-z\-]{10,}\b")),
    ("sendgrid", re.compile(r"\bSG\.[0-9A-Za-z_\-]{16,}\.[0-9A-Za-z_\-]{16,}\b")),
    ("npm", re.compile(r"\bnpm_[0-9A-Za-z]{36}\b")),
    ("twilio", re.compile(r"\bSK[0-9a-fA-F]{32}\b")),
    ("openai-style", re.compile(r"\bsk-[0-9A-Za-z_\-]{20,}\b")),
]

GENERIC_ASSIGN = re.compile(
    r"""(?ix)\b(api[_-]?key|apikey|access[_-]?token|auth[_-]?token|
        client[_-]?secret|secret|password|passwd|pwd|
        private[_-]?key|refresh[_-]?token|session[_-]?token)\b
        ["'']?\s*[:=]\s*["']([^"'\s]{8,256})["']""")

JWT_SHAPE = re.compile(r"\beyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\b")

SUSPICIOUS_HOST = re.compile(
    r"""(?xi)\b[\w.\-]*(?:dev|staging|stage|uat|qa|test|internal|intranet|
        vpn|admin|jenkins|gitlab|jira|confluence|kibana|grafana|sentry)
        [\w.\-]*\.(?:com|net|org|io|dev|app|co|local)\b""")

PRIVATE_IP = re.compile(
    r"\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}|"
    r"192\.168\.\d{1,3}\.\d{1,3}|127\.\d{1,3}\.\d{1,3}\.\d{1,3})\b")

ABSOLUTE_API = re.compile(r"""["'`](/(?:api|v[0-9]+|internal|admin)[/\w.\-]*)["'`]""")

SRC_HREF = re.compile(r"""(?:src|href)\s*=\s*["'']([^"']+\.js)(?:\?[^"']*)?["'']""", re.I)


def http_get(url: str) -> tuple[int, str]:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        body = resp.read().decode("utf-8", errors="replace")
        return resp.status, body


def resolve_url(base: str, candidate: str) -> str | None:
    candidate = html.unescape(candidate)
    if candidate.startswith("//"):
        return "https:" + candidate
    return urllib.parse.urljoin(base, candidate)


def extract_js_urls(page_url: str, page_html: str) -> list[str]:
    urls: list[str] = []
    for m in SRC_HREF.finditer(page_html):
        u = resolve_url(page_url, m.group(1))
        if u and u.startswith("http") and u not in urls:
            urls.append(u)
    return urls


def scan_text(text: str) -> list[tuple[str, str]]:
    """Return [(kind, matched_string)] — deduplicated, order preserved."""
    found: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()

    def add(kind: str, value: str) -> None:
        key = (kind, value)
        if key not in seen and len(value) < 4096:
            seen.add(key)
            found.append(key)

    for kind, pattern in PROVIDER_PATTERNS:
        for m in pattern.finditer(text):
            add("KEY:" + kind, m.group(0))
    for m in GENERIC_ASSIGN.finditer(text):
        add("ASSIGN:" + m.group(1).lower(), m.group(2))
    for m in JWT_SHAPE.finditer(text):
        add("JWT-shaped", m.group(0))
    for m in SUSPICIOUS_HOST.finditer(text):
        add("HOST:" + m.group(0), m.group(0))
    for m in PRIVATE_IP.finditer(text):
        add("PRIVATE-IP", m.group(0))
    for m in ABSOLUTE_API.finditer(text):
        add("API-PATH", m.group(1))
    return found


def redact(value: str) -> str:
    """Show shape without leaking the full value into logs/reports."""
    if len(value) <= 10:
        return value[:2] + "…" + value[-1:]
    return value[:8] + "…" + value[-4:]


def main() -> int:
    ap = argparse.ArgumentParser(description="Low-impact JS secret/asset hunter (recon leads only).")
    ap.add_argument("--url", help="page to pull <script src> from")
    ap.add_argument("--js", action="append", default=[], help="JS file URL to scan directly (repeatable)")
    ap.add_argument("--out", help="write findings to this file")
    ap.add_argument("--full", action="store_true", help="print full values (default: redacted)")
    args = ap.parse_args()

    if not args.url and not args.js:
        ap.error("provide --url and/or --js")

    targets: list[str] = []
    if args.url:
        try:
            status, page = http_get(args.url)
            print(f"[i] page {args.url} -> {status}, {len(page)} bytes")
            targets = extract_js_urls(args.url, page)
            print(f"[i] found {len(targets)} JS file(s) linked")
            # also scan the page itself — inline scripts often hold config
            targets = [args.url] + targets
        except Exception as exc:
            print(f"[!] failed to fetch page: {exc}", file=sys.stderr)
    targets.extend(args.js)

    all_findings: dict[str, list[tuple[str, str]]] = {}
    for url in targets:
        try:
            status, text = http_get(url)
            size = len(text)
            findings = scan_text(text)
            all_findings[url] = findings
            print(f"[i] {url} -> {status}, {size} bytes, {len(findings)} finding(s)")
        except Exception as exc:
            print(f"[!] {url}: {exc}", file=sys.stderr)
        time.sleep(DELAY)

    print("\n=== FINDINGS (leads — never use a discovered credential) ===")
    lines: list[str] = []
    for url, findings in all_findings.items():
        for kind, value in findings:
            shown = value if args.full else redact(value)
            line = f"{url}\n    {kind}: {shown}"
            lines.append(line)
            print(line)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
        print(f"\n[i] written to {args.out}")

    print("\n[nb] Next steps: confirm the artifact's purpose, check whether the")
    print("     secret is a dummy/test value, REDACT in notes, and report via the")
    print("     program channel. A public identifier (pk_live, SDK ids) is usually")
    print("     NOT a vulnerability by itself — impact reasoning required.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
