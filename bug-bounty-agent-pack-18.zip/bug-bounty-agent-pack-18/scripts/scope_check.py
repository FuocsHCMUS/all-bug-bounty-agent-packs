#!/usr/bin/env python3
"""scope_check.py — is this host explicitly in scope?

Purpose
    Mechanical guardrail against human error. You paste your program's scope
    patterns (from the policy you read *today*, not from memory) into a text
    file, then ask whether a host/path is authorized BEFORE sending requests.

Scope file format (one pattern per line, # comments allowed):
    app.example.com            exact host
    *.api.example.com          wildcard host (matches api.example.com and deeper? NO — one level only, like a policy usually means)
    https://app.example.com/pay  host + path prefix (path rules)
    203.0.113.0/24             CIDR
    !staging.example.com       negation (out of scope even if another rule matches)

Usage
    python scope_check.py --scope scope.txt --host app.example.com
    python scope_check.py --scope scope.txt --url https://app.example.com/pay/x
    python scope_check.py --scope scope.txt --batch hosts.txt     # one host per line

Teaching notes
    - This script can only match what you TYPED. If your scope file is stale,
      the check is garbage. The policy is the truth; this is a seatbelt.
    - Wildcard here means "one label", matching how most programs write it.
      A host like a.b.api.example.com needs two rules or an explicit check.
    - Exit codes: 0 = in scope, 1 = not in scope, 2 = error (e.g. bad file).
      Scripts can call this to gate themselves: scope_check || abort.
"""

from __future__ import annotations

import argparse
import fnmatch
import ipaddress
import sys
from dataclasses import dataclass
from urllib.parse import urlsplit


@dataclass
class Rule:
    raw: str
    pattern: str          # host pattern (possibly wildcard)
    path: str | None      # path prefix if the rule includes one
    negated: bool
    cidr: ipaddress._BaseNetwork | None


def parse_scope_file(text: str) -> list[Rule]:
    rules: list[Rule] = []
    for lineno, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        negated = line.startswith("!")
        if negated:
            line = line[1:].strip()

        cidr = None
        try:
            cidr = ipaddress.ip_network(line, strict=False)
        except ValueError:
            pass

        path = None
        pattern = line
        if cidr is None and "://" in line:
            parts = urlsplit(line)
            pattern = parts.hostname or ""
            path = parts.path or None
        elif cidr is None and "/" in line:
            # host/path form without scheme, e.g. app.example.com/pay
            host_part, _, path_part = line.partition("/")
            pattern = host_part
            path = "/" + path_part

        pattern = pattern.lower().lstrip(".")
        if not pattern and cidr is None:
            print(f"[!] line {lineno}: no host in {raw!r}, skipping", file=sys.stderr)
            continue
        rules.append(Rule(raw=raw, pattern=pattern, path=path, negated=negated, cidr=cidr))
    return rules


def host_matches(pattern: str, host: str) -> bool:
    """Exact or one-level wildcard. '*.api.example.com' matches 'api.example.com'
    and 'v1.api.example.com' but NOT 'a.b.api.example.com'."""
    if pattern.startswith("*."):
        parent = pattern[2:]
        return host == parent or host.endswith("." + parent) and "." not in host[: -len(parent) - 1]
    return fnmatch.fnmatchcase(host, pattern)


def check(host: str, path: str | None, rules: list[Rule]) -> tuple[bool, Rule | None, Rule | None]:
    """Returns (allowed, matching_allow_rule, matching_deny_rule)."""
    host = (host or "").lower().rstrip(".")
    allowed_by: Rule | None = None
    denied_by: Rule | None = None
    for r in rules:
        if r.cidr is not None:
            try:
                addr = ipaddress.ip_address(host)
                if addr in r.cidr:
                    if r.negated:
                        denied_by = r
                    else:
                        allowed_by = r
            except ValueError:
                continue  # host is a name, rule is CIDR; policy nuance for a human
            continue
        if host_matches(r.pattern, host):
            if r.path is not None:
                if path and path.startswith(r.path):
                    if r.negated:
                        denied_by = r
                    else:
                        allowed_by = r
                continue  # path rule with no path match: no decision
            if r.negated:
                denied_by = r
            else:
                allowed_by = r
    return (denied_by is None and allowed_by is not None, allowed_by, denied_by)


def split_target(target: str) -> tuple[str, str | None]:
    if "://" in target:
        parts = urlsplit(target)
        return (parts.hostname or ""), (parts.path or None)
    if "/" in target:
        h, _, p = target.partition("/")
        return h.lower(), "/" + p
    return target.lower(), None


def main() -> int:
    ap = argparse.ArgumentParser(description="Mechanical scope seatbelt. The policy is still the truth.")
    ap.add_argument("--scope", required=True, help="scope file, one pattern per line")
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--host", help="hostname to check")
    group.add_argument("--url", help="full URL to check (host + path)")
    group.add_argument("--batch", help="file with one host/URL per line")
    args = ap.parse_args()

    try:
        text = open(args.scope, encoding="utf-8").read()
    except OSError as exc:
        print(f"[!] cannot read scope file: {exc}", file=sys.stderr)
        return 2
    rules = parse_scope_file(text)
    if not rules:
        print("[!] scope file has no usable rules", file=sys.stderr)
        return 2

    targets: list[str] = []
    if args.host:
        targets = [args.host]
    elif args.url:
        targets = [args.url]
    else:
        try:
            targets = [ln.strip() for ln in open(args.batch, encoding="utf-8") if ln.strip() and not ln.startswith("#")]
        except OSError as exc:
            print(f"[!] cannot read batch file: {exc}", file=sys.stderr)
            return 2

    failures = 0
    for t in targets:
        host, path = split_target(t)
        if not host:
            print(f"??  {t}: unparseable")
            failures += 1
            continue
        ok, allow, deny = check(host, path, rules)
        if deny is not None:
            print(f"NO  {t}  (excluded by: {deny.raw})")
            failures += 1
        elif ok and allow is not None:
            print(f"YES {t}  (matched: {allow.raw})")
        else:
            print(f"NO  {t}  (no rule matched — treat as OUT unless the policy says otherwise)")
            failures += 1

    print("\n[nb] YES means 'matches the patterns you typed'. Verify the scope file")
    print("     against today's policy before trusting it. Ambiguous ownership,")
    print("     third-party hosts, and path-less wildcard mismatches need human eyes.")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
