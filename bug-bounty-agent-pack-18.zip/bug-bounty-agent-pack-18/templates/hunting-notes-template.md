# Hunting Notes — YYYY-MM-DD

## Session header

```yaml
program:
policy_url:
policy_verified_at_utc:
target_assets:
timebox:
request_budget:
test_accounts: [roles only, no credentials here]
phase: 00|01|02|03|04|05|06|07|08
```

## Plan for today

1. [...]
2. [...]
3. [...]

## Observations log

Format every entry as:

```text
HH:MM | FACT/INFERENCE/HYPOTHESIS | source or request | observation | confidence | next
```

Example:

```text
14:05 | FACT | GET /api/v2/orders (test account, role member) | response includes order.owner_email in body | high | check whether owner_email is another tenant's on contrast request
```

## Hypotheses touched

| ID | Claim | Status | Oracle | Result |
|---|---|---|---|---|
| HYP-001 | ... | queued/testing/weakened/confirmed/blocked | ... | ... |

## Evidence written

- `targets/<program>/evidence/<file>` — what it is, sanitized.

## Decisions and stop events

- HH:MM — decision — reason.

## New concepts encountered (for debrief)

- [term] — one-line definition in my own words — where it appeared.

## Posture observations

| Area | Observation | Confidence | Risk label | Evidence |
|---|---|---|---|---|
| authorization | ... | ... | does-well / needs-improvement / at-risk / high-risk | ... |

## Tools/dependencies used or requested

- [tool/lib] — purpose — install type (pip / portable clone / needs operator approval).

## Open questions for next session

1. [...]

## Expansion log (agent fills in)

- [idea/file/method added beyond operator's request] — why.
