# Technique Card — [Name]

```yaml
id: TECH-NNN
name: [short, memorable name]
primitive: [one sentence: the mechanism, no target names]
status: research_only | lab_confirmed | safe_to_validate | confirmed_finding | blocked
origin: [writeup / CVE / patch-diff / CTF / self-derived — with links]
created: YYYY-MM-DD
last_updated: YYYY-MM-DD
related: [CVE-... CWE-... ATT&CK-... other TECH-...]
```

## The primitive (abstract)

2–5 sentences. Explain the mechanism so it survives version churn: which components disagree, about what, and why that disagreement matters for security. No payload trivia.

## Preconditions

- [component/feature required]
- [configuration/flag required]
- [attacker position required]
- [state required]

## Trust boundary / component seam

Which two components disagree, and which one's belief wins. Draw it:

```text
component A (believes X) → passes value to → component B (believes Y)
security decision made at: [point]
decision made on representation: [encoded/decoded/canonical form]
```

## Variation matrix (brainstorm)

| Dimension | Variations worth testing | Why it might matter |
|---|---|---|
| representation | ... | ... |
| identity | ... | ... |
| state | ... | ... |
| transport | ... | ... |
| oracle | ... | ... |

## Local lab recipe

- App/lab used: [name + version + source link or "toy implementation in this repo"]
- Synthetic data: [...]
- Weakened control: [...]
- Fixed control: [...]
- Assertion/oracle: [...]
- Command sequence (safe, inert):

```bash
# example
python -I lab/run_experiment.py --case 01
```

- Expected: baseline passes; weakened fails; fixed passes.

## Expected oracle

What observation proves the primitive worked, in the safest possible form.

## False positives and disproof checks

- [what looks like this bug but isn't]
- [what would make this a real bug]
- [how to rule out cache/proxy/test-harness artifacts]

## Production validation constraints

- What must be true about the program policy to test on a real target.
- The maximum rung on the impact ladder allowed.
- The stop condition.

## Fix pattern and retest

- The control that closes it.
- The regression test that proves it's closed.

## Skill prerequisites

What the operator should be comfortable with before studying this: [concepts, with links into knowledge/].

## Teaching note (operator)

- The real-world problem this class of bug creates.
- The one-sentence takeaway.
- A drill idea.
