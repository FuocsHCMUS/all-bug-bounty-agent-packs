# Workflow 00 — Target Selection, Authorization & Dossier

## Purpose

Choose a program that is genuinely authorized, learn its rules, and create a target dossier before any active request. The goal is not to find the most famous company; it is to find a target whose scope, policy, test accounts, and reporting path are clear enough to support high-quality research.

## Inputs

The operator may provide a platform, program URL, company, asset, technology focus, time budget, or learning goal. Missing inputs are not permission to guess. If no target is supplied, perform public research and propose three candidates without probing them.

## Phase A — Find candidate programs

Search official program directories and the program's own security page. Useful sources include HackerOne, Bugcrowd, Intigriti, YesWeHack, Google VRP, GitHub Security, Microsoft Security Response Center, Apple Security Bounty, and vendor-specific programs. Record the canonical program URL, platform, current status, reward range if published, and last policy update.

Prefer candidates with a clear asset table, explicit exclusions, test-account instructions, safe-harbor language, and a responsive disclosure channel. Prefer a small, well-defined web application over a huge wildcard when the operator is learning. Treat a program landing page as a directory; the actual policy and asset list are the authority.

## Phase B — Read and normalize policy

Create `targets/<program-slug>/dossier.md` and copy the following fields:

```yaml
program_name:
platform:
policy_url:
canonical_security_page:
policy_checked_at_utc:
policy_revision_or_last_updated:
status: active | paused | private | unknown
operator_focus:
allowed_researcher_accounts:
```

Then normalize the policy into these sections:

```text
IN-SCOPE ASSETS:
OUT-OF-SCOPE ASSETS:
IN-SCOPE VULNERABILITY CLASSES:
EXCLUDED / NOT-ELIGIBLE CLASSES:
AUTHENTICATION AND TEST-ACCOUNT RULES:
RATE, CONCURRENCY, AND AUTOMATION RULES:
DATA-HANDLING AND PRIVACY RULES:
PROHIBITED TESTS:
DISCLOSURE / PUBLICATION RULES:
DUPLICATE / KNOWN-ISSUE RULES:
BOUNTY / ELIGIBILITY NOTES:
CONTACT / ESCALATION PATH:
UNRESOLVED QUESTIONS:
```

Quote short policy excerpts with links and timestamps. Do not paste an entire copyrighted page when a summary and link are enough. Mark each field `confirmed`, `inferred`, or `unknown`.

## Phase C — Resolve scope

Use `scripts/scope_check.py` with a local scope file. The scope file should contain one pattern per line, such as an exact hostname, a wildcard hostname, or a URL path prefix when the program's rules are path-specific. The script is a guardrail for human error, not proof of authorization.

For each candidate asset, record DNS ownership clues, certificate names, platform mapping, and whether the asset resolves to a third party. A wildcard does not automatically cover a SaaS vendor, a parked domain, a CDN, or a customer-controlled tenant. If ownership is ambiguous, stop and ask the program.

## Phase D — Choose the first research slice

Do not begin with “scan everything.” Select one bounded slice using this score:

```text
priority = (potential_impact × confidence_of_scope × learning_value × likelihood)
           / (validation_cost × production_risk)
```

Use a qualitative 1–5 score. Good first slices include a documented API area, a role-sensitive workflow, a file import/export feature, a webhook/integration boundary, a password-reset flow, a tenant invitation flow, or a public client bundle. Avoid high-impact areas that require destructive behavior.

## Phase E — Dossier acceptance checklist

Before active testing, the agent must be able to answer yes to every item:

- The current policy URL is recorded.
- The exact host/path is explicitly in scope or unambiguously covered.
- The planned request type is allowed.
- A test account or synthetic data strategy is available if needed.
- The expected impact is low and the stop condition is clear.
- The agent has a notes path and evidence path.
- The operator knows what external tools or libraries will be used.
- The agent has a rollback/stop plan if the service behaves unexpectedly.

If any answer is no, status is `BLOCKED` or `RESEARCH-ONLY`.

## Output: target dossier

End the file with:

```markdown
## Authorization decision
- Decision: APPROVED_FOR_LOW_IMPACT_TESTING | RESEARCH_ONLY | BLOCKED
- Basis: [policy URL + relevant section]
- Approved slice: [one bounded area]
- Maximum request budget: [number / rate / duration]
- Stop conditions: [specific signals]
- Operator approval still required for: [list]
- Next workflow: 01-recon | ask operator | local-lab reproduction
```

## Beginner lesson

A scope list is like a property boundary on a map. A hostname that looks related may still belong to a different owner. Safe harbor is like a promise not to punish good-faith work that follows the rules; it is not a deed to every neighboring property. The dossier turns vague intent into a testable authorization record.
