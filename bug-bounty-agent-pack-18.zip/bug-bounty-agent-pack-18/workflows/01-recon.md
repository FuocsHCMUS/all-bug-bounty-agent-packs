# Workflow 01 — Reconnaissance & Attack-Surface Mapping

## Purpose

Build an accurate map of an authorized target before forming exploit hypotheses. Recon is not “run a giant scanner.” It is structured observation: identify components, trust boundaries, roles, state transitions, data flows, and places where two components may disagree.

## Recon contract

Every observation is labeled as one of:

- **FACT:** directly observed from an allowed source.
- **DOCUMENTED:** stated by the program or vendor.
- **INFERENCE:** a reasoned interpretation that needs confirmation.
- **HYPOTHESIS:** a possible weakness to test.
- **DEAD END:** a tested idea that did not reproduce under stated conditions.

Log timestamp, source, account/role, request budget, and confidence. Never treat a port, endpoint, JavaScript string, or error message as proof of a vulnerability.

## Phase 0 — Prepare the notebook

Create:

```text
notes/hunting-notes-YYYY-MM-DD.md
targets/<program-slug>/attack-surface.md
targets/<program-slug>/evidence/
```

Copy the policy scope into the notes. Define a request budget and a stop condition. Use synthetic canary values. Create an account/role matrix if the policy allows multiple test accounts.

## Phase 1 — Passive map

Collect only information that is public or explicitly allowed:

- Program documentation, changelogs, API docs, OpenAPI descriptions, SDKs, and client bundles.
- DNS and certificate transparency names that map back to in-scope ownership.
- Public package metadata, version strings, vendor advisories, and published source.
- Public error documentation and normal browser-visible routes.
- Public repositories, issue discussions, and writeups, treated as historical context.

For each artifact, record the URL, retrieval time, version, and whether it is authoritative. Do not copy secrets into notes. If a public artifact contains a credential, do not use it; redact it, record the location, and report through the appropriate channel.

## Phase 2 — Normal-traffic map

With the permitted test account, observe ordinary product flows. Capture a redacted request/response pair for each major feature. Create a table:

| Feature | Actor/role | Asset | State change | API route | Trust boundary | Notes |
|---|---|---|---|---|---|---|
| sign-up | anonymous | account | creates pending user | ... | public → identity | ... |
| invite | owner/admin | membership | adds member | ... | tenant A → tenant A | ... |
| export | member | report | creates file | ... | app → object storage | ... |

Do not guess routes by spraying. Follow links, browser network logs, documented API calls, and bounded wordlists only when the policy allows them.

## Phase 3 — Identity and authorization map

Build a role matrix. Use two or more operator-controlled test accounts only when permitted. Test the same normal action as each role, then observe whether the server—not merely the UI—enforces the intended decision. The safe contrast is “my object versus my other test account's object,” never a random user's record.

Record:

```text
role A can:
role B can:
role C can:
object owner relationship:
tenant relationship:
server-side decision point:
client-only control observed:
```

## Phase 4 — Data-flow and parser map

For each input, follow it through the system:

```text
source → validation → normalization → storage → queue/cache → sink → response
```

Mark boundaries where data changes representation: URL to filesystem path, JSON to template, string to SQL query builder, archive to extracted files, user text to Markdown/HTML, webhook to internal job, or token to identity. Note which component performs canonicalization and whether later components repeat it.

This phase generates hypotheses without executing dangerous payloads. A parser disagreement is a clue: it becomes a finding only if a safe, authorized contrast demonstrates a security boundary failure.

## Phase 5 — Client-side and integration map

Inspect client code for routes, feature flags, API schemas, source maps, storage use, message origins, third-party integrations, and error handling. Treat client-side restrictions as hints, not authorization. Map webhooks, OAuth redirect destinations, SSO metadata, cloud storage links, email/SMS flows, and CI/CD hooks only if they are in scope.

## Phase 6 — Bounded active discovery

Only after policy verification, use small, polite, bounded checks. Every command must show:

```text
scope input | request count | concurrency | delay | timeout | user agent | output path | stop condition
```

Prefer one request per hypothesis over broad enumeration. If a tool wants to scan more than the policy permits, do not run it. Ask the operator before any new system install; keep portable tools in the workspace.

## Phase 7 — Attack-surface map output

Write `attack-surface.md` with these sections:

1. Executive map: application, API, identity, storage, integrations, operations.
2. Assets and sensitivity: account data, tenant data, secrets, financial or health data, internal actions.
3. Roles and trust boundaries.
4. Endpoints/features grouped by function.
5. Input and parser boundaries.
6. Technology/version clues with confidence and source.
7. Candidate hypotheses, not findings.
8. Gaps and unknowns.
9. Request budget and test log.
10. Next step and stop conditions.

## Beginner lesson

Recon is like learning a city's roads before asking where a bank is vulnerable. A route tells you where traffic goes; a trust boundary tells you who is supposed to be allowed through. The most useful recon question is not “what else can I scan?” but “which boundary would matter if it failed, and what harmless observation would reveal that?”
