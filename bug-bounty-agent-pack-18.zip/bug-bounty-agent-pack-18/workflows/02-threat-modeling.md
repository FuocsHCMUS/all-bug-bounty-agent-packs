# Workflow 02 — Threat Modeling & Hypothesis Backlog

## Purpose

Turn the attack-surface map into a small queue of testable, prioritized hypotheses. A hypothesis is a claim that can be supported or weakened by a controlled observation. It is not a payload, a hunch presented as fact, or a copied trick from a writeup.

## Step 1 — Define the security question

For each feature, write a sentence in this form:

> Can **actor A** cause **component B** to perform **action C** on **asset D** outside the intended **rule E**, through **boundary F**, without **control G**?

Examples of neutral questions:

- Can a member cause the server to return an object owned by another operator-controlled tenant?
- Can a value accepted by an import parser reach a more privileged sink than intended?
- Can a state transition be completed without the prerequisite approval?
- Can a cache or queue serve a response under the wrong identity or freshness assumption?
- Can a disclosed dependency version plausibly match a vendor advisory, and is the affected feature reachable?

## Step 2 — Build an abuse-case tree

For each feature, branch by:

```text
identity: anonymous / user / member / owner / admin / service
object: own / peer test account / other tenant / public / deleted / stale
state: before / during / after / repeated / concurrent
input: empty / long / encoded / duplicated / alternate type / boundary value
transport: browser / API / webhook / job / export / callback
component: frontend / gateway / app / worker / cache / storage / third party
```

The agent may brainstorm unusual combinations, but every branch must be narrowed to a safe observation before execution.

## Step 3 — Score hypotheses

Use a 1–5 qualitative score:

```text
impact:        confidentiality + integrity + availability + business effect
likelihood:    evidence of reachable precondition and weak control
novelty:       not already obvious from public documentation
confidence:    quality of the current evidence
learning:      value to the operator's skill growth
cost:          time, request budget, and lab effort
risk:          production, privacy, and policy risk
priority = (impact + likelihood + novelty + confidence + learning)
           / (cost + risk)
```

A low-risk, high-learning hypothesis may outrank a speculative critical chain. Do not equate severity with priority.

## Step 4 — State the expected oracle

Every hypothesis needs an oracle: a safe, observable difference between the intended and unintended behavior. Examples include a documented status difference, a test object's ownership, a response header, an application state transition, a redacted field, a queue result, or a deterministic local-lab assertion. If there is no oracle, redesign the hypothesis.

## Step 5 — Define a validation ladder

```text
L0: documentation/source comparison
L1: normal request baseline
L2: controlled contrast with synthetic data
L3: single minimal proof on an operator-controlled object
L4: local-lab reproduction for risky behavior
STOP: evidence sufficient for a report
```

Do not jump from L1 to high-impact production testing. If a finding is established at L2 or L3, stop.

## Step 6 — Look for chains responsibly

Represent a chain as a graph:

```text
primitive A --enables--> state B --exposes--> asset C
```

For every edge, record evidence and dependency. If any edge is merely assumed, mark the chain `unconfirmed`. Report the confirmed primitive even when the full chain cannot be safely demonstrated.

## Step 7 — Hypothesis record

Use this structure for each item:

```markdown
### HYP-001 — [short claim]
- Status: queued | testing | weakened | confirmed | blocked
- Feature / boundary:
- Actor and test account:
- Intended rule:
- Suspected failure:
- Evidence so far:
- Expected safe oracle:
- Validation rung:
- Request budget:
- Impact if true:
- Production risk:
- Local-lab alternative:
- Stop condition:
- Result:
- Next action:
- Learning concept:
```

## Step 8 — Prioritization review

Before testing, select at most three hypotheses for the current timebox. Explain why the others wait. This prevents the agent from wandering into unbounded scanning and gives the operator a clear learning path.

## Beginner lesson

Threat modeling is asking “what could go wrong?” in a structured way. An asset is something worth protecting; an actor is who acts; a trust boundary is where permissions or assumptions change; a threat is a way the intended rule could fail; a control is what should stop it. A hypothesis makes that story falsifiable.
