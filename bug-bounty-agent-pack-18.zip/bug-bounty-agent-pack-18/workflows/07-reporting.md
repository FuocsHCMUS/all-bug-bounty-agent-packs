# Workflow 07 — Reporting, Triage & Security Posture Annex

## Purpose

Turn evidence into a report a program can reproduce, triage, fix, and retest. A report is not a story about how clever the researcher was; it is a compact engineering ticket with a clear security consequence.

## Report gate

Only call a result `confirmed` when the asset is authorized, the behavior is reproducible, the security rule is clear, and the impact is supported by evidence. If version or impact is inferred, say so. If the proof is blocked by policy or risk, report it as a lead or ask the program for permission rather than overstating it.

## Report anatomy

Use `templates/vulnerability-report-template.md` and include:

1. **Title:** `[class] [asset/feature] allows [security boundary failure]`.
2. **Summary:** two or three sentences: who can do what, to which asset, and why it matters.
3. **Asset and scope basis:** exact host/path, program URL, policy clause, and test date.
4. **Preconditions:** account role, tenant, feature flag, version, and setup.
5. **Reproduction:** numbered minimal steps with sanitized requests and responses.
6. **Expected versus actual:** state the intended rule and observed failure.
7. **Impact:** specific confidentiality, integrity, availability, privacy, or business consequence; avoid speculative escalation.
8. **Evidence:** screenshots/logs/request IDs with secrets and personal data redacted.
9. **Root cause:** the missing or inconsistent control, not merely “input is bad.”
10. **Remediation:** a prioritized fix direction and defense-in-depth ideas.
11. **Severity rationale:** use the program's taxonomy first; use CVSS as a transparent supplement, not an automatic bounty amount.
12. **Retest plan:** exact expected fixed behavior.
13. **Disclosure notes:** follow the policy; no public disclosure unless explicitly permitted.

## Severity reasoning

Explain each CVSS-like dimension in plain language: attack vector, complexity, privileges, interaction, scope, confidentiality, integrity, and availability. Use the lowest severity supported by the demonstrated impact, and state what additional evidence would change the rating. A critical-sounding title cannot substitute for a demonstrated consequence.

## Triage-friendly evidence

Provide a baseline and a contrast. Include the account roles and object ownership. Use one synthetic identifier, not a dataset. Put long raw material in an attached artifact or local evidence path as allowed by the platform. Redact cookies, tokens, keys, addresses, names, payment data, and internal identifiers. If the platform supports private attachments, use them only when necessary.

## Remediation quality

A useful remediation explains where the invariant should be enforced and how to test it. For authorization: server-side policy checks, object ownership/tenant binding, deny-by-default, and regression tests. For injection: parameterization, context-aware encoding, safe parser modes, and negative tests. For secrets: revoke/rotate, remove from history and artifacts, scope privileges, and add detection. For state bugs: atomic transitions, idempotency, replay protection, and concurrency tests.

## Security posture annex

After every finding or substantial assessment, produce a separate learning annex. It is an assessment of observable engineering practices, not a claim about the entire company. Use confidence labels and evidence links.

### What the organization appears to do well

Look for evidence such as a clear vulnerability disclosure policy, safe-harbor language, documented scope, security contact, MFA, strong cookie attributes, modern headers, dependency update cadence, authorization tests, rate controls, secure defaults, incident response contact, and a responsive triage process. Avoid praising a control that was not observed.

### What needs improvement

Describe concrete gaps: inconsistent authorization across endpoints, unclear asset ownership, stale versions, missing security headers where relevant, weak error handling, insufficient test-account documentation, unclear disclosure instructions, missing regression tests, or dependency visibility gaps. Tie each gap to a risk and a practical improvement.

### At risk

Use this label for conditions that could become harmful under common preconditions: exposed attack surface, weak tenant binding, high-risk integration without clear signature validation, unmaintained client dependencies, or a recovery flow with ambiguous state. Explain confidence and what evidence is missing.

### High risk

Reserve this label for demonstrated or strongly evidenced issues with material confidentiality, integrity, availability, privacy, or business impact, and distinguish “high risk control gap” from “confirmed vulnerability.” Avoid extrapolating from one endpoint to the whole company.

### Posture table

| Area | Observation | Evidence | Confidence | Risk | Improvement | Retest signal |
|---|---|---|---|---|---|---|
| authorization | ... | ... | high/med/low | ... | ... | ... |
| identity/session | ... | ... | ... | ... | ... | ... |
| dependency/CVE hygiene | ... | ... | ... | ... | ... | ... |
| data handling | ... | ... | ... | ... | ... | ... |
| operations/response | ... | ... | ... | ... | ... | ... |

## Submission checklist

Before giving the report to the operator, verify: policy URL and scope are fresh; reproduction works from a clean account or documented state; no secrets or unnecessary personal data remain; the title matches the demonstrated impact; duplicate risk was considered; remediation is actionable; the report is in the platform's requested format; and the operator knows what must be submitted manually.

## Beginner lesson

A security report is a bridge between a researcher and an engineer. The researcher supplies a reproducible observation and impact; the engineer needs a precise fix and a way to test it. Clear boundaries, evidence, and a retest plan make a report valuable even when the final severity or bounty differs from the researcher's first guess.
