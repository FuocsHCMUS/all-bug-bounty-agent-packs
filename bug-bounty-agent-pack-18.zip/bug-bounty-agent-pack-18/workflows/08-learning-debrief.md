# Workflow 08 — Learning Debrief, Skill Tree & Next Session

## Purpose

Convert each hunt into durable skill. The operator is learning networking, application security, pentesting, and SOC concepts; therefore the session ends with a teaching debrief even when no finding is confirmed.

## Debrief structure

Write `notes/debrief-YYYY-MM-DD.md` with these sections.

### 1. Session result

State the target, policy basis, timebox, scope, request budget, and outcome: confirmed finding, hypothesis, research-only, blocked, or dead end. Explain what was deliberately not tested and why.

### 2. System model in plain language

Describe the application's normal flow from browser/client to DNS, TLS, gateway, application, database, queue, cache, storage, and third-party services as applicable. Explain which component made each security decision. Use a short glossary for every new acronym.

### 3. Concept ladder

For every important concept, use:

```text
beginner definition:
real-world problem it solves:
normal mechanism:
trust boundary:
failure mode:
what we observed:
how to fix and retest:
local exercise:
```

Cover at least one concept from each relevant layer: network, HTTP/API, identity/authorization, data handling, code/runtime, and detection/response.

### 4. Finding or hypothesis anatomy

Break the result into source, sink, actor, asset, invariant, precondition, oracle, impact, and remediation. Draw a small text flow if useful:

```text
actor → request → boundary/control → component → asset
                         ↑ missing / inconsistent decision
```

### 5. What the organization does well and should improve

Summarize the posture annex from 07 using confidence labels. Do not make claims about internal processes that were not observable. Name one positive practice, one improvement, one at-risk condition, and one follow-up question.

### 6. Skill progression

Update a personal skill tree:

```text
Networking
├── DNS / TLS / HTTP
├── proxies / caching / CDNs
└── sockets / timeouts / concurrency
Web security
├── identity / sessions / authorization
├── input / output / parsers
└── APIs / integrations / business logic
Security engineering
├── logging / detection / response
├── dependency / secrets / SDLC
└── regression / threat modeling / remediation
Research craft
├── scope / evidence / reporting
├── source criticism / CVE matching
└── lab design / hypothesis testing
```

Mark each node `new`, `practiced`, `reliable`, or `teach someone else`.

### 7. Drills

Give the operator three drills at increasing difficulty:

- **Foundation:** explain a concept in their own words or draw the request/data flow.
- **Lab:** reproduce the primitive in an intentionally vulnerable local app and verify the fixed version.
- **Applied:** inspect a new local or authorized feature, write three hypotheses, and defend the safest oracle.

Never assign a drill that requires attacking an unapproved target.

### 8. Next-session plan

Choose at most three next actions, each with a purpose, expected evidence, safe stop condition, and learning objective. Include a tool/dependency plan and whether operator confirmation is needed.

## Quality check

A good debrief lets a beginner answer: What was the normal system doing? Which rule should have held? Where did the trust boundary fail? How did we prove it safely? How would the owner fix and retest it? What skill can I practice next?

## Beginner lesson

Learning is not separate from hunting. The same habit—model first, change one variable, observe an oracle, record evidence, and retest the fix—is used by a bug bounty researcher, a secure developer, and a SOC analyst investigating an alert.
