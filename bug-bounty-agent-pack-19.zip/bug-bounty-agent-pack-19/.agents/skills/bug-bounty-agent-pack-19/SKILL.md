---
name: bug-bounty-agent-pack-19
description: Use when working on a bug bounty engagement, CVE applicability review, security experiment, report, or beginner security lesson in the BB19 workspace.
---

# BB19 workspace skill loader

Resolve the pack root as the directory three levels above this skill directory. Read [the shared instructions](../../../AGENTS.md) and [the task router](../../../SKILL.md). Follow the relevant workflow and maintain session records under that pack root.

Load only task-relevant references. This loader does not grant live target access or approve tool execution. The pack's evidence labels, user execution preferences, and beginner teaching contract apply throughout.
