# Pack design and implementation record

Created: 2026-11-04. All pack content is English. Target workstation: Windows 11, PowerShell, Python 3.14 or later.

## Design

The requested deliverable is a portable, repository-local prompt pack for a senior bug bounty research partner that also teaches a beginner. The design uses one shared instruction contract, short native loaders, and detailed references loaded for the current task. A single enormous always-loaded prompt would waste context; separate, independently maintained copies for six products would drift. This pack instead keeps shared behavior in `AGENTS.md`, task routing in `SKILL.md`, and substantive procedures in `core/`, `workflows/`, `playbooks/`, and `education/`.

The agent can discover public programs, study primary sources, analyze supplied artifacts, develop creative hypotheses, and prepare reproducible reports. Live testing is a separate activity tied to a selected program, its current asset scope, permitted methods, and the user's execution approvals. No real company, asset, account, or CVE is pre-authorized by this pack. Report submission remains with the user, as requested.

Compatibility is based on official documentation retrieved on 2026-11-04, not assumptions about instruction filenames. Current Claude Code supports `AGENTS.md` with version and precedence caveats. Current Antigravity also documents `AGENTS.md` and `.agents/rules/`. Legacy examples remain inactive until deliberately used. No global configuration is edited.

## Implementation plan

1. Create shared entrypoints, the startup prompt, native loaders, six platform guides, and a source register.
2. Write the research lifecycle: program discovery, scope intake, architecture, CVE applicability, writeup transfer, hypothesis selection, validation, reporting, defense, and resumption.
3. Add advanced subject playbooks, a first-principles curriculum, and reusable specialist prompts.
4. Add structured engagement, experiment, evidence, approval, report, and learning templates, plus a clearly fictional worked example.
5. Implement dependency-free offline Python helpers for session scaffolding, pack validation, evidence hashing, environment inspection, and a synthetic authorization lab.
6. Verify files, links, loader paths, JSON, hashes, helper behavior, and realistic decision scenarios. Record the limits of verification explicitly.

## Acceptance criteria

- Every requested platform has a concrete loading path and a way to check loading.
- Portable downloads stay inside the workspace; system installation, MCP/plugin/skill installation, and new script/tool execution follow the user's confirmation preferences. Python dependencies may be installed in a workspace virtual environment without repeatedly asking.
- Observations, inference, candidate issues, reproduced behavior, and confirmed impact remain distinct.
- Research produces learning and defensive insights even when no vulnerability is confirmed.
- Creativity is expressed as testable hypotheses and controlled experiments, with explicit disconfirming evidence.
- All live-specific fields start empty; examples use fictional reserved names and synthetic data.
- The pack includes no internet scanner, remote exploit runner, platform account automation, or automatic report submission.

## Verification scope

Local structural and helper validation is required. An independent read-only behavioral review checks whether the instructions are usable. Successful local checks do not establish that all six installed products have loaded the pack or that any target has a vulnerability.

## Completion work

The earlier build stopped before its QA documents, file index, and distribution
manifest were finished. Completion preserved the existing research content and
added those packaging artifacts. See [the validation report](qa/VALIDATION_REPORT.md)
for executed checks and [the application review](qa/BEHAVIOR_REVIEW.md) for the
independent scenario results.

The user explicitly approved the bounded offline checks in
[APR-BUILD-001](qa/EXECUTION_APPROVAL.md). Python 3.14.8 ran the 18-test suite:
16 passed, 2 skipped because this Windows process could not create symlinks,
and no tests failed. The optional external skill-creator validator could not
import PyYAML in either existing runtime; no dependency or system software was
installed for it. The pack's own simple metadata and local structure checks ran.

The independent review identified two usability defects, both corrected: how to
choose among several saved sessions, and a startup expectation that assumed a
fresh workspace. Four focused follow-up cases applied the revised instructions
without remaining actionable ambiguity in those cases. This review is a
qualitative sample, not a measured reliability improvement.

Additional ideas implemented beyond a basic persona prompt include twenty
hypothesis operators; evidence, uncertainty, coverage, and novelty ledgers;
patch-neighbor and cross-feature reasoning; session resumption; telemetry and
regression proposals; teach-back exercises; and a synthetic vulnerable/repaired
authorization model. These support research depth while keeping observations
distinct from untested explanations.
