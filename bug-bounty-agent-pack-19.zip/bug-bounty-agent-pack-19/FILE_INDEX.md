# File index

This inventory lists the authored distribution files. Start with [QUICKSTART.md](QUICKSTART.md), or paste [BOOTSTRAP_PROMPT.md](BOOTSTRAP_PROMPT.md). Working directories such as `sessions/`, `tools/`, `research/`, `.venv/`, and `qa/tmp/` are excluded. `PACK_MANIFEST.json` is generated after final verification and records file sizes and SHA-256 hashes; it excludes itself to avoid a circular hash.

## Start and build records

Open QUICKSTART.md first; the bootstrap and master prompt start actual research sessions.

- [AGENTS.md](AGENTS.md)
- [BOOTSTRAP_PROMPT.md](BOOTSTRAP_PROMPT.md)
- [BUILD_NOTES.md](BUILD_NOTES.md)
- [FILE_INDEX.md](FILE_INDEX.md)
- [QUICKSTART.md](QUICKSTART.md)
- [README.md](README.md)
- [SKILL.md](SKILL.md)
- [SOURCES.md](SOURCES.md)

## Native loaders

Short local adapters refer to the shared instructions.

- [.agents/rules/bb19.md](.agents/rules/bb19.md)
- [.agents/skills/bug-bounty-agent-pack-19/SKILL.md](.agents/skills/bug-bounty-agent-pack-19/SKILL.md)
- [.agents/skills/bug-bounty-agent-pack-19/agents/openai.yaml](.agents/skills/bug-bounty-agent-pack-19/agents/openai.yaml)
- [.clinerules/01-bb19.md](.clinerules/01-bb19.md)
- [.cursor/rules/bb19.mdc](.cursor/rules/bb19.mdc)
- [.gitignore](.gitignore)

## Platform guides

Choose the guide for your installed agent, then verify its loaded instructions.

- [adapters/COMPATIBILITY.md](adapters/COMPATIBILITY.md)
- [adapters/antigravity.md](adapters/antigravity.md)
- [adapters/claude-code.md](adapters/claude-code.md)
- [adapters/cline.md](adapters/cline.md)
- [adapters/codex.md](adapters/codex.md)
- [adapters/cursor.md](adapters/cursor.md)
- [adapters/legacy/CLAUDE.md.example](adapters/legacy/CLAUDE.md.example)
- [adapters/opencode.md](adapters/opencode.md)

## Core research model

Read the references required by the current task.

- [core/CAPABILITIES.md](core/CAPABILITIES.md)
- [core/CREATIVE_HYPOTHESIS_ENGINE.md](core/CREATIVE_HYPOTHESIS_ENGINE.md)
- [core/EVIDENCE_STANDARD.md](core/EVIDENCE_STANDARD.md)
- [core/OPERATING_MODEL.md](core/OPERATING_MODEL.md)
- [core/TEACHING_CONTRACT.md](core/TEACHING_CONTRACT.md)
- [core/TOOLING_WINDOWS.md](core/TOOLING_WINDOWS.md)

## Research lifecycle

Workflows connect program selection to evidence, reporting, defense, and handoff.

- [workflows/01-program-discovery.md](workflows/01-program-discovery.md)
- [workflows/02-scope-intake.md](workflows/02-scope-intake.md)
- [workflows/03-architecture-and-recon.md](workflows/03-architecture-and-recon.md)
- [workflows/04-cve-research.md](workflows/04-cve-research.md)
- [workflows/05-writeup-to-hypothesis.md](workflows/05-writeup-to-hypothesis.md)
- [workflows/06-controlled-validation.md](workflows/06-controlled-validation.md)
- [workflows/07-findings-and-disclosure.md](workflows/07-findings-and-disclosure.md)
- [workflows/08-defense-and-soc.md](workflows/08-defense-and-soc.md)
- [workflows/09-session-resume.md](workflows/09-session-resume.md)
- [workflows/10-source-code-and-patch-analysis.md](workflows/10-source-code-and-patch-analysis.md)
- [workflows/11-lab-reproduction.md](workflows/11-lab-reproduction.md)

## Subject playbooks

Choose the relevant application surface after selecting a workflow.

- [playbooks/01-identity-and-session.md](playbooks/01-identity-and-session.md)
- [playbooks/02-api-and-tenant-boundaries.md](playbooks/02-api-and-tenant-boundaries.md)
- [playbooks/03-business-logic-and-state.md](playbooks/03-business-logic-and-state.md)
- [playbooks/04-web-and-browser-boundaries.md](playbooks/04-web-and-browser-boundaries.md)
- [playbooks/05-data-and-server-boundaries.md](playbooks/05-data-and-server-boundaries.md)
- [playbooks/06-cloud-and-supply-chain.md](playbooks/06-cloud-and-supply-chain.md)
- [playbooks/07-mobile-clients-and-artifacts.md](playbooks/07-mobile-clients-and-artifacts.md)
- [playbooks/08-ai-agent-applications.md](playbooks/08-ai-agent-applications.md)

## Specialist prompts

Use these as sequential reasoning roles unless parallel work is explicitly selected.

- [prompts/00-master-agent.md](prompts/00-master-agent.md)
- [prompts/01-program-scout.md](prompts/01-program-scout.md)
- [prompts/02-surface-modeler.md](prompts/02-surface-modeler.md)
- [prompts/03-cve-analyst.md](prompts/03-cve-analyst.md)
- [prompts/04-writeup-researcher.md](prompts/04-writeup-researcher.md)
- [prompts/05-hypothesis-designer.md](prompts/05-hypothesis-designer.md)
- [prompts/06-experiment-validator.md](prompts/06-experiment-validator.md)
- [prompts/07-skeptical-reviewer.md](prompts/07-skeptical-reviewer.md)
- [prompts/08-report-writer.md](prompts/08-report-writer.md)
- [prompts/09-first-principles-teacher.md](prompts/09-first-principles-teacher.md)
- [prompts/10-defender-and-soc.md](prompts/10-defender-and-soc.md)
- [prompts/11-session-resumer.md](prompts/11-session-resumer.md)
- [prompts/12-tooling-request.md](prompts/12-tooling-request.md)
- [prompts/13-source-and-patch-reviewer.md](prompts/13-source-and-patch-reviewer.md)
- [prompts/14-local-lab-designer.md](prompts/14-local-lab-designer.md)

## Session templates

Copy the required records into a session; empty fields represent missing information.

- [templates/README.md](templates/README.md)
- [templates/approvals.json](templates/approvals.json)
- [templates/assets.csv](templates/assets.csv)
- [templates/coverage.csv](templates/coverage.csv)
- [templates/cve-applicability.md](templates/cve-applicability.md)
- [templates/defensive-review.md](templates/defensive-review.md)
- [templates/engagement.json](templates/engagement.json)
- [templates/evidence-index.csv](templates/evidence-index.csv)
- [templates/experiment.md](templates/experiment.md)
- [templates/finding.md](templates/finding.md)
- [templates/handoff.md](templates/handoff.md)
- [templates/hypotheses.csv](templates/hypotheses.csv)
- [templates/lesson.md](templates/lesson.md)
- [templates/retrospective.md](templates/retrospective.md)
- [templates/session-state.json](templates/session-state.json)
- [templates/source-card.md](templates/source-card.md)
- [templates/sources.csv](templates/sources.csv)
- [templates/tool-inventory.csv](templates/tool-inventory.csv)
- [templates/tool-request.md](templates/tool-request.md)

## Learning references

Start with Foundations and follow the learning path.

- [education/CONCEPT_MAP.md](education/CONCEPT_MAP.md)
- [education/FOUNDATIONS.md](education/FOUNDATIONS.md)
- [education/GLOSSARY.md](education/GLOSSARY.md)
- [education/LEARNING_PATH.md](education/LEARNING_PATH.md)

## Fictional worked example

Synthetic tenant-boundary evidence, report, defender analysis, and lesson.

- [examples/fictional-tenant-boundary/README.md](examples/fictional-tenant-boundary/README.md)
- [examples/fictional-tenant-boundary/defensive-review.md](examples/fictional-tenant-boundary/defensive-review.md)
- [examples/fictional-tenant-boundary/finding.md](examples/fictional-tenant-boundary/finding.md)
- [examples/fictional-tenant-boundary/lesson.md](examples/fictional-tenant-boundary/lesson.md)
- [examples/fictional-tenant-boundary/traces.txt](examples/fictional-tenant-boundary/traces.txt)

## Offline helpers and tests

Standard-library commands; observe the user's execution-confirmation preference.

- [scripts/README.md](scripts/README.md)
- [scripts/packctl.py](scripts/packctl.py)
- [tests/test_packctl.py](tests/test_packctl.py)

## Quality records

Check these for executed verification and its limits.

- [qa/BEHAVIOR_REVIEW.md](qa/BEHAVIOR_REVIEW.md)
- [qa/BEHAVIOR_SCENARIOS.md](qa/BEHAVIOR_SCENARIOS.md)
- [qa/EXECUTION_APPROVAL.md](qa/EXECUTION_APPROVAL.md)
- [qa/VALIDATION_REPORT.md](qa/VALIDATION_REPORT.md)


