# Quick start

## 1. Open the correct folder

Open `bug-bounty-agent-pack-19` as the workspace in your chosen agent application. In PowerShell, move into it from the parent workspace:

```powershell
Set-Location -LiteralPath '.\bug-bounty-agent-pack-19'
```

Select your platform in [adapters/COMPATIBILITY.md](adapters/COMPATIBILITY.md). Nothing needs to be installed to read the pack or use its prompts.

## 2. Confirm that instructions loaded

Paste this into a new chat:

```text
Read AGENTS.md and SKILL.md in this workspace. State the pack ID, the current
engagement state, where session records belong, and the execution preferences.
Do not run scripts or make target requests. Then read BOOTSTRAP_PROMPT.md
and start with public-source program discovery or an offline learning task.
```

Expected substance: pack ID `BB19`; session records in `sessions/<session-id>/`; script/tool confirmation preferences preserved. In a fresh workspace with no sessions, no live engagement is selected or authorized. In an existing workspace, resolve the session using `AGENTS.md` and summarize its actual brief and approvals; do not replace valid recorded state with the fresh-workspace expectation. An agent repeating a filename is not enough: check that its summary matches the actual instructions.

## 3. Choose your first task

For a beginner, use one of these exact prompts:

```text
Use this pack in LEARN mode. Teach the request/response model, sessions,
authentication, and authorization from first principles. Walk me through
the fictional tenant-boundary example. Ask three short teach-back questions.
Do not make network requests to an application.
```

```text
Use this pack in DISCOVER mode. Research three current public bug bounty
programs from official HackerOne or Bugcrowd listings. Compare explicit
scope, access requirements, beginner learning value, public rules about
automation, and likely setup effort. Cite current sources. Return a ranked
shortlist and a draft engagement brief. Do not start active testing.
```

```text
Use this pack in ANALYZE mode. I will provide a program policy and redacted
HTTP traces from accounts I control. Build the trust-boundary model,
record observations and unknowns, and propose the smallest discriminating
tests. Explain every new concept before using it.
```

## 4. Create a session when useful

The offline helper is optional. After you approve its first execution, use:

```powershell
python .\scripts\packctl.py doctor
python .\scripts\packctl.py init-session beginner-first-session
python .\scripts\packctl.py init-session beginner-first-session --create
```

The first `init-session` is a preview. The `--create` command creates a new folder under `sessions/` and refuses to replace an existing session. Neither command contacts a target. Edit the new `engagement.json` with real policy information before planning live work; empty fields deliberately mean unknown.

## 5. Start live work only with a concrete brief

Give the agent the official program policy URL or text, a specific in-scope asset, relevant exclusions, permitted methods, rate and request budgets, your controlled test identities, and your approval for the proposed commands. If information is missing, the agent can continue reading sources, building a local model, and drafting tests while it asks only for the missing details.

The state moves through `DISCOVER -> INTAKE -> MODEL -> RESEARCH -> PLAN -> VALIDATE -> REPORT -> DEFEND -> LEARN -> HANDOFF`. Approval requests include exact commands and effects. A user-approved command does not expand the program's scope.

## 6. Keep the outputs together

Ask the agent to maintain `session-state.json`, `hypotheses.csv`, `coverage.csv`, `sources.csv`, and `evidence-index.csv` in the session folder. A confirmed finding gets its own experiment, report, defensive review, and beginner lesson. An unconfirmed lead stays in the hypothesis queue.

Before submitting a report yourself, read its reproduction steps, evidence, impact, limitations, and redactions. The agent should be able to explain every claim without relying on a scanner label or a guessed architecture.
