# Bug Bounty Agent Pack 19

A portable research, validation, reporting, and learning workspace for a bug bounty researcher using Claude Code, Codex, OpenCode, Cline, Cursor, or Google Antigravity.

The agent acts as a senior application security researcher, a skeptical experiment designer, a clear report writer, and a patient mentor. It studies current program policies and primary vulnerability sources, models application trust boundaries, develops original hypotheses, checks the smallest meaningful proof, and turns each result into a lesson. It also explains the defender's perspective: prevention, telemetry, detection, triage, remediation, and regression testing.

**Start with [QUICKSTART.md](QUICKSTART.md).** To give an agent one prompt, paste [BOOTSTRAP_PROMPT.md](BOOTSTRAP_PROMPT.md). The complete research persona is in [prompts/00-master-agent.md](prompts/00-master-agent.md).

## What is included

| Part | Purpose |
| --- | --- |
| [AGENTS.md](AGENTS.md) | Shared project instructions, execution preferences, evidence rules, and output contract |
| [SKILL.md](SKILL.md) | Task router; load the relevant references rather than the entire pack |
| [adapters/COMPATIBILITY.md](adapters/COMPATIBILITY.md) | Six platform entrypoints and loading checks |
| [core/OPERATING_MODEL.md](core/OPERATING_MODEL.md) | Research states, role lenses, prioritization, and handoff |
| [core/CREATIVE_HYPOTHESIS_ENGINE.md](core/CREATIVE_HYPOTHESIS_ENGINE.md) | Techniques for generating and falsifying original hypotheses |
| [workflows/](workflows/01-program-discovery.md) | The lifecycle from program discovery to retest and lessons |
| [playbooks/](playbooks/01-identity-and-session.md) | Identity, APIs, business logic, browser, server, cloud, mobile, and AI surfaces |
| [education/FOUNDATIONS.md](education/FOUNDATIONS.md) | Networking and security concepts explained from first principles |
| [prompts/](prompts/01-program-scout.md) | Focused specialist prompts with concrete inputs and outputs |
| [templates/README.md](templates/README.md) | Structured engagement, evidence, experiment, report, defense, and lesson records |
| [examples/fictional-tenant-boundary/README.md](examples/fictional-tenant-boundary/README.md) | A complete synthetic example connecting offensive and defensive reasoning |
| [scripts/README.md](scripts/README.md) | Offline Python helpers; no third-party packages required |
| [qa/BEHAVIOR_SCENARIOS.md](qa/BEHAVIOR_SCENARIOS.md) | Scenarios for checking whether an agent actually follows the workflow |
| [SOURCES.md](SOURCES.md) | Official compatibility and research references, with retrieval limitations |

## What good work looks like

A useful output is not a long list of payloads or scanner alerts. It is a defensible claim with a specific asset, principal, prerequisite, input change, observed result, negative control, demonstrated impact, and clear limitation. A failed hypothesis is useful when its assumptions and discriminating evidence are recorded.

The pack encourages difficult reasoning: authorization asymmetries, distributed state, canonicalization, lifecycle transitions, parser disagreement, feature interactions, patch variants, and multi-step chains. Each idea becomes an explicit experiment. A plausible chain is recorded as plausible until its individual links and composition are demonstrated.

## Execution preferences

- Keep portable tools, cloned repositories, dependency environments, downloaded documents, and session artifacts inside this workspace.
- Small portable downloads and workspace Python dependencies are already permitted by the user's preference. Record source, version, size, and purpose. Downloading a tool does not authorize executing it.
- Ask before new scripts or tools run unless the user has already approved the exact operation or a clearly bounded command family. Reuse existing approvals within their scope.
- Ask before system installations, administrator actions, drivers, persistent services, MCP servers, plugins, or externally installed skills. See [core/TOOLING_WINDOWS.md](core/TOOLING_WINDOWS.md).
- Public documentation research can proceed independently. Active requests to a company application require a selected, current program scope and an approved test plan. The agent prepares reports for the user to submit.

These are operating boundaries for accurate, reproducible research. They leave hypothesis generation open-ended and prevent a program listing, a tool README, or a guessed hostname from silently becoming an execution instruction.

## Packaging and maintenance

Open **this folder itself** as the agent workspace, or launch the agent with this folder as its current directory. Opening only its parent may leave project instructions undiscovered. No global configuration changes or symlinks are required.

The root instructions are authoritative for this pack. Native loader files contain short references, not separate research policies. The discoverable skill is under `.agents/skills/bug-bounty-agent-pack-19/`. The root `SKILL.md` also works as a manually attached reference.

Compatibility documentation was checked on **2026-11-04**. Installation versions, program scopes, tool support, CVE records, and source availability change. Recheck the relevant source when starting an actual engagement. See [FILE_INDEX.md](FILE_INDEX.md) for the generated file inventory and [qa/VALIDATION_REPORT.md](qa/VALIDATION_REPORT.md) for what was tested.
