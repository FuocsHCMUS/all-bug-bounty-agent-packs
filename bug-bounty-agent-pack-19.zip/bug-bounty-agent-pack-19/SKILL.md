---
name: bug-bounty-agent-pack-19
description: Use when conducting a scoped bug bounty research session, analyzing CVE applicability or supplied security evidence, developing testable application security hypotheses, or teaching the underlying concepts with this pack.
---

# Bug bounty research and learning

Read [AGENTS.md](AGENTS.md) for the shared contract. Begin with the user's actual task and current session state. This is a research workflow, not a claim that tools, credentials, target permission, or vulnerabilities already exist.

## Route the task

| User need | Read next | Deliverable |
| --- | --- | --- |
| Find a public program | [Program discovery](workflows/01-program-discovery.md) | Sourced shortlist and proposed engagement |
| Interpret program rules | [Scope intake](workflows/02-scope-intake.md) | Explicit asset and method matrix |
| Understand an application | [Architecture and recon](workflows/03-architecture-and-recon.md) | Identity, asset, state, and data-flow model |
| Investigate a CVE lead | [CVE research](workflows/04-cve-research.md) | Applicability matrix with unknowns |
| Learn from a writeup or CTF | [Writeup transfer](workflows/05-writeup-to-hypothesis.md) | Mechanism card and new falsifiable hypotheses |
| Invent or prioritize tests | [Hypothesis engine](core/CREATIVE_HYPOTHESIS_ENGINE.md) | Ranked experiments with controls |
| Validate behavior | [Controlled validation](workflows/06-controlled-validation.md) | Reproducible evidence and scoped conclusion |
| Draft a report or retest | [Findings and disclosure](workflows/07-findings-and-disclosure.md) | User-ready draft or retest record |
| Explain defensive implications | [Defense and SOC](workflows/08-defense-and-soc.md) | Evidence-bounded control and detection analysis |
| Resume interrupted work | [Session resume](workflows/09-session-resume.md) | Current state, approvals, and next action |
| Review source or a patch | [Source and patch analysis](workflows/10-source-code-and-patch-analysis.md) | Reachability, root cause, variants, regression plan |
| Reproduce an idea locally | [Lab reproduction](workflows/11-lab-reproduction.md) | Synthetic, bounded experiment |
| Teach a new researcher | [Teaching contract](core/TEACHING_CONTRACT.md), [Foundations](education/FOUNDATIONS.md) | Layered explanation and teach-back exercise |
| Set up tools | [Windows tooling](core/TOOLING_WINDOWS.md), [Capabilities](core/CAPABILITIES.md) | Concrete tool request or workspace-only setup |

Read the relevant subject playbook after selecting the workflow. Start with the invariant and preconditions; choose tools only after the test has a clear observable result. Avoid loading every reference at session start.

## Working recipe

1. Capture the known facts, user objective, current authority, and unknowns.
2. Model the relevant identity, object, boundary, and state transition.
3. Form competing hypotheses and predict outcomes that distinguish them.
4. Prepare the smallest authorized experiment and a normal-behavior control.
5. Record actual results and update confidence. Preserve inconclusive outcomes.
6. Produce a report only as strong as the demonstrated behavior.
7. Translate the result into a prevention lesson, a detection idea, and the next learning step.

For example, a private object appearing in a second controlled tenant is a candidate authorization failure. Establish its privacy rule and account contexts, exclude legitimate sharing and mixed sessions, and compare permitted versus forbidden reads. A confirmed conclusion covers those demonstrated reads; other endpoints and write permissions remain separate hypotheses.

Use [templates/README.md](templates/README.md) for records and [prompts/00-master-agent.md](prompts/00-master-agent.md) when a full reusable persona is useful. The pack's entrypoint is intentionally short; the depth lives in the referenced files.
