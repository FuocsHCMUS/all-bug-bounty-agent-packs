# Official source register and research starting points

Reference date: **2026-11-04**. Summaries are original; consult the linked source for exact current behavior. `Opened` means the page or repository was retrieved during pack creation. It does not mean a product was installed or every linked record was verified. `Pointer` means a recommended starting URL, not a reviewed current program or vulnerability.

## Agent configuration sources

| Source | Use | Retrieval note |
| --- | --- | --- |
| [Claude Code memory](https://code.claude.com/docs/en/memory#agentsmd) | Native AGENTS support, version/precedence caveats, optional import | Opened; also cross-checked through documentation retrieval |
| [Codex AGENTS instructions](https://developers.openai.com/codex/guides/agents-md) | Instruction discovery and precedence | Opened; redirected to official ChatGPT Learn documentation |
| [Codex skills](https://developers.openai.com/codex/skills) | Project skill discovery | Opened; redirected to official ChatGPT Learn documentation |
| [OpenCode rules](https://opencode.ai/docs/rules/) | Project AGENTS instructions | Opened |
| [OpenCode skills](https://opencode.ai/docs/skills/) | Agent-compatible skill location and manifest | Opened |
| [Cline rules](https://docs.cline.bot/customization/cline-rules) | AGENTS and workspace rule directories | Opened |
| [Cursor rules](https://cursor.com/docs/rules) | AGENTS and `.mdc` project rules | Opened |
| [Antigravity rules](https://antigravity.google/docs/rules) | AGENTS, modular rules, valid trigger syntax | Opened |
| [Antigravity learn command](https://antigravity.google/docs/commands/learn) | Rule and skill locations | Opened during completion; workspace `.agents/skills/<name>/SKILL.md` documented |

## Programs, scope, and report context

| Source | Use | Retrieval note |
| --- | --- | --- |
| [HackerOne program directory](https://hackerone.com/directory/programs) | Discover candidate public programs | Pointer; no program selected or tested |
| [HackerOne scope guidance](https://docs.hackerone.com/en/articles/8495670-scope-best-practices) | Understand explicit asset and exclusion wording | Opened; each actual policy remains authoritative |
| [Bugcrowd engagements](https://bugcrowd.com/engagements) | Discover candidate engagements | Pointer; no engagement selected or tested |
| [Bugcrowd engagement brief header](https://docs.bugcrowd.com/researchers/engagement-brief/header/) | Interpret engagement context | Opened; the parent brief URL was unavailable through the retrieval tool |
| [Bugcrowd VRT repository](https://github.com/bugcrowd/vulnerability-rating-taxonomy) | Baseline weakness priority taxonomy | Opened; use the current version and actual program context |

## Vulnerability identity and prioritization

| Source | Use | Retrieval note |
| --- | --- | --- |
| [CVE Program](https://www.cve.org/) | CVE identity and authoritative record navigation | Opened shell required JavaScript; no specific CVE record assessed |
| [Official CVE List repository](https://github.com/CVEProject/cvelistV5) | CVE JSON records and CNA information | Repository opened as an alternative primary source |
| [NVD](https://nvd.nist.gov/vuln) | Enrichment and advisory references | Opened URL returned no readable content; no current record claims made |
| [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog) | Known-exploitation context | Retrieval returned 403; no entry-level claims made |
| [CISA KEV data mirror](https://github.com/cisagov/kev-data) | Official agency repository mirror | Repository opened; no target-specific applicability inferred |
| [FIRST EPSS](https://www.first.org/epss/) | Exploitation likelihood context | Opened; values must be retrieved with dates for actual use |
| [FIRST CVSS](https://www.first.org/cvss/) | Severity specification and calculators | Opened; follow the program's required version |

For every actual CVE assessment, add the vendor advisory, CNA record, exact affected-product conditions, patch/release information, and retrieval dates to the session's source register. This pack intentionally contains no stale “current critical CVE” list.

## Testing, requirements, and defender concepts

| Source | Use | Retrieval note |
| --- | --- | --- |
| [OWASP Web Security Testing Guide](https://owasp.org/www-project-web-security-testing-guide/) | Structured testing themes and versioned references | Opened; pin the chosen version in a session |
| [OWASP ASVS](https://asvs.owasp.org/) | Security requirements and verification | Opened through the official project URL |
| [OWASP API Security](https://owasp.org/www-project-api-security/) | API security concepts and categories | Opened |
| [MITRE ATT&CK](https://attack.mitre.org/) | Adversary behavior and defender context | Opened; verify exact IDs/version before mapping |
| [MITRE CWE](https://cwe.mitre.org/) | Weakness classification | Pointer; verify exact IDs before use |
| [PortSwigger Web Security Academy](https://portswigger.net/web-security) | Original vendor-authored educational material and labs | Pointer; no copied lesson or target result |
| [Python documentation](https://docs.python.org/3/) | Runtime and standard-library behavior | Pointer; check the exact installed 3.14+ version |

## Source discipline

Prefer original author research, vendor advisories, maintainer patches, protocol specifications, and official product documentation. Search results and reposts can lead to a source but should not silently replace it. Record inaccessible pages, conflicting statements, stale dates, and unverified links. A source's existence does not authorize target actions or prove that its technique applies now.
