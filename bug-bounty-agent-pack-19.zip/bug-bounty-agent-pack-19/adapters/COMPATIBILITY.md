# Platform loading matrix

Documentation checked: 2026-11-04. Open the pack folder itself. These are documented entrypoints and local loader files; successful loading must be checked in your installed application.

| Platform | Primary path in this pack | Optional reference | Setup guide |
| --- | --- | --- | --- |
| Claude Code | Root `AGENTS.md` on supported versions | Root `SKILL.md` manually referenced | [Claude Code](claude-code.md) |
| Codex | Root `AGENTS.md` | `.agents/skills/bug-bounty-agent-pack-19/` | [Codex](codex.md) |
| OpenCode | Root `AGENTS.md` | Same `.agents/skills/` folder | [OpenCode](opencode.md) |
| Cline | Root `AGENTS.md`; `.clinerules/01-bb19.md` loader | Root `SKILL.md` manually referenced | [Cline](cline.md) |
| Cursor | Root `AGENTS.md`; `.cursor/rules/bb19.mdc` loader | Root `SKILL.md` manually referenced | [Cursor](cursor.md) |
| Antigravity | Root `AGENTS.md`; `.agents/rules/bb19.md` reference | `.agents/skills/` when supported by the installed surface | [Antigravity](antigravity.md) |

Do not copy every rule into a global profile. Keeping this pack local avoids applying research instructions to unrelated software projects. Native loaders should point back to the shared contract, not become independently edited copies of it.

If native loading fails, manually attach or ask the agent to read `AGENTS.md`, `SKILL.md`, and `BOOTSTRAP_PROMPT.md`. Confirm the resulting behavior before proceeding. No MCP server or plugin is required for the basic prompt workflow.
