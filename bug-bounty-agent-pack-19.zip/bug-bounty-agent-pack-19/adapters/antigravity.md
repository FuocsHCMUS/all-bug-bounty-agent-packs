# Google Antigravity

Sources: [rules](https://antigravity.google/docs/rules), [learning and skill locations](https://antigravity.google/docs/commands/learn), checked 2026-11-04.

Current documentation describes workspace `AGENTS.md` and `.agents/rules/*.md`. Modular rule files require valid `trigger` frontmatter. This pack's `.agents/rules/bb19.md` uses `model_decision`; the shared root `AGENTS.md` supplies continuous instructions. The documentation also describes `.agents/skills/<name>/SKILL.md` for workspace skills. Product surfaces and older versions can differ.

Open this folder itself and inspect the Customizations panel. Confirm the root instructions and the BB19 reference are visible. Run the startup check in [QUICKSTART.md](../QUICKSTART.md). If discovery differs, explicitly read root `AGENTS.md` and `SKILL.md` before choosing a workflow. No active `GEMINI.md` is necessary for the documented path used here.

Do not automatically migrate this pack into a global Gemini configuration. If an older installed version requires legacy paths, compare its official documentation and request any needed installation or configuration change first. Existing project files and approval preferences remain the source of truth for this workspace.
