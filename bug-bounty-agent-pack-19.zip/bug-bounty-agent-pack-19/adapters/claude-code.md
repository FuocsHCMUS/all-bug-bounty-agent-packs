# Claude Code

Official source: [project memory and AGENTS.md](https://code.claude.com/docs/en/memory#agentsmd), checked 2026-11-04.

The documented native `AGENTS.md` support requires v2.1.277 or later. By default, a project-path `CLAUDE.md`, `.claude/CLAUDE.md`, or `CLAUDE.local.md` takes precedence and can prevent native `AGENTS.md` loading. User-global and managed instructions have separate behavior. Some older sessions and disabled built-in support need a fallback.

Open this pack as the working directory. This pack deliberately has no active `CLAUDE.md`. Use `/memory` to inspect loaded instructions. Before v2.1.280, directly loaded `AGENTS.md` files were not listed in `/memory` or `/context`; use the startup content check below on those versions. If a project-path Claude file shadows the pack, inspect `/config` -> Project instructions; the documented `claude-md-and-agents-md` mode loads both. Do not automatically edit global settings.

For a session that cannot read `AGENTS.md` directly, an optional adjacent `CLAUDE.md` containing `@AGENTS.md` imports the shared instructions. The inactive [legacy example](legacy/CLAUDE.md.example) shows that fallback. Use it only when needed; no symlink is required on Windows.

Then paste the startup check from [QUICKSTART.md](../QUICKSTART.md), manually reference the root `SKILL.md`, and choose a task. Do not assume Claude discovers Codex's `.agents/skills/` directory. The manually referenced router is sufficient for this pack.
