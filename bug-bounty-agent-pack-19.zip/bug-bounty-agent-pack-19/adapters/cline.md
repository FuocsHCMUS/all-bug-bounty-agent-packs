# Cline

Official source: [Cline rules](https://docs.cline.bot/customization/cline-rules), checked 2026-11-04.

Cline documents `AGENTS.md` and `.clinerules/` among its recognized rule sources. Detected rule types appear in its Rules panel and can be toggled. This pack includes a short `.clinerules/01-bb19.md` loader as well as the shared root `AGENTS.md`.

Open this folder in the editor and confirm the relevant rules are enabled. Paste the startup check from [QUICKSTART.md](../QUICKSTART.md). If both files load, the small loader points to the same contract; do not duplicate the complete handbook there.

Use the root `SKILL.md` as a manually read router. This guide does not assume a particular Cline skill extension or provider. Keep command approvals visible and review the tool request before executing. An approval in Cline should be recorded in the session so a resumed chat can identify its exact extent.

If the agent cannot read local files, paste `BOOTSTRAP_PROMPT.md` and the relevant task reference into the chat; document that manual loading was used.
