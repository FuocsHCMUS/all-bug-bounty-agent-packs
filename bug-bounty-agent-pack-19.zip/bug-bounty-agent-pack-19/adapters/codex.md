# Codex

Sources: [AGENTS.md discovery](https://developers.openai.com/codex/guides/agents-md), [local skills](https://developers.openai.com/codex/skills), checked 2026-11-04.

Launch Codex in this pack folder. Codex reads project instruction files along its discovery path; closer guidance can override earlier guidance, and `AGENTS.override.md` can take precedence. Without a detected project root, current-directory discovery matters. Keep this folder as the current directory for this non-Git package.

The discoverable skill is `.agents/skills/bug-bounty-agent-pack-19/SKILL.md`. Ask for `$bug-bounty-agent-pack-19`, or manually ask Codex to read the root `SKILL.md`. Skill availability depends on the local product surface and its configured discovery.

Run the startup check from [QUICKSTART.md](../QUICKSTART.md). Verify that Codex recognizes pack ID `BB19`, the empty engagement state, and execution preferences. If it reports different instructions, inspect the actual loaded files and current working directory before editing anything.

Use the host's existing approval interface. This pack supplies human-readable requests and approval records; it does not change the sandbox or approval settings. No model name, API key, system configuration, or MCP installation is required by the pack.
