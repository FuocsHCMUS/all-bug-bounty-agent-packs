# Cursor

Official source: [Cursor rules](https://cursor.com/docs/rules), checked 2026-11-04.

Cursor documents root and nested `AGENTS.md` instructions. Its project rules use `.cursor/rules/*.mdc` with frontmatter. This pack includes `.cursor/rules/bb19.mdc` with `alwaysApply: true`; it is a short loader. Plain `.md` files in that rule directory are not a substitute for the documented `.mdc` format.

Open this folder, inspect Customize -> Rules, and confirm the loader is recognized. Paste the startup check from [QUICKSTART.md](../QUICKSTART.md). File references in rules identify documents to read; do not assume their complete contents have already been injected.

Read root `SKILL.md` when choosing a task. Keep the large playbooks outside the always-applied rule so ordinary chats do not spend their context on unrelated references. The evidence and teaching contracts still apply to every substantive result.

Use the existing terminal and network approval controls. Avoid broad command auto-approval for a research workspace; approve the concrete experiment or bounded command family described in the session plan.
