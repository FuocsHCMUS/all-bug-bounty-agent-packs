# OpenCode

Sources: [rules](https://opencode.ai/docs/rules/), [skills](https://opencode.ai/docs/skills/), checked 2026-11-04.

OpenCode documents project-root `AGENTS.md` and an agent-compatible `.agents/skills/<name>/SKILL.md` discovery location. It also supports other project and global locations. This pack uses the shared root instructions and one agent-compatible skill; no `opencode.json` override is needed.

Start in this folder. Run the startup check in [QUICKSTART.md](../QUICKSTART.md), and ask OpenCode to load `bug-bounty-agent-pack-19` if its native skill tool exposes it. If skill discovery is unavailable, manually reference root `SKILL.md`.

Preserve your existing permissions and provider configuration. The pack's research roles are task prompts, not claims that named OpenCode subagents have been installed. Execute specialist prompts sequentially unless parallel delegation has been explicitly selected and supported. Keep all roles on the same engagement, scope snapshot, evidence IDs, and hypothesis queue.
