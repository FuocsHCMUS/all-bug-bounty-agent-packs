# Optional capabilities and integrations

The pack is usable as local Markdown. Additional tools improve evidence collection but are not presumed installed. Inspect the actual host's available tools before suggesting installation.

| Capability | Benefit | Data exposure and setup questions |
| --- | --- | --- |
| Search and official documentation retrieval | Current policies, advisories, and support information | Does the query disclose target secrets? Can sources be cited and dated? |
| Browser inspection | Understand normal flows and inspect controlled-account behavior | Which browser profile and accounts are in use? Are clicks read-only or state-changing? |
| HTTP proxy/repeater | Compare a small number of precise requests | Does it capture credentials? Where are histories stored? Is a certificate installation needed? |
| Local source search and Git diff | Trace checks and patch variants in supplied source | Is source authorized and confined to the workspace? |
| Offline JSON/CSV/trace parsing | Structure supplied observations without target traffic | Are credentials and personal data redacted first? |
| Local lab runtime | Reproduce a mechanism with synthetic data | Does it start a listener, expose a port, or require Docker/WSL? |
| Reference documentation MCP | Retrieve current API and framework guidance | Which server is already available? Does setup modify global configuration? |
| Browser or filesystem MCP | Host-specific automation and artifact access | What permissions and directories are granted? What actions need confirmation? |

A recommendation names the missing capability, why the current workflow needs it, an official source, expected installation scope, privileges, cost, and a manual fallback. Do not prescribe an arbitrary server package solely because its name sounds relevant. MCP configuration formats differ among hosts and change over time; verify official documentation for the installed version before presenting a concrete configuration.

A minimal setup is a local agent with file access, a public-source browser/search tool, and Python. Burp Suite, ZAP, browser developer tools, repository search tools, or other specialist tools can be proposed when their specific value is clear. Active scanning is a separate operation with a specific method, scope, and budget; the presence of a scanner is not a reason to use it.

For a public PoC repository, acquiring source can help inspect the mechanism without running it. Pin the commit, review entrypoints and dependencies, identify embedded credentials or endpoints, and ask whether a much smaller local model can answer the research question. Running unknown exploit code is not required to understand a vendor's patch.

No integration can expand the program's allowed assets or transform a speculative finding into evidence. If a tool is unavailable, state the limitation and continue with source research, artifact analysis, or a reviewable test plan.
