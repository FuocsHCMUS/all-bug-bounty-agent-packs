# Creative hypothesis engine

Creativity is the search for a surprising failure of a concrete assumption. Strong ideas explain a mechanism, predict a result, and invite disproof. Complexity is useful only when the system actually contains the interacting parts.

## Start with an invariant

An invariant is a rule that should remain true across inputs and states. Examples:

- A principal can read a private document only when current policy permits access.
- A role change takes effect on every route that relies on that role.
- An export contains only rows visible to the requesting principal at the relevant authorization time.
- A one-use invitation cannot create additional membership after consumption or revocation.
- Untrusted content cannot become executable instructions or a trusted tool decision.

Name the subject, resource, action, state, and authority. “Try IDOR” is a category. “Does the attachment download authorize the parent document and tenant for the current user?” is a testable question.

## Generate variations across meaningful axes

| Axis | Useful contrasts |
| --- | --- |
| Principal | Anonymous, controlled member A, controlled member B, delegated role, revoked member |
| Resource | Owned object, shared object, private object in another controlled tenant, child object |
| Action | Read, update, export, duplicate, preview, restore, download, asynchronous processing |
| Representation | UI route, REST route, GraphQL resolver, legacy route, bulk route, background job |
| Time | Before grant, after grant, after revoke, after logout, during a documented transition |
| Location | Client, gateway, application, worker, cache, object store, downstream service |
| Authority | Session, role assignment, tenant claim, signed capability, object ownership |

Do not enumerate the full Cartesian product. Select contrasts that probe a shared policy assumption.

## Twenty reasoning operators

1. **Route asymmetry.** Compare two legitimate representations of the same action. A UI, API, export, and download may reach different policy checks. Predict the exact response difference; a hidden route is not itself a flaw.
2. **Parent-child authority.** Ask whether permission is evaluated on the actual parent of a child object. A correct tenant field supplied by the client does not establish the child's tenant.
3. **Lifecycle reversal.** Revisit previously valid access after revocation, transfer, deletion, restore, archival, or expiry. Distinguish an intentional validity period from a stale authority decision.
4. **Subject confusion.** Follow where identity originates and whether a later component substitutes a user-supplied subject, tenant, or role for authenticated context.
5. **Representation disagreement.** Compare how two components interpret an identifier, path, type, or structured object. First demonstrate the differing interpretations in a local model; then ask whether they cross a real boundary.
6. **Canonicalization timing.** Ask whether normalization occurs before or after validation and authorization. Different spellings matter only if they resolve to the same protected resource with different decisions.
7. **Cache identity.** Determine which response dimensions depend on principal or tenant and which dimensions enter the cache key. Separate application caches, browser caches, and edge caches.
8. **Worker identity.** Trace a job from request authorization to queued data and later execution. Which actor's authority applies at enqueue time and at execution time? Has relevant state changed?
9. **Capability lifetime.** For a signed or bearer link, identify its audience, object binding, action binding, expiry, and revocation model. Possession-based access can be intentional; compare behavior against the documented promise.
10. **Default branch analysis.** In available source, inspect missing, null, empty, unknown, and exception paths. Ask whether missing policy data denies, grants, or falls back to a broader context.
11. **Batch disagreement.** A bulk operation may authorize the request while missing per-item checks. Test a minimal mixed set of controlled items when permitted; do not scale the batch to prove the same issue.
12. **Type and schema drift.** Compare what a client sends, what a gateway validates, and what the application binds. Investigate property authority, not arbitrary undocumented parameter spam.
13. **Idempotency and replay.** Identify the business operation key and its binding to actor, tenant, parameters, and lifetime. Use a local state machine before any live transition that could create financial or account effects.
14. **Cross-feature composition.** Find whether one feature creates an artifact another feature trusts: exports, previews, webhooks, imports, invitations, integrations, or support attachments. Trace the trust transition explicitly.
15. **Patch-neighbor analysis.** Study which assumption a patch repairs. Search authorized source for equivalent paths, shared helpers, and alternate representations with the same assumption. This is stronger than randomly mutating a published payload.
16. **Error-path policy.** Determine whether validation failures, partial results, retries, or exceptions expose a broader object or use a less restrictive backend query. A stack trace is a clue to investigate, not proof of full compromise.
17. **Boundary relocation.** Ask whether the system relies on client filtering, UI hiding, network location, or gateway behavior for a decision the service must enforce. Test the service's contract, not a presumed architecture.
18. **State-machine gap.** Enumerate allowed transitions and their preconditions. Look for operations accepted from an unintended state or sequences that bypass a required decision. Explain why the business rule matters.
19. **Metamorphic relation.** Define a transformation that should preserve or change the result predictably. Changing only a tenant to an unauthorized one should change permission; changing presentation formatting should not change policy.
20. **Counterexample construction.** Begin with a proposed defense and build the smallest case it should reject. A defense that merely happens to reject a malformed request has not necessarily enforced the intended invariant.

## Compose mechanisms carefully

Write a chain as nodes and edges: initial capability -> obtained capability -> next protected operation -> demonstrated impact. Every edge needs its own prerequisites and evidence. A harmless redirect plus an unrelated token concern does not automatically become account takeover. If an edge requires a secret, victim action, privilege, or cross-scope asset that is unavailable, leave that edge unproven.

Search for chains in the architecture, not in severity labels. An export job might preserve an outdated membership snapshot; a link it produces might remain valid after revocation. These are distinct hypotheses whose composition depends on the actual authorization promise and timestamps.

## Convert an idea into an experiment

Use [the experiment template](../templates/experiment.md). Fill these fields before choosing a tool:

```text
Invariant: [subject] may perform [action] on [object] only under [condition].
Observed clue: [evidence ID or source].
Hypothesis: [component] trusts [assumption] at [boundary].
Alternative: [legitimate sharing, different state, cache, or another explanation].
Single changed variable: [one identity, resource, action, or state].
Positive prediction: [specific observable marker and decision].
Negative/control prediction: [normal permitted and normal forbidden behavior].
Disconfirmation: [result that would make us reject or narrow the idea].
Budget and stop: [finite requests, time, and state effects].
```

For high-impact or ambiguous mechanisms, prefer a synthetic local model or owner-provided environment. The intellectual work can proceed before permission to run an experiment exists.

## Keep the search honest

Maintain a novelty ledger: known mechanism, new application-specific variant, untested composition, or independently derived idea. Do not call an idea a zero-day because no CVE was found. Do not select a sophisticated explanation when an account mix-up explains the same evidence. Reward hypotheses that survive controls, including simple ones.

After three unproductive branches with no new evidence, return to the system model. Identify missing product knowledge, an untested boundary, or an incorrect assumption. The next best action may be reading documentation or asking one precise question.
