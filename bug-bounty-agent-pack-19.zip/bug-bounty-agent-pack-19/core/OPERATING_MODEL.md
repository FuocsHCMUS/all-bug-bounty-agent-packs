# Research operating model

## One researcher, several reasoning lenses

The default is one agent changing lenses. These are responsibilities, not installed subagents or a reason to multiply tool calls.

| Lens | Central question | Output |
| --- | --- | --- |
| Program scout | Where can this researcher productively work now? | Sourced shortlist |
| Architect | What identities, services, objects, and states interact? | Boundary and data-flow model |
| Research analyst | What prior mechanism or advisory is relevant? | Source and applicability cards |
| Hypothesis designer | Which assumption might fail, and how would we know? | Ranked experiment |
| Validator | What actually happened under controlled conditions? | Evidence record |
| Skeptic | What else explains the result? | Disconfirming tests and claim limits |
| Reporter | Can another person reproduce the exact claim? | Submission draft |
| Defender | Where should prevention and detection occur? | Control and telemetry analysis |
| Teacher | Can a beginner explain why this matters? | Layered lesson and exercise |

If the user explicitly requests parallel agents, divide independent source reviews or evidence reviews. Supply each worker with the same engagement snapshot and an exact artifact contract. Keep active target requests under one coordinator and one shared budget. A child agent cannot grant itself broader permission. Otherwise run the lenses sequentially.

## State machine

```text
DISCOVER -> INTAKE -> MODEL -> RESEARCH -> PLAN -> VALIDATE
                                         ^          |
                                         |          v
                                      RESEARCH <- ASSESS
                                                    |
                               REPORT -> DEFEND -> LEARN -> HANDOFF
```

`LEARN`, `ANALYZE`, and `LOCAL_LAB` can be standalone tracks. `WAITING_FOR_USER` and `BLOCKED_EXTERNAL` annotate the current state; they do not erase it. Continue independent tasks while a particular command or question is pending.

| State | Entry information | Exit artifact |
| --- | --- | --- |
| DISCOVER | Learning goals, available time, public sources | Shortlist with current policy links |
| INTAKE | Selected program and policy | Engagement manifest with explicit unknowns |
| MODEL | Known allowed assets and supplied traces | Asset, principal, workflow, and boundary maps |
| RESEARCH | Concrete surface or suspicious behavior | Source cards, CVE conditions, hypotheses |
| PLAN | Ranked hypothesis | Approved minimal experiment with budget |
| VALIDATE | Complete prerequisites and approvals | Actual requests/results and controls |
| ASSESS | Evidence bundle | Confirmed, rejected, inconclusive, or pending lead |
| REPORT | Demonstrated security boundary failure | Reproducible draft with bounded impact |
| DEFEND | Finding or well-observed control | Prevention and detection review |
| LEARN | Result and learner prerequisites | Lesson, exercise, and teach-back answers |
| HANDOFF | Current ledgers and files | Resume-ready state and next action |

## Working rhythm

At the start, identify the highest-value uncertainty, not merely the most familiar tool. At each useful checkpoint write the conclusion, evidence IDs, unresolved assumptions, and next action. Keep a concise status update after a meaningful result or roughly every minute of ongoing work; do not stream raw thinking or repeat unchanged status.

Choose a finite research budget. A reasonable initial planning assumption is a 60-minute block: 10 minutes for scope and prerequisites, 15 for modeling, 15 for source research, 15 for one discriminating experiment, and 5 for handoff. Adjust to the task. This timebox is an organizing aid, never a target request-rate authorization.

When a branch stalls, identify why: missing identity, uncertain version, ambiguous sharing model, unavailable source, noisy signal, missing tool, or incompatible environment. Record the cheapest way to resolve that uncertainty. Do not repeatedly run an unchanged test and call it progress.

## Prioritization

Rank candidates using ordinal judgments, not invented exploit probabilities:

- **Relevance:** Is the surface in scope and reachable under the documented prerequisites?
- **Evidence:** Do we have an anomalous result or only a generic class of concern?
- **Impact:** What asset or business invariant could fail?
- **Discrimination:** Will one small experiment separate competing explanations?
- **Effort:** What accounts, local setup, or source access are required?
- **Learning value:** Does this teach a transferable concept?
- **Operational cost:** Will it create state, consume scarce requests, or require additional approval?

High hypothetical impact with no reachable preconditions belongs below a well-supported, inexpensive boundary check. Maintain a small top queue and preserve the rest in the ledger.

## Completion and handoff

A session is complete when its objective has a defensible answer and its artifacts are usable. Finding zero confirmed issues is a valid result. Completion requires an explicit coverage limit, rejected and inconclusive hypotheses, source freshness, changed state or cleanup notes, and the next learning step.

Update `session-state.json` after a decision that a resumed agent would otherwise have to rediscover. Store evidence references rather than pasting sensitive content into every handoff. If the user's approval expires or its target changes, mark it accordingly; do not silently carry it into a new program.
