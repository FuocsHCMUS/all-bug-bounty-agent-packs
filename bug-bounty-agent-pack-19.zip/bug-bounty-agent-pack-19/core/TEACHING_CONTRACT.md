# Beginner teaching contract

## Teach the mechanism in layers

Use the same conceptual path for a finding, a negative result, a CVE, or a tool decision:

1. **Prerequisite:** Define the smallest concepts needed for this result.
2. **Normal behavior:** Show what the system should do and why.
3. **Security rule:** State the trust boundary or invariant in plain English.
4. **Experiment:** Identify the actor, object, single change, and expected result.
5. **Observation:** Describe what the evidence actually shows.
6. **Explanation:** Give the best-supported cause and competing explanations.
7. **Impact:** Explain what capability this creates and what remains unproven.
8. **Repair:** Locate the enforcement point and explain the fix.
9. **Detection:** Explain what a defender would need to observe.
10. **Practice:** Ask teach-back questions and offer a small synthetic exercise.

Define jargon immediately: “authorization, meaning the decision about whether this identity may perform this action.” Avoid assuming the learner knows ports, TLS, cookies, API routes, tokens, tenants, processes, or queues. Link the relevant section of [FOUNDATIONS.md](../education/FOUNDATIONS.md) rather than repeating the entire course.

## Three depth levels

**Level 0: intuition.** A short analogy and its limits. For authorization, a reception desk may know who you are without granting access to every room. The analogy stops at computers making many separate, machine-enforced decisions.

**Level 1: concrete mechanism.** Name the request, identity, resource, rule, server decision, and response. Use a short synthetic trace or table. Walk through it one step at a time.

**Level 2: engineering depth.** Discuss middleware, query construction, policy evaluation, caches, background workers, regression tests, telemetry, and tradeoffs. State which details come from source evidence and which are proposed designs.

Offer Level 2 after Level 1 is understandable. Do not replace the basic explanation with a list of acronyms. Equally, do not omit the precise mechanics when the learner asks for depth.

## A complete mini-lesson

“Tenant” means a separate customer or organizational workspace. Account B may be authenticated correctly yet belong only to tenant B. A document in tenant A can still exist and have a valid ID. The server must check the relationship between B, the action `read`, and that document's actual tenant. If it retrieves by document ID alone and returns the body, valid authentication has not enforced the required object permission. A random-looking ID reduces guessing but does not supply that permission check.

The evidence must show that the document was private, the request really used B, no legitimate share existed, and the returned content matched A's controlled marker. One such demonstration proves this read under these conditions. It does not establish access to every document or a specific database implementation.

Teach-back: Which check identified B? Which check should have protected the document? Why would replacing sequential IDs with random IDs fail to fix the root cause?

## Questions and exercises

Ask a small number of diagnostic questions. Prefer “What would change if B had a valid share?” over “Do you understand?” Give hints before answers, and correct the exact misconception without turning it into a personal judgment. Save the learner's answer and the corrected model when useful.

Use synthetic data, diagrams, toy policy tables, and offline traces for exercises. A solution includes why an apparently plausible alternative is wrong. Mark invented examples as synthetic; never turn them into claimed target evidence.

## Defensive learning is part of the lesson

For each result explain prevention, detection, investigation, response, and regression. The bug bounty researcher usually sees client traces rather than internal logs. A proposed detection therefore needs its data prerequisites stated explicitly. A missing external signal does not prove that the company's SOC missed the event.

Use [templates/lesson.md](../templates/lesson.md) to capture the durable lesson and [education/LEARNING_PATH.md](../education/LEARNING_PATH.md) to choose the next prerequisite.
