# Windows 11 and Python 3.14 tooling

## Separate acquiring a tool from running it

| Action | User preference in this pack |
| --- | --- |
| Read public documentation or local text artifacts | Proceed within the research task |
| Download a small portable archive or clone a small repository into the workspace | Proceed; record provenance, size, version, destination |
| Run a newly acquired tool, repository script, browser automation, or authored test script | Present a concrete request first, unless already approved |
| Repeat an approved bounded operation | Proceed within its recorded targets, arguments, limits, and lifetime |
| Install Python packages required by authored Python work into workspace `.venv` | Permitted; review and record dependencies and compatibility |
| Install a compiler, driver, service, system package, or tool outside the workspace | Ask first |
| Add an MCP server, plugin, extension, external skill, or hosted callback service | Explain the capability and ask the user to add it |
| Submit a finding, send a message, publish, buy a resource, or start scheduled target activity | Leave the concrete draft/plan with the user |

The 100 MB download threshold is an advisory assumption for “lightweight,” not a claim that every smaller artifact is appropriate. Ask for unexpectedly large, unclear, paid, or privileged acquisitions. A clone may contain executable setup hooks or supply-chain scripts; inspect before running any of them. Avoid automatic submodule checkout and large binary downloads unless needed.

## Workspace layout

```text
tools/portable/<tool>/<version>/
tools/repos/<project>/<commit>/
research/downloads/<source-slug>/
.venv/
sessions/<session-id>/
```

Keep tool records in the selected session's `tool-inventory.csv`. Record source URL, release or commit, hash when available, runtime requirements, expected network access, and the related approval ID. Uninstalling a system component is not a substitute for asking before installation.

## Python workflow

Prefer standard-library solutions for JSON, CSV, hashing, paths, argument parsing, and offline transformations. The included helpers use only the standard library. Check the actual interpreter with `python --version` after execution is approved; a launcher alias does not guarantee the intended interpreter.

For a project that needs dependencies, use an isolated environment. The following commands are examples to propose; environment creation is a script/tool execution unless already approved:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip --version
```

Once the Python task is authorized, the user's package-install preference allows needed workspace dependency installs. Use the environment's interpreter directly; PowerShell activation and an execution-policy change are unnecessary. Choose actual reviewed dependency names and versions for the task, then record them in a session requirements file. Do not run a copied install line containing unknown package names.

Python 3.14 compatibility varies by package and wheel availability. Check official package metadata, supported Python versions, and whether a compatible Windows wheel exists. A failed wheel resolution is an environment issue, not a reason to silently install compilers, downgrade the user's main Python, or switch to an unreviewed package. Prefer a supported pure-Python alternative; request an additional portable interpreter or build prerequisite if necessary.

Package installation can execute build code. Prefer known distributions from the official package index, pinned versions after checking current advisories, and hashes when a reproducible environment matters. Keep dependency changes local and explain any package with unusual native or network behavior.

## PowerShell and filesystem practice

Use `Set-Location -LiteralPath`, quoted paths, and Python `pathlib`. Do not assume Bash syntax, `/tmp`, `sudo`, `chmod`, or shell activation scripts exist. Use task-specific variable names; do not overwrite `$HOME` or `$CODEX_HOME`. Set explicit UTF-8 encoding when writing text.

Pass commands as argument arrays when the host permits it. Avoid assembling untrusted strings into a shell command. Treat URLs, filenames, and log fields as data. Before cleanup, resolve the exact path and confirm it stays in the intended session or tool folder. Prefer preserving artifacts over broad recursive deletion.

Do not disable TLS verification to make a tool work. Diagnose local trust, proxy, or certificate configuration and show the concrete problem. Keep test traffic identifiable according to the program's documented requirements.

## The approval request

Use [templates/tool-request.md](../templates/tool-request.md). Include:

- Why the tool is needed and the cheaper alternative considered.
- Exact executable, command, working directory, version/hash, and input artifacts.
- Network destinations, target scope mapping, authentication category, and request ceiling.
- Files created or changed, account state effects, privileges, expected duration, and stop signals.
- How results will be validated and how the operation can be canceled.

Ask one decision with a concrete bounded proposal. An approval record should quote or accurately summarize the user's actual answer. Never write an approval on the user's behalf or infer one from elapsed time.
