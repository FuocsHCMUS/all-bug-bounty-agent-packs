# How the concepts connect

```mermaid
flowchart TD
    A[Processes and operating systems] --> B[Addresses, ports, DNS, transport]
    B --> C[TLS and HTTP]
    C --> D[Cookies, tokens, and sessions]
    D --> E[Authentication: who is the principal?]
    E --> F[Authorization: may this action access this object?]
    F --> G[Trust boundaries, tenants, and data flow]
    G --> H[State, workers, caches, and interpretation]
    H --> I[Hypothesis and controlled experiment]
    I --> J[Evidence and bounded impact]
    J --> K[Reproduction and remediation]
    J --> L[Telemetry and detection]
    K --> M[Regression and learning]
    L --> M
```

A useful finding follows this path in reverse as an explanation: show the observed result, identify the failed rule, locate the boundary, and explain the underlying request and identity mechanisms. A useful prevention follows it forward: establish trustworthy identity, enforce the right permission, preserve it through state transitions, and verify the result.

The offensive and defensive perspectives share the same mechanism. The researcher asks how a rule might fail. The engineer asks where to enforce it. The SOC analyst asks which evidence would reveal the failure or attempted misuse. The learner needs to understand all three questions without assuming they have the same visibility.
