# Networking and security from first principles

Read only the sections needed for the current experiment. Each section starts with the normal mechanism, then connects it to a research question. The examples are synthetic and use reserved `.invalid` names.

## 1. A computer runs processes

A program is stored instructions. A process is a running instance with memory and operating-system resources. The operating system decides which files, devices, and network operations that process can use. A web server is a process or a group of processes that receives requests and produces responses.

A vulnerability in an application does not automatically grant operating-system administrator access. Impact depends on the code path, the process's privileges, isolation, accessible data, and available operations. Keep those layers separate when reading dramatic exploit claims.

**Question:** If a document read bypasses an application check, what additional evidence would be needed to claim control of the host operating system?

## 2. Addresses, ports, and sockets

An IP address identifies a network interface or reachable network endpoint in a routing context. IPv4 and IPv6 are different address formats and protocol families. A port helps the receiving system deliver traffic to the intended service. A socket is an operating-system interface used by a process to communicate.

The familiar HTTPS port is 443, but a port number does not prove the protocol or the application's identity. One address can host many websites; a service can use a non-default port. A cloud or CDN address may be shared by unrelated customers. An address relationship alone therefore cannot establish bug bounty scope.

Routing moves packets between networks. NAT can translate addresses and ports. A loopback address refers to the local machine; it is useful for local services and labs. “Internal” and “external” depend on the observer's network position, not merely on how a hostname looks.

**Question:** Why does discovering another hostname on the same IP not prove permission to test it?

## 3. DNS maps names to information

DNS lets applications look up information associated with names, commonly the addresses needed for a connection. Records can point directly to addresses or refer to other names. A hostname is easier for people to use than an address, but it is not a permission system.

Answers can change and be cached. Different resolvers or times can produce different results. A CNAME toward a provider does not by itself prove that a resource is abandoned, claimable, or within a company's testing scope. Source attribution and program scope remain separate questions.

**Question:** Which observations would you need beyond a DNS alias to understand who operates a particular application?

## 4. Transport and encryption

TCP provides an ordered byte stream between endpoints. UDP sends datagrams with different delivery semantics. Higher-level protocols build behavior on top; modern web traffic can also use HTTP/3 over QUIC, which runs over UDP. Do not assume that every web exchange uses exactly the same transport path.

TLS protects a connection's confidentiality and integrity and authenticates the server identity through certificate validation under the client's trust model. TLS does not decide whether the logged-in user may read a document. A perfectly encrypted request can still ask for an unauthorized object.

Disabling certificate verification removes an important identity check and changes the meaning of an experiment. Diagnose trust or proxy issues instead of treating verification errors as an inconvenience to bypass.

**Question:** Can HTTPS protect data in transit while the application returns it to the wrong user? Explain the two different checks.

## 5. URLs and origins

A URL can contain a scheme, host, port, path, query, and fragment. Different components parse and normalize these parts. The browser's origin is the scheme, host, and port. A path identifies a resource within a service; a query carries parameters; a fragment is normally handled by the client rather than sent as part of an HTTP request target.

```text
https://app.acme.invalid:443/api/documents/demo-1?view=summary#details
scheme  host             port  path                  query        fragment
```

A security check should use the component that matters to the rule. Comparing the beginning of a raw URL string is not generally equivalent to verifying the parsed destination host. Normalization matters because two strings may refer to the same resource, or two parsers may disagree about their meaning.

**Question:** Which URL components determine whether two pages have the same origin? Which component identifies the requested document?

## 6. HTTP is a request/response contract

The client sends a method, a request target, headers, and sometimes a body. The server returns a status, headers, and sometimes a body. Application semantics determine what the exchange means.

```http
GET /api/documents/demo-1 HTTP/1.1
Host: app.acme.invalid
Authorization: Bearer <TOKEN_MEMBER_A>
Accept: application/json

```

```http
HTTP/1.1 200 OK
Content-Type: application/json

{"id":"demo-1","title":"Synthetic document","marker":"TENANT_A_DEMO_7"}
```

This is an invented trace, not a request to execute. The token label replaces a secret. The marker identifies controlled data. A researcher would still need evidence of ownership, privacy, principal identity, and expected permission to interpret this response as authorized or unauthorized.

Statuses summarize outcomes but do not replace content analysis. A `200` can contain an application error. A `403` can contain an unintended body. A redirect can point elsewhere. The HTTP method is informative but does not guarantee absence of state changes in a particular application.

**Question:** What must you examine beyond the status to determine whether private data was returned?

## 7. Sessions connect requests to an identity

HTTP requests do not inherently remember a person. An application commonly uses a session identifier, cookie, bearer token, or another credential to connect requests to a principal. The browser may automatically attach cookies under their scope and browser rules. A bearer token is a capability: possession can authorize its intended use.

An opaque session token may point to server-side state. A structured token may contain readable claims, but claims become trustworthy only through the correct validation. Reading or decoding a token is different from validating it. Secrets should be replaced by stable labels in reports and lesson files.

Sessions have lifecycles: creation, renewal, expiry, logout, revocation, and response to role or password changes. Different products promise different revocation semantics. Establish the promise before calling a surviving artifact a flaw.

**Question:** Why is a token that says `role=admin` not enough, by itself, to establish that the server will or should treat the caller as an administrator?

## 8. Authentication and authorization answer different questions

Authentication asks “Who is making this request?” Authorization asks “May this principal perform this action on this resource under these conditions?” Correct authentication can coexist with broken authorization.

| Principal | Resource | Intended action | Expected policy |
| --- | --- | --- | --- |
| Member A in tenant A | Private document in A | Read | Allow if role permits |
| Member B in tenant B | Private document in A | Read | Deny absent a legitimate share |
| Revoked member of A | Private document in A | Read | Follow the product's defined revocation semantics |

The server needs a trustworthy relationship among the authenticated subject, actual resource, action, and current policy. A user-supplied tenant parameter may help route a request, but it is not proof of membership. An unpredictable document ID makes guessing harder; it does not enforce permission.

**Question:** If the list page hides A's document from B but the download returns it to B, which boundary failed?

## 9. Trust boundaries and data flow

A trust boundary separates contexts with different authority or assumptions. Examples include browser to server, one tenant to another, application to database, request handler to worker, and retrieved text to an AI tool decision.

Follow data through the system. Where did it originate? Who can change it? Which component validates it? Which component has authority to act? Does the correct decision happen before protected data or effects are produced?

```text
Controlled user -> client request -> authentication -> object lookup
                -> authorization -> protected operation -> response
```

Real systems can reorder and distribute these steps. A useful model marks observed components separately from inferred ones. A black-box response may prove a boundary failure without revealing the database schema or exact middleware implementation.

**Question:** Which parts of that diagram can an HTTP trace establish directly, and which usually require source or internal telemetry?

## 10. Data, interpretation, and injection

Computers interpret structured languages: SQL, HTML, shell commands, templates, paths, URLs, and serialized objects. Injection occurs when input intended as data changes the meaning of an interpreted operation. The exact parser and context determine the mechanism.

The repair must preserve the boundary: parameterized database operations, correct contextual encoding, explicit command arguments, reviewed sanitization, constrained resource resolution, or an appropriate structured API. Blocking one suspicious string is usually weaker than keeping data separate from executable structure.

A parser error can suggest a backend. Reflected text can suggest an output path. Neither alone proves execution, data access, or a high-impact compromise.

**Question:** What evidence would distinguish “the server printed my text” from “my text changed the operation it executed”?

## 11. State, queues, caches, and time

State is information that survives beyond one operation: membership, document privacy, job status, invitation consumption, or account balance. A worker may perform an action later than the request that created its job. A cache reuses a prior result. These mechanisms create important questions about whose authority applies and at what time.

For a job, compare permission at enqueue and execution. For a cache, compare the dimensions that affect visibility against the actual cache key. For a one-use operation, consider whether checking and consuming share the correct atomic boundary.

Not every delay is a vulnerability. Eventual consistency may be part of a documented design. Establish the invariant and the harmful capability before naming a race or stale-authority issue.

**Question:** Why might authorizing only when a long-lived export job is created be insufficient after membership is revoked?

## 12. Vulnerability vocabulary

A weakness is a general class of mistake. CWE classifies weakness types. A vulnerability is a specific security-relevant failure in a product or deployment. A CVE identifies a disclosed vulnerability record. An exploit uses a vulnerability to obtain a capability. A PoC demonstrates a mechanism under stated conditions. A finding is your evidence-backed conclusion about the assessed environment.

A product banner plus a CVE search result is a lead. Applicability also depends on build, patch state, configuration, reachable feature, privileges, and behavior. A deployment can contain a package without using its vulnerable feature.

CVSS technical severity, EPSS exploitation likelihood, known-exploitation catalog status, business risk, and bounty payment answer different questions. Do not let a scary label replace the actual demonstrated impact.

**Question:** What is still unknown when a server advertises an old product version?

## 13. Security experiments are controlled comparisons

A hypothesis predicts an observable result. A control checks normal behavior or rules out an alternative. A good experiment changes one relevant variable, records actual inputs and outputs, and states what would disprove the idea.

For a tenant issue, the comparison might keep the object constant while changing the controlled principal. But that works only if sharing state, token identity, cache behavior, and role are understood. Repetition helps only when it answers a real uncertainty; repeating a flawed setup can repeat the same mistake.

Keep observations, inferences, and untested extensions separate. One observed endpoint does not establish every endpoint. One negative result does not establish company-wide security.

**Question:** Name one alternative explanation for a surprising cross-account result and the control that would separate it from an authorization failure.

## 14. Pentesting, AppSec, and SOC connect

Pentesting explores whether a system's security properties fail under assessed conditions. Application security also designs, builds, reviews, and verifies those properties. A SOC monitors and investigates security-relevant activity, using telemetry that a researcher often cannot see.

Prevention blocks an invalid action. Logging records an event. Detection identifies a concerning event or sequence. Response investigates and contains it. Regression testing checks that a repaired behavior stays repaired. These are related activities with different evidence requirements.

For each finding ask: where should the operation be stopped, which event would reveal it, which context makes that event meaningful, how could a defender investigate it, and which test would prevent recurrence? Describe internal telemetry as proposed unless it was actually supplied.

**Question:** Why does observing a denied request establish neither that an alert fired nor that no alert fired?

Continue with [the learning path](LEARNING_PATH.md), [the glossary](GLOSSARY.md), or [the worked example](../examples/fictional-tenant-boundary/README.md).
