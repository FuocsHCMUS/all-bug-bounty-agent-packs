# Working glossary

| Term | Plain meaning |
| --- | --- |
| Actor/principal | The identity whose permissions apply to an operation |
| Asset | A system, application, resource, or artifact being assessed |
| Authentication | Establishing which identity a request represents |
| Authorization | Deciding whether that identity may perform an action on a resource |
| Availability | Whether authorized use remains possible when needed |
| Backport | A fix applied to an older maintained branch |
| Bearer capability | Authority that can be exercised by whoever possesses the value |
| Blast radius | The bounded set of resources or operations an issue can affect |
| Boundary | A separation between contexts with different trust or authority |
| Cache | A mechanism that reuses previously computed or retrieved results |
| Callback | A later request or event sent to a configured destination |
| Canonicalization | Converting equivalent representations into a chosen normalized form |
| Claim | A statement whose supporting evidence and limits should be explicit |
| Client | Software that requests a service, such as a browser or mobile app |
| CNA | An organization authorized within the CVE Program to assign and publish CVE records |
| Confidentiality | Restricting information access to intended parties |
| Control | A comparison or mechanism used to test expected behavior |
| Cookie | Browser-managed data sent under defined scope and browser rules |
| CORS | Browser rules for reading responses across origins |
| Correlation ID | A value used to connect related events across components |
| CSRF | An unwanted authenticated action induced from another context |
| CVE | An identifier and record for a disclosed vulnerability |
| CVSS | A structured way to describe technical vulnerability severity |
| CWE | A classification system for types of software weaknesses |
| Data flow | The path data takes through components and transformations |
| DNS | The naming system used to look up information such as network addresses |
| Endpoint | A reachable service location or an application operation, depending on context |
| EPSS | A model-based estimate of near-term exploitation likelihood for published CVEs |
| Evidence | Captured information supporting a particular claim |
| Exploit | A technique that uses a vulnerability to obtain a capability |
| False negative | A real condition that a check or detection misses |
| False positive | A flagged condition that is not the issue being claimed |
| Finding | An evidence-backed assessment conclusion about a specific environment |
| Hash | A deterministic fingerprint useful for comparing artifact contents |
| Header | A named metadata field in a request or response |
| HTTP | A protocol for exchanging requests and responses |
| Hypothesis | A proposed explanation that predicts a testable result |
| Idempotency | Repeating an operation without creating additional intended effects |
| Inference | An interpretation drawn from observations |
| Injection | Untrusted data changing the meaning of an interpreted operation |
| Integrity | Protecting information and operations from unauthorized change |
| Invariant | A rule that should remain true across valid inputs and states |
| IP address | An address used in network communication and routing |
| Job/worker | Work queued for processing, and the process that performs it |
| JWT | A structured token format whose trust depends on correct validation |
| KEV | CISA's catalog of known exploited vulnerabilities |
| Least privilege | Granting only the authority required for the intended operation |
| MFA | Authentication using more than one factor category |
| Negative control | A comparison expected to lack the effect under investigation |
| Nonce | A value used to bind or distinguish a particular protocol operation |
| OAuth | A framework for delegated authorization |
| Object | A specific application resource, such as one document |
| OIDC | An identity layer built on OAuth 2.0 |
| Origin | The browser security tuple of scheme, hostname, and port |
| Parser | Software that interprets structured input |
| Patch | A change intended to repair behavior |
| PoC | A proof of concept demonstrating behavior under stated conditions |
| Policy | The rule that determines whether an action is allowed |
| Port | A transport identifier used to direct communication to a service |
| Privilege | Authority to access data or perform an operation |
| Race condition | A failure dependent on the ordering of interacting operations |
| Reachability | Whether relevant inputs can actually reach a particular code path |
| Redaction | Removing or replacing sensitive details while preserving useful evidence |
| Regression test | A check that detects the return of an earlier defect |
| Replay | Reusing a prior message or operation |
| Resolver | A component resolving a name or field, depending on the system |
| Scope | The explicitly defined assets and methods of an engagement |
| Session | Context connecting multiple requests to an authenticated identity |
| Sink | A sensitive operation receiving data from an input path |
| SOC | A security operations function that monitors and investigates events |
| Source | The origin of input data or a reference supporting a claim |
| SSRF | Unintended server-side requests crossing a destination or authority boundary |
| State machine | A model of allowed states and transitions |
| Telemetry | Recorded events and measurements used to understand system behavior |
| Tenant | A separate customer or organizational workspace |
| TLS | Protocols protecting a connection's confidentiality, integrity, and peer identity |
| Token audience | The intended recipient or service context for a token |
| Trust boundary | A point where data or authority crosses contexts with different assumptions |
| VDP | A vulnerability disclosure program, which may have no bounty payments |
| VRT | Bugcrowd's baseline vulnerability rating taxonomy |
| XSS | Untrusted content executing in a relevant browser script context |

For exact specifications, versions, and applicability, consult current authoritative sources. The glossary supplies intuition, not a replacement for a protocol or program specification.
