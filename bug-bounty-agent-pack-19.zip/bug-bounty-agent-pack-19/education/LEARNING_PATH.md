# A practical learning path

This is a sequence of prerequisites, not a deadline or a promise of bounty income. Use the agent as a teacher: predict a result, inspect a synthetic artifact, explain the mechanism, and answer a teach-back question before moving forward.

| Stage | Learn | Practice | Evidence of understanding |
| --- | --- | --- | --- |
| 1. Networking | Processes, addresses, ports, DNS, routing, transport, TLS | Annotate a fictional URL and connection path | Explain which layer identifies the host, service, and protected connection |
| 2. HTTP and browsers | Requests, responses, headers, cookies, origins, redirects | Read the synthetic HTTP traces in this pack | Explain why status alone is insufficient |
| 3. Identity and permission | Sessions, roles, tenants, object rules | Complete an allow/deny policy table | Distinguish authentication from authorization |
| 4. Research quality | Sources, CVE conditions, hypotheses, controls | Fill a CVE applicability card with unknowns intact | Explain why a version match is a lead |
| 5. Controlled testing | One variable, negative controls, evidence | Use the offline tenant lab after approving execution | Predict vulnerable and repaired results |
| 6. Reporting | Reproduction, demonstrated impact, severity limits | Rewrite the fictional example as a concise draft | Every major claim points to evidence |
| 7. Defense and SOC | Prevention, logging, detection, triage, regression | Design synthetic allowed/denied/shared events | State data requirements and false-positive cases |
| 8. Advanced reasoning | Lifecycle, caches, workers, composition, patch variants | Create three distinct hypotheses from one mechanism | Each has a disconfirming result and a minimal test |

## Suggested progression

Spend the first sessions entirely on synthetic examples and supplied traces. Learn to identify the subject, action, resource, state, and policy before using specialist tools. Then research a current public program and create a brief without testing its assets. Move to live work only when the scope, accounts, and experiment are concrete.

Choose one weakness family at a time. Authorization is a useful teaching example because it exposes the distinction among identity, object ownership, and policy without needing a large toolchain. It is not a guarantee of easy findings.

## Source study

Use the official resources in [SOURCES.md](../SOURCES.md): OWASP WSTG for test themes, ASVS for security requirements, vendor advisories and CVE sources for applicability, original writeups for mechanisms, and MITRE ATT&CK for adversary behavior where the mapping fits. Read an original source, summarize its mechanism in your own words, identify prerequisites, and create a local counterexample or control.

Do not memorize a payload catalog before understanding what interprets the input and why the boundary matters. A familiar payload failing does not show a system is secure, and an unfamiliar error does not prove exploitation.

## Personal progress log

After each session answer:

1. Which concept can I now explain without the agent?
2. Which observation changed my model of the system?
3. Which assumption was wrong or remains unknown?
4. What distinguishes the failure from normal behavior?
5. Which prevention and detection ideas follow from the mechanism?
6. What is the smallest next exercise?

Save this in the session retrospective. Review misconceptions and unresolved prerequisites before adding more tools.
