# Synthetic case study: a private document read

**Everything in this example is invented for learning. No company was tested, no network requests were made, and no real vulnerability or CVE is claimed.** The `.invalid` hostname and all identities, markers, and timestamps are fictional.

Read [the traces](traces.txt), [the finding](finding.md), [the lesson](lesson.md), and [the defensive review](defensive-review.md). The offline `packctl.py lab` command illustrates a related policy mistake using pure Python objects; it is not an HTTP reproduction of these fictional traces.

## Scenario

Acme Notes has separate workspaces, called tenants. `member_a` belongs to tenant A. `member_b` belongs only to tenant B. Document `demo-1` belongs to A, is private, and has no external shares. A's role permits reading it; B has no permission. Both accounts are controlled by the fictional researcher.

The invented observations are:

- `EV-DEMO-1`: A reads the document and receives its synthetic marker.
- `EV-DEMO-2`: B's request receives the same private marker.
- `EV-DEMO-3`: an unauthenticated request receives no document.
- `EV-DEMO-4`: the scenario's policy table establishes no valid share for B.

The key hypothesis is that authentication is enforced while object-level authorization is missing on this particular route. The traces establish behavior in the scenario; they do not reveal the internal implementation. The offline lab supplies one possible implementation of that mistake, explicitly as a model.

## What to practice

Identify the principal, action, resource, privacy rule, changed variable, and control. Then explain why random document IDs, a hidden UI button, or HTTPS would not repair this permission failure. Finally, identify which internal fields a defender would need to detect it reliably.
