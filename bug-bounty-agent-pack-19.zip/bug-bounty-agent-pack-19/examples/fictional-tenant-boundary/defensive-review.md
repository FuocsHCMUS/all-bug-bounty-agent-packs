# Synthetic defensive review

## What the evidence supports

| Category | Statement | Limit |
| --- | --- | --- |
| Observed control in the scenario | An unauthenticated request receives no document | One invented route and state |
| Demonstrated weakness in the scenario | A private marker crosses from tenant A to B | No claim about other routes or companies |
| Proposed prevention | Authorize the actual object against the principal before returning it | Implementation is not supplied |
| Proposed detection | Compare a successful operation against the authoritative expected permission | Requires company-side identity and policy context |
| Not assessed | Logging, alerting, incident response, encryption, deployment controls | No internal data exists |

## Telemetry proposal

Useful fields would include request ID, actor label, effective tenant, actual resource tenant, action, sharing/delegation context, policy decision/reason, and semantic outcome. A cross-tenant comparison without sharing context would incorrectly flag legitimate shares or delegated service actions.

An illustrative detection asks whether a private-object action succeeded while policy expected deny. It should be validated on synthetic same-tenant allowed, cross-tenant denied, valid shared, revoked-member, and deliberately faulty events. No production query is supplied because there is no real schema or SIEM engine.

## Triage and regression

A defender could correlate request and policy events, verify the actor's membership at the event time, inspect alternate object paths, and assess whether historical access records support any broader exposure. These are proposed internal activities, not observations from the researcher.

Regression should test both legitimate and forbidden access and include revocation and directly related representations. Detection complements the fix: an alert after a forbidden response has already returned is not equivalent to preventing disclosure.
