# Synthetic F-DEMO-1 — Private document returned across tenant boundary

Status: teaching example, not a real submission.

## Summary

In the fictional Acme Notes scenario, an authenticated reader belonging only to tenant B receives tenant A's private document through `GET /api/documents/demo-1`. The scenario establishes that no sharing grant exists. The demonstrated impact is one unauthorized cross-tenant read of controlled synthetic data.

## Preconditions and reproduction

1. Use the scenario's two authenticated controlled members and private A document, as defined by `EV-DEMO-4`.
2. Read the document as A. `EV-DEMO-1` returns marker `TENANT_A_DEMO_7`, confirming the normal permitted action.
3. Keep the resource constant and use B's credential context. `EV-DEMO-2` returns the same marker despite B's lack of permission.
4. Compare the unauthenticated control. `EV-DEMO-3` returns no document.

These are steps for interpreting the invented traces, not commands to run.

## Expected versus actual

B should receive no protected document content because the private object belongs to a tenant where B has no membership or share. Instead the response contains A's controlled marker. The content, identity context, and policy fixture support the conclusion; status `200` alone would be insufficient.

## Impact and limits

The scenario demonstrates private document disclosure to an authenticated member of another tenant on this route. It does not demonstrate write access, access to every document, account takeover, historical exploitation, or host compromise. No numeric severity, platform priority, payment, or CVE is assigned.

## Root-cause inference and repair

The results are consistent with checking login while failing to apply the object's tenant permission. They do not establish the actual middleware or query implementation. A repair should bind the server's object read to the authenticated principal and authoritative membership/sharing policy before returning content.

Regression cases should preserve A's legitimate read, reject B's private-object read, reject anonymous access, handle revoked membership according to the product promise, and check directly related alternate paths. A real report would need captured evidence and current program scope, neither of which exists in this example.
