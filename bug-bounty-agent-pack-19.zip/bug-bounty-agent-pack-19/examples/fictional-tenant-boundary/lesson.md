# Lesson: identity is not permission

## Intuition

A reception desk can know who you are without granting you access to every office. The computer equivalent needs an actual permission decision for each protected operation; recognizing a session is only the identity step.

## Follow the request

The resource is document `demo-1`. The action is `read`. The actor changes from A to B while the object stays the same. The fixture says the document is private to tenant A and B has no share. The response nevertheless includes A's marker. That is the precise failed relationship.

The anonymous denial shows one useful behavior: this route distinguishes an unauthenticated request. It does not fix or negate the cross-tenant failure. The application can pass one check and fail another.

## Engineering depth

A possible implementation checks whether a session exists, fetches by document ID, and returns the result. A stronger design evaluates the actual object's policy against the real principal before serialization. The offline lab contrasts these two rules. It does not claim that any real company uses either implementation.

Random IDs reduce guessing but do not grant permission. HTTPS protects transport but does not choose the rightful recipient. Hiding the document in B's UI does not prevent B from making a direct request if the server accepts it.

## Practice

Predict what changes if the product intentionally grants B a valid read-only share. The same response could become authorized; the report would need a different policy premise. This is why privacy and sharing controls matter.

Teach-back questions:

1. Which observation supports correct unauthenticated rejection?
2. Which evidence establishes B's lack of permission?
3. Which additional claim would require a separate test: private read, write access, or universal tenant exposure?

Answer guide: the anonymous trace supports only its bounded rejection; the fixture supplies the intended policy; write access and broader scale are untested. For a real assessment the fixture's assertions would need actual evidence.
