# Identity, sessions, and delegated authority

## Concepts first

Authentication establishes which principal a request represents. A session carries that identity across requests. Authorization decides whether that principal can perform this action on this resource now. A role is a bundle of permissions; a tenant is a customer or organizational boundary. These concepts interact but are not interchangeable.

## Map the lifecycle

Trace registration, verification, login, session issuance, logout, recovery, password changes, MFA enrollment/removal, role changes, invitations, membership revocation, and account deletion. Record expected effects on existing sessions, refresh tokens, signed links, and background work. Product promises determine which revocation semantics matter.

| Research question | Small distinguishing comparison | Important alternative |
| --- | --- | --- |
| Does current membership govern access? | Same controlled session and object before/after membership revocation | Documented grace period or independent capability |
| Is the role check consistent across representations? | Same controlled actor/action through UI and documented API | Different intended permissions |
| Is recovery bound to the right identity? | Trace the token's intended account and purpose in an approved local or controlled flow | Legitimate account-linking behavior |
| Is a one-time invitation consumed consistently? | Local state model or minimal allowed controlled transition | Invitation intentionally allows multiple members |
| Does a child object inherit the right policy? | Parent read and child download under the same actor | Child is intentionally public/shared |

## OAuth/OIDC and signed tokens

Explain OAuth as delegated authorization and OIDC as an identity layer. Map client, authorization server, resource server, redirect destination, authorization response, token, and intended audience. Check the documented binding among client, redirect, state, nonce, code verifier, issuer, and audience. A missing parameter matters only when it creates a demonstrable security consequence in that flow.

For JWT-like tokens, distinguish readable claims from validated claims. Ask which component validates signature, issuer, audience, lifetime, and key selection before using a claim. Decode a synthetic token locally for learning; do not confuse decoding with verification. A key identifier or algorithm label is an input to inspect, not authority to choose arbitrary trust.

## Hypothesis generation

Use lifecycle reversal, subject confusion, capability lifetime, and route asymmetry. Investigate whether authority is recomputed after a role change or copied into a long-lived artifact. For account linking, identify which identity proves ownership of each account and whether both proofs bind to the same operation.

## Evidence and impact

Record principal labels, session origin, permissions, resource privacy, transition timestamps, and actual results. Mixed browser profiles and stale cookies are common alternative explanations. A successful login is not proof of access to protected resources; a stale session is not necessarily a reportable issue if the documented model permits its lifetime.

Account takeover is a strong claim: establish the actual capability over a controlled account and its prerequisites. Do not infer it from a redirect, a token-shaped string, or a recovery response alone.

## Repair, defense, and lesson

Potential enforcement points include centralized policy evaluation, audience-bound tokens, correct lifecycle invalidation, and consistent object checks. Proposed telemetry should preserve the actor, session event, role transition, resource, policy decision, and request ID without logging credentials.

Teach-back: Why can a valid session still receive a correct denial? What additional evidence would show that a signed link violates a revocation promise?
