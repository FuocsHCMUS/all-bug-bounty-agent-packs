# APIs, objects, properties, and tenants

## Concepts first

An API is a contract for requesting data or actions. An object is a particular resource. Object-level authorization controls which resources a principal may access; function-level authorization controls which actions they may invoke; property-level authorization controls which fields they may read or change. A list filtered in the client does not necessarily protect the underlying object route.

## Build a permission table

Use controlled principals and resources. Record tenant membership, role, object owner, sharing state, and permitted actions. Include a known allowed case, a known forbidden case, and a nonexistent object. Determine actual intended policy before interpreting differences.

| Surface | Invariant to investigate | Meaningful contrast |
| --- | --- | --- |
| Direct resource read | Retrieved object is authorized for the actor | Own private object versus other controlled tenant's private object |
| Child/attachment route | Child belongs to an authorized parent | Parent access versus child access |
| List/search/export | Every returned item follows the actor's visibility | List result versus direct read versus export |
| Update/create | Sensitive properties derive from authority, not client assertion | Documented field versus server-managed ownership/role field in a local model |
| Bulk request | Every item is independently authorized | Minimal mixed set of controlled allowed and forbidden items |
| Background API job | Enqueue and execution use the intended authority | Permission before and after a controlled lifecycle transition |

## REST, GraphQL, and alternate representations

For REST, examine object relationships and policy consistency across actions. HTTP method names do not prove that an operation is read-only; check application semantics. For GraphQL, map resolver authorization, nested relationships, field visibility, and documented batch behavior. Introspection availability is not automatically a vulnerability. A deeply nested response is only meaningful when it crosses a real policy boundary.

For API version differences, identify whether the versions share policy helpers or data models. An old version endpoint is not a finding merely because it exists. For schema binding, ask whether the server accepts client-selected authority-bearing properties and whether doing so violates the intended role model.

## Advanced reasoning

Investigate a resource's true tenant rather than trusting a path parameter's tenant. Compare policy at parent lookup, child lookup, and final object serialization. Consider polymorphic resources, delegated projects, external shares, soft-deleted objects, restored membership, and worker-generated artifacts. Each context may change the legitimate access rule.

Use metamorphic tests: changing an object from an allowed to a forbidden controlled tenant should change the decision, while harmless presentation changes should not. A difference in response length alone is weaker evidence than a controlled private marker or a forbidden state transition.

## Evidence and repair

Capture account contexts, ownership/privacy evidence, relevant requests and responses, and legitimate-sharing controls. Root-cause proposals may include policy-aware object queries, centralized authorization, per-item checks, property allowlists derived from roles, and consistent enforcement across resolvers and workers.

Proposed SOC data needs actor, effective tenant, actual resource tenant, action, authoritative permission decision, result, and sharing/delegation context. The researcher cannot assume those fields exist internally.

Teach-back: Why does an unpredictable ID fail to replace object authorization? Why can a correct list endpoint coexist with a vulnerable download route?
