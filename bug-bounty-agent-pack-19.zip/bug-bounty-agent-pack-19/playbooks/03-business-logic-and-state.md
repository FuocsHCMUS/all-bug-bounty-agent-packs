# Business logic, state machines, and concurrency

## Concepts first

A business rule defines a valid operation in the product: who can approve an action, how many times a benefit can be used, when an invitation is valid, or which transition follows another. A state machine describes allowed states and transitions. A race condition arises when concurrent operations interact with shared state in a way the rule did not anticipate.

## Extract the rule before testing

Ask what must always be conserved or enforced: membership count, one-time use, ownership, approval order, quota, inventory, or ledger balance. Represent the rule as a small state table. Identify the authoritative data and the component that changes it.

| Mechanism | Hypothesis | Preferred initial experiment |
| --- | --- | --- |
| One-time operation | Consumption and effect are separate decisions | Offline transition sequence with synthetic state |
| Idempotency | Replay key is not bound to actor or operation inputs | Local model of key lookup and effect |
| Multi-step approval | Final action trusts a stale or different approval | Controlled transition table and source/trace review |
| Revocation | A queued operation retains authority after it should end | Enqueue/execute timeline with known policy |
| Counter/quota | Check and update do not share the intended atomic boundary | Deterministic interleaving in a local model |
| Partial failure | Retry repeats an already completed effect | Local failure/retry simulation |

## Think about interleavings

Write a timeline for two operations: read state, decide, update state, commit effect. Show exactly which ordering violates the invariant. This often reveals whether a database constraint, transaction, lock, or idempotency record is necessary. Do not equate “two requests at once” with a demonstrated race.

Start with local, deterministic interleavings and source evidence. Live concurrency can create significant state effects; propose a narrow test only when the program permits it and the user approves its exact budget. Never use real financial loss, uncontrolled purchases, production resource exhaustion, or another person's account as the proof.

## Composition and edge states

Consider transitions involving cancel, retry, expire, refund, restore, archive, transfer, and duplicate. Ask whether each transition revalidates the same rule. External integrations may deliver events more than once or out of order. The application must define which duplicate and late events are legitimate.

An apparent inconsistency may be eventual consistency rather than a security failure. Establish the promised semantics and the observable harmful capability. A stale UI indicator is weaker than an authoritative forbidden action that actually completes.

## Evidence and repair

Record initial state, operation identity, order, actor, transition times, authoritative final state, and all relevant control results. A local demonstration needs an explicit limitation about real storage and scheduling behavior.

Repair options include atomic constraints, correct transaction boundaries, actor-bound idempotency, explicit state preconditions, and authorization at the moment an effect is committed. Proposed telemetry should connect request IDs, operation keys, state transitions, retries, and the business effect.

Teach-back: Why can a retry be correct for a read yet dangerous for a state-changing operation? Which invariant distinguishes a harmless duplicate response from a duplicated business effect?
