# Web and browser trust boundaries

## Concepts first

The browser enforces rules about origins, navigation, scripts, cookies, and resource access. An origin is the scheme, hostname, and port. Browser security mechanisms help applications isolate content; they do not replace server-side permissions.

Cross-site scripting means untrusted data becomes executable content in a relevant browser context. CSRF concerns an unwanted authenticated action induced from another context. CORS controls when scripts can read cross-origin responses; it is not the same mechanism as preventing every cross-origin request.

## Model sources, interpretation, and effect

For an injection lead, identify where input comes from, which parser/context interprets it, whether escaping or sanitization occurs, and what capability execution would have. Reflection alone is not execution. A local DOM change or a harmless marker is not automatically evidence of session compromise or cross-user impact.

| Surface | Research question | Critical control |
| --- | --- | --- |
| Reflected/stored content | Does untrusted input reach an executable context? | Correct context-specific encoding or sanitization |
| DOM rendering | Does client code reinterpret data as markup or code? | Source-to-sink trace and actual DOM behavior |
| Cross-origin API | Can an unintended origin read sensitive controlled data with the required credentials? | Browser-enforced behavior and credential context |
| State-changing request | Does the server verify request intent appropriately? | Real action semantics and authentication context |
| Redirect/navigation | Is a destination trusted for a security-sensitive flow? | Exact parsed destination, not visual similarity |
| Frame embedding | Does embedding enable a meaningful sensitive action? | Actual interaction and product policy |
| Cache/edge behavior | Does a response intended for one identity appear in another context? | Distinguish browser, edge, and application caches |

## Advanced reasoning

Compare validation before and after URL parsing. Hostname prefixes, path strings, and user-visible labels are not substitutes for parsed origin checks. Trace security-sensitive redirects through the entire documented flow; a generic open redirect does not automatically prove credential disclosure.

For content rendering, distinguish HTML, attribute, URL, script, stylesheet, and structured-data contexts. The correct defense depends on the interpreter. For postMessage-like communication, identify sender origin, receiving window, message type, and authority-bearing data before forming a hypothesis.

For caches, determine which response attributes depend on user identity and whether the actual cache key accounts for them. Only examine shared-cache interactions in an environment and test design the program explicitly permits; use controlled markers and stop once the boundary is established.

## Evidence and repair

Use an approved browser context, controlled accounts, and minimally invasive markers. Record actual browser behavior, console/network evidence where relevant, and the precise security consequence. Missing headers, permissive-looking settings, or scanner warnings are leads that need context.

Repairs can include contextual output encoding, reviewed sanitization, strict destination binding, proper CSRF defenses, correct origin validation, and identity-aware caching. CSP is a defense layer whose presence or absence does not alone establish whether a specific injection is exploitable.

Teach-back: Why does a CORS setting affect response reading rather than all request sending? What evidence turns reflected text into a confirmed browser execution issue?
