# Data interpretation and server-side boundaries

## Concepts first

A server often passes input to another interpreter or resource boundary: a database, filesystem, template engine, command runner, parser, URL fetcher, or object decoder. A security problem occurs when untrusted data gains authority or interpretation beyond the intended contract.

Map source -> transformation -> validation -> authorization -> sensitive operation -> observable result. Identify the runtime and actual API behavior from authoritative documentation or source. Avoid treating every dangerous-looking function call as a reachable flaw.

## Research matrix

| Surface | Failed assumption to investigate | Minimal meaningful evidence |
| --- | --- | --- |
| Database query | Data is interpreted as query structure | Authorized source trace or a bounded controlled semantic difference |
| Template rendering | User data becomes template/program logic | Local reproduction or harmless controlled rendering proof |
| File access | Normalized requested path remains inside the intended resource boundary | Synthetic path-resolution cases and actual authorization context |
| Upload/processing | File metadata or content is trusted by later processors | Controlled artifact, parser behavior, and reachable processing path |
| URL retrieval | Destination authority is validated consistently at the actual fetch | Approved controlled destination and observable fetch behavior |
| Structured decoding | Input can select unsafe types or side effects | Source/patch evidence and isolated synthetic reproduction |
| Command invocation | Input can change command structure rather than an argument value | Exact API trace and local controlled model |

## Server-side request behavior

For an SSRF-like lead, identify who chooses a URL, which component fetches it, which protocols and redirects it follows, and how destination policy is enforced. A DNS lookup, timeout, or echoed URL alone may not prove a server-side fetch. A controlled callback service is an additional tool/data destination that needs approval and program compatibility.

Use a user-controlled benign endpoint when a live proof is permitted. Do not turn a generic fetch feature into private-network exploration, metadata credential access, or a broader pivot. If the interesting question is address normalization, redirect revalidation, or DNS resolution timing, model it locally and propose the relevant policy check.

## Files, archives, and uploads

Distinguish filename validation, path normalization, filesystem resolution, symlinks, archive members, content type, and later interpretation. A file extension is a convention, not proof of how a processor behaves. A successful upload is not remote execution. Trace the actual storage and processing authority before assigning impact.

Use inert synthetic files. For archive extraction or path traversal reasoning, a local temporary workspace is usually sufficient to explain the mechanism and compare a repaired containment check. Avoid overwriting application or system files as proof.

## Injection and decoding

Read vendor patches and library documentation to establish actual interpretation. Error strings can reveal a parser or backend, but they do not prove data access, command execution, or privileged context. Time-based signals need controls for network noise and background work; prefer direct controlled semantics when available.

For high-impact server execution or memory-safety leads, use source analysis, owner-provided environments, and isolated labs to establish the mechanism. A report can be useful with carefully bounded evidence and explicit limits; destructive proof is unnecessary.

## Repair and telemetry

Potential repairs include parameterized APIs, explicit argument boundaries, policy-aware resource resolution, protocol/destination validation at the actual use point, bounded parsers, and minimal processing privileges. Proposed detection needs context such as destination, operation, principal, job, policy decision, and anomalous processing behavior. Explain which data is unavailable externally.

Teach-back: Why is a URL string that passes a superficial check not necessarily the destination a fetcher will use? Why does a successful upload say little about the processing chain?
