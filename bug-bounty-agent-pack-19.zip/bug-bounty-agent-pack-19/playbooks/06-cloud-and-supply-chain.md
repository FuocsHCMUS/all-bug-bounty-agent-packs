# Cloud boundaries, configuration, and software provenance

## Concepts first

Cloud resources have identities, policies, and scopes just as application objects do. A public endpoint can be intentionally public. A denied request can reflect a policy decision without revealing the complete configuration. Supply-chain analysis asks where software came from, what version and dependencies are present, and which code or data is trusted during build and runtime.

## Cloud research questions

- Does a controlled identity receive exactly the intended resource permissions?
- Are object visibility and application sharing promises consistent?
- Does an integration bind authority to the right customer, project, and operation?
- Does a signed capability limit object, action, audience, and lifetime appropriately?
- Does a worker or service role act with broader authority than the requester should obtain?
- Does an exported or cached artifact preserve the intended tenant boundary?

Inspect only assets explicitly included in the selected program. A cloud-provider hostname, bucket name, shared IP, dangling DNS record, or branded resource does not alone establish ownership or testing scope. A possible takeover lead remains a lead until authoritative ownership conditions and program-permitted proof are established; do not claim or provision a third-party resource as an automatic test.

## Evidence and controls

Use owner-provided configuration or controlled-account behavior where available. Compare the same resource under allowed and forbidden contexts. Redact signed URLs and credentials: a URL can itself be a bearer capability. Do not test discovered credentials against services; treat their apparent presence as sensitive evidence requiring a minimal report and user guidance.

## Dependency and build analysis

Identify exact package coordinates, lockfile versions, build artifacts, provenance statements, and runtime reachability. A dependency can be present but unused, development-only, mitigated, vendored with a patch, or outside the affected feature. Use [CVE applicability](../workflows/04-cve-research.md) rather than equating a dependency alert with a deployed exploit.

Read install and build scripts as executable code. Distinguish acquiring source from executing it. Pin a repository commit and inspect dependencies before running a PoC. A README's popularity or a passing upstream badge does not verify that the local artifact is appropriate for the user's Windows/Python environment.

## Advanced hypotheses

Investigate authority copied across asynchronous boundaries, environment-specific policy drift, stale capability lifetime, tenant identity lost in artifact generation, and differences between application-level policy and underlying resource policy. Where source exists, trace which service identity reaches which cloud operation and whether requester context is enforced before that point.

## Defense and teaching

Remediation may involve least-privilege service identities, policy binding at the correct resource, short-lived capabilities with appropriate semantics, explicit tenant context, dependency inventory, and reproducible updates. Proposed cloud detections need provider audit events and identity/resource enrichment; a researcher cannot infer those logs from an HTTP response.

Teach-back: Why is “publicly reachable” different from “publicly readable”? Why does a vulnerable package version in a lockfile not prove the application's affected code path is reachable?
