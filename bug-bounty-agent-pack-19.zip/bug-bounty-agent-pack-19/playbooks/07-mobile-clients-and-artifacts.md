# Mobile, desktop, and public client artifacts

## Concepts first

A client application runs in an environment controlled by its user. It can improve usability and enforce local protections, but server authorization must not depend solely on the client's hidden UI or embedded constants. Public client code can reveal routes and data contracts without proving that the backend implements them insecurely.

## Establish the artifact

Record official download origin, application identity, build/version, platform, artifact hash, and the program's scope for client analysis. A third-party mirror or old binary may not match current behavior. Downloading or unpacking an artifact is separate from installing it, attaching debuggers, adding certificates, or changing the operating system; follow the user's tooling preferences.

## Research questions

- Which backend hosts are documented and independently in scope?
- Which actions are restricted only in the UI versus on the server?
- Which data is stored locally, with what stated protection and threat model?
- Are deep links or URL handlers bound to the intended action and identity?
- Are tokens audience-bound and stored according to the platform's actual facilities?
- Do mobile and web representations use consistent object permissions?
- Does a legacy client version expose a supported backend path with a different policy?

## Avoid common false positives

An API key may be a public identifier rather than a secret; determine its intended authority without attempting unauthorized service access. An endpoint string is not a vulnerability. Local modification of a user's own app process does not automatically demonstrate a remote attacker capability. A debug message, absence of obfuscation, or a certificate configuration needs a threat model and actual impact before becoming a finding.

## Controlled analysis

Use synthetic accounts and data, supplied traces, and official client documentation. If static inspection is sufficient, avoid proposing a large mobile toolchain. If dynamic inspection requires an emulator, device tooling, administrator changes, or a proxy certificate, explain the exact benefit and obtain the relevant setup approval.

For deep-link hypotheses, map parsed scheme, host, path, action, account context, and any security token binding. User-visible similarity is not evidence of an origin match. For storage, identify the actual sensitive data and attacker prerequisites; do not copy real secrets into lesson artifacts.

## Reporting and defense

Separate client-side exposure from backend authorization impact. Report the specific artifact and version, environment prerequisites, observed behavior, and realistic attacker capability. Remediation may belong in server policy, platform storage APIs, strict link handling, or release configuration depending on the evidence.

Teach-back: Why is hiding an administrative button insufficient if the API accepts the action? Why can an embedded public client identifier be expected rather than a credential leak?
