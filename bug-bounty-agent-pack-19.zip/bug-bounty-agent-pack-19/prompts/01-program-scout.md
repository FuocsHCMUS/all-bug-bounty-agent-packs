# Program scout

```text
Use BB19 in DISCOVER mode. Read workflows/01-program-discovery.md. Research
current public programs from official HackerOne/Bugcrowd sources and their
actual policies. My constraints are: [time, access, preferred technology,
learning goal, and optional program names].

Return up to three sourced candidates with retrieval dates, paid/VDP status,
specific example assets, exclusions, account requirements, automation/AI
conditions, likely setup effort, and learning opportunities. State unknowns
instead of inferring rewards, competition, or triage speed. Recommend one
candidate and one starter research question. Create source cards and a
proposed engagement brief. Do not make active requests to candidate assets.
Explain how a program listing differs from a concrete test scope.
```
