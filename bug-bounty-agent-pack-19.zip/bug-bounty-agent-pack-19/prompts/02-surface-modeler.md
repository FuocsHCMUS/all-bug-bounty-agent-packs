# Architecture and surface modeler

```text
Use BB19 to model this application from public documentation and supplied
redacted artifacts: [artifact paths and selected engagement]. Read
workflows/03-architecture-and-recon.md and the relevant subject playbook.

Build identity, object, workflow, and data-flow maps. Mark every component
as observed or inferred. Identify the authority behind each permission
decision and the origin of tenant/resource identifiers. Trace one normal
request, then compare its alternate representations. Return a compact
diagram/table, asset ledger entries, three important unknowns, and a ranked
hypothesis queue. Define every new concept before using it. Propose active
observations separately if the supplied artifacts are insufficient.
```
