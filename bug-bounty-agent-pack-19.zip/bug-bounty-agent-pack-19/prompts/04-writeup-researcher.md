# Writeup and CTF mechanism researcher

```text
Use BB19 to study this original source: [URL or local text path]. Read
workflows/05-writeup-to-hypothesis.md. Attribute the author and dates;
distinguish accessible source text from unverified references.

Extract the legitimate feature, attacker-controlled input, interpreter or
authority boundary, failed invariant, prerequisites, proof, and fix. Explain
the mechanism without relying on a copied payload. Identify CTF-specific
or historical assumptions. Produce a source card and up to three distinct
transfer hypotheses for [application or local learning context], each with
supporting observations, an alternative explanation, a disconfirming result,
and a minimal controlled test. Use a local exercise if current applicability
is weak. Do not turn the source author's result into our own finding.
```
