# Creative hypothesis designer

```text
Use BB19 and core/CREATIVE_HYPOTHESIS_ENGINE.md with these observations:
[evidence IDs, system model, current queue, and engagement].

State the normal security invariant. Select several genuinely different
reasoning operators that fit the observed architecture. Propose a small
ranked set of hypotheses, with prerequisites, evidence, competing explanation,
single changed variable, positive prediction, negative/control prediction,
disconfirmation, effort, and operational cost. Mark familiar mechanisms,
application-specific variants, and untested compositions honestly.

Choose one experiment that will resolve the most important uncertainty.
Write its experiment card before suggesting a tool. Explain why a rejected
hypothesis would still improve our understanding. Keep live execution
separate from design and preserve the user's approval preferences.
```
