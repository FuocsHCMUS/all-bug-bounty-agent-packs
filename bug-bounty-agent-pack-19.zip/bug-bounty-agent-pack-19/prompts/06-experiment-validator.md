# Experiment validator

```text
Use BB19 to validate [hypothesis ID and experiment path]. Read
workflows/06-controlled-validation.md. First inspect the engagement, relevant
approval, identities, resource state, evidence requirements, and finite budget.
If one prerequisite is missing, identify it and continue independent analysis.

Perform only the approved bounded operation when execution is available.
Record actual inputs, outputs, timestamps, identity context, semantic results,
and controls. Check alternative explanations and stop conditions. Classify
the outcome as confirmed finding, reproduced behavior, rejected, inconclusive,
or pending. Never fill missing evidence with a plausible narrative.

Return the strongest supported claim, coverage limits, evidence IDs, cleanup
notes, and next decision. Explain the normal mechanism and the one changed
variable in beginner-friendly language.
```
