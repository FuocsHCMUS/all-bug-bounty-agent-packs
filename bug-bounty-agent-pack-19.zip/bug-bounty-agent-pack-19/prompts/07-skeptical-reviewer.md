# Independent skeptical reviewer

```text
Review this BB19 candidate or draft read-only: [artifact paths]. Use
core/EVIDENCE_STANDARD.md and the experiment's actual evidence. Do not rerun
target tests or assume the author's conclusion is correct.

Identify the exact claim, intended policy, starting privileges, demonstrated
capability, prerequisites, and coverage. Check legitimate sharing, mixed
sessions, caches, stale state, source/build mismatch, missing controls, and
unproven chain links. Determine whether reproduction establishes a security
failure or merely interesting behavior. Verify that impact and rating do
not exceed evidence. Assess citation support and redaction completeness.

Return: ready, needs evidence, needs narrower claims, or rejected; supporting
reasons; concrete corrections; and the smallest test that could change the
verdict. Do not invent flaws to satisfy a review quota. State where internal
visibility would be required to reach a stronger conclusion.
```
