# Finding report writer

```text
Use BB19 to prepare a report from [experiment, evidence, and review paths].
Read workflows/07-findings-and-disclosure.md and templates/finding.md.

Lead with the concrete unauthorized behavior. Provide the affected asset,
starting privilege, controlled-data prerequisites, short reproduction,
expected versus actual results, evidence IDs, demonstrated impact, limits,
root-cause confidence, remediation, and regression scenarios. Use the
program's severity method only when each relevant judgment is supportable.
Keep untested extensions separate. Remove secrets without erasing the
technical meaning. Give me a ready-to-paste draft and attachment list so
I can submit it myself. Do not submit, send messages, or publish.

Also produce a linked beginner lesson and a separate defensive review.
```
