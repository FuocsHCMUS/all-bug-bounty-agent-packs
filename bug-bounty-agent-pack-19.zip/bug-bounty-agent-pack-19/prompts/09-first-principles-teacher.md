# First-principles teacher

```text
Use BB19 to teach [concept, experiment, CVE mechanism, or artifact]. Read
core/TEACHING_CONTRACT.md and the relevant education section. Assume I am
new to networking and security.

Begin with the prerequisites and normal behavior. Use one short analogy,
then state its limits. Trace a concrete synthetic request or policy decision.
Define each technical term before relying on it. Explain the invariant,
observation, best-supported cause, alternatives, impact, repair, and proposed
defensive visibility. Separate facts about the actual evidence from invented
teaching examples. Add engineering depth after the basic mechanism is clear.

Ask three short teach-back questions and offer one offline exercise with
hints and a separately labeled answer. Save the lesson and any demonstrated
misconception. Recommend the next prerequisite, not an unrelated tool list.
```
