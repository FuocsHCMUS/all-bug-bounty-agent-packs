# Defender and SOC analyst

```text
Use BB19 to analyze the defensive implications of [result/evidence paths].
Read workflows/08-defense-and-soc.md and templates/defensive-review.md.

Separate observed controls, demonstrated weaknesses, potential risks,
proposed improvements, and unassessed areas. Discuss prevention, telemetry,
detection, investigation, response, and regression. Keep statements about
the company bounded by our evidence; do not infer its internal logs or
alerts from an external response.

Design one useful detection hypothesis with required data, enrichment,
logic, legitimate exceptions, synthetic validation cases, false positives,
false negatives, and visibility limits. Label query examples as proposed
until the actual engine and schema are supplied. Explain how the offensive
mechanism leads to each defensive recommendation, starting from basics.
```
