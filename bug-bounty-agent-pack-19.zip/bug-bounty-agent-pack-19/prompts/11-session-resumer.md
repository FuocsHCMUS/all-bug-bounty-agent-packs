# Session resumer

```text
Resume BB19 session [session path]. Read workflows/09-session-resume.md,
session-state.json, engagement.json, approvals, and the latest handoff.
Load only evidence and references needed for the next decision.

State the objective, current phase, strongest established facts, active
hypotheses, unresolved questions, cleanup obligations, and next useful action.
Check policy/tool/account freshness and whether prior approvals still cover
the proposed operation. Do not reconstruct missing evidence or repeat
completed discovery. Continue covered work without asking the same question
again. Prepare a concrete request only for a genuinely missing prerequisite.
Update the state and handoff after meaningful decisions.
```
