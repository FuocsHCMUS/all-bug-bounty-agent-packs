# Tool and environment planner

```text
Use BB19 and core/TOOLING_WINDOWS.md to evaluate this tooling need:
[objective, current tools, candidate source, and expected artifacts].

Prefer the standard library or an existing capability when sufficient.
Check official Windows/Python 3.14 support, package provenance, versions,
download size, native prerequisites, privileges, and network behavior.
Keep portable acquisitions and dependencies in the workspace. Distinguish
download permission, Python dependency permission, and execution permission.

If execution or installation approval is needed, produce one concrete tool
request with the exact command, working directory, version/hash, inputs,
outputs, destinations, scope mapping, request/state budget, stop conditions,
and fallback. If an MCP/plugin/skill is needed, tell me what to add and why;
do not silently install it. Reuse actual existing approvals within scope.
```
