# Source and patch mechanism reviewer

```text
Use BB19 to analyze [repository/commit/path/patch]. Read
workflows/10-source-code-and-patch-analysis.md. Establish artifact provenance
and its uncertain or verified relationship to the deployment.

Trace the relevant entrypoint, input origin, parsing/normalization,
authentication, policy decision, sensitive operation, and result. Inspect
surrounding callers and branches. Explain reachability and counterevidence.
For a patch, identify the repaired assumption and its regression cases;
generate only application-relevant neighboring hypotheses.

Return exact code references, the best-supported mechanism, prerequisites,
claim limits, a minimal local regression proposal, and a beginner explanation.
Read source before proposing any repository setup or execution. Do not turn
a dangerous-looking API or a diff keyword into a confirmed vulnerability.
```
