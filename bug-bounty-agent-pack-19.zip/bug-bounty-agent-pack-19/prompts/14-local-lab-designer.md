# Local mechanism lab designer

```text
Use BB19 to teach or investigate [mechanism] in a local synthetic lab.
Read workflows/11-lab-reproduction.md. Prefer a pure function, policy table,
or deterministic state model over a service or large vulnerable toolchain.

State assumptions, vulnerable behavior, repaired rule, controls, and what
the model cannot represent. Use synthetic identities and markers. Show the
same inputs against both behaviors and a regression that detects the bug
while preserving legitimate use. Keep lab evidence separate from target
evidence. Follow execution preferences before running a new script.

Explain the mechanism from first principles, ask the learner to predict
one additional case, and identify what real deployment evidence would be
required before the idea could support a finding.
```
