# Offline helpers

`packctl.py` uses the Python standard library and is intended for Python 3.14 or later on Windows 11. It has no HTTP client, scanner, remote exploit runner, shell execution, package installation, or report-submission behavior. The tests start local Python subprocesses to exercise the CLI; they do not contact targets.

The user's preference is to confirm new script/tool execution. These commands are examples to review before their first execution in a future session. Once approved, reuse the approval within its stated scope.

## Commands

Run from the pack root in PowerShell:

```powershell
python .\scripts\packctl.py doctor
python .\scripts\packctl.py validate
python .\scripts\packctl.py init-session example-session
python .\scripts\packctl.py init-session example-session --create
python .\scripts\packctl.py lab
python .\scripts\packctl.py hash-evidence .\sessions\example-session\evidence\redacted
python -m unittest discover -s tests -v
```

| Command | Behavior |
| --- | --- |
| `doctor` | Reports Python/platform and optional PATH locations; does not execute optional tools |
| `validate` | Checks distribution files, UTF-8 decoding, JSON syntax, simple skill frontmatter, local file links, and an existing distribution manifest |
| `init-session SLUG` | Previews files and directories without creating a session |
| `init-session SLUG --create` | Creates a new draft; refuses replacement and path escapes |
| `lab` | Shows four synthetic policy cases against an intentionally defective and repaired rule |
| `hash-evidence PATH` | Emits SHA-256, byte count, and relative path for files inside the selected workspace |
| `manifest` | Emits a reproducible hash inventory of distribution files; writes nothing by itself |

Output is JSON except concise command errors on stderr. Exit codes are 0 for success, 1 for a failed structural validation, and 2 for an invalid operation or filesystem error. The global `--root` option, if needed for a relocated copy, goes before the subcommand.

## Important limits

Structural validation does not inspect current program policies, prove an approval exists, evaluate wildcard scope semantics, verify external URLs, execute native agent loaders, or validate security findings. The `live_testing_ready` checks are completeness checks only. Draft templates intentionally remain incomplete.

The Markdown link check verifies local targets outside fenced code blocks. It does not validate heading anchors or every Markdown dialect. Skill frontmatter checking supports this pack's simple fields; it is not a general YAML parser. Native application loading is a separate check.

Hashing does not redact files or authenticate their capture. Original and redacted artifacts need separate IDs. Link and directory-junction traversal is refused; these helpers assume a workspace not concurrently modified by an adversarial process. A filesystem failure during creation may leave an incomplete new folder, which is preserved for inspection rather than deleted automatically.

The distribution manifest excludes itself, `sessions/`, `tools/`, `research/`, `.venv/`, cache directories, and `qa/tmp/`. Those directories are mutable working data, not distribution integrity claims. If pack content changes deliberately, review the changes before regenerating `PACK_MANIFEST.json`. Do not regenerate a manifest merely to hide an unexplained mismatch.

## Distribution maintenance

To generate a reviewed manifest without PowerShell redirection encoding ambiguity:

```powershell
python -c 'import pathlib, subprocess, sys; p = subprocess.run([sys.executable, "scripts/packctl.py", "manifest"], check=True, capture_output=True, text=True, encoding="utf-8"); pathlib.Path("PACK_MANIFEST.json").write_text(p.stdout, encoding="utf-8", newline="\n")'
```

This command changes the local manifest and should follow the same execution preference. Regenerate it only after distribution edits are complete, then run `validate`.
