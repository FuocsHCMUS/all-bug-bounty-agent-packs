"""BB19 offline workspace helpers. No network access or target execution."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote, urlsplit


DEFAULT_ROOT = Path(__file__).resolve().parents[1]
MANIFEST_NAME = "PACK_MANIFEST.json"
IGNORED_TOP = {"sessions", "tools", "research", ".venv", ".git"}
IGNORED_ANY = {"__pycache__", ".pytest_cache"}
SESSION_FILES = (
    "engagement.json", "session-state.json", "approvals.json", "assets.csv",
    "hypotheses.csv", "coverage.csv", "sources.csv", "evidence-index.csv",
    "tool-inventory.csv",
)
SESSION_DIRS = (
    "notes", "experiments", "evidence/raw", "evidence/redacted",
    "reports", "lessons", "handoffs",
)
DEVICE_NAMES = {"con", "prn", "aux", "nul"} | {
    f"{prefix}{number}" for prefix in ("com", "lpt") for number in range(1, 10)
}


def linked(path: Path) -> bool:
    return path.is_symlink() or path.is_junction()


def contained(root: Path, candidate: Path, *, must_exist: bool = False) -> Path:
    """Reject escapes and link/junction traversal in the selected workspace."""
    root = root.resolve(strict=True)
    candidate = Path(os.path.abspath(candidate))
    if not candidate.is_relative_to(root):
        raise ValueError("Path is outside the selected workspace")
    cursor = root
    for part in candidate.relative_to(root).parts:
        cursor = cursor / part
        if linked(cursor):
            raise ValueError(f"Link or junction traversal refused: {cursor.relative_to(root)}")
    resolved = candidate.resolve(strict=must_exist)
    if not resolved.is_relative_to(root):
        raise ValueError("Resolved path is outside the selected workspace")
    return resolved


def pack_files(root: Path) -> list[Path]:
    files = []
    for current, dirs, names in os.walk(root, followlinks=False):
        directory = Path(current)
        allowed = []
        for name in sorted(dirs):
            path = directory / name
            relative = path.relative_to(root)
            if name in IGNORED_ANY or (len(relative.parts) == 1 and name in IGNORED_TOP):
                continue
            if relative.parts[:2] == ("qa", "tmp"):
                continue
            contained(root, path, must_exist=True)
            allowed.append(name)
        dirs[:] = allowed
        for name in sorted(names):
            if name.endswith((".pyc", ".pyo")):
                continue
            path = contained(root, directory / name, must_exist=True)
            if path.is_file():
                files.append(path)
    return sorted(files, key=lambda path: path.relative_to(root).as_posix())


def digest_file(path: Path) -> dict:
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"bytes": path.stat().st_size, "sha256": digest}


def manifest(root: Path) -> dict:
    entries = []
    for path in pack_files(root):
        if path == root / MANIFEST_NAME:
            continue
        entries.append({"path": path.relative_to(root).as_posix(), **digest_file(path)})
    return {"schema_version": 1, "pack_id": "BB19", "algorithm": "sha256", "files": entries}


def hash_evidence(root: Path, relative: str) -> dict:
    target = contained(root, root / relative, must_exist=True)
    paths = []
    if target.is_file():
        paths = [target]
        base = target.parent
    elif target.is_dir():
        base = target
        for current, dirs, names in os.walk(target, followlinks=False):
            for name in dirs:
                contained(root, Path(current) / name, must_exist=True)
            for name in names:
                path = contained(root, Path(current) / name, must_exist=True)
                if path.is_file():
                    paths.append(path)
    else:
        raise ValueError("Evidence path is not a regular file or directory")
    entries = [
        {"path": path.relative_to(base).as_posix(), **digest_file(path)}
        for path in sorted(paths, key=lambda path: path.relative_to(base).as_posix())
    ]
    return {
        "algorithm": "sha256", "workspace_relative_path": target.relative_to(root).as_posix(),
        "files": entries,
        "limitation": "Hashes identify current bytes; they do not authenticate a capture or redact secrets.",
    }


def init_session(root: Path, slug: str, create: bool) -> dict:
    if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", slug) or len(slug) > 64 or slug in DEVICE_NAMES:
        raise ValueError("Use a lowercase alphanumeric/hyphen session slug, <=64 characters, excluding Windows device names")
    target = contained(root, root / "sessions" / slug)
    if target.exists():
        raise ValueError("Session already exists; choose another slug or resume it")
    contents = {}
    for name in SESSION_FILES:
        source = contained(root, root / "templates" / name, must_exist=True)
        contents[name] = source.read_text(encoding="utf-8")
    stamp = datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    brief = json.loads(contents["engagement.json"])
    brief.update(engagement_id=slug, status="draft", live_testing_ready=False,
                 execution_approval_ids=[], created_utc=stamp, updated_utc=stamp)
    state = json.loads(contents["session-state.json"])
    state.update(session_id=slug, current_state="INTAKE", created_utc=stamp, updated_utc=stamp)
    contents["engagement.json"] = json.dumps(brief, indent=2) + "\n"
    contents["session-state.json"] = json.dumps(state, indent=2) + "\n"
    contents["approvals.json"] = json.dumps({"schema_version": 1, "approvals": []}, indent=2) + "\n"
    if create:
        target.parent.mkdir(parents=True, exist_ok=True)
        contained(root, target.parent, must_exist=True)
        target.mkdir(exist_ok=False)
        for name in SESSION_DIRS:
            (target / name).mkdir(parents=True, exist_ok=True)
        for name, content in contents.items():
            (target / name).write_text(content, encoding="utf-8", newline="\n")
    return {
        "session": target.relative_to(root).as_posix(), "created": create,
        "files": list(SESSION_FILES), "directories": list(SESSION_DIRS),
        "next_action": "Choose offline learning or complete the current engagement brief; no live permission is created.",
    }


def engagement_errors(data: object) -> list[str]:
    if not isinstance(data, dict) or data.get("schema_version") != 1 or data.get("pack_id") != "BB19":
        return ["Invalid engagement schema identity"]
    errors = []
    if not isinstance(data.get("live_testing_ready"), bool):
        errors.append("live_testing_ready must be a boolean")
    if not isinstance(data.get("scope"), dict) or not isinstance(data["scope"].get("assets"), list):
        errors.append("scope.assets must be a list")
    if data.get("live_testing_ready"):
        program = data.get("program", {})
        limits = data.get("limits", {})
        if not isinstance(program, dict) or not program.get("policy_url") or not program.get("policy_retrieved_utc"):
            errors.append("Ready brief needs policy URL and retrieval time")
        if not isinstance(data.get("scope"), dict) or not data["scope"].get("assets"):
            errors.append("Ready brief needs explicit scope assets")
        if not data.get("controlled_identities") or not data.get("execution_approval_ids"):
            errors.append("Ready brief needs identity context and actual approval references")
        for key in ("proposed_total_requests", "proposed_concurrency", "timeout_seconds"):
            if not isinstance(limits, dict) or type(limits.get(key)) is not int or limits[key] <= 0:
                errors.append(f"Ready brief needs positive integer {key}")
    return errors


def skill_errors(path: Path, text: str, root: Path) -> list[str]:
    if path.name != "SKILL.md":
        return []
    match = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|$)", text, re.DOTALL)
    if not match:
        return ["SKILL.md lacks frontmatter"]
    fields = {}
    for line in match[1].splitlines():
        key, separator, value = line.partition(":")
        if separator and not line.startswith(" "):
            fields[key.strip()] = value.strip().strip("\"'")
    name, description = fields.get("name", ""), fields.get("description", "")
    errors = []
    if len(name) > 64 or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name):
        errors.append("Invalid skill name")
    if not 1 <= len(description) <= 1024:
        errors.append("Skill description must contain 1-1024 characters")
    if path.parent != root and name != path.parent.name:
        errors.append("Discoverable skill name differs from its directory")
    return errors


def validate(root: Path) -> dict:
    errors = []
    required = {"README.md", "AGENTS.md", "SKILL.md"} | {
        f"templates/{name}" for name in ("engagement.json", "session-state.json", "approvals.json")
    }
    files = pack_files(root)
    actual = {path.relative_to(root).as_posix(): path for path in files}
    for name in sorted(required - actual.keys()):
        errors.append(f"Missing required file: {name}")
    local_links = 0
    for name, path in actual.items():
        if path.suffix not in {".md", ".mdc", ".json", ".yaml", ".csv", ".py", ".txt"}:
            continue
        try:
            content = path.read_text(encoding="utf-8")
            if content.startswith("\ufeff"):
                errors.append(f"{name}: UTF-8 BOM is not expected")
            if path.suffix == ".json":
                data = json.loads(content)
                if path.name == "engagement.json":
                    errors.extend(f"{name}: {error}" for error in engagement_errors(data))
            if path.suffix in {".md", ".mdc"}:
                errors.extend(f"{name}: {error}" for error in skill_errors(path, content, root))
                # Ignore fenced examples; validate authored inline file links only.
                prose = re.sub(r"(?ms)^```[^\n]*\n.*?^```[^\n]*(?:\n|$)", "", content)
                for destination in re.findall(r"\[[^\]\n]+\]\(([^)\n]+)\)", prose):
                    destination = destination.strip().strip("<>")
                    parsed = urlsplit(destination)
                    if parsed.scheme or parsed.netloc or not parsed.path:
                        continue
                    local_links += 1
                    candidate = path.parent / unquote(parsed.path)
                    try:
                        contained(root, candidate, must_exist=True)
                    except (OSError, ValueError) as exc:
                        errors.append(f"{name}: invalid local link {destination}: {exc}")
        except (OSError, UnicodeError, ValueError) as exc:
            errors.append(f"{name}: {exc}")
    manifest_verified = False
    manifest_path = root / MANIFEST_NAME
    if manifest_path.exists():
        try:
            saved = json.loads(manifest_path.read_text(encoding="utf-8"))
            current = manifest(root)
            if saved != current:
                errors.append("Distribution manifest mismatch: content or file list changed")
            else:
                manifest_verified = True
        except (OSError, ValueError) as exc:
            errors.append(f"Invalid distribution manifest: {exc}")
    return {
        "ok": not errors, "files_checked": len(files), "local_links_checked": local_links,
        "manifest_verified": manifest_verified, "errors": errors,
        "limits": "Local structure, simple skill frontmatter, JSON, file links, and optional hashes only; no host loading or target validation.",
    }


def lab() -> dict:
    resource = {"tenant": "tenant_a", "marker": "TENANT_A_DEMO_7"}
    principals = {
        "same_tenant": {"authenticated": True, "memberships": {"tenant_a"}},
        "cross_tenant": {"authenticated": True, "memberships": {"tenant_b"}},
        "anonymous": {"authenticated": False, "memberships": set()},
        "revoked_membership": {"authenticated": True, "memberships": set()},
    }
    cases = []
    for name, principal in principals.items():
        # Intentional toy defect: recognizing identity alone grants a private read.
        vulnerable = principal["authenticated"]
        # Toy repair: require current membership for this private, unshared object.
        repaired = principal["authenticated"] and resource["tenant"] in principal["memberships"]
        cases.append({
            "case": name, "vulnerable": "allow" if vulnerable else "deny",
            "repaired": "allow" if repaired else "deny",
            "vulnerable_marker": resource["marker"] if vulnerable else None,
            "repaired_marker": resource["marker"] if repaired else None,
        })
    return {
        "environment": "synthetic offline policy model", "cases": cases,
        "lesson": "Authentication identifies a principal; object authorization enforces the private resource's rule.",
        "limitations": "No network, server, sharing feature, role hierarchy, distributed timing, or real company is modeled.",
    }


def doctor() -> dict:
    return {
        "python_version": platform.python_version(), "python_executable": sys.executable,
        "platform": platform.platform(), "python_3_14_or_later": sys.version_info >= (3, 14),
        "optional_tools_on_path": {name: shutil.which(name) for name in ("git", "rg", "curl", "node")},
        "dependencies_required": [],
        "note": "PATH lookup only; no optional tool is executed and nothing is installed.",
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT, help="Pack root; defaults to this script's parent workspace")
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("doctor", "validate", "manifest", "lab"):
        commands.add_parser(name)
    session = commands.add_parser("init-session")
    session.add_argument("slug")
    session.add_argument("--create", action="store_true", help="Create the previewed workspace-local draft")
    evidence = commands.add_parser("hash-evidence")
    evidence.add_argument("path", help="File/directory inside the selected pack root")
    args = parser.parse_args(argv)
    try:
        root = args.root.resolve(strict=True)
        if not (root / "AGENTS.md").is_file() or not (root / "templates").is_dir():
            raise ValueError("Select a BB19 root containing AGENTS.md and templates/")
        if args.command == "doctor":
            result = doctor()
        elif args.command == "validate":
            result = validate(root)
        elif args.command == "manifest":
            result = manifest(root)
        elif args.command == "lab":
            result = lab()
        elif args.command == "init-session":
            result = init_session(root, args.slug, args.create)
        else:
            result = hash_evidence(root, args.path)
        print(json.dumps(result, indent=2, ensure_ascii=True))
        return 1 if args.command == "validate" and not result["ok"] else 0
    except (OSError, ValueError) as exc:
        print(f"BB19 error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
