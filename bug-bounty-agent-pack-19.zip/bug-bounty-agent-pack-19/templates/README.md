# Session templates and artifact contracts

The templates deliberately contain empty fields and labeled prompts. They are forms, not completed evidence or permission records. Copy them into a session and preserve the template originals.

| File | When to use |
| --- | --- |
| [engagement.json](engagement.json) | Selected program, scope, methods, identities, limits, and policy provenance |
| [session-state.json](session-state.json) | Resume state and pointers to authoritative artifacts |
| [approvals.json](approvals.json) | Actual user approvals, their boundaries, and their source |
| [assets.csv](assets.csv) | Discovered assets and their scoped/unscoped status |
| [hypotheses.csv](hypotheses.csv) | Ranked ideas, assumptions, outcomes, and next tests |
| [coverage.csv](coverage.csv) | What was tested, untested, rejected, or inconclusive |
| [sources.csv](sources.csv) | Source register with retrieval dates and supported claims |
| [evidence-index.csv](evidence-index.csv) | Captures, identity context, redaction, integrity, and claim support |
| [tool-inventory.csv](tool-inventory.csv) | Download/install provenance and execution approval references |
| [source-card.md](source-card.md) | Mechanism extracted from an original source |
| [cve-applicability.md](cve-applicability.md) | Independent CVE preconditions and evidence |
| [experiment.md](experiment.md) | Falsifiable comparison and actual outcome |
| [finding.md](finding.md) | Report draft for the user to submit |
| [defensive-review.md](defensive-review.md) | Observed controls and proposed security operations improvements |
| [lesson.md](lesson.md) | First-principles explanation and exercise |
| [tool-request.md](tool-request.md) | Concrete execution or installation proposal |
| [handoff.md](handoff.md) | Resumption without redoing discovery |
| [retrospective.md](retrospective.md) | Learning, dead ends, and process improvement |

## IDs, statuses, and time

Use stable IDs: `H-001` for a hypothesis, `EXP-001` for an experiment, `EV-001` for evidence, `SRC-001` for a source, `APR-001` for an approval, and `F-001` for a finding. Use UTC ISO 8601 timestamps in records and the user's timezone for conversational scheduling. No schedule is created by this pack.

Hypothesis statuses: `queued`, `researching`, `planned`, `pending_approval`, `testing`, `confirmed`, `rejected`, `inconclusive`, `deferred`. Coverage statuses should describe the actual outcome, not simply “done.” Unknown values remain empty or `unknown`, not an assumed success.

CSV files contain headers only. Quote fields containing commas or newlines using standard CSV rules. Lists of evidence IDs can use semicolons inside one quoted field. Keep secrets out of all ledgers.

## Engagement schema conventions

`scope.assets` is a list of records with `asset`, `asset_type`, `policy_quote`, `policy_source_id`, `interpretation`, `allowed_methods`, `excluded_methods`, and `restrictions`. This is a human-reviewed interpretation, not an automatic URL matcher. Record wildcard, port, path, and third-party caveats explicitly.

`controlled_identities` contains labels, tenant labels, roles, and expected permissions. Store credential references only; never token values. `limits` separates published limits from the smaller proposed experiment budget. `live_testing_ready` starts false and can be marked true only when the actual prerequisites and approvals are recorded; setting it is not itself authorization.

`approvals.json` entries should include `id`, `recorded_utc`, `user_statement`, `source_reference`, `operation`, `commands`, `targets`, `limits`, `valid_until_or_condition`, and `status`. The agent records a real user decision. No initial approval is supplied.

## Session layout

```text
sessions/<session-id>/
    engagement.json
    session-state.json
    approvals.json
    assets.csv / hypotheses.csv / coverage.csv / sources.csv
    evidence-index.csv / tool-inventory.csv
    notes/
    experiments/
    evidence/raw/
    evidence/redacted/
    reports/
    lessons/
    handoffs/
```

The offline helper creates this skeleton without target access. Store completed experiment/report forms in the relevant subfolder with stable IDs. Avoid duplicating authoritative evidence into many documents; link by ID and relative path.
