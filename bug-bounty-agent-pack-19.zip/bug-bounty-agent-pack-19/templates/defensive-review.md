# Defensive review — [finding or experiment ID]

## Evidence boundary

State tested assets, identities, states, timestamps, data available, and important unseen internal controls.

| Category | Specific statement | Evidence | Confidence and coverage limit |
| --- | --- | --- | --- |
| Observed control | | | |
| Demonstrated weakness | | | |
| Potential risk | | | |
| Proposed improvement | | | |
| Not assessed | | | |

## Risk scenario

Describe actor, prerequisite, action, protected asset, demonstrated effect, possible scope, and unverified extensions. Discuss confidentiality, integrity, availability, reliability, exposure window, revocation, and blast radius without inventing scale.

## Prevention

State the invariant, authoritative enforcement point, proposed repair, and legitimate behavior that must remain available.

## Telemetry and detection proposal

- Available researcher-visible data:
- Additional company-side data required:
- Field definitions and identity/resource enrichment:
- Detection logic and why it indicates this mechanism:
- Legitimate exceptions:
- Synthetic allowed, denied, shared, and revoked-access cases:
- False positives and false negatives:
- Coverage and retention questions:
- Validation and tuning plan:

Any query remains a proposal until the actual schema/engine is known.

## Investigation and response

Explain useful correlations, triage questions, containment options, preservation of evidence, and recovery checks. Mark actions requiring internal authority as recommendations.

## Regression and teaching

List original and related boundary tests. Explain the distinction between blocking, logging, detecting, and responding. Include one strength the evidence supports and one question only the company can answer.
