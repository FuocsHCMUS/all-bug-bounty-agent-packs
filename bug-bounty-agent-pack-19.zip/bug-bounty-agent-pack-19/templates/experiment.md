# EXP-[number] — [one concrete research question]

## Design

- Related hypothesis and evidence IDs:
- Environment: target / owner-provided test environment / synthetic local lab:
- Invariant:
- Observed clue:
- Hypothesis:
- Strongest competing explanation:
- Necessary prerequisites:
- Program scope and policy source:
- Applicable user approval ID:
- Controlled principals and resource state:
- Single changed variable:
- Expected vulnerable result:
- Expected normal/control result:
- Result that would disconfirm or narrow the hypothesis:
- Exact command or manual operation:
- Request, time, retry, and state-change budget:
- Stop signals and cleanup plan:

## Actual execution

Record execution time, exact relevant inputs, tool version, principal context, outputs, and evidence IDs. If not executed, write `pending` and why; do not fill this section with predicted results.

## Assessment

- Observed result:
- Control outcome:
- Alternative explanations addressed:
- Remaining uncertainty:
- Classification and confidence with reason:
- Strongest supported claim:
- Untested extensions:
- Cleanup performed or still required:
- Next decision:

## Beginner explanation

Define prerequisites, normal behavior, the changed variable, why the result matters, and one teach-back question.
