# F-[number] — [action + protected resource + failed boundary]

Status: draft / ready for user review / submitted by user / retest. Environment: actual target or clearly labeled synthetic example.

## Summary

Describe starting privileges, affected asset, operation, and demonstrated unauthorized result in a few sentences. State the bounded impact directly.

## Affected asset and prerequisites

- Official program and current policy reference:
- Exact endpoint/component/version where established:
- Controlled account roles and tenant relationships:
- Object ownership, privacy, and sharing state:
- Required feature/configuration:
- Related experiment, source, and evidence IDs:

## Reproduction

1. Establish the controlled resource and expected permission.
2. Perform the normal authorized control and record its result.
3. Change the one relevant variable and perform the documented test.
4. Observe the exact controlled marker or forbidden effect.

Replace these form instructions with actual reproducible steps. Include relevant redacted request/response excerpts and evidence references. Explain any intentionally omitted repetition.

## Expected and actual behavior

State the rule, expected decision, actual semantic result, and relevant control. Do not rely on a status code alone.

## Demonstrated impact and limits

Explain what this principal can do to this class of controlled resource under the established conditions. State untested endpoints, roles, configurations, scales, and chain links. Separate possible extensions from the demonstrated result.

## Severity rationale

Use the program's required method. Include a complete verified vector and metric rationale only if justified. Do not promise a program priority or bounty outcome.

## Root cause

Give source-supported facts where available, otherwise label the explanation as an inference. Identify competing explanations and how controls addressed them.

## Remediation and regression

Identify the correct enforcement point, a practical repair, relevant implementation tradeoffs, and tests preserving allowed behavior while rejecting the failure. Include lifecycle and alternate-path variants when directly relevant.

## Evidence and handling notes

List redacted attachments and IDs, what the researcher did, when sufficient proof was obtained, test state created, and cleanup status. Keep credentials and unrelated personal data out of the draft.

## Linked analysis

Point to the separate beginner lesson and defensive review. The user reviews and submits the report personally.
