# Session handoff — [session ID]

- Objective and current state:
- Engagement/policy snapshot and freshness:
- Actual applicable approvals and limits:
- Strongest established facts and evidence IDs:
- Active, rejected, inconclusive, and pending hypotheses:
- Current artifact paths:
- Tool/environment changes:
- Account/resource state created or changed:
- Cleanup obligations:
- Pending user questions and external blockers:
- Independent work still possible:
- Exact next analysis step or proposed command:
- Why that step resolves the next uncertainty:
- Learning progress and next prerequisite:
- Updated UTC:
