# Lesson — [concept and related artifact IDs]

## Learning goal and prerequisites

What should the learner be able to explain or predict afterward? Define the required networking, HTTP, identity, or state concepts.

## Level 0 — Intuition

Use one short analogy and state where it stops being accurate.

## Level 1 — Concrete mechanism

Trace the subject, action, resource, rule, request, decision, and result. Use synthetic data or clearly attributed actual evidence. Explain normal behavior before the failure.

## Level 2 — Engineering depth

Discuss the enforcement point, data flow, relevant state, source/patch evidence, root-cause confidence, and alternative explanations. Separate observations from proposed architecture.

## Impact, repair, and defender view

Explain the demonstrated capability, limits, root repair, regression, telemetry requirements, detection hypothesis, and visibility gaps.

## Practice

- Predict one new case:
- Hint:
- Answer and reasoning, shown after the learner attempts it:
- Three teach-back questions:
- Learner answer and corrected misconception:

## Next step

Name the next prerequisite or exercise and why it follows. Link to sources and related pack references.
