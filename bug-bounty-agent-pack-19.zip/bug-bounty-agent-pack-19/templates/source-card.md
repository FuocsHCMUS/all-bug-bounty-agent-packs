# SRC-[number] — Source mechanism card

- Original title, author, issuing organization:
- URL or supplied artifact:
- Publication/update date and retrieval UTC:
- Source type and access status:
- Exact section supporting the claim:
- Environment, build, and prerequisites:
- What was independently verified here:

## Mechanism in our own words

Describe the legitimate feature, controlled input, interpreter or authority, failed invariant, and observed result. Attribute historical results to the source author.

## Preconditions and limits

List required privileges, configuration, timing, versions, and context. Identify CTF-specific or obsolete assumptions.

## Transfer to this application

Map each prerequisite to an observation, contradiction, or unknown. State a falsifiable hypothesis and a result that would reject it.

## Defensive and learning value

Explain enforcement points, telemetry questions, prerequisites the learner needs, and a small synthetic exercise. Link to the original source rather than copying its complete text.
