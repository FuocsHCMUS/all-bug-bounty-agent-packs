# Tool request — APR-[proposed number]

- Objective and uncertainty this operation resolves:
- Why existing/manual/offline alternatives are insufficient:
- Tool source, version/commit, hash, size, and provenance:
- Windows 11 / Python 3.14 support evidence:
- Acquisition destination in workspace:
- Exact executable and command:
- Working directory and input files:
- Output files and local changes:
- Privileges, system changes, dependencies, and cost:
- Network destinations and credential category:
- Program asset/method mapping for target requests:
- Total request, concurrency, timeout, retry, time, and state budget:
- Stop signals and cancellation method:
- Cleanup/reversal plan where relevant:
- Proposed approval extent and completion/expiry condition:

## Decision requested

Ask one concrete question about the operation above. Explain which existing user preference makes confirmation necessary. Download permission and Python dependency permission should not be re-requested if already covered.

## Actual user decision

Pending until a real answer is received. Record the user's statement, source reference, time, allowed extent, and approval ID in `approvals.json`. The agent does not complete this field by inference.
