"""Offline CLI contract tests; all temporary data stays under qa/tmp/."""

import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


PACK = Path(__file__).resolve().parents[1]
SCRIPT = PACK / "scripts" / "packctl.py"


class PackCtlTests(unittest.TestCase):
    def setUp(self):
        scratch = PACK / "qa" / "tmp"
        scratch.mkdir(parents=True, exist_ok=True)
        self.temporary = tempfile.TemporaryDirectory(prefix="bb19-test-", dir=scratch)
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name).resolve()
        self.assertTrue(self.base.is_relative_to(scratch.resolve()))
        self.root = self.base / "pack"
        self.root.mkdir()
        (self.root / "README.md").write_text("# Demo\n\n[Contract](AGENTS.md)\n", encoding="utf-8")
        (self.root / "AGENTS.md").write_text("# Test fixture\n", encoding="utf-8")
        (self.root / "SKILL.md").write_text(
            "---\nname: bug-bounty-agent-pack-19\ndescription: Use when reviewing a fixture.\n---\n\n# Fixture\n",
            encoding="utf-8",
        )
        (self.root / "templates").mkdir()
        for path in (PACK / "templates").iterdir():
            if path.suffix in {".json", ".csv"}:
                shutil.copyfile(path, self.root / "templates" / path.name)

    def run_cli(self, *args):
        return subprocess.run(
            [sys.executable, str(SCRIPT), "--root", str(self.root), *args],
            capture_output=True, text=True, encoding="utf-8", timeout=15,
        )

    def success(self, *args):
        result = self.run_cli(*args)
        self.assertEqual(result.returncode, 0, result.stderr or result.stdout)
        return json.loads(result.stdout)

    def test_preview_lists_a_session_without_creating_it(self):
        result = self.success("init-session", "first-session")
        self.assertFalse(result["created"])
        self.assertIn("engagement.json", result["files"])
        self.assertFalse((self.root / "sessions").exists())

    def test_creation_makes_a_draft_with_no_live_permission_or_approvals(self):
        result = self.success("init-session", "first-session", "--create")
        target = self.root / "sessions" / "first-session"
        self.assertTrue(result["created"])
        brief = json.loads((target / "engagement.json").read_text(encoding="utf-8"))
        state = json.loads((target / "session-state.json").read_text(encoding="utf-8"))
        approvals = json.loads((target / "approvals.json").read_text(encoding="utf-8"))
        self.assertFalse(brief["live_testing_ready"])
        self.assertEqual(brief["scope"]["assets"], [])
        self.assertEqual(approvals["approvals"], [])
        self.assertEqual(state["session_id"], "first-session")
        self.assertTrue((target / "evidence" / "redacted").is_dir())

    def test_existing_session_is_never_overwritten(self):
        self.success("init-session", "first-session", "--create")
        sentinel = self.root / "sessions" / "first-session" / "notes" / "keep.txt"
        sentinel.write_text("preserve this", encoding="utf-8")
        result = self.run_cli("init-session", "first-session", "--create")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(sentinel.read_text(encoding="utf-8"), "preserve this")

    def test_session_slugs_cannot_escape_or_use_windows_device_names(self):
        for slug in ("../escape", "a/b", "a\\b", "UpperCase", "con", "nul", "com1", "bad..slug"):
            with self.subTest(slug=slug):
                result = self.run_cli("init-session", slug, "--create")
                self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.root / "sessions").exists())

    def test_linked_session_parent_cannot_write_outside_the_pack(self):
        outside = self.base / "outside"
        outside.mkdir()
        try:
            (self.root / "sessions").symlink_to(outside, target_is_directory=True)
        except OSError as exc:
            self.skipTest(f"Directory symlinks unavailable on this workstation: {exc}")
        result = self.run_cli("init-session", "first-session", "--create")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(list(outside.iterdir()), [])

    def test_missing_template_does_not_leave_a_partial_session(self):
        (self.root / "templates" / "approvals.json").unlink()
        result = self.run_cli("init-session", "first-session", "--create")
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.root / "sessions" / "first-session").exists())

    def test_hashes_known_bytes_without_returning_their_contents(self):
        evidence = self.root / "evidence-demo"
        evidence.mkdir()
        (evidence / "sample.bin").write_bytes(b"abc")
        result = self.success("hash-evidence", "evidence-demo")
        self.assertEqual(result["files"], [{
            "path": "sample.bin", "bytes": 3,
            "sha256": "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
        }])

    def test_hashing_refuses_an_outside_path(self):
        (self.base / "outside.bin").write_bytes(b"private")
        result = self.run_cli("hash-evidence", "../outside.bin")
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("private", result.stdout)

    def test_hashing_refuses_a_linked_evidence_file(self):
        outside = self.base / "outside.bin"
        outside.write_bytes(b"private")
        evidence = self.root / "evidence-demo"
        evidence.mkdir()
        try:
            (evidence / "linked.bin").symlink_to(outside)
        except OSError as exc:
            self.skipTest(f"File symlinks unavailable on this workstation: {exc}")
        result = self.run_cli("hash-evidence", "evidence-demo")
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("private", result.stdout)

    def test_validation_accepts_complete_local_links_and_draft_templates(self):
        result = self.success("validate")
        self.assertTrue(result["ok"])
        self.assertFalse(result["manifest_verified"])

    def test_validation_reports_a_broken_link(self):
        (self.root / "README.md").write_text("[Missing](missing.md)\n", encoding="utf-8")
        result = self.run_cli("validate")
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(json.loads(result.stdout)["ok"])

    def test_validation_refuses_links_outside_the_pack(self):
        (self.base / "outside.md").write_text("private", encoding="utf-8")
        (self.root / "README.md").write_text("[Outside](../outside.md)\n", encoding="utf-8")
        result = self.run_cli("validate")
        self.assertNotEqual(result.returncode, 0)

    def test_invalid_json_is_a_validation_failure(self):
        (self.root / "templates" / "approvals.json").write_text("{", encoding="utf-8")
        result = self.run_cli("validate")
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(json.loads(result.stdout)["ok"])

    def test_a_ready_flag_without_prerequisites_fails_structural_validation(self):
        path = self.root / "templates" / "engagement.json"
        brief = json.loads(path.read_text(encoding="utf-8"))
        brief["live_testing_ready"] = True
        path.write_text(json.dumps(brief), encoding="utf-8")
        result = self.run_cli("validate")
        self.assertNotEqual(result.returncode, 0)

    def test_manifest_omits_mutable_and_private_directories(self):
        for relative in ("sessions/private.txt", "tools/repos/tool.txt", "research/downloads/page.txt", ".venv/secret.txt"):
            path = self.root / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("not pack distribution content", encoding="utf-8")
        result = self.success("manifest")
        paths = {item["path"] for item in result["files"]}
        self.assertIn("AGENTS.md", paths)
        self.assertFalse(any(path.startswith(("sessions/", "tools/", "research/", ".venv/")) for path in paths))
        self.assertNotIn("PACK_MANIFEST.json", paths)

    def test_manifest_detects_modified_distribution_content(self):
        manifest = self.success("manifest")
        (self.root / "PACK_MANIFEST.json").write_text(json.dumps(manifest), encoding="utf-8")
        self.assertTrue(self.success("validate")["manifest_verified"])
        (self.root / "AGENTS.md").write_text("changed", encoding="utf-8")
        result = self.run_cli("validate")
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(json.loads(result.stdout)["ok"])

    def test_lab_preserves_legitimate_access_and_repairs_cross_tenant_access(self):
        result = self.success("lab")
        cases = {case["case"]: case for case in result["cases"]}
        self.assertEqual(cases["same_tenant"]["vulnerable"], "allow")
        self.assertEqual(cases["same_tenant"]["repaired"], "allow")
        self.assertEqual(cases["cross_tenant"]["vulnerable"], "allow")
        self.assertEqual(cases["cross_tenant"]["repaired"], "deny")
        self.assertEqual(cases["anonymous"]["vulnerable"], "deny")
        self.assertEqual(cases["revoked_membership"]["repaired"], "deny")

    def test_doctor_reports_environment_without_installing_anything(self):
        before = {path.relative_to(self.root) for path in self.root.rglob("*")}
        result = self.success("doctor")
        self.assertIn("python_version", result)
        self.assertIn("optional_tools_on_path", result)
        self.assertEqual(before, {path.relative_to(self.root) for path in self.root.rglob("*")})


if __name__ == "__main__":
    unittest.main()
