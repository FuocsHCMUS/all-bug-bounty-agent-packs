# 02 — Establish an engagement brief

## Inputs

An official program policy, the user's intended objective, a proposed asset, and available test identities. If a private policy cannot be browsed, ask the user for relevant text with secrets removed and record its origin.

Copy [templates/engagement.json](../templates/engagement.json) into the session. Empty fields are unresolved information. The example schema is a record, not a machine-enforced firewall or a platform authorization token.

## Interpret scope precisely

Build an asset/method matrix containing the exact policy wording, normalized asset interpretation, protocol and port, path restrictions, exclusions, allowed techniques, and evidence source. Distinguish testing scope from bounty eligibility; a program may allow an asset without paying for every issue class on it.

Questions that materially change a test:

- Does a wildcard include the apex host, or only subdomains under the program's wording?
- Does an asset entry cover a website, a particular API, a mobile binary, a repository, or a network range?
- Are third-party hosted integrations excluded despite sharing a brand or DNS chain?
- Are test accounts, request headers, source IP declarations, or test tenants required?
- Are automation, concurrency, callbacks, file uploads, state changes, or certain issue classes restricted?
- Is the program currently accepting the relevant kind of report?

Do not infer scope from search results, certificate transparency, CNAMEs, IP ownership, acquisitions, redirects, or visual branding. Such observations may create questions for the brief. A redirect destination receives its own scope check before a test follows it. Preserve the original policy text alongside your interpretation when a subtle wildcard or exclusion matters.

## Record operation limits

Capture the program limit and a smaller proposed experiment budget separately. Unknown rate limits are not unlimited. Prefer a small manual comparison while clarifying the missing limit. Record total request ceiling, concurrency, timeout, retry ceiling, and whether the operation changes application state.

Do not invent test identities or credentials. Use stable labels such as `member_a`, `member_b`, and `tenant_a`; the secret values belong in the user's approved credential mechanism. Record the expected relationship between accounts and resources without pasting tokens.

## Approval and state

Scope interpretation and the user's permission to execute are distinct fields. An in-scope asset does not approve a new script. A script approval does not override a program exclusion. Record actual user approvals in [templates/approvals.json](../templates/approvals.json), including covered targets, commands or command family, limits, and expiry or completion condition.

Before moving to live validation, ensure the proposed operation can be mapped to both fields. If one field is missing, state exactly what is missing and continue useful independent work. Do not make the user reapprove an unchanged, still-valid bounded operation.

## Exit artifact

A usable brief states: who is testing, which program, where the authoritative policy lives, which precise asset and methods are allowed, which controlled identities exist, what the experiment budget is, which approvals apply, and which unknowns remain. Then begin [modeling](03-architecture-and-recon.md).
