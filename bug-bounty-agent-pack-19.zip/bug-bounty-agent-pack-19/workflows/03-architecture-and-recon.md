# 03 — Model the application and its attack surface

## Start with product behavior

Use public product documentation and supplied redacted traces first. When live browsing is approved, walk normal workflows with controlled accounts before designing unusual requests. Explain the product's purpose to the learner: users, organizations, projects, documents, jobs, integrations, and business outcomes.

Build four connected maps:

1. **Identity map:** login methods, sessions, roles, tenants, delegated permissions, service accounts, and revocation events.
2. **Object map:** parent-child relationships, ownership, visibility, sharing, external identifiers, and lifecycle states.
3. **Data-flow map:** browser/client -> edge/gateway -> application -> storage/worker -> downstream destination. Mark observed components and inferred components differently.
4. **Workflow map:** actions and transitions such as create, approve, invite, accept, revoke, export, archive, restore, and delete.

For each boundary ask which component has authority to make the decision and which inputs it trusts. A client-provided `tenant_id` is a statement, not necessarily proof of membership. A signed token proves only the claims it is actually validated to carry.

## Asset ledger

Use [templates/assets.csv](../templates/assets.csv). Record the exact asset, discovery source, scope evidence, component hypothesis, observed technology, confidence, principal context, and interesting boundaries. Keep discovered-but-unscoped assets in a separate status; do not test them.

Collect information that changes a hypothesis: documented endpoints, object relationships, observable authorization transitions, request formats, feature versions, and relevant publicly exposed client code. Do not collect a large inventory merely because a tool can produce one.

## Trace a normal request

For one action, explain:

- How the user enters the action and how the client encodes it.
- How the server identifies the principal.
- How the requested object is located.
- Which permission should be checked and where tenant context originates.
- What state changes or background jobs follow.
- What response or artifact proves success.

Then identify alternate paths for the same action: API versus UI, list versus direct read, preview versus download, synchronous response versus export. Use the [hypothesis engine](../core/CREATIVE_HYPOTHESIS_ENGINE.md) to prioritize meaningful contrasts.

## Technology identification

Record exact evidence for frameworks, products, versions, and infrastructure. A response header can be rewritten, hidden, or stale. Public client bundles can identify client dependencies without proving the server uses the same version. A CDN can mask the origin. Separate each inference from the observation that supports it.

If a product lead suggests known vulnerabilities, move to [CVE research](04-cve-research.md). If behavior suggests a design weakness with no known advisory, start with the relevant subject playbook. Neither route requires a named CVE to be useful.

## Exit artifact

Produce a compact boundary diagram or table, the top three unanswered questions, and a ranked hypothesis queue. State coverage limits: which identities, endpoints, states, and sources have actually been observed. Preserve normal controls as well as anomalies.
