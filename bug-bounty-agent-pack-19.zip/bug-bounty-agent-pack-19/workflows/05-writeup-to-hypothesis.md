# 05 — Turn writeups and CTF lessons into research

## Read for the mechanism

A writeup describes one person's environment, observations, and historical result. A CTF intentionally constructs a puzzle. Neither automatically establishes the behavior of a current company application.

Create [a source card](../templates/source-card.md) with the original author, URL, publication and retrieval dates, environment, prerequisites, trust boundary, critical observation, root cause, fix if known, and what you have independently verified. Prefer original research and official training material over unattributed compilations.

## Decompose the technique

Answer these questions in order:

1. What legitimate feature was being used?
2. Which principal controlled which input?
3. Which component interpreted that input, and under what authority?
4. What invariant failed?
5. What exact observable result established the failure?
6. What prerequisite or environmental quirk made it possible?
7. Which control or patch would interrupt it?

Remove storytelling, payout amounts, and payload syntax until the mechanism is clear. Keep syntax only when it is necessary to understand an actual parser or protocol disagreement, and use a local reproduction when possible.

## Transfer the idea, not the whole exploit

Translate the source mechanism into a technology-independent statement. Example: “a background job reused stale membership authority” can become questions about exports, previews, scheduled reports, or revocable sharing. It does not imply those features are vulnerable.

For each proposed target application, map source prerequisites to observed application facts. Mark absent, contradicted, and unknown conditions. If a CTF depended on a deliberately exposed debug interface or an obsolete library, explain why its transfer may fail.

Generate a few candidate variants using different operators from [the hypothesis engine](../core/CREATIVE_HYPOTHESIS_ENGINE.md). Each variant needs a novel application-specific observation or a clear architectural question. Rewording the same payload is not a new hypothesis.

## A useful technique card

```text
Mechanism: [one sentence about the failed assumption].
Necessary conditions: [identity, feature, authority, representation, state].
Source evidence: [original source and exact support].
Current application evidence: [observed facts, separate from guesses].
Transfer hypothesis: [a falsifiable statement about this application].
Smallest distinguishing test: [input difference and expected output].
Counterexample: [a result that would show the analogy is wrong].
Defensive lesson: [enforcement and telemetry points].
```

## Learn without creating findings

When the mechanism is interesting but current applicability is weak, create a local synthetic exercise. Explain the bug, a repaired version, and the regression that separates them. Keep local observations out of live evidence ledgers, or label their environment clearly. Do not turn a CTF flag or a local toy result into a report about a company.

Respect source attribution and avoid copying entire proprietary writeups or training lessons into the pack. Save concise mechanism notes and links; quote only small necessary excerpts.
