# 06 — Validate one hypothesis at a time

## Prepare a discriminating experiment

Use [templates/experiment.md](../templates/experiment.md). Specify the invariant, observed clue, hypothesis, competing explanation, relevant program scope, principal labels, controlled resources, single variable, expected vulnerable result, expected control result, finite request budget, and stop signals.

Before execution, map the exact command or manual operation to the user's approval. A new tool needs confirmation even if a similar tool was used elsewhere. If a covered operation merely repeats with approved inputs and within its budget, reuse the approval. Do not convert a public-source research permission into application test traffic.

## Establish controls

Start with an expected valid action and verify the principal and resource state. Then compare the forbidden context using the same controlled object or marker. Keep every other relevant variable stable where possible. If the resource is intentionally shared, design a different control rather than calling the expected access a vulnerability.

For two-account testing, verify identity in the actual session or token context, label cookie stores, and avoid browser tab/session confusion. For a revoked user, capture the exact revocation time and the relevant session or capability lifetime. For caches, distinguish fresh responses from cached content and avoid assuming the cache layer exists.

## Observe semantics, not just status

A `200` response may contain an error object. A `403` response may still include content or a useful side effect. A redirect can move the request to another host. A timeout can reflect network conditions. Examine response meaning, selected markers, state changes, and request context.

Use the least amount of controlled content needed to establish the claim. If a private marker proves a read, there is no need to retrieve additional real records. If an outcome unexpectedly creates privilege, exposes unrelated secrets, changes money/account state, or crosses scope, stop that branch and preserve the minimum evidence for a clear user update.

## Record and assess

Save exact relevant inputs, outputs, identities, timestamps, source versions, and controls. Redact credentials before reports or external processing. Keep original evidence separate from redacted copies with a mapping in the evidence index. Hashes support artifact integrity but do not prove the original capture's truth.

Classify the outcome:

- **Confirmed finding:** the intended security rule is established and a failure is demonstrated.
- **Reproduced behavior:** the result is clear, but its security meaning still needs a policy or sharing clarification.
- **Rejected hypothesis:** the distinguishing result supports another explanation.
- **Inconclusive:** the experiment could not separate explanations or lacked prerequisites.
- **Pending:** execution or an external dependency has not occurred.

Record the reason and remaining uncertainty. Repeating a noisy test without a plan for distinguishing noise from signal does not increase confidence automatically.

## Extension and cleanup

Further impact testing requires its own question. Write down what it would prove beyond the existing evidence and whether that evidence is necessary. Do not extend a demonstrated read into write, account takeover, remote execution, or a broader chain solely to obtain a higher severity label.

List test objects created, resources consumed, permissions changed, and artifacts that should be cleaned up. Use the product's normal controlled-account cleanup when covered by the approved plan. Ask before any new destructive or system-level cleanup action.

## Deliverable

Return the observed result, controls, strongest supported claim, limitations, evidence IDs, and next decision. Then produce a beginner explanation and, for a confirmed finding, move to [reporting](07-findings-and-disclosure.md).
