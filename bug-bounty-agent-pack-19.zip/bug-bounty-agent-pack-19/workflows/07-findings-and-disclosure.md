# 07 — Draft findings, remediation, and retests

## Write the report around the behavior

Use [templates/finding.md](../templates/finding.md). A title names the action, protected resource, and broken boundary. “Cross-tenant private document read through attachment download” is more informative than “Critical IDOR.” Keep the exact endpoint and impact consistent throughout the report.

The first paragraph should establish the actor's starting privileges, the operation, the demonstrated unauthorized result, and the affected asset. Then list prerequisites and short numbered reproduction steps. Each step names a controlled account or resource and predicts an observable result.

Include one expected authorized control and one unauthorized result when available. Reference minimal, redacted evidence. Distinguish observed behavior from root-cause inference; source access may support a more precise explanation than black-box traces.

## Impact and rating

State the demonstrated capability and affected data class. Quantify only what was actually established. Keep hypothetical extensions separate and list the additional conditions they require. Do not claim all tenants, all objects, historical exploitation, account takeover, or remote execution from a narrow observation.

Use the program's requested severity system. If a CVSS vector is requested, justify each metric using the specified version and official calculator. If no full vector can be justified, explain the impact and leave the disputed metrics for review rather than inventing a numeric score. Program priority and payment remain program decisions.

## Remediation

Tie the fix to the invariant and the component with authority. Prefer centralized server-side policy enforcement, object queries scoped to the current principal and tenant, explicit transition checks, and consistent policy use in alternate routes. These are design options; choose based on the mechanism and evidence.

Include regression scenarios that fail before a fix and pass after it: permitted access, forbidden access, revoked membership, alternate representation, and relevant child/batch paths. Avoid proposing “hide the button,” “use random IDs,” or “block a string” as a complete repair when the root issue is authorization or interpretation.

## Readiness review

Use the skeptic prompt before declaring a draft ready. Check that another researcher can follow the steps with their own controlled data, each important claim has evidence, irrelevant secrets are removed, current policy information is recorded, and the report does not depend on unpublished internal assumptions.

The user requested to submit findings personally. Provide a ready-to-paste draft and attachment list. Do not click submit, send messages, publish, or contact the company. A serious finding should be handed to the user promptly once sufficient evidence exists; extensive extra exploitation is not necessary for a strong disclosure.

## Retest

Record the vendor's claimed fix and the evidence source. Recheck current program scope and the user's applicable approval. Repeat the original minimal proof and its normal control, then assess directly related variants if covered. A different error response is not sufficient by itself; verify that the protected result and side effects are prevented.

Classify the outcome as fixed under tested conditions, partially fixed, behavior changed but inconclusive, or still reproducible. Preserve new evidence separately from the original finding. Update the defense review and lesson to explain why the change works or leaves a gap.
