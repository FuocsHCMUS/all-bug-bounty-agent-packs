# 08 — Explain controls, risk, and SOC implications

## Do not score an entire company from one endpoint

A researcher can observe a boundary failure or a control response without seeing internal architecture, logs, alerts, or incident handling. Separate:

- **Observed control:** a specific behavior supported by a captured test.
- **Observed weakness:** a demonstrated failure under stated conditions.
- **Potential risk:** a plausible consequence with unverified prerequisites.
- **Proposed improvement:** a design, telemetry, or process recommendation.
- **Not assessed:** an area for which no relevant evidence exists.

Use [templates/defensive-review.md](../templates/defensive-review.md). Every strength and concern needs an evidence reference and a coverage limit.

## Analyze five defensive activities

1. **Prevent:** Which boundary should reject the action before protected work occurs? Consider authentication, authorization, input interpretation, capability binding, tenant isolation, and transition checks.
2. **Observe:** Which event would preserve the actor, action, object, decision, and policy context? A status code alone may miss successful unauthorized behavior.
3. **Detect:** What relationship or sequence distinguishes this behavior from legitimate use?
4. **Investigate/respond:** What evidence would a defender correlate, and what containment or cleanup might be appropriate?
5. **Verify/improve:** Which regression, monitoring test, or architectural change makes the fix durable?

Avoid unsupported statements such as “their WAF failed,” “the SOC did not detect it,” or “their access logging is excellent.” You can recommend the telemetry that would answer those questions.

## Telemetry contract

For a tenant authorization issue, useful proposed fields include timestamp, request ID, authenticated subject, effective tenant, resource ID, resource tenant, operation, authorization decision and reason, policy version, endpoint, response semantic outcome, and relevant job ID. Protect credentials and sensitive payloads; field selection should be minimal and purpose-specific.

Distinguish available client-visible data from company-side requirements. A researcher can record their own controlled test traces. Comparing resource tenant against authenticated tenant in production usually requires server-side enrichment and legitimate-sharing context.

## Detection hypothesis

Write a detection as a falsifiable proposal:

```text
Purpose: identify a successful cross-tenant private-object action.
Data required: authenticated identity, effective tenant, resource tenant,
sharing/policy decision, operation result, timestamp, request ID.
Logic: an operation succeeded where the authoritative policy expected deny.
Exceptions: documented cross-tenant shares, delegated support, service jobs.
Validation: synthetic allowed, denied, shared, and revoked-access events.
Limits: absent identity enrichment or incomplete event coverage can hide cases.
```

Label any SQL, SIEM, or Sigma-like example as proposed until the actual schema and engine are known. Do not invent field names and claim a production-ready rule. Set thresholds only with a baseline and explain expected false positives and false negatives.

## Risk analysis

Discuss confidentiality, integrity, availability, blast radius, prerequisites, persistence of the exposure, revocation behavior, exploit reliability, exposure window, and detection opportunities. Assign a risk label only to a clearly stated scenario. Unknown scale or unseen controls stay unknown.

Map an observed weakness to a verified CWE or ASVS requirement when useful. ATT&CK describes adversary behaviors; a vulnerability class does not necessarily map cleanly to one technique. Check exact identifiers in the relevant version instead of guessing them.

## Turn the result into a lesson

Explain why a correct login check can coexist with a failed object permission check; why a denial is not the same as a logged or alerted denial; and why monitoring complements rather than replaces prevention. Include one control the evidence supports, one specific improvement, and one question that requires internal data.
