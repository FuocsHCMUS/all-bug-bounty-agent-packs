# 09 — Resume and hand off research

## Resume sequence

1. Resolve the session using [the shared session-selection order](../AGENTS.md). If multiple sessions remain ambiguous, ask which one to resume and continue independent reading. Then read `session-state.json`, the selected `engagement.json`, approvals, and the last handoff.
2. Read the active hypothesis and experiment, then only the evidence and sources they reference.
3. Identify what changed: policy freshness, scope, accounts, build/version, test data, tool version, approvals, or earlier cleanup.
4. State the strongest established result and the next unresolved question.
5. Continue an existing valid bounded operation or prepare the specific missing input request.

Do not rerun reconnaissance or ask every setup question from scratch. Equally, do not trust a compacted summary over the actual evidence ledger. A prior agent's confidence statement is not a substitute for its underlying captures.

## State record

Track the session objective, current state, engagement path, active hypothesis IDs, confirmed finding IDs, evidence index, source register, approval record, pending user questions, blockers, cleanup obligations, and next action. Use stable IDs such as `H-001`, `EXP-001`, `EV-001`, and `F-001`; avoid encoding secrets into filenames.

If a source or artifact is unavailable, mark it missing and explain its effect on confidence. Do not reconstruct absent evidence from memory. If records conflict, preserve both with provenance and resolve the conflict before a dependent claim.

## Handoff recipe

Use [templates/handoff.md](../templates/handoff.md). A handoff should let a new agent continue without rereading the entire chat:

- Objective and current phase.
- Exact scope snapshot and relevant approvals.
- Established facts and evidence IDs.
- Hypotheses tested, rejected, inconclusive, and pending.
- Changes made to accounts, resources, tools, and local environment.
- Pending questions and independent tasks that remain possible.
- The next command or analysis step, including why it matters.

## End-of-session learning

Save a short [retrospective](../templates/retrospective.md). Capture which model of the system improved, which test changed your mind, where effort was wasted, what the learner can now explain, and what prerequisite to study next. Do not measure success only by vulnerability count.

Session data is private by default through `.gitignore`. Publishing a redacted case study is a separate user action and requires review of the program's disclosure requirements and the evidence's sensitivity.
