# 10 — Analyze supplied source and patches

## Establish the artifact

Record repository origin, commit or release, paths in scope, language/runtime, local modifications, and why this source relates to the deployment. A public repository with the same product name may not be the deployed edition or build. Keep that correspondence uncertain until evidence supports it.

Inspect code as data first. Do not run repository setup, tests, build hooks, or install scripts merely to read a route. Follow the execution preference before running new code. Use local search and targeted reads rather than dumping the whole repository into context.

## Trace an operation

Follow the path from a real entrypoint through parsing, authentication, authorization, business logic, storage or sink, and response. For each stage record the concrete function, the input's origin, normalization, principal context, validation, and error behavior. Distinguish reachable runtime code from dead code, test fixtures, generated artifacts, and example snippets.

For an authorization candidate, check whether the policy applies to the actual retrieved object, all relevant branches, and alternate representations. For an injection candidate, identify whether attacker-controlled data reaches a sensitive interpreter under conditions that make it executable. A string concatenation or dangerous-looking API name alone is not a validated vulnerability.

## Read a patch

Compare before and after code at an immutable commit range. Identify the failed assumption, the enforcement point added or changed, the input normalization order, and the regression cases. Read surrounding code and call sites; a diff alone can hide a preexisting wrapper or a downstream guard.

Generate variants from equivalent runtime paths, shared helpers, inherited behavior, batch handling, background jobs, and lifecycle edges. A variant needs its own reachability and invariant analysis. Do not report the same root cause many times merely because multiple routes reach it.

## Validate the theory

Prefer an offline regression with synthetic data when source is available. A good test contrasts the vulnerable behavior and the intended fix while preserving legitimate behavior. State what the local test proves and what deployment-specific conditions remain unverified.

If running a project would require additional runtimes, native builds, containers, or system changes, prepare a tooling request. Windows/Python compatibility is an explicit engineering issue; do not silently change the user's workstation to match an old PoC.

## Deliverable

Produce a concise source-to-decision or source-to-sink trace, exact code references, reachability evidence, prerequisites, counterevidence, a bounded claim, and a minimal remediation/regression proposal. Translate the trace into a beginner explanation of where trust enters and where it should be checked.
