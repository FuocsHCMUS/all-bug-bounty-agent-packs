# 11 — Reproduce a mechanism locally

## Purpose

Use a lab to understand a mechanism, compare a repair, or resolve uncertainty without relying on an actual company's behavior. A lab result is evidence about the lab. It becomes a target finding only after separately establishing real applicability and permitted behavior.

## Prefer the smallest model

A policy table, state machine, pure Python function, or static trace can answer many questions without a running service. Before proposing Docker, WSL, a vulnerable VM, or a complex application, explain why a smaller model is insufficient. System components and new tools need user confirmation.

The included `python .\scripts\packctl.py lab` command is a deterministic offline demonstration of authentication versus object authorization. It uses synthetic dictionaries and no listening socket, HTTP client, credentials, file writes, or external services. Propose its execution before running it in a future session unless already approved.

## Lab design

State the mechanism, input space, expected vulnerable result, repaired rule, and positive/negative controls. Keep the model's assumptions visible. A pure function does not reproduce browser caching, distributed races, or TLS; say when those properties are outside the model.

For stateful behavior, write a transition table before code. For concurrent behavior, model allowed interleavings deterministically before considering a live timing experiment. For parser disagreements, compare actual parsers supported by the current runtime rather than relying on copied folklore.

## Compare vulnerable and repaired behavior

Use the same synthetic inputs for both versions. Show the exact change in the enforcement point and verify legitimate behavior remains available. Include a regression that would detect the original mistake. Avoid adding unrelated vulnerable features merely to make the lab more dramatic.

## Lesson and limitations

Explain what the toy model leaves out and which observations a real deployment would need. Ask the learner to predict one new case, such as a valid same-tenant read, a denied cross-tenant read, or revoked membership. Save their answer and the corrected explanation in a lesson artifact.

When learning from a historical CVE, use the advisory and patch to verify the mechanism and supported environment before adopting a public reproduction. Source inspection and a minimal model often provide more learning value than running a large unreviewed exploit repository.
