# SECURITY SKILLS LEARNING PATH & CONCEPT BREAKDOWN

> For cybersecurity students building foundational knowledge from the ground up.
> Reference: [AGENTS.md](./AGENTS.md)

## 1. LEARNING ROADMAP

```
BEGINNER (Months 1-3)
|-- Networking fundamentals (TCP/IP, DNS, HTTP)
|-- Linux basics & command line
|-- Web technologies (HTML, CSS, JS, HTTP)
|-- OWASP Top 10 understanding
|-- Basic tool usage (Burp Suite, Nmap)

INTERMEDIATE (Months 4-8)
|-- Web app pentesting methodology
|-- Common vulnerability classes (SQLi, XSS, SSRF)
|-- API security testing
|-- Scripting (Python for security)
|-- CTF participation
|-- First bug bounty submissions

ADVANCED (Months 9-18)
|-- Exploit development
|-- Vulnerability chaining
|-- Cloud security
|-- Mobile security
|-- Advanced techniques (deserialization, smuggling)
|-- Consistent bug bounty earnings

EXPERT (18+ months)
|-- Zero-day research
|-- Novel attack technique development
|-- Security tool development
|-- Conference talks & publications
|-- Mentoring others
```

## 2. CORE CONCEPTS BREAKDOWN

### CONCEPT: HTTP (HyperText Transfer Protocol)
```
WHAT: The language web browsers and servers use to communicate.
WHY: Every web vulnerability involves HTTP. Understanding it is non-negotiable.
HOW:
  1. Client (browser) sends REQUEST to server
  2. Request has: Method (GET/POST), URL, Headers, Body
  3. Server processes request and sends RESPONSE
  4. Response has: Status Code (200/404/500), Headers, Body
  5. Headers carry metadata (cookies, content-type, auth tokens)
ATTACK: Manipulate requests (change params, headers, methods) to find vulns
DEFENSE: Validate all input, set security headers, use HTTPS
TOOLS: Burp Suite (intercept/modify), curl, httpx, browser DevTools
RELATED: HTTPS/TLS, REST APIs, WebSockets, HTTP/2
RESOURCES: MDN Web Docs, PortSwigger Web Security Academy
```

### CONCEPT: Same-Origin Policy (SOP)
```
WHAT: Browser rule that prevents one website from reading data from another.
WHY: Without SOP, any website could steal your bank data while you browse.
HOW:
  1. Origin = Protocol + Domain + Port (https://example.com:443)
  2. Scripts from origin A cannot read responses from origin B
  3. CORS headers can relax this policy for specific origins
  4. Cookies follow slightly different rules (domain-based)
ATTACK: Find CORS misconfigurations, XSS (bypasses SOP), CSRF
DEFENSE: Strict CORS policy, SameSite cookies, CSP headers
TOOLS: Browser DevTools, Burp Suite, CORS scanner
RELATED: CORS, CSP, XSS, CSRF, Cookies
```

### CONCEPT: SQL Injection (SQLi)
```
WHAT: Tricking a database by inserting SQL commands into user input.
WHY: Can read/modify/delete entire databases. One of the most critical vulns.
HOW:
  1. App takes user input and puts it directly in SQL query
  2. Example: SELECT * FROM users WHERE name = '[USER_INPUT]'
  3. If input is: ' OR '1'='1
  4. Query becomes: SELECT * FROM users WHERE name = '' OR '1'='1'
  5. This returns ALL users because '1'='1' is always true
ATTACK: Extract data, bypass auth, read files, sometimes execute commands
DEFENSE: Parameterized queries (prepared statements), input validation, WAF
TOOLS: sqlmap, Burp Suite, manual testing
RELATED: NoSQL injection, ORM injection, blind SQLi, second-order SQLi
```

### CONCEPT: Cross-Site Scripting (XSS)
```
WHAT: Injecting JavaScript into a website that runs in other users' browsers.
WHY: Can steal cookies/sessions, deface sites, redirect users, keylog.
HOW:
  1. App reflects user input in HTML without sanitization
  2. Attacker injects: <script>alert(document.cookie)</script>
  3. When victim views the page, the script executes in their browser
  4. Types: Reflected (URL), Stored (database), DOM-based (client-side)
ATTACK: Session hijacking, account takeover, phishing, worm propagation
DEFENSE: Output encoding, CSP headers, HttpOnly cookies, input validation
TOOLS: dalfox, XSStrike, Burp Suite, browser DevTools
RELATED: CSP, SOP, CORS, DOM manipulation, cookie security
```

### CONCEPT: Server-Side Request Forgery (SSRF)
```
WHAT: Making the server send requests to places it shouldn't.
WHY: Can access internal services, cloud metadata, bypass firewalls.
HOW:
  1. App fetches a URL provided by user (image URL, webhook, etc.)
  2. Attacker provides internal URL: http://169.254.169.254/
  3. Server fetches it (has access to internal network)
  4. Response may contain AWS keys, internal data, etc.
ATTACK: Read cloud credentials, scan internal network, access admin panels
DEFENSE: URL allowlisting, block private IPs, disable redirects
TOOLS: SSRFmap, Burp Collaborator, custom scripts
RELATED: Cloud metadata, DNS rebinding, protocol smuggling
```

## 3. PRACTICE PLATFORMS

| Platform | URL | Type | Cost |
|----------|-----|------|------|
| PortSwigger Academy | portswigger.net/web-security | Labs | Free |
| HackTheBox | hackthebox.com | Machines | Free/Paid |
| TryHackMe | tryhackme.com | Guided rooms | Free/Paid |
| PentesterLab | pentesterlab.com | Exercises | Paid |
| OWASP WebGoat | github.com/WebGoat | Vulnerable app | Free |
| Damn Vulnerable Web App | github.com/digininja/DVWA | Vulnerable app | Free |
| HackerOne CTF | ctf.hacker101.com | CTF challenges | Free |
| PicoCTF | picoctf.org | Beginner CTF | Free |

## 4. RECOMMENDED LEARNING ORDER

1. **PortSwigger Academy** — Complete all free labs (SQL injection first)
2. **TryHackMe** — Complete "Pre Security" and "Jr Penetration Tester" paths
3. **HackTheBox** — Start with Easy machines, watch IppSec walkthroughs
4. **Bug Bounty** — Start with programs that have wide scope and good response
5. **CTFs** — Join CTFtime events, start with web challenges

*Learning path loaded.*
