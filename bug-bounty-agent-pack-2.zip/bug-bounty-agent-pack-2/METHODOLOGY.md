# DEEP PENETRATION TESTING METHODOLOGY

> Reference: [AGENTS.md](./AGENTS.md) | [RULES.md](./RULES.md) | [SKILL.md](./SKILL.md)

## 1. THE PENETRATION TESTING LIFECYCLE

```
PLANNING --> RECON --> SCANNING --> EXPLOITATION --> POST-EXPLOIT --> REPORTING
```

### 1.1. Planning: Define scope, rules, environment, target profile.
### 1.2. Recon (60% of time here!):

**Passive:** CT logs (crt.sh), DNS (SecurityTrails), OSINT (Google dorks, GitHub, Wayback), Shodan/Censys, LinkedIn, breach data.

**Active:** Subdomain enum (subfinder, amass), port scan (Nmap, rustscan), web crawl (katana, gospider), content discovery (ffuf, feroxbuster), param discovery (Arjun), JS analysis (LinkFinder, SecretFinder), API discovery (kiterunner).

### 1.3. Scanning: Tech fingerprint, vuln scan (nuclei), SSL/TLS, headers, CMS-specific.
### 1.4. Exploitation: Validate, minimal PoC, demonstrate impact, document, chain.
### 1.5. Reporting: Clear, reproducible, CVSS, CWE, remediation, posture analysis.

## 2. ATTACK SURFACE MAP
```
ATTACK SURFACE
|-- Domains & Subdomains (active, inactive, dangling, cloud)
|-- Network Services (ports, admin panels, DBs, API gateways)
|-- Web Apps (login, upload, search, payment, API, admin)
|-- Auth (login, reset, OAuth/SSO, MFA, sessions)
|-- Third-Party (CDN, analytics, payment, email, chat)
```

### Google Dorks
```
site:target.com filetype:pdf | xlsx | csv
site:target.com inurl:admin | login | dashboard
site:target.com intitle:"index of"
site:target.com inurl:api | v1 | v2
site:target.com inurl:redirect | url= | return=
"target.com" site:github.com password | secret | api_key
```

## 3. TESTING BY VULN CLASS

### Auth Testing
1. Default/common creds → 2. Brute force protection → 3. Password reset (token predictable? host header injection? reuse?) → 4. MFA (skip step? response manipulation? backup codes?) → 5. OAuth (redirect_uri? state? token leakage?) → 6. JWT (alg confusion? weak secret? claims?) → 7. Session (fixation? concurrent? logout?)

### Authz Testing
1. Map roles → 2. Each endpoint: no auth, low priv, change IDs (IDOR), change method, older API → 3. Mass assignment → 4. Function-level → 5. Business logic

### Injection Testing
1. Identify inputs (params, body, headers, cookies, uploads, JSON/XML, WebSocket) → 2. Each input: SQLi, XSS, SSTI, CMDi, SSRF, XXE, path traversal → 3. WAF? Identify type, apply bypasses

## 4. BUG BOUNTY PLATFORM TIPS

**HackerOne:** Read policy, check Hacktivity, structured reports, mediation available.
**Bugcrowd:** VRT for severity, check Crowdstream, P1-P4 scale, triage team.
**General:** Check for dupes, chain for impact, quality > quantity, specialize, automate recon.

*Methodology loaded.*
