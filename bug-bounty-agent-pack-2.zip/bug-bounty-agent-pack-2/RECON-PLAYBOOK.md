# RECONNAISSANCE PLAYBOOK

> Reference: [AGENTS.md](./AGENTS.md) | [METHODOLOGY.md](./METHODOLOGY.md)

## 1. RECON WORKFLOW

```
TARGET DOMAIN
|-- Phase 1: Passive Recon (no interaction)
|   |-- DNS enumeration (CT logs, DNS history, records)
|   |-- OSINT (Google dorks, GitHub, Wayback, Shodan)
|   |-- Tech fingerprinting (Wappalyzer, BuiltWith)
|-- Phase 2: Active Recon (direct interaction)
|   |-- Subdomain brute-force & permutation
|   |-- Port & service scanning
|   |-- Content discovery (dirs, files, params)
|   |-- JavaScript analysis (endpoints, secrets)
|-- Phase 3: Analysis
|   |-- Attack surface map
|   |-- Priority targets
|   |-- CVE correlation
```

## 2. SUBDOMAIN ENUMERATION

### Passive Sources
```bash
# Certificate Transparency
curl -s "https://crt.sh/?q=%.target.com&output=json" | jq -r '.[].name_value' | sort -u

# SecurityTrails (API key needed)
curl -s "https://api.securitytrails.com/v1/domain/target.com/subdomains" -H "APIKEY: YOUR_KEY"

# AlienVault OTX
curl -s "https://otx.alienvault.com/api/v1/indicators/domain/target.com/passive_dns" | jq -r '.passive_dns[].hostname'

# Wayback Machine
curl -s "http://web.archive.org/cdx/search/cdx?url=*.target.com/*&output=text&fl=original" | sort -u

# Common Crawl
curl -s "https://index.commoncrawl.org/CC-MAIN-2024-10-index?url=*.target.com&output=json" | jq -r '.url'
```

### Active Enumeration
```bash
# Brute-force with wordlist
ffuf -u "https://FUZZ.target.com" -w subdomains.txt -mc 200,301,302,403

# DNS brute-force
subfinder -d target.com -all -o subs.txt
amass enum -d target.com -o amass_subs.txt

# Permutation
altdns -i subs.txt -o permuted.txt -w words.txt
```

## 3. PORT & SERVICE SCANNING

```bash
# Fast scan all ports
rustscan -a target.com -- -sV -sC -oN scan.txt

# Nmap comprehensive
nmap -sV -sC -p- -T4 --min-rate=1000 target.com -oA nmap_full

# Service-specific
nmap -p 80,443,8080,8443 --script=http-enum target.com
```

## 4. CONTENT DISCOVERY

```bash
# Directory brute-force
ffuf -u "https://target.com/FUZZ" -w /path/to/wordlist.txt -mc 200,301,302,403 -recursion

# Technology-specific wordlists
# WordPress: wp-content, wp-admin, wp-json, xmlrpc.php
# Laravel: .env, storage/logs, telescope, horizon
# Django: admin/, __debug__/, api/, static/
# Node/Express: .env, package.json, node_modules/
# Java/Spring: actuator/, swagger-ui/, api-docs/

# Parameter discovery
arjun -u "https://target.com/endpoint" -m GET POST

# Wayback URLs
echo "target.com" | waybackurls | sort -u | grep -E "\?.*="
echo "target.com" | gau | sort -u
```

## 5. JAVASCRIPT ANALYSIS

```bash
# Find JS files
echo "target.com" | gau | grep -iE "\.js$" | sort -u > js_files.txt

# Extract endpoints from JS
cat js_files.txt | while read url; do
    curl -s "$url" | grep -oP '["'"'"'](/[a-zA-Z0-9_/.-]+)["'"'"']' | sort -u
done

# Find secrets in JS
# Look for: API keys, tokens, passwords, internal URLs, S3 buckets
nuclei -l js_files.txt -t exposures/
```

## 6. CLOUD ASSET DISCOVERY

```bash
# S3 Buckets
# Check: target.s3.amazonaws.com, s3.amazonaws.com/target
# Tools: cloud_enum, S3Scanner, bucket-finder

# Azure Blob
# Check: target.blob.core.windows.net
# Tools: MicroBurst

# GCP
# Check: storage.googleapis.com/target
```

## 7. RECON AUTOMATION SCRIPT

```python
#!/usr/bin/env python3
"""Automated recon pipeline - run all passive recon sources."""
import asyncio, httpx, json, sys
from datetime import datetime

async def full_recon(domain: str):
    print(f"[*] Starting recon for: {domain}")
    print(f"[*] Time: {datetime.now().isoformat()}")
    results = {"domain": domain, "subdomains": set(), "tech": {}, "ports": []}
    
    async with httpx.AsyncClient(timeout=30, follow_redirects=True) as c:
        # crt.sh
        print("[*] Querying crt.sh...")
        try:
            r = await c.get(f"https://crt.sh/?q=%.{domain}&output=json")
            if r.status_code == 200:
                for e in r.json():
                    for s in e.get("name_value","").splitlines():
                        s = s.strip().lower()
                        if s.endswith(f".{domain}"): results["subdomains"].add(s)
            print(f"    Found {len(results['subdomains'])} subdomains")
        except Exception as e: print(f"    Error: {e}")
    
    results["subdomains"] = sorted(results["subdomains"])
    # Save results
    out = f"recon_data/{domain}_recon.json"
    with open(out, "w") as f:
        json.dump({"domain": domain, "subdomains": results["subdomains"]}, f, indent=2)
    print(f"[+] Results saved to {out}")

if __name__ == "__main__":
    domain = sys.argv[1] if len(sys.argv) > 1 else input("Domain: ")
    asyncio.run(full_recon(domain))
```

*Recon playbook loaded.*
