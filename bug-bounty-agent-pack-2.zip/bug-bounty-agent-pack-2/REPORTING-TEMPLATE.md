# BUG BOUNTY REPORT TEMPLATE & SECURITY POSTURE ANALYSIS

> Reference: [AGENTS.md](./AGENTS.md) | [RULES.md](./RULES.md)

## 1. VULNERABILITY REPORT TEMPLATE

```markdown
# [SEVERITY] Vulnerability Title — Brief Description

## Summary
One paragraph: what the vulnerability is, where it exists, and its impact.

## Severity
- **Rating:** Critical / High / Medium / Low / Informational
- **CVSS 4.0 Score:** X.X
- **CVSS Vector:** CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N
- **CWE:** CWE-XXX (Vulnerability Name)

## Affected Component
- **URL/Endpoint:** https://target.com/api/v1/users/{id}
- **Parameter:** id
- **HTTP Method:** GET
- **Authentication Required:** Yes/No (specify level)

## Steps to Reproduce
1. Navigate to https://target.com/login
2. Log in with credentials (any authenticated user)
3. Intercept the request to /api/v1/users/123
4. Change the user ID from 123 to 456
5. Observe that you can access another user's data

## HTTP Request
    GET /api/v1/users/456 HTTP/2
    Host: target.com
    Authorization: Bearer eyJ...
    Cookie: session=abc123

## HTTP Response
    HTTP/2 200 OK
    Content-Type: application/json
    {"id":456,"email":"victim@example.com","name":"Victim User","ssn":"123-45-6789"}

## Impact
- **Confidentiality:** An attacker can access any user's PII (name, email, SSN)
- **Integrity:** N/A (read-only access)
- **Availability:** N/A
- **Business Impact:** Mass data breach, regulatory violations (GDPR, CCPA)
- **Affected Users:** All registered users (~X users)

## Proof of Concept
[Screenshot or script demonstrating the vulnerability]

## Remediation
1. Implement proper authorization checks on the /api/v1/users/{id} endpoint
2. Verify that the authenticated user can only access their own data
3. Example fix (pseudocode):
   if request.user.id != requested_user_id:
       return 403 Forbidden

## References
- CWE-639: Authorization Bypass Through User-Controlled Key
- OWASP: Broken Object Level Authorization
- https://owasp.org/API-Security/editions/2023/en/0xa1-broken-object-level-authorization/
```

## 2. SECURITY POSTURE ANALYSIS TEMPLATE

```markdown
# SECURITY POSTURE REPORT: [Target Name]
Date: [Date]
Tester: PHANTOM (AI-Assisted Bug Bounty)
Scope: [Domains/applications tested]

## EXECUTIVE SUMMARY
[2-3 paragraphs summarizing overall security posture, key findings, and recommendations]

## FINDINGS SUMMARY
| Severity | Count | Examples |
|----------|-------|----------|
| 🔴 Critical | X | [Brief list] |
| 🟠 High | X | [Brief list] |
| 🟡 Medium | X | [Brief list] |
| 🔵 Low | X | [Brief list] |
| ⚪ Info | X | [Brief list] |

## SECURITY STRENGTHS 🟢
- [What the company does well]
- [Strong security controls observed]
- [Good practices identified]

## NEEDS IMPROVEMENT 🟡
- [Areas with partial protection]
- [Controls that could be strengthened]

## AT RISK 🟠
- [Potential vulnerabilities]
- [Weak configurations]

## CRITICAL RISKS 🔴
- [Active vulnerabilities]
- [Severe misconfigurations]

## DETAILED ANALYSIS BY DIMENSION

### 1. Authentication & Access Control
Status: [🟢/🟡/🟠/🔴]
Observations: [What was found]
Recommendations: [How to improve]

### 2. Input Validation
Status: [🟢/🟡/🟠/🔴]
[...]

### 3-12. [Repeat for each dimension from AGENTS.md Section 6.2]

## PRIORITIZED RECOMMENDATIONS
1. [Most critical fix] — Timeline: Immediate
2. [Second priority] — Timeline: 1 week
3. [Third priority] — Timeline: 1 month
[...]
```

## 3. CVSS 4.0 QUICK REFERENCE

| Metric | Values | Description |
|--------|--------|-------------|
| AV (Attack Vector) | N/A/L/P | Network/Adjacent/Local/Physical |
| AC (Attack Complexity) | L/H | Low/High |
| AT (Attack Requirements) | N/P | None/Present |
| PR (Privileges Required) | N/L/H | None/Low/High |
| UI (User Interaction) | N/P/A | None/Passive/Active |
| VC (Confidentiality) | N/L/H | None/Low/High |
| VI (Integrity) | N/L/H | None/Low/High |
| VA (Availability) | N/L/H | None/Low/High |

## 4. CWE QUICK REFERENCE

| CWE | Name | Common In |
|-----|------|-----------|
| CWE-79 | XSS | Web apps |
| CWE-89 | SQL Injection | Database apps |
| CWE-639 | IDOR | APIs |
| CWE-352 | CSRF | Web forms |
| CWE-918 | SSRF | URL fetchers |
| CWE-611 | XXE | XML parsers |
| CWE-78 | OS Command Injection | System calls |
| CWE-94 | Code Injection | Template engines |
| CWE-287 | Auth Bypass | Login systems |
| CWE-862 | Missing Authorization | APIs |
| CWE-200 | Info Disclosure | Error pages |
| CWE-522 | Weak Credentials | Auth systems |

*Reporting template loaded.*
