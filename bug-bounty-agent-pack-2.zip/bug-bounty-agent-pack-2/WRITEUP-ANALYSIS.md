# WRITEUP & CTF ANALYSIS FRAMEWORK

> Reference: [AGENTS.md](./AGENTS.md) | [SKILL.md](./SKILL.md)

## 1. WRITEUP SOURCES

### Bug Bounty Writeups
| Source | URL | Type |
|--------|-----|------|
| HackerOne Hacktivity | hackerone.com/hacktivity | Disclosed reports |
| Bugcrowd Crowdstream | bugcrowd.com/crowdstream | Disclosed reports |
| Pentester Land | pentester.land/list-of-bug-bounty-writeups.html | Curated list |
| InfoSec Writeups | infosecwriteups.com | Medium publication |
| Medium Bug Bounty | medium.com/tag/bug-bounty | Community writeups |
| PortSwigger Research | portswigger.net/research | Advanced research |
| Project Zero | googleprojectzero.blogspot.com | Zero-day research |

### CTF Writeups
| Source | URL | Type |
|--------|-----|------|
| CTFtime | ctftime.org/writeups | Competition writeups |
| GitHub CTF repos | github.com/topics/ctf-writeups | Community solutions |
| LiveOverflow | youtube.com/LiveOverflow | Video explanations |
| John Hammond | youtube.com/JohnHammond010 | CTF walkthroughs |
| IppSec | youtube.com/ippsec | HTB walkthroughs |

### Research Papers & Blogs
- PortSwigger Daily Swig, Google Project Zero, Trail of Bits blog
- Assetnote Research, Detectify Labs, Bishop Fox blog
- Orange Tsai blog, James Kettle research, Frans Rosen blog

## 2. WRITEUP ANALYSIS FRAMEWORK

When reading a writeup, extract these elements:

```
WRITEUP ANALYSIS
|-- VULNERABILITY
|   |-- Class: [XSS/SQLi/SSRF/IDOR/etc.]
|   |-- Subtype: [Stored/Reflected/Blind/etc.]
|   |-- Severity: [Critical/High/Medium/Low]
|   |-- Bounty: [$amount]
|-- ROOT CAUSE
|   |-- Why did this vulnerability exist?
|   |-- What assumption did the developer make?
|   |-- What control was missing or misconfigured?
|-- DISCOVERY METHOD
|   |-- How was it found? (manual/automated/accident)
|   |-- What tools were used?
|   |-- What made the researcher look there?
|-- EXPLOITATION CHAIN
|   |-- Step 1: [Initial access/discovery]
|   |-- Step 2: [Exploitation]
|   |-- Step N: [Impact demonstration]
|-- BYPASS TECHNIQUES
|   |-- What security controls were bypassed?
|   |-- How were they bypassed?
|   |-- What encoding/obfuscation was used?
|-- APPLICABILITY
|   |-- Can this technique apply to our target?
|   |-- What conditions are needed?
|   |-- What variations might work?
|-- LESSONS LEARNED
|   |-- What new technique did we learn?
|   |-- How does this change our methodology?
|   |-- What should we test next?
```

## 3. CTF SKILL MAPPING

### Web Challenges
- SQL injection (error, union, blind, second-order)
- XSS (reflected, stored, DOM, CSP bypass)
- SSTI (Jinja2, Twig, Pebble, Freemarker)
- SSRF (basic, cloud, protocol smuggling)
- Deserialization (PHP, Java, Python pickle, .NET)
- File inclusion (LFI, RFI, log poisoning)
- Race conditions (TOCTOU, double-spend)
- Prototype pollution (Node.js)
- JWT attacks (algorithm confusion, key cracking)

### Crypto Challenges
- Classical ciphers (Caesar, Vigenere, substitution)
- RSA attacks (small e, Wiener, Hastad, common modulus)
- AES attacks (ECB penguin, CBC bit-flipping, padding oracle)
- Hash attacks (length extension, collision)
- PRNG attacks (seed prediction, state recovery)

### Forensics/OSINT
- Metadata extraction (EXIF, PDF, DOCX)
- Network packet analysis (Wireshark, tcpdump)
- Memory forensics (Volatility)
- Steganography (image, audio, text)
- Log analysis and timeline reconstruction

## 4. TECHNIQUE ADAPTATION PROCESS

```
READ WRITEUP --> EXTRACT TECHNIQUE --> ABSTRACT PATTERN --> ADAPT TO TARGET
     |                |                     |                    |
     v                v                     v                    v
  Understand      What was the         Generalize          Apply to
  the specific    core trick?          the approach        current
  scenario                                                 target
```

### Example Adaptation:
**Writeup:** "Found SSRF via PDF generation feature"
**Pattern:** Any feature that fetches URLs (PDF gen, image resize, link preview, webhook)
**Adaptation:** Check if target has any URL-fetching feature, test with SSRF payloads

*Writeup analysis framework loaded.*
