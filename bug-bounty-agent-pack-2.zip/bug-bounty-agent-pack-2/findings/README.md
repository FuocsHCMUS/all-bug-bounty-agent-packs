# Findings Directory

This directory stores discovered vulnerabilities during bug bounty engagements.

## Structure
Each finding is stored as a JSON or Markdown file:
```
findings/
├── vuln_scan.json          (automated scanner results)
├── finding_001_sqli.md     (manual finding)
├── finding_002_xss.md      (manual finding)
└── ...
```

## Finding Template
```markdown
# Finding: [Title]
- Severity: [Critical/High/Medium/Low]
- Target: [URL]
- Date: [Date]
- Status: [New/Reported/Triaged/Resolved]

## Description
[What the vulnerability is]

## Steps to Reproduce
[How to reproduce]

## Impact
[What an attacker can achieve]

## Evidence
[Screenshots, requests, responses]
```
