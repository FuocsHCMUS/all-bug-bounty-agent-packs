# Notes Directory

Learning notes, technique documentation, and research findings.

## Structure
- `concepts/` — Security concept breakdowns
- `techniques/` — Exploitation technique notes
- `writeup_analysis/` — Analysis of public writeups
- `session_notes/` — Per-session progress notes
