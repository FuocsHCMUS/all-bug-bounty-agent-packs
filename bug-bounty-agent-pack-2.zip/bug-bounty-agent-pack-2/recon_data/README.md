# Recon Data Directory

Stores reconnaissance results from automated and manual enumeration.

## Contents
- `{domain}_recon.json` — Full recon results
- `{domain}_subdomains.json` — Subdomain enumeration
- `cve_{keyword}.json` — CVE search results
- `js_analysis.json` — JavaScript analysis results
