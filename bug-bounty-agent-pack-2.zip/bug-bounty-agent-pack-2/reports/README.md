# Reports Directory

Generated bug bounty reports ready for submission.

## Naming Convention
`report_YYYYMMDD_HHMMSS_vulnerability_title.md`

## Platforms
- HackerOne: https://hackerone.com
- Bugcrowd: https://bugcrowd.com
- Intigriti: https://intigriti.com
- YesWeHack: https://yeswehack.com
