#!/usr/bin/env python3
"""
CVE Correlator — Search NVD for CVEs related to a technology/keyword.
Usage: python cve_correlator.py <keyword> [version]
Example: python cve_correlator.py apache 2.4.49
Requirements: pip install httpx rich
"""
import asyncio, sys, json
from datetime import datetime
from pathlib import Path
try:
    import httpx
except ImportError:
    print("[!] Run: pip install httpx"); sys.exit(1)
try:
    from rich.console import Console
    from rich.table import Table
    console = Console()
except ImportError:
    print("[!] Run: pip install rich"); sys.exit(1)

async def search_nvd(keyword: str, max_results: int = 25):
    """Search NVD API for CVEs matching keyword."""
    url = f"https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch={keyword}&resultsPerPage={max_results}"
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(url)
        if r.status_code == 200:
            return r.json().get("vulnerabilities", [])
        else:
            console.print(f"[red][!] NVD API error: {r.status_code}[/red]")
            return []

async def search_exploitdb(keyword: str):
    """Search ExploitDB via Google (passive)."""
    console.print(f"[yellow][*] ExploitDB search: https://www.exploit-db.com/search?q={keyword}[/yellow]")
    console.print(f"[yellow][*] GitHub search: https://github.com/search?q={keyword}+exploit&type=repositories[/yellow]")

def parse_cvss(metrics: dict) -> str:
    """Extract CVSS score from NVD metrics."""
    for version in ["cvssMetricV40", "cvssMetricV31", "cvssMetricV30", "cvssMetricV2"]:
        if version in metrics:
            data = metrics[version]
            if isinstance(data, list) and data:
                score = data[0].get("cvssData", {}).get("baseScore", "N/A")
                severity = data[0].get("cvssData", {}).get("baseSeverity", "N/A")
                return f"{score} ({severity})"
    return "N/A"

async def main(keyword: str, version: str = None):
    search_term = f"{keyword} {version}" if version else keyword
    console.print(f"[bold green][*] CVE Correlator — Searching: {search_term}[/bold green]")
    
    cves = await search_nvd(search_term)
    await search_exploitdb(search_term)
    
    if not cves:
        console.print("[yellow][!] No CVEs found. Try broader search terms.[/yellow]")
        return
    
    table = Table(title=f"CVEs for: {search_term}")
    table.add_column("CVE ID", style="cyan", width=18)
    table.add_column("CVSS", style="red", width=15)
    table.add_column("Description", style="white", width=80)
    
    results = []
    for vuln in cves:
        cve = vuln.get("cve", {})
        cve_id = cve.get("id", "N/A")
        desc = cve.get("descriptions", [{}])[0].get("value", "N/A")[:120]
        cvss = parse_cvss(cve.get("metrics", {}))
        table.add_row(cve_id, cvss, desc)
        results.append({"id": cve_id, "cvss": cvss, "description": desc})
    
    console.print(table)
    console.print(f"\n[green][+] Found {len(cves)} CVEs[/green]")
    
    # Save
    out = Path(__file__).parent.parent / "recon_data" / f"cve_{keyword}.json"
    out.parent.mkdir(exist_ok=True)
    with open(out, "w") as f:
        json.dump({"keyword": search_term, "timestamp": datetime.now().isoformat(), "cves": results}, f, indent=2)
    console.print(f"[green][+] Saved: {out}[/green]")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python cve_correlator.py <keyword> [version]")
        sys.exit(1)
    kw = sys.argv[1]
    ver = sys.argv[2] if len(sys.argv) > 2 else None
    asyncio.run(main(kw, ver))
