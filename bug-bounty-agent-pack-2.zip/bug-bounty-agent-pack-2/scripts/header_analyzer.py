#!/usr/bin/env python3
"""
HTTP Security Header Analyzer — Check security headers for a URL.
Usage: python header_analyzer.py <url>
Requirements: pip install httpx rich
"""
import sys
try:
    import httpx
except ImportError:
    print("[!] Run: pip install httpx"); sys.exit(1)
try:
    from rich.console import Console
    from rich.table import Table
    console = Console()
except ImportError:
    print("[!] Run: pip install rich"); sys.exit(1)

SECURITY_HEADERS = {
    "strict-transport-security": ("HIGH", "HSTS missing — SSL stripping risk", "Strict-Transport-Security: max-age=31536000; includeSubDomains; preload"),
    "content-security-policy": ("MEDIUM", "CSP missing — XSS risk increased", "Content-Security-Policy: default-src 'self'"),
    "x-content-type-options": ("LOW", "MIME type sniffing possible", "X-Content-Type-Options: nosniff"),
    "x-frame-options": ("MEDIUM", "Clickjacking possible", "X-Frame-Options: DENY"),
    "referrer-policy": ("LOW", "URL leakage to third parties", "Referrer-Policy: strict-origin-when-cross-origin"),
    "permissions-policy": ("LOW", "Browser features unrestricted", "Permissions-Policy: camera=(), microphone=(), geolocation=()"),
    "cross-origin-opener-policy": ("MEDIUM", "Cross-origin attacks possible", "Cross-Origin-Opener-Policy: same-origin"),
    "cross-origin-resource-policy": ("MEDIUM", "Cross-origin resource loading unrestricted", "Cross-Origin-Resource-Policy: same-origin"),
    "cross-origin-embedder-policy": ("LOW", "Cross-origin embedding unrestricted", "Cross-Origin-Embedder-Policy: require-corp"),
}

INFO_HEADERS_TO_CHECK = ["server", "x-powered-by", "x-aspnet-version", "x-aspnetmvc-version", "x-generator"]

def analyze(url: str):
    console.print(f"[bold green][*] Analyzing: {url}[/bold green]\n")
    with httpx.Client(verify=False, follow_redirects=True, timeout=15) as c:
        r = c.get(url)
        headers = {k.lower(): v for k, v in r.headers.items()}
    
    # Missing security headers
    table = Table(title="Missing Security Headers")
    table.add_column("Header", style="cyan")
    table.add_column("Severity", style="red")
    table.add_column("Risk", style="yellow")
    table.add_column("Recommendation", style="green")
    
    missing = 0
    for header, (severity, risk, rec) in SECURITY_HEADERS.items():
        if header not in headers:
            table.add_row(header, severity, risk, rec)
            missing += 1
    console.print(table)
    
    # Present security headers
    table2 = Table(title="Present Security Headers")
    table2.add_column("Header", style="cyan")
    table2.add_column("Value", style="green")
    for header in SECURITY_HEADERS:
        if header in headers:
            table2.add_row(header, headers[header][:80])
    console.print(table2)
    
    # Information disclosure headers
    table3 = Table(title="Information Disclosure Headers")
    table3.add_column("Header", style="cyan")
    table3.add_column("Value", style="red")
    for header in INFO_HEADERS_TO_CHECK:
        if header in headers:
            table3.add_row(header, headers[header])
    console.print(table3)
    
    # Score
    total = len(SECURITY_HEADERS)
    present = total - missing
    score = (present / total) * 100
    color = "green" if score >= 80 else "yellow" if score >= 50 else "red"
    console.print(f"\n[{color}]Security Header Score: {present}/{total} ({score:.0f}%)[/{color}]")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python header_analyzer.py <url>")
        sys.exit(1)
    analyze(sys.argv[1])
