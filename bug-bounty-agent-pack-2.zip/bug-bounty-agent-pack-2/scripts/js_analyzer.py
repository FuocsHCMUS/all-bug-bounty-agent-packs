#!/usr/bin/env python3
"""
JavaScript Endpoint & Secret Analyzer — Extract endpoints, API keys, and secrets from JS files.
Usage: python js_analyzer.py <url>
Requirements: pip install httpx rich
"""
import asyncio, sys, re, json
from urllib.parse import urljoin
from pathlib import Path
from datetime import datetime
try:
    import httpx
except ImportError:
    print("[!] Run: pip install httpx"); sys.exit(1)
try:
    from rich.console import Console
    from rich.table import Table
    console = Console()
except ImportError:
    print("[!] Run: pip install rich"); sys.exit(1)

SECRET_PATTERNS = [
    (r'(?:api[_-]?key|apikey|api_secret)\s*[:=]\s*["\']([^"\']{10,})["\']', "API_KEY"),
    (r'(?:access[_-]?token|auth[_-]?token)\s*[:=]\s*["\']([^"\']{10,})["\']', "TOKEN"),
    (r'(?:secret[_-]?key|client[_-]?secret)\s*[:=]\s*["\']([^"\']{10,})["\']', "SECRET"),
    (r'(?:password|passwd|pwd)\s*[:=]\s*["\']([^"\']{6,})["\']', "PASSWORD"),
    (r'sk-[a-zA-Z0-9]{20,}', "OPENAI_KEY"),
    (r'ghp_[a-zA-Z0-9]{36}', "GITHUB_TOKEN"),
    (r'glpat-[a-zA-Z0-9\-]{20,}', "GITLAB_TOKEN"),
    (r'xox[baprs]-[a-zA-Z0-9\-]+', "SLACK_TOKEN"),
    (r'AKIA[0-9A-Z]{16}', "AWS_ACCESS_KEY"),
    (r'(?:firebase|supabase|mongodb\+srv)://[^\s"\']+', "DB_URI"),
    (r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----', "PRIVATE_KEY"),
]

ENDPOINT_PATTERNS = [
    r'["\'](/api/[^"\'?\s]{2,})["\']',
    r'["\'](/v[0-9]+/[^"\'?\s]{2,})["\']',
    r'["\'](/graphql[^"\'?\s]*)["\']',
    r'fetch\s*\(\s*["\']([^"\']+)["\']',
    r'axios\.[a-z]+\s*\(\s*["\']([^"\']+)["\']',
    r'\.ajax\s*\(\s*\{[^}]*url\s*:\s*["\']([^"\']+)["\']',
    r'["\'](/[a-zA-Z0-9_-]+/[a-zA-Z0-9_-]+(?:/[a-zA-Z0-9_-]+)*)["\']',
]

async def analyze_js(base_url: str):
    console.print(f"[bold green][*] JS Analyzer — Target: {base_url}[/bold green]\n")
    all_secrets = set()
    all_endpoints = set()
    all_js_files = set()
    all_emails = set()
    
    async with httpx.AsyncClient(timeout=15, verify=False, follow_redirects=True) as c:
        # Get main page and find JS files
        r = await c.get(base_url)
        js_urls = set(re.findall(r'src=["\']([^"\']*\.js[^"\']*)["\']', r.text))
        js_urls.update(re.findall(r'href=["\']([^"\']*\.js[^"\']*)["\']', r.text))
        
        for js_path in js_urls:
            full_url = urljoin(base_url, js_path)
            all_js_files.add(full_url)
        
        console.print(f"[cyan][*] Found {len(all_js_files)} JS files[/cyan]")
        
        # Analyze each JS file
        for js_url in all_js_files:
            try:
                jr = await c.get(js_url)
                content = jr.text
                # Secrets
                for pattern, label in SECRET_PATTERNS:
                    for match in re.finditer(pattern, content, re.I):
                        all_secrets.add(f"[{label}] {match.group()[:100]}")
                # Endpoints
                for pattern in ENDPOINT_PATTERNS:
                    for match in re.finditer(pattern, content):
                        ep = match.group(1)
                        if len(ep) > 3 and not ep.endswith(('.js','.css','.png','.jpg','.svg','.gif')):
                            all_endpoints.add(ep)
                # Emails
                all_emails.update(re.findall(r'[\w.+-]+@[\w-]+\.[\w.]+', content))
            except Exception:
                pass
    
    # Display results
    if all_secrets:
        table = Table(title="Secrets Found", style="red")
        table.add_column("Type", style="yellow")
        table.add_column("Value", style="red")
        for s in sorted(all_secrets):
            parts = s.split("] ", 1)
            table.add_row(parts[0]+"]", parts[1] if len(parts)>1 else s)
        console.print(table)
    else:
        console.print("[green][+] No secrets found in JS files[/green]")
    
    if all_endpoints:
        table2 = Table(title="Endpoints Found")
        table2.add_column("Endpoint", style="cyan")
        for ep in sorted(all_endpoints):
            table2.add_row(ep)
        console.print(table2)
    
    if all_emails:
        console.print(f"\n[yellow]Emails found: {', '.join(sorted(all_emails))}[/yellow]")
    
    # Save
    out = Path(__file__).parent.parent / "recon_data" / "js_analysis.json"
    out.parent.mkdir(exist_ok=True)
    with open(out, "w") as f:
        json.dump({"url":base_url,"timestamp":datetime.now().isoformat(),"js_files":sorted(all_js_files),
                   "secrets":sorted(all_secrets),"endpoints":sorted(all_endpoints),"emails":sorted(all_emails)},f,indent=2)
    console.print(f"\n[green][+] Saved: {out}[/green]")

if __name__ == "__main__":
    if len(sys.argv) < 2: print("Usage: python js_analyzer.py <url>"); sys.exit(1)
    asyncio.run(analyze_js(sys.argv[1]))
