#!/usr/bin/env python3
"""
Automated Recon Engine for Bug Bounty. Passive subdomain enum + alive check + fingerprint.
Usage: python recon_engine.py <domain>
Requirements: pip install httpx rich
"""
import asyncio, sys, json, re
from datetime import datetime
from pathlib import Path
try:
    import httpx
except ImportError:
    print("[!] Run: pip install httpx"); sys.exit(1)
try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    console = Console()
except ImportError:
    print("[!] Run: pip install rich"); sys.exit(1)

async def enum_crtsh(c, domain):
    subs = set()
    try:
        r = await c.get(f"https://crt.sh/?q=%.{domain}&output=json")
        if r.status_code == 200:
            for e in r.json():
                for n in e.get("name_value","").splitlines():
                    n = n.strip().lower().replace("*.","")
                    if n.endswith(f".{domain}") or n == domain: subs.add(n)
    except Exception as e: console.print(f"[red][!] crt.sh: {e}[/red]")
    return subs

async def enum_hackertarget(c, domain):
    subs = set()
    try:
        r = await c.get(f"https://api.hackertarget.com/hostsearch/?q={domain}")
        if r.status_code == 200 and "error" not in r.text.lower():
            for line in r.text.strip().splitlines():
                if "," in line: subs.add(line.split(",")[0].strip().lower())
    except Exception as e: console.print(f"[red][!] HackerTarget: {e}[/red]")
    return subs

async def enum_otx(c, domain):
    subs = set()
    try:
        r = await c.get(f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns")
        if r.status_code == 200:
            for e in r.json().get("passive_dns",[]):
                h = e.get("hostname","").lower()
                if h.endswith(f".{domain}"): subs.add(h)
    except Exception as e: console.print(f"[red][!] OTX: {e}[/red]")
    return subs

async def check_alive(c, sub):
    for scheme in ["https","http"]:
        try:
            r = await c.get(f"{scheme}://{sub}", timeout=8)
            return {"subdomain":sub,"status":r.status_code,"server":r.headers.get("server","N/A"),"size":len(r.content)}
        except: continue
    return None

async def fingerprint(c, url):
    tech = {"server":[],"framework":[],"cms":[],"waf":[]}
    try:
        r = await c.get(url, timeout=10)
        h = dict(r.headers)
        if "server" in h: tech["server"].append(h["server"])
        if "x-powered-by" in h: tech["framework"].append(h["x-powered-by"])
        if "cf-ray" in h: tech["waf"].append("Cloudflare")
        body = r.text[:50000]
        if re.search(r"wp-content/",body,re.I): tech["cms"].append("WordPress")
        if re.search(r"__NEXT_DATA__",body,re.I): tech["cms"].append("Next.js")
    except: pass
    return tech

async def main(domain):
    console.print(Panel(f"[bold green]PHANTOM Recon[/bold green]\nTarget: {domain}\nTime: {datetime.now().isoformat()}"))
    async with httpx.AsyncClient(timeout=30, follow_redirects=True, verify=False) as c:
        console.print("\n[cyan][*] Subdomain Enumeration[/cyan]")
        results = await asyncio.gather(enum_crtsh(c,domain), enum_hackertarget(c,domain), enum_otx(c,domain))
        all_subs = set().union(*results, {domain})
        console.print(f"[green][+] {len(all_subs)} subdomains[/green]")
        console.print("\n[cyan][*] Alive Check[/cyan]")
        alive = [r for r in await asyncio.gather(*[check_alive(c,s) for s in sorted(all_subs)]) if r]
        console.print(f"[green][+] {len(alive)} alive[/green]")
        t = Table(title="Alive Hosts")
        t.add_column("Subdomain",style="cyan"); t.add_column("Status",style="green"); t.add_column("Server",style="yellow")
        for h in sorted(alive, key=lambda x:x["subdomain"]): t.add_row(h["subdomain"],str(h["status"]),h["server"])
        console.print(t)
        console.print("\n[cyan][*] Fingerprinting[/cyan]")
        tech = await fingerprint(c, f"https://{domain}")
        for k,v in tech.items():
            if v: console.print(f"  [yellow]{k}:[/yellow] {', '.join(v)}")
    out = Path(__file__).parent.parent / "recon_data" / f"{domain}_recon.json"
    out.parent.mkdir(exist_ok=True)
    with open(out,"w") as f: json.dump({"domain":domain,"timestamp":datetime.now().isoformat(),"subdomains":sorted(all_subs),"alive":alive,"tech":tech},f,indent=2,default=str)
    console.print(f"\n[green][+] Saved: {out}[/green]")

if __name__ == "__main__":
    if len(sys.argv) < 2: print("Usage: python recon_engine.py <domain>"); sys.exit(1)
    asyncio.run(main(sys.argv[1]))
