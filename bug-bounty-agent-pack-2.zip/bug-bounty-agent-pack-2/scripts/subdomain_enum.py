#!/usr/bin/env python3
"""
Subdomain Enumeration Tool — Multi-source passive subdomain discovery.
Usage: python subdomain_enum.py <domain>
Requirements: pip install httpx rich
"""
import asyncio, sys, json
from datetime import datetime
from pathlib import Path
try:
    import httpx
except ImportError:
    print("[!] Run: pip install httpx"); sys.exit(1)
try:
    from rich.console import Console
    console = Console()
except ImportError:
    print("[!] Run: pip install rich"); sys.exit(1)

SOURCES = {
    "crt.sh": "https://crt.sh/?q=%.{domain}&output=json",
    "HackerTarget": "https://api.hackertarget.com/hostsearch/?q={domain}",
    "OTX": "https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns",
    "URLScan": "https://urlscan.io/api/v1/search/?q=domain:{domain}&size=1000",
    "RapidDNS": "https://rapiddns.io/subdomain/{domain}?full=1",
}

async def enum_source(c, name, url, domain):
    subs = set()
    try:
        r = await c.get(url.format(domain=domain))
        if r.status_code != 200: return subs
        if name == "crt.sh":
            for e in r.json():
                for s in e.get("name_value","").splitlines():
                    s = s.strip().lower().replace("*.","")
                    if s.endswith(f".{domain}"): subs.add(s)
        elif name == "HackerTarget":
            for line in r.text.strip().splitlines():
                if "," in line: subs.add(line.split(",")[0].strip().lower())
        elif name == "OTX":
            for e in r.json().get("passive_dns",[]):
                h = e.get("hostname","").lower()
                if h.endswith(f".{domain}"): subs.add(h)
        elif name == "URLScan":
            for res in r.json().get("results",[]):
                h = res.get("page",{}).get("domain","").lower()
                if h.endswith(f".{domain}"): subs.add(h)
        elif name == "RapidDNS":
            import re
            for m in re.finditer(r'<td>([a-zA-Z0-9._-]+\.' + re.escape(domain) + r')</td>', r.text):
                subs.add(m.group(1).lower())
        console.print(f"  [green]{name}: {len(subs)} subdomains[/green]")
    except Exception as e:
        console.print(f"  [red]{name}: {e}[/red]")
    return subs

async def main(domain):
    console.print(f"[bold green][*] Subdomain Enumeration: {domain}[/bold green]")
    async with httpx.AsyncClient(timeout=30, follow_redirects=True, verify=False) as c:
        tasks = [enum_source(c, name, url, domain) for name, url in SOURCES.items()]
        results = await asyncio.gather(*tasks)
    all_subs = sorted(set().union(*results, {domain}))
    console.print(f"\n[bold green][+] Total unique: {len(all_subs)}[/bold green]")
    for s in all_subs: console.print(f"  {s}")
    out = Path(__file__).parent.parent / "recon_data" / f"{domain}_subdomains.json"
    out.parent.mkdir(exist_ok=True)
    with open(out,"w") as f: json.dump({"domain":domain,"count":len(all_subs),"subdomains":all_subs,"timestamp":datetime.now().isoformat()},f,indent=2)
    console.print(f"[green][+] Saved: {out}[/green]")

if __name__ == "__main__":
    if len(sys.argv) < 2: print("Usage: python subdomain_enum.py <domain>"); sys.exit(1)
    asyncio.run(main(sys.argv[1]))
