#!/usr/bin/env python3
"""
Lightweight Vulnerability Scanner — Check for common misconfigurations.
Usage: python vuln_scanner.py <url>
Requirements: pip install httpx rich
"""
import asyncio, sys, re, json
from datetime import datetime
from pathlib import Path
try:
    import httpx
except ImportError:
    print("[!] Run: pip install httpx"); sys.exit(1)
try:
    from rich.console import Console
    from rich.table import Table
    console = Console()
except ImportError:
    print("[!] Run: pip install rich"); sys.exit(1)

CHECKS = [
    ("/.env", "Environment file exposed", "CRITICAL", [r"DB_PASSWORD", r"APP_KEY", r"SECRET"]),
    ("/.git/config", "Git repository exposed", "HIGH", [r"\[core\]", r"\[remote"]),
    ("/robots.txt", "Robots.txt (recon)", "INFO", [r"Disallow"]),
    ("/sitemap.xml", "Sitemap found (recon)", "INFO", [r"<urlset", r"<sitemapindex"]),
    ("/.well-known/security.txt", "Security.txt", "INFO", [r"Contact:"]),
    ("/server-status", "Apache server-status exposed", "HIGH", [r"Apache Server Status"]),
    ("/server-info", "Apache server-info exposed", "HIGH", [r"Apache Server Information"]),
    ("/phpinfo.php", "PHP info exposed", "HIGH", [r"phpinfo()", r"PHP Version"]),
    ("/wp-json/wp/v2/users", "WordPress user enum", "MEDIUM", [r'"slug"']),
    ("/api/swagger.json", "Swagger API docs exposed", "MEDIUM", [r'"swagger"', r'"openapi"']),
    ("/api/v1/swagger.json", "Swagger v1 exposed", "MEDIUM", [r'"swagger"']),
    ("/graphql", "GraphQL endpoint", "INFO", []),
    ("/actuator", "Spring Actuator exposed", "HIGH", [r'"_links"']),
    ("/actuator/env", "Spring Actuator env", "CRITICAL", [r'"propertySources"']),
    ("/debug/pprof/", "Go pprof debug exposed", "HIGH", [r"Types of profiles"]),
    ("/.DS_Store", "macOS DS_Store exposed", "LOW", []),
    ("/crossdomain.xml", "Flash crossdomain policy", "LOW", [r"cross-domain-policy"]),
    ("/elmah.axd", "ELMAH error log exposed", "HIGH", [r"Error Log"]),
    ("/trace.axd", "ASP.NET trace exposed", "HIGH", [r"Application Trace"]),
    ("/telescope/requests", "Laravel Telescope exposed", "HIGH", [r"telescope"]),
]

async def check_endpoint(c, base_url, path, desc, severity, patterns):
    try:
        r = await c.get(f"{base_url.rstrip('/')}{path}", timeout=8)
        if r.status_code == 200:
            if not patterns:  # No pattern needed, just check 200
                return {"path": path, "desc": desc, "severity": severity, "status": 200}
            for pat in patterns:
                if re.search(pat, r.text, re.I):
                    return {"path": path, "desc": desc, "severity": severity, "status": 200}
    except:
        pass
    return None

async def main(url):
    console.print(f"[bold green][*] Vuln Scanner — Target: {url}[/bold green]\n")
    findings = []
    async with httpx.AsyncClient(verify=False, follow_redirects=True) as c:
        tasks = [check_endpoint(c, url, *check) for check in CHECKS]
        results = await asyncio.gather(*tasks)
        findings = [r for r in results if r]
    
    if findings:
        table = Table(title="Findings")
        table.add_column("Severity", style="red")
        table.add_column("Path", style="cyan")
        table.add_column("Description", style="yellow")
        sev_order = {"CRITICAL":0,"HIGH":1,"MEDIUM":2,"LOW":3,"INFO":4}
        for f in sorted(findings, key=lambda x: sev_order.get(x["severity"],5)):
            table.add_row(f["severity"], f["path"], f["desc"])
        console.print(table)
    else:
        console.print("[green][+] No common misconfigurations found[/green]")
    
    out = Path(__file__).parent.parent / "findings" / "vuln_scan.json"
    out.parent.mkdir(exist_ok=True)
    with open(out,"w") as f:
        json.dump({"url":url,"timestamp":datetime.now().isoformat(),"findings":findings},f,indent=2)
    console.print(f"\n[green][+] Saved: {out}[/green]")

if __name__ == "__main__":
    if len(sys.argv) < 2: print("Usage: python vuln_scanner.py <url>"); sys.exit(1)
    asyncio.run(main(sys.argv[1]))
