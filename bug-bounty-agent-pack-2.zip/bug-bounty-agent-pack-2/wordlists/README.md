# Wordlists for Bug Bounty Hunting

## Recommended Wordlists to Download

### Subdomain Wordlists
```bash
# SecLists (comprehensive collection)
git clone --depth 1 https://github.com/danielmiessler/SecLists.git

# Assetnote Wordlists (high quality, regularly updated)
# Download from: https://wordlists.assetnote.io/

# Best subdomain lists:
# SecLists/Discovery/DNS/subdomains-top1million-5000.txt
# SecLists/Discovery/DNS/subdomains-top1million-20000.txt
# SecLists/Discovery/DNS/subdomains-top1million-110000.txt
```

### Directory/File Wordlists
```bash
# Best directory lists:
# SecLists/Discovery/Web-Content/common.txt
# SecLists/Discovery/Web-Content/directory-list-2.3-medium.txt
# SecLists/Discovery/Web-Content/raft-large-directories.txt
# SecLists/Discovery/Web-Content/raft-large-files.txt

# Technology-specific:
# SecLists/Discovery/Web-Content/CMS/wordpress.fuzz.txt
# SecLists/Discovery/Web-Content/CMS/drupal.txt
# SecLists/Discovery/Web-Content/api/api-endpoints.txt
```

### Fuzzing Payloads
```bash
# XSS payloads:
# SecLists/Fuzzing/XSS/
# https://github.com/payloadbox/xss-payload-list

# SQL Injection:
# SecLists/Fuzzing/SQLi/
# https://github.com/payloadbox/sql-injection-payload-list

# SSTI:
# https://github.com/payloadbox/ssti-payloads

# Command Injection:
# SecLists/Fuzzing/command-injection-commix.txt
```

### Password Lists
```bash
# SecLists/Passwords/Common-Credentials/
# SecLists/Passwords/Default-Credentials/
# rockyou.txt (download separately - large file)
```

## Quick Download Commands
```bash
# Clone SecLists (most important)
git clone --depth 1 https://github.com/danielmiessler/SecLists.git

# Clone PayloadsAllTheThings
git clone --depth 1 https://github.com/swisskyrepo/PayloadsAllTheThings.git

# Clone FuzzDB
git clone --depth 1 https://github.com/fuzzdb-project/fuzzdb.git
```

## Note
These wordlists are large. Clone them into this directory or a shared location.
The agent will reference them from `./wordlists/SecLists/` paths.
