---
trigger: model_decision
description: Apply when researching a bounty program, security hypothesis, CVE, finding, or student Pentest/SOC lesson.
---

Read [root AGENTS.md](../../AGENTS.md), then [canonical SKILL.md](../../SKILL.md). Load only the reference needed for the current task.

The root file defines the user's acquisition/dependency exceptions, execution confirmation and English artifact contract. This rule supplies a discovery pointer, not broader permission. Keep the complete pack together.
