---
name: research-bug-bounty
description: Use when researching a bug bounty program, CVE candidate, security writeup, controlled experiment, reproducible finding, or related Pentest and SOC lesson in this workspace.
---

# Research Bug Bounty: Project Entry

This is a project router into the complete Bug Bounty Agent Pack 20.

1. Read [root AGENTS.md](../../../AGENTS.md).
2. Read [canonical SKILL.md](../../../SKILL.md).
3. Select the relevant reference from its routing table.
4. Read the active campaign state, scope and approval records.
5. Produce the required hypothesis, evidence, report and learning artifacts.

The pack root is three directories above this file. Resolve referenced resources relative to the file that contains each reference. Do not relocate this router alone.

Keep PACK_ROOT distinct from WORKSPACE_ROOT if the user selects a separate output workspace. Do not assume the skill directory is the campaign destination.

Public research and artifact authoring can proceed. Small portable acquisition and local dependency installs follow the user's stated exceptions. Other script/tool runs need a matching concrete grant. This instruction does not enforce network isolation.

Use [the prompt index](../../../prompts/INDEX.md) for a task-specific starting point.
