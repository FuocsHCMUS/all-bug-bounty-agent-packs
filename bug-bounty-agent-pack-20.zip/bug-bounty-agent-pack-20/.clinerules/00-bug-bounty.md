# Bug Bounty Research Entry

Read [AGENTS.md](../AGENTS.md) and [SKILL.md](../SKILL.md) in the workspace root. Use the routing table to load the relevant reference and preserve the active campaign's state.

Keep all artifacts English. The shared core defines research evidence, learning notes, workspace-local Python dependencies, portable downloads and user confirmation for other script/tool runs.

This is a short discovery rule. It does not add target scope or execution permission.
