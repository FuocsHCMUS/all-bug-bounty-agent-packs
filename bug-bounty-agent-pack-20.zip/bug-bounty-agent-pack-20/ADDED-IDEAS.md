# Expanded Ideas

The original request asked for strong research, CVE/writeup analysis, six-agent support, Windows/Python handling and beginner-friendly security notes. This pack also adds:

1. **Twenty task prompts** spanning program selection through retest and a session handoff.
2. **Twenty research lenses** that create original, falsifiable hypotheses through roles, state, representations, time and integration boundaries.
3. **An invariant catalog** to connect an exploit idea to the property the application must preserve.
4. **Evidence states** separating a lead, plausible applicability, reproduced behavior and report readiness.
5. **A CVE applicability matrix** covering editions, configurations, patch backports and reachable code.
6. **PoC source review** with data-flow and side-effect analysis before any execution.
7. **Negative controls** to distinguish a genuine issue from public resources, stale sessions, caching and ordinary behavior.
8. **An explicit approval ledger** that separates acquisition, dependency installation, execution and integration installation.
9. **A control-observation rubric** that records both strengths and gaps without rating an entire company from a sample.
10. **A SOC companion** connecting evidence to needed telemetry, competing explanations, detection logic and validation.
11. **A beginner learning engine** with intuition, causal mechanism, a bounded technical example and teach-back.
12. **Session memory files** for evidence-based continuity and cross-agent handoff.
13. **Offline utility scripts** for campaign scaffolding and measured evidence hashes.
14. **A worked synthetic case** showing a narrow API authorization finding and what its evidence does not establish.
15. **Source freshness and provenance** for platform behavior, advisories and changing standards.
16. **Regression and retest design** that checks neighboring cases and permitted success paths after remediation.
17. **AI/tool boundary analysis**, including prompt injection, capability scope and untrusted research content.
18. **A bounded research backlog** that records why ideas were rejected, parked or chosen.
19. **Optional integration planning** based on actual need rather than installing a large tool collection.
20. **Verification disclosures** separating checks performed here from native Windows and six-product testing.
