# Bug Bounty Agent Pack 20

An English research and learning workspace for **Claude Code, Codex, OpenCode, Cline, Cursor and Antigravity**, designed for Fuocs's Windows 11 / PowerShell 7 / Python 3.14.x environment.

Start with [START-HERE.md](START-HERE.md). Product discovery behavior was checked against primary documentation on **2026-11-04**; see [SOURCES.md](SOURCES.md). Read [VERIFICATION.md](VERIFICATION.md) for the exact checks and untested environments.

## What you receive

| Part | Purpose |
| --- | --- |
| [AGENTS.md](AGENTS.md) | Shared workspace behavior and the user's execution preferences |
| [SKILL.md](SKILL.md) | Research router; loads detailed references only as needed |
| [SYSTEM-PROMPT.md](SYSTEM-PROMPT.md) | Portable instruction for agents without native discovery |
| [adapters/COMPATIBILITY.md](adapters/COMPATIBILITY.md) | Exact mapping for six products and version caveats |
| [prompts/INDEX.md](prompts/INDEX.md) | Twenty ready-to-use task prompts |
| [references/](references/) | Detailed research, CVE, experiment, reporting, teaching and SOC methods |
| [templates/](templates/) | Campaign state, scope, approvals, evidence and output contracts |
| [examples/README.md](examples/README.md) | A complete synthetic authorization case from hypothesis to learning |
| [scripts/packctl.py](scripts/packctl.py) | Offline campaign initialization and evidence manifests |
| [ADDED-IDEAS.md](ADDED-IDEAS.md) | Ideas expanded beyond the original request |

This is an instruction pack with offline utilities. It is not a preinstalled scanner, autonomous exploitation service, or promise of accepted findings.

## Open the folder

Extract the archive and open **bug-bounty-agent-pack-20 itself** as the agent's workspace. Keep the complete folder together. The native skill entries refer back to the root; copying just their SKILL.md files breaks those references.

The root AGENTS.md is the canonical shared instruction. Detailed references are not automatically loaded all at once. Native rule files and skill entries are thin routers, so they can load together without six copies of the entire process.

Claude Code's current documentation supports AGENTS.md directly on v2.1.277 and later, subject to the existing CLAUDE.md files and configuration. An optional compatibility import is in [adapters/claude-code/CLAUDE.md.template](adapters/claude-code/CLAUDE.md.template). It is intentionally not installed at the workspace root by default. See the Claude adapter before adding it.

Older Antigravity installations may use singular .agent paths; the checked documentation uses .agents. Cline has its own .cline skill directory. Use the appropriate adapter; do not assume every product interprets @ imports or slash commands identically.

## First task

Paste this after opening the complete folder:

> Read AGENTS.md and SKILL.md. Use prompts/01-bootstrap.md. Check which instructions and capabilities are available without running scripts or tools. Create a public-research campaign and explain what input is needed before any target validation. Keep all files in English.

Then use [02-program-intake.md](prompts/02-program-intake.md) with one specific program URL or a brief you can access. The agent should research and draft artifacts without automatically launching a target scan.

The pack uses natural-language task prompts. Prompt filenames are not native slash commands. Invoke a skill only through syntax supported by your installed product.

## Windows and Python

You already use Python 3.14.x. Select the installed interpreter explicitly, then create .venv in the workspace after granting that setup command. Invoke .venv/Scripts/python.exe directly. The offline utility needs no third-party packages.

Additional Python libraries may be installed into that environment under your standing dependency permission. Wheels and source builds have different compatibility and execution implications. See [windows-python.md](references/windows-python.md) for exact PowerShell examples, interpreter checks and troubleshooting.

Portable download permission covers storing small tools and source repositories in tools/. Running their commands remains a separate approval. A large download, system application or integration gets a concrete proposal first.

## Research loop

Understand a user journey, identify an invariant, create a testable hypothesis, compare explanations, choose the smallest experiment, record its controls, review evidence and teach the result. Twenty research lenses help generate ideas; they are perspectives for one agent or explicitly delegated work, not a request to launch twenty agents.

A CVE candidate passes through product identification, prerequisite checks and patch/reachability analysis. A public PoC is inspected before execution. A finding carries reproducible evidence and bounded impact. Rejected and inconclusive hypotheses remain useful learning artifacts.

The pack prepares reports for you to submit. It does not automatically contact program staff, publish disclosures or test arbitrary companies.

## Campaign files

Each campaign contains campaign.json, STATE.md, SCOPE.md, APPROVALS.md, DECISIONS.md, research/, hypotheses/, experiments/, findings/, observations/, learning/ and evidence/. Use [templates/campaign.json](templates/campaign.json) as the starting schema.

Scope, approval and actual evidence are separate records. Changing a Markdown field does not grant technical permission or isolate network traffic. Enforce tool permissions and network constraints in the agent host and operating environment too.

## Reuse in another project

The simplest workflow is to keep this complete folder as the research workspace. For an existing project, copy or reference the full pack in a dedicated subfolder, merge the relevant instruction into its existing AGENTS.md, and point the entry rule at that real path. Never overwrite an existing instruction file or assume a router's relative path still works after moving it.

No personal skill, MCP server, plugin, extension or Windows application is installed by this deliverable. Install only the integrations you actually need; [integrations.md](references/integrations.md) explains how to choose them.

## Reading order

1. START-HERE.md and the adapter for your agent.
2. AGENTS.md and SKILL.md.
3. Program intake and the research loop.
4. Creative research plus the reference for the selected surface.
5. Experiment design and tool approval before execution.
6. Evidence, reporting, learning and SOC analysis.
7. Review/retest and a session checkpoint.

Keep the entry files small and put specialized detail in references. More prompt text does not by itself improve findings; better hypotheses, controls and evidence do.
