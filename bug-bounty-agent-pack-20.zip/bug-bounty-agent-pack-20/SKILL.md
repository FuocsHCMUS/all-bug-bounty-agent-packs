---
name: research-bug-bounty
description: Use when researching a bug bounty program, investigating a vulnerability hypothesis or CVE candidate, analyzing security writeups, preparing a reproducible finding, or turning assessment evidence into Pentest and SOC lessons.
---

# Research Bug Bounty

Produce evidence-backed research and a lesson the student can explain. Use [AGENTS.md](AGENTS.md) as the workspace contract.

## Route the task

| Situation | Read |
| --- | --- |
| Need networking/HTTP/identity foundations | [foundations.md](references/foundations.md) |
| New program or missing scope | [program-intake.md](references/program-intake.md) |
| Need a productive investigation loop | [research-loop.md](references/research-loop.md) |
| Need original hypotheses | [creative-research.md](references/creative-research.md) |
| CVE or product-version match | [cve-research.md](references/cve-research.md) |
| Writeup, CTF or PoC source | [writeup-analysis.md](references/writeup-analysis.md) |
| Web, identity or API reasoning | [web-and-api.md](references/web-and-api.md) |
| Cloud, mobile or AI surface | [specialized-surfaces.md](references/specialized-surfaces.md) |
| Preparing a live experiment | [experiment-design.md](references/experiment-design.md) |
| Downloading or executing tools | [tools-and-approvals.md](references/tools-and-approvals.md) |
| Need a missing MCP/plugin/capability | [integrations.md](references/integrations.md) |
| Windows or Python issue | [windows-python.md](references/windows-python.md) |
| Evidence or report | [evidence-and-reporting.md](references/evidence-and-reporting.md) |
| Explain a result to a beginner | [learning-engine.md](references/learning-engine.md) |
| Controls and company observations | [control-assessment.md](references/control-assessment.md) |
| Detection and SOC implications | [soc-and-detection.md](references/soc-and-detection.md) |
| Sessions or delegated research | [state-and-coordination.md](references/state-and-coordination.md) |
| Review, fix or retest | [review-and-retest.md](references/review-and-retest.md) |

## Working sequence

1. Name the question, exact asset, source facts and missing inputs.
2. Read the current brief and campaign state. Continue public research when testing is not yet ready.
3. Write an invariant: a condition that must remain true, such as an object belonging to one tenant remaining inaccessible to another.
4. Propose competing explanations and the smallest distinguishing experiment.
5. Obtain or reuse a matching execution grant before scripts/tools run. Portable download permission is not execution permission.
6. Capture the baseline, one changed condition, a negative control, and cleanup.
7. Classify the result: candidate, plausible, reproduced, report-ready, rejected or inconclusive. State why.
8. Write the hypothesis, finding when justified, learning note and control observation in the paths defined by AGENTS.md.
9. Update campaign state and give the user one useful next action.

## Example

An API advertises a version with an upstream advisory. Record the banner as an observation and create a candidate. Investigate product edition, reachable feature, configuration and backports before validation. A permitted synthetic-object check may establish a narrow result; it does not establish every impact claimed by a public PoC. Teach fingerprinting versus applicability versus exploitation, then record the unanswered prerequisites.

## Completion output

Give verdict, observed evidence, bounded impact, confidence, artifact links, cleanup and next decision. Draft severity only when impact is supported. Use [templates/](templates/) and [prompts/INDEX.md](prompts/INDEX.md) for exact output shapes.

Common mistakes: turning a banner into a confirmed CVE, treating a denied request as proof the whole service is secure, running a portable binary immediately after downloading, forgetting negative controls, or presenting imagined SOC logs as observed data. Correct the evidence or experiment rather than adding stronger adjectives.
