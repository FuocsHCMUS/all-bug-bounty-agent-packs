# Checked Sources and Freshness

Checked on **2026-11-04**. These are primary documentation sources used for current product discovery and foundational references. This pack's research recipes, prompts and templates are original synthesis.

| Source | Used for | Retrieval |
| --- | --- | --- |
| [Claude Code memory](https://code.claude.com/docs/en/memory) | Conditional direct AGENTS.md support and compatibility import | Read relevant AGENTS.md sections |
| [Claude Code skills](https://code.claude.com/docs/en/skills) | Native skill background; no shared .agents assumption for Claude | Opened; shared path search had no match |
| [Codex AGENTS.md](https://developers.openai.com/codex/guides/agents-md) | Discovery/overrides and instruction-size limit | Read relevant discovery section; official redirect |
| [Codex skills](https://developers.openai.com/codex/skills) | Project .agents skill discovery | Read relevant location section; official redirect |
| [OpenCode rules](https://docs.opencode.ai/docs/rules/) | Project AGENTS.md | Read |
| [OpenCode skills](https://docs.opencode.ai/docs/skills/) | Skill locations and metadata/directory matching | Read relevant sections |
| [Cline rules](https://docs.cline.bot/customization/cline-rules) | AGENTS.md and .clinerules discovery | Read |
| [Cline skills](https://docs.cline.bot/customization/skills) | .cline/skills project convention | Read relevant locations |
| [Cursor rules](https://cursor.com/docs/rules) | AGENTS.md and .mdc project rules | Read |
| [Cursor skills](https://cursor.com/docs/skills) | Shared .agents project skills | Search retrieved current official documentation |
| [Antigravity rules](https://antigravity.google/docs/rules/) | Plural .agents paths and trigger frontmatter | Read relevant sections |
| [Antigravity skills](https://antigravity.google/docs/skills/) | Shared project skills and version caveat | Read relevant locations |
| [Python venv](https://docs.python.org/3.14/library/venv.html) | Isolated, non-portable virtual environments | Read |
| [Python on Windows](https://docs.python.org/3.14/using/windows.html) | Existing interpreter and launcher/manager context | Read |
| [Python free threading](https://docs.python.org/3.14/howto/free-threading-python.html) | Build and extension-compatibility distinction | Official search result read |
| [HackerOne scope](https://docs.hackerone.com/en/articles/8495670-scope-best-practices) | Asset granularity and explicit exclusions | Read |
| [Bugcrowd brief](https://docs.bugcrowd.com/researchers/engagement-management/details/) | Current brief, targets and engagement rules | Read |
| [OWASP WSTG](https://owasp.org/www-project-web-security-testing-guide/) | Test-domain reference and versioned citation practice | Official project search content read |
| [FIRST CVSS v4.0](https://www.first.org/cvss/v4.0/specification-document) | Authoritative scoring reference | Opened; no specific score/vector asserted |

## Starting points not fully retrieved

- [CVE](https://www.cve.org/): site opened but the returned page required JavaScript; no specific record was verified.
- [NVD](https://nvd.nist.gov/): provided as a research starting point; no specific record retrieved.
- [CISA KEV](https://www.cisa.gov/known-exploited-vulnerabilities-catalog): fetch returned HTTP 403 here. Do not claim a catalog check was completed.

No specific live company's scope, vulnerability or patch status was checked during pack creation. The synthetic example has no real CVE identifier.

## Recheck rules

Recheck native discovery after agent upgrades, program policy before active sessions, advisory revisions before CVE conclusions, package support before installation, and standards/framework versions before exact mappings. A retrieved source's publication date and the date of the underlying event are different facts.

Read original sources before precise claims; do not rely on third-party mirrors where primary documentation is available. Keep source URLs, retrieval dates, relevant sections and the claim each supports. Do not invent citations or video metadata.
