# Start Here

Extract the downloaded archive first. If using PowerShell 7 in the download directory, Windows' tar command can unpack the complete folder:

~~~powershell
tar.exe -xzf .\bug-bounty-agent-pack-20.tar.gz
Set-Location .\bug-bounty-agent-pack-20
~~~

These are user-run setup instructions, not commands already executed on your computer. Keep the hidden project configuration folders when moving the pack.

## 1. Choose your agent

| Agent | Open this guide |
| --- | --- |
| Claude Code | [claude-code.md](adapters/claude-code.md) |
| Codex | [codex.md](adapters/codex.md) |
| OpenCode | [opencode.md](adapters/opencode.md) |
| Cline | [cline.md](adapters/cline.md) |
| Cursor | [cursor.md](adapters/cursor.md) |
| Antigravity | [antigravity.md](adapters/antigravity.md) |

Open the complete extracted folder, not an individual prompt file. Ask the agent to list the instruction paths it actually received. Being present on disk does not prove a file was loaded.

## 2. Bootstrap without execution

Use [prompt 01](prompts/01-bootstrap.md). The agent can prepare a campaign by writing files directly. It should not run the included Python utility until you approve that command.

If you prefer to run setup yourself, PowerShell examples are in [windows-python.md](references/windows-python.md). The utility has no runtime dependencies.

## 3. Supply one program

Use [prompt 02](prompts/02-program-intake.md) with the precise program URL or brief. Public program research is a starting point. Testing needs the current asset/method scope and a concrete execution grant.

The agent should fill SCOPE.md, mark unknowns and propose a small first investigation. It should never treat all of HackerOne or Bugcrowd as a test target.

## 4. Research before experiments

Use [prompt 04](prompts/04-hypothesis-sprint.md) for original ideas, [prompt 05](prompts/05-cve-triage.md) for a CVE candidate, or [prompt 06](prompts/06-writeup-to-hypothesis.md) for a writeup.

Expect an invariant, prerequisites, alternative explanation, distinguishing test and evidence plan. Ask the agent to explain unfamiliar words before moving to advanced variations.

## 5. Approve a concrete command

Use [prompt 11](prompts/11-experiment-plan.md). A good approval request includes the exact command, its working directory and interpreter, the specific hosts/files it touches, budget and cleanup.

You may grant a bounded family of actions for a session. The agent records that decision and reuses it without repeatedly asking for unchanged actions. Acquiring a portable tool does not grant its execution.

## 6. Read the findings and lessons

A confirmed result gets a report draft. Every meaningful result, including a control holding or a hypothesis failing, gets a learning note. Read the hypothesis alongside the evidence; the report must not claim more than the experiment supports.

The worked example is synthetic and has not been run against any company. Start at [examples/README.md](examples/README.md) to see the expected artifact structure.

## 7. End with a checkpoint

Use [prompt 20](prompts/20-session-checkpoint.md). Save completed work, negative results, remaining questions, permissions and one next step. This allows a new session or different agent to continue without inventing history.
