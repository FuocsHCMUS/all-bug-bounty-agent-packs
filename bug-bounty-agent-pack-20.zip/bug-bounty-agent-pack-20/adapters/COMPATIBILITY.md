# Agent Compatibility

Checked primary documentation on **2026-11-04**. “Documented” means discovery was verified in docs; it does not mean this pack was executed inside that product.

| Product | Shared instructions | Native project material shipped | Important check |
| --- | --- | --- | --- |
| Claude Code | Root AGENTS.md on supported releases/configurations | Optional CLAUDE.md compatibility template | Verify actual loaded instructions |
| Codex | Root AGENTS.md | .agents/skills/research-bug-bounty/SKILL.md | More local/override instructions can affect behavior |
| OpenCode | Root AGENTS.md | Shared .agents skill | Avoid duplicate same-name skill copies |
| Cline | Root AGENTS.md and .clinerules/ | .clinerules/00-bug-bounty.md | Check enabled rules in the UI |
| Cursor | Root AGENTS.md | .cursor/rules/bug-bounty-research.mdc and shared .agents skill | Rules and skills have different activation |
| Antigravity | Root AGENTS.md | .agents/rules/ and shared .agents skill | Current docs use plural .agents; older installs may differ |

The native skill file is a router into the complete extracted pack. Root SKILL.md is the canonical reference, not an independently movable skill folder. Do not copy a router by itself or rename its directory without updating metadata and links.

## Setup validation prompt

“List the project instruction paths you actually received. Read AGENTS.md and SKILL.md. Explain the execution-confirmation rule, portable/dependency exceptions, output location and one required research artifact. Do not run commands.”

If an agent cannot read the references, fix discovery/path configuration before relying on it. File presence alone does not demonstrate loading or enforcement.

Never overwrite existing rules, settings or AGENTS.md when merging this pack into another project. Keep permission controls in the host and use the approval ledger for the user's decisions.

The twenty prompt files are not universal native commands. No external plugin/MCP installation is required to read and use them.
