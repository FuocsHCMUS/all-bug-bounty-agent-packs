# Antigravity

Open the complete folder. Current checked docs support root AGENTS.md and plural .agents/rules/ plus .agents/skills/. The shipped rule uses valid trigger: model_decision metadata and routes to the core.

Inspect active customizations, then use the bootstrap prompt. Older installations may use singular .agent paths; check their actual docs/version before moving files. Do not install duplicate copies speculatively.

Set the selected Python interpreter to the workspace .venv/Scripts/python.exe after that environment exists. Direct interpreter invocation avoids needing activation-policy changes.

Artifact review, terminal execution and browser permissions remain separate host settings. The pack does not silently modify them or install MCP/plugins/skills.

Primary references: [rules](https://antigravity.google/docs/rules/), [skills](https://antigravity.google/docs/skills/).
