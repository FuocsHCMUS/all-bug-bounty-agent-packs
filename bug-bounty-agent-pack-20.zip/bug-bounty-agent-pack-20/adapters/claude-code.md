# Claude Code

Open the complete pack folder and use the bootstrap prompt.

The checked documentation supports direct AGENTS.md reading on v2.1.277+, with configuration and existing CLAUDE.md/CLAUDE.local.md files affecting loading. Inspect /memory and the installed version rather than assuming discovery succeeded.

If a session needs the fallback, create a root CLAUDE.md containing:

~~~text
@AGENTS.md
~~~

The optional [compatibility template](claude-code/CLAUDE.md.template) shows this. Place it next to root AGENTS.md, not inside this adapters folder. Merge carefully if a CLAUDE.md already exists.

The pack uses AGENTS.md to route to root SKILL.md; it does not require a separately installed Claude skill. A native Claude skill can be added later through the user's chosen installation process with the full resources available.

Do not broaden command permissions or add hooks just to make the pack load.

Primary references: [memory](https://code.claude.com/docs/en/memory), [skills](https://code.claude.com/docs/en/skills).
