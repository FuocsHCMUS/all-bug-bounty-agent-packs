# Cline

Open the complete folder and inspect the Rules panel. Cline documents AGENTS.md and workspace .clinerules/. The shipped [00-bug-bounty.md](../.clinerules/00-bug-bounty.md) routes into the same shared core; it does not duplicate the detailed workflow.

Enable the relevant rule, then use prompts/01-bootstrap.md. Verify the actual instruction paths and output workspace. Keep command execution under confirmation unless a concrete campaign grant applies.

Cline's native project skills use .cline/skills/; they are not automatically installed by the shared .agents entry in this pack. The root instructions already let Cline use all references and templates. Add a native skill through the user's chosen Skills workflow only if useful, with the full pack paths preserved.

Do not enable broad auto-approval for terminals or browser target activity simply because a tool is portable.

Primary references: [rules](https://docs.cline.bot/customization/cline-rules), [skills](https://docs.cline.bot/customization/skills).
