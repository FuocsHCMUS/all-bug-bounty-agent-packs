# Codex

Open the complete pack as the project. Root AGENTS.md supplies the shared behavior. The native entry at [.agents/skills/research-bug-bounty/SKILL.md](../.agents/skills/research-bug-bounty/SKILL.md) points to the complete local reference.

Use the setup validation prompt in COMPATIBILITY.md. If the native skill appears, select it or ask for it using your installed Codex surface. Otherwise, explicitly ask Codex to read root SKILL.md; the research documents remain usable.

Codex's documented instruction discovery merges instructions along the project path and recognizes override files. More specific instructions can affect the session. The documented default combined project instruction cap is 32 KiB, another reason to keep entry instructions small.

Do not change global config.toml or turn off command approvals to use this pack. Read the current campaign and concrete grants before running scripts.

This project entry is not an installation into ChatGPT's personal Skills directory.

Primary references: [AGENTS.md](https://developers.openai.com/codex/guides/agents-md), [skills](https://developers.openai.com/codex/skills).
