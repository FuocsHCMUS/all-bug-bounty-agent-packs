# Cursor

Open the complete folder. Cursor documents root AGENTS.md, project .cursor/rules/*.mdc and skills in .agents/skills/.

The shipped .mdc rule is a short, task-relevant router. Its alwaysApply value is false because root AGENTS.md already carries the standing workspace behavior. A plain .md file inside .cursor/rules is not the equivalent native project rule.

Use the bootstrap prompt, inspect applicable rules and verify the agent reads root SKILL.md and the selected reference. Do not assume a visible skill/rule means its commands have execution permission.

If copying the pack into an existing repository, merge instruction content and fix relative references; do not overwrite the repository's rules. Keep the full pack available.

Primary references: [rules](https://cursor.com/docs/rules), [skills](https://cursor.com/docs/skills).
