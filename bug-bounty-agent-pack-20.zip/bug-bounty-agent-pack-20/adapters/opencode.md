# OpenCode

Open the complete pack folder. Root AGENTS.md supplies shared instructions; the shared .agents skill is a documented project skill location.

The pack does not need a custom agent, opencode.json, external plugin or auto-executing hook. Keep existing provider and tool settings.

Ask OpenCode to read AGENTS.md and SKILL.md, then use the task prompts. If a skill is not discovered, check project location, name/directory match and the installed product's current docs. Avoid installing another same-name copy into .opencode or .claude while leaving the shared copy active.

Natural-language references in instructions should be explicitly opened by the agent; do not assume every @ token acts as an import.

Primary references: [rules](https://docs.opencode.ai/docs/rules/), [skills](https://docs.opencode.ai/docs/skills/).
