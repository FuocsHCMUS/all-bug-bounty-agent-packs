# Implementation Plan

**Goal:** Deliver the complete English pack, ready to open in six coding agents.
**Architecture:** Shared core, references, twenty prompts, output templates, thin native adapters.
**Tech stack:** Markdown, JSON, Python standard library, PowerShell examples.
**Spec:** [DESIGN.md](DESIGN.md).

## Tasks

- [x] Verify platform discovery with primary documentation.
- [x] Capture a baseline response to a synthetic research task.
- [x] Author core instructions, research references and twenty prompts.
- [x] Add native adapters, evidence templates and worked examples.
- [x] Write meaningful utility tests, observe missing behavior, implement, run the suite.
- [x] Forward-test with independent agents; fix material issues.
- [x] Check local references and structured files; generate and verify the packaged folder. Persistence is confirmed by the final delivery result.

## Review focus

Download permission versus execution permission; banner matches versus verified applicability; scoped observations versus company-wide claims; native discovery differences; campaign overwrite and path escape; fabricated evidence; ambiguous synthetic examples.

## Execution decisions

The detailed user request authorizes creation of this reversible deliverable. Continue without a separate approval round. Do not conduct a live bounty hunt, install integrations, or contact a company while building the pack.
