# Design

Build an English research and learning workspace for Fuocs, a student developing networking, Pentest and SOC skills. The folder name is `bug-bounty-agent-pack-20`.

Use one shared process with detailed references loaded on demand. Six native adapters provide instruction discovery; twenty task prompts make common work repeatable. A monolithic prompt would waste context; independent per-product workflows would drift. This modular approach is the author's implementation choice under the user's detailed creation request.

Windows 11, PowerShell 7 and Python 3.14.x are the user's baseline. Packages belong in a project-local `.venv`. Small portable downloads and local dependency installs are preauthorized; running downloaded code is a separate decision. Other script/tool execution needs a concrete user grant. MCP, plugin and skill installation remains a user decision.

Research may proceed independently. Live validation needs the current program brief, an applicable asset and method, and execution permission. Reports are prepared for the user to submit. Every outcome produces evidence-linked lessons, including controls that held and unknowns.

The executable utility performs only offline campaign initialization and streaming evidence hashing. It does not probe systems or enforce network permissions.

Acceptance: all links resolve, JSON parses, skill metadata is well formed, the complete offline suite passes, synthetic examples are labelled, and product discovery claims have primary sources. Behavioral checks use fresh agents with synthetic tasks. Native Windows/product execution must not be claimed without evidence.

This folder is a distributable project pack. No personal ChatGPT skill, integration or Windows setting is installed during its creation.
