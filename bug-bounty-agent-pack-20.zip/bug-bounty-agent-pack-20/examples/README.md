# Worked Synthetic Case

**SYNTHETIC — NOT EXECUTED.** Every identity, hostname, response and business object in this example is invented for teaching. No company was tested, no real CVE is asserted and no live finding is confirmed.

Follow this sequence:

1. [SCOPE.md](SCOPE.md): a fictional fixture's permissions and controlled data.
2. [H-001.md](H-001.md): a falsifiable authorization hypothesis.
3. [X-001.md](X-001.md): the proposed comparison and controls.
4. [E-001.md](E-001.md): explicitly fabricated teaching responses.
5. [F-001.md](F-001.md): how a report would describe this behavior if real evidence established it.
6. [L-001.md](L-001.md): a beginner lesson.
7. [O-001.md](O-001.md): narrow control strengths/gaps and unknowns.
8. [SOC.md](SOC.md): telemetry needed to investigate the behavior.

This example shows artifact relationships. It is not authorization, a runnable exploit or a record of collected target data. Use actual campaign evidence for a real report.
