# Synthetic Fixture Scope

**SYNTHETIC — NOT EXECUTED.**

The fictional application is Invoice Classroom at api.training.invalid. This is a reserved invalid example name and should not be contacted.

The teaching model has owned accounts A and B, each a member of a different synthetic tenant. A owns inv-a. B owns inv-b with canary text CLASSROOM_B_INVOICE. Both invoices are private with no sharing relationship.

The model's policy requires that members read only their own tenant's private invoices. A documented administrator workflow is outside this particular scenario.

No actual program brief exists here. These fictional fixture assumptions must never be copied into a real campaign as program permission.

Proposed model operations: normal owned read, forbidden cross-tenant read, alternate download path, and unauthenticated download. There are no real traffic budgets or execution grants in this example.
