# SOC Companion for the Synthetic Case

**SYNTHETIC DESIGN — NOT EXECUTED.** No internal logs or alerts were accessed.

## Behavior and alternatives

The invented model has A receiving B's canary through a download operation. Possible real-world explanations would include a missing authorization decision, intended sharing, a service/admin relationship or misidentified session state.

## Required telemetry

A trustworthy application event would ideally preserve effective actor, tenant, object owner, action, policy decision and request/job correlation context. Identity logs alone may show that A logged in but not whether A could read inv-b.

These are proposed fields, not verified field names in any product.

## Detection concept

~~~text
PSEUDOCODE — NOT EXECUTED
for each invoice-serving decision:
    resolve actor and intended access relationship
    resolve object privacy, owner and allowed sharing
    identify allowed actions that conflict with the resolved policy
    retain the real correlation identifier when available
~~~

A real implementation must use the application's actual policy semantics. Comparing tenant strings alone can misclassify legitimate sharing or service workflows.

## Validation cases

Synthetic A-own allowed: no violation. A-to-B-private allowed: violation in this model. Intended shared access: no violation. Missing owner context: visibility gap rather than automatic proof of safety.

False positives can come from legitimate delegated service access. False negatives can come from missing worker/download logs or incomplete ownership context.

No visible alert tells us nothing here because no real detection was run. Prevention, logging, alerting and human response remain separate questions.
