# Bootstrap the Research Workspace

Read AGENTS.md, SKILL.md and references/tools-and-approvals.md. Establish PACK_ROOT and WORKSPACE_ROOT. Do not execute scripts or tool commands during this bootstrap; use available file-reading and editing capabilities.

Inventory capabilities you actually have: public search, local reads/writes, browser inspection, approved terminal execution and source-host access. Mark unavailable capabilities honestly. Do not install integrations.

Create a public-research campaign from templates/campaign.json, STATE.md, SCOPE.md, APPROVALS.md and DECISIONS.md. Use a clear proposed slug if the user has not named one. Keep all artifacts English.

Deliver the actual paths, the instruction files you read, the current mode and the smallest missing input needed to research one program. Explain the download/dependency exceptions and execution confirmation in a few plain sentences. Do not invent a live scope, grant, target result or finding.
