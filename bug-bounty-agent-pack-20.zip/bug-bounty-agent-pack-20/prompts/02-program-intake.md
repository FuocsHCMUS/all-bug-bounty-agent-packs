# Read One Program Brief

Input: one specific official program URL or supplied current brief.

Read references/program-intake.md. Locate the authoritative brief and relevant linked restrictions. Save the retrieved time, exact source URL and a local snapshot or clearly attributed summary.

Fill SCOPE.md and campaign.json with permitted assets, explicit exclusions, methods, automation policy, rate/budget requirements, accounts, data constraints and reporting expectations. Keep unknowns as unknowns. Explain any ambiguous wildcard, redirect or third-party boundary.

Recommend one reachable user journey and two initial research questions. Continue public research independently. Do not run target probes or tools while preparing intake. Deliver the scope mapping, blockers that change a concrete decision and one bounded next step.
