# Map a User Journey and Trust Boundaries

Input: a campaign, a permitted product surface and available docs or supplied traces.

Read references/research-loop.md and references/foundations.md as needed. Model the normal user journey before identifying weaknesses. Describe principal, object, action, tenant, state, authorization decision and downstream effects.

Separate observed components from inferred components. Map API, browser, worker, cache, storage and integration boundaries only where relevant. Use a compact diagram for meaningful branching and a table for exact role/object relationships.

Write research/surface-map.md with evidence links, unknowns and three high-information questions. Explain the first three essential terms for a beginner. Propose experiments only; do not execute new tools or target traffic without an applicable grant.
