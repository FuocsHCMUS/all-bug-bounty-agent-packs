# Generate Creative, Falsifiable Hypotheses

Input: a surface map and current campaign evidence.

Read references/creative-research.md. Select the research lenses that fit this surface. Generate eight distinct hypotheses, then rank and select the best three by evidence fit, potential bounded impact, information gain, prerequisites and cost.

For each selected idea create an H-### card with an invariant, precise precondition, causal failure theory, strongest normal alternative, minimum distinguishing experiment, positive/negative controls, rejection signal and next evidence need.

Include at least one state/lifecycle idea and one trust-boundary idea when the surface supports them. Do not manufacture novelty or add unsupported chain edges. Save rejected ideas with reasons. Research and design are authorized; execution requires the campaign's normal checks.
