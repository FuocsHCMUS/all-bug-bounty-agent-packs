# Extract a Writeup's Mechanism

Input: an original writeup, advisory, CTF article or supplied exploit source.

Read references/writeup-analysis.md. Record provenance, date, product/version and whether the environment is synthetic or production. Extract the invariant, trust boundary, attacker-controlled input, prerequisites, root cause, evidence, impact and fix.

Explain which CTF conveniences or deployment assumptions would not transfer. If code is linked, inspect dependencies, entrypoint, default actions, external destinations, subprocesses and data extraction without running it.

Write a source card and up to three new hypotheses grounded in the current scoped architecture. Each needs independent prerequisites, a rejection condition and minimal controlled evidence. Do not copy the original target's impact as if it were demonstrated here. Add a beginner explanation of the mechanism.
