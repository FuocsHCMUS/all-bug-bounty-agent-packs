# Investigate Authorization With Owned Accounts

Input: accounts A/B, documented roles/tenants, controlled synthetic objects and a scoped workflow.

Read references/web-and-api.md. Build a principal × action × object × tenant × state matrix. Establish privacy, sharing rules and legitimate administrative relationships before interpreting access.

Prepare normal permitted, forbidden and alternative-path cases. Keep session, cache and object state differences explicit. Explain authentication, authorization and ownership separately.

Create hypothesis and experiment cards for the most informative comparison. Do not enumerate other people's records. Obtain or reuse the exact execution grant before running any requests. Report actual versus expected behavior, bounded coverage and a learning note; a 200 status alone does not confirm an authorization flaw.
