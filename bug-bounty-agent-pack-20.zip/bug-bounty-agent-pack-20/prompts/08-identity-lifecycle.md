# Investigate Sessions and Identity Transitions

Input: a documented login/session workflow and owned accounts.

Read references/web-and-api.md. Map authentication, session/token context, role/tenant membership, expiry, revocation and sensitive actions. State the intended invariant at each transition.

Consider logout, membership removal, password change and asynchronous artifacts, selecting only transitions relevant to the product's documented expectations. Do not assume every persistent session is a flaw.

Create two falsifiable hypotheses, including a competing intended behavior. Design controlled before/after cases, semantic evidence, cleanup and a bounded execution proposal. If analyzing OAuth/OIDC, specify issuer/client/redirect/code/token/audience bindings rather than using a generic account-takeover label.

Write a lesson showing why a valid identity or signature does not establish every permission.
