# Analyze Business State and Async Work

Input: a scoped workflow such as export, invitation, approval, sharing or integration setup.

Write the normal state machine and the invariant for each permitted transition. Identify authoritative state, initiating identity, worker identity, retries, idempotency and revocation expectations.

Use references/creative-research.md and experiment-design.md to propose three specific failure theories. Investigate timing and concurrency with a deterministic local model first. Do not stress a live service to explore a theoretical race.

For each theory specify the minimum discriminating test, controls, request/state budget and cleanup. Label unexecuted results. Explain which production trade-off might create the failure and which regression test would protect the invariant.
