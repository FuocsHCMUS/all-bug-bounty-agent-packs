# Review a Tool or PoC Before Running

Input: a source repository, release archive or local script.

Read references/tools-and-approvals.md and writeup-analysis.md. Record official upstream, pinned version/commit, footprint, destination and available integrity evidence. Small portable acquisition into workspace/tools is allowed; it does not authorize execution.

Trace entrypoint, defaults, dependencies, subprocesses, filesystem writes, network destinations, callbacks, data collection and cleanup. Check whether a detect/check option performs exploitation or extraction.

Write a side-effect table and identify the smallest relevant mechanism. Prefer a local controlled reproduction if the original tool is unnecessarily broad. If execution is useful, prepare templates/tool-proposal.md with the exact command and effects; ask one concrete confirmation question unless a matching grant already exists.
