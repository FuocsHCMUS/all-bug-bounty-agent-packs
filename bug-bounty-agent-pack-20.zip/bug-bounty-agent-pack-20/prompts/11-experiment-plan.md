# Prepare One Reviewable Experiment

Input: one hypothesis with enough prerequisites to design a test.

Read references/experiment-design.md and the scope/approval records. Use templates/experiment.md to create experiments/X-###.md in the active campaign. Preserve the template. Specify exact environment, owned identities, synthetic object, command, working directory, interpreter, target path, network behavior, budget, controls, stop conditions and cleanup.

Write a script first if needed, but do not execute it yet. Explain how the outcome will distinguish the hypothesis from its strongest alternative. Avoid requests that collect more data than the claim needs.

Show the complete concrete action for the user to review. Reuse an existing grant only when it matches the current source, behavior, target, budget and expiry. Continue independent source research while execution remains pending.
