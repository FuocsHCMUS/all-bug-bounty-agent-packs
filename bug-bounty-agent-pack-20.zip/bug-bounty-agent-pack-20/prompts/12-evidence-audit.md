# Audit Evidence and Challenge the Claim

Input: a hypothesis, experiment result and actual evidence files or supplied excerpts.

Read references/evidence-and-reporting.md and review-and-retest.md. Build a claim-to-evidence matrix. Verify account/object context, expected privacy, semantic output, controls, reproducibility and any unproven chain edges.

Distinguish observed, supplied, synthetic and expected evidence. Do not create missing logs or hashes. If a hash manifest would help, prepare or reuse a concrete grant for the offline utility.

Return the strongest defensible verdict, claims that must be narrowed, remaining alternative explanations and one next discriminating action. Separate confidence from severity. Update artifact states only when the evidence supports the transition.
