# Write a Reproducible Finding Draft

Input: reproduced behavior, controls, scoped asset and minimized evidence.

Use templates/finding.md. Lead with the concrete principal/action/object/path and the invariant violated. Give prerequisites and steps a triager can follow without reading this conversation.

Separate observed impact from potential impact that requires additional assumptions. Include actual evidence references, environment, expected/actual behavior, severity model and rationale, confidence, remediation and a bounded retest plan.

Check for public-sharing explanations, misleading status codes and unsupported chain claims. Remove secrets and unrelated records. Clearly label any synthetic explanatory material.

Save the report draft and a short submission handoff for the user. Do not submit it, message the company or publish details automatically.
