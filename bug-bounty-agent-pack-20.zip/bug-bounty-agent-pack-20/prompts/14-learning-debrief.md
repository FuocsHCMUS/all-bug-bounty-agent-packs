# Teach This Result From First Principles

Input: one finding, rejected hypothesis or control that held.

Read references/learning-engine.md. Create an L-### note with one main concept and at most two supporting concepts. Begin with the original business problem and define essential terms.

Explain intuition, its limits, causal mechanism, observed evidence, what the evidence does not prove, an alternative explanation and the relevant defensive view. Use a small diagram or comparison table only when it clarifies the mechanism.

Add a production trade-off, proposed owner role, a regression check and one beginner misconception. Finish with one to three teach-back questions. In interactive teaching, wait for the learner's answers; in batch artifact work, save the questions and continue independent research.
