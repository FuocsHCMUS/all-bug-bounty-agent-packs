# Assess Strengths, Gaps and Unknowns

Input: the campaign's actual evidence and tested coverage.

Read references/control-assessment.md. Write an O-### record for each meaningful strength, demonstrated gap or unresolved potential risk. State exact surface, conditions, time, evidence and confidence.

Keep observation, inference and unknown separate. Use the categories demonstrated for this case, gap demonstrated for this case, potential risk, unknown or not evaluated. Do not produce a company-wide maturity score.

For improvements, identify the control objective, proposed owner role, operational trade-off, evidence of completion, regression case and residual uncertainty. Explain relevant security activities for the student without pretending to know the company's internal process.
