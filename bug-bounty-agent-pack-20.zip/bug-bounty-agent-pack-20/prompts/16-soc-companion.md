# Connect the Behavior to Detection and Investigation

Input: one hypothesis/finding and available telemetry, if any.

Read references/soc-and-detection.md. Use templates/soc-companion.md to create research/SOC-H-###.md or research/SOC-F-###.md in the active campaign, preserving the template. Describe principal, object, action, time, state and result, marking which fields were observed.

Give at least two plausible explanations. Identify needed application, identity, worker and network evidence and explain each source's limitations. Separate event time from ingestion time.

Use exact query syntax only when product and schema are verified. Otherwise write labelled pseudocode with required fields. Include synthetic permitted/violation/exception/missing-data validation cases, false positives and false negatives.

Do not claim no logging or SOC failure because a test was allowed or no visible response occurred. Save next evidence requests and a bounded handoff.
