# Design the Fix and Verify Its Invariant

Input: a finding, proposed fix and any deployment information.

Read references/review-and-retest.md. Explain the invariant the permanent fix restores and distinguish temporary mitigation. Identify proposed owner role, compatibility/performance trade-off, rollout and rollback considerations.

Use templates/retest.md to create experiments/RT-F-###.md in the active campaign, preserving the template. Include the original forbidden case, legitimate success path, neighboring roles/objects and relevant alternate/async paths. Use synthetic data. Confirm current scope and execution grant before any actual retest.

Report fixed, partially fixed, inconclusive, regression or not retested according to actual results. Do not claim a company deployed the fix unless evidence establishes that. Update the lesson with what changed and what remains outside coverage.
