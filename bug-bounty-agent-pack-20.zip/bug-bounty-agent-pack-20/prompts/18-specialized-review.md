# Review a Cloud, Mobile or AI Surface

Input: one precisely scoped specialized surface and available artifacts.

Read references/specialized-surfaces.md. Choose one primary perspective. For cloud, identify the exact provider/principal/resource/policy context. For mobile, separate on-device logic from server enforcement. For AI, separate model output, broker authorization, tool invocation and actual side effect.

Map trust boundaries and the relevant invariant. Record third-party exclusions and unknown permissions. Review supplied source/configuration before proposing tools.

Create two grounded hypotheses, minimal local fixtures where appropriate, a controlled evidence plan and a beginner lesson. Do not silently install a runtime/integration or expand web scope to a cloud account, mobile vendor or third-party tool service.
