# Propose the Smallest Missing Capability

Input: the current task and a capability the agent cannot perform.

Read references/integrations.md. Inventory existing connectors and local capabilities first. Continue useful research and authoring that do not depend on the missing capability.

If a new MCP server, plugin, skill, extension, application or runtime is needed, prepare a concrete proposal: official source, pinned version where possible, purpose, minimum permissions, reviewed configuration with secret placeholders, local path, data exposed, network effects, expected cost/footprint, removal and a first bounded verification action.

Ask the user to install or enable it. Do not use portable-download permission to install an integration. Never request tokens/passwords in chat. State exactly which task remains blocked and which work can proceed.
