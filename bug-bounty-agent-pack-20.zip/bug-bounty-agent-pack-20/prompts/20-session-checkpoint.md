# Save an Evidence-Based Handoff

Input: the active campaign and work completed this session.

Read references/state-and-coordination.md. Update STATE.md, DECISIONS.md and any changed artifact states. Record actual commands/results, source versions, evidence IDs, permission grants/expiry, consumed budgets, rejected hypotheses, unresolved assumptions and cleanup.

Link the hypothesis, experiment, finding, lesson and observation files that actually exist. Label proposed files as unsaved. Check scope freshness and account/tool state needs for the next session.

Give a concise handoff: current verdict, observed evidence, bounded impact if any, confidence, artifacts, remaining unknowns and one next action. Do not claim a live test, report submission, fix deployment or detection execution that did not happen. Preserve enough detail for a different agent to resume without repeating completed experiments.
