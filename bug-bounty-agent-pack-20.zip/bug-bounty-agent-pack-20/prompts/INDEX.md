# Twenty Task Prompts

These are natural-language prompts, not universal slash commands. Open a file and paste its task into the agent after the shared workspace instructions load. Supply actual inputs instead of inventing targets or results.

| No. | Prompt | Main output |
| --- | --- | --- |
| 01 | [Bootstrap the Research Workspace](01-bootstrap.md) | Campaign and capability inventory |
| 02 | [Read One Program Brief](02-program-intake.md) | Scope and current brief |
| 03 | [Map a User Journey and Trust Boundaries](03-surface-map.md) | User journey and boundaries |
| 04 | [Generate Creative, Falsifiable Hypotheses](04-hypothesis-sprint.md) | Hypothesis backlog |
| 05 | [Assess a CVE Candidate](05-cve-triage.md) | CVE applicability matrix |
| 06 | [Extract a Writeup's Mechanism](06-writeup-to-hypothesis.md) | Mechanism card and transfers |
| 07 | [Investigate Authorization With Owned Accounts](07-authorization-matrix.md) | Role/object decision matrix |
| 08 | [Investigate Sessions and Identity Transitions](08-identity-lifecycle.md) | Lifecycle hypotheses |
| 09 | [Analyze Business State and Async Work](09-state-and-business-logic.md) | State model and experiments |
| 10 | [Review a Tool or PoC Before Running](10-poc-source-review.md) | Side-effect inventory |
| 11 | [Prepare One Reviewable Experiment](11-experiment-plan.md) | Concrete experiment for review |
| 12 | [Audit Evidence and Challenge the Claim](12-evidence-audit.md) | Claim-to-evidence audit |
| 13 | [Write a Reproducible Finding Draft](13-report-draft.md) | Finding draft |
| 14 | [Teach This Result From First Principles](14-learning-debrief.md) | Learning note |
| 15 | [Assess Strengths, Gaps and Unknowns](15-control-observations.md) | Control observations |
| 16 | [Connect the Behavior to Detection and Investigation](16-soc-companion.md) | SOC companion |
| 17 | [Design the Fix and Verify Its Invariant](17-remediation-and-retest.md) | Fix/retest matrix |
| 18 | [Review a Cloud, Mobile or AI Surface](18-specialized-review.md) | Specialized hypotheses |
| 19 | [Propose the Smallest Missing Capability](19-integration-proposal.md) | Integration proposal |
| 20 | [Save an Evidence-Based Handoff](20-session-checkpoint.md) | State and next action |
