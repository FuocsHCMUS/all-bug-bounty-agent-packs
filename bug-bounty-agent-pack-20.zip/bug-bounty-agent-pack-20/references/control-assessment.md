# Assess Controls Without Overclaiming

## Contents

Observation model; confidence; narrow strengths; gaps; improvement plan.

A bounty assessment samples a limited surface. It does not expose an entire company's security program, internal architecture, SOC processes or patch governance. Write what your evidence supports.

## Observation model

For each observation, record the business action, control objective, exact tested condition, date, evidence ID, result, coverage, confidence and unknowns. Use one of these states:

- **Demonstrated for this case:** the observed action preserved the invariant.
- **Gap demonstrated for this case:** controlled evidence shows a specific failure.
- **Potential risk:** a prerequisite or architectural concern warrants further investigation.
- **Unknown:** the available view does not support a conclusion.
- **Not evaluated:** the campaign did not assess this area.

“Not observed” is not equivalent to “not implemented.”

## Strengths

A control that denied an invalid action is worth teaching. Explain the invariant it preserved, where the decision appears to occur, and what the experiment actually covered.

Do not infer the precise backend implementation from a denied request alone. Several components might have produced the result. Additional telemetry or source evidence is needed to attribute it.

Example: “Owned member A could not download B's private synthetic attachment through path P under state S.” This supports a narrow strength. “The company has excellent access control” exceeds the sample.

## Weaknesses and risk

Separate observed gap from possible consequences. Explain the boundary crossed, required permissions, affected objects/actions and what remains unknown.

A severity recommendation should identify relevant business context. Avoid calling a company “high risk” globally because one endpoint failed. Likewise, no findings in a time-boxed session does not establish low risk.

For each material gap, write prevention, detection, remediation ownership, verification and residual uncertainty. Be specific: server-side ownership enforcement at the download path is clearer than “improve security.”

## Security activities worth learning

Connect relevant observations to:

- Asset inventory and component/version tracking.
- Identity lifecycle and access review.
- Secure design and centralized authorization.
- Input/output handling at interpretation boundaries.
- Patch/backport validation and release management.
- Dependency provenance and artifact integrity.
- Logging, alerting, investigation and retention.
- Change management, regression checks and rollback.
- Vulnerability intake, triage, remediation and retest.

Mark each activity as observed, suggested or unknown. Public behavior seldom demonstrates how the organization runs these processes internally.

## Improvement plan

Write a concise action card: control objective, proposed fix, owner role, evidence of completion, deployment trade-off, regression test and remaining risk. Owner roles are suggestions unless the program identifies actual owners.

Explain operational costs: authorization consistency versus caching, detailed telemetry versus data volume/privacy, revocation freshness versus availability, or central policy versus service autonomy. Avoid presenting a single best practice as universally optimal.

Use [control-observation.md](../templates/control-observation.md). This gives the student useful enterprise reasoning while keeping claims tied to real coverage.
