# Creative Research Through Invariants

## Contents

Reasoning recipe; twenty lenses; composition; prioritization.

Creativity means generating a surprising, testable explanation from the system's assumptions. It is not equivalent to more payloads, stronger adjectives or unrestricted execution.

## Reasoning recipe

1. Name a valuable action and the invariant protecting it.
2. Identify where components disagree about identity, object, state, representation or time.
3. Construct the smallest counterexample using controlled data.
4. State a competing normal explanation.
5. Predict distinguishing evidence and a negative control.
6. Test only the supported, approved branch.
7. Generalize the root cause after evidence exists.

Keep observation and invention distinct. A useful analogy can inspire a hypothesis, but it cannot supply missing evidence.

## Twenty research lenses

| Lens | Question that creates a hypothesis | Candidate discriminator |
| --- | --- | --- |
| 1. Identity | Does every step bind the same authenticated principal? | Compare owned identities across the workflow |
| 2. Role | Is the action evaluated under the current role? | Equivalent permitted and denied role cases |
| 3. Tenant | Can a resource reference cross an organization boundary? | Synthetic resources in two owned tenants |
| 4. Ownership | Is access based on owning the object or knowing its identifier? | Known private object versus intentionally public object |
| 5. Lifecycle | Does revocation reach old sessions, links and jobs? | Before/after a controlled state transition |
| 6. Time | Are expiry and freshness evaluated consistently? | Documented boundary times in a local model |
| 7. Representation | Do parsers interpret equivalent inputs differently? | A minimal representation pair in a local harness |
| 8. Canonicalization | Is a decision made before normalization changes meaning? | Trace validation and use of a harmless sentinel |
| 9. Alternate client | Does another official client reach a different decision path? | Same owned action with equivalent credentials |
| 10. Async work | Does a background worker recheck the relevant authority? | Job creation, role change and controlled completion |
| 11. Cache | Does cache identity include the context required by the object? | Compare controlled cache entries without shared-user effects |
| 12. Integration | Does trust survive an unverified downstream assertion? | Inspect documented contracts and synthetic fixtures |
| 13. Failure path | Does an error or timeout change authorization semantics? | Local failure simulation rather than live disruption |
| 14. Retry | Does repeating an operation violate an intended invariant? | Small deterministic local model with rollback |
| 15. Data provenance | Can untrusted metadata become a trusted decision? | Trace where a field was created and checked |
| 16. Resource binding | Is a token/link bound to the intended action and object? | Owned tokens and one changed binding |
| 17. Configuration | Does security depend on an optional feature or default? | Match the deployment's actual prerequisite |
| 18. Version/patch | Does a branch include the relevant fix or a backport? | Patch behavior and code path, not banner alone |
| 19. Trust composition | Do two individually bounded behaviors combine? | Verify every edge and the final bounded effect |
| 20. Observability | Would evidence distinguish prevention, logging and alerting? | A documented telemetry plan with known blind spots |

A lens is a viewpoint. Do not spawn twenty agents or issue twenty live tests simply because this table has twenty rows.

## Composing findings

Represent a proposed chain as edges: evidence for A, prerequisite for B, authority carried between them and the minimum final effect. Mark each edge observed, inferred, unsupported or contradicted.

Ask what breaks the chain: a missing permission, inaccessible feature, token audience, state mismatch, patch, user interaction or downstream validation. Do not multiply conjectures into a “critical chain.” If the first confirmed effect already proves the report's impact, stop expanding the live demonstration.

## Depth without indiscriminate activity

Use source review, local reproductions and architecture models to explore risky mechanics. For production-facing tests, select the smallest result that supports a specific claim. Controlled narrow tests can coexist with broad offensive imagination.

For each research sprint, produce an idea backlog containing a root-cause family, why it fits the surface, prerequisites, evidence needed, expected rejection signal, test cost and next decision. Retire ideas when evidence contradicts them; revisit only when assumptions change.
