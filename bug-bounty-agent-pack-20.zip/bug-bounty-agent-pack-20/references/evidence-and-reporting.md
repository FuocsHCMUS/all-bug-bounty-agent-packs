# Evidence and Report Preparation

## Contents

Evidence records; minimization; claims; severity; report; disclosure.

## Evidence records

Assign stable IDs such as E-001 and link them to an experiment X-001 and hypothesis H-001. Record source, collection time with timezone, tool/version, environment, relevant inputs, ownership/context, redaction and limitations.

Store only what is necessary to substantiate the result. Prefer one synthetic canary object to a list of records. Tokens, credentials and unrelated personal data do not belong in shared artifacts.

A screenshot can illustrate a result but may omit request context. A request/response excerpt can support a narrow claim but may omit browser state. Combine complementary evidence when needed rather than collecting everything.

If hashing a file, compute its actual bytes with a named algorithm. The included manifest utility streams SHA-256. A checksum helps detect later changes; it does not prove the collection was legitimate, the result is true or the file originated where claimed.

Record event time and collection/ingestion time separately when they differ. State clock uncertainty. Never invent a request ID, log event, hash, command output or timestamp.

## Evidence versus claims

Build a claim-to-evidence table:

| Claim | Required evidence | What it would not prove |
| --- | --- | --- |
| Product banner exists | Saved relevant response excerpt | Actual vulnerable build |
| Owned account A received B's private canary | Object ownership, expected policy, controlled requests | Unrestricted access to all tenants |
| Unauthorized update succeeded | Verified synthetic object's state before/after | Wider privileges on unrelated actions |
| A control denied the test | Semantically verified denied action | Complete protection of the whole application |
| A detection fired | Actual correlated alert/telemetry | Full coverage of all variants |

Mark evidence as observed, supplied, synthetic or expected. Supplied evidence still needs provenance; expected evidence was not collected.

## Confidence and severity

Confidence describes support for a claim. Severity describes impact in context. Keep them separate. A potentially severe candidate can still have low confidence; a confirmed narrow issue can have high confidence and modest impact.

Use the program's severity model. If using CVSS, identify the version, exact vector, source and rationale; check official definitions. A CVSS number is not a bounty estimate. Do not map a vulnerability name mechanically to a priority. State preconditions, affected boundary, data/action, user interaction and compensating controls.

## Report shape

Use [finding.md](../templates/finding.md). Lead with the concrete behavior: who can do what to whose controlled object, through which path, under which conditions.

Include scope reference, environment/version, prerequisites, reproducible steps, expected/actual result, minimal evidence, observed impact, untested potential impact, severity rationale, confidence, remediation and retest. List assumptions and cleanup.

Remove tool chatter, raw secret values, duplicate screenshots and unsupported attack-chain claims. Write for a triager who has not seen the research session.

If reproduction is flaky, describe the rate and conditions actually measured. Do not turn one unexplained anomaly into a reliable exploit.

## Submission and learning

Prepare the report for the user to submit through the correct program. Do not automatically send it, contact staff or publish. Respect the user's preference to handle disclosure.

Create a separate student lesson and a control observation. Private program specifics stay in campaign records. A shareable portfolio version must remove secrets, private targets and undisclosed vulnerability details.

Official scoring background: [FIRST CVSS v4.0](https://www.first.org/cvss/v4.0/specification-document). Recheck the program's required model before assigning a vector.
