# Design a Discriminating Experiment

## Contents

Question; preparation; controls; approval; execution; interpretation.

## Define the question

An experiment should answer one bounded question. Name the invariant, exact object/action, identities, relevant state and observation that would support or reject the hypothesis.

Example: “Can owned account A read B's synthetic private invoice through the export download path?” This is narrower and more useful than “Is authorization broken?”

## Separate prerequisites

There are three distinct checks:

1. The program permits the asset and method.
2. The environment and controlled accounts satisfy the technical prerequisites.
3. The user has granted the concrete script/tool execution.

A grant to run a local script does not supply missing program scope. A program's allowed automation does not replace the user's requested execution confirmation.

## Specify the experiment

Use [experiment.md](../templates/experiment.md). Record actual versions, target origin/path, request budget, duration, concurrency, data involved, expected traffic and side effects. If the program gives no acceptable rate or automation policy, do not invent a permission or a universal “safe” rate.

Choose canary data that demonstrates the effect with minimal exposure. Avoid broad enumeration. Identify asynchronous costs such as queue jobs, emails, billing operations and persistent links.

## Controls

- **Positive control:** the permitted normal operation works.
- **Negative control:** an intentionally forbidden or irrelevant case remains denied.
- **Alternative explanation check:** distinguish public objects, stale sessions, caching, proxies, client-only behavior and unrelated account state.
- **Reproducibility check:** repeat only enough to establish the observation, within the approved budget.
- **Cleanup check:** remove synthetic artifacts and verify their relevant state.

Do not compare requests that differ in several unrecorded ways. Account role, object ownership, cookies, time and cache context can be confounders. Change one meaningful condition where practical and record all known differences.

A status code alone may be ambiguous. A 200 response could contain an error shell; a 403 may come from a gateway. Inspect minimized semantic output and the actual invariant.

## Concrete approval

Present the exact command and working directory, interpreter version, files/hosts, privileges, expected outputs, state changes, budget and cleanup. Use APPROVALS.md to reuse an existing matching grant. If the command changes destination, data class, behavior or budget materially, obtain a new grant.

An agent may author a script and inspect its source before asking. Prepare the complete reviewable artifact; avoid asking the user to approve a vague idea to “run some tools.”

## Interpret the result

Write actual output separately from expected output. Classify the hypothesis. A denial can reject the specific test, but it does not establish complete coverage of all authorization paths. A success needs controls before becoming a finding.

If unexpected user data appears, minimize retention, stop the affected test and preserve only the evidence necessary for the user to handle the situation. If the service becomes unstable, stop rather than increasing retries.

The best next step is the one that reduces the most important remaining uncertainty with the least additional interaction.
