# Foundations: From a Request to a Security Claim

## Contents

1. Systems and networks
2. Names, connections and encryption
3. HTTP and browser state
4. Identity and authorization
5. Vulnerabilities and evidence
6. Operations and detection
7. A learning ladder

Read one section at a time. Learn the normal operation before studying how it can fail.

## 1. Systems and networks

A **client** asks for a service; a **server** provides it. These are roles, not fixed kinds of machine. A browser is commonly a client of a web API, and that API may be a client of a database.

An **IP address** identifies a network-layer destination or interface context. A **port** identifies a transport endpoint on a host. A host can offer several services on different ports, and several applications can share infrastructure.

A **protocol** defines the format and interpretation of messages. An application request passes through several protocols. A network connection reaching a service does not prove the application's business operation succeeded.

**Trust boundary** means a point where data or authority crosses between contexts with different assumptions. The boundary between browser input and server code is important because the user can control their client.

Intuition: a receptionist receives requests and forwards them to specialized staff. Where the analogy fails: protocols do not understand a person's intentions; they process defined values and state.

## 2. Names, connections and encryption

**DNS** maps names to data such as addresses. A DNS answer can lead to shared hosting, a load balancer or a third party. It does not prove ownership or testing scope.

**TCP** provides an ordered byte stream between endpoints. Establishing a TCP connection says the transport reached a peer. It does not establish the peer's identity or application authorization.

**TLS** protects a connection's confidentiality and integrity and commonly authenticates the server using a certificate. It does not decide whether user A may read user B's invoice. Encryption can carry both legitimate and unauthorized application requests.

For troubleshooting, distinguish name resolution, transport connection, TLS validation and application behavior. A ping reply proves neither HTTPS availability nor a correct permission decision.

Self-check: if the TLS handshake succeeds and the API returns a valid private invoice to the wrong account, which layer failed? Explain why stronger encryption alone does not repair that condition.

## 3. HTTP and browser state

An HTTP **request** includes a method, target, headers and possibly a body. A **response** includes a status, headers and possibly a body. The server interprets those inputs in the context of the application.

An **origin** is defined by scheme, host and port. Browser origin rules restrict what script can access across origins. Those rules do not replace server-side checks and do not apply identically to a standalone script.

A **cookie** is browser-managed state sent according to its scope and attributes. A **session** is the application context associating requests with an authenticated identity or workflow. The session can be backed by server storage, tokens or another implementation.

A status code is evidence about response handling, but its meaning still needs context. A 200 may carry an error message; a redirect may end at a login page; a forbidden response may come from a gateway rather than the application.

A read-only method name is not a guarantee of zero effects. A request may trigger logging, cache population, computation or an incorrectly implemented state change.

**Cache** means stored results reused later. It improves performance but needs a key and visibility policy matching the data. Personalized data requires the relevant user or tenant context to be handled correctly.

## 4. Identity and authorization

**Authentication** establishes an identity. **Authorization** decides what that identity can do. **Ownership** and **sharing** describe relationships to a resource. A **tenant** is an organizational or customer boundary in a multi-tenant service.

Model an authorization decision with five questions:

| Input | Question |
| --- | --- |
| Principal | Who is making the request? |
| Action | What operation are they asking for? |
| Object | Which resource is affected? |
| Context | Which tenant, role, sharing relation and state apply? |
| Policy | What relationship permits or denies this operation? |

Knowing an object's identifier is not automatically a permission. Conversely, an intentionally public object may be accessible by design. A credible test establishes the expected privacy and account relationships before interpreting a response.

A **capability link** can intentionally grant access to anyone who possesses it. Its scope, expiry and revocation semantics determine whether a specific behavior is a flaw. Do not call every accessible download an authorization bypass.

A token's **audience** identifies the service or context expected to accept it. A token's scope and lifetime are separate constraints. A valid signature does not establish every authorization condition.

## 5. Vulnerabilities and evidence

A **vulnerability** is a weakness that can violate a security property under relevant conditions. A **precondition** is something that must be true for a behavior to occur. **Reachability** asks whether the relevant input path can actually reach the affected logic.

An **exploit** is a method that uses a weakness to produce an effect. A **proof of concept** demonstrates a mechanism; its presence on the internet does not establish applicability to a specific target.

A **CVE** is an identifier and record for a publicly disclosed vulnerability. A **CWE** describes a weakness category. **CVSS** describes severity through a defined scoring model. These are different purposes, not interchangeable labels.

A **false positive** is an alert or conclusion that does not represent the claimed condition. A **false negative** misses a condition that is present. A result can also be inconclusive because evidence is insufficient.

A **negative control** is a case expected not to exhibit the behavior. It helps reject explanations such as public sharing or incorrect account state. A **positive control** establishes that the normal permitted operation works.

For example, if A retrieves B's private synthetic canary through one path and a comparable forbidden path denies it, that differential can help locate a decision gap. It does not establish every possible object is exposed.

## 6. Operations and detection

A **log event** records something a system emitted. An **alert** is an interpretation requiring attention. An **incident** is an operational assessment, not merely a scary string in a log.

A **SOC** investigates and responds using telemetry such as identity, endpoint, network and application events. A bounty researcher typically cannot observe all of that telemetry.

**Prevention** blocks or limits a behavior. **Detection** identifies it. **Response** handles the situation. A request being allowed does not prove it was not logged; no public reply does not prove no alert occurred.

**Remediation** restores the intended security property. **Retesting** checks the specific behavior after a fix. A **regression test** helps prevent the same invariant from failing again during later changes.

Operational trade-offs matter: detailed object-level logging aids investigations but has cost and privacy implications; central policy improves consistency but adds dependencies; fast revocation can require careful cache design.

## 7. A learning ladder

1. Explain a normal request from browser to application and back.
2. Identify identity, object, action and expected permission.
3. Predict outputs for an allowed and forbidden synthetic case.
4. Observe or inspect evidence and reject at least one alternative explanation.
5. Explain the root cause and propose a fix plus a regression test.
6. Describe the telemetry a defender would need and its limitations.
7. Transfer the reasoning to a new workflow with different objects or state.

Do not jump directly from a glossary to a live exploit. A small local model and a precise prediction build stronger understanding.

**Essence:** Security research asks which property should hold, under which assumptions, and what evidence shows it held or failed. Tools help observe behavior; they do not replace that reasoning.
