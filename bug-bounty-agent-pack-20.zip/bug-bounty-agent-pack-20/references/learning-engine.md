# Beginner-to-Expert Learning Engine

## Contents

Lesson contract; explanation ladder; worked example; production; practice.

The student should be able to explain a result, predict evidence and transfer the idea. Finding a bug is not the only successful learning outcome.

## Lesson contract

For every meaningful investigation, create L-###.md using [learning-note.md](../templates/learning-note.md). A note should cover one main concept and at most two supporting concepts. Link the actual hypothesis and evidence; define every unfamiliar essential term.

Use English in the artifact. Keep technical vocabulary consistent so the student can recognize it in documentation and interviews.

## Explanation ladder

1. **Intuition:** describe the problem with a familiar example, then state where the analogy stops being accurate.
2. **Mechanism:** show actors, inputs, identity, state, decision and output in causal order.
3. **Evidence:** identify what a request, response, log or source line demonstrates and what it does not.
4. **Failure:** explain the broken assumption and a normal alternative explanation.
5. **Defense:** prevention, detection, remediation and verification at the relevant boundary.
6. **Expert extension:** one edge case, a trade-off and the conditions under which the answer changes.

Introduce only one to three new concepts per step. Do not dump a taxonomy before the student understands the basic request.

## Example: private-object authorization

Start with the normal goal: a user can read their invoice while another user cannot. The server must evaluate identity and permission for the requested invoice.

Authentication identifies A. Ownership relates an invoice to B. Authorization decides whether A has a permitted relationship to B's invoice. Merely changing the identifier does not itself prove anything; the response must contain the controlled private canary or a verified state change.

A successful cross-account canary read supports that particular boundary failure. It does not prove database-wide access. A 403 on another path shows that path denied this case, not that every path is secure.

Ask the student to predict which component should enforce the decision and which evidence could distinguish public sharing from a missing ownership check.

## Diagrams and demonstrations

Use a small Mermaid diagram for meaningful branching or a trust boundary; use a table for exact comparisons. Avoid decorative diagrams.

For live observation, specify environment, privileges, command, read/change effect, expected output, interpretation and cleanup. Label examples EXPECTED — NOT EXECUTED or SYNTHETIC as appropriate.

For a risky mechanic, use an isolated toy model. A local demonstration proves that model, not a production target.

## Production context

Explain the owner role, deployment constraint, telemetry cost, change process, regression check and rollback. Distinguish the proposed control from the actual organization's implementation.

A fix needs an operational owner and verification. A SOC needs the fields necessary to distinguish policy violations from intended behavior. A developer needs a regression test protecting the invariant.

## Practice

Finish with one to three questions: explain in your own words, predict a changed case, or identify missing evidence. In an interactive lesson, wait for the student's answer before giving the solution. In batch research, save the questions and continue independent work.

Maintain a misconception log. Score understanding by explanation, prediction, practical reproduction and ability to justify a trade-off, not by reading completion.

If a video would help, verify a real title, publisher, date and link before suggesting it. Say whether you accessed a transcript, description or the video itself. Do not invent timestamps or claim the video says something you have not inspected.
