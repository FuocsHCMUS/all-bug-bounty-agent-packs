# Program Intake

## Contents

Program choice; brief capture; asset scope; accounts and data; first deliverable.

## Choose one program deliberately

A bug bounty program defines a particular research relationship. HackerOne and Bugcrowd help discover programs; a platform listing does not authorize attacks on the platform or every affiliated domain.

Prefer a program whose current scope, permitted methods, account creation and reporting expectations can be understood. Consider feature access, whether you can obtain two owned accounts, product complexity, expected learning, likely duplicate areas and time budget. Do not select solely by the largest advertised reward. Never promise a payout or novelty.

Public research can compare candidate programs in a table: exact official URL, accessible scope, relevant features, permitted automation, account needs, exclusions, access constraints, unknowns and estimated first-session work. Do not invent reputation or response-time statistics.

## Capture the current brief

Save a local text snapshot or an explicit summary with source URL, retrieved time, section references and a measured hash if actual bytes were saved. Include linked rules and announcements that change the experiment. Preserve private briefs locally; do not upload them to a public service.

Read allowed and excluded assets separately. Extract protocol/hostname/path restrictions, app IDs, repositories, product editions, environments and any third-party exclusions. Record method-specific rules, automation limits, identification headers, request budgets, data handling and reporting requirements exactly. Unknown is a valid value.

Check brief changes before a new active testing session or after an announcement. A historical snapshot is evidence of what was read, not assurance the scope remains current.

## Asset reasoning

For an exact hostname, do not silently include sibling hosts or an entire IP range. A DNS alias or redirect may lead to a third party. Confirm the destination before following test traffic. A wildcard does not settle ownership of every backend dependency, cloud service or payment provider.

A hostname-only scope may still constrain paths, accounts, ports, methods and environments. A repository in scope does not automatically include hosted production services built from it. A mobile package in scope does not necessarily include its analytics provider.

Document how each planned experiment maps to an explicit asset entry. If scope semantics are ambiguous, draft one precise question for the user to resolve. Continue source research and lab modeling while that question remains open.

## Accounts and data

Use owned test identities A and B with documented roles and tenant relationships. Do not record actual passwords or tokens in shared notes. Identify which records each account owns and whether actions send email, create charges, invoke a queue or contact integrations.

Specify synthetic canary records, cleanup and permitted callback endpoints if relevant. Do not assume the user controls a random collaborator server or that callbacks are allowed.

## First deliverable

Complete SCOPE.md and campaign.json, then choose one user journey. Write a small data-flow sketch, two hypotheses and the missing prerequisites. Start in public-research mode until a live experiment is ready and approved.

Primary background: [HackerOne scope guidance](https://docs.hackerone.com/en/articles/8495670-scope-best-practices) and [Bugcrowd brief details](https://docs.bugcrowd.com/researchers/engagement-management/details/). The current program brief supplies actual permissions.
