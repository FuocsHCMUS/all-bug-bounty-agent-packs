# The Research Loop

## Contents

Model; hypothesize; prioritize; investigate; experiment; learn; stop and resume.

## 1. Model a real journey

Start with a concrete function: sharing a document, exporting an invoice, changing a role, uploading a file or connecting an integration. Identify the principal, object, action, tenant, permission decision and side effect.

A principal is the identity making a request. An object is the resource being acted on. An invariant is a condition that must remain true, such as a revoked member losing access to future exports.

Write the expected path in a few sentences. Add the minimum relevant components: browser, gateway, API, authorization service, storage and asynchronous worker. Mark what you observed and what is inferred.

## 2. Create a falsifiable hypothesis

Use: “If [precondition], then [specific boundary] may fail when [one controlled change], observable as [evidence].”

Bad: “Try IDOR everywhere.”
Better: “The download worker may authorize only at export creation, so revoking the requesting user's role before download may leave access valid.”

List the invariant, prerequisites, strongest alternative explanation, a negative control, cleanup and one result that would reject the idea. An observation that cannot contradict the hypothesis is a poor experiment.

## 3. Prioritize by information gain

Compare hypotheses using evidence fit, reachable surface, potential impact if true, distinguishability, effort, operational cost and dependence on unknown assumptions. Use qualitative ranks unless the user wants a numerical heuristic. Do not present an invented score as probability or expected bounty.

Choose one to three hypotheses for a session. Reserve time for controls and notes. Researching twenty surfaces superficially usually creates weaker evidence than understanding one workflow.

## 4. Read and triangulate

Use specifications, vendor advisories, product docs, source code and patch diffs. Record source, date, version and the claim each supports. A search snippet is a lead; read the relevant source before making a precise technical claim.

When sources disagree, check edition, deployment mode, advisory revision, branch and whether a fix was backported. Record conflict instead of choosing the most dramatic interpretation.

## 5. Prepare and run the smallest experiment

Create an experiment card before execution. Confirm scope and execution permission separately. Capture a normal control, change one meaningful condition and record actual outputs. If a test is not executed, write EXPECTED — NOT EXECUTED.

Update the model when the outcome differs. Do not rerun the same request repeatedly without explaining what new information the repetition would add.

## 6. Classify and review

- **Candidate:** an observation suggests a possibility.
- **Plausible:** relevant prerequisites are supported, but impact is unconfirmed.
- **Reproduced:** the specific boundary failure is demonstrated with controls.
- **Report-ready:** reproduced behavior has sufficient evidence, bounded impact, cleanup and reproducible steps.
- **Rejected:** a defined hypothesis was contradicted.
- **Inconclusive:** available evidence does not distinguish the explanations.

These are workflow states, not platform decisions.

## 7. Learn and checkpoint

Write a learning note even when the control held. Connect behavior to the property being protected, a defensive measure and the evidence a SOC would need. Save negative results and the conditions under which they might need reconsideration.

End with the verdict, artifact paths, limitations and one next action. Stop an experiment on budget exhaustion, unexpected data exposure, service instability, scope changes or loss of the conditions the approval relied on. Research and documentation can continue.
