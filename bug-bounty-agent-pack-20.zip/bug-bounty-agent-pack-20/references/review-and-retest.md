# Review, Remediation and Retest

## Contents

Challenge the finding; fix the invariant; retest; residual risk; completion.

## Independent challenge

Read the proposed report as a skeptical triager:

- Is the object demonstrably private and controlled?
- Does the account have an intended relationship that explains access?
- Is the result server-side, current and reproducible?
- Are session, cache, role and tenant differences recorded?
- Are all claimed chain edges supported?
- Does impact stay within observed behavior?
- Can another reader reproduce it from the report alone?
- Are evidence excerpts minimized and appropriately labelled?

Do not inflate severity to make the report more compelling. Improve evidence or narrow the claim.

## Remediation

Connect the fix to the violated invariant. Identify the decision point, relevant inputs and failure semantics. A generic recommendation to sanitize input or improve authentication may not address an object-authorization flaw.

Suggest an owner role rather than inventing a named company team. Describe migration, rollout, performance, availability and compatibility implications. Separate a compensating control from a permanent correction.

A WAF rule can mitigate some paths without repairing authorization in application code. A patch may fix a component but leave deployment prerequisites unchanged. State what each measure does and does not cover.

## Retest matrix

Verify:

1. The original forbidden case is denied semantically.
2. The legitimate operation still works.
3. Neighboring roles and owned objects preserve the intended relationship.
4. Alternate relevant paths and asynchronous behavior are covered where authorized.
5. Revocation and state changes behave as specified.
6. Telemetry captures enough context to verify the decision if available.
7. Synthetic artifacts are cleaned up.

The retest itself needs current scope and a matching execution grant. A report being accepted does not automatically authorize new test surfaces.

## Interpreting the fix

A single successful retest supports the tested condition. It does not prove every variant is impossible. Distinguish fixed, partially fixed, inconclusive, regression observed and not retested.

If behavior changed for reasons unrelated to the fix, document that uncertainty. An unavailable endpoint does not prove the invariant was restored.

## Completion

Record exact environment and what actually ran, final result, evidence IDs, remaining uncertainty, cleanup and next owner/action. Link the finding, observation and learning note.

Do not claim a report was submitted, a bounty accepted, a company remediated or a detection deployed unless that happened and supporting evidence exists.
