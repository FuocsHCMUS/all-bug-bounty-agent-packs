# From Pentest Evidence to SOC Reasoning

## Contents

Behavior; telemetry; investigation; detection proposal; validation; handoff.

A SOC investigates behavior using telemetry. A bounty researcher often lacks internal telemetry. Teach the required evidence and uncertainty without inventing logs or claiming a detection failed.

## Describe the behavior first

Identify principal, object, action, tenant, time, path, state transition and result. State which of those fields were observed and which are inferred.

A denied API call could be a harmless user error, a misconfigured client or an attempted boundary crossing. An allowed call could be intended sharing or unauthorized access. Start with at least two explanations.

## Telemetry requirements

For an authorization issue, useful application events may include a trusted actor identifier, effective role, tenant, resource owner, action, decision, policy/version context, request/job correlation ID and event time.

Access logs alone may have only path and status. Identity logs may show authentication but not object authorization. Network logs can show a connection without proving what the application allowed. Explain these visibility limits.

Use privacy-preserving identifiers and avoid unnecessary content. Request IDs are valuable for correlation only if the system actually emits them and the logs preserve them.

## Investigation sequence

1. Establish the tested business operation and timestamp uncertainty.
2. Correlate authentication, application decision and asynchronous work where available.
3. Compare actor/tenant/resource relationships with the intended access model.
4. Check sharing, role changes, cached state and authorized administrative activity.
5. Assess observed impact, confidence and remaining coverage gaps.
6. Suggest a next evidence source or escalation owner.

An empty query does not prove no event occurred. Confirm schema, retention, ingestion delays, sampling and time range.

## Detection proposal

When the product and schema are unknown, use labelled pseudocode rather than invented SPL, KQL or Sigma fields:

~~~text
PSEUDOCODE — NOT EXECUTED
select application decisions for the relevant operation and time range
join trusted actor context with resource ownership and sharing policy
flag allowed actions where the resolved policy says actor is unauthorized
exclude documented service/admin workflows only after verifying their context
retain correlation IDs for investigation
~~~

This is a model for instrumentation and analysis, not a ready-to-run query. Derive exact field names and policy semantics from the real source.

Describe false positives such as legitimate sharing or service identities. Describe false negatives such as missing owner fields, unlogged worker actions and role state captured too late.

## Validation

Use synthetic events labelled as such. Include a permitted case, a forbidden case, a legitimate exception, a missing-field case and an asynchronous case if relevant. State expected matches, then report measured results only when the actual detection runs.

A request being blocked and an alert being raised are separate observations. Prevention, logging, alerting and human response can each succeed or fail independently.

Map ATT&CK only when the actual observed behavior supports a verified technique. A weakness category and an ATT&CK technique are not interchangeable.

## Handoff

Create a SOC companion with summary, entities, timestamps/timezone, evidence links, alternative explanations, severity rationale, confidence, visibility gaps, next query/data request and proposed owner. Do not claim compromise, attribution or exfiltration from a single IP, status code or read access.
