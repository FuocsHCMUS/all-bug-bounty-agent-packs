# Specialized Surfaces: Cloud, Mobile, AI and Supply Chain

## Contents

Cloud; mobile; AI agents; source/dependencies; when to switch to a lab.

The core evidence and approval workflow applies to every surface. Do not silently treat a web scope as permission for an entire cloud account, a vendor's hosted infrastructure or a third-party mobile SDK.

## Cloud

Identify the provider and the exact account, subscription/project, region, principal and resource. These are not interchangeable labels across AWS, Azure and Google Cloud.

Trace principal authentication, policy evaluation, resource binding, network reachability, data handling and auditability. Distinguish an exposed endpoint from permission to enumerate a storage service or alter IAM.

A cloud authorization hypothesis needs the actual policy path and resource context. Do not infer administrator access from a policy keyword or an error. Use read-only supplied policy review and synthetic local fixtures when actual cloud inspection is unavailable.

For a proposed test, include cost, resource creation, queued work, audit trail and teardown. Installing a CLI is a separate user decision; cloud credentials should remain in the user's credential store, not in prompts or reports.

## Mobile

Confirm the exact application package/bundle, version and allowed analysis methods. Map which logic runs on-device and which is enforced by the backend. A client-side check can be bypassable without establishing a server-side flaw.

Read public app documentation and supplied code or artifacts. Treat decompilers and instrumentation tools as tools requiring an installation/execution decision. An allowed package does not automatically bring its analytics, advertising, payment or identity providers into scope.

Use owned accounts and synthetic data. Distinguish insecure storage, transport, endpoint authorization and application logic; each needs different evidence.

## AI and tool-using applications

Model user identity, conversation/session, retrieved content, model output, tool broker and downstream service. A prompt injection is untrusted content attempting to steer an agent. A harmful-looking model response alone does not prove the ability to execute a privileged tool or obtain private data.

Investigate the boundary between a model's suggestion and the broker's deterministic authorization. Use local synthetic documents and dummy tool fixtures to show whether a boundary can be crossed. Separate prompt compliance, tool invocation, downstream acceptance and actual side effect.

Do not make real agents reveal secrets or perform damaging actions as a demonstration. A harmless marker and a fixture can explain the root cause without creating production harm.

## Source and dependency review

Separate installed dependencies, reachable vulnerable paths and deployment exposure. Read lockfiles and source provenance. For a secret-like string, do not use it to test a service; record a minimized fingerprint and context for the user.

Review build identities, untrusted inputs, artifact promotion and release permissions conceptually. Do not trigger third-party CI workflows or publish packages as a research shortcut.

For an open-source patch, connect the change to an invariant and a regression test. A hypothetical dependency substitution remains a hypothesis until scope and a controlled experiment support it.

## Switching to a lab

If a surface requires destructive behavior, service disruption, bulk extraction or broad privilege changes to demonstrate, develop a local synthetic reproduction and document the production prerequisites separately. A lab result proves the lab behavior; it does not certify the target's configuration.
