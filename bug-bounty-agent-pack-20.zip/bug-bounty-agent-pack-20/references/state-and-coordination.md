# State, Sessions and Coordination

## Contents

Campaign tree; identifiers; checkpoints; role lenses; delegation; budgets.

## Campaign records

Use one campaign per program or clearly defined independent scope. Keep campaign.json, SCOPE.md, APPROVALS.md, STATE.md and DECISIONS.md together.

- research/ stores brief snapshots, source cards, models and surface maps.
- hypotheses/ stores H-### cards, including rejected ideas.
- experiments/ stores X-### plans and results.
- findings/ stores F-### reports supported by evidence.
- observations/ stores O-### control assessments.
- learning/ stores L-### lessons.
- evidence/ stores minimized actual evidence. Do not commit raw evidence.

Use [templates/](../templates/) for exact structures. A folder path is not a security boundary; set actual file and tool permissions in the host environment.

## Template-to-output mapping

Read templates as reusable sources and fill campaign copies. Resolve every destination below under WORKSPACE_ROOT/campaigns/<slug>/.

| Source template | Campaign destination |
| --- | --- |
| campaign.json, STATE.md, SCOPE.md, APPROVALS.md, DECISIONS.md | Same filenames at campaign root |
| hypothesis.md | hypotheses/H-###.md |
| experiment.md | experiments/X-###.md |
| cve-applicability.md | research/CVE-###.md |
| evidence-record.md | evidence/E-###.md |
| finding.md | findings/F-###.md |
| learning-note.md | learning/L-###.md |
| control-observation.md | observations/O-###.md |
| soc-companion.md | research/SOC-H-###.md or research/SOC-F-###.md |
| tool-proposal.md | research/TOOL-###.md |
| retest.md | experiments/RT-F-###.md |

State fields describing scope, approvals and testing readiness remain descriptive. Writing them does not grant permission. Never overwrite reusable templates or an existing campaign artifact without an intentional update to that artifact.

## IDs and relationships

Assign stable IDs sequentially within a campaign. Do not rename a finding because its severity changes. Link hypothesis to experiment, experiment to evidence, finding to evidence, and lesson/observation to the relevant result.

A hypothesis can have many experiments. A failed experiment can be inconclusive rather than rejecting the hypothesis. Preserve the reason for each state change.

If multiple agents write, reserve ID ranges or have the coordinator allocate IDs. Do not resolve collisions by silently overwriting a file.

## Checkpoint

At session end, save objective, current scope snapshot, progress, actual commands/results, evidence IDs, approvals and budgets, rejected hypotheses, unresolved assumptions, cleanup and one next action.

At resume, reread the relevant files. Check brief changes, account state, tool versions, grant expiration and remaining budget. Do not rerun an experiment merely because the previous conversation context is unavailable.

File state must remain consistent with evidence. A manually edited live_testing_enabled field is descriptive; it does not grant execution or program permission.

## Role lenses

A single agent can switch perspective among researcher, source analyst, experiment designer, evidence reviewer, reporting editor, SOC analyst and beginner mentor. Use these as focused modes, not fictional people or claims of experience.

Switch perspective deliberately: an evidence reviewer asks what could falsify the claim; a mentor asks what the student must understand first. Multiple perspectives do not require multiple concurrent agents.

## Delegation

Delegate only when the user or host workflow allows it. Prefer independent public-source research, local document review or hypothesis critique. Give the minimum task context and a concrete artifact to produce.

Specify input paths, output paths, scope, forbidden side effects, budget and whether tools may run. Delegation does not expand permission. A subagent cannot grant the coordinator authority it lacks.

Keep one owner for mutable campaign state, scope and approvals. Reconcile claims against raw evidence before merging another agent's report. Do not trust a success summary without examining the artifact.

## Time and budget

Agree or propose a bounded session. A useful default structure allocates time to understanding, hypotheses, one meaningful experiment, controls and notes; this is a planning suggestion, not a granted rate limit.

Stop a branch when its prerequisites are contradicted or the next step would exceed scope, grant or budget. Record why. Resume public research, a local model or teaching when live work is blocked.
