# Tools, Downloads and Execution Grants

## Contents

Decision table; acquisition; script review; grants; integration changes.

## Decision table

| Action | Default under the user's preferences |
| --- | --- |
| Read supplied files, public docs, source and advisories | Proceed |
| Write notes, scripts and proposed configuration in workspace | Proceed |
| Download/clone a small portable tool/repo into workspace/tools | Proceed; record provenance |
| Install needed identified Python packages into project .venv | Proceed under the dependency exception |
| Execute a workspace utility, downloaded binary, PoC or test suite | Ask unless a matching concrete grant exists |
| Run a scanner, target request script or automated browser test | Ask; verify program scope/method separately |
| Install MCP, plugins, skills, extensions or applications | Ask user to install/enable |
| Change global interpreter, PATH, OS policy, driver or service | Ask with a concrete proposal |
| Submit a report, message a company or publish a finding | User handles it unless explicitly instructed otherwise |

Search, file-reading and ordinary editing through the agent's built-in capabilities are covered by the research task. Do not disguise target interaction as “just reading.”

“Small” is not a fixed size the user supplied. Read reported archive/repo size first when available. If it is likely to be large, has substantial submodules, or requires a second-stage download, explain the footprint and ask. Do not use an invented numeric threshold as if the user agreed to it.

## Acquiring portable sources

Use an official upstream release/repository, a workspace-local destination and a reproducible version or commit. Record license/provenance, download size when known, publisher checksums/signatures when available, and your own measured hash when downloaded. A hash you compute provides later integrity comparison; it does not prove publisher trust.

Do not run a binary merely to obtain its version before execution is approved. Read metadata first. Review archive contents and avoid extraction paths escaping tools/. A small executable may still alter the machine.

Clone without enabling unfamiliar hooks, recursive submodules or setup actions. Do not run remote shell pipelines. Keep acquired tools outside campaign evidence and document any modifications.

## Python dependency exception

Use the exact .venv interpreter with -m pip. Identify the package and import name; check upstream documentation and PyPI provenance to reduce typosquatting mistakes. Prefer a compatible wheel. Routine identified package installation is covered by the user's request.

A source build or VCS package can run build code, so inspect its source and effects first. The user's broad local-dependency permission includes needed builds that remain within the workspace and .venv. If a build needs a new system compiler, runtime, large external download or OS change, make a concrete proposal and request approval for that additional action. Do not silently downgrade the interpreter to make a package install.

## Script/tool review

Before requesting execution, read the relevant entrypoint and default behavior. Inventory network destinations, subprocesses, filesystem effects, data access, concurrency, retries and cleanup. Prefer argument arrays and explicit paths. Avoid shell concatenation of untrusted input.

For target scripts, make host/method limits explicit in code and environment. A commented promise is not enforcement. Treat redirects and DNS resolution as possible changes to the destination; a string hostname check alone does not constrain the actual network.

## Reusable grants

An approval record names command or bounded command family, source revision, working directory, interpreter/tool version, files/hosts, operation class, limits, expiration and user's actual grant. Mark requests, grants and denials distinctly.

Do not fabricate a grant by writing “approved” yourself. Do not infer a broad family from one command. Reuse the record only when the current operation fits it, and record consumption of any shared budget.

## Integrations

Read [integrations.md](integrations.md). Ask for the smallest missing capability and prepare the exact reviewed configuration. Do not install a collection of MCP servers speculatively.
