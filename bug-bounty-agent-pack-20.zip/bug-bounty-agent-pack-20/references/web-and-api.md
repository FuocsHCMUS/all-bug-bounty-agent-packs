# Web, API and Identity Research

## Contents

Fundamentals; authorization; sessions; OAuth; input boundaries; state; caches; files.

For foundational explanations, read [foundations.md](foundations.md). Use these ideas to build experiments, not as a checklist to run against every endpoint.

## Authorization

Authentication establishes who the requester is. Authorization decides whether that identity may perform this action on this object in this context. A valid session can still be denied an action.

Model the decision as principal × action × object × tenant × state. Build an authorization matrix with owned accounts and synthetic objects. Compare UI behavior with the server's decision; hiding a button is not server-side authorization.

Investigate alternate read, update, download, export and asynchronous paths for the same controlled object. Each is a hypothesis, not automatic coverage. Record intended public objects so a public download is not misreported as private-object access.

For a tenant case, document A's and B's membership, role, object's owner and how the object's privacy was established. Do not enumerate other people's identifiers to increase the apparent impact.

## Sessions and account lifecycle

A session is the continuing authenticated context between requests. Determine where state lives, how a token is bound and which transitions should invalidate it. Consider logout, password change, role change, revocation and tenant removal.

A persistent session after a password change may be intended by a program's policy; identify the documented security expectation before calling it a flaw. Use owned sessions. Record token expiry, server rejection and client state separately.

Cookies have independent attributes governing browser behavior. HttpOnly restricts script access, Secure restricts transmission context, and SameSite affects cross-site cookie behavior. None replaces object authorization. Avoid claiming a missing attribute proves account takeover.

## OAuth and OIDC

OAuth delegates access; OpenID Connect adds an identity layer. Follow actor, client, authorization server, redirect, code/token, audience and resource server. Determine what is bound to what: client, redirect, transaction, user, token audience and requested scope.

Review documented flows and local fixtures before live variations. A redirect observation alone does not prove credential theft or account takeover. State the exact missing binding, prerequisites and the controlled evidence needed to show impact. Do not conflate login CSRF, authorization-code handling and resource authorization.

## Input and interpretation boundaries

For injection research, trace untrusted input to the component interpreting it. Identify whether the data becomes query structure, markup, a path, a template or a command. A character accepted by an input field is not evidence of execution.

Separate storage, reflection, interpretation and execution. Use a harmless synthetic sentinel or isolated local reproduction. Model correct parameterization, output encoding and validation at the boundary where their semantics matter.

For server-side request features, identify the intended destinations and the component making the outbound request. Do not probe metadata services, private networks or unrelated callback collectors in live research. A local controlled receiver can illustrate the mechanism when permitted.

## Business state and asynchronous work

Write a state machine before proposing timing tests. Determine allowed transitions, authority at each transition, idempotency and who owns the final result. An asynchronous job may outlive the session that created it, so the security expectation must be specified.

Explore retries and concurrent semantics in a local deterministic model first. Concurrency and high request rates are operational changes requiring explicit budgets; do not equate creativity with stress testing.

## Caches and file flows

For a cache, identify the cache key, user/tenant context, response visibility and invalidation. Compare controlled artifacts without affecting unrelated visitors. A response-header change alone does not establish a cache isolation flaw.

For uploads and downloads, trace naming, storage, ownership, metadata, serving origin, content interpretation and lifecycle. A file accepted for storage is different from being executed or served under a sensitive origin. Prefer synthetic harmless files and explicit cleanup.

Map relevant test domains to the checked [OWASP WSTG](https://owasp.org/www-project-web-security-testing-guide/). Pin versioned scenario references when citing specific tests; do not invent scenario IDs.
