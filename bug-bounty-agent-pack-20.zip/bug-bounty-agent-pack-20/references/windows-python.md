# Windows 11, PowerShell 7 and Python 3.14.x

## Contents

Interpreter; virtual environment; packages; utilities; compatibility; troubleshooting.

The examples below are **instructions for the user's environment, not commands executed on Windows during pack creation**. Commands need an applicable execution grant when the agent runs them. They require a normal user terminal, not Administrator.

## Select the existing interpreter

Use PowerShell 7 in the extracted workspace:

~~~powershell
Get-Command py, python -ErrorAction SilentlyContinue
py -3.14 -c "import sys; print(sys.executable); print(sys.version)"
~~~

The second line launches an installed 3.14 runtime on launchers supporting that selector. If it cannot find the runtime, stop and inspect the existing Python setup; do not accept an automatic runtime installation silently. The Python install manager and older launcher have different management commands. Avoid assuming py list and py -0p are interchangeable.

Set a task-specific variable to the actual existing interpreter path printed above:

~~~powershell
$BasePython = 'C:\path\to\Python314\python.exe'
& $BasePython -c "import sys, sysconfig; print(sys.version); print(sysconfig.get_config_var('Py_GIL_DISABLED'))"
& $BasePython -m venv .venv
$VenvPython = Join-Path $PWD '.venv\Scripts\python.exe'
& $VenvPython -c "import sys; print(sys.executable); print(sys.prefix != sys.base_prefix)"
~~~

The first command inspects version/build. Creating .venv writes a local environment; the final command should print True for the environment check. Output here is expected, not a measured result.

Use an existing .venv only after checking that it points to the intended interpreter. Do not move or copy virtual environments between machines; recreate them.

## Use the interpreter directly

Activation is optional:

~~~powershell
& $VenvPython -m pip --version
& $VenvPython -m pip check
~~~

No change to PowerShell execution policy is needed to invoke python.exe directly. Do not use a global pip, --user, Administrator, or a persistent machine-level environment variable.

For an identified needed dependency, review its source and choose a compatible release before installing. The example package name below is a placeholder, not a recommendation:

~~~powershell
& $VenvPython -m pip install --only-binary=:all: 'REPLACE_WITH_REVIEWED_PACKAGE'
& $VenvPython -m pip check
~~~

Do not paste that placeholder command unchanged. --only-binary=:all: prevents falling back to a source build; it may fail where no compatible wheel exists. Explain that failure rather than removing the option blindly. The pack's offline utility itself needs no packages.

Capture installed versions when relevant:

~~~powershell
& $VenvPython -m pip freeze | Set-Content -Encoding utf8 requirements.local.txt
~~~

Review the output before sharing; direct dependency URLs can contain private details. A freeze file records installed versions, not a security guarantee or complete cross-platform lock.

## Included offline utility

After reviewing the script and approving its execution:

~~~powershell
& $VenvPython .\scripts\packctl.py --help
& $VenvPython .\scripts\packctl.py init --workspace . --name first-program
$ManifestJson = & $VenvPython .\scripts\packctl.py manifest --evidence .\campaigns\first-program\evidence
if ($LASTEXITCODE -ne 0) { throw 'Hashing failed; the previous manifest was preserved.' }
$ManifestJson | Set-Content -Encoding utf8 .\campaigns\first-program\evidence-manifest.json
& $VenvPython -m unittest discover -s tests -v
~~~

init creates a new campaign and refuses to replace an existing one. manifest reads regular evidence files and prints JSON hashes; keep output outside evidence/ so it does not hash its own prior output. Capture stdout and check the exit code before replacing a saved manifest, as shown above. It does not authenticate evidence or redact secrets. Review files before sharing.

## Python compatibility

A package may support Python 3.14 source syntax but lack Windows wheels, native-extension support or free-threaded-build support. Those are different questions. Pin the supported version after checking upstream metadata and release notes.

If a dependency fails, capture the interpreter, architecture, build type and the smallest relevant error. Try a supported wheel or alternative implementation first. If another Python runtime is genuinely needed, ask the user before installing it and use a separate local environment; preserve the existing one.

Do not promise compatibility with all future Python 3.14.x+ versions. Recheck versions after upgrades.

## Troubleshooting

| Symptom | First check | Useful correction |
| --- | --- | --- |
| Wrong Python | sys.executable and sys.version | Use the intended absolute path |
| pip installs elsewhere | Invoke the venv interpreter with -m pip | Avoid bare pip |
| Activate.ps1 blocked | Direct python.exe invocation | No policy change needed |
| No matching wheel | Python version, architecture, package metadata | Review a supported release/alternative |
| Native build fails | Build prerequisites and backend output | Ask before system build-tool installation |
| Source cloned successfully | Files acquired only | Obtain execution grant before running |

Official background: [venv](https://docs.python.org/3.14/library/venv.html), [Python on Windows](https://docs.python.org/3.14/using/windows.html), [free threading](https://docs.python.org/3.14/howto/free-threading-python.html).
