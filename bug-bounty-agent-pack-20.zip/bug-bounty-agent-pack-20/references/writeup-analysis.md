# Turn a Writeup Into Transferable Research

## Contents

Read critically; extract mechanism; review code; transfer; teach.

## Read the original source

Record author, title, original URL, publication/update date, product/version and whether the source is a lab, CTF, public disclosure or vendor advisory. A repost may omit constraints. Search snippets do not establish the full chain.

Summarize the trust boundary, violated invariant, prerequisites, root cause, distinguishing evidence, impact and fix. Keep the author's confirmed observations separate from your inference.

A CTF may supply source code, predictable identities, unrestricted errors or a single vulnerable instance. Those conveniences change the research cost and may not exist in a real program. Do not transfer the challenge's flag or exploit path as if it were a production fact.

## Extract a mechanism card

Use this format:

- The system was supposed to preserve …
- It trusted … at boundary …
- That assumption failed because …
- The attacker controlled … but did not need …
- The minimum observable effect was …
- A normal explanation was excluded by …
- The fix restored … and regression tests should cover …

If the article does not supply one item, write unknown rather than filling it with imagination.

## Review linked code without executing it

Read dependencies, installation instructions, entrypoints and network calls. Inspect default flags as carefully as the visible example. A tool labelled “detect” may issue an exploit, enumerate records or call a collector service.

Build a side-effect inventory: files read/written, commands spawned, external destinations, account changes, callbacks, data printed and retained state. Distinguish the required mechanism from convenience features. Record the exact source revision and any local changes.

Downloading a small repository into tools/ is preauthorized under the pack's workspace policy. Running its installer, tests or PoC is not covered by that download permission.

## Transfer as a hypothesis

Identify a structural similarity to your current scoped surface. Similarity could be the same parser boundary, asynchronous authorization decision, token binding or state transition; a matching language or product logo alone is weak evidence.

Create a new hypothesis card with local prerequisites and a rejection condition. Do not copy an exploit wholesale and rename the domain. Select a harmless sentinel and controlled identities where possible.

Generate at most a few adjacent hypotheses. For each, say which new assumption it adds and how to test that assumption independently. Novelty remains unverified until prior research and reproducible evidence support it.

## Teach the mechanism

Explain the original business operation before explaining its failure. Introduce one to three new terms at a time. Show the normal flow, the changed condition and the evidence separating them.

Close with what defenders can prevent, what telemetry would reveal, what a patch changes and one teach-back question. A failed transfer can still teach why the new system's design preserved the invariant.
