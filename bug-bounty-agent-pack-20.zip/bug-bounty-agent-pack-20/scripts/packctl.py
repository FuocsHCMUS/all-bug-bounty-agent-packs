"""Offline campaign scaffolding and evidence hashing; standard library only.

No target requests, downloads, package installation, or subprocess execution.
This utility does not enforce scope, grants, isolation, or evidence redaction.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys


PACK_ROOT = Path(__file__).resolve().parents[1]
RESERVED = {"con", "prn", "aux", "nul"} | {
    f"{prefix}{number}" for prefix in ("com", "lpt") for number in range(1, 10)
}
CAMPAIGN_DIRS = (
    "research", "hypotheses", "experiments", "findings",
    "observations", "learning", "evidence",
)


def redirected(path: Path) -> bool:
    """Reject symlinks and Windows junctions rather than following them."""
    return path.is_symlink() or bool(getattr(path, "is_junction", lambda: False)())


def plain_directory(path: Path) -> Path:
    """Check user-supplied path components before canonicalizing."""
    absolute = path.absolute()
    for part in (absolute, *absolute.parents):
        if redirected(part):
            raise ValueError(f"Symlink or junction is not allowed: {part}")
    if not absolute.is_dir():
        raise ValueError(f"Directory does not exist: {absolute}")
    return absolute.resolve()


def init_campaign(workspace: Path, slug: str) -> Path:
    if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", slug) or len(slug) > 64 or slug in RESERVED:
        raise ValueError("Invalid campaign name: use a lowercase hyphenated slug, up to 64 characters; no Windows reserved names")
    root = plain_directory(workspace)
    campaigns = root / "campaigns"
    if redirected(campaigns):
        raise ValueError("Symlink or junction is not allowed for campaigns")
    campaigns.mkdir(exist_ok=True)
    campaign = campaigns / slug
    if campaign.exists() or redirected(campaign):
        raise ValueError(f"Campaign already exists; no files changed: {campaign}")

    # Validate and load all bundled inputs before creating the campaign.
    templates = PACK_ROOT / "templates"
    config = json.loads((templates / "campaign.json").read_text(encoding="utf-8"))
    config["slug"] = slug
    names = ("STATE.md", "SCOPE.md", "APPROVALS.md", "DECISIONS.md")
    documents = {name: (templates / name).read_text(encoding="utf-8") for name in names}
    campaign.mkdir()  # Exclusive creation protects an already existing campaign.
    try:
        for name in CAMPAIGN_DIRS:
            (campaign / name).mkdir()
        (campaign / "campaign.json").write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
        for name, content in documents.items():
            (campaign / name).write_text(content, encoding="utf-8")
    except Exception:
        # Only remove the directory created by this invocation after a partial write.
        shutil.rmtree(campaign)
        raise
    return campaign


def evidence_manifest(evidence: Path) -> dict:
    root = plain_directory(evidence)
    paths = []

    def walk_error(error):
        raise error

    for current, dirs, files in os.walk(root, followlinks=False, onerror=walk_error):
        base = Path(current)
        for name in sorted(dirs):
            path = base / name
            if redirected(path):
                raise ValueError(f"Symlink or junction is not allowed in evidence: {path}")
        for name in sorted(files):
            path = base / name
            if redirected(path) or not stat.S_ISREG(path.lstat().st_mode):
                raise ValueError(f"Only regular, non-linked evidence files are allowed: {path}")
            paths.append(path)

    rows = []
    for path in sorted(paths, key=lambda p: p.relative_to(root).as_posix()):
        before = path.stat()
        digest = hashlib.sha256()
        size = 0
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                size += len(chunk)
                digest.update(chunk)
        after = path.stat()
        if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino) or size != after.st_size:
            raise ValueError(f"Evidence changed while hashing; retry only after collection stops: {path}")
        rows.append({"path": path.relative_to(root).as_posix(), "size_bytes": size, "sha256": digest.hexdigest()})
    return {"schema_version": "1.0", "algorithm": "SHA-256", "files": rows}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Offline campaign initialization and evidence manifests; no network activity.")
    commands = parser.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init", help="Create a new campaign without overwriting an existing one")
    init.add_argument("--workspace", type=Path, required=True, help="Existing workspace directory")
    init.add_argument("--name", required=True, help="Lowercase campaign slug")
    manifest = commands.add_parser("manifest", help="Print a deterministic JSON manifest of regular evidence files")
    manifest.add_argument("--evidence", type=Path, required=True, help="Evidence directory; put redirected output outside it")
    args = parser.parse_args(argv)
    try:
        if args.command == "init":
            result = {"created_campaign": str(init_campaign(args.workspace, args.name))}
        else:
            result = evidence_manifest(args.evidence)
    except (OSError, ValueError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 2
    print(json.dumps(result, indent=2, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
