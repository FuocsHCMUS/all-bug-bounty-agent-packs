# Execution Approval Ledger

Standing preferences: public research and workspace authoring may proceed. Small portable acquisition into workspace/tools and identified needed dependency installation into the local .venv are preauthorized. Other script/tool executions require a matching concrete grant. MCP/plugin/skill/application installation is a user decision.

## Grant record

- Approval ID: A-###
- Status: requested / granted / denied / expired
- Requested time with timezone:
- User's actual decision and source:
- Exact command or explicitly bounded command family:
- Source revision / reviewed script hash:
- Working directory:
- Interpreter / tool version:
- Permitted files / hosts / paths / accounts:
- Allowed operation and network effects:
- Privileges:
- Budget, rate, concurrency and duration:
- State changes and cleanup:
- Expiration / invalidation conditions:
- Consumed budget:
- Linked experiments:

No grants exist until a real user decision is recorded. Editing this file does not grant permission or enforce technical isolation.
