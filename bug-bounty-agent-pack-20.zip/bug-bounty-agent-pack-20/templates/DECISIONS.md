# Decision Log

| Time with timezone | Decision | Evidence | Alternatives | Trade-off | Revisit condition |
| --- | --- | --- | --- | --- | --- |

Record technical choices, scope interpretations, evidence limitations and why a hypothesis was prioritized or rejected. Do not invent the user's agreement; identify an agent proposal as a proposal.
