# Scope Record

- Program name and platform:
- Official brief URL:
- Retrieved time with timezone:
- Saved brief path / actual hash:
- Relevant announcements:
- Last checked for changes:

## Asset and method mapping

| Planned asset/action | Exact brief entry | Allowed methods | Exclusions | Evidence / section |
| --- | --- | --- | --- | --- |

## Automation and traffic

- Automation policy: unknown
- Request budget / rate / concurrency: unknown
- Identification requirements:
- Redirect / third-party constraints:
- Permitted time window:

## Accounts, objects and data

Owned accounts and roles; tenant relationships; synthetic objects; data minimization; permitted callbacks; state changes; cleanup.

## Reporting

Required format, submission route, disclosure constraints and user handoff.

## Unknowns

Record unresolved scope interpretations. Do not convert unknown to permission.

## Testing readiness

Asset permitted? Method permitted? Technical prerequisites met? Matching execution grant? Any missing condition keeps the proposed test pending.
