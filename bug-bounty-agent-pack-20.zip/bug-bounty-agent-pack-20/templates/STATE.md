# Campaign State

- Campaign ID:
- Last updated with timezone:
- Current objective:
- Mode: public-research
- Scope snapshot and last change check:
- Read this next:

## Completed work

| Artifact ID | Outcome | Evidence / file | Limitations |
| --- | --- | --- | --- |

## Active hypotheses

| ID | State | Missing prerequisite | Next discriminating action |
| --- | --- | --- | --- |

## Rejected or parked hypotheses

Record why, supporting evidence and the condition that would justify revisiting.

## Commands and permissions

Record actual commands run, approval IDs, versions and remaining budgets. No grants are assumed.

## Environment

Actual OS, shell, interpreter path/version/build, tools, integrations and known limitations.

## Cleanup

Created synthetic objects, pending cleanup and verification.

## Open questions

Only questions that change a concrete decision.

## One next action

State one bounded action and the evidence it should produce.
