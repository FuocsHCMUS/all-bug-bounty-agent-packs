# O-###: Bounded Control Observation

- Business operation / asset / date:
- Control objective:
- Result: demonstrated for this case / gap demonstrated for this case / potential risk / unknown / not evaluated
- Evidence IDs:
- Exact tested condition and coverage:
- Confidence:
- Observation:
- Inference:
- Unknowns:
- Suggested control improvement or preserved strength:
- Proposed owner role:
- Operational trade-off:
- Verification / regression evidence:
- Residual risk:

Do not turn this sample into a company-wide maturity rating.
