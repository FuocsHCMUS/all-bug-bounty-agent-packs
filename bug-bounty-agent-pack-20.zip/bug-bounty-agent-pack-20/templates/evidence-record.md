# E-###: Evidence Record

- Classification: observed / supplied / synthetic / expected
- Hypothesis / experiment:
- Source and acquisition context:
- Event time / collection time / timezone:
- Collector / tool / version:
- Local path:
- Actual SHA-256, if measured:
- Identity / role / object / ownership context:
- Redactions and transformations:
- Relevant excerpt:
- Claim supported:
- Claims not supported:
- Integrity / provenance limitations:
- Access / retention / cleanup:

Do not invent hashes or logs. Synthetic and expected evidence cannot confirm a live finding.
