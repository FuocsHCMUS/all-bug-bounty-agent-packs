# X-###: Bounded Experiment

- Hypothesis:
- Asset / brief mapping:
- Environment / versions:
- Controlled identities / object ownership:
- Execution approval ID and matching command:
- Budget / rate / concurrency / duration:
- Network destinations and redirects:
- State changes / costs / cleanup:
- Stop conditions:

## Prediction

Expected behavior if the hypothesis is true; expected behavior if the competing explanation is true.

## Procedure

Location, privileges, exact command/inputs, one changed condition and controls. Label unexecuted commands as proposed.

## Actual results

Use NOT EXECUTED until run. Record timestamps, actual output and evidence IDs. Expected output is not a result.

## Interpretation

Supported / rejected / inconclusive; strongest alternative explanation; limits.

## Cleanup verification

Actual actions and evidence, or pending cleanup with owner.
