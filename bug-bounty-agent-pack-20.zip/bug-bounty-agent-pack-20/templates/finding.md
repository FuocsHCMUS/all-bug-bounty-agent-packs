# F-###: Concrete Behavior and Bounded Impact

- Status: draft / reproduced / report-ready / retest pending
- Program and exact scoped asset:
- Related hypothesis / experiment / evidence IDs:
- Environment and relevant versions:

## Summary

Under [preconditions], [principal] can [specific action] on [controlled object] through [path], contrary to [invariant].

## Prerequisites and reproduction

Owned identities, roles, privacy/sharing state, minimal steps, exact relevant inputs and actual outputs.

## Expected versus actual

Explain the semantic decision and controls.

## Evidence

| Claim | Evidence ID / path | Limitation |
| --- | --- | --- |

## Impact

Observed impact first. Separate untested potential impact and its additional prerequisites.

## Severity and confidence

Program model/version; severity rationale; confidence rationale separately. Give a CVSS vector only when assessed against the proper specification.

## Root cause and remediation

Confirmed cause or labelled hypothesis; owner role; permanent fix; temporary mitigation; trade-offs.

## Retest

Original forbidden case, legitimate control and neighboring cases. Link the retest plan.

## Cleanup and limitations

State what was actually cleaned and what remains.

## Submission handoff

Prepared for the user to submit. No automatic submission or public disclosure.
