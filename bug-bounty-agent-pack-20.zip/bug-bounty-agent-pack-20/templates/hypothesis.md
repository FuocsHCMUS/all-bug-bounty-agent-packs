# H-###: Specific Question

- State: candidate / plausible / reproduced / report-ready / rejected / inconclusive
- Created / updated:
- Asset and scoped user journey:
- Related source / evidence IDs:

## Invariant

The condition that must remain true.

## Hypothesis

If [precondition], then [boundary] may fail when [controlled change], observable as [evidence].

## Preconditions

| Condition | Confirmed / contradicted / unknown | Evidence |
| --- | --- | --- |

## Competing explanations

At least one plausible normal explanation and the observation that distinguishes it.

## Experiment

Exact controlled comparison; positive and negative controls; request/state budget; approval needed; cleanup. Link X-###.

## Rejection signal

What result would contradict this hypothesis?

## Result and confidence

Actual result versus expected; evidence IDs; what remains unproven. Severity is separate.

## Next action

One useful discriminating step or reason to stop.
