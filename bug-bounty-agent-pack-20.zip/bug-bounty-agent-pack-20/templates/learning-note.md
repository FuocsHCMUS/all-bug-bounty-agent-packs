# L-###: One Concept From the Investigation

- Level:
- Related hypothesis / experiment / evidence:
- One main concept and up to two supporting concepts:

## Problem and vocabulary

The original problem; one-line definitions at first use.

## Intuition

A simple example and where the analogy stops being accurate.

## Mechanism

Actors, identity, inputs, state, decision and output in causal order.

## Evidence

What was observed; what it proves; what it does not; competing explanation.

## Failure or control that held

Explain the invariant, not just the tool output.

## Defense and production

Prevention, telemetry, investigation, remediation owner, trade-off and regression verification. Mark unknown company details as unknown.

## Beginner mistake

One misconception and how to detect it.

## Teach-back

One to three original questions. Wait for answers during interactive teaching.

## Next practice

A local controlled task and a measurable exit criterion.
