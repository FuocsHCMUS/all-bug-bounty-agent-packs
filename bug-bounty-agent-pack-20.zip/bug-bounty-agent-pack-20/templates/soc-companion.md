# SOC Companion

- Related finding / hypothesis / evidence:
- Observed behavior:
- Entities and trusted identity context:
- Event time / collection time / timezone / clock uncertainty:

## Competing explanations

At least one malicious/unauthorized and one normal explanation when plausible.

## Telemetry

Actual available sources versus sources that would be needed. Required fields and visibility gaps.

## Investigation logic

Exact dialect/schema if verified; otherwise labelled pseudocode.

## Detection validation

Synthetic permitted case, violation case, legitimate exception and missing-data case; expected matches versus measured results.

## False positives / false negatives

Context, sampling, asynchronous paths, joins and retention.

## Assessment and handoff

Severity and confidence separately; next evidence request; owner role; escalation and close criteria. No claim of SOC failure without actual evidence.
