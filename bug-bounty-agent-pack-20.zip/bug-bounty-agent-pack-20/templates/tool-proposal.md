# Concrete Tool / Execution Proposal

- Problem this action answers:
- Existing capability checked:
- Official source and pinned version / revision:
- Local destination / expected size:
- Exact command:
- Working directory:
- Interpreter / runtime / privileges:
- Files / hosts / paths / identities involved:
- Network effects / redirects / callbacks:
- File writes / subprocesses / state changes / costs:
- Budget / concurrency / duration:
- Expected output and interpretation:
- Failure / stop conditions:
- Cleanup / removal:
- Scope evidence:
- Existing matching approval, if any:
- Decision requested:

If proposing MCP/plugin/skill/application installation, provide reviewed configuration with secret placeholders and ask the user to install/enable it.
