"""Offline end-to-end contracts; no network or third-party packages."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "packctl.py"


class PackctlTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def run_cli(self, *args):
        return subprocess.run(
            [sys.executable, str(SCRIPT), *map(str, args)],
            capture_output=True, text=True, timeout=15,
        )

    def test_help_describes_offline_commands(self):
        result = self.run_cli("--help")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("init", result.stdout)
        self.assertIn("manifest", result.stdout)

    def test_init_creates_usable_campaign(self):
        result = self.run_cli("init", "--workspace", self.root, "--name", "first-program")
        self.assertEqual(result.returncode, 0, result.stderr)
        campaign = self.root / "campaigns" / "first-program"
        config = json.loads((campaign / "campaign.json").read_text(encoding="utf-8"))
        self.assertEqual(config["slug"], "first-program")
        self.assertEqual(config["mode"], "public-research")
        self.assertFalse(config["live_testing_enabled"])
        for name in ("STATE.md", "SCOPE.md", "APPROVALS.md", "DECISIONS.md"):
            self.assertTrue((campaign / name).is_file(), name)
        for name in ("research", "hypotheses", "experiments", "findings", "observations", "learning", "evidence"):
            self.assertTrue((campaign / name).is_dir(), name)

    def test_init_refuses_existing_campaign_without_overwrite(self):
        campaign = self.root / "campaigns" / "existing"
        campaign.mkdir(parents=True)
        marker = campaign / "STATE.md"
        marker.write_text("preserve this", encoding="utf-8")
        result = self.run_cli("init", "--workspace", self.root, "--name", "existing")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(marker.read_text(encoding="utf-8"), "preserve this")

    def test_init_rejects_traversal_and_windows_reserved_slugs(self):
        for slug in ("../escape", "..", "nested/path", "UPPER", "with space", "con", "nul", "com1", "lpt9", "bad."):
            with self.subTest(slug=slug):
                result = self.run_cli("init", "--workspace", self.root, "--name", slug)
                self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.root / "campaigns").exists())

    def test_init_rejects_campaigns_symlink(self):
        outside = self.root / "outside"
        outside.mkdir()
        link = self.root / "campaigns"
        try:
            link.symlink_to(outside, target_is_directory=True)
        except OSError:
            self.skipTest("Symlinks unavailable on this host")
        result = self.run_cli("init", "--workspace", self.root, "--name", "first")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(list(outside.iterdir()), [])

    def test_manifest_hashes_binary_files_in_sorted_relative_order(self):
        evidence = self.root / "evidence"
        (evidence / "nested").mkdir(parents=True)
        (evidence / "z.bin").write_bytes(b"\x00\xff\x10")
        (evidence / "nested" / "a.txt").write_bytes(b"synthetic evidence\n")
        result = self.run_cli("manifest", "--evidence", evidence)
        self.assertEqual(result.returncode, 0, result.stderr)
        rows = json.loads(result.stdout)["files"]
        self.assertEqual([r["path"] for r in rows], ["nested/a.txt", "z.bin"])
        self.assertEqual(rows[1]["sha256"], hashlib.sha256(b"\x00\xff\x10").hexdigest())
        self.assertEqual(rows[1]["size_bytes"], 3)

    def test_manifest_is_deterministic(self):
        evidence = self.root / "evidence"
        evidence.mkdir()
        (evidence / "a.txt").write_text("fixed bytes", encoding="utf-8")
        first = self.run_cli("manifest", "--evidence", evidence)
        second = self.run_cli("manifest", "--evidence", evidence)
        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual(first.stdout, second.stdout)

    def test_manifest_accepts_empty_directory(self):
        result = self.run_cli("manifest", "--evidence", self.root)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["files"], [])

    def test_manifest_rejects_missing_directory(self):
        result = self.run_cli("manifest", "--evidence", self.root / "missing")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")

    def test_manifest_rejects_symlinked_file(self):
        evidence = self.root / "evidence"
        evidence.mkdir()
        secret = self.root / "private.txt"
        secret.write_text("do not include", encoding="utf-8")
        try:
            (evidence / "linked.txt").symlink_to(secret)
        except OSError:
            self.skipTest("Symlinks unavailable on this host")
        result = self.run_cli("manifest", "--evidence", evidence)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")

    def test_manifest_rejects_symlinked_directory(self):
        evidence = self.root / "evidence"
        evidence.mkdir()
        outside = self.root / "outside"
        outside.mkdir()
        try:
            (evidence / "linked").symlink_to(outside, target_is_directory=True)
        except OSError:
            self.skipTest("Symlinks unavailable on this host")
        result = self.run_cli("manifest", "--evidence", evidence)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")

    def test_manifest_rejects_symlinked_root(self):
        evidence = self.root / "actual"
        evidence.mkdir()
        link = self.root / "alias"
        try:
            link.symlink_to(evidence, target_is_directory=True)
        except OSError:
            self.skipTest("Symlinks unavailable on this host")
        result = self.run_cli("manifest", "--evidence", link)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")


if __name__ == "__main__":
    unittest.main()
