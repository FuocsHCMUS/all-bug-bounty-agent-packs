# LEARNING-PATH.md - Cybersecurity Learning Roadmap

> A comprehensive learning path for a cybersecurity student, from absolute beginner to professional.

---

## How to Use This Guide

This roadmap is designed for you - a student learning cybersecurity. It starts from the very basics and builds up to advanced topics. Each section explains concepts from the ground up, assuming no prior knowledge.

---

## Level 0: Foundations (Start Here)

### 0.1 How the Internet Works

**What you need to understand:**

**IP Address:** Every device on the internet has a unique address, like a home address. Example: 192.168.1.1. There are two versions: IPv4 (like 192.168.1.1) and IPv6 (like 2001:0db8:85a3::8a2e:0370:7334).

**DNS (Domain Name System):** DNS translates human-readable names (google.com) into IP addresses (142.250.80.46). It is like a phone book for the internet. When you type "google.com" in your browser, DNS looks up the IP address so your computer knows where to connect.

**HTTP/HTTPS:** HTTP (HyperText Transfer Protocol) is how your browser talks to web servers. HTTPS is the secure version that encrypts the communication. Think of HTTP as sending a postcard (anyone can read it) and HTTPS as sending a sealed letter.

**TCP/IP:** The fundamental protocols of the internet. TCP ensures data arrives correctly and in order. IP handles addressing and routing. Together, they are like the postal system of the internet.

**Ports:** Ports are like apartment numbers in a building. The IP address gets you to the building (server), and the port number gets you to the specific apartment (service). Common ports: 80 (HTTP), 443 (HTTPS), 22 (SSH), 21 (FTP), 3306 (MySQL).

**Practice:**
- Open your terminal and run: ping google.com
- Run: nslookup google.com
- Run: traceroute google.com (or tracert on Windows)
- Use browser developer tools (F12) to see HTTP requests

### 0.2 How Web Applications Work

**Client-Server Model:** Your browser (client) sends requests to a web server. The server processes the request and sends back a response. Like ordering food at a restaurant - you (client) tell the waiter (HTTP) what you want, the kitchen (server) makes it, and the waiter brings it back.

**Frontend vs Backend:**
- Frontend: What you see in the browser (HTML, CSS, JavaScript)
- Backend: The server-side code that processes data (Python, Java, PHP, Node.js)
- Database: Where data is stored (MySQL, PostgreSQL, MongoDB)

**HTTP Methods:**
- GET: Retrieve data (like reading a page)
- POST: Send data (like submitting a form)
- PUT: Update data (like editing a profile)
- DELETE: Remove data (like deleting a post)
- PATCH: Partially update data
- OPTIONS: Check what methods are allowed

**HTTP Status Codes:**
- 200: OK (success)
- 301/302: Redirect
- 400: Bad Request
- 401: Unauthorized (not logged in)
- 403: Forbidden (logged in but not allowed)
- 404: Not Found
- 500: Internal Server Error

**Cookies and Sessions:**
Cookies are small pieces of data stored in your browser. Sessions are server-side records of your login state. Together, they keep you logged in. When you log in, the server creates a session and gives you a cookie with the session ID. On each request, your browser sends the cookie so the server knows who you are.

**Practice:**
- Use browser dev tools (F12 > Network tab) to see requests
- Install a proxy tool (Burp Suite Community) and intercept requests
- Build a simple web app with Flask or Express.js

### 0.3 Linux Basics

**Why Linux?** Most security tools run on Linux. Most servers run Linux. You need to be comfortable with the command line.

**Essential Commands:**
```bash
ls          # List files
cd          # Change directory
pwd         # Print working directory
cat         # Display file contents
grep        # Search text patterns
find        # Find files
chmod       # Change permissions
curl        # Make HTTP requests
wget        # Download files
nmap        # Network scanning
pip/pip3    # Python package manager
git         # Version control
```

**Practice:**
- Install a Linux VM (Ubuntu or Kali Linux)
- Complete OverTheWire Bandit: https://overthewire.org/wargames/bandit/
- Use the terminal for everything for one week

---

## Level 1: Security Fundamentals

### 1.1 CIA Triad

The three pillars of information security:

**Confidentiality:** Information is only accessible to authorized people. Like a diary with a lock - only you should read it.

**Integrity:** Information has not been tampered with. Like a sealed envelope - you know nobody changed the letter inside.

**Availability:** Information and systems are accessible when needed. Like a hospital that must be open 24/7 - downtime is not acceptable.

### 1.2 Authentication vs Authorization

**Authentication (AuthN):** Proving WHO you are. Like showing your ID at a bar.
**Authorization (AuthZ):** Proving WHAT you can do. Like the bouncer checking if you are on the VIP list.

You can be authenticated (proven identity) but not authorized (not allowed to do something).

### 1.3 Encryption Basics

**Symmetric Encryption:** Same key to encrypt and decrypt. Like a padlock where both people have the same key. Fast but key distribution is a problem. Examples: AES, ChaCha20.

**Asymmetric Encryption:** Two keys - public (encrypt) and private (decrypt). Like a mailbox - anyone can put mail in (public key) but only you can open it (private key). Slower but solves key distribution. Examples: RSA, ECC.

**Hashing:** One-way function that converts data to a fixed-size string. Like a fingerprint - you can create it from a person but cannot recreate the person from a fingerprint. Used for passwords. Examples: SHA-256, bcrypt.

### 1.4 OWASP Top 10

The most critical web application security risks:
1. Broken Access Control
2. Cryptographic Failures
3. Injection
4. Insecure Design
5. Security Misconfiguration
6. Vulnerable and Outdated Components
7. Identification and Authentication Failures
8. Software and Data Integrity Failures
9. Security Logging and Monitoring Failures
10. Server-Side Request Forgery (SSRF)

Study each one at: https://owasp.org/Top10/

---

## Level 2: Hands-On Practice

### 2.1 Practice Platforms

**For Absolute Beginners:**
- TryHackMe: https://tryhackme.com/ (guided rooms, very beginner-friendly)
- PortSwigger Web Security Academy: https://portswigger.net/web-security (free, excellent)
- OWASP WebGoat: https://owasp.org/www-project-webgoat/ (intentionally vulnerable app)

**For Intermediate:**
- HackTheBox: https://www.hackthebox.com/ (more challenging)
- PentesterLab: https://pentesterlab.com/ (structured exercises)
- VulnHub: https://www.vulnhub.com/ (downloadable VMs)

**For Advanced:**
- CTF competitions: https://ctftime.org/
- Real bug bounty programs
- Custom lab environments

### 2.2 Recommended Learning Order

1. Complete TryHackMe "Pre Security" path
2. Complete TryHackMe "Introduction to Cyber Security" path
3. Complete PortSwigger Web Security Academy (all labs)
4. Start HackTheBox easy machines
5. Participate in CTF competitions
6. Start bug bounty on easy programs

---

## Level 3: Specialization Paths

### Path A: Penetration Tester
- Web application testing
- Network penetration testing
- Mobile application testing
- Cloud security testing
- Certifications: OSCP, OSWE, BSCP

### Path B: SOC Analyst
- Log analysis and SIEM
- Incident response
- Threat hunting
- Malware analysis basics
- Certifications: CompTIA Security+, CySA+, BTL1

### Path C: Bug Bounty Hunter
- Web application security (deep)
- API security
- Mobile security
- Creative thinking and chaining
- No certification needed - your track record is your resume

### Path D: Security Engineer
- Secure coding practices
- Security architecture
- DevSecOps
- Cloud security
- Certifications: CISSP, AWS Security Specialty

### Path E: Red Team Operator
- Advanced penetration testing
- Social engineering
- Physical security
- Custom tool development
- Certifications: OSCP, CRTO, CRTE

---

## Level 4: Advanced Topics

### 4.1 Advanced Web Attacks
- HTTP Request Smuggling
- Web Cache Poisoning
- Prototype Pollution
- Deserialization Attacks
- Race Conditions
- DOM Clobbering

### 4.2 Cloud Security
- AWS/Azure/GCP security
- Container security (Docker, Kubernetes)
- Serverless security
- IAM misconfigurations

### 4.3 Mobile Security
- Android application testing
- iOS application testing
- API security for mobile apps
- Certificate pinning bypass

### 4.4 Binary Exploitation
- Buffer overflows
- Format string vulnerabilities
- Return-oriented programming (ROP)
- Heap exploitation

---

## Daily Practice Routine

**Beginner (1-2 hours/day):**
- 30 min: Read a writeup or blog post
- 30 min: Practice on TryHackMe or PortSwigger
- 30 min: Learn a new tool or technique

**Intermediate (2-4 hours/day):**
- 1 hour: Bug bounty hunting
- 1 hour: Practice on HackTheBox
- 30 min: Read writeups
- 30 min: Tool development/scripting

**Advanced (4+ hours/day):**
- 2-3 hours: Active bug bounty hunting
- 1 hour: Research new techniques
- 30 min: Read academic papers or research
- 30 min: Community engagement

---

## Essential Resources

### Books
- "The Web Application Hacker Handbook" by Dafydd Stuttard
- "Bug Bounty Bootcamp" by Vickie Li
- "Real-World Bug Hunting" by Peter Yaworski
- "Hacking: The Art of Exploitation" by Jon Erickson
- "The Tangled Web" by Michal Zalewski

### YouTube Channels
- NahamSec (bug bounty)
- STOK (bug bounty)
- LiveOverflow (CTF and research)
- John Hammond (CTF and security)
- IppSec (HackTheBox walkthroughs)
- PwnFunction (web security concepts)
- NetworkChuck (networking basics)

### Twitter/X Accounts to Follow
- @NahamSec, @staboratory, @orange_8361
- @albinowax, @garaboreth, @samaboretcurry
- @InsiderPhD, @haaboretkleys, @LiveOverflow

### Newsletters
- tl;dr sec: https://tldrsec.com/
- Bug Bytes: https://blog.intigriti.com/category/bugbytes/
- Pentester Land: https://pentester.land/newsletter/
