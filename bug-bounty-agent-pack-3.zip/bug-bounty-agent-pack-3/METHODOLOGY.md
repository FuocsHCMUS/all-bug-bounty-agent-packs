# METHODOLOGY.md - Complete Bug Bounty Hunting Methodology

> A systematic, step-by-step approach to finding vulnerabilities in bug bounty programs.

---

## Phase 0: Program Selection and Scope Review

### 0.1 Choosing a Program

**Where to find programs:**
- HackerOne: https://hackerone.com/directory/programs
- Bugcrowd: https://bugcrowd.com/programs
- Intigriti: https://www.intigriti.com/programs
- YesWeHack: https://yeswehack.com/programs
- Synack (invite-only)
- Company security pages (e.g., security.google.com)

**Selection criteria:**
- Program maturity (newer programs = more low-hanging fruit)
- Scope breadth (wider scope = more attack surface)
- Bounty amounts (balance effort vs reward)
- Response time (faster triage = better experience)
- Technology stack (match your skills)
- Exclusions (avoid programs with too many restrictions)

**Beginner Concept:**
Think of bug bounty programs like job listings. Each company posts what they want tested (scope), what they will pay (bounty table), and their rules. Start with programs that have wide scope and are responsive. Avoid programs that have been running for years with hundreds of hackers - the easy bugs are already found.

### 0.2 Reading the Scope

CRITICAL - Read EVERYTHING:
- In-scope domains, IPs, applications
- Out-of-scope assets (DO NOT TOUCH)
- Allowed testing methods
- Prohibited actions
- Severity ratings and bounty amounts
- Safe harbor provisions
- Disclosure policy
- Special instructions

---

## Phase 1: Passive Reconnaissance

### 1.1 Domain Intelligence

```bash
# WHOIS lookup
whois target.com

# DNS records
dig target.com ANY
dig target.com A
dig target.com MX
dig target.com TXT
dig target.com NS

# Reverse DNS
dig -x <IP>

# Certificate Transparency
curl -s "https://crt.sh/?q=%25.target.com&output=json" | jq -r ".[].name_value" | sort -u

# Wayback Machine URLs
echo target.com | waybackurls | sort -u > wayback_urls.txt

# Google Dorking
# site:target.com
# site:target.com filetype:pdf
# site:target.com inurl:admin
# site:target.com intitle:"index of"
# site:target.com ext:php inurl:config
```

**Beginner Concept:**
Passive recon is gathering intel without touching the target. WHOIS tells you who registered the domain. DNS records show what servers handle email, web traffic, etc. Certificate Transparency logs reveal all SSL certificates issued for a domain - which reveals subdomains. Google dorking uses advanced search operators to find interesting pages indexed by Google.

### 1.2 Technology Identification

```bash
# Check HTTP headers
curl -I https://target.com

# Analyze response for tech clues
curl -s https://target.com | grep -i "powered by\|generator\|framework"

# Check robots.txt and sitemap
curl -s https://target.com/robots.txt
curl -s https://target.com/sitemap.xml
```

### 1.3 GitHub and Code Repository Search

```
# Search GitHub for:
"target.com" password
"target.com" secret
"target.com" api_key
"target.com" token
org:targetcompany password
org:targetcompany secret_key
```

---

## Phase 2: Active Reconnaissance

### 2.1 Subdomain Enumeration

```bash
# Multiple tools for comprehensive coverage
subfinder -d target.com -o subdomains_subfinder.txt
amass enum -passive -d target.com -o subdomains_amass.txt
assetfinder --subs-only target.com > subdomains_assetfinder.txt

# Combine and deduplicate
cat subdomains_*.txt | sort -u > all_subdomains.txt

# Check which are alive
cat all_subdomains.txt | httpx -silent -status-code -title -tech-detect -o alive_subdomains.txt

# DNS resolution
cat all_subdomains.txt | dnsx -silent -a -resp -o resolved_subdomains.txt
```

### 2.2 Port Scanning

```bash
# Quick scan of common ports
nmap -sV -sC -T4 --top-ports 1000 target.com -oN nmap_quick.txt

# Full port scan
nmap -sV -p- -T4 target.com -oN nmap_full.txt

# UDP scan (top ports)
nmap -sU --top-ports 100 target.com -oN nmap_udp.txt
```

### 2.3 Directory and File Discovery

```bash
# Fast fuzzing with ffuf
ffuf -u https://target.com/FUZZ -w /path/to/wordlist.txt -mc 200,301,302,403 -o ffuf_results.json

# API endpoint discovery
ffuf -u https://target.com/api/FUZZ -w /path/to/api-wordlist.txt -mc 200,201,401,403

# Backup file discovery
ffuf -u https://target.com/FUZZ -w /path/to/backup-wordlist.txt -e .bak,.old,.backup,.swp,.git
```

### 2.4 JavaScript Analysis

```bash
# Collect JS files
katana -u https://target.com -jc -d 3 -o js_urls.txt

# Extract endpoints from JS
cat js_urls.txt | grep "\.js$" | while read url; do
  curl -s "$url" | grep -oP "['\"][/][a-zA-Z0-9_/\-\.]+['\"]" 
done | sort -u > js_endpoints.txt

# Search for secrets in JS
cat js_urls.txt | grep "\.js$" | while read url; do
  curl -s "$url" | grep -iE "api[_-]?key|secret|token|password|auth" 
done > js_secrets.txt
```

---

## Phase 3: Vulnerability Discovery

### 3.1 Automated Scanning

```bash
# Nuclei - template-based scanning
nuclei -u https://target.com -t cves/ -o nuclei_cves.txt
nuclei -u https://target.com -t vulnerabilities/ -o nuclei_vulns.txt
nuclei -u https://target.com -t misconfiguration/ -o nuclei_misconfig.txt
nuclei -u https://target.com -t exposures/ -o nuclei_exposures.txt

# Scan all subdomains
nuclei -l alive_subdomains.txt -t cves/ -o nuclei_all_cves.txt
```

### 3.2 Manual Testing Checklist

**Authentication:**
- [ ] Test default credentials
- [ ] Test brute force protection
- [ ] Test password reset flow
- [ ] Test 2FA bypass
- [ ] Test session management
- [ ] Test remember me functionality
- [ ] Test OAuth/SSO flows
- [ ] Test JWT implementation

**Authorization:**
- [ ] Test IDOR on all endpoints
- [ ] Test horizontal privilege escalation
- [ ] Test vertical privilege escalation
- [ ] Test API authorization
- [ ] Test direct object references
- [ ] Test function-level access control

**Injection:**
- [ ] Test SQL injection on all inputs
- [ ] Test XSS (reflected, stored, DOM)
- [ ] Test SSTI on template-rendered inputs
- [ ] Test command injection
- [ ] Test XXE on XML inputs
- [ ] Test LDAP injection
- [ ] Test header injection

**Server-Side:**
- [ ] Test SSRF on URL inputs
- [ ] Test file upload vulnerabilities
- [ ] Test deserialization issues
- [ ] Test race conditions
- [ ] Test business logic flaws

**Configuration:**
- [ ] Check security headers
- [ ] Check CORS configuration
- [ ] Check CSP policy
- [ ] Check cookie flags
- [ ] Check TLS configuration
- [ ] Check error handling
- [ ] Check information disclosure

---

## Phase 4: Exploitation and Validation

### 4.1 Confirming Vulnerabilities

For each potential finding:
1. Reproduce the issue at least 3 times
2. Document exact steps
3. Capture HTTP requests/responses
4. Create a minimal PoC
5. Assess real-world impact
6. Check if it is a duplicate

### 4.2 Vulnerability Chaining

Look for chains:
- Information Disclosure + IDOR = Account Takeover
- XSS + CSRF = Privilege Escalation
- SSRF + Cloud Metadata = RCE
- Open Redirect + OAuth = Token Theft
- Race Condition + Business Logic = Financial Impact
- Subdomain Takeover + Cookie Scope = Session Hijacking

---

## Phase 5: Reporting

See REPORTING-TEMPLATE.md for detailed templates.

Key principles:
1. Clear, descriptive title
2. Accurate severity (use CVSS calculator)
3. Complete reproduction steps (assume reader knows nothing)
4. Working PoC (code, screenshots, or video)
5. Real-world impact (not theoretical)
6. Actionable remediation
7. Professional tone

---

## Phase 6: Learning and Improvement

After each session:
1. What vulnerabilities did I find?
2. What techniques worked?
3. What did I miss and why?
4. What new techniques did I learn?
5. What tools should I add to my arsenal?
6. What areas need more practice?
7. Document lessons learned
