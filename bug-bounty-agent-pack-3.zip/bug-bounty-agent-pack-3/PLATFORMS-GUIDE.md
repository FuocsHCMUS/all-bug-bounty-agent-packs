# PLATFORMS-GUIDE.md - Bug Bounty Platform Guide

> How to navigate and use major bug bounty platforms effectively.

---

## What Are Bug Bounty Platforms?

**Beginner Explanation:**
Bug bounty platforms are like job marketplaces for hackers. Companies post their applications and say "find bugs in our stuff, and we will pay you." The platform handles the communication, payment, and legal protection. Think of it like Uber, but instead of driving people, you are finding security bugs.

---

## Platform 1: HackerOne

**URL:** https://hackerone.com
**Type:** Largest bug bounty platform
**Best for:** Wide variety of programs, good reputation system

### Getting Started
1. Create account at https://hackerone.com/users/sign_up
2. Complete your profile
3. Browse programs at https://hackerone.com/directory/programs
4. Start with programs that have wide scope and are responsive

### Finding Programs
- **Directory:** https://hackerone.com/directory/programs
- Filter by: bounty amount, response time, program type
- Look for: "Managed" programs (faster triage)
- Check: response efficiency metrics

### Hacktivity (Learning from Others)
- **URL:** https://hackerone.com/hacktivity
- Browse disclosed reports
- Filter by severity, program, vulnerability type
- Study how top hackers write reports
- Learn new techniques from real findings

### Reputation System
- Signal: Quality of your reports (higher is better)
- Impact: Severity of your findings
- Reputation: Overall score
- Higher reputation = access to private programs = bigger bounties

### Tips for HackerOne
- Start with public programs
- Write excellent reports (quality over quantity)
- Build reputation to get invited to private programs
- Private programs have less competition and higher bounties
- Respond promptly to triage questions
- Be professional and patient

---

## Platform 2: Bugcrowd

**URL:** https://bugcrowd.com
**Type:** Major bug bounty platform with VRT
**Best for:** Structured vulnerability rating, good for beginners

### Getting Started
1. Create account at https://bugcrowd.com/user/sign_up
2. Complete your profile and skills assessment
3. Browse programs at https://bugcrowd.com/programs
4. Read the Vulnerability Rating Taxonomy (VRT)

### Vulnerability Rating Taxonomy (VRT)
- Bugcrowd uses VRT to standardize severity ratings
- URL: https://bugcrowd.com/vulnerability-rating-taxonomy
- Helps you understand what severity your finding will receive
- Study this to set proper expectations

### Crowdstream
- Community feed of activity
- See what others are finding
- Learn from community discussions

### Tips for Bugcrowd
- Understand the VRT before submitting
- Use the submission form completely
- Include all required fields
- Follow up on submissions professionally

---

## Platform 3: Intigriti

**URL:** https://www.intigriti.com
**Type:** European bug bounty platform
**Best for:** European companies, good community

### Key Features
- Strong European presence
- Good triage team
- Community events and challenges
- Transparent program metrics

---

## Platform 4: YesWeHack

**URL:** https://yeswehack.com
**Type:** European bug bounty platform
**Best for:** French/European companies, DOJO training

### Key Features
- DOJO: Training platform for learning
- Strong European client base
- Good for beginners with training resources

---

## Platform 5: Synack

**URL:** https://www.synack.com
**Type:** Invite-only, premium platform
**Best for:** Experienced hunters, higher payouts

### Key Features
- Invite-only (requires application and assessment)
- Higher bounties on average
- Less competition
- Requires passing technical assessment
- Uses their own testing platform (LaunchPoint)

---

## Choosing Your First Program

### For Absolute Beginners:
1. Start with programs that accept all vulnerability types
2. Choose programs with wide scope (*.target.com)
3. Look for programs with fast response times
4. Avoid programs with hundreds of resolved reports (picked clean)
5. Consider programs with lower bounties but less competition

### Program Selection Checklist:
- [ ] Is the scope clear and wide enough?
- [ ] Are the bounty amounts reasonable for the effort?
- [ ] Is the response time acceptable?
- [ ] Are there any testing restrictions I need to follow?
- [ ] Does the technology stack match my skills?
- [ ] How many hackers are already active on this program?
- [ ] Are there disclosed reports I can learn from?

---

## Submitting Reports

### Before Submitting:
1. Verify the vulnerability is real (reproduce 3 times)
2. Check it is in scope
3. Search for duplicates in disclosed reports
4. Write a clear, complete report (use REPORTING-TEMPLATE.md)
5. Include a working PoC
6. Assess severity accurately (do not over-inflate)

### After Submitting:
1. Be patient (triage can take days to weeks)
2. Respond promptly to questions
3. Provide additional information if requested
4. Be professional even if you disagree with triage
5. Learn from feedback

### Common Rejection Reasons:
- Out of scope
- Duplicate (someone reported it first)
- Informational / no security impact
- Known issue / accepted risk
- Insufficient evidence
- Not reproducible

### How to Avoid Rejections:
- Read scope carefully
- Demonstrate real impact
- Provide complete reproduction steps
- Include working PoC
- Be honest about severity

---

## Building Your Reputation

### Short-term (0-3 months):
- Submit high-quality reports on public programs
- Focus on quality over quantity
- Learn from every interaction with triage
- Read disclosed reports daily

### Medium-term (3-12 months):
- Get invited to private programs
- Specialize in specific vulnerability types
- Build relationships with program teams
- Participate in live hacking events

### Long-term (1+ years):
- Become a top researcher on platforms
- Get invited to exclusive programs
- Speak at conferences about your findings
- Mentor other researchers
- Consider full-time bug bounty or security consulting

---

## Platform Comparison

| Feature | HackerOne | Bugcrowd | Intigriti | YesWeHack | Synack |
|---------|-----------|----------|-----------|-----------|--------|
| Programs | 2000+ | 1000+ | 200+ | 500+ | 100+ |
| Avg Bounty | Varies | Varies | Varies | Varies | Higher |
| Beginner Friendly | Yes | Yes | Yes | Yes | No |
| Private Programs | Yes | Yes | Yes | Yes | All |
| Training | CTF | University | Community | DOJO | Assessment |
| Triage Speed | Varies | Varies | Good | Good | Fast |
| Payment | PayPal/Bank | PayPal/Bank | Bank | Bank | Bank |
