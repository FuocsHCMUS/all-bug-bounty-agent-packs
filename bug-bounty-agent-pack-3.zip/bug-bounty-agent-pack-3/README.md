# Bug Bounty Agent Pack v3

> A comprehensive AI agent prompt pack for autonomous bug bounty hunting, vulnerability research, exploit development, and cybersecurity education.

---

## What Is This?

This pack transforms AI coding agents into elite bug bounty hunters. It provides structured prompts, methodologies, and reference materials that enable AI agents to:

1. **Hunt bugs autonomously** on authorized bug bounty programs
2. **Research CVEs** and map them to target technologies
3. **Develop creative exploits** and chain vulnerabilities
4. **Generate professional reports** with full reproduction steps
5. **Teach cybersecurity** concepts from the ground up
6. **Assess security posture** of target organizations

---

## Supported AI Agents

| Agent | Config File | Description |
|-------|------------|-------------|
| Claude Code | `AGENTS.md` | Primary agent config (new AGENTS.md format) |
| Cline | `.clinerules` | VS Code extension config |
| Cursor | `.cursorrules` | Cursor IDE config |
| OpenAI Codex | `CODEX.md` | Codex CLI config |
| opencode | `OPENCODE.md` | opencode config |
| Antigravity | `ANTIGRAVITY.md` | Antigravity config |

---

## File Structure

```
bug-bounty-agent-pack-3/
|
|-- AGENTS.md              # Core agent directives (Claude Code)
|-- SKILL.md               # Skills and competency definitions
|-- RULES.md               # Legal, ethical, and operational rules
|-- .clinerules            # Cline agent configuration
|-- .cursorrules           # Cursor agent configuration
|-- CODEX.md               # OpenAI Codex configuration
|-- OPENCODE.md            # opencode configuration
|-- ANTIGRAVITY.md         # Antigravity configuration
|-- METHODOLOGY.md         # Complete hunting methodology
|-- CVE-RESEARCH.md        # CVE research and mapping guide
|-- EXPLOIT-TECHNIQUES.md  # Exploit techniques catalog
|-- RECON-PLAYBOOK.md      # Reconnaissance playbook
|-- TOOLS-ARSENAL.md       # Security tools reference
|-- PLATFORMS-GUIDE.md     # Bug bounty platform guide
|-- REPORTING-TEMPLATE.md  # Report templates
|-- SECURITY-ASSESSMENT.md # Security posture analysis guide
|-- WRITEUP-ANALYSIS.md    # Learning from writeups guide
|-- LEARNING-PATH.md       # Cybersecurity learning roadmap
|-- WORKFLOW-AUTOMATION.md # Automation scripts and workflows
|-- README.md              # This file
```

---

## Quick Start

### For Claude Code:
1. Copy this folder to your project root
2. Claude Code will automatically read `AGENTS.md`
3. Ask: "Hunt bugs on [target program]"

### For Cline:
1. Copy `.clinerules` to your project root
2. Cline will read the rules automatically
3. Ask: "Start bug bounty hunting on [target]"

### For Cursor:
1. Copy `.cursorrules` to your project root
2. Cursor will apply the rules
3. Ask: "Find vulnerabilities in [target]"

### For Codex:
1. Reference `CODEX.md` in your Codex configuration
2. Ask: "Run bug bounty workflow on [target]"

### For opencode:
1. Reference `OPENCODE.md` in your configuration
2. Ask: "Start security testing on [target]"

### For Antigravity:
1. Reference `ANTIGRAVITY.md` in your configuration
2. Ask: "Begin bug bounty hunting on [target]"

---

## Key Features

### Autonomous Hunting
The agent follows a systematic methodology to discover vulnerabilities without constant guidance.

### CVE Research
Automatically identifies technologies, searches CVE databases, and checks for known vulnerabilities.

### Creative Exploitation
Goes beyond checklists - chains vulnerabilities, bypasses security controls, and develops novel techniques.

### Professional Reporting
Generates detailed, professional bug reports ready for submission to bug bounty platforms.

### Security Education
Every finding comes with learning notes that explain concepts from absolute basics, perfect for cybersecurity students.

### Security Posture Analysis
Assesses the overall security maturity of target organizations, identifying strengths, weaknesses, and risks.

---

## Ethics and Legal

This pack is designed for AUTHORIZED security testing only:
- Only test targets with explicit permission (bug bounty programs)
- Follow all program rules and scope restrictions
- Practice responsible disclosure
- Never perform destructive actions
- Respect privacy and data handling requirements

---

## For Cybersecurity Students

This pack is designed with learning in mind. Every file includes:
- **Beginner explanations** of complex concepts
- **Real-world analogies** to make concepts relatable
- **Step-by-step breakdowns** from fundamentals
- **Career path mapping** for different security roles
- **Practice resources** and recommended learning platforms
- **Reading lists** and community resources

See `LEARNING-PATH.md` for a complete cybersecurity learning roadmap.

---

## Version

**v3.0** - October 2026

## License

For educational and authorized security testing purposes only.
