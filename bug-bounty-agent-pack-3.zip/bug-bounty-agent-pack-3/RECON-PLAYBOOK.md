# RECON-PLAYBOOK.md - Comprehensive Reconnaissance Playbook

> Step-by-step reconnaissance procedures for bug bounty hunting.

---

## Overview

Reconnaissance is the MOST important phase of bug bounty hunting. The more you know about your target, the more attack surface you can test. Many top hunters spend 80% of their time on recon and 20% on exploitation.

**Beginner Analogy:**
Recon is like studying for an exam. The more you study (recon), the better you perform on the test (finding bugs). Skipping recon is like walking into an exam blind.

---

## Stage 1: OSINT (Open Source Intelligence)

### 1.1 Domain Information
```bash
# WHOIS - Who owns the domain?
whois target.com
# Look for: registrant org, email, name servers, creation date

# Historical WHOIS
# Use: https://whois-history.whoisxmlapi.com/

# Reverse WHOIS - Find other domains by same registrant
# Use: https://viewdns.info/reversewhois/
```

### 1.2 DNS Intelligence
```bash
# All DNS records
dig target.com ANY +noall +answer
dig target.com A
dig target.com AAAA
dig target.com MX
dig target.com TXT
dig target.com NS
dig target.com SOA
dig target.com CNAME

# SPF record (email security)
dig target.com TXT | grep spf

# DMARC record
dig _dmarc.target.com TXT

# DKIM
dig selector._domainkey.target.com TXT

# Zone transfer attempt (usually blocked)
dig axfr target.com @ns1.target.com

# DNS history
# Use: https://securitytrails.com/
```

### 1.3 Certificate Transparency
```bash
# Find subdomains via CT logs
curl -s "https://crt.sh/?q=%25.target.com&output=json" | jq -r ".[].name_value" | sed "s/\\*\\.//" | sort -u > ct_subdomains.txt

# Alternative: Censys
# https://search.censys.io/
```

### 1.4 Web Archives
```bash
# Wayback Machine URLs
echo target.com | waybackurls > wayback_urls.txt

# GAU (GetAllUrls) - multiple sources
echo target.com | gau --threads 5 > gau_urls.txt

# Filter interesting URLs
cat gau_urls.txt | grep -iE "admin|login|api|config|backup|test|dev|staging" > interesting_urls.txt

# Find parameters
cat gau_urls.txt | grep "=" | sort -u > parameterized_urls.txt
```

### 1.5 Google Dorking
```
# Find subdomains
site:target.com

# Find login pages
site:target.com inurl:login OR inurl:signin OR inurl:admin

# Find exposed files
site:target.com filetype:pdf OR filetype:doc OR filetype:xls
site:target.com filetype:env OR filetype:log OR filetype:sql
site:target.com filetype:xml OR filetype:json OR filetype:yaml

# Find directories
site:target.com intitle:"index of"

# Find error pages (info disclosure)
site:target.com intext:"error" OR intext:"warning" OR intext:"stack trace"

# Find config files
site:target.com inurl:config OR inurl:setup OR inurl:install

# Find API documentation
site:target.com inurl:api OR inurl:swagger OR inurl:graphql
```

### 1.6 GitHub Recon
```
# Search for secrets
"target.com" password
"target.com" api_key
"target.com" secret
"target.com" token
"target.com" AWS_ACCESS_KEY
org:targetorg password
org:targetorg secret
org:targetorg api_key

# Search for internal URLs
"target.com" inurl:internal
"target.com" staging
"target.com" dev

# Tools
trufflehog git https://github.com/targetorg/repo
gitleaks detect --source /path/to/repo
```

### 1.7 Shodan/Censys
```
# Shodan queries
org:"Target Company"
hostname:target.com
ssl.cert.subject.cn:target.com
http.title:"Target Company"

# Censys queries
services.tls.certificates.leaf.names: target.com
```

---

## Stage 2: Subdomain Enumeration

### 2.1 Passive Enumeration
```bash
# Multiple tools for coverage
subfinder -d target.com -all -o subfinder.txt
amass enum -passive -d target.com -o amass.txt
assetfinder --subs-only target.com > assetfinder.txt
findomain -t target.com -q > findomain.txt

# Combine results
cat subfinder.txt amass.txt assetfinder.txt findomain.txt | sort -u > all_subs.txt
echo "[*] Total unique subdomains: $(wc -l < all_subs.txt)"
```

### 2.2 Active Enumeration
```bash
# DNS brute force
puredns bruteforce /path/to/dns-wordlist.txt target.com -r resolvers.txt -w bruteforce_subs.txt

# Permutation scanning
gotator -sub all_subs.txt -perm /path/to/permutations.txt -depth 1 -numbers 10 -md 3 | dnsx -silent > permutation_subs.txt

# Add to master list
cat all_subs.txt bruteforce_subs.txt permutation_subs.txt | sort -u > final_subs.txt
```

### 2.3 Alive Check
```bash
# Check which subdomains are alive
cat final_subs.txt | httpx -silent -status-code -title -tech-detect -follow-redirects -o alive_hosts.txt

# DNS resolution
cat final_subs.txt | dnsx -silent -a -resp -o resolved_dns.txt

# Screenshot alive hosts
gowitness file -f alive_hosts.txt -P screenshots/
```

---

## Stage 3: Port and Service Scanning

```bash
# Extract IPs from resolved subdomains
cat resolved_dns.txt | awk "{print $2}" | sort -u > ips.txt

# Quick port scan
nmap -sV -sC -T4 --top-ports 1000 -iL ips.txt -oN nmap_quick.txt

# Full port scan (slower but thorough)
nmap -sV -p- -T4 -iL ips.txt -oN nmap_full.txt

# Masscan for speed
masscan -iL ips.txt -p1-65535 --rate 10000 -oG masscan_results.txt
```

---

## Stage 4: Web Application Mapping

### 4.1 Technology Fingerprinting
```bash
# Detect technologies
cat alive_hosts.txt | httpx -tech-detect -status-code -title -content-length -o tech_detect.txt

# Wappalyzer-style detection
whatweb -i alive_hosts.txt --log-brief whatweb_results.txt
```

### 4.2 Directory and File Discovery
```bash
# Fast fuzzing
ffuf -u https://target.com/FUZZ -w /path/to/wordlist.txt -mc 200,301,302,403 -recursion -recursion-depth 2 -o ffuf_dirs.json

# API discovery
ffuf -u https://target.com/api/FUZZ -w /path/to/api-wordlist.txt -mc all -fc 404

# Common sensitive files
ffuf -u https://target.com/FUZZ -w /path/to/sensitive-files.txt -mc 200
# .env, .git/config, .htaccess, web.config, phpinfo.php, etc.
```

### 4.3 JavaScript Analysis
```bash
# Crawl for JS files
katana -u https://target.com -jc -d 3 -ef css,png,jpg,gif,svg,woff -o crawled_urls.txt

# Extract JS files
cat crawled_urls.txt | grep "\.js$" | sort -u > js_files.txt

# Analyze JS for endpoints and secrets
cat js_files.txt | while read url; do
  echo "=== $url ==="
  curl -s "$url" | grep -oP "(https?://[^\"\s]+|/api/[^\"\s]+|/v[0-9]/[^\"\s]+)" | sort -u
done > js_endpoints.txt

# Search for secrets
cat js_files.txt | while read url; do
  curl -s "$url" | grep -iE "(api[_-]?key|secret|token|password|auth|credential|private[_-]?key)\s*[:=]" 
done > js_secrets.txt
```

### 4.4 Parameter Discovery
```bash
# Discover parameters
arjun -u https://target.com/endpoint -m GET POST
paramspider -d target.com

# From archived URLs
cat gau_urls.txt | grep "?" | unfurl keys | sort -u > parameters.txt
```

---

## Stage 5: Vulnerability Surface Mapping

```bash
# Create a summary of attack surface
echo "=== ATTACK SURFACE SUMMARY ==="
echo "Subdomains found: $(wc -l < final_subs.txt)"
echo "Alive hosts: $(wc -l < alive_hosts.txt)"
echo "Open ports: $(grep -c "open" nmap_quick.txt)"
echo "JS files: $(wc -l < js_files.txt)"
echo "Parameters: $(wc -l < parameters.txt)"
echo "Interesting URLs: $(wc -l < interesting_urls.txt)"

# Prioritize targets
# 1. Hosts with interesting technologies
# 2. Endpoints with parameters
# 3. API endpoints
# 4. Admin panels
# 5. File upload functionality
# 6. Authentication endpoints
```

---

## Recon Automation Script

```bash
#!/bin/bash
# recon.sh - Automated reconnaissance script
# Usage: ./recon.sh target.com

TARGET=$1
OUTDIR="recon_$TARGET"
mkdir -p $OUTDIR

echo "[*] Starting recon on $TARGET"

# Subdomain enumeration
echo "[*] Enumerating subdomains..."
subfinder -d $TARGET -silent > $OUTDIR/subs.txt
echo "[+] Found $(wc -l < $OUTDIR/subs.txt) subdomains"

# Alive check
echo "[*] Checking alive hosts..."
cat $OUTDIR/subs.txt | httpx -silent -status-code -title > $OUTDIR/alive.txt
echo "[+] Found $(wc -l < $OUTDIR/alive.txt) alive hosts"

# Technology detection
echo "[*] Detecting technologies..."
cat $OUTDIR/subs.txt | httpx -silent -tech-detect > $OUTDIR/tech.txt

# URL collection
echo "[*] Collecting URLs..."
echo $TARGET | gau --threads 5 > $OUTDIR/urls.txt
echo "[+] Found $(wc -l < $OUTDIR/urls.txt) URLs"

# Nuclei scan
echo "[*] Running nuclei..."
nuclei -l $OUTDIR/alive.txt -severity critical,high -silent > $OUTDIR/nuclei.txt
echo "[+] Nuclei findings: $(wc -l < $OUTDIR/nuclei.txt)"

echo "[*] Recon complete! Results in $OUTDIR/"
```
