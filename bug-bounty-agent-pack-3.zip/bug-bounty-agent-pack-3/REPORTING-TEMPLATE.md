# REPORTING-TEMPLATE.md - Bug Bounty Report Templates

> Professional templates for reporting vulnerabilities to bug bounty programs.

---

## Template 1: Standard Vulnerability Report

```markdown
## Title
[Vulnerability Type] in [Feature/Endpoint] allows [Impact]

Example: "Stored XSS in User Profile Bio Field Allows Session Hijacking of Any User"

## Severity
[Critical / High / Medium / Low / Informational]
CVSS Score: [X.X]
CVSS Vector: [CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H]

## Vulnerability Type
[CWE-XXX: Vulnerability Name]
Examples:
- CWE-79: Cross-Site Scripting (XSS)
- CWE-89: SQL Injection
- CWE-918: Server-Side Request Forgery (SSRF)
- CWE-639: Insecure Direct Object Reference (IDOR)
- CWE-287: Authentication Bypass

## Description
[Clear, concise description of the vulnerability. What is the issue? Where does it exist? Why is it dangerous?]

The [feature/endpoint] at [URL] is vulnerable to [vulnerability type] because [root cause]. An attacker can exploit this to [impact].

## Steps to Reproduce

### Prerequisites
- [Account type needed]
- [Tools needed]
- [Any setup required]

### Reproduction Steps
1. Navigate to [URL]
2. [Specific action]
3. [Specific action with payload]
4. Observe [vulnerable behavior]

### HTTP Request (if applicable)
```
POST /api/endpoint HTTP/1.1
Host: target.com
Content-Type: application/json
Authorization: Bearer [token]

{"param": "malicious_value"}
```

### HTTP Response
```
HTTP/1.1 200 OK
Content-Type: application/json

{"result": "showing_vulnerability"}
```

## Proof of Concept

[Include one or more of:]
- Screenshot showing the vulnerability
- Video demonstrating the exploit
- Code snippet for automated reproduction
- cURL command that triggers the issue

```bash
curl -X POST https://target.com/api/endpoint \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer TOKEN" \
  -d '{"param": "payload"}'
```

## Impact

### What an attacker can achieve:
- [Specific impact 1]
- [Specific impact 2]
- [Specific impact 3]

### Affected Users/Data:
- [Who is affected]
- [What data is at risk]
- [Scale of impact]

### Business Impact:
- [Financial impact]
- [Reputational impact]
- [Compliance impact]

## Remediation

### Recommended Fix:
[Describe the fix clearly]

### Code Example (Before):
```python
# Vulnerable code
user_input = request.get("input")
template.render(user_input)  # No sanitization
```

### Code Example (After):
```python
# Fixed code
from markupsafe import escape
user_input = escape(request.get("input"))
template.render(user_input)  # Input sanitized
```

### Additional Recommendations:
- [Recommendation 1]
- [Recommendation 2]
- [Recommendation 3]

## References
- [OWASP link]
- [CWE link]
- [CVE link if applicable]
- [Related research/writeups]
```

---

## Template 2: Security Posture Assessment

```markdown
## Security Posture Assessment: [Target Name]

### Date: [Date]
### Scope: [What was tested]
### Duration: [Time spent]

---

### Executive Summary
[Brief overview of findings and overall security posture]

---

### Strengths (What the company does well)

1. **[Strength 1]**
   - Description: [Details]
   - Why it matters: [Explanation]

2. **[Strength 2]**
   - Description: [Details]
   - Why it matters: [Explanation]

---

### Areas for Improvement

1. **[Area 1]** - Risk Level: [High/Medium/Low]
   - Current state: [What is happening now]
   - Recommended state: [What should happen]
   - How to improve: [Specific steps]

2. **[Area 2]** - Risk Level: [High/Medium/Low]
   - Current state: [Details]
   - Recommended state: [Details]
   - How to improve: [Steps]

---

### High Risk Areas

1. **[Risk 1]** - CRITICAL
   - Description: [Details]
   - Potential impact: [What could happen]
   - Immediate action needed: [What to do now]

---

### Recommendations Priority Matrix

| Priority | Action | Effort | Impact |
|----------|--------|--------|--------|
| 1 (Critical) | [Action] | [Low/Med/High] | [Low/Med/High] |
| 2 (High) | [Action] | [Low/Med/High] | [Low/Med/High] |
| 3 (Medium) | [Action] | [Low/Med/High] | [Low/Med/High] |
| 4 (Low) | [Action] | [Low/Med/High] | [Low/Med/High] |

---

### Security Metrics

- **Authentication Security:** [Score/10]
- **Authorization Controls:** [Score/10]
- **Input Validation:** [Score/10]
- **Encryption/Data Protection:** [Score/10]
- **Security Headers:** [Score/10]
- **Patch Management:** [Score/10]
- **Error Handling:** [Score/10]
- **API Security:** [Score/10]
- **Overall Score:** [Score/10]
```

---

## Template 3: Learning Notes

```markdown
## Learning Notes: [Vulnerability/Technique Name]

### Difficulty Level: [Beginner/Intermediate/Advanced/Expert]

### What Is This?
[Explain the concept as if talking to someone who has never heard of it]

### Why Does This Vulnerability Exist?
[Root cause explanation - what mistake leads to this bug]

### How Does It Work? (Step by Step)
1. [Step 1 - simplest explanation]
2. [Step 2]
3. [Step 3]

### Real-World Analogy
[Compare to something in everyday life]

### How to Find It
[Practical steps for discovering this vulnerability]

### How to Exploit It
[Ethical exploitation for PoC purposes]

### How to Fix It
[Developer perspective - how to prevent this]

### Related Concepts
- [Related concept 1] - [Brief description]
- [Related concept 2] - [Brief description]

### Career Relevance
- Penetration Tester: [How this skill applies]
- SOC Analyst: [How this skill applies]
- Security Engineer: [How this skill applies]
- Bug Bounty Hunter: [How this skill applies]

### Practice Resources
- [Lab/CTF 1]
- [Lab/CTF 2]
- [Reading material]

### Key Takeaways
1. [Takeaway 1]
2. [Takeaway 2]
3. [Takeaway 3]
```

---

## Report Writing Tips

### DO:
- Write a clear, specific title
- Include ALL reproduction steps
- Show real impact, not theoretical
- Provide working PoC
- Be professional and respectful
- Include remediation advice
- Reference standards (CWE, OWASP)
- Use proper formatting

### DO NOT:
- Write vague descriptions
- Skip reproduction steps
- Exaggerate severity
- Include unnecessary information
- Be rude or demanding
- Submit without testing your PoC
- Report known/accepted risks
- Submit duplicates without checking

### Severity Assessment Guide

**Critical (CVSS 9.0-10.0):**
- Remote Code Execution
- Authentication Bypass (full)
- SQL Injection with data access
- Full account takeover

**High (CVSS 7.0-8.9):**
- Stored XSS affecting all users
- SSRF to internal services
- IDOR with sensitive data access
- Privilege escalation

**Medium (CVSS 4.0-6.9):**
- Reflected XSS
- CSRF on important actions
- Information disclosure (moderate)
- Missing security controls

**Low (CVSS 0.1-3.9):**
- Self-XSS
- Missing security headers
- Verbose error messages
- Minor information disclosure

**Informational:**
- Best practice recommendations
- No direct security impact
- Theoretical issues
