# SECURITY-ASSESSMENT.md - Company Security Posture Analysis Guide

> How to evaluate and document the overall security posture of a target organization.

---

## Purpose

Beyond finding individual bugs, a skilled security researcher can assess the overall security maturity of an organization. This helps:
1. The company understand their security strengths and weaknesses
2. You (the operator) learn what good security looks like
3. Prioritize which areas need the most attention
4. Understand security from both offensive and defensive perspectives

---

## Assessment Framework

### Category 1: Authentication and Identity

**What to evaluate:**
- Password policy strength (length, complexity, rotation)
- Multi-factor authentication availability and enforcement
- Session management (timeout, invalidation, secure tokens)
- OAuth/SSO implementation correctness
- Account lockout and brute force protection
- Password reset security
- Credential storage (hashing algorithm, salting)

**Scoring:**
- Strong: MFA enforced, strong password policy, secure session management
- Adequate: MFA available but optional, decent password policy
- Weak: No MFA, weak passwords allowed, poor session management
- Critical: Default credentials, no lockout, plaintext passwords

**Beginner Concept:**
Authentication is how a system verifies WHO you are. Think of it like showing your ID at a bar. Strong authentication means checking multiple forms of ID (MFA). Weak authentication means accepting any piece of paper with a name on it.

---

### Category 2: Authorization and Access Control

**What to evaluate:**
- Role-based access control (RBAC) implementation
- Object-level authorization (IDOR prevention)
- Function-level authorization
- API authorization consistency
- Principle of least privilege
- Separation of duties

**Scoring:**
- Strong: Consistent RBAC, no IDOR, proper API auth
- Adequate: Mostly correct with minor inconsistencies
- Weak: IDOR found, inconsistent authorization checks
- Critical: No authorization checks, horizontal/vertical escalation possible

**Beginner Concept:**
Authorization is what you are ALLOWED to do after proving who you are. Authentication = showing your ID. Authorization = the bouncer checking if your name is on the VIP list. You might be authenticated (proven identity) but not authorized (not on the list).

---

### Category 3: Input Validation and Output Encoding

**What to evaluate:**
- Server-side input validation presence
- Client-side vs server-side validation
- Output encoding/escaping
- Parameterized queries (SQL injection prevention)
- Content Security Policy
- File upload validation

**Scoring:**
- Strong: Comprehensive server-side validation, parameterized queries, CSP
- Adequate: Most inputs validated, some gaps
- Weak: Inconsistent validation, some injection points
- Critical: No input validation, multiple injection vulnerabilities

**Beginner Concept:**
Input validation is checking that data from users is safe before processing it. Imagine a bouncer checking bags at a concert. Output encoding is making sure data displayed to users cannot be interpreted as code. Together, they prevent injection attacks.

---

### Category 4: Data Protection

**What to evaluate:**
- Encryption in transit (TLS version, cipher suites)
- Encryption at rest
- Sensitive data exposure in responses
- PII handling and minimization
- Data retention policies
- Backup security

**Scoring:**
- Strong: TLS 1.3, encrypted at rest, minimal data exposure
- Adequate: TLS 1.2+, some encryption, reasonable data handling
- Weak: Old TLS versions, some data exposed unnecessarily
- Critical: No encryption, sensitive data in plaintext, PII leaks

---

### Category 5: Security Headers and Configuration

**What to evaluate:**
```
Strict-Transport-Security (HSTS)
Content-Security-Policy (CSP)
X-Content-Type-Options
X-Frame-Options
X-XSS-Protection (legacy)
Referrer-Policy
Permissions-Policy
Cross-Origin headers (CORS, COEP, COOP)
Cookie flags (Secure, HttpOnly, SameSite)
```

**How to check:**
```bash
curl -I https://target.com | grep -iE "strict-transport|content-security|x-content-type|x-frame|referrer-policy|permissions-policy"
```

**Scoring:**
- Strong: All recommended headers present and properly configured
- Adequate: Most headers present, minor misconfigurations
- Weak: Several headers missing
- Critical: No security headers, misconfigured CORS

**Beginner Concept:**
Security headers are instructions from the server to the browser about how to handle the page securely. They are like safety labels on products. HSTS says always use HTTPS. CSP says only load scripts from trusted sources. Without them, the browser does not know what security rules to follow.

---

### Category 6: Error Handling and Information Disclosure

**What to evaluate:**
- Custom error pages vs stack traces
- Debug mode in production
- Server version disclosure
- Technology stack disclosure
- Internal IP/path disclosure
- Verbose error messages

**Scoring:**
- Strong: Custom error pages, no tech disclosure, no debug info
- Adequate: Mostly custom errors, minimal disclosure
- Weak: Some stack traces, version info visible
- Critical: Full stack traces, debug mode on, internal paths exposed

---

### Category 7: Patch Management

**What to evaluate:**
- Software version currency (how up-to-date)
- Known CVE exposure
- Dependency management
- Update frequency
- End-of-life software usage

**Scoring:**
- Strong: All software current, no known CVEs, regular updates
- Adequate: Mostly current, minor version lag
- Weak: Several outdated components, some known CVEs
- Critical: Major CVEs unpatched, EOL software in use

---

### Category 8: API Security

**What to evaluate:**
- API authentication mechanisms
- Rate limiting
- Input validation on API endpoints
- API versioning and deprecation
- Documentation exposure (Swagger/OpenAPI)
- GraphQL security (if applicable)

---

### Category 9: Cloud Security (if applicable)

**What to evaluate:**
- Cloud storage permissions (S3, Azure Blob, GCP)
- IAM configuration
- Network security groups
- Secrets management
- Container security
- Serverless function security

---

### Category 10: Security Architecture

**What to evaluate:**
- Defense in depth (multiple layers)
- Network segmentation
- WAF presence and effectiveness
- Rate limiting and DDoS protection
- Logging and monitoring indicators
- Incident response readiness

---

## Assessment Output Format

```
=== SECURITY POSTURE ASSESSMENT ===
Target: [name]
Date: [date]
Assessor: BugHunterAgent v3

OVERALL SCORE: [X/100]

| Category | Score | Rating |
|----------|-------|--------|
| Authentication | X/10 | Strong/Adequate/Weak/Critical |
| Authorization | X/10 | Strong/Adequate/Weak/Critical |
| Input Validation | X/10 | Strong/Adequate/Weak/Critical |
| Data Protection | X/10 | Strong/Adequate/Weak/Critical |
| Security Headers | X/10 | Strong/Adequate/Weak/Critical |
| Error Handling | X/10 | Strong/Adequate/Weak/Critical |
| Patch Management | X/10 | Strong/Adequate/Weak/Critical |
| API Security | X/10 | Strong/Adequate/Weak/Critical |
| Cloud Security | X/10 | Strong/Adequate/Weak/Critical |
| Security Architecture | X/10 | Strong/Adequate/Weak/Critical |

TOP STRENGTHS:
1. [strength]
2. [strength]
3. [strength]

TOP RISKS:
1. [risk] - Impact: [description]
2. [risk] - Impact: [description]
3. [risk] - Impact: [description]

PRIORITIZED RECOMMENDATIONS:
1. [CRITICAL] [recommendation]
2. [HIGH] [recommendation]
3. [MEDIUM] [recommendation]
4. [LOW] [recommendation]
```
