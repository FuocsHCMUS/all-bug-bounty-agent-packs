# SKILL.md - Bug Bounty Hunter Skills Definition

> This file defines the skills, capabilities, and competencies the agent must possess and continuously develop.

---

## Skill Categories

### 1. RECONNAISSANCE (Recon)

#### 1.1 Passive Reconnaissance

**Skill:** Gather information without directly interacting with the target
**Level:** Foundation

**Techniques:**
- OSINT (Open Source Intelligence) gathering
- WHOIS lookups and domain registration history
- DNS record analysis (A, AAAA, CNAME, MX, TXT, NS, SOA)
- Certificate Transparency log mining (crt.sh, censys)
- Google dorking (site:, inurl:, intitle:, filetype:, ext:)
- Shodan/Censys/ZoomEye searches
- Wayback Machine / web archive analysis
- Social media and employee OSINT
- GitHub/GitLab code repository searching
- Pastebin and paste site monitoring
- Job listing analysis (reveals tech stack)
- Public S3 bucket / cloud storage enumeration

**Concept Breakdown (For Beginners):**
Passive recon is like being a detective who only reads public records. You never touch the target directly - you only look at information that is already publicly available. Think of it like reading a company public website, checking their DNS records (like a phone book for the internet), or looking at old versions of their website on archive.org.

WHY it matters: Before you test anything, you need to understand what you are looking at. What technologies do they use? What domains do they own? What services are exposed? This is your map of the battlefield.

#### 1.2 Active Reconnaissance

**Skill:** Directly interact with target to discover assets and services
**Level:** Intermediate

**Techniques:**
- Subdomain enumeration (brute-force + permutation)
- Port scanning (TCP/UDP, service version detection)
- Web crawling and spidering
- Directory and file brute-forcing
- Virtual host discovery
- API endpoint discovery
- JavaScript file analysis (endpoints, secrets, API keys)
- Technology fingerprinting (Wappalyzer-style)
- WAF detection and identification
- Cloud infrastructure mapping

**Concept Breakdown (For Beginners):**
Active recon is when you start knocking on doors. You are sending requests to the target to see what responds. Port scanning is like checking which doors are open on a building. Directory brute-forcing is like trying different room numbers to see which ones exist.

IMPORTANT: Only do this on targets you have permission to test! This is where you cross from reading public info to interacting with systems. Always check the bug bounty program scope first.

---

### 2. VULNERABILITY ASSESSMENT

#### 2.1 Web Application Vulnerabilities

**Skill:** Identify and exploit web application security flaws
**Level:** Core Competency

**Vulnerability Classes:**

**A. Injection Attacks**

- **SQL Injection (SQLi)**
  - Classic: OR 1=1--
  - Blind: Boolean-based, Time-based
  - Out-of-band: DNS/HTTP exfiltration
  - Second-order: Stored payload triggered later

- **Cross-Site Scripting (XSS)**
  - Reflected: Input reflected in response
  - Stored: Payload saved and served to others
  - DOM-based: Client-side JavaScript manipulation
  - Mutation XSS (mXSS): Browser parsing quirks

- **Server-Side Template Injection (SSTI)**
  - Jinja2, Twig, Freemarker, Velocity, Pebble
  - Detection: {{7*7}}, ${7*7}, #{7*7}
  - Escalation to RCE

- **Command Injection**
  - OS command injection via user input
  - Blind command injection (time-based, OOB)

- **XML External Entity (XXE)**
  - Classic XXE: File read
  - Blind XXE: Out-of-band data exfiltration
  - XXE via file upload (SVG, DOCX, XLSX)

**B. Broken Access Control**

- **IDOR (Insecure Direct Object Reference)**
  - Horizontal: Access other users data
  - Vertical: Access admin functionality
  - Parameter manipulation, UUID prediction

- **Privilege Escalation**
  - Horizontal: User A to User B (same role)
  - Vertical: User to Admin
  - Role manipulation, JWT tampering

- **BOLA/BFLA (API-specific)**
  - Broken Object Level Authorization
  - Broken Function Level Authorization

**C. Authentication Flaws**
- Brute force attacks
- Credential stuffing
- Password reset poisoning
- 2FA bypass techniques
- Session fixation/hijacking
- OAuth/OIDC misconfigurations
- JWT attacks (none algorithm, key confusion, claim tampering)

**D. Server-Side Request Forgery (SSRF)**
- Classic SSRF: Access internal services
- Blind SSRF: No direct response
- Cloud metadata access (169.254.169.254)
- Protocol smuggling (gopher://, file://)
- DNS rebinding

**E. Business Logic Flaws**
- Race conditions (TOCTOU)
- Price manipulation
- Coupon/discount abuse
- Feature abuse
- Workflow bypass
- Mass assignment

**Concept Breakdown (For Beginners):**
Web vulnerabilities are like finding unlocked windows in a house. Each type is a different kind of window:

- Injection: You are putting unexpected commands where the app expects normal data. Like writing a SQL command in a search box.
- Broken Access Control: The app does not properly check if you are allowed to see something. Like being able to view someone else bank account by changing a number in the URL.
- Auth Flaws: Problems with how the app verifies who you are. Like a lock that can be picked easily.
- SSRF: Tricking the server into making requests on your behalf to internal systems it can reach but you cannot.
- Business Logic: The app works as coded, but the logic itself is flawed. Like a store that lets you apply a discount twice.

#### 2.2 API Security

**Skill:** Test REST, GraphQL, gRPC, and WebSocket APIs
**Level:** Intermediate-Advanced

**Focus Areas:**
- API endpoint discovery and documentation
- Authentication and authorization testing
- Input validation and injection testing
- Rate limiting and resource exhaustion
- Mass assignment / excessive data exposure
- GraphQL introspection and query abuse
- WebSocket security testing
- API versioning issues (old versions still accessible)

**Concept Breakdown:**
APIs are how different software components talk to each other. Think of them as the back door of a web application. The pretty website you see is the front door - the API is where the real data exchange happens. Many bugs hide in APIs because developers focus security on the front-end but forget the API.

#### 2.3 Infrastructure Vulnerabilities

**Skill:** Identify server, network, and cloud misconfigurations
**Level:** Intermediate

**Focus Areas:**
- Outdated software with known CVEs
- Default credentials
- Exposed admin panels and debug endpoints
- Cloud misconfigurations (S3, Azure Blob, GCP buckets)
- DNS misconfigurations (zone transfer, subdomain takeover)
- TLS/SSL weaknesses
- CORS misconfigurations
- Security header analysis
- Information disclosure (server versions, stack traces)

---

### 3. EXPLOIT DEVELOPMENT

#### 3.1 Custom Exploit Writing

**Skill:** Develop targeted exploits for discovered vulnerabilities
**Level:** Advanced

**Capabilities:**
- Write Python/Go exploit scripts
- Craft custom payloads for specific contexts
- Bypass WAF rules and input filters
- Develop PoC (Proof of Concept) demonstrations
- Chain multiple vulnerabilities into complex attacks
- Automate exploitation for reproducibility

**Concept Breakdown:**
An exploit is a piece of code or a sequence of actions that takes advantage of a vulnerability. Writing exploits is like being a locksmith who can demonstrate exactly how a lock can be picked. In bug bounty, you need to prove the vulnerability is real and show its impact - that is what a PoC does.

#### 3.2 WAF/Filter Bypass

**Skill:** Circumvent security controls to prove vulnerabilities
**Level:** Advanced

**Techniques:**
- Encoding tricks (URL, HTML, Unicode, double encoding)
- Case variation and null bytes
- HTTP parameter pollution
- Content-Type manipulation
- Chunked transfer encoding abuse
- HTTP/2 specific bypasses
- IP-based restriction bypasses
- Custom header injection

**Concept Breakdown:**
A WAF (Web Application Firewall) is like a security guard at the door checking everyone bags. It looks for known attack patterns and blocks them. Bypassing a WAF means finding ways to disguise your payload so the guard does not recognize it, but the application behind the guard still processes it as intended.

---

### 4. CVE RESEARCH

#### 4.1 CVE Discovery and Mapping

**Skill:** Find and map known vulnerabilities to target systems
**Level:** Intermediate

**Process:**
1. Identify exact software versions on target
2. Search CVE databases (NVD, MITRE, vendor advisories)
3. Cross-reference with exploit databases
4. Verify if patches have been applied
5. Assess exploitability in the target context
6. Develop or adapt existing PoCs

**Concept Breakdown:**
CVE = Common Vulnerabilities and Exposures. It is a standardized naming system for known security bugs. Each CVE has an ID like CVE-2024-12345. When you find that a target uses Apache 2.4.49, you can search for CVEs affecting that version and check if the target is vulnerable. It is like checking if a car model has been recalled for a safety defect.

#### 4.2 Zero-Day Research

**Skill:** Discover previously unknown vulnerabilities
**Level:** Expert

**Approach:**
- Source code review (when available)
- Binary analysis and reverse engineering
- Fuzzing with custom harnesses
- Differential analysis between versions
- Logic flow analysis
- Dependency analysis for transitive vulnerabilities

**Concept Breakdown:**
A zero-day is a vulnerability that nobody knows about yet - there are zero days of awareness. Finding these is the holy grail of security research. It requires deep understanding of how software works and creative thinking about what could go wrong.

---

### 5. REPORTING AND COMMUNICATION

#### 5.1 Bug Report Writing

**Skill:** Write clear, impactful vulnerability reports
**Level:** Essential

**Components:**
- Clear title describing the vulnerability
- Severity assessment (CVSS scoring)
- Detailed description of the issue
- Step-by-step reproduction instructions
- Proof of Concept (code, screenshots, video)
- Impact assessment (what an attacker could do)
- Remediation recommendations
- References (CVEs, OWASP, CWE)

**Concept Breakdown:**
Your report is your product. A great finding with a bad report might get dismissed. A well-written report with clear reproduction steps and impact assessment will get triaged faster and rewarded higher. Think of it as writing a lab report in school - be precise, be clear, and show your work.

#### 5.2 Security Assessment

**Skill:** Evaluate overall security posture of a target
**Level:** Intermediate

**Assessment Areas:**
- Authentication strength
- Authorization model robustness
- Input validation coverage
- Error handling and information disclosure
- Encryption and data protection
- Security headers and configurations
- Patch management and update frequency
- Incident response readiness
- Security architecture design
- Defense in depth implementation

---

### 6. CONTINUOUS LEARNING

#### 6.1 Writeup Analysis

**Skill:** Learn from published vulnerability writeups and CTF solutions
**Level:** Ongoing

**Sources:**
- HackerOne disclosed reports
- Bugcrowd published findings
- Personal blogs of top researchers
- CTF writeups on CTFtime
- Conference talks (DEF CON, Black Hat, BSides)
- Academic security papers

**Process:**
1. Read the writeup carefully
2. Understand the vulnerability class
3. Note the discovery methodology
4. Study the exploitation technique
5. Identify what made this finding unique
6. Practice reproducing similar findings
7. Adapt techniques to your own targets

#### 6.2 Tool Mastery

**Skill:** Proficiently use security testing tools
**Level:** Ongoing

**Categories:**
- Proxy tools (Burp Suite, mitmproxy, OWASP ZAP)
- Scanners (Nuclei, Nikto, Nessus)
- Fuzzers (ffuf, wfuzz, AFL)
- Exploitation frameworks (Metasploit, custom scripts)
- Programming (Python, Go, JavaScript, Bash)
- Cloud security tools (ScoutSuite, Prowler, CloudMapper)
