# WORKFLOW-AUTOMATION.md - Automated Bug Bounty Workflows

> Automation scripts and workflows for efficient bug bounty hunting.

---

## Why Automate?

Automation lets you:
1. Cover more attack surface in less time
2. Run repetitive tasks while you focus on creative testing
3. Continuously monitor targets for changes
4. Catch low-hanging fruit automatically
5. Build a pipeline that works while you sleep

**Beginner Analogy:**
Automation is like setting up fishing nets instead of using a fishing rod. The nets catch fish while you do other things. But you still need to know WHERE to place the nets (methodology) and HOW to identify good fish (vulnerability assessment).

---

## Workflow 1: Full Recon Pipeline

```bash
#!/bin/bash
# full-recon.sh - Complete reconnaissance pipeline
# Usage: ./full-recon.sh target.com

set -e
TARGET="$1"
DATE=$(date +%Y%m%d)
OUTDIR="results/${TARGET}/${DATE}"
mkdir -p "${OUTDIR}/{subdomains,urls,ports,vulns,js,screenshots}"

echo "========================================"
echo "[*] Full Recon Pipeline for: ${TARGET}"
echo "[*] Output: ${OUTDIR}"
echo "[*] Started: $(date)"
echo "========================================"

# Phase 1: Subdomain Enumeration
echo "[PHASE 1] Subdomain Enumeration"
subfinder -d "${TARGET}" -silent > "${OUTDIR}/subdomains/subfinder.txt" 2>/dev/null
amass enum -passive -d "${TARGET}" -o "${OUTDIR}/subdomains/amass.txt" 2>/dev/null
assetfinder --subs-only "${TARGET}" > "${OUTDIR}/subdomains/assetfinder.txt" 2>/dev/null

# Combine and deduplicate
cat "${OUTDIR}"/subdomains/*.txt | sort -u > "${OUTDIR}/subdomains/all.txt"
echo "[+] Total unique subdomains: $(wc -l < "${OUTDIR}/subdomains/all.txt")"

# Phase 2: Alive Check
echo "[PHASE 2] Alive Check"
cat "${OUTDIR}/subdomains/all.txt" | httpx -silent -status-code -title -tech-detect -follow-redirects > "${OUTDIR}/subdomains/alive.txt"
echo "[+] Alive hosts: $(wc -l < "${OUTDIR}/subdomains/alive.txt")"

# Phase 3: URL Collection
echo "[PHASE 3] URL Collection"
echo "${TARGET}" | gau --threads 5 > "${OUTDIR}/urls/gau.txt" 2>/dev/null
echo "${TARGET}" | waybackurls > "${OUTDIR}/urls/wayback.txt" 2>/dev/null
cat "${OUTDIR}"/urls/*.txt | sort -u > "${OUTDIR}/urls/all.txt"
echo "[+] Total URLs: $(wc -l < "${OUTDIR}/urls/all.txt")"

# Phase 4: Port Scanning
echo "[PHASE 4] Port Scanning"
cat "${OUTDIR}/subdomains/all.txt" | dnsx -silent -a -resp-only | sort -u > "${OUTDIR}/ports/ips.txt"
nmap -sV -T4 --top-ports 1000 -iL "${OUTDIR}/ports/ips.txt" -oN "${OUTDIR}/ports/nmap.txt" 2>/dev/null
echo "[+] Port scan complete"

# Phase 5: Vulnerability Scanning
echo "[PHASE 5] Vulnerability Scanning"
cat "${OUTDIR}/subdomains/alive.txt" | awk "{print \$1}" | nuclei -silent -severity critical,high -o "${OUTDIR}/vulns/nuclei_critical.txt" 2>/dev/null
echo "[+] Critical/High findings: $(wc -l < "${OUTDIR}/vulns/nuclei_critical.txt")"

# Phase 6: JavaScript Analysis
echo "[PHASE 6] JavaScript Analysis"
cat "${OUTDIR}/urls/all.txt" | grep -iE "\.js$" | sort -u > "${OUTDIR}/js/js_files.txt"
echo "[+] JS files found: $(wc -l < "${OUTDIR}/js/js_files.txt")"

echo "========================================"
echo "[*] Recon Complete: $(date)"
echo "[*] Results saved to: ${OUTDIR}"
echo "========================================"
```

---

## Workflow 2: Vulnerability-Specific Scanners

### XSS Scanner
```bash
#!/bin/bash
# xss-scan.sh - Automated XSS scanning
# Usage: ./xss-scan.sh target.com

TARGET="$1"
OUTDIR="results/${TARGET}/xss"
mkdir -p "${OUTDIR}"

echo "[*] XSS Scanning: ${TARGET}"

# Collect URLs with parameters
echo "${TARGET}" | gau | grep "=" | sort -u > "${OUTDIR}/params.txt"
echo "[+] URLs with parameters: $(wc -l < "${OUTDIR}/params.txt")"

# Run dalfox
cat "${OUTDIR}/params.txt" | dalfox pipe --silence -o "${OUTDIR}/dalfox_results.txt" 2>/dev/null
echo "[+] XSS findings: $(wc -l < "${OUTDIR}/dalfox_results.txt")"
```

### SSRF Scanner
```bash
#!/bin/bash
# ssrf-scan.sh - Find potential SSRF endpoints
# Usage: ./ssrf-scan.sh target.com

TARGET="$1"
OUTDIR="results/${TARGET}/ssrf"
mkdir -p "${OUTDIR}"

echo "[*] SSRF Endpoint Discovery: ${TARGET}"

# Find URL-like parameters
echo "${TARGET}" | gau | grep -iE "url=|uri=|path=|dest=|redirect=|site=|html=|fetch=|proxy=|page=|feed=|host=|to=|out=|ref=|callback=" | sort -u > "${OUTDIR}/potential_ssrf.txt"
echo "[+] Potential SSRF endpoints: $(wc -l < "${OUTDIR}/potential_ssrf.txt")"
```

### Subdomain Takeover Scanner
```bash
#!/bin/bash
# takeover-scan.sh - Check for subdomain takeover
# Usage: ./takeover-scan.sh subdomains.txt

SUBDOMAINS="$1"
OUTDIR="results/takeover"
mkdir -p "${OUTDIR}"

echo "[*] Checking for subdomain takeover..."

# Check CNAME records
cat "${SUBDOMAINS}" | dnsx -silent -cname -resp > "${OUTDIR}/cnames.txt"

# Look for dangling CNAMEs
grep -iE "amazonaws|azure|github|heroku|shopify|fastly|pantheon|wordpress|tumblr|ghost" "${OUTDIR}/cnames.txt" > "${OUTDIR}/potential_takeover.txt"
echo "[+] Potential takeovers: $(wc -l < "${OUTDIR}/potential_takeover.txt")"
```

---

## Workflow 3: Continuous Monitoring

```bash
#!/bin/bash
# monitor.sh - Continuous monitoring for new assets and changes
# Usage: ./monitor.sh target.com
# Run via cron: 0 */6 * * * /path/to/monitor.sh target.com

TARGET="$1"
MONITOR_DIR="monitor/${TARGET}"
mkdir -p "${MONITOR_DIR}"

DATE=$(date +%Y%m%d_%H%M)
NEW_SUBS="${MONITOR_DIR}/subs_${DATE}.txt"
OLD_SUBS="${MONITOR_DIR}/subs_latest.txt"

# Get current subdomains
subfinder -d "${TARGET}" -silent | sort -u > "${NEW_SUBS}"

# Compare with previous scan
if [ -f "${OLD_SUBS}" ]; then
    NEW=$(comm -13 "${OLD_SUBS}" "${NEW_SUBS}")
    if [ -n "${NEW}" ]; then
        echo "[ALERT] New subdomains found for ${TARGET}:"
        echo "${NEW}"
        echo "${NEW}" >> "${MONITOR_DIR}/new_discoveries.txt"
        
        # Scan new subdomains immediately
        echo "${NEW}" | httpx -silent -status-code -title | tee -a "${MONITOR_DIR}/new_alive.txt"
        echo "${NEW}" | nuclei -silent -severity critical,high | tee -a "${MONITOR_DIR}/new_vulns.txt"
    fi
fi

# Update latest
cp "${NEW_SUBS}" "${OLD_SUBS}"
```

---

## Workflow 4: Python Automation Framework

```python
#!/usr/bin/env python3
"""bug_hunter.py - Automated bug bounty hunting framework"""

import subprocess
import json
import os
from datetime import datetime
from pathlib import Path

class BugHunter:
    def __init__(self, target, output_dir=None):
        self.target = target
        self.output_dir = output_dir or f"results/{target}/{datetime.now().strftime("%Y%m%d")}"
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)
        self.findings = []
    
    def run_command(self, cmd, output_file=None):
        """Run a shell command and optionally save output."""
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=300)
            if output_file:
                with open(f"{self.output_dir}/{output_file}", "w") as f:
                    f.write(result.stdout)
            return result.stdout
        except subprocess.TimeoutExpired:
            return ""
    
    def enumerate_subdomains(self):
        """Enumerate subdomains using multiple tools."""
        print(f"[*] Enumerating subdomains for {self.target}")
        self.run_command(f"subfinder -d {self.target} -silent", "subdomains.txt")
        return self.read_file("subdomains.txt")
    
    def check_alive(self, subdomains_file="subdomains.txt"):
        """Check which hosts are alive."""
        print("[*] Checking alive hosts")
        self.run_command(
            f"cat {self.output_dir}/{subdomains_file} | httpx -silent -status-code -title",
            "alive.txt"
        )
        return self.read_file("alive.txt")
    
    def scan_vulnerabilities(self, hosts_file="alive.txt"):
        """Scan for vulnerabilities with nuclei."""
        print("[*] Scanning for vulnerabilities")
        self.run_command(
            f"cat {self.output_dir}/{hosts_file} | awk '{{print $1}}' | nuclei -silent -severity critical,high",
            "vulns.txt"
        )
        return self.read_file("vulns.txt")
    
    def read_file(self, filename):
        """Read a file from the output directory."""
        filepath = f"{self.output_dir}/{filename}"
        if os.path.exists(filepath):
            with open(filepath) as f:
                return f.read().strip().split("\n")
        return []
    
    def generate_report(self):
        """Generate a summary report."""
        report = {
            "target": self.target,
            "date": datetime.now().isoformat(),
            "subdomains": len(self.read_file("subdomains.txt")),
            "alive_hosts": len(self.read_file("alive.txt")),
            "vulnerabilities": len(self.read_file("vulns.txt")),
            "findings": self.findings
        }
        with open(f"{self.output_dir}/report.json", "w") as f:
            json.dump(report, f, indent=2)
        print(f"[+] Report saved to {self.output_dir}/report.json")
        return report
    
    def run_full_pipeline(self):
        """Run the complete hunting pipeline."""
        print(f"=== Bug Hunting Pipeline: {self.target} ===")
        self.enumerate_subdomains()
        self.check_alive()
        self.scan_vulnerabilities()
        report = self.generate_report()
        print(f"=== Pipeline Complete ===")
        print(f"Subdomains: {report["subdomains"]}")
        print(f"Alive: {report["alive_hosts"]}")
        print(f"Vulns: {report["vulnerabilities"]}")
        return report

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python3 bug_hunter.py target.com")
        sys.exit(1)
    hunter = BugHunter(sys.argv[1])
    hunter.run_full_pipeline()
```

---

## Workflow 5: Nuclei Custom Templates

```yaml
# custom-checks.yaml - Custom nuclei template
id: custom-sensitive-files

info:
  name: Sensitive File Exposure Check
  author: BugHunterAgent
  severity: medium
  description: Checks for common sensitive files

requests:
  - method: GET
    path:
      - "{{BaseURL}}/.env"
      - "{{BaseURL}}/.git/config"
      - "{{BaseURL}}/wp-config.php.bak"
      - "{{BaseURL}}/config.php.bak"
      - "{{BaseURL}}/.htaccess"
      - "{{BaseURL}}/phpinfo.php"
      - "{{BaseURL}}/server-status"
      - "{{BaseURL}}/debug"
      - "{{BaseURL}}/.DS_Store"
      - "{{BaseURL}}/backup.sql"
    matchers-condition: or
    matchers:
      - type: status
        status:
          - 200
      - type: word
        words:
          - "DB_PASSWORD"
          - "[core]"
          - "phpinfo()"
          - "Apache Server Status"
```

---

## Automation Best Practices

1. **Respect Rate Limits:** Add delays between requests
2. **Handle Errors:** Scripts should not crash on network errors
3. **Log Everything:** Save all output for later analysis
4. **Deduplicate:** Remove duplicate results before testing
5. **Prioritize:** Focus automated testing on high-impact areas
6. **Validate:** Always manually verify automated findings
7. **Update:** Keep tools and wordlists up to date
8. **Scope Check:** Ensure automation stays within scope
