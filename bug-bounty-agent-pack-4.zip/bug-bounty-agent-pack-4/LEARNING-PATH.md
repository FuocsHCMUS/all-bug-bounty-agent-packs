# CYBERSECURITY STUDENT LEARNING PATH

A comprehensive learning path for a cybersecurity student to develop from beginner to professional bug bounty hunter and penetration tester.

---

## 1. FOUNDATION CONCEPTS (START HERE)

### 1.1. How the Internet Works
```
Before hacking anything, you need to understand how things work normally.

THE INTERNET IN SIMPLE TERMS:
Imagine the internet as a postal system:
- Your computer = your house
- IP address = your home address (e.g., 192.168.1.1)
- Domain name = a friendly name for the address (e.g., google.com)
- DNS = the phone book that converts names to addresses
- Router = the post office that routes mail
- HTTP = the language used to write letters
- HTTPS = letters in a sealed envelope (encrypted)
- Port = the specific mailbox at the address (port 80 = web, port 443 = secure web)

WHAT HAPPENS WHEN YOU VISIT A WEBSITE:
1. You type "google.com" in your browser
2. Your computer asks DNS: "What is the IP address of google.com?"
3. DNS responds: "It is 142.250.80.46"
4. Your computer connects to 142.250.80.46 on port 443 (HTTPS)
5. Your browser sends an HTTP request: "GET / HTTP/1.1"
6. Google server processes the request
7. Google server sends back HTML, CSS, JavaScript
8. Your browser renders the page

KEY PROTOCOLS TO UNDERSTAND:
- TCP/IP: The foundation of internet communication
- HTTP/HTTPS: How web pages are requested and delivered
- DNS: How domain names are resolved to IP addresses
- TLS/SSL: How encryption works for HTTPS
- WebSocket: Real-time bidirectional communication
- SMTP/POP3/IMAP: How email works
```

### 1.2. How Web Applications Work
```
A web application has three main parts:

1. FRONTEND (Client-Side):
   - What you see in the browser
   - HTML = structure (the skeleton)
   - CSS = styling (the clothes)
   - JavaScript = behavior (the muscles)
   - Runs on YOUR computer
   - NEVER trust the frontend for security (users can modify it)

2. BACKEND (Server-Side):
   - The brain of the application
   - Processes requests, talks to database
   - Languages: Python, PHP, Java, Node.js, Ruby, Go, C#
   - Frameworks: Django, Laravel, Spring, Express, Rails
   - Runs on the SERVER (users cannot directly modify it)

3. DATABASE:
   - Where data is stored
   - SQL databases: MySQL, PostgreSQL, MSSQL, SQLite
   - NoSQL databases: MongoDB, Redis, Elasticsearch
   - Stores users, passwords, content, settings

HOW THEY INTERACT:
   Browser (Frontend)
       |
       | HTTP Request (GET /profile?id=123)
       v
   Web Server (Backend)
       |
       | SQL Query (SELECT * FROM users WHERE id=123)
       v
   Database
       |
       | Returns user data
       v
   Web Server processes data
       |
       | HTTP Response (HTML page with user profile)
       v
   Browser renders the page

WHY THIS MATTERS FOR SECURITY:
- If the backend does not validate the "id" parameter, an attacker can change
  id=123 to id=124 and see another user profile (IDOR vulnerability)
- If the backend puts user input directly into SQL queries, an attacker can
  inject SQL commands (SQL Injection)
- If the backend puts user input into HTML without encoding, an attacker can
  inject JavaScript (XSS)
```

### 1.3. HTTP Protocol Deep Dive
```
HTTP (HyperText Transfer Protocol) is the language browsers and servers speak.

HTTP REQUEST STRUCTURE:
-----------------------
GET /api/users/123 HTTP/1.1        <- Method, Path, Version
Host: api.target.com               <- Which server
Cookie: session=abc123             <- Your session token
Authorization: Bearer eyJhbG...    <- Your auth token
Content-Type: application/json     <- What format the body is in
User-Agent: Mozilla/5.0...         <- Your browser info

{"name": "test"}                   <- Request body (for POST/PUT)

HTTP RESPONSE STRUCTURE:
------------------------
HTTP/1.1 200 OK                    <- Status code
Content-Type: application/json     <- Response format
Set-Cookie: session=xyz789         <- Server sets a cookie
X-Frame-Options: DENY              <- Security header

{"id": 123, "name": "John"}        <- Response body

HTTP METHODS:
- GET: Retrieve data (should not modify anything)
- POST: Create new data
- PUT: Update existing data (full replacement)
- PATCH: Update existing data (partial)
- DELETE: Remove data
- OPTIONS: Check what methods are allowed
- HEAD: Like GET but only returns headers
- TRACE: Echo back the request (can be dangerous)

STATUS CODES:
- 200 OK: Success
- 201 Created: New resource created
- 301/302: Redirect
- 400 Bad Request: Your request was malformed
- 401 Unauthorized: You need to log in
- 403 Forbidden: You are logged in but not allowed
- 404 Not Found: Resource does not exist
- 405 Method Not Allowed: Wrong HTTP method
- 500 Internal Server Error: Server crashed (interesting for hackers!)
- 502/503: Server overloaded or down

SECURITY-RELEVANT HEADERS:
- Cookie / Set-Cookie: Session management
- Authorization: Authentication tokens
- Content-Security-Policy: XSS protection
- X-Frame-Options: Clickjacking protection
- Strict-Transport-Security: Force HTTPS
- Access-Control-Allow-Origin: CORS policy
```

---

## 2. LEARNING ROADMAP

### Phase 1: Foundations (Month 1-2)
```
[ ] Networking basics (TCP/IP, DNS, HTTP)
[ ] Linux command line basics
[ ] Python programming basics
[ ] HTML/CSS/JavaScript basics
[ ] How web applications work
[ ] HTTP protocol deep understanding
[ ] Browser developer tools usage

Resources:
- TryHackMe: "Pre Security" and "Introduction to Cyber Security" paths
- Professor Messer Network+ videos (free on YouTube)
- Automate the Boring Stuff with Python (free online)
- MDN Web Docs (HTML/CSS/JS tutorials)
```

### Phase 2: Security Fundamentals (Month 3-4)
```
[ ] OWASP Top 10 understanding
[ ] Common vulnerability types (XSS, SQLi, SSRF, IDOR)
[ ] Authentication and session management
[ ] Cryptography basics
[ ] Network security basics
[ ] Using Burp Suite
[ ] Using Nmap

Resources:
- PortSwigger Web Security Academy (FREE and EXCELLENT)
- TryHackMe: "Web Fundamentals" path
- OWASP Testing Guide
- Burp Suite documentation
```

### Phase 3: Hands-On Practice (Month 5-8)
```
[ ] Complete PortSwigger Academy labs (ALL of them)
[ ] HackTheBox starting point machines
[ ] TryHackMe offensive security path
[ ] DVWA (Damn Vulnerable Web Application)
[ ] bWAPP (buggy Web Application)
[ ] Juice Shop (OWASP)
[ ] WebGoat (OWASP)
[ ] CTF competitions (picoCTF, CTFtime events)

Resources:
- PortSwigger Academy: https://portswigger.net/web-security
- HackTheBox: https://www.hackthebox.com/
- TryHackMe: https://tryhackme.com/
- PicoCTF: https://picoctf.org/
```

### Phase 4: Bug Bounty Hunting (Month 9-12)
```
[ ] Create accounts on HackerOne, Bugcrowd
[ ] Start with VDP (Vulnerability Disclosure Programs) - no bounty but good practice
[ ] Read 100+ bug bounty writeups
[ ] Develop your own methodology
[ ] Build custom recon tools
[ ] Submit your first reports
[ ] Learn from rejections and duplicates
[ ] Specialize in 2-3 vulnerability types

Resources:
- HackerOne: https://hackerone.com/
- Bugcrowd: https://bugcrowd.com/
- Bug bounty writeups (see WRITEUP-ANALYSIS.md)
- Nahamsec (YouTube): Bug bounty tips
- STOK (YouTube): Bug bounty methodology
```

### Phase 5: Specialization (Month 12+)
```
Choose 1-2 areas to specialize in:

[ ] Web Application Security (most common in bug bounty)
[ ] API Security (growing demand)
[ ] Cloud Security (AWS/Azure/GCP)
[ ] Mobile Security (Android/iOS)
[ ] Network Penetration Testing
[ ] Active Directory / Internal Network
[ ] IoT Security
[ ] Reverse Engineering
[ ] Malware Analysis
[ ] Digital Forensics
[ ] Incident Response
[ ] Security Architecture
```

---

## 3. CERTIFICATIONS ROADMAP

```
BEGINNER:
- CompTIA Security+ (foundational security knowledge)
- CompTIA Network+ (networking fundamentals)
- eJPT (eLearnSecurity Junior Penetration Tester)

INTERMEDIATE:
- CEH (Certified Ethical Hacker)
- CompTIA PenTest+
- eWPT (eLearnSecurity Web Application Penetration Tester)
- PNPT (Practical Network Penetration Tester)

ADVANCED:
- OSCP (Offensive Security Certified Professional) - GOLD STANDARD
- OSWE (Offensive Security Web Expert)
- OSEP (Offensive Security Experienced Penetration Tester)
- BSCP (Burp Suite Certified Practitioner)
- CRTP (Certified Red Team Professional)
- CRTO (Certified Red Team Operator)

EXPERT:
- OSCE3 (Offensive Security Certified Expert 3)
- GXPN (GIAC Exploit Researcher and Advanced Penetration Tester)
- CREST CRT/CCT
```

---

## 4. SKILL DEVELOPMENT AREAS

### For SOC Analyst
```
- Log analysis (Splunk, ELK Stack)
- SIEM operations
- Incident detection and triage
- Threat intelligence
- Network traffic analysis (Wireshark)
- Malware analysis basics
- Forensics basics
- MITRE ATT&CK framework
```

### For Penetration Tester
```
- Web application testing (OWASP methodology)
- Network penetration testing
- Active Directory attacks
- Social engineering
- Report writing
- Tool development (Python)
- Cloud security testing
- Mobile application testing
```

### For Red Team Operator
```
- Advanced persistent threat (APT) simulation
- Custom tool development
- Evasion techniques (AV, EDR bypass)
- C2 framework operation (Cobalt Strike, Sliver)
- Physical security testing
- Social engineering campaigns
- Lateral movement and pivoting
- Data exfiltration techniques
```

---

## 5. DAILY PRACTICE ROUTINE

```
Suggested daily routine for a cybersecurity student:

1. MORNING (1 hour):
   - Read 1-2 bug bounty writeups
   - Take notes using the extraction framework
   - Add new techniques to your database

2. AFTERNOON (2-3 hours):
   - Practice on labs (PortSwigger, HackTheBox, TryHackMe)
   - OR work on bug bounty targets
   - OR develop custom tools

3. EVENING (1 hour):
   - Watch security talks/tutorials
   - Read security news (The Hacker News, Krebs on Security)
   - Participate in security communities (Twitter/X, Discord, Reddit)

WEEKLY:
   - Participate in at least one CTF event
   - Write up one of your findings or learnings
   - Review and update your methodology

MONTHLY:
   - Set specific goals (e.g., "find 3 XSS bugs this month")
   - Review progress and adjust strategy
   - Learn one new tool or technique in depth
```

---

*The most important thing is consistency. 2 hours every day beats 14 hours on weekends. Build the habit, and the skills will follow.*

