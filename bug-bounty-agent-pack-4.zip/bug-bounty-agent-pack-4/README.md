# Bug Bounty Super Agent Pack v4

The ultimate AI agent prompt pack for autonomous bug bounty hunting, penetration testing, vulnerability research, and offensive security operations.

## Overview

This pack transforms any AI coding agent into an elite bug bounty hunter and offensive security professional. It provides comprehensive instructions, methodologies, code templates, and automation scripts for finding vulnerabilities in web applications, APIs, networks, cloud infrastructure, and more.

## Supported AI Agents

| Agent | Config File | How to Use |
|-------|------------|------------|
| **Claude Code** | `AGENTS.md` | Place in workspace root or reference from `.agents/` |
| **Cline** | `.clinerules` | Copy to workspace root |
| **Cursor** | `.cursorrules` | Copy to workspace root |
| **OpenAI Codex** | `codex.md` | Reference in Codex configuration |
| **OpenCode** | `opencode.md` | Reference in OpenCode configuration |
| **Antigravity** | `antigravity.md` | Load in Antigravity IDE |

## File Structure

```
bug-bounty-agent-pack-4/
|-- AGENTS.md              # Master agent instructions (Claude Code primary)
|-- RULES.md               # Core operational rules and engagement modes
|-- SKILL.md               # Technical code templates and exploitation frameworks
|-- METHODOLOGY.md         # Complete bug bounty and pentest methodology
|-- CVE-RESEARCH.md        # CVE research, exploit analysis, and weaponization guide
|-- RECON-PLAYBOOK.md      # Reconnaissance and attack surface mapping playbook
|-- WRITEUP-ANALYSIS.md    # How to analyze writeups and extract techniques
|-- TOOLKIT.md             # Tools inventory, setup, and environment configuration
|-- LEARNING-PATH.md       # Cybersecurity student learning path
|-- .clinerules            # Cline-specific configuration
|-- .cursorrules           # Cursor-specific configuration
|-- codex.md               # OpenAI Codex instructions
|-- opencode.md            # OpenCode instructions
|-- antigravity.md         # Antigravity IDE integration
|-- README.md              # This file
|-- scripts/               # Python automation scripts
|   |-- recon.py           # Multi-source subdomain enumeration and HTTP probing
|   |-- scanner.py         # Vulnerability scanner (XSS, SQLi, SSRF, headers)
|   |-- reporter.py        # Bug bounty report generator
|   |-- cve_lookup.py      # CVE search tool using NVD API
|   |-- dorker.py          # Google dork generator
|-- templates/             # Report templates
|   |-- report-template.md # Bug bounty report template with CVSS guide
|-- wordlists/             # Custom wordlists (add your own)
```

## Quick Start

### 1. Install Python Dependencies
```powershell
pip install aiohttp requests beautifulsoup4 rich colorama dnspython
```

### 2. Run Recon
```powershell
python scripts/recon.py target.com --probe
```

### 3. Run Vulnerability Scanner
```powershell
python scripts/scanner.py "https://target.com/page?id=1" --all
```

### 4. Search for CVEs
```powershell
python scripts/cve_lookup.py apache 2.4 --severity critical --pocs
```

### 5. Generate Google Dorks
```powershell
python scripts/dorker.py target.com -o dorks.txt
```

### 6. Generate Report
```powershell
python scripts/reporter.py --interactive
python scripts/reporter.py --from-json scan_results.json
```

## Agent Capabilities

### 7 Operational Modes
1. **RECONNAISSANCE** - Attack surface mapping, subdomain enumeration, OSINT
2. **VULNERABILITY ASSESSMENT** - Testing for specific vulnerabilities with payloads
3. **EXPLOITATION** - Crafting exploits, bypassing protections, demonstrating impact
4. **POST-EXPLOITATION** - Privilege escalation, lateral movement, persistence
5. **REPORTING** - Professional bug bounty reports with CVSS scoring
6. **EDUCATION** - Concept explanations from first principles for students
7. **TOOLSMITH** - Building custom Python security tools

### Key Features
- Autonomous CVE research and exploit development
- Bug bounty writeup analysis and technique extraction
- Creative vulnerability chaining for maximum impact
- Multi-platform bug bounty support (HackerOne, Bugcrowd, Intigriti, YesWeHack)
- Comprehensive security posture analysis after findings
- Detailed learning notes for cybersecurity students
- Production-quality Python 3.14+ automation scripts

## Environment
- **OS:** Windows 11
- **Python:** 3.14.x+
- **Shell:** PowerShell

## Tool Installation Policy
- **Free to install:** pip packages, git clone repos, portable tools (into workspace)
- **Ask user first:** System-level installations, MSI/EXE, services
- **Ask user first:** MCP servers, IDE plugins, extensions

---

*Built for cybersecurity students and aspiring bug bounty hunters. Learn by doing.*

