# RECONNAISSANCE AND ATTACK SURFACE MAPPING PLAYBOOK

Step-by-step playbook for comprehensive target reconnaissance.

---

## PHASE 1: SCOPE DEFINITION

```
Before starting recon, clearly define:
1. What domains/IPs are in scope?
2. What is explicitly out of scope?
3. Are there rate limiting requirements?
4. Is automated scanning allowed?
5. What testing hours are permitted?
6. Are there any special rules (no DoS, no social engineering, etc.)?

Document this in a scope.txt file:
---
Program: [Company Name]
Platform: [HackerOne/Bugcrowd/etc.]
In-Scope:
  - *.target.com
  - api.target.com
  - mobile.target.com
Out-of-Scope:
  - blog.target.com (third-party hosted)
  - *.staging.target.com
Rules:
  - No automated scanning on production
  - No DoS testing
  - Report before accessing sensitive data
---
```

## PHASE 2: PASSIVE RECON CHECKLIST

```
[ ] Subdomain enumeration (Subfinder, Amass, crt.sh)
[ ] DNS record analysis (A, AAAA, MX, TXT, CNAME, NS, SOA)
[ ] WHOIS lookup
[ ] Certificate Transparency logs
[ ] Wayback Machine URL extraction
[ ] Google dorking (sensitive files, login pages, errors)
[ ] GitHub/GitLab secret scanning
[ ] Shodan/Censys infrastructure mapping
[ ] Social media OSINT
[ ] Job posting analysis (tech stack hints)
[ ] Pastebin/paste site searches
[ ] S3/Azure Blob/GCS bucket enumeration
[ ] ASN and IP range discovery
[ ] Email harvesting (Hunter.io, theHarvester)
[ ] Document metadata extraction (FOCA, exiftool)
```

## PHASE 3: ACTIVE RECON CHECKLIST

```
[ ] Port scanning (top 1000, then full if needed)
[ ] Service version detection
[ ] Web technology fingerprinting
[ ] Directory/file bruteforcing
[ ] Virtual host discovery
[ ] API endpoint discovery
[ ] Parameter discovery
[ ] JavaScript file analysis (LinkFinder, JSParser)
[ ] robots.txt and sitemap.xml analysis
[ ] .well-known directory check
[ ] CORS configuration testing
[ ] HTTP method testing
[ ] Security header analysis
[ ] SSL/TLS configuration testing
[ ] WAF detection and fingerprinting
```

## PHASE 4: ATTACK SURFACE PRIORITIZATION

```
Prioritize targets by likelihood of finding bugs:

HIGH PRIORITY:
1. Newly added features (less tested)
2. File upload functionality
3. Payment/transaction features
4. Authentication/password reset flows
5. API endpoints (especially undocumented)
6. Admin panels
7. Legacy/old subdomains
8. Third-party integrations
9. WebSocket endpoints
10. GraphQL endpoints

MEDIUM PRIORITY:
1. Search functionality
2. User profile/settings
3. Comment/review systems
4. Email functionality
5. Export/download features
6. Notification systems

LOWER PRIORITY (but still test):
1. Static content pages
2. FAQ/help pages
3. Marketing pages
4. CDN-served assets
```

## PHASE 5: RECON AUTOMATION SCRIPT

```bash
# Quick recon one-liner pipeline (adapt for your tools)
# Step 1: Subdomain enumeration
subfinder -d target.com -all -o subs.txt

# Step 2: Probe live hosts
cat subs.txt | httpx -title -tech-detect -status-code -follow-redirects -o live_hosts.txt

# Step 3: URL extraction from archives
cat subs.txt | waybackurls | sort -u > wayback_urls.txt
cat subs.txt | gau | sort -u > gau_urls.txt

# Step 4: Parameter extraction
cat wayback_urls.txt gau_urls.txt | sort -u | grep "=" > params.txt

# Step 5: JavaScript file extraction
cat wayback_urls.txt gau_urls.txt | sort -u | grep "\.js$" > js_files.txt

# Step 6: Directory bruteforcing on live hosts
cat live_hosts.txt | awk "{print $1}" | while read url; do
  ffuf -w /path/to/wordlist.txt -u "$url/FUZZ" -mc 200,301,302,403 -o "ffuf_$(echo $url | md5sum | cut -d' ' -f1).json"
done

# Step 7: Nuclei scanning
nuclei -l live_hosts.txt -t nuclei-templates/ -severity critical,high,medium -o nuclei_results.txt
```

## PHASE 6: RECON DATA ORGANIZATION

```
Organize your recon data in a structured folder:

target_name/
+-- scope.txt
+-- recon/
|   +-- subdomains.txt
|   +-- live_hosts.txt
|   +-- ports/
|   |   +-- nmap_results.xml
|   |   +-- masscan_results.txt
|   +-- urls/
|   |   +-- wayback_urls.txt
|   |   +-- gau_urls.txt
|   |   +-- params.txt
|   |   +-- js_files.txt
|   +-- tech/
|   |   +-- technologies.json
|   |   +-- headers.json
|   +-- secrets/
|       +-- github_leaks.txt
|       +-- js_secrets.txt
+-- vulns/
|   +-- nuclei_results.txt
|   +-- manual_findings/
+-- reports/
|   +-- report_001.md
+-- notes.md
```

---

*Run this playbook for every new target. Thorough recon is the foundation of successful bug bounty hunting.*

