# TOOLKIT - TOOLS, SETUP AND ENVIRONMENT CONFIGURATION

Complete tool inventory for bug bounty hunting on Windows 11 with Python 3.14+.

---

## 1. ESSENTIAL TOOLS BY CATEGORY

### 1.1. Reconnaissance Tools
```
Tool               | Type       | Install Method              | Purpose
--------------------|-----------|-----------------------------|---------------------------------
Subfinder           | Go binary | go install / download release| Passive subdomain enumeration
Amass               | Go binary | go install / download release| Comprehensive subdomain enum
httpx               | Go binary | go install / download release| HTTP probing and fingerprinting
naabu               | Go binary | go install / download release| Fast port scanner
Nmap                | Installer | Download from nmap.org       | Network scanning (ASK USER)
Masscan             | Binary    | Download release             | Ultra-fast port scanner
RustScan            | Binary    | Download release             | Fast port scanner + Nmap
theHarvester        | Python    | pip install theHarvester     | Email and subdomain harvesting
Shodan CLI          | Python    | pip install shodan           | Shodan search from CLI
```

### 1.2. Web Application Testing Tools
```
Tool               | Type       | Install Method              | Purpose
--------------------|-----------|-----------------------------|---------------------------------
Burp Suite          | Java app  | Download from portswigger    | Web proxy and scanner (ASK USER)
ffuf                | Go binary | Download release             | Web fuzzer (dirs, params, vhosts)
feroxbuster         | Rust bin  | Download release             | Recursive content discovery
dirsearch           | Python    | pip install dirsearch        | Directory bruteforcing
SQLMap              | Python    | pip install sqlmap           | SQL injection automation
XSStrike            | Python    | git clone                    | XSS scanner
Dalfox              | Go binary | Download release             | XSS scanner and parameter analysis
Arjun               | Python    | pip install arjun            | HTTP parameter discovery
ParamSpider         | Python    | git clone + pip install      | Parameter mining from archives
Nuclei              | Go binary | Download release             | Template-based vuln scanner
nikto               | Perl      | git clone                    | Web server scanner
```

### 1.3. Exploitation Tools
```
Tool               | Type       | Install Method              | Purpose
--------------------|-----------|-----------------------------|---------------------------------
Metasploit          | Ruby      | Installer (ASK USER)         | Exploitation framework
CyberChef           | Web       | https://gchq.github.io/CyberChef/ | Data encoding/decoding
jwt_tool            | Python    | git clone + pip install      | JWT testing and exploitation
Hashcat             | Binary    | Download release             | Password cracking (ASK USER)
John the Ripper     | Binary    | Download release             | Password cracking
CRLFuzz             | Go binary | Download release             | CRLF injection scanner
SSRFmap             | Python    | git clone                    | SSRF exploitation
Commix              | Python    | pip install commix           | Command injection exploitation
```

### 1.4. OSINT Tools
```
Tool               | Type       | Install Method              | Purpose
--------------------|-----------|-----------------------------|---------------------------------
Maltego             | Java app  | Download (ASK USER)          | Visual link analysis
SpiderFoot          | Python    | pip install spiderfoot       | Automated OSINT
recon-ng            | Python    | pip install recon-ng         | OSINT framework
theHarvester        | Python    | pip install theHarvester     | Email/subdomain harvesting
Sherlock            | Python    | pip install sherlock-project | Username enumeration
holehe              | Python    | pip install holehe           | Email to social media accounts
```

### 1.5. Python Libraries for Custom Tools
```
pip install aiohttp          # Async HTTP client
pip install requests         # HTTP library
pip install beautifulsoup4   # HTML parsing
pip install lxml             # XML/HTML parsing
pip install pyjwt            # JWT handling
pip install cryptography     # Crypto operations
pip install rich             # Beautiful terminal output
pip install colorama         # Colored terminal output
pip install argparse         # CLI argument parsing (stdlib)
pip install dnspython        # DNS queries
pip install python-whois     # WHOIS lookups
pip install shodan           # Shodan API
pip install censys           # Censys API
pip install selenium         # Browser automation
pip install playwright       # Browser automation
pip install scrapy           # Web scraping framework
pip install httpx            # Modern HTTP client (Python)
pip install pwntools         # CTF/exploit development
pip install scapy            # Packet manipulation
pip install impacket         # Network protocol tools
pip install paramiko         # SSH client
pip install python-nmap      # Nmap Python bindings
```

---

## 2. ENVIRONMENT SETUP

### 2.1. Python Virtual Environment
```powershell
# Create a dedicated venv for bug bounty tools
python -m venv .\bb-venv
.\.\bb-venv\Scripts\Activate.ps1

# Install core libraries
pip install aiohttp requests beautifulsoup4 lxml rich colorama dnspython python-whois httpx
```

### 2.2. Go Tools Installation
```powershell
# If Go is installed, install tools directly:
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
go install -v github.com/ffuf/ffuf/v2@latest
go install -v github.com/tomnomnom/waybackurls@latest
go install -v github.com/lc/gau/v2/cmd/gau@latest
go install -v github.com/hahwul/dalfox/v2@latest

# If Go is NOT installed, download pre-compiled binaries from GitHub releases
# and place them in the workspace tools/ folder
```

### 2.3. Workspace Structure
```
bug-bounty-agent-pack-4/
+-- AGENTS.md              # Master agent instructions
+-- RULES.md               # Core operational rules
+-- SKILL.md               # Technical skill templates
+-- METHODOLOGY.md         # Full methodology guide
+-- CVE-RESEARCH.md        # CVE research guide
+-- RECON-PLAYBOOK.md      # Recon playbook
+-- WRITEUP-ANALYSIS.md    # Writeup analysis guide
+-- TOOLKIT.md             # This file
+-- LEARNING-PATH.md       # Learning path
+-- .clinerules            # Cline config
+-- .cursorrules           # Cursor config
+-- codex.md               # Codex config
+-- opencode.md            # OpenCode config
+-- antigravity.md         # Antigravity config
+-- scripts/               # Python automation scripts
|   +-- recon.py           # Recon automation
|   +-- scanner.py         # Vulnerability scanner
|   +-- reporter.py        # Report generator
+-- templates/             # Report templates
+-- wordlists/             # Custom wordlists
+-- tools/                 # Downloaded portable tools
+-- targets/               # Per-target data
```

---

## 3. TOOL INSTALLATION POLICY

```
FREE TO INSTALL (No user confirmation needed):
- Python packages via pip
- Git clone repos into workspace
- Download portable binaries into workspace/tools/
- Create virtual environments
- Download wordlists

ASK USER FIRST:
- System-wide installations (MSI, EXE installers)
- Services (Docker, databases)
- Network tools that require admin privileges
- Browser extensions
- IDE plugins/MCP servers

ALWAYS PROVIDE:
- Exact installation command
- What the tool does
- Why it is needed for the current task
- Alternative if user declines
```

---

## 4. RECOMMENDED WORDLISTS

```
SecLists (ESSENTIAL - clone into workspace):
  git clone https://github.com/danielmiessler/SecLists.git

Key wordlists from SecLists:
- Discovery/Web-Content/common.txt (4,600 entries)
- Discovery/Web-Content/big.txt (20,469 entries)
- Discovery/Web-Content/directory-list-2.3-medium.txt (220,546 entries)
- Discovery/Web-Content/raft-large-words.txt (119,600 entries)
- Discovery/DNS/subdomains-top1million-5000.txt
- Fuzzing/SQLi/Generic-SQLi.txt
- Fuzzing/XSS/XSS-Jhaddix.txt
- Passwords/Common-Credentials/10-million-password-list-top-10000.txt

Assetnote Wordlists:
  https://wordlists.assetnote.io/
  Best for: Technology-specific wordlists

FuzzDB:
  git clone https://github.com/fuzzdb-project/fuzzdb.git
```

---

*Keep your tools updated. New versions often include new features and bug fixes that improve your testing capability.*

