#!/usr/bin/env python3
"""CVE Lookup Tool

Search for CVEs related to specific technologies using the NVD API.
Part of Bug Bounty Super Agent Pack v4.

Usage:
    python cve_lookup.py apache 2.4
    python cve_lookup.py wordpress --severity critical
    python cve_lookup.py log4j -o cves.json
"""

import asyncio
import aiohttp
import argparse
import json
import sys
from datetime import datetime


async def search_nvd(keyword: str, severity: str = None) -> list[dict]:
    """Search NVD for CVEs matching a keyword."""
    results = []
    async with aiohttp.ClientSession() as session:
        url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
        params = {
            "keywordSearch": keyword,
            "resultsPerPage": 50,
        }
        if severity:
            params["cvssV3Severity"] = severity.upper()

        try:
            print(f"[*] Searching NVD for: {keyword}")
            async with session.get(
                url, params=params,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    total = data.get("totalResults", 0)
                    print(f"[+] Total results: {total}")

                    for vuln in data.get("vulnerabilities", []):
                        cve = vuln.get("cve", {})
                        cve_id = cve.get("id", "")
                        descriptions = cve.get("descriptions", [])
                        desc = next(
                            (d["value"] for d in descriptions if d["lang"] == "en"),
                            "No description"
                        )

                        # Extract CVSS
                        metrics = cve.get("metrics", {})
                        cvss_score = None
                        cvss_severity = None
                        cvss_vector = None
                        for ver in ["cvssMetricV31", "cvssMetricV30", "cvssMetricV2"]:
                            if ver in metrics:
                                m = metrics[ver][0]
                                cvss_data = m.get("cvssData", {})
                                cvss_score = cvss_data.get("baseScore")
                                cvss_severity = cvss_data.get("baseSeverity", m.get("baseSeverity"))
                                cvss_vector = cvss_data.get("vectorString")
                                break

                        # Extract references
                        refs = []
                        for ref in cve.get("references", []):
                            refs.append(ref.get("url", ""))

                        results.append({
                            "cve_id": cve_id,
                            "description": desc[:300],
                            "cvss_score": cvss_score,
                            "cvss_severity": cvss_severity,
                            "cvss_vector": cvss_vector,
                            "published": cve.get("published", "")[:10],
                            "references": refs[:5],
                        })
                elif resp.status == 403:
                    print("[!] NVD API rate limited. Wait 30 seconds and try again.")
                else:
                    print(f"[!] NVD API returned status {resp.status}")
        except Exception as e:
            print(f"[!] Error: {e}")

    return results


async def search_github_pocs(cve_id: str) -> list[dict]:
    """Search GitHub for PoC exploits."""
    results = []
    async with aiohttp.ClientSession() as session:
        try:
            url = f"https://api.github.com/search/repositories?q={cve_id}+poc&sort=stars&order=desc&per_page=5"
            headers = {"Accept": "application/vnd.github.v3+json"}
            async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    for repo in data.get("items", [])[:5]:
                        results.append({
                            "name": repo["full_name"],
                            "url": repo["html_url"],
                            "stars": repo["stargazers_count"],
                            "description": (repo.get("description") or "")[:200],
                        })
        except Exception:
            pass
    return results


def main():
    parser = argparse.ArgumentParser(
        description="CVE Lookup Tool v4 - Search NVD for vulnerabilities",
    )
    parser.add_argument("keyword", nargs="+", help="Search keyword(s) (e.g., apache 2.4)")
    parser.add_argument("--severity", choices=["low", "medium", "high", "critical"],
                        help="Filter by CVSS severity")
    parser.add_argument("--pocs", action="store_true", help="Search GitHub for PoC exploits")
    parser.add_argument("-o", "--output", help="Output file (JSON)")
    args = parser.parse_args()

    keyword = " ".join(args.keyword)

    print("=" * 60)
    print("  CVE Lookup Tool v4")
    print(f"  Keyword: {keyword}")
    print(f"  Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    cves = asyncio.run(search_nvd(keyword, args.severity))

    if not cves:
        print("\n[!] No CVEs found.")
        return

    # Display results
    print(f"\n{'=' * 80}")
    for cve in cves:
        score = cve['cvss_score'] or 'N/A'
        severity = cve['cvss_severity'] or 'N/A'
        print(f"\n  {cve['cve_id']} | Score: {score} | Severity: {severity} | Published: {cve['published']}")
        print(f"  {cve['description']}")

        if args.pocs:
            pocs = asyncio.run(search_github_pocs(cve['cve_id']))
            if pocs:
                print(f"  PoCs found:")
                for poc in pocs:
                    print(f"    - {poc['url']} ({poc['stars']} stars)")
            cve['pocs'] = pocs

    print(f"\n{'=' * 80}")
    print(f"  Total CVEs: {len(cves)}")

    if args.output:
        with open(args.output, "w") as f:
            json.dump(cves, f, indent=2)
        print(f"  Saved to: {args.output}")


if __name__ == "__main__":
    main()

