#!/usr/bin/env python3
"""Google Dork Generator

Generate comprehensive Google dorks for bug bounty reconnaissance.
Part of Bug Bounty Super Agent Pack v4.

Usage:
    python dorker.py target.com
    python dorker.py target.com -o dorks.txt
"""

import argparse
from datetime import datetime


def generate_dorks(domain: str) -> list[dict]:
    """Generate categorized Google dorks for a target domain."""
    dorks = [
        # Sensitive files
        {"cat": "Sensitive Files", "dork": f'site:{domain} ext:sql | ext:db | ext:log | ext:cfg | ext:env | ext:ini | ext:bak'},
        {"cat": "Sensitive Files", "dork": f'site:{domain} ext:xml | ext:json | ext:yml | ext:yaml | ext:toml | ext:conf'},
        {"cat": "Sensitive Files", "dork": f'site:{domain} ext:pem | ext:key | ext:crt | ext:p12 | ext:pfx'},
        {"cat": "Sensitive Files", "dork": f'site:{domain} filetype:pdf | filetype:doc | filetype:xlsx | filetype:csv'},
        {"cat": "Sensitive Files", "dork": f'site:{domain} ext:swp | ext:old | ext:bak | ext:orig | ext:save'},

        # Directory listings
        {"cat": "Directory Listing", "dork": f'site:{domain} intitle:"index of" | intitle:"directory listing"'},
        {"cat": "Directory Listing", "dork": f'site:{domain} intitle:"index of" "parent directory"'},
        {"cat": "Directory Listing", "dork": f'site:{domain} intitle:"index of" ".git"'},

        # Login and admin pages
        {"cat": "Login Pages", "dork": f'site:{domain} inurl:login | inurl:signin | inurl:auth | inurl:sso'},
        {"cat": "Login Pages", "dork": f'site:{domain} inurl:admin | inurl:dashboard | inurl:panel | inurl:console'},
        {"cat": "Login Pages", "dork": f'site:{domain} inurl:wp-admin | inurl:wp-login | inurl:administrator'},
        {"cat": "Login Pages", "dork": f'site:{domain} intitle:"login" | intitle:"sign in" | intitle:"admin"'},

        # Information disclosure
        {"cat": "Info Disclosure", "dork": f'site:{domain} "password" | "api_key" | "apikey" | "secret" | "token"'},
        {"cat": "Info Disclosure", "dork": f'site:{domain} "BEGIN RSA PRIVATE KEY" | "BEGIN DSA PRIVATE KEY" | "BEGIN EC PRIVATE KEY"'},
        {"cat": "Info Disclosure", "dork": f'site:{domain} "AWS_SECRET_ACCESS_KEY" | "AKIA" | "aws_access_key_id"'},
        {"cat": "Info Disclosure", "dork": f'site:{domain} inurl:phpinfo | inurl:server-status | inurl:server-info'},
        {"cat": "Info Disclosure", "dork": f'site:{domain} inurl:debug | inurl:trace | inurl:test | inurl:staging'},
        {"cat": "Info Disclosure", "dork": f'site:{domain} "MYSQL_ROOT_PASSWORD" | "DATABASE_URL" | "DB_PASSWORD"'},

        # Error pages
        {"cat": "Error Pages", "dork": f'site:{domain} "SQL syntax" | "mysql_fetch" | "ORA-" | "PostgreSQL"'},
        {"cat": "Error Pages", "dork": f'site:{domain} "Warning:" "on line" ext:php'},
        {"cat": "Error Pages", "dork": f'site:{domain} "Fatal error" | "Uncaught exception" | "Stack trace"'},
        {"cat": "Error Pages", "dork": f'site:{domain} "Traceback (most recent call last)"'},
        {"cat": "Error Pages", "dork": f'site:{domain} inurl:error | inurl:exception | inurl:debug'},

        # API endpoints
        {"cat": "API Endpoints", "dork": f'site:{domain} inurl:api | inurl:/v1/ | inurl:/v2/ | inurl:/v3/'},
        {"cat": "API Endpoints", "dork": f'site:{domain} inurl:graphql | inurl:swagger | inurl:openapi | inurl:api-docs'},
        {"cat": "API Endpoints", "dork": f'site:{domain} ext:json inurl:api | ext:json inurl:config'},
        {"cat": "API Endpoints", "dork": f'site:{domain} inurl:rest | inurl:endpoint | inurl:webhook'},

        # Subdomains
        {"cat": "Subdomains", "dork": f'site:*.{domain} -www'},
        {"cat": "Subdomains", "dork": f'site:*.*.{domain}'},

        # Code leaks
        {"cat": "Code Leaks", "dork": f'site:github.com "{domain}"'},
        {"cat": "Code Leaks", "dork": f'site:gitlab.com "{domain}"'},
        {"cat": "Code Leaks", "dork": f'site:bitbucket.org "{domain}"'},
        {"cat": "Code Leaks", "dork": f'site:pastebin.com "{domain}"'},
        {"cat": "Code Leaks", "dork": f'site:trello.com "{domain}"'},
        {"cat": "Code Leaks", "dork": f'site:jira.atlassian.com "{domain}"'},
        {"cat": "Code Leaks", "dork": f'site:codepen.io "{domain}"'},
        {"cat": "Code Leaks", "dork": f'site:replit.com "{domain}"'},

        # Cloud storage
        {"cat": "Cloud Storage", "dork": f'site:s3.amazonaws.com "{domain}"'},
        {"cat": "Cloud Storage", "dork": f'site:blob.core.windows.net "{domain}"'},
        {"cat": "Cloud Storage", "dork": f'site:storage.googleapis.com "{domain}"'},
        {"cat": "Cloud Storage", "dork": f'site:digitaloceanspaces.com "{domain}"'},

        # Documents and data
        {"cat": "Documents", "dork": f'site:{domain} filetype:pdf "confidential" | "internal" | "restricted"'},
        {"cat": "Documents", "dork": f'site:{domain} filetype:xlsx | filetype:csv "password" | "email" | "user"'},
        {"cat": "Documents", "dork": f'site:{domain} filetype:docx "internal use only" | "not for distribution"'},

        # Technology specific
        {"cat": "Tech Specific", "dork": f'site:{domain} inurl:.env | inurl:docker-compose | inurl:Dockerfile'},
        {"cat": "Tech Specific", "dork": f'site:{domain} inurl:package.json | inurl:composer.json | inurl:Gemfile'},
        {"cat": "Tech Specific", "dork": f'site:{domain} inurl:.git/config | inurl:.git/HEAD'},
        {"cat": "Tech Specific", "dork": f'site:{domain} inurl:actuator | inurl:actuator/env | inurl:actuator/health'},
        {"cat": "Tech Specific", "dork": f'site:{domain} inurl:elmah.axd | inurl:trace.axd'},
    ]
    return dorks


def main():
    parser = argparse.ArgumentParser(description="Google Dork Generator for Bug Bounty v4")
    parser.add_argument("domain", help="Target domain")
    parser.add_argument("-o", "--output", help="Output file")
    parser.add_argument("-c", "--category", help="Filter by category")
    args = parser.parse_args()

    print("=" * 60)
    print("  Google Dork Generator v4")
    print(f"  Target: {args.domain}")
    print("=" * 60)

    dorks = generate_dorks(args.domain)

    if args.category:
        dorks = [d for d in dorks if args.category.lower() in d["cat"].lower()]

    current_cat = ""
    output_lines = []
    for d in dorks:
        if d["cat"] != current_cat:
            current_cat = d["cat"]
            header = f"\n--- {current_cat} ---"
            print(header)
            output_lines.append(header)
        print(f"  {d['dork']}")
        output_lines.append(d["dork"])

    print(f"\n[+] Total dorks generated: {len(dorks)}")

    if args.output:
        with open(args.output, "w") as f:
            f.write("\n".join(output_lines))
        print(f"[+] Saved to: {args.output}")


if __name__ == "__main__":
    main()

