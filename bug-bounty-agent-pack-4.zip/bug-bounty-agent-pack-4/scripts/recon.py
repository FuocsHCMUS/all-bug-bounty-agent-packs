#!/usr/bin/env python3
"""Bug Bounty Recon Automation Script

Multi-source subdomain enumeration, HTTP probing, and technology fingerprinting.
Part of Bug Bounty Super Agent Pack v4.

Usage:
    python recon.py target.com
    python recon.py target.com -o results/
    python recon.py target.com --probe --tech-detect
"""

import asyncio
import aiohttp
import argparse
import json
import re
import sys
import os
from datetime import datetime
from pathlib import Path
from typing import Optional


# ============================================================
# SUBDOMAIN ENUMERATION
# ============================================================

async def fetch_crtsh(session: aiohttp.ClientSession, domain: str) -> set[str]:
    """Query crt.sh Certificate Transparency logs."""
    subs = set()
    try:
        url = f"https://crt.sh/?q=%.{domain}&output=json"
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as resp:
            if resp.status == 200:
                data = await resp.json(content_type=None)
                for entry in data:
                    name = entry.get("name_value", "")
                    for sub in name.split("\n"):
                        sub = sub.strip().lower().replace("*.", "")
                        if sub.endswith(f".{domain}") or sub == domain:
                            subs.add(sub)
        print(f"  [+] crt.sh: {len(subs)} subdomains")
    except Exception as e:
        print(f"  [!] crt.sh error: {e}")
    return subs


async def fetch_hackertarget(session: aiohttp.ClientSession, domain: str) -> set[str]:
    """Query HackerTarget API."""
    subs = set()
    try:
        url = f"https://api.hackertarget.com/hostsearch/?q={domain}"
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as resp:
            if resp.status == 200:
                text = await resp.text()
                for line in text.strip().split("\n"):
                    if "," in line:
                        sub = line.split(",")[0].strip().lower()
                        if sub.endswith(f".{domain}") or sub == domain:
                            subs.add(sub)
        print(f"  [+] HackerTarget: {len(subs)} subdomains")
    except Exception as e:
        print(f"  [!] HackerTarget error: {e}")
    return subs


async def fetch_alienvault(session: aiohttp.ClientSession, domain: str) -> set[str]:
    """Query AlienVault OTX."""
    subs = set()
    try:
        url = f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns"
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as resp:
            if resp.status == 200:
                data = await resp.json()
                for entry in data.get("passive_dns", []):
                    hostname = entry.get("hostname", "").strip().lower()
                    if hostname.endswith(f".{domain}") or hostname == domain:
                        subs.add(hostname)
        print(f"  [+] AlienVault: {len(subs)} subdomains")
    except Exception as e:
        print(f"  [!] AlienVault error: {e}")
    return subs


async def fetch_rapiddns(session: aiohttp.ClientSession, domain: str) -> set[str]:
    """Query RapidDNS."""
    subs = set()
    try:
        url = f"https://rapiddns.io/subdomain/{domain}?full=1"
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=30)) as resp:
            if resp.status == 200:
                text = await resp.text()
                pattern = r"([a-zA-Z0-9][-a-zA-Z0-9]*\." + re.escape(domain) + r")"
                matches = re.findall(pattern, text)
                for m in matches:
                    subs.add(m.lower())
        print(f"  [+] RapidDNS: {len(subs)} subdomains")
    except Exception as e:
        print(f"  [!] RapidDNS error: {e}")
    return subs


async def fetch_urlscan(session: aiohttp.ClientSession, domain: str) -> set[str]:
    """Query urlscan.io."""
    subs = set()
    try:
        url = f"https://urlscan.io/api/v1/search/?q=domain:{domain}&size=1000"
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as resp:
            if resp.status == 200:
                data = await resp.json()
                for result in data.get("results", []):
                    page = result.get("page", {})
                    hostname = page.get("domain", "").strip().lower()
                    if hostname.endswith(f".{domain}") or hostname == domain:
                        subs.add(hostname)
        print(f"  [+] urlscan.io: {len(subs)} subdomains")
    except Exception as e:
        print(f"  [!] urlscan.io error: {e}")
    return subs


async def enumerate_subdomains(domain: str) -> set[str]:
    """Run all subdomain enumeration sources concurrently."""
    print(f"\n[*] Enumerating subdomains for: {domain}")
    async with aiohttp.ClientSession() as session:
        tasks = [
            fetch_crtsh(session, domain),
            fetch_hackertarget(session, domain),
            fetch_alienvault(session, domain),
            fetch_rapiddns(session, domain),
            fetch_urlscan(session, domain),
        ]
        results = await asyncio.gather(*tasks)
        all_subs = set()
        for result in results:
            all_subs.update(result)
        return all_subs


# ============================================================
# HTTP PROBING
# ============================================================

async def probe_host(session: aiohttp.ClientSession, host: str) -> Optional[dict]:
    """Probe a host for HTTP/HTTPS availability."""
    for scheme in ["https", "http"]:
        url = f"{scheme}://{host}"
        try:
            async with session.get(
                url, timeout=aiohttp.ClientTimeout(total=8),
                allow_redirects=True, ssl=False
            ) as resp:
                body = await resp.text(errors="ignore")
                title_match = re.search(r"<title[^>]*>(.*?)</title>", body, re.I | re.S)
                title = title_match.group(1).strip()[:100] if title_match else ""

                return {
                    "url": str(resp.url),
                    "host": host,
                    "status": resp.status,
                    "title": title,
                    "server": resp.headers.get("Server", ""),
                    "content_length": len(body),
                    "redirect": str(resp.url) if str(resp.url) != url else None,
                }
        except Exception:
            continue
    return None


async def probe_hosts(hosts: list[str], concurrency: int = 30) -> list[dict]:
    """Probe multiple hosts concurrently."""
    print(f"\n[*] Probing {len(hosts)} hosts...")
    sem = asyncio.Semaphore(concurrency)
    connector = aiohttp.TCPConnector(limit=concurrency, ssl=False)
    results = []

    async with aiohttp.ClientSession(connector=connector) as session:
        async def bounded_probe(host):
            async with sem:
                return await probe_host(session, host)

        tasks = [bounded_probe(h) for h in hosts]
        probe_results = await asyncio.gather(*tasks)
        for r in probe_results:
            if r:
                results.append(r)
                print(f"  [+] {r['url']} [{r['status']}] {r['title']}")

    print(f"[+] {len(results)} live hosts found")
    return results


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Bug Bounty Recon Automation - Subdomain Enumeration and HTTP Probing",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("domain", help="Target domain to enumerate")
    parser.add_argument("-o", "--output", help="Output directory", default=".")
    parser.add_argument("--probe", action="store_true", help="Probe discovered subdomains for live hosts")
    parser.add_argument("--concurrency", type=int, default=30, help="Concurrent connections for probing")
    args = parser.parse_args()

    # Create output directory
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("  Bug Bounty Recon Automation v4")
    print(f"  Target: {args.domain}")
    print(f"  Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # Subdomain enumeration
    subdomains = asyncio.run(enumerate_subdomains(args.domain))
    print(f"\n[+] Total unique subdomains: {len(subdomains)}")

    # Save subdomains
    subs_file = output_dir / f"{args.domain}_subdomains.txt"
    with open(subs_file, "w") as f:
        f.write("\n".join(sorted(subdomains)))
    print(f"[+] Subdomains saved to: {subs_file}")

    # HTTP probing
    if args.probe and subdomains:
        live_hosts = asyncio.run(probe_hosts(sorted(subdomains), args.concurrency))

        # Save live hosts
        live_file = output_dir / f"{args.domain}_live_hosts.json"
        with open(live_file, "w") as f:
            json.dump(live_hosts, f, indent=2)
        print(f"[+] Live hosts saved to: {live_file}")

    print(f"\n[*] Recon complete for {args.domain}")


if __name__ == "__main__":
    main()

