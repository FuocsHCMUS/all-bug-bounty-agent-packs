# Bug Bounty Report Template

## [Vulnerability Title]

### Summary
| Field | Value |
|-------|-------|
| **Severity** | [CRITICAL/HIGH/MEDIUM/LOW/INFO] |
| **CVSS Score** | [X.X] |
| **CVSS Vector** | [CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H] |
| **CWE** | [CWE-XXX: Name] |
| **Affected Asset** | [URL/endpoint] |
| **Date Reported** | [YYYY-MM-DD] |

### Description
[Clear, concise description of the vulnerability. What it is, where it is, and why it matters.]

### Steps to Reproduce
1. [Step 1 - Be specific enough that anyone can follow]
2. [Step 2]
3. [Step 3]
4. [Observe the result]

### Proof of Concept
```
[PoC code, curl command, or HTTP request/response]
```

### Impact
[Describe the real-world business impact. What can an attacker do? How many users are affected? What data is at risk?]

### Remediation
[Specific, actionable fix recommendations. Not just "fix the bug" but HOW to fix it.]

### References
- [OWASP reference]
- [CWE reference]
- [Related CVE if applicable]
- [Blog post or writeup]

---

## CVSS 3.1 Quick Reference

### Attack Vector (AV)
- Network (N): Remotely exploitable
- Adjacent (A): Requires adjacent network
- Local (L): Requires local access
- Physical (P): Requires physical access

### Attack Complexity (AC)
- Low (L): No special conditions
- High (H): Requires specific conditions

### Privileges Required (PR)
- None (N): No authentication needed
- Low (L): Basic user access
- High (H): Admin/elevated access

### User Interaction (UI)
- None (N): No user action needed
- Required (R): User must click/interact

### Scope (S)
- Unchanged (U): Impact limited to vulnerable component
- Changed (C): Impact extends beyond vulnerable component

### Impact (C/I/A)
- None (N): No impact
- Low (L): Limited impact
- High (H): Total compromise

### Common CVSS Scores
- RCE (unauthenticated): 9.8-10.0
- SQL Injection (data access): 7.5-9.8
- SSRF (internal access): 7.0-9.0
- Stored XSS: 6.1-8.0
- IDOR (data access): 6.5-7.5
- Reflected XSS: 5.4-6.1
- CSRF: 4.3-6.5
- Information Disclosure: 3.0-5.3
- Missing Security Headers: 2.0-4.0

