---
name: bug-bounty-agent-pack-5
description: Use when conducting authorized bug bounty research, checking CVE applicability, learning from writeups, preparing private reports, or mentoring a beginner during an approved investigation.
---

# Shared bounty skill adapter

Read [canonical AGENTS.md](../../../AGENTS.md) and [canonical SKILL.md](../../../SKILL.md), then follow their workflow. Resolve links in each loaded document relative to that document. This adapter adds no execution permission. Do not activate another wrapper for the same task.
