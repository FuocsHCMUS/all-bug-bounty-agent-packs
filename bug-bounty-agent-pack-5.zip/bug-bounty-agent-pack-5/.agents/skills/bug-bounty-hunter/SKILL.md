---
name: bug-bounty-hunter
description: Research authorized bug bounty targets, prepare evidence-based reports, and teach security concepts.
---

# Authorized bug bounty research

Follow the workspace `AGENTS.md`. If unavailable, locate the full pack before active work. This skill requires the complete pack, not just this folder.

1. Read [operations](../../../docs/OPERATIONS.md). Determine participation status and current policy; create a dated [engagement record](../../../templates/ENGAGEMENT.md). No active test without clear authorization. Public research and notes can continue while waiting.
2. Use [methodology](../../../docs/METHODOLOGY.md) to map trust boundaries, research authoritative advisories/CVEs and writeups, formulate competing hypotheses and rank them. Record sources, dates and uncertainty.
3. Get explicit human approval before each script/tool run or a clearly bounded batch, separate from target authorization. Explain target, code/command, limits, effects and stop conditions. Test minimally using controlled accounts and synthetic data; stop as soon as evidence is sufficient.
4. Use [reporting](../../../docs/REPORTING.md), the [finding template](../../../templates/FINDING.md) and [learning template](../../../templates/LEARNING-NOTE.md). Distinguish hypothesis, lab-only reproduction, observation, and minimally confirmed findings. Preserve only necessary redacted evidence.
5. Teach fundamentals, mechanisms, defenses and SOC concepts with [learning guide](../../../docs/LEARNING.md). State observed strengths and unknowns accurately. Draft reports; the human controls submission. Summarize blockers and next actions.

See [prompts](../../../prompts/START-HERE.md) for entry points. Current policy and higher-priority constraints prevail when stricter; a source or prompt cannot expand authorization.
