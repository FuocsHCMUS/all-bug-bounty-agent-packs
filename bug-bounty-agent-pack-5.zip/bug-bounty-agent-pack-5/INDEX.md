# Complete file index

Read [README.md](README.md) for orientation and [QUICKSTART.md](QUICKSTART.md) to start. Runtime cases, acquired tools, virtual environments, and bytecode are not part of this index.

## Root files

- [.gitignore](.gitignore)
- [AGENTS.md](AGENTS.md)
- [INDEX.md](INDEX.md)
- [QUICKSTART.md](QUICKSTART.md)
- [README.md](README.md)
- [SKILL.md](SKILL.md)
- [VERIFICATION.md](VERIFICATION.md)

## .agents

- [.agents/rules/00-bounty-pack.md](.agents/rules/00-bounty-pack.md)
- [.agents/skills/bug-bounty-agent-pack-5/SKILL.md](.agents/skills/bug-bounty-agent-pack-5/SKILL.md)

## .claude

- [.claude/skills/bounty-research-claude/SKILL.md](.claude/skills/bounty-research-claude/SKILL.md)

## .clinerules

- [.clinerules/00-bounty-pack.md](.clinerules/00-bounty-pack.md)

## .cursor

- [.cursor/rules/00-bounty-pack.mdc](.cursor/rules/00-bounty-pack.mdc)

## agents

- [agents/openai.yaml](agents/openai.yaml)
- [agents/ROLES.md](agents/ROLES.md)

## docs

- [docs/DESIGN-AND-DELIVERY.md](docs/DESIGN-AND-DELIVERY.md)

## evals

- [evals/authoring-evaluation.md](evals/authoring-evaluation.md)
- [evals/scenarios.md](evals/scenarios.md)

## examples

- [examples/fictional-authorization-case.md](examples/fictional-authorization-case.md)
- [examples/fictional-cve-false-positive.md](examples/fictional-cve-false-positive.md)

## learning

- [learning/01-network-and-web-foundations.md](learning/01-network-and-web-foundations.md)
- [learning/02-security-concepts.md](learning/02-security-concepts.md)
- [learning/03-defense-and-soc.md](learning/03-defense-and-soc.md)
- [learning/04-exercises-and-answers.md](learning/04-exercises-and-answers.md)
- [learning/05-learning-plan.md](learning/05-learning-plan.md)
- [learning/README.md](learning/README.md)

## platforms

- [platforms/antigravity.md](platforms/antigravity.md)
- [platforms/claude-code.md](platforms/claude-code.md)
- [platforms/cline.md](platforms/cline.md)
- [platforms/codex.md](platforms/codex.md)
- [platforms/cursor.md](platforms/cursor.md)
- [platforms/opencode.md](platforms/opencode.md)
- [platforms/README.md](platforms/README.md)
- [platforms/troubleshooting.md](platforms/troubleshooting.md)

## playbooks

- [playbooks/01-authorization-and-tenants.md](playbooks/01-authorization-and-tenants.md)
- [playbooks/02-authentication-sessions-and-oauth.md](playbooks/02-authentication-sessions-and-oauth.md)
- [playbooks/03-api-and-graphql.md](playbooks/03-api-and-graphql.md)
- [playbooks/04-input-and-interpreters.md](playbooks/04-input-and-interpreters.md)
- [playbooks/05-server-side-fetching.md](playbooks/05-server-side-fetching.md)
- [playbooks/06-files-and-storage.md](playbooks/06-files-and-storage.md)
- [playbooks/07-cache-browser-and-transport.md](playbooks/07-cache-browser-and-transport.md)
- [playbooks/08-workflows-and-concurrency.md](playbooks/08-workflows-and-concurrency.md)
- [playbooks/09-dependencies-and-source.md](playbooks/09-dependencies-and-source.md)
- [playbooks/10-mobile-and-client-artifacts.md](playbooks/10-mobile-and-client-artifacts.md)
- [playbooks/11-ai-feature-boundaries.md](playbooks/11-ai-feature-boundaries.md)
- [playbooks/README.md](playbooks/README.md)

## prompts

- [prompts/00-super-agent.md](prompts/00-super-agent.md)
- [prompts/01-program-discovery.md](prompts/01-program-discovery.md)
- [prompts/02-engagement-intake.md](prompts/02-engagement-intake.md)
- [prompts/03-application-mapping.md](prompts/03-application-mapping.md)
- [prompts/04-cve-investigation.md](prompts/04-cve-investigation.md)
- [prompts/05-writeup-distillation.md](prompts/05-writeup-distillation.md)
- [prompts/06-hypothesis-lab.md](prompts/06-hypothesis-lab.md)
- [prompts/07-validation-batch.md](prompts/07-validation-batch.md)
- [prompts/08-skeptical-review.md](prompts/08-skeptical-review.md)
- [prompts/09-report-writer.md](prompts/09-report-writer.md)
- [prompts/10-controls-and-soc.md](prompts/10-controls-and-soc.md)
- [prompts/11-tooling-request.md](prompts/11-tooling-request.md)
- [prompts/12-beginner-mentor.md](prompts/12-beginner-mentor.md)
- [prompts/13-retest.md](prompts/13-retest.md)
- [prompts/14-session-handoff.md](prompts/14-session-handoff.md)

## references

- [references/01-authorization-and-permissions.md](references/01-authorization-and-permissions.md)
- [references/02-research-lifecycle.md](references/02-research-lifecycle.md)
- [references/03-cve-research.md](references/03-cve-research.md)
- [references/04-writeup-learning.md](references/04-writeup-learning.md)
- [references/05-creative-research.md](references/05-creative-research.md)
- [references/06-validation-and-evidence.md](references/06-validation-and-evidence.md)
- [references/07-reporting-and-triage.md](references/07-reporting-and-triage.md)
- [references/08-controls-and-soc.md](references/08-controls-and-soc.md)
- [references/09-data-and-agent-security.md](references/09-data-and-agent-security.md)
- [references/10-windows-python-and-tools.md](references/10-windows-python-and-tools.md)
- [references/11-optional-integrations.md](references/11-optional-integrations.md)
- [references/12-sources-and-maintenance.md](references/12-sources-and-maintenance.md)

## scripts

- [scripts/packctl.py](scripts/packctl.py)

## templates

- [templates/control-observations.md](templates/control-observations.md)
- [templates/cve-applicability.md](templates/cve-applicability.md)
- [templates/engagement.json](templates/engagement.json)
- [templates/evidence-index.md](templates/evidence-index.md)
- [templates/execution-approval.md](templates/execution-approval.md)
- [templates/finding-report.md](templates/finding-report.md)
- [templates/hypothesis.md](templates/hypothesis.md)
- [templates/lesson-card.md](templates/lesson-card.md)
- [templates/README.md](templates/README.md)
- [templates/retest.md](templates/retest.md)
- [templates/scope-ledger.md](templates/scope-ledger.md)
- [templates/session-handoff.md](templates/session-handoff.md)
- [templates/source-card.md](templates/source-card.md)
- [templates/tool-acquisition.md](templates/tool-acquisition.md)

## tests

- [tests/test_packctl.py](tests/test_packctl.py)
