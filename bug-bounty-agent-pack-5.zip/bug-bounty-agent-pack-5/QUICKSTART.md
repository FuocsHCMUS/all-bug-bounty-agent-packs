# Quickstart

## 1. Open the right workspace

Open `bug-bounty-agent-pack-5` directly in your agent. Read [platforms/README.md](platforms/README.md) and the guide for that product. No MCP server, plugin, external skill installation, scanner, Docker, WSL, or API account is required to start using the pack.

Ask the agent:

```text
Read AGENTS.md and SKILL.md. Use this pack as my authorized bug bounty research
workspace and beginner security mentor. Start in research-only mode. Explain
your permission boundaries, identify the instructions you actually loaded,
and propose the next useful task without contacting a test target.
```

An agent claiming to be ready is not proof the runtime loaded these files. Confirm file paths in the product's instruction/context UI where available, then use the [behavior scenarios](evals/scenarios.md).

## 2. Choose a starting task

For public program discovery:

```text
Use prompts/01-program-discovery.md. Research public HackerOne and Bugcrowd
program pages and produce a shortlist suitable for a beginner. Check current
rules, AI/automation restrictions, exclusions, account needs, and uncertainty.
Do not start active testing. Recommend one program and prepare an engagement draft.
```

For a specific program:

```text
Use prompts/02-engagement-intake.md. Here is the official program URL: [paste URL].
Read its current policy. Prepare the scope ledger, unresolved questions, an
application-learning plan, and a small proposed test batch. I will approve
execution separately. Use only my test accounts and synthetic data.
```

For learning without a target:

```text
Use prompts/12-beginner-mentor.md. Teach DNS, TCP, TLS, HTTP, cookies, sessions,
and authorization from first principles. Use the fictional example and local
paper exercises in learning/. Give short quizzes and explain every new term.
```

## 3. Create a case

Ask the agent to copy the templates, or review and authorize the offline helper:

```powershell
python .\scripts\packctl.py new-case my-first-program
python .\scripts\packctl.py validate-case .\cases\my-first-program\engagement.json
```

The generated case starts with no allowed assets and no execution approval. Successful structural validation does not grant permission to test.

## 4. Approve a concrete execution batch when ready

Use [execution approval](templates/execution-approval.md). Include exact commands/tool versions, asset and method limits, accounts, duration, total requests, concurrency, data handling, and stop conditions. A reusable approval may cover repeated identical bounded actions; it never expands to new hosts, techniques, code, costs, or risk. Ask again only when those materially change.

If no budget is agreed, active testing stays blocked. Do not invent a supposedly safe universal request rate. A public webpage fetch for reading published policy is not permission to scan that site.

## 5. Review the result

Expect a research log even when no vulnerability is confirmed. A good output includes what was checked, what evidence supports the conclusion, what remains unknown, a private report draft if appropriate, control observations with limitations, and one lesson connecting the issue to its defensive detection and fix.

Use [prompts/14-session-handoff.md](prompts/14-session-handoff.md) before switching products or ending a long session. Resume from written state, recheck policy and unexpired approvals, and do not repeat tests merely because context was lost.
