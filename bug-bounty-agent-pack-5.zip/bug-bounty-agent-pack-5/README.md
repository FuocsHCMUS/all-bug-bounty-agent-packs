# Bug Bounty Agent Pack 5

A detailed, English-language operating pack for authorized vulnerability research and beginner security education. Designed for Claude Code, Codex, OpenCode, Cline, Cursor, and Google Antigravity on Windows 11 with Python 3.14+.

**Start here:** [QUICKSTART.md](QUICKSTART.md). **Persistent instructions:** [AGENTS.md](AGENTS.md). **Skill entrypoint:** [SKILL.md](SKILL.md). **Copy/paste master prompt:** [prompts/00-super-agent.md](prompts/00-super-agent.md).

Browse the [complete file index](INDEX.md) or the [verification record](VERIFICATION.md).

## What this pack provides

- A senior researcher operating model: program selection, scope interpretation, application mapping, evidence-driven hypotheses, bounded validation, private reporting, and retesting.
- CVE research that checks actual applicability instead of treating a version banner as a vulnerability.
- Writeup and CTF learning that extracts root causes, trust boundaries, and reusable ideas while accounting for production differences.
- Advanced reasoning through invariants, state machines, differential tests, patch analysis, attack graphs, and falsifiable experiments.
- A beginner curriculum explaining networking, HTTP, identity, authorization, vulnerability classes, remediation, telemetry, and incident response.
- Evidence templates, permission records, research ledgers, control observations, SOC notes, lesson cards, and session handoffs.
- Small offline Python utilities to create case folders, check engagement configuration, and hash evidence. They send no network requests and run no testing tools.

The pack does not promise findings, zero-days, payment, or universal compliance by agents. Prompt instructions are guidance. Use application approvals, OS isolation, separate browser profiles, and request limits as real execution controls.

## Suggested reading paths

| Need | Read next |
| --- | --- |
| Open it in an agent | [Quickstart](QUICKSTART.md), then the matching [platform guide](platforms/README.md) |
| Learn the workflow | [Lifecycle](references/02-research-lifecycle.md) |
| Understand permissions | [Authorization and permissions](references/01-authorization-and-permissions.md) |
| Investigate a CVE | [CVE research](references/03-cve-research.md) |
| Learn from a writeup | [Writeup learning](references/04-writeup-learning.md) |
| Develop original hypotheses | [Creative research](references/05-creative-research.md) |
| Start learning cyber | [Foundations](learning/01-network-and-web-foundations.md), then [learning plan](learning/05-learning-plan.md) |
| Draft a finding | [Reporting](references/07-reporting-and-triage.md) and [report template](templates/finding-report.md) |
| Explain company controls | [Control observations](references/08-controls-and-soc.md) |
| Prepare local tools | [Windows and Python](references/10-windows-python-and-tools.md) |

## Working folders

`cases/<case-id>/` holds engagement-specific records. Keep raw evidence private and separate from shareable reports. `tools/` is for approved portable acquisitions. `.venv/` is for project-local Python packages. `research/` is for source cards and reusable concepts. These runtime folders are ignored by Git. Templates and fictional examples are safe to share after review; real case material usually is not.

Open **this folder itself** as the workspace. Opening only its parent may prevent some products from discovering the nested instructions or skills until they visit this folder.

## Default operating posture

Public research and local writing can proceed. Before active target testing, record the current program policy, exact assets and exclusions, permitted methods, applicable AI/automation rules, and a user-approved execution plan. Ask before testing script/tool execution, machine installations, MCP/plugin/skill additions, or sending/submitting anything. Lightweight portable downloads and workspace-local `pip` installation are permitted preparation under the conditions in AGENTS.md.

The user's intention is to review findings and submit them personally. Always finish with a private report package and an educational explanation. Do not click Submit or contact a company unless separately instructed.

Platform documentation was checked on **2026-11-03**. See [sources](references/12-sources-and-maintenance.md) for links, compatibility qualifications, and update instructions. No live bounty target was tested while authoring this pack.
