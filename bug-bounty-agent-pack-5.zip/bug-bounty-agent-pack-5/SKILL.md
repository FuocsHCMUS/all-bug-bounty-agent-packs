---
name: bug-bounty-agent-pack-5
description: Use when conducting authorized bug bounty research, reviewing CVE applicability, learning from security writeups, preparing private vulnerability reports, or mentoring a beginner through an approved security investigation.
---

# Bug Bounty Research and Mentoring

Read [AGENTS.md](AGENTS.md) first. This skill supports authorized research; it is not permission to test a target. Keep public research, executable preparation, approved validation, and external submission as separate decisions.

## Choose the working mode

| User's need | Load |
| --- | --- |
| Start or select a program | [Discovery prompt](prompts/01-program-discovery.md), [lifecycle](references/02-research-lifecycle.md) |
| Establish scope or approvals | [Intake prompt](prompts/02-engagement-intake.md), [permissions](references/01-authorization-and-permissions.md) |
| Understand an application | [Mapping prompt](prompts/03-application-mapping.md), relevant [playbook](playbooks/README.md) |
| Research CVEs | [CVE guide](references/03-cve-research.md), [CVE prompt](prompts/04-cve-investigation.md) |
| Learn a technique | [Writeup guide](references/04-writeup-learning.md), [source prompt](prompts/05-writeup-distillation.md) |
| Create test hypotheses | [Research methods](references/05-creative-research.md), [hypothesis prompt](prompts/06-hypothesis-lab.md) |
| Validate a candidate | [Validation guide](references/06-validation-and-evidence.md), [execution prompt](prompts/07-validation-batch.md) |
| Write or challenge a report | [Reporting guide](references/07-reporting-and-triage.md), [skeptical review](prompts/08-skeptical-review.md) |
| Assess observed controls or SOC implications | [Controls guide](references/08-controls-and-soc.md), [control prompt](prompts/10-controls-and-soc.md) |
| Learn fundamentals | [Learning index](learning/README.md), [mentor prompt](prompts/12-beginner-mentor.md) |
| Prepare tools or integrations | [Windows tools](references/10-windows-python-and-tools.md), [integrations](references/11-optional-integrations.md) |
| Diagnose instruction or skill loading | [Loading troubleshooting](platforms/troubleshooting.md) |
| Resume work | [Handoff prompt](prompts/14-session-handoff.md) |

## Working loop

1. Identify the active case, state, current policy, and actual permissions. Start `RESEARCH_ONLY` if incomplete.
2. Separate facts from hypotheses. Build a small ranked queue with falsification criteria.
3. Prepare the least invasive useful experiment and negative control. Present the exact bounded plan before requesting execution approval.
4. Execute only within program permission and recorded user approval. Stop on unexpected data, scope changes, instability, or sufficient proof.
5. Review evidence skeptically. Confirm only demonstrated behavior; record rejected or unresolved hypotheses too.
6. Produce private report drafts, scoped control observations, remediation and SOC notes, and beginner lesson cards.
7. Save a handoff with spent budget, artifacts, approvals, unknowns, and next actions.

Use [templates](templates/README.md) for records. The [master prompt](prompts/00-super-agent.md) provides a full copy/paste activation. The [fictional case](examples/fictional-authorization-case.md) shows expected evidence quality without claiming a real finding.
