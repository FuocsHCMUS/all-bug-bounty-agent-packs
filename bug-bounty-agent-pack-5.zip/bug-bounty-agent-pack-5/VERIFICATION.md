# Verification and delivery record

Verified on 2026-11-03 using Windows 11 and Python **3.14.8**.

## What was verified

- Offline unit suite: **22 tests discovered, 21 passed, 1 skipped, 0 failures**. The symlink-creation test was skipped because the current Windows session lacks the required creation privilege. Path/overwrite/default-state/numeric-validation/hash/change-detection tests passed. Mocked regression tests verify that UNC/device/outside-workspace paths are rejected before filesystem metadata checks and that parent redirect checks precede child inspection.
- CLI smoke checks: created a synthetic research-only case; validated it while returning `authorization_verified: false`; hashed a local `abc` fixture to the expected SHA-256; refused an overwrite attempt.
- Root skill and both discovery wrappers passed the installed skill-creator `quick_validate.py` validator.
- OpenAI UI metadata, Cursor rule frontmatter, and Antigravity rule frontmatter parsed as valid YAML with their expected activation keys.
- All JSON artifacts parsed and Python sources parsed. Local Markdown links were checked for existence and containment within this pack.
- An independent baseline evaluator correctly handled five paper scenarios. A separate forward evaluator handled nine scenarios using the actual instructions. No hard policy contradiction was found; two usability improvements were incorporated. See [evaluation record](evals/authoring-evaluation.md).

## Test commands

```powershell
python -B -m unittest discover -s tests -v
python -B .\scripts\packctl.py new-case my-reviewed-case
python -B .\scripts\packctl.py validate-case .\cases\my-reviewed-case\engagement.json
python -B .\scripts\packctl.py manifest .\cases\my-reviewed-case\evidence\redacted
```

The last three commands are examples of the tested interfaces; review/approve helper execution in future agent sessions. They are not target tests. Running `new-case` with an existing ID intentionally fails.

The helper and tests need only the standard library. PyYAML 6.0.3 was installed as a trusted Windows/Python 3.14 wheel into a workspace-local `.venv/` solely to run the author's skill/YAML validators. It did not alter system Python. The automatic approval layer rejected cleanup, including a proposed constrained non-recursive alternative, with `blocked by policy` and no more specific reason. Therefore `.venv/`, `cases/pack-offline-selftest/`, and generated `__pycache__/` folders remain locally. They contain authoring dependencies, an explicitly synthetic `abc` fixture, or bytecode; they are Git-ignored and excluded from INDEX.md and content counts. No further deletion workaround was attempted.

## Review-driven correction

A read-only helper review identified that the original path check could inspect a Windows UNC path before rejecting it, and could inspect a child before detecting an ancestor junction. The implementation now rejects remote/device syntax and outside-workspace CLI paths lexically, then checks local components parent-first using lstat. Regression checks use mocked metadata calls; they do not test against a live network endpoint.

## Limits

No real bounty target was scanned or exploited. No findings, CVE applicability, company weaknesses, or bounty eligibility were established. Fictional examples are labeled synthetic. No report was submitted and no company was contacted.

The six products' official configuration documentation was researched; the products were **not** each launched and tested end to end. Product versions, managed settings, and ancestor instructions can affect discovery. Use [platform troubleshooting](platforms/troubleshooting.md) and the paper scenarios on the actual installed product.

Structural validation is not program authorization, human consent, live URL scope matching, current-policy verification, approval-expiry enforcement, request-budget enforcement, or a security sandbox. File hashing is an integrity aid, not proof of authenticity or a complete legal chain of custody. Filesystem checks assume the local tree is not being adversarially changed between checks; do not use this helper as an isolation boundary.
