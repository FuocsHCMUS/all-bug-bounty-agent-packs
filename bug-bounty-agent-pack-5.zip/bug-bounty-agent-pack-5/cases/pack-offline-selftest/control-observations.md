# Scoped control and SOC observations

- Case, assets, time window, methods, and sample limits: [scope]
- Data sources actually available: [evidence]

| Domain/control | Label | Evidence | What the control protects | Confidence and limits | Improvement/next verification |
| --- | --- | --- | --- | --- | --- |
| [control] | [OBSERVED_EFFECTIVE/OBSERVED_WEAKNESS/INFERRED_RISK/NOT_ASSESSED] | [IDs] | [concept] | [scope] | [specific action] |

## Defender learning

- Root cause and primary prevention: [fix]
- Proposed telemetry fields and privacy limits: [schema idea]
- Correlation/detection concept: [logic]
- Legitimate alternatives/false positives: [cases]
- Internal verification the owner could perform: [steps]
- Containment/recovery considerations: [owner decisions]
- Regression tests and residual uncertainty: [coverage]

This memo does not score whole-company maturity or claim knowledge of unobserved internal practices.
