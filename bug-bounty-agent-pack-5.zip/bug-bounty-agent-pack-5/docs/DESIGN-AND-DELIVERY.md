# Design and delivery plan

Date: 2026-11-03. Language: English. Intended host: Windows 11, Python 3.14 or newer.

## User requirements

Create a substantial portable prompt pack for Claude Code, Codex, OpenCode, Cline, Cursor, and Google Antigravity. Support authorized bug bounty discovery, scope analysis, CVE applicability research, writeup learning, original hypothesis development, controlled validation, private reporting, company control observations, and beginner education spanning networking, application security, pentesting, and SOC work. Keep everything in this folder. Permit lightweight portable downloads and workspace-local Python dependency installation; ask before running testing scripts/tools, machine installations, or adding MCP servers/plugins/skills.

## Architecture

Use one canonical AGENTS.md for persistent constraints, a concise root SKILL.md for on-demand routing, deep references and playbooks, reusable prompts and templates, and small platform adapters. Prefer a native AGENTS.md setup over conflicting copies of a large prompt. Ship explicit skill-discovery wrappers for .agents and .claude. No installed skills, global configuration changes, live target contact, accounts, API keys, subscriptions, or background jobs are needed to use the documentation.

Two alternatives were considered: a single giant instruction file (easy to paste but expensive and easy to truncate), and six independent packs (easy initial integration but high policy drift). Shared policy with small adapters preserves depth while keeping startup context manageable.

## Deliverables and acceptance

- [x] Check official platform instruction-file documentation and record dates and uncertainty.
- [x] Write shared instructions, master prompt, specialist roles, permission policy, and working states.
- [x] Write workflows, testing playbooks, source research, education, reporting, and defense guides.
- [x] Add templates, fictional worked examples, platform setup, and dependency guidance.
- [x] Add only offline, standard-library Python helpers, with tests for meaningful filesystem and validation behavior.
- [x] Check local links, JSON, skill metadata, helper behavior, and realistic agent pressure scenarios.
- [x] Deliver a file index and explain expansions beyond the original request.

The pack contains no automated target scanner or exploit runner. Its autonomy is in planning, public research, analyzing authorized artifacts, and preparing evidence-based tests. Active work needs a documented program scope and the user's approval for a bounded execution plan. This is a product boundary, not a claim that prompts enforce a security sandbox.

## Verification limits

Document structural checks and offline helper tests do not prove runtime compliance in six different products. Independent scenario evaluation tests instructions without contacting targets. Record actual results and do not claim six-platform end-to-end validation unless those applications were exercised.
