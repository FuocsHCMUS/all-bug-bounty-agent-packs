# Integration and discovery

Open this folder as the workspace. `AGENTS.md` is the source of project instructions; the skill is at `.agents/skills/bug-bounty-hunter/SKILL.md`. Keep the directory structure intact. Rules are prompts, not hooks or a sandbox. Configure each product's own permissions.

| Agent | Setup and fallback |
|---|---|
| Codex | Open the folder; supported versions discover project `AGENTS.md` and project skills. Ask which files were read. If needed explicitly request both paths. |
| OpenCode | Open the folder; official documentation describes `AGENTS.md`. If skill discovery differs, explicitly request both paths. |
| Claude Code | Direct `AGENTS.md` support requires v2.1.277 or later. By default it loads when there is no `CLAUDE.md` or `CLAUDE.local.md` in the working directory or ancestors; settings and session type also matter. Check `/memory` and `/config`. Explicitly ask it to read the skill path. If direct loading is unavailable, use a `CLAUDE.md` importing `@AGENTS.md` or select the documented setting. |
| Cline | Current documentation lists `AGENTS.md` as a supported rule; check the Rules panel. Explicitly load the skill, or use `.clinerules/` to direct it to the files if needed. |
| Cursor | Check whether `AGENTS.md` loads; otherwise explicitly read both files or add an always-applied rule in `.cursor/rules/` using current documentation. |
| Google Antigravity | Open this folder and verify rule discovery. If needed explicitly read both files or configure the appropriate workspace rule according to current documentation. |

A Markdown link is not necessarily automatically imported: ask the agent to actually read the relevant file. Versions and precedence change. Do not replace existing rules or install MCP servers, plugins, extensions or skills globally without approval. Restart after changing configuration if needed.

Smoke test: ask the agent to summarize its user-approval rule and where it records scope. It should distinguish permission to test from permission to execute a script, and should not run a scan. This demonstrates observed behavior, not a guarantee.
