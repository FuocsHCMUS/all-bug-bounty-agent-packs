# Learning companion

Teach each case in layers: a plain analogy, exact terms, a request/data-flow sequence, the mechanism, observed evidence, realistic impact, defenses, detection and verification. Explain where the analogy breaks down. Use invented data, a small exercise with answer, and suggested next reading. Never confuse lab behavior with evidence on a real target.

## Foundations

1. Programs run as processes with identities and permissions. A network links systems through addresses and ports. DNS maps names to records; domain, IP and HTTP host are related but distinct. TLS protects a connection and authenticates a server within its trust model; it does not guarantee a secure application.
2. A browser sends an HTTP request containing a method, URL, headers and sometimes a body; a server returns a status, headers and body. Cookies may carry session identifiers. Explain token exposure and redact secrets. An API exposes operations. Authentication identifies an actor, authorization decides permitted actions, and auditing records events.
3. A trust boundary is where data or authority crosses between components or actors. An invariant is a property that must remain true: for example, only a permitted user may read an item. Threat models connect assets, actors, entry points, boundaries and assumptions.
4. A vulnerability is a weakness with security impact in context. CVE identifies a catalogued vulnerability, not proof a deployment is affected. CWE names a weakness class. CVSS describes severity characteristics; CISA KEV signals known exploitation, not that a specific host is vulnerable. Risk depends on exposure, likelihood, impact and uncertainty.

## Mechanisms and examples

Imagine Alice and Bob have separate objects. A server should check authorization on every request, not merely hide Bob's object in the interface. Explain the legitimate request, boundary, expected response, controlled-account observation and data-access check. For injection, explain the difference between data and executable syntax and the role of parameterization in a local example. For browser problems, distinguish origin, site, session and attacker control. For caches, explain keys and audience isolation. For business logic, draw a state machine and specify the invariant before considering sequences or races.

## Defense, SOC and practice

Separate prevention (server-side authorization, least privilege, safe APIs), detection (appropriate structured actor/object/action/outcome/time events), response (triage, contain, preserve, notify, recover), and verification (positive and negative regression tests). Logging alone does not prove a SOC monitors an event; a WAF or rate limit does not replace authorization. For each detection idea discuss missing telemetry, privacy, false positives and a response path.

Suggested progression: networking/DNS/TLS; HTTP and browser tools; Windows/Linux basics; Python; identity and access; OWASP web/API security; databases and cloud; threat modeling; secure coding; logging and incident response; clear reports. Practice in intentionally vulnerable local apps or sanctioned labs. Request approval before running tools even locally.
