# Research and investigation methodology

## Choose and understand

Compare current official programs by eligibility, exact assets, exclusions, automation, permitted accounts and beginner suitability. Read the whole brief. Public, private/invitation, vulnerability disclosure and bounty programs can have different terms and reward eligibility. Record source and time; choose a narrow surface. An index entry is discovery, not permission.

Map legitimate actors, assets, entry points, identities, roles, data flows, trust boundaries and state transitions. Record exact scheme, hostname, port and path, account and policy basis. Map third parties separately. Enumerate relevant features such as login, recovery, organizations, sharing, invitations, uploads, APIs, billing and background jobs. Stick to authorized test accounts.

## CVEs and published research

Search official vendor advisories and patch notes, CVE records, NVD, CISA KEV, authoritative project repositories and reputable writeups. Record source and retrieval time, component, affected versions, prerequisite features and configuration, fixed releases, reachability, evidence for product/version, potential backports and confidence. A banner, version, CPE match, KEV listing or scanner output alone is not proof. CDNs may fingerprint a different component and vendors may backport patches. Translate writeups and CTF techniques into hypotheses; lab behavior does not establish production impact or permission. Treat PoCs as untrusted code and do not execute without authorization and human approval.

## Hypothesis design

For each hypothesis record asset, entry point, trust boundary, expected invariant, proposed failure, prerequisites, minimal distinguishing observation, benign baseline/control, competing explanations, effects and stop conditions. Prioritize by reachability, evidence quality, potential impact and test cost. Seek creative combinations by comparing identity against ownership, cache keys against authorization, request processing against asynchronous jobs, state transitions against transactions, parser differences, client checks against server checks and role changes against existing sessions. Use a disposable lab to understand uncertain or risky behavior first.

## Questions by class

- Authorization: compare permitted access for two controlled identities and their own objects, roles and tenants; change one variable and retain a baseline. Never access real users' objects.
- Authentication/session: examine registration, recovery, MFA, rotation and revocation without brute force or account lockout. Confirm account ownership and policy.
- Input handling: trace untrusted values across parsing and interpretation boundaries, including templates, databases, paths and redirects. Learn dangerous mechanisms in a local lab; use harmless markers where permitted.
- Business logic: model state, retries, limits and transitions. Purchases, messages, credits and race tests can affect production: require explicit program authorization and human approval, and prefer sandbox resources.
- APIs and browsers: assess actual server enforcement, origin handling and caching in context. A missing header or reflected string alone rarely proves impact. WebSockets, mobile clients and GraphQL need explicit scope.
- Uploads, cloud and integrations: map processing identity and destination boundary. Do not probe internal networks, execute files, retrieve metadata or use callbacks without explicit program permission and specific approval.
- Supply chain: correlate component, version, configuration and reachability. Treat scanner matches and version strings as leads, not proof.

## Verify and decide

Confirm scope and propose minimal observations; request approval before running scripts/tools. Establish a baseline, change a variable, preserve sanitized evidence and use negative controls within approved limits. Consider cache, proxy, asynchronous processing, test data and user error as alternative explanations. Classify `hypothesis`, `inconclusive`, `lab-only`, `observed`, or `confirmed with minimal evidence`. Client observations rarely establish server-side root cause. Stop when sufficient proof exists. Recheck policy at each new session.
