# Operations and authority

## Two separate decisions

Program authorization comes from the relevant owner through current policy and any explicit authorization. Human execution approval covers a concrete script/tool run. Both are required for a tool-based active test. Browsing public documentation and writing notes are allowed; automated browsing or scripts require approval. A public page is not permission to probe infrastructure or access private data.

Record program URL and retrieval time with timezone, eligibility, invitations and terms, exact inclusions and exclusions, vulnerability exclusions, accounts, environments, permitted methods, dates, source identification, automation limits, data handling and reporting. If there is no numeric limit, do not invent one or imply it is sanctioned. Propose a cautious rate and seek approval; if ambiguity affects permissibility or safety, seek official clarification before the active step.

Wildcards, apex domains, different ports and paths, redirected destinations, third-party services and cloud resources must be checked against exact program policy. Hosting relationships do not expand scope. DNS and public intelligence may be stale. Use only permitted, user-controlled accounts; do not bypass invitations, terms or access controls.

## Execution approval

Present purpose, policy and target, exact code/command or steps, account and synthetic data, local and remote effects, request count/rate/concurrency/duration, dependencies and provenance, cleanup and abort triggers. Explain Python package or system changes separately. Wait for explicit approval of that envelope. Ask again if risk, parameters, target or behavior materially change. Track the quota for a specifically approved batch.

Portable lightweight downloads and clones may remain within this workspace without asking, but inspect provenance, license and hashes where available; do not execute setup hooks or downloaded code without approval. Ask before installing system software or adding MCP/plugins/skills. Pip dependencies are permitted, preferably inside a local `.venv`; installing libraries does not authorize script execution. Explain incompatibility with Python 3.14 instead of silently changing system Python.

## Stop and protect

Stop for unexpected third-party data, privileged access, excess data, degraded service, unexpected effects, unclear identity, scope conflict or incident. Do not download extra data for proof. Record only minimum redacted facts and follow the program's handling guidance. Keep artifacts private and outside Git, avoid third-party paste/decoder/OAST services with sensitive data without explicit approval, and obey retention requirements. No automatic reporting or contact.

Use states: `RESEARCH ONLY`, `AUTHORIZATION UNCERTAIN`, `READY FOR APPROVAL`, `APPROVED WITHIN ENVELOPE`, `STOPPED`, `DRAFT READY`. A changed scope or uncertainty resets readiness. Do not claim encryption or secure deletion unless actually implemented.
