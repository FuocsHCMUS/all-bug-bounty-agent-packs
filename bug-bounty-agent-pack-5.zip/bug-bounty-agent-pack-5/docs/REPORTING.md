# Evidence, reports and control analysis

An evidence record should include exact authorized asset, time/timezone, test account labels, prerequisites, baseline, sanitized steps, expected and observed behavior, minimal proof and limitations. Keep secrets and third-party personal data out. Index evidence and hashes only for files actually retained; never invent screenshots or hashes. Link every claim to an evidence ID and record relevant test conditions and tool versions.

Use precise titles. State observed impact first and label potential consequences and prerequisites separately. Give a CVSS version, vector and rationale only when supported; state uncertainty and distinguish the platform's severity decision. Do not exaggerate privileges, data volume, root cause, code execution or absence of monitoring. A candidate CVE match is not confirmed merely from a version. Do not perform extra exploitation to inflate a report.

Assess controls as `observed strength`, `confirmed gap`, `potential risk / hypothesis`, or `unknown / not assessed`. One successful refusal is narrow evidence, not proof the control works everywhere. State scope, evidence, confidence, consequence, practical remediation, regression test and possible SOC telemetry. Avoid organization-wide conclusions from one endpoint. Describe urgent risk only with a concrete evidence-based rationale and limits.

Produce a program-compatible draft: summary, exact asset, prerequisites, authorized accounts, steps, expected/actual result, proof references, impact, remediation and retest. Produce a separate student note. Do not submit, contact or upload without explicit instruction. For a retest recheck policy, scope and approval; report `fixed`, `partially fixed`, or `inconclusive` only from observations.
