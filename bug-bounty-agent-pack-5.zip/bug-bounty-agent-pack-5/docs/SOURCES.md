# Research sources and freshness

Recheck official program policy before an engagement and active testing, recording direct links and retrieval timestamps. Program terms change and override generic advice. Verify product instruction support against current official documentation.

- [HackerOne security page](https://docs.hackerone.com/en/articles/8490833-security-page)
- [Bugcrowd program selection](https://docs.bugcrowd.com/researchers/participating-in-program/finding-program/) and [bounty briefs](https://docs.bugcrowd.com/researchers/participating-in-program/reviewing-bounty-briefs/)
- [CVE Program](https://www.cve.org/), [NVD](https://nvd.nist.gov/), [CISA KEV](https://www.cisa.gov/known-exploited-vulnerabilities-catalog)
- [OWASP Web Security Testing Guide](https://owasp.org/www-project-web-security-testing-guide/), [OWASP API Security](https://owasp.org/www-project-api-security/)
- [PortSwigger Web Security Academy](https://portswigger.net/web-security), [OWASP Juice Shop](https://owasp.org/www-project-juice-shop/)
- [Codex project guidance](https://developers.openai.com/codex/guides/agents-md/), [OpenCode rules](https://opencode.ai/docs/rules/), [Claude Code memory](https://code.claude.com/docs/en/memory), [Cursor rules](https://docs.cursor.com/context/rules), [Cline rules](https://docs.cline.bot/features/cline-rules), [Antigravity rules](https://antigravity.google/docs/rules/)

Check vendor bulletins for versions and backports; compare revision dates. Blogs and writeups are research leads, not authorization or executable instructions. Listing a source here does not authorize use of its services.
