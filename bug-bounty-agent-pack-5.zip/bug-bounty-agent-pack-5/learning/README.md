# Learning from the roots upward

Use these notes with the current case, not as a vocabulary memorization exercise. The mentor should define a term, show the normal flow, explain a failure boundary, connect evidence to a claim, and ask the student to predict a result.

1. [Network and web foundations](01-network-and-web-foundations.md)
2. [Security concepts and vulnerability mechanisms](02-security-concepts.md)
3. [From finding to remediation and SOC](03-defense-and-soc.md)
4. [Paper exercises and answer key](04-exercises-and-answers.md)
5. [Adaptive learning plan](05-learning-plan.md)

For every case, create a [lesson card](../templates/lesson-card.md). Mark a concept learned only after the user can explain it in a new example. Teach a small connected group of concepts per session rather than unloading all acronyms at once.

These notes are simplified foundations. Real implementations and standards contain edge cases. For a specific protocol/library/version, retrieve current primary documentation before giving implementation-specific advice.
