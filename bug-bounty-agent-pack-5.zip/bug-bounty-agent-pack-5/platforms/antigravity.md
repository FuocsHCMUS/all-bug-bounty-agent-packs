# Google Antigravity

Current [official rules documentation](https://antigravity.google/docs/rules/) supports AGENTS.md and .agents/rules, with legacy .agent compatibility. The supplied rule uses `trigger: always_on`; current docs require valid trigger frontmatter for modular rules. [Skills documentation](https://antigravity.google/docs/skills) describes the project skill mechanism.

Open the pack root, inspect active workspace rules, and read AGENTS.md plus root SKILL.md. Prefer the shared `.agents/skills/bug-bounty-agent-pack-5/` wrapper. An older IDE build may use different legacy paths; verify its official documentation or explicitly read the canonical files. Do not create duplicate full policy copies in .agent and .agents.

No root GEMINI.md is necessary for this default setup. Keep terminal/browser permission review and artifact review active. Do not use an unrestricted execution mode to make the agent seem more autonomous. Parallel agents are optional and need user approval; they share scope and budgets.

Inspect discovery on the actual surface in use: App, CLI, and IDE/extension behavior can differ. The pack has not been run end to end in all three surfaces.
