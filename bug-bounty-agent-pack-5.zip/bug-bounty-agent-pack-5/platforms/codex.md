# Codex

Use the pack root's AGENTS.md and `.agents/skills/bug-bounty-agent-pack-5/SKILL.md`. The [official instructions guide](https://learn.chatgpt.com/docs/agent-configuration/agents-md) describes ancestor discovery and overrides; [skill documentation](https://learn.chatgpt.com/docs/build-skills) describes local project skills. Existing personal or parent instructions can affect behavior.

1. Open this folder directly as the workspace, then start/resume a session.
2. Ask Codex to read AGENTS.md and activate `$bug-bounty-agent-pack-5` when available. Explicit file reading is the fallback.
3. Confirm it states RESEARCH_ONLY and prepares a plan before testing.
4. Keep sandbox and approval controls appropriate to the task; this pack does not require unrestricted execution.

The root instructions are deliberately smaller than a long manual. Detailed references load on demand, helping avoid the documented instruction-size cap. Do not increase limits or alter global config just to load every reference at startup.

No OpenAI API key, model-specific option, scheduled task, or multi-agent feature is required. The logical roles can run sequentially in one session. If the user later approves delegation, every worker inherits the same program scope and shared execution budget.
