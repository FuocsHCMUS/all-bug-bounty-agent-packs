# OpenCode

[Official rules documentation](https://opencode.ai/docs/rules/) supports AGENTS.md. [Skills documentation](https://opencode.ai/docs/skills/) describes project skill directories including .agents/skills and .claude/skills compatibility. Discovery and permission configuration differ across major versions.

Open the pack root, ask OpenCode to read AGENTS.md and root SKILL.md, and choose the shared `bug-bounty-agent-pack-5` skill if listed. The Claude wrapper may appear as a second, differently named entry; do not activate both for the same task.

No opencode.json is required here. A static permission example for the wrong major version could silently weaken controls, so this pack leaves runtime configuration to the installed product. Review its native settings and retain confirmation for shell, outside-workspace access, network testing, and external integrations. Do not use a universal allow policy.

If skill discovery fails, explicitly read the canonical files. Do not run /init over this pack as a troubleshooting shortcut; it may rewrite the instruction source. If you choose to generate additional project configuration, review the exact diff first and preserve the shared permission rules.
