# Copy-and-use prompts

Open the pack as workspace, replace bracketed fields, and avoid sharing credentials. Ask the agent to read `AGENTS.md` and the skill first.

## Find a program

> Read `AGENTS.md` and `.agents/skills/bug-bounty-hunter/SKILL.md`. Research public HackerOne or Bugcrowd programs using official pages. Compare eligibility, exact assets, exclusions, automation and account restrictions; select two beginner-suitable candidates. Cite current sources and dates and draft a scope record. Distinguish unknowns from confirmed permission. Only browse public documentation and write notes. Do not scan, run scripts/tools, register or submit reports.

## Investigate a program

> Follow this pack for [official URL]. My participation status is [status], authorized assets [exact assets] and test accounts [labels]. Verify current policy and build an authorization matrix. Rank hypotheses for [feature], research relevant CVEs and writeups, and explain evidence and uncertainty. Propose minimal verification and ask before each tool or script run. Do not use real user data or submit anything.

## Research a CVE without touching a host

> Research [CVE ID] using the CVE record, vendor advisory and NVD. Explain component, versions, prerequisites, mechanism, backports, detection and remediation. Build an applicability matrix for [product/version evidence], separating observations and assumptions. Do not probe a host or execute a PoC. Explain what authorization would be needed for further verification.

## Learn in a lab

> Teach [concept] from networking and HTTP fundamentals through the vulnerability, remediation and SOC visibility. Propose an isolated synthetic-data lab, setup, cleanup and exercise. Before running commands, scripts or tools, request my approval and explain effects. Include a solution and quiz.

## Review a finding

> Analyze [redacted evidence/paths] against `docs/REPORTING.md`. Identify facts, alternative explanations, gaps, severity assumptions and program acceptance concerns. Draft a report and separate beginner note, evaluating observed strengths, confirmed gaps and unknown controls. Do not submit or contact anyone.

## Resume

> Read [engagement folder] and recheck official policy. Summarize authorized scope, previous approvals and their applicability, hypotheses, evidence, stop conditions and next safe action. Ask before new or materially changed script/tool execution; do not reuse approval for another target.
