# Windows 11, Python 3.14+, and local tools

## Principles

Keep dependencies and acquisitions within this workspace. Use native PowerShell paths and commands. Do not modify the machine's execution policy, PATH, registry, Defender, firewall, certificates, services, or Python installation to make a tool convenient. Ask before machine installations or runtime changes. Do not assume Unix commands, Docker, WSL, administrator rights, or Python wheels exist.

The user permits local Python dependency setup. Prefer the standard library whenever it meets the task. The included helpers require **no third-party libraries**. They do not scan hosts, make HTTP requests, download CVEs, execute PoCs, or submit reports.

## Interpreter and virtual environment

Review commands before execution under the relevant permission rule:

```powershell
python --version
python -m venv .venv
.\.venv\Scripts\python.exe -m pip --version
```

Activation is optional. Calling the full interpreter path avoids changing PowerShell execution policy and avoids installing into the wrong Python. For a needed package, replace the package/version with a reviewed choice:

```powershell
.\.venv\Scripts\python.exe -m pip install --only-binary=:all: "reviewed-package==reviewed-version"
```

That last line is a syntax example, not a runnable dependency declaration. Do not run placeholder names. Record the actual pinned choice, origin, reason, license, and any transitive dependencies. Export versions after installation if useful, then review for private URLs/credentials before sharing. Do not upgrade every package or pip by habit.

If Python 3.14 lacks a compatible wheel, use a standard-library alternative or another reviewed tool. Explain the compatibility failure. Ask before installing compilers, another interpreter, or a source build. Do not assume Python 3.15 or a future version is backward compatible without checking.

## Portable acquisition record

For every downloaded archive/repository, record tool name, task it enables, official URL, version/commit, checksum, license, expected compressed/extracted size, exact workspace destination, dependency requirements, network behavior, and inspection result. The user's blanket permission covers lightweight portable acquisition. Ask when size is substantial, unclear, or likely to trigger a large dependency chain. Do not run the acquired code automatically.

Reject archives with absolute paths, `..` traversal, unexpected symlinks/junctions, or files targeting trusted instruction locations. Inspect extraction paths before writing. Avoid recursive cloning unless the user understands the additional acquisitions. Do not use a downloaded repo as the top-level agent workspace.

## Tool categories and decisions

| Category | When it helps | Decision |
| --- | --- | --- |
| Built-in browser/editor | Read policies, inspect user-supplied artifacts | Start here |
| Offline parsers/hashers | Normalize evidence and create local records | Included helper; review/approve execution |
| Intercepting proxy | Understand approved manual request flows | Check existing install first; install/run require appropriate approval |
| Dependency/source analyzer | User-owned or program-authorized source | Review data exposure and file scope |
| Broad scanner/fuzzer | Only explicit program-permitted, bounded tests | Never a default discovery step |
| Exploit framework/public PoC | Understand an advisory, preferably in a lab | Inspect source; separate execution approval; avoid harmful modules |
| Packet capture | A narrow authorized local diagnostic | Can collect unrelated secrets; ask about scope and drivers |

Do not download a toolkit bundle simply because it is popular. Tool names and recommendations change; verify current official releases and Windows/Python compatibility when actually needed.

## Included offline helper commands

From the pack root, after approval:

```powershell
python .\scripts\packctl.py new-case example-case
python .\scripts\packctl.py validate-case .\cases\example-case\engagement.json
python .\scripts\packctl.py manifest .\cases\example-case\evidence\redacted
python -m unittest discover -s tests -v
```

`manifest` prints JSON to standard output; it does not write into the evidence tree. Redirect to a separate file if wanted. Do not save the manifest inside the input folder and expect repeated runs to be identical. File hashes reflect the files at read time; stop concurrent writers for a stable snapshot.

`validate-case` checks structural completeness. It cannot verify program ownership, policy truth, genuine human approval, URL scope, or runtime request limits. Keep the actual policy and approval records available for review.

## Process cleanup

Record any process started, port bound, files created, and shutdown command. Bind local labs to loopback, isolate them, and stop after use. A loopback service can still be reachable by local processes; it is not a full sandbox. Verify resolved paths before any recursive removal. Use `Remove-Item -LiteralPath` only on a verified workspace path and preserve evidence the user still needs.
