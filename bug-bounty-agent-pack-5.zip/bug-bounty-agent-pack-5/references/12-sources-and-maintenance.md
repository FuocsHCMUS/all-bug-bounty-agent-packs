# Sources, compatibility, and maintenance

Checked: **2026-11-03**. These are primary sources consulted while authoring the pack. Platform discovery and policy details change; verify them again when installing or using a different product/version. The original workflows and examples in this pack are author-created guidance, not copied platform manuals.

## Agent configuration sources

| Platform | Official source | Configuration conclusion |
| --- | --- | --- |
| Claude Code | [Memory and project instructions](https://code.claude.com/docs/en/memory) | Native AGENTS.md support is documented, with version/configuration and CLAUDE-file caveats. No root CLAUDE.md is required for this pack's default setup. |
| Claude Code skills | [Skills](https://code.claude.com/docs/en/skills) | Use a project .claude/skills wrapper when native skill discovery is wanted. |
| Codex | [AGENTS.md instructions](https://learn.chatgpt.com/docs/agent-configuration/agents-md), [build skills](https://learn.chatgpt.com/docs/build-skills) | AGENTS.md and project .agents/skills are documented. Keep startup instructions small. |
| OpenCode | [Rules](https://opencode.ai/docs/rules/), [skills](https://opencode.ai/docs/skills/) | AGENTS.md and native/cross-compatible project skills are documented. Major-version config differs; the pack does not hard-code shell permission JSON. |
| Cline | [Rules](https://docs.cline.bot/customization/cline-rules) | AGENTS.md and .clinerules/ are documented. Keep task execution approvals enabled. |
| Cursor | [Rules](https://cursor.com/docs/rules) | AGENTS.md plus .cursor/rules/*.mdc adapters are supported. |
| Google Antigravity | [Rules](https://antigravity.google/docs/rules/), [skills](https://antigravity.google/docs/skills) | Current docs use .agents/ with legacy .agent/ compatibility; AGENTS.md is supported. Rule frontmatter needs a valid trigger. |

OpenCode's official repository documentation was also queried through Context7 for skill discovery. Retrieved sources included [skills documentation](https://github.com/anomalyco/opencode/blob/dev/services/www/src/docs/content/skills.mdx). No Context7 or other MCP setup is required by this pack.

## Security research sources

- [HackerOne safe harbor overview](https://docs.hackerone.com/en/articles/8494502-safe-harbor-overview-faq): scope remains explicit; read the selected program's current terms.
- [Bugcrowd finding a program](https://docs.bugcrowd.com/researchers/participating-in-program/finding-program/): program scope and participation constraints.
- [Bugcrowd code of conduct](https://www.bugcrowd.com/resources/hacker-resources/code-of-conduct/): conduct and confidentiality, including GenAI considerations. Consult the live wording.
- [Bugcrowd public disclosure policy](https://docs.bugcrowd.com/researchers/disclosure/disclosure/): disclosure permissions and confidentiality expectations.
- [OWASP WSTG](https://owasp.org/www-project-web-security-testing-guide/): testing methodology. Cite the version/section actually used rather than an unstable latest section number.
- [OWASP API Security Project](https://owasp.org/www-project-api-security/): API authorization and related risk categories.
- [FIRST CVSS](https://www.first.org/cvss/): severity framework; [FIRST EPSS](https://www.first.org/epss/): exploitation-probability estimates.
- [CVE Program](https://www.cve.org/) and [NVD](https://nvd.nist.gov/): recommended lookup destinations; no particular CVE was researched or claimed applicable while building the pack.
- [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog): recommended prioritization source. The authoring browser received a 403 on the catalog page; no current catalog contents/count were used.

## Maintenance procedure

1. Reopen official documentation for the product version actually installed.
2. Verify instruction discovery, precedence, skill paths, and rule frontmatter. Use native context/settings inspection and behavior tests.
3. Change canonical AGENTS.md/SKILL.md first. Update small adapters only where routing changes.
4. Never add broad tool auto-approval as a compatibility fix.
5. Run offline tests and local reference checks, then the evaluation scenarios.
6. Record what was tested, product/version, date, and limitations in a new verification note.

This pack's authoring checks do not establish that each desktop product was launched or obeyed every instruction. Be explicit about that distinction when distributing it.
