"""Offline case preparation and evidence hashing. Python 3.14+, stdlib only.

No network clients, subprocesses, package installation, scanning, or submission.
Configuration validation does not establish program or human authorization.
"""
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path, PureWindowsPath
import re
import stat
import sys

PACK_ROOT = Path(__file__).resolve().parents[1]
DEVICE_NAMES = {"con", "prn", "aux", "nul"} | {
    f"{prefix}{number}" for prefix in ("com", "lpt") for number in range(1, 10)
}


def local_path(value):
    """Lexically reject remote/device/alternate-stream paths before any metadata."""
    raw = str(value)
    windows = PureWindowsPath(raw)
    if raw.replace("\\", "/").startswith("//") or windows.drive.startswith("\\\\"):
        raise ValueError("Remote and Windows device paths are not allowed")
    if windows.drive and not windows.root:
        raise ValueError("Drive-relative paths are not allowed")
    if any(":" in part for part in windows.parts[1 if windows.drive else 0:]):
        raise ValueError("Alternate-stream and URI paths are not allowed")
    return Path(os.path.abspath(raw))


def reject_redirected_path(path):
    """Inspect parents before children; lstat never follows the inspected leaf."""
    path = local_path(path)
    for component in reversed((path, *path.parents)):
        try:
            info = component.lstat()
        except FileNotFoundError:
            continue
        attributes = getattr(info, "st_file_attributes", 0)
        if stat.S_ISLNK(info.st_mode) or attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
            raise ValueError(f"Refusing redirected path: {component}")


def new_case(case_root, case_id):
    """Create one new folder; never reuse/overwrite a case or accept path syntax."""
    if not isinstance(case_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,63}", case_id):
        raise ValueError("Case ID must be 1-64 lowercase letters/digits/hyphens, starting with a letter/digit")
    if case_id in DEVICE_NAMES:
        raise ValueError("Case ID is a reserved Windows device name")
    case_root = local_path(case_root)
    reject_redirected_path(case_root)
    case_root.mkdir(parents=True, exist_ok=True)
    destination = case_root / case_id
    reject_redirected_path(destination)
    destination.mkdir(exist_ok=False)
    data = json.loads((PACK_ROOT / "templates" / "engagement.json").read_text(encoding="utf-8"))
    data["case_id"] = case_id
    (destination / "engagement.json").write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    for name in ("research", "hypotheses", "evidence/raw", "evidence/redacted", "reports", "lessons", "approvals"):
        (destination / name).mkdir(parents=True)
    template_map = {
        "scope-ledger.md": "scope-ledger.md",
        "execution-approval.md": "approvals/execution-plan.md",
        "evidence-index.md": "evidence-index.md",
        "control-observations.md": "control-observations.md",
        "session-handoff.md": "session-handoff.md",
    }
    for source, target in template_map.items():
        content = (PACK_ROOT / "templates" / source).read_text(encoding="utf-8")
        (destination / target).write_text(content, encoding="utf-8")
    return destination


def validate_engagement(data):
    """Return structural errors only. This cannot certify permission or scope."""
    if not isinstance(data, dict):
        return ["engagement must be a JSON object"]
    errors = []
    if type(data.get("schema_version")) is not int or data["schema_version"] != 1:
        errors.append("schema_version must be integer 1")
    mode = data.get("mode")
    if mode not in ("research-only", "local-lab", "live-testing"):
        errors.append("mode must be research-only, local-lab, or live-testing")
    case_id = data.get("case_id")
    if not isinstance(case_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,63}", case_id) or case_id in DEVICE_NAMES:
        errors.append("case_id must be a valid non-reserved lowercase case identifier")
    if not isinstance(data.get("status"), str) or not data["status"].strip():
        errors.append("status must be a nonempty string")
    sections = {}
    for name in ("program", "limits", "execution_approval"):
        value = data.get(name)
        if not isinstance(value, dict):
            errors.append(f"{name} must be an object")
            value = {}
        sections[name] = value
    for name in ("allowed_assets", "excluded_assets", "allowed_methods", "test_accounts", "stop_conditions"):
        if not isinstance(data.get(name), list):
            errors.append(f"{name} must be an array")
    for name in ("allowed_assets", "excluded_assets"):
        if isinstance(data.get(name), list):
            for index, asset in enumerate(data[name]):
                if not isinstance(asset, dict) or any(
                    not isinstance(asset.get(key), str) or not asset[key].strip()
                    for key in ("type", "value", "scope_evidence")
                ):
                    errors.append(f"{name}[{index}] must contain nonempty type, value, and scope_evidence strings")
    for name in ("allowed_methods", "test_accounts", "stop_conditions"):
        if isinstance(data.get(name), list) and any(
            not isinstance(item, str) or not item.strip() for item in data[name]
        ):
            errors.append(f"{name} entries must be nonempty strings")
    limits = sections["limits"]
    for name in ("max_requests", "max_concurrency", "duration_minutes", "max_response_bytes"):
        value = limits.get(name)
        if value is not None and (type(value) is not int or value <= 0):
            errors.append(f"limits.{name} must be null or a positive integer")
    value = limits.get("max_requests_per_second")
    if value is not None and (type(value) not in (int, float) or not 0 < value < float("inf")):
        errors.append("limits.max_requests_per_second must be null or a finite positive number")
    if type(limits.get("max_retries")) is not int or limits["max_retries"] < 0:
        errors.append("limits.max_retries must be a nonnegative integer")
    approval = sections["execution_approval"]
    if type(approval.get("approved")) is not bool:
        errors.append("execution_approval.approved must be a boolean")
    if mode in ("local-lab", "live-testing"):
        for name in ("max_requests", "max_requests_per_second", "max_concurrency", "duration_minutes", "max_response_bytes"):
            if limits.get(name) is None:
                errors.append(f"limits.{name} is required for execution modes")
        if approval.get("approved") is not True:
            errors.append("execution_approval.approved must reference an actual human approval")
        for name in ("plan_id", "plan_path", "human_record_path", "approved_at", "expires_at"):
            if not isinstance(approval.get(name), str) or not approval[name].strip():
                errors.append(f"execution_approval.{name} is required for execution modes")
        for name in ("approved_at", "expires_at"):
            value = approval.get(name)
            if isinstance(value, str) and value.strip():
                try:
                    parsed = datetime.fromisoformat(value)
                    if parsed.utcoffset() is None:
                        raise ValueError("timezone required")
                except ValueError:
                    errors.append(f"execution_approval.{name} must be an ISO timestamp with timezone")
        if not data.get("stop_conditions"):
            errors.append("stop_conditions must be nonempty for execution modes")
    if mode == "live-testing":
        program = sections["program"]
        for name in ("name", "policy_url", "reviewed_at", "disclosure_rule"):
            if not isinstance(program.get(name), str) or not program[name].strip():
                errors.append(f"program.{name} is required for live-testing")
        if program.get("participation_eligible") is not True:
            errors.append("program.participation_eligible must be reviewed for live-testing")
        if program.get("ai_and_automation_reviewed") is not True:
            errors.append("program.ai_and_automation_reviewed must be true for live-testing")
        for name in ("allowed_assets", "allowed_methods", "test_accounts"):
            if not isinstance(data.get(name), list) or not data[name]:
                errors.append(f"{name} must be nonempty for live-testing")
    return errors


def evidence_manifest(folder):
    """Hash regular files without following filesystem redirects or writing files."""
    folder = local_path(folder)
    reject_redirected_path(folder)
    if not folder.is_dir():
        raise ValueError("Evidence input must be a directory")
    rows = []
    pending = [folder]
    while pending:
        current = pending.pop()
        reject_redirected_path(current)
        for entry in sorted(current.iterdir()):
            reject_redirected_path(entry)
            if entry.is_dir():
                pending.append(entry)
                continue
            before = entry.stat()
            if not stat.S_ISREG(before.st_mode):
                raise ValueError(f"Not a regular file: {entry}")
            digest = hashlib.sha256()
            with entry.open("rb") as stream:
                while chunk := stream.read(1024 * 1024):
                    digest.update(chunk)
            after = entry.stat()
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise ValueError(f"File changed while hashing: {entry}")
            rows.append({"path": entry.relative_to(folder).as_posix(), "bytes": after.st_size, "sha256": digest.hexdigest()})
    return sorted(rows, key=lambda item: item["path"])


def workspace_input(value):
    path = local_path(value)
    if not path.is_relative_to(PACK_ROOT):
        raise ValueError("CLI paths must remain inside the pack workspace")
    reject_redirected_path(path)
    return path


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    create = commands.add_parser("new-case", help="Create a new research-only case; never overwrite")
    create.add_argument("case_id")
    validate = commands.add_parser("validate-case", help="Check JSON structure, not actual authorization")
    validate.add_argument("path")
    manifest = commands.add_parser("manifest", help="Print SHA-256 manifest; no writes or network")
    manifest.add_argument("folder")
    args = parser.parse_args(argv)
    try:
        if args.command == "new-case":
            print(new_case(PACK_ROOT / "cases", args.case_id))
        elif args.command == "validate-case":
            data = json.loads(workspace_input(args.path).read_text(encoding="utf-8-sig"))
            errors = validate_engagement(data)
            print(json.dumps({"structurally_valid": not errors, "authorization_verified": False, "errors": errors}, indent=2))
            return 1 if errors else 0
        else:
            print(json.dumps(evidence_manifest(workspace_input(args.folder)), indent=2))
    except (OSError, ValueError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
