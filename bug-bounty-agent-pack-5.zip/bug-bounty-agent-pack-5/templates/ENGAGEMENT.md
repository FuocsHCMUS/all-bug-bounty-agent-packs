# Engagement and authorization record

- Program, official policy URL and type:
- Retrieval date, time, timezone and policy revision:
- Participation/invitation status and terms accepted by human:
- Exact asset: scheme, hostname, port, path, environment, account/tenant:
- Scope evidence, exclusions, third parties and redirects:
- Allowed methods and prohibited vulnerability classes or actions:
- Automation, limits, source identity, time window and required headers:
- Controlled account labels and synthetic data constraints; no credentials:
- Sensitive-data handling, incident and disclosure requirements:
- Authorized external services/callbacks, if any:
- Unknowns and clarification required:
- State: RESEARCH ONLY / AUTHORIZATION UNCERTAIN / READY FOR APPROVAL / APPROVED WITHIN ENVELOPE / STOPPED / DRAFT READY

## Approval ledger

| Time | Purpose | Exact tool/script and approved parameters | Target | Rate and duration | Stop condition | Approval reference | Outcome |
|---|---|---|---|---|---|---|---|

## Hypotheses

| ID | Surface and boundary | Hypothesis / invariant | Source / evidence | Alternative explanation | Minimal safe test | Status / confidence |
|---|---|---|---|---|---|---|

Recheck current policy before active work and after changes. Keep evidence private and sanitized.
