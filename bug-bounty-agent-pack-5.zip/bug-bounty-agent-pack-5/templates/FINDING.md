# Finding draft: [precise title]

- Program, official policy and scope evidence:
- Status: hypothesis / inconclusive / lab-only / observed / confirmed:
- Confidence, affected asset and feature, date/timezone:
- Authorized test identities, roles and prerequisites:
- Summary, trust boundary and expected invariant:
- Expected behavior:
- Actual observed behavior:

## Minimal reproduction

1. [Use permitted controlled accounts and synthetic test data.]
2. [Exact sanitized steps and conditions.]
3. [Result and evidence ID.]

## Evidence and limitations

| ID | Time | Sanitized artifact / observation | Claim supported | Limit |
|---|---|---|---|---|

## Impact and severity

Observed impact, separately labelled possible impact and prerequisites, relevant exclusions, and CVSS version/vector and rationale only where supported.

## Root cause and fixes

Separate observed condition and root-cause hypothesis. Recommend immediate containment, durable fix, positive and negative regression tests, and useful audit events without secrets.

## Sources and disclosure

Policy and advisory links with retrieval dates. Draft only: human reviews and submits according to program rules.
