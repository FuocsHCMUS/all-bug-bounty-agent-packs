# Student learning note: [topic]

## One-minute explanation

Plain-language summary and analogy; explain where the analogy stops being accurate.

## Foundations and mechanism

Define relevant network, HTTP, browser, authentication, authorization and trust-boundary terms. Describe legitimate data flow, then actor -> request -> component -> decision -> response. Explain invariant and gap with invented data. Separate evidence IDs from hypotheses and unknowns.

## Security controls and SOC

| Category | Observation / risk | Evidence and coverage | Confidence | Improvement / verification |
|---|---|---|---|---|
| Observed strength | | | | |
| Confirmed gap | | | | |
| Potential risk | | | | |
| Unknown / not assessed | | | | |

Explain prevention, telemetry, detection idea, false positives, response and privacy. An unobserved control is not necessarily absent.

## Practice and review

Propose a safe local or sanctioned lab exercise, expected result, solution, three self-check questions with answers and next reading. Ask approval before execution.
