# Case templates

Copy only templates needed for the active case. Fields in square brackets are intentional user-fillable fields, not claims of completed work. JSON uses empty arrays and null values so incomplete authorization is explicit.

| File | Purpose |
| --- | --- |
| [engagement.json](engagement.json) | Machine-readable draft and execution summary |
| [scope-ledger.md](scope-ledger.md) | Asset/method scope evidence and exclusions |
| [execution-approval.md](execution-approval.md) | Exact reviewable operation and human decision |
| [hypothesis.md](hypothesis.md) | Falsifiable research idea |
| [source-card.md](source-card.md) | Writeup/advisory/paper learning record |
| [cve-applicability.md](cve-applicability.md) | Build/configuration/path-specific CVE assessment |
| [evidence-index.md](evidence-index.md) | Private evidence provenance and redaction map |
| [finding-report.md](finding-report.md) | Focused private vulnerability report |
| [control-observations.md](control-observations.md) | Scoped positive/negative/unknown control analysis |
| [lesson-card.md](lesson-card.md) | Beginner concept and learning record |
| [session-handoff.md](session-handoff.md) | State, approvals, budgets, and next action |
| [tool-acquisition.md](tool-acquisition.md) | Portable download or dependency provenance |
| [retest.md](retest.md) | Fix verification with limited coverage |

Do not check secrets into Git. A filled approval record must link to a real human decision; agents cannot authorize themselves by editing these files.

## Engagement JSON conventions

`new-case` supplies a valid case_id and copies the research-only draft. To record an asset, use an object with nonempty `type`, `value`, and `scope_evidence` strings, for example a fictional record `{"type":"hostname","value":"app.example.invalid","scope_evidence":"scope-ledger.md, policy section 2"}`. Apply the same format to exclusions. This is a record format, not automatic URL matching or scope enforcement.

Methods, account labels, and stop conditions are arrays of nonempty strings. Do not put credentials into account labels. Execution modes require positive request/rate/concurrency/duration/response limits, a nonnegative retry limit, an actual approval summarized by plan/record paths and timezone-bearing timestamps, and stop conditions. Live-testing additionally requires reviewed program details, eligibility/AI review flags, assets, methods, and controlled account labels.

The helper does not fetch policies, open approval records, validate legal scope, check timestamp freshness, compare hashes, or enforce runtime limits. A structurally complete live-testing file can still be unauthorized, outdated, or wrong. The agent must review the underlying records before action.
