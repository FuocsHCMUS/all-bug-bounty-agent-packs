"""Offline behavioral tests; no target traffic, dependencies, or credentials."""
import importlib.util
from contextlib import ExitStack
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

MODULE = Path(__file__).resolve().parents[1] / "scripts" / "packctl.py"
spec = importlib.util.spec_from_file_location("packctl", MODULE)
packctl = importlib.util.module_from_spec(spec)
spec.loader.exec_module(packctl)


class PackTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_new_case_has_research_defaults(self):
        case = packctl.new_case(self.root, "acme-lab")
        data = json.loads((case / "engagement.json").read_text())
        self.assertEqual(data["mode"], "research-only")
        self.assertEqual(data["status"], "DRAFT")
        self.assertEqual(data["allowed_assets"], [])
        self.assertFalse(data["execution_approval"]["approved"])

    def test_new_case_never_overwrites(self):
        case = packctl.new_case(self.root, "one")
        (case / "notes.md").write_text("keep me")
        with self.assertRaises(FileExistsError):
            packctl.new_case(self.root, "one")
        self.assertEqual((case / "notes.md").read_text(), "keep me")

    def test_case_name_cannot_escape(self):
        for value in ("../bad", "..", "a/b", "a\\b", "C:bad", "CON", "aux", "nul.txt", "-bad"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                packctl.new_case(self.root, value)

    def test_bad_new_case_leaves_no_partial_case(self):
        with self.assertRaises(ValueError):
            packctl.new_case(self.root, "../outside")
        self.assertEqual(list(self.root.iterdir()), [])

    def test_draft_is_structurally_valid(self):
        case = packctl.new_case(self.root, "draft")
        data = json.loads((case / "engagement.json").read_text())
        self.assertEqual(packctl.validate_engagement(data), [])

    def test_live_configuration_requires_concrete_fields(self):
        case = packctl.new_case(self.root, "live")
        data = json.loads((case / "engagement.json").read_text())
        data["mode"] = "live-testing"
        errors = packctl.validate_engagement(data)
        for term in ("policy_url", "allowed_assets", "reviewed_at", "max_requests", "execution_approval"):
            self.assertTrue(any(term in error for error in errors), (term, errors))

    def test_booleans_are_not_request_counts(self):
        case = packctl.new_case(self.root, "counts")
        data = json.loads((case / "engagement.json").read_text())
        data["limits"]["max_requests"] = True
        self.assertTrue(any("max_requests" in e for e in packctl.validate_engagement(data)))

    def test_unknown_mode_rejected(self):
        self.assertTrue(packctl.validate_engagement({"mode": "unlimited"}))

    def test_non_object_rejected_cleanly(self):
        for value in (None, [], "hello"):
            self.assertTrue(packctl.validate_engagement(value))

    def test_manifest_hash_and_relative_path(self):
        (self.root / "sample.txt").write_bytes(b"abc")
        rows = packctl.evidence_manifest(self.root)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["path"], "sample.txt")
        self.assertEqual(rows[0]["bytes"], 3)
        self.assertEqual(rows[0]["sha256"], "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")

    def test_manifest_deterministic(self):
        (self.root / "z.txt").write_text("z")
        (self.root / "a.txt").write_text("a")
        self.assertEqual([r["path"] for r in packctl.evidence_manifest(self.root)], ["a.txt", "z.txt"])

    def test_empty_manifest(self):
        self.assertEqual(packctl.evidence_manifest(self.root), [])

    def test_manifest_requires_directory(self):
        file = self.root / "file"
        file.write_text("x")
        with self.assertRaises(ValueError):
            packctl.evidence_manifest(file)

    def test_manifest_does_not_follow_a_link(self):
        target = self.root / "real"
        target.mkdir()
        (target / "file.txt").write_text("private")
        try:
            (self.root / "alias").symlink_to(target, target_is_directory=True)
        except OSError:
            self.skipTest("Creating symlinks requires privileges on this Windows host")
        with self.assertRaises(ValueError):
            packctl.evidence_manifest(self.root)

    def test_cli_rejects_outside_workspace_input(self):
        with self.assertRaises(ValueError):
            packctl.workspace_input(self.root)

    def test_invalid_nested_sections_return_errors(self):
        data = {"program": [], "limits": None, "execution_approval": "yes"}
        errors = packctl.validate_engagement(data)
        self.assertTrue(any("program must be an object" in error for error in errors))
        self.assertTrue(any("limits must be an object" in error for error in errors))

    def test_empty_asset_records_are_not_structurally_valid(self):
        case = packctl.new_case(self.root, "assets")
        data = json.loads((case / "engagement.json").read_text())
        data["allowed_assets"] = [{}]
        self.assertTrue(any("allowed_assets" in error for error in packctl.validate_engagement(data)))

    def test_numeric_methods_are_not_structurally_valid(self):
        case = packctl.new_case(self.root, "methods")
        data = json.loads((case / "engagement.json").read_text())
        data["allowed_methods"] = [3]
        self.assertTrue(any("allowed_methods" in error for error in packctl.validate_engagement(data)))

    def test_manifest_detects_file_change_during_hash(self):
        file = self.root / "changing.txt"
        file.write_bytes(b"before")
        real_sha256 = packctl.hashlib.sha256

        def changed_hash():
            file.write_bytes(b"after-much-longer")
            return real_sha256()

        with patch.object(packctl.hashlib, "sha256", side_effect=changed_hash):
            with self.assertRaises(ValueError):
                packctl.evidence_manifest(self.root)

    def test_cli_outside_path_rejected_before_metadata(self):
        with ExitStack() as stack:
            for method in ("lstat", "is_symlink", "is_junction", "exists", "resolve"):
                stack.enter_context(patch.object(Path, method, side_effect=AssertionError("unexpected metadata access")))
            with self.assertRaises(ValueError):
                packctl.workspace_input(self.root)

    def test_unc_and_device_paths_rejected_before_metadata(self):
        for remote in (r"\\offline-test.invalid\share\evidence", "//offline-test.invalid/share", r"\\?\C:\data", r"\\.\pipe\data"):
            with self.subTest(path=remote):
                with ExitStack() as stack:
                    for method in ("lstat", "is_symlink", "is_junction", "exists", "resolve"):
                        stack.enter_context(patch.object(Path, method, side_effect=AssertionError("unexpected metadata access")))
                    with self.assertRaises(ValueError):
                        packctl.workspace_input(remote)

    def test_redirect_ancestors_checked_before_leaf(self):
        barrier = self.root / "barrier"
        barrier.mkdir()
        leaf = barrier / "untrusted-leaf"
        seen = []
        original = Path.lstat

        def observe(path):
            seen.append(path)
            if path == barrier:
                raise ValueError("simulated redirect barrier")
            return original(path)

        with patch.object(Path, "lstat", observe), patch.object(Path, "is_symlink", side_effect=AssertionError("unexpected follow-style check")):
            with self.assertRaises(ValueError):
                packctl.reject_redirected_path(leaf)
        self.assertNotIn(leaf, seen)


if __name__ == "__main__":
    unittest.main()
