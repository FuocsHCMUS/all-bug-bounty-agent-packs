---
name: bounty-research-claude
description: Use when a Claude Code session needs this workspace's authorized bug bounty research, CVE review, report preparation, or beginner security mentoring workflow.
---

# Claude Code bounty skill adapter

Read [canonical AGENTS.md](../../../AGENTS.md) and [canonical SKILL.md](../../../SKILL.md), then follow them. Resolve later links relative to their containing document. This wrapper is a discovery adapter, not a separate policy or authorization grant. Use one wrapper per task.
