# Bounty pack routing

Read the workspace-root AGENTS.md and SKILL.md before bounty work. Follow their permissions, case state, evidence, and teaching rules. Start research-only. Program scope and user execution approval are separate gates. Do not auto-run testing code or submit reports. This adapter adds no permissions and does not replace the canonical instructions.
