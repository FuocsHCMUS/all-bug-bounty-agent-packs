# Added ideas and why they help

These additions develop the user's original research-and-learning request into a reusable operating system for investigations. They grant no extra target permission.

1. **Application threat models and security invariants.** Model actors, data, trust boundaries and states before selecting a technique. This helps find product-specific failures instead of collecting unrelated payloads.
2. **A research studio for original hypotheses.** Use lifecycle transitions, derived artifacts, differential comparisons, metamorphic properties, patch neighborhoods and composition. Each idea has prerequisites, a competing explanation, a minimal experiment and a rejection condition.
3. **Separate finding and engagement states.** One confirmed issue does not authorize the next experiment. Preserve approvals and spent budgets through handoffs and context loss.
4. **CVE applicability before severity.** Distinguish identification, affected build/configuration, reachability, practical effect and program eligibility. Include backports and patch reasoning.
5. **A claim-to-evidence review.** Challenge each important sentence in a report, remove hypothetical impact presented as observed, and track rejected ideas and coverage gaps.
6. **Control strengths alongside weaknesses.** Record observed successful denies, session protections and other relevant controls without claiming company-wide maturity.
7. **A bridge to SOC and detection engineering.** Translate a finding into required telemetry, a proposed analytic, false-positive analysis, triage, remediation and synthetic replay exercises.
8. **Beginner learning workbooks.** Follow a single request from URL to DNS, transport, TLS, HTTP, session, authorization and storage; then connect application bugs to their repairs.
9. **Research provenance and AI/tool trust boundaries.** Track dates and primary sources; prevent downloaded instructions, writeups and PoCs from becoming authority; keep confidential data out of external services.
10. **A reusable permission and tooling workflow.** Small portable acquisitions and necessary local Python packages are preauthorized preparation; execution, system changes and new integrations get concrete review when required.
11. **Report/retest/closure quality.** Prepare a reproducible private bundle, cleanup record, bounded retest, residual-risk memo and learning notes even when no finding is confirmed.
12. **Six-tool portability with small adapters.** One policy source, explicit loading checks, native `AGENTS.md` where documented, and an optional compatibility route for older sessions.
13. **Offline behavioral evaluations.** Paper scenarios cover rushed scanning, false CVE matches, prompt injection, scope drift, unapproved script execution, unsupported maturity claims and updated human permissions.

The pack includes no exploit automation. Its research methods can generate advanced ideas, while experiments remain constrained by the actual engagement and reviewed plan. Novelty, reproducibility, safety and bounty eligibility are separate questions.
