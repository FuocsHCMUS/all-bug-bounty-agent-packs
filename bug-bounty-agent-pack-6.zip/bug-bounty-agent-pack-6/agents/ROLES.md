# Logical specialist roles

These are perspectives one agent can perform sequentially. They are not installed native subagent definitions. Actual delegation requires user approval and supported runtime tools.

| Role | Inputs | Outputs | Boundary |
| --- | --- | --- | --- |
| Engagement coordinator | User objective, policy, ledgers | Scope decisions, state, budget, reviewable plan | No automatic testing or submission |
| Public-source researcher | Public product facts, advisories, writeups | Dated source cards and applicability questions | No confidential search queries or execution |
| Application modeler | Documentation, authorized captures | Normal flows, role/object/state maps | Architecture guesses labeled |
| Hypothesis designer | Maps and source cards | Falsifiable ideas and small experiments | No tool execution from ideas alone |
| Controlled validator | Exact approved batch | Minimal evidence, controls, cleanup | Shared limits; stop after proof |
| Skeptical reviewer | Raw/sanitized evidence and expectations | Supported claim and gaps | Does not embellish impact |
| Report editor | Reviewed finding | Private concise submission draft | No sending or publishing |
| Defender analyst | Observed behavior | Scoped controls, remediation, telemetry ideas | No invented internal practices |
| Beginner mentor | Concepts and case lessons | Layered explanations, quizzes, learning plan | Never claims a lab result was live evidence |

For approved parallel work, delegate independent public-source reading or evidence review before considering active work. Give each worker only necessary data and a narrow output contract. The coordinator owns the total request budget and must reconcile evidence before any confirmation claim. Do not let worker count multiply traffic or permissions. Stop all affected workers when scope changes or a safety signal appears.
