# Design and delivery

Date: 2026-11-03. Deliverable: an extensive English prompt and skill library for six agents, in the user-requested `bug-bounty-agent-pack-6` folder. Existing pack 5 remains unchanged.

## Design choice

This is a new documentation package with multiple integrations. The user's detailed request authorizes creating the complete local pack and choosing useful expansions. Use a shared persistent policy, a short skill router, modular references, playbooks, reusable prompts, templates, teaching material and small platform adapters. A single huge startup prompt is prone to context truncation; six separate policies are harder to keep consistent. Depth belongs in files loaded for the active task.

Selected textual workflows from the existing local pack 5 provide a baseline; version 6 adds the extended intake guide, application model, research studio, CVE workbook, writeup translation, evidence review, workbooks, templates, prompts and updated source/verification records. Do not copy prior execution results, case data, virtual environments, test claims or downloaded tooling into this package.

## Acceptance contract

- All artifacts are inside this folder and written in English.
- Support Claude Code, Codex, OpenCode, Cline, Cursor and Antigravity through canonical instructions and documented adapters.
- Cover public discovery, scope, product learning, CVEs, source/writeup research, creative hypotheses, permitted validation, reports and retesting.
- Preserve the user's portable-download and Python-dependency permissions and confirmation preference for execution and integrations.
- Explain concepts progressively and connect offensive findings to fixes, controls and SOC observations.
- Distinguish facts, hypotheses, demonstrated impact and unknowns; no invented company findings or maturity grades.
- Verify local links, JSON and skill frontmatter, copied-version references, execution defaults and realistic offline decisions.
- State that six-platform end-to-end behavior and live target testing were not performed.

## Authorship boundaries

Authoring uses public documentation and ordinary local file operations. No script/tool payload is run, no program is joined, no account is created, no plugin/skill is globally installed, and no report is sent. Portable acquisitions and Python dependencies are future capabilities documented for a real need; the pack itself requires none.

The policy source is AGENTS.md. Specialist roles are sequential perspectives by default. Optional delegation needs the user's permission in future engagements. Offline independent pack review during authoring is prescribed by the skill-authoring workflow and does not contact targets.
