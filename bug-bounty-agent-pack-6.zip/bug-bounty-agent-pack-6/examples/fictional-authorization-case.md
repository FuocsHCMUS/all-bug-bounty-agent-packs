# Fictional worked case: inconsistent export authorization

**Training example only. Every product, account, URL, request, response, timestamp, and result below is synthetic. No real company was tested and no vulnerability was discovered by creating this example.** The `.invalid` domain is a placeholder, not a target.

## Product model

Fictional product StudyBoard stores private team projects. Account A belongs to test tenant T1 and owns project P-A. Account B belongs to test tenant T2 and owns project P-B. Both accounts and all records belong to the tester in this fictional model. The hypothetical program permits a small cross-account read comparison on these synthetic resources. This policy is invented for teaching and supplies no real authorization.

The intended invariant is: only members of a project's tenant may read the project or any private export derived from it. A distinct public-sharing feature is disabled for this example.

## Hypothesis H-01

The regular project endpoint enforces tenant isolation, but a derived export route may omit the same check. Supporting clue: the fictional architecture has separate handlers for interactive project reads and export reads. That is a hypothesis, not a finding.

Competing explanations: exports are intentionally public; B is accidentally a member of T1; a proxy returns A's cached response; the body contains no private data; or the marker comes from the test setup rather than the server.

## Proposed minimal batch

Five illustrative read requests, one at a time, no redirects, synthetic markers only, no real users, and no writes. Real execution would need an actual program policy and a concrete human approval. We would stop immediately if unexpected data appeared.

| Step | Actor | Object/action | Expected | Synthetic result |
| --- | --- | --- | --- | --- |
| 1 | A/T1 | Read P-A | Allow marker A-UNIQUE | Allow |
| 2 | B/T2 | Read P-B | Allow marker B-UNIQUE | Allow |
| 3 | B/T2 | Read P-A through normal route | Deny | Deny |
| 4 | A/T1 | Read P-A private export | Allow marker A-UNIQUE | Allow |
| 5 | B/T2 | Read P-A private export | Deny | Returns marker A-UNIQUE |

Illustrative step 5:

```http
GET /api/projects/P-A/private-export HTTP/1.1
Host: studyboard.example.invalid
Authorization: Bearer REDACTED-TEST-B
```

```http
HTTP/1.1 200 OK
Content-Type: application/json
Cache-Control: no-store

{"project":"P-A","training_marker":"A-UNIQUE"}
```

The table and snippets are deliberately fabricated teaching fixtures. `Cache-Control: no-store` in a fixture would not itself prove caching was excluded in a real investigation; real evidence would need request provenance and environmental checks.

## Evidence interpretation

Under the example's stated conditions, step 5 violates the tenant isolation rule while step 3 shows the regular route enforcing it. The content marker matters more than status 200. The allowed baselines establish that the identities/objects are valid. Real validation would also verify session separation, membership, sharing semantics, and caching assumptions from actual artifacts.

Supported claim: an ordinary test user in T2 can read the controlled T1 project's private export through this route. Unsupported claims: every customer is affected, write access is possible, administrator credentials are exposed, or the company's SOC failed to detect it.

## Private report draft

**Title:** A user in another tenant can read a private project export through the export route.

**Summary:** The normal project route denies cross-tenant access, but the private-export route returns the controlled project's synthetic contents to an ordinary account from another tenant.

**Reproduction:** Establish A/T1 and B/T2; create the two controlled records; confirm each legitimate read; confirm B is denied the normal P-A route; then perform the approved export comparison. Attach sanitized request/response pairs and account/ownership provenance.

**Impact:** Demonstrated cross-tenant disclosure of a private controlled export. The example does not measure population-wide exposure or any write capability. Severity should follow the real program's taxonomy and the sensitivity actually established; no calculated CVSS score is supplied here.

**Fix:** Enforce the same subject/action/object/tenant policy before serving private export contents. Bind storage and async jobs to the correct authorization context. Add tests that preserve allowed owner access and deny a peer tenant, removed membership, and relevant derived artifact routes.

**Cleanup:** In a real case, remove only permitted tester-created fixtures and record retained evidence. No actual cleanup is required for this written example.

## Control memo

- `OBSERVED_EFFECTIVE` in the synthetic model: normal route denies the peer-tenant read.
- `OBSERVED_WEAKNESS` in the synthetic model: export route returns the controlled foreign-tenant marker.
- `INFERRED_RISK`: other derived routes might share the implementation assumption; untested.
- `NOT_ASSESSED`: actual company-wide exposure, patch governance, monitoring, incident response, and all real company controls.

## Beginner explanation

Imagine a school office checks your class before handing you a folder, but the photocopy desk hands out a copy to anyone with the folder number. Protecting the original does not protect the copy. In a web service, each path that exposes the same private data must enforce the relevant policy.

The analogy simplifies authentication, roles, and intentional sharing. The real rule depends on product requirements. Ask the student: why does a random folder number not replace a permission check? Which logs would help the owner compare the normal and export routes? Why is reading another real student's folder unnecessary to demonstrate the defect?
