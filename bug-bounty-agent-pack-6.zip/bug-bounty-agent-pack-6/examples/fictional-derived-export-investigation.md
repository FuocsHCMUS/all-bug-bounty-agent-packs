# Fictional investigation: private source, inconsistent export

This entire case is invented for learning. No requests were executed and no real company, asset or vulnerability is represented. `.invalid` names and controlled labels are deliberate.

## Product model

NotebookBox is a fictional multi-tenant application. Its documented rule says a private project's content and exports are available only to its current members. Account A owns synthetic project A1 in tenant Red. Account B owns B1 in tenant Blue and has no role in Red. A1 contains the unique harmless marker `SYNTHETIC-RED-NOTE`.

Normal flow: user logs in, selects a project, opens a document and requests an export. The main document and generated export represent the same protected content. Internal services are unknown; the model does not invent their architecture.

## Hypothesis

The export path may fail to preserve the project's authorization rule. If B obtains A1's protected marker through export while the normal document route correctly denies B, that would support a specific derivative-access failure. Intended sharing, mixed sessions and cached data are the main alternatives to rule out.

## Reviewable experiment on paper

The plan would establish legitimate reads by A/A1 and B/B1, test B/A1 on the normal document path, and perform one export comparison with controlled sessions. A real engagement would need current program permission and a user-approved bounded batch before any execution. The example grants neither.

## Hypothetical observations

| Paper event | Expected | Invented result | Interpretation |
| --- | --- | --- | --- |
| A reads A1 | Allow | A marker visible | Legitimate baseline |
| B reads B1 | Allow | B marker visible | B session works |
| B reads A1 document | Deny | No protected content | Effective tested document control |
| B retrieves A1 export | Deny | A marker visible | Candidate export boundary failure |

Additional paper checks establish private sharing semantics, separate session profiles and absence of cached A content. In a real case those checks need actual evidence, not this table.

## Claim review

Supported **within this fictional model**: the derivative path contradicts the stated access rule and exposes controlled content. Inferred cause: missing or inconsistent authorization around export retrieval. Unknown: implementation detail, other routes, historical exposure, real-customer extent and SOC visibility. Unsupported: “all tenants compromised,” “administrator takeover,” “the company has no SOC.”

## Report shape

Title: “Unrelated controlled account retrieves a private project export through the export route.” Include prerequisites, exact owned objects, expected policy, baseline and forbidden comparison, minimal sanitized evidence, demonstrated confidentiality effect, limitations, repair and cleanup. Do not attach cookies or enumerate customers to prove scale.

## Repair and regression idea

Enforce current subject/action/object/tenant policy when producing and retrieving the derivative, consistent with intended capability/link semantics. Cover owner allow, unrelated peer deny, removed-member behavior and legitimate sharing. Random identifiers and hidden buttons do not replace policy enforcement.

## Control and SOC notes

The normal route's deny is a positive observation with narrow coverage. The export failure is a separate weakness. Proposed telemetry includes request ID, effective subject, tenant, resource policy, route, authorization decision and result. Whether such logs exist remains unknown. A defender could correlate the paper events after mapping them to a real approved dataset.

## Beginner explanation

Authentication tells the server the request represents B. Authorization should decide whether B may read A1. The export is another copy of the same protected content, so its access path must preserve the relevant rule. The defect belongs to that decision; TLS may have delivered every byte correctly.

Check understanding: if A intentionally created a public export link, what fact would change the conclusion? Answer: the link's intended authority, privacy promise and access semantics must be established. Public access alone is not automatically unauthorized access.
