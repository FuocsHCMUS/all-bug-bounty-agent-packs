# Network and web foundations

## 1. A computer needs both a destination and a service

An IP address identifies a network endpoint for routing. A port identifies a transport endpoint used by a service. A hostname is a human-readable name that can resolve to one or more addresses. A single IP can host many sites, and a site can use many IPs. Therefore, finding an IP associated with a company does not make every service on it an authorized test target.

An analogy is a building address and an office extension. It helps distinguish address from service, but real routing, proxies, virtual hosting, and shared infrastructure are more complicated than one building per address.

## 2. DNS resolves names; it does not grant trust or scope

The Domain Name System maps names to records. A/AAAA records identify IP addresses; CNAME records point a name toward another name. DNS results can change. A CNAME into a cloud provider does not mean the company owns every service at that provider. A certificate listing several names is also not a scope authorization document.

For security reasoning, ask who owns the name, who operates the endpoint, which hostname the application expects, and what the program actually includes. Do not bypass those questions by scanning all resolved addresses.

## 3. Transport carries bytes

TCP supplies an ordered reliable byte stream. UDP supplies datagrams with different tradeoffs. Web protocols can use different transports: familiar HTTP/1.1 and HTTP/2 deployments commonly use TCP with TLS, while HTTP/3 uses QUIC over UDP. The important beginner distinction is that transport delivery does not itself determine who is allowed to read an application object.

You do not need packet-level tooling to understand every web issue. Start by explaining the request and the server's trust decision. Packet capture is a separate activity that can collect unrelated secrets and may need additional installation or permission.

## 4. TLS protects the connection

Transport Layer Security provides encrypted authenticated communication when correctly configured and validated. A browser checks the certificate against the requested identity and its trust configuration. HTTPS can protect bytes in transit while the application still returns the wrong user's data. It cannot repair missing object authorization.

Distinguish encryption from hashing and encoding. Encoding changes representation, such as turning binary data into text. Encryption provides confidentiality using keys. Hashing creates a fixed-size digest useful for integrity comparisons; a file hash alone does not prove where the file came from.

## 5. HTTP expresses an application exchange

An HTTP request includes a method, destination/path, headers, and sometimes a body. The response includes a status, headers, and sometimes content. GET commonly retrieves, POST commonly submits, but actual side effects depend on the application. Do not assume a request is safe because its method looks read-only.

A fictional exchange:

```http
GET /api/projects/demo-a HTTP/1.1
Host: app.example.invalid
Cookie: session=REDACTED
```

The server might return 200 with data, 403 with an error, or 200 with an application-level error body. You must inspect meaning, identity, and protected content rather than using the status alone as proof.

## 6. State and identity are layered on requests

Cookies let a browser attach stored values to matching requests. A session cookie often references server-side state, but designs vary. A bearer token permits whoever possesses it to present it; handle it as a secret. A JSON Web Token is a token format, not a guarantee of secure validation. A valid signature does not prove the token is appropriate for every audience or operation.

Authentication answers "which subject is making this request?" Authorization answers "may that subject do this action to this object now?" Tenant context asks "within which organization's boundary?" These decisions belong on the server, even if the client UI hides options.

## 7. Browsers add another security model

An origin is the scheme, host, and port combination. The same-origin policy limits some cross-origin script interactions. Cookies, CORS, browser navigation, and server authorization interact through distinct rules. Do not assume "the browser blocked it" means the server denied it, or "CORS allowed it" means sensitive data was exposed.

## Explain a page load end to end

Have the student narrate: parse URL -> resolve name -> establish transport -> validate TLS where used -> send HTTP request -> attach permitted session context -> authenticate -> authorize -> retrieve/process data -> return response -> render under browser rules. Real caches and proxies may add steps. Use that path to locate the trust decision relevant to a finding.

Check understanding: if HTTPS is correct but B receives A's private object, which layer failed? Why does a shared IP not expand bounty scope? What evidence beyond a 200 status would establish unauthorized access?
