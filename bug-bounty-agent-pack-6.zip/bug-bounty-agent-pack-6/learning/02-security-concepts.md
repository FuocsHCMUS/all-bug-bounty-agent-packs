# Security concepts and mechanisms

## Assets, threats, vulnerabilities, exploits, and impact

An asset is something valuable: private data, an account, money, service availability, or integrity of a decision. A threat is a potential source or cause of harm. A vulnerability is a weakness that can violate a security property under stated conditions. An exploit is a way to trigger that weakness. Impact is the resulting harm. A proof of concept demonstrates a specific claim; it should be smaller and safer than the worst possible exploit.

The CIA triad is confidentiality, integrity, and availability. Confidentiality concerns unauthorized disclosure. Integrity concerns unauthorized change or incorrect trusted state. Availability concerns legitimate use of a service. A finding can affect more than one, but claim only what evidence supports.

## Trust boundaries and invariants

A trust boundary is where data or authority crosses between contexts with different trust: browser to server, user to administrator, tenant to tenant, application to database, or retrieved document to an AI tool executor. An invariant is a rule that must remain true, such as "a removed member cannot read private project exports after the documented revocation point."

Vulnerability hunting becomes clearer when you name the invariant before testing. Otherwise, a surprising response can be mistaken for a security issue even when it matches intended product behavior.

## Common class mechanisms

- **Broken authorization:** the server knows the requester but does not correctly enforce the action/object/tenant rule. Random identifiers do not substitute for checks.
- **Authentication/session failure:** the system accepts an inappropriate identity proof or mishandles its lifetime, context, or recovery.
- **Injection:** data crosses into an interpreter as instructions. A fix should preserve data/instruction separation at the relevant grammar boundary.
- **Cross-site scripting:** untrusted input executes in a browser context with security consequences. Reflection without execution and context is only a clue.
- **Server-side request forgery:** a user influences a server's network request beyond its intended destination/authority. A harmless approved callback proves fetching, not automatically internal compromise.
- **Path/file boundary failure:** user-controlled path or archive metadata escapes the intended file/object boundary. Use local harmless models rather than production file access.
- **Business logic/replay failure:** a sequence or repeated operation violates a product rule. The intended state machine must be known first.
- **Race condition:** concurrent operations interact incorrectly with shared state. A UI flicker is not proof; production concurrency can be disruptive.
- **Cache isolation failure:** a response is reused across identities or contexts that should remain separate. Check browser/proxy artifacts before concluding.

Each class spans many implementations. Knowing the label is the start of an explanation, not the end.

## CVE, CWE, CVSS, and EPSS

CVE identifies a published vulnerability record. CWE classifies kinds of weakness. CVSS expresses technical severity using defined metrics. EPSS estimates the chance of exploitation in the wild for a published CVE over a future time window. None independently proves a particular deployment is vulnerable. An application-specific authorization bug may be real without any CVE.

## Evidence, confidence, and controls

An observation is what the artifacts show. A hypothesis explains it. A negative control is a comparison expected not to exhibit the suspected effect. Confidence describes how well evidence excludes alternatives. A finding is confirmed only to the extent the observed approved proof supports it.

Example: A can read A1; B can read B1; B unexpectedly reads A1 containing A's unique synthetic marker; A1 is documented private; sessions are separate; caching/public sharing are ruled out. This supports a specific authorization failure. It does not establish how many real customers are affected.

## Fix versus defense in depth

The primary fix repairs the violated invariant. Defense in depth reduces exposure or damage if another layer fails. For an ownership check, the primary fix is server-side authorization at the correct boundary. Logging, random IDs, rate limits, and UI restrictions may help other goals but do not replace it.

Check understanding: explain why a vulnerable dependency listed in a lockfile may be unreachable; why a scanner alert needs review; and why a strong report distinguishes demonstrated impact from a hypothetical attack chain.
