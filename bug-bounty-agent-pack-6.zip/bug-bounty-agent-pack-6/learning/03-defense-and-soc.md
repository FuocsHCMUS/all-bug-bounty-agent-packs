# Connecting offensive evidence to defense and SOC

## Prevent, observe, respond, improve

Security engineering tries to preserve the correct invariant before harm occurs. Detection engineering tries to identify meaningful suspicious behavior from telemetry. Incident response decides whether harm is occurring, limits it, restores service, and improves controls. Bug bounty research can inform all three, but an external researcher does not automatically see the company's internal capabilities.

## What is a SOC?

A Security Operations Center is a function that monitors, investigates, and coordinates responses to security events. It can be a team, a service, or a distributed operating model. A SIEM collects/normalizes/correlates events; an EDR focuses on endpoint telemetry and response. These tools produce signals. Analysts need context to decide whether a signal is a real incident.

An event is a recorded occurrence. An alert is a rule/model raising attention. An incident is an assessed situation requiring response. A false positive is a benign condition triggering a detection; a false negative is relevant harmful behavior the detection misses. More alerts do not necessarily mean better detection.

## Follow a fictional authorization issue into logs

Suppose B reads A's synthetic export in a controlled test. Useful server-side records could connect authenticated subject, tenant, object owner, route, authorization decision, request ID, build, and time. The key question is whether the server evaluated the intended policy, not whether the user agent string looked suspicious.

An illustrative synthetic record:

```json
{
  "timestamp": "2026-11-03T10:00:00+07:00",
  "request_id": "synthetic-r-04",
  "subject": "test-B",
  "tenant": "test-T2",
  "resource": "synthetic-export-A1",
  "resource_tenant": "test-T1",
  "operation": "export.read",
  "policy_result": "unexpected_allow"
}
```

This is invented training data, not an observed company log or recommended exact schema. Avoid logging raw exported content, cookies, bearer tokens, or personal data.

## From fields to an analytic

A candidate analytic might ask: does an ordinary subject repeatedly request objects belonging to other tenants, and do any operations unexpectedly allow it? It needs accurate ownership and subject/tenant fields. Legitimate administrators, migration jobs, shared resources, and service accounts may be exceptions. Tuning requires authorized data and a threat model; do not claim a query is effective without testing it.

The strongest corrective action remains fixing authorization. Detection can shorten time to discovery but does not make unauthorized access acceptable.

## Triage and response questions

1. Is the event real and attributable to the tested feature/build?
2. What identities, objects, and time window are involved?
3. Does the behavior match intended policy or an approved test?
4. Is there evidence of unauthorized disclosure/change, or only denied attempts?
5. What limited containment can the owner apply without unnecessary disruption?
6. Which logs or deployment records can confirm scope internally?
7. Which root-cause fix and regression test prevent recurrence?

The agent can draft these questions for the user. It must not access the company's monitoring systems or take containment actions without separate authorization.

## A fair company control memo

Record one observed effective control: for example, the regular object endpoint denied B as expected. Record the weakness: the export route did not enforce the same boundary. Record inferred risk: another derived artifact may share the helper. Record not assessed: whether alerts triggered. This teaches a nuanced conclusion without pretending to audit the entire company.

Check understanding: what evidence would distinguish an authorization-denied spike from successful data exposure? Why can a company have a good login control and a bad export authorization path at the same time?
