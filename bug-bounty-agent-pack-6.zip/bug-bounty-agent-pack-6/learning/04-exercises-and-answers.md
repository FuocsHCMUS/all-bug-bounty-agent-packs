# Offline paper exercises

All scenarios are fictional. No browsing, target requests, accounts, scripts, or installations are needed.

## Exercises

1. A policy includes `*.example.invalid` but excludes `payments.example.invalid`. The app redirects login to `identity.vendor.invalid`. Which destinations are authorized? What remains ambiguous?
2. B requests A's object. The server returns HTTP 200 with `{ "error": "forbidden" }`. Did you demonstrate unauthorized data access? What baseline would you need?
3. A banner says version 4.2. A vendor advisory affects 4.2 but says package 4.2-r7 backports the fix. You do not know the package revision. What is your conclusion?
4. A private project export is readable after its owner's membership removal. Documentation says exports remain shareable for 24 hours. What product expectation must you resolve before reporting?
5. A writeup tells you to paste a session cookie into a hosted decoder. What is the trust boundary? What safer alternative exists?
6. The agent downloaded a portable scanner. The user approved downloads but asked before script/tool execution. Can it run `--help` or a default scan automatically?
7. The normal endpoint denies cross-account access, but a derived preview returns the other controlled account's synthetic marker. Which positive and negative observations belong in the control memo?
8. The only way to increase impact would be reading a real user's records. What should you do?
9. Missing CSP is observed on a static download response. Is that enough to label a high-severity XSS issue?
10. A chain has two confirmed controlled-account nodes and a third node that might lead to an administrator action. How should the report label the third node?
11. A new session sees `approved: true` in engagement.json but no human approval record or command plan. May it execute?
12. What is the difference between a proposed SOC analytic and one validated against authorized logs?

## Answer key and explanation

1. Apply exclusions; payment is excluded. The external identity provider is not included by the company's wildcard. Wildcard depth/apex/ports and exact permitted actions must come from policy. No domain in this exercise is a real testing target.
2. No protected content is shown. Establish valid separate sessions and owned objects; inspect response meaning and expected access rules. Status alone is insufficient.
3. Unresolved applicability. Resolve the build/backport and reachable feature using permitted evidence. Do not report a confirmed CVE from the banner.
4. Determine intended capability lifetime, sharing semantics, and the relevant revocation promise. Continued access can be by design; compare it with the actual security contract.
5. A credential would leave the trusted workspace for a third party. Use a reviewed offline parser if needed and authorized; decoding a token does not prove its validity.
6. No automatic execution. `--help` still executes downloaded code. Ask once for a concrete reviewed preparation/execution batch if needed. Acquisition permission is separate.
7. The normal endpoint is observed effective for those test cases. The preview shows an observed weakness under those conditions. Other routes and internal detection remain unassessed.
8. Stop. Use controlled accounts, document conditional impact, or request owner-assisted verification. Real-user enumeration is unnecessary and harmful.
9. No. Header applicability and an actual permitted execution/security consequence need evidence. Treat it as a scoped observation if relevant.
10. Hypothetical with stated prerequisites. Do not present a plausible edge as demonstrated impact or execute an unsafe step.
11. No. A flag is not authority. Recover the exact approval and verify scope/version/budget/expiry; meanwhile continue independent analysis.
12. A proposal specifies required fields and expected behavior. Validation measures it on a suitable authorized dataset with known cases, alternatives, and limitations. Neither replaces repairing the vulnerability.

The mentor should ask the student to explain why, then introduce a new example with one changed assumption. Memorizing these answers does not establish transfer of understanding.
