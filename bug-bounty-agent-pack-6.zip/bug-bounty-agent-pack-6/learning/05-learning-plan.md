# Adaptive learning plan

Use milestones rather than a promise that a fixed number of days creates expertise. The agent should adapt pacing to the student's answers and available time. Real target practice comes only after the authorization/execution gates.

| Stage | Understand | Practice without live targets | Evidence of progress |
| --- | --- | --- | --- |
| 1. Request journey | DNS, address/port, transport, TLS, HTTP | Narrate a fictional page load and label trust decisions | Explain why HTTPS does not fix authorization |
| 2. Identity and objects | Session, role, tenant, ownership | Build a two-account allow/deny matrix on paper | Predict results for owner, peer, removed member |
| 3. Mechanisms | Data/instruction separation, lifecycle, caching | Trace input and model one state machine | Explain root cause without relying on payload names |
| 4. Evidence | Baseline, negative control, alternatives | Review fictional proof and identify overclaims | Separate observation, hypothesis, and confirmed impact |
| 5. Source research | CVE/CWE, vendor advisories, backports | Complete a public-source applicability card | Reject banner-only confirmation with reasons |
| 6. Safe lab | Isolation, synthetic data, cleanup | Propose a local experiment and approval plan | Bound resources and stop conditions before execution |
| 7. Program intake | Scope, exclusions, AI terms, eligibility | Prepare a research-only real program dossier | Identify third-party and disclosure boundaries |
| 8. Bounded research | Product flows and original hypotheses | Conduct only a specifically approved minimal batch | Record controls, limits, and rejected hypotheses |
| 9. Reporting | Reproducibility, severity, remediation | Write a concise private report and regression idea | Every claim traces to evidence |
| 10. Defense | Telemetry, triage, containment, limitations | Design a synthetic detection and discuss false positives | Separate proposed analytics from verified monitoring |

## Suggested session rhythm

Start with one retrieval question from the prior lesson. Explain a single connected topic using a concrete flow. Ask the student to predict a result before showing it. Use a short exercise, then ask for a plain-language explanation. End with a lesson card: what changed in their understanding, what remains confusing, and a small next task.

## Depth ladder

For any finding, the mentor should offer three layers. First: describe who should be allowed to do what. Second: identify the request, identity, object, component, and missing decision. Third: examine implementation contracts, state transitions, regression coverage, detection fields, and deployment constraints. Move deeper only when the preceding model is clear.

## Skills beyond exploitation

Practice careful note taking, source verification, uncertainty calibration, debugging, concise reporting, defensive design, privacy-aware logging, and respectful triage communication. These are valuable for application security, pentesting, SOC, and security engineering even when a hunt produces no confirmed vulnerability.

Keep a skill ledger using the lesson-card template. Record `introduced`, `explained correctly`, `applied in a new example`, or `needs review`. Avoid arbitrary percentages or claiming professional readiness from a few exercises.
