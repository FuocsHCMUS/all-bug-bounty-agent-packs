# Foundations workbook: understand one request completely

Read after [network/web foundations](01-network-and-web-foundations.md). This workbook is for a student who is new to networks and cyber security. Use fictional names and paper exercises; no script or target is needed.

## Lesson 1: name, address, service and ownership

A hostname is a name. An IP address participates in network routing. A transport port distinguishes endpoints used by services. A URL adds a scheme, authority and resource path. A company can use many providers; one provider IP can host many customers. Technical association is not legal or program scope.

Take `https://app.example.invalid:443/projects/demo-a`. `https` indicates the scheme, `app.example.invalid` is the host, 443 is the explicit port, and `/projects/demo-a` identifies an application resource. The string `demo-a` may be an object reference. It does not by itself prove ownership or grant access.

Exercise: a scoped hostname resolves through a CNAME to a shared provider. Which fact describes routing, and which source determines permission? Answer: DNS describes naming/routing relationships; the current owner program policy determines permitted testing. The provider's other tenants do not become in scope.

## Lesson 2: what happens before HTTP

The client determines where to connect, often using DNS. For familiar HTTPS over TCP, a transport connection is established and TLS authenticates the service identity and protects communication. Other web protocols have different transport details, such as HTTP/3 using QUIC. The learning goal is to separate moving protected bytes from deciding application access.

Certificates help a client decide whether it is communicating with the expected endpoint under its trust configuration. They do not certify that the application has no bugs, that every user is authorized, or that its business rules are correct.

Exercise: HTTPS succeeds, but the server returns another controlled account's private test document. Did encryption fail? Answer: not necessarily. The transport can securely deliver the wrong application data. The relevant failure may be authorization.

## Lesson 3: requests are messages with context

A request contains a method, destination/path, headers and sometimes a body. A response contains a status, headers and often content. A status is a summary chosen by the implementation; the body and state effect still matter.

Fictional normal request:

```http
GET /api/projects/demo-a HTTP/1.1
Host: app.example.invalid
Cookie: session=REDACTED
```

The server must interpret the session, identify the subject, determine the requested action, locate the object and apply the relevant policy. A UI may hide a button, but a separate client can still send messages. The server therefore needs its own authority checks.

Exercise: why is a `200` response not enough to confirm unauthorized access? Answer: it could contain an error, public metadata, cached content or a page unrelated to the protected object. You need identity, ownership, intended policy and meaningful content/state evidence.

## Lesson 4: identity, session and authority

Authentication concerns the identity being represented. A session associates subsequent requests with context established earlier. Authorization decides whether that subject may perform this action on this object in this state. These decisions can use role, tenant, ownership and sharing rules.

A bearer token is valuable because possession can permit use. A token format such as JWT does not establish correct validation, audience, expiry or authorization. Keep real tokens out of logs, command arguments, lesson notes and public evidence.

Analogy: a badge may identify a person; it does not necessarily open every room. The analogy stops being exact when services, delegated authority and shared objects enter the model. Always return to the actual subject/action/object policy.

Exercise: account B knows account A's object identifier. Should a random-looking identifier be the primary protection? Answer: the server should enforce authorization unless the product deliberately defines a controlled capability link. Unpredictability alone does not repair missing checks.

## Lesson 5: browser restrictions are distinct controls

An origin combines scheme, host and port. Browsers enforce rules about scripts interacting across origins. Cookies have their own matching and security attributes. CORS expresses aspects of cross-origin response sharing. These mechanisms interact, but none is a substitute for the application's resource authorization.

If a browser blocks one script from reading a response, a server may still have accepted a state-changing request. If a response has permissive cross-origin headers, it is not automatically a sensitive-data leak: credentials, browser behavior and actual protected content matter. Learn the complete flow before naming the bug.

Exercise: why is “CORS is enabled” not a finding? Answer: some resources are intentionally public and legitimately shared. A security claim needs a protected resource, relevant credential behavior, permitted proof and an actual confidentiality or integrity consequence.

## Lesson 6: storage and derived data

An application may store original data in a database, files in object storage and a generated preview elsewhere. Each representation has access behavior and lifetime. A private source document and a public preview can violate a product promise if that preview exposes protected content. They can also be intentional sharing features. Evidence and semantics decide.

Draw a private synthetic document, its preview and its export. For each arrow, ask which component carries the owner/tenant context and where the access check occurs. This is a data-flow model. Label unknown architecture instead of inventing internal services.

Exercise: the normal document route denies B, while an export returns A's unique synthetic marker to B. What can you conclude? Answer: with correct session separation, privacy semantics and controls, the export path demonstrates a specific boundary failure. You cannot conclude that every route or every customer is affected.

## Lesson 7: time changes authority

Membership can be added or removed; links can expire; sessions can be revoked; jobs can continue after a request ends. A state machine describes valid states and transitions. The intended policy determines when a right should stop.

Distinguish a promised immediate revocation from a documented limited link lifetime. A test must record time and relevant state. A stale UI view is not the same as a new server response after revocation. Clocks, caches and background work can complicate interpretation.

Exercise: which question comes first when a link works after a member is removed? Answer: what authority does the link represent, and what revocation guarantee does the product make? Then design a controlled comparison for that guarantee.

## Lesson 8: evidence is an argument you can inspect

A strong argument states the security promise, controlled context, exact observation, meaningful comparison and limited consequence. A weak argument says “critical vulnerability” and attaches a tool warning. Negative controls help distinguish your explanation from plausible alternatives.

Record what was actually observed. Mark simulations, fictional examples and unexecuted commands clearly. A safe synthetic proof is often stronger than collecting real data: its origin is known and its access meaning can be established without harming others.

Exercise: rewrite “all users can steal everything” after a two-account export test. Better: “In the tested environment, controlled account B retrieved A's private synthetic document through the export route. Broader object and account coverage was not tested.”

## Learning contract

For each new term, explain its prerequisite, show normal behavior, identify the trust decision, show a harmless example, explain the failure, connect the fix and describe possible defender visibility. Ask the student to explain it back in their own words. If the answer is unclear, use a simpler example before adding advanced details.

Keep [lesson cards](../templates/lesson-card.md) and the [learning plan](05-learning-plan.md). Track demonstrated understanding rather than number of tools installed or payloads memorized.
