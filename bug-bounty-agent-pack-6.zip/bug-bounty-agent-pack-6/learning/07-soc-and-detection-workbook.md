# SOC and detection workbook: turn one finding into defensive understanding

Read with [defense and SOC](03-defense-and-soc.md), [controls](../references/08-controls-and-soc.md) and [detection design](../templates/detection-design.md). Every log example below is fictional. No access to a company's SOC is assumed.

## 1. Distinguish bug, event, alert and incident

A vulnerability is a weakness under stated conditions. An event records an occurrence. An analytic evaluates events and context. An alert is a signal worth investigating. An incident is an assessed security situation requiring response under an organization's process. A suspicious event is not automatically a confirmed incident, just as a scanner alert is not automatically a confirmed vulnerability.

A SOC, or security operations center, combines people, process and technology for monitoring and response. A SIEM helps collect, search and correlate security data. EDR concerns endpoint visibility and response. These tools have different scopes. An external bounty researcher cannot infer their presence or absence from one web response.

## 2. Start with the invariant

Suppose a fictional private export route failed an ownership rule in a controlled test. The primary repair belongs in authorization and policy propagation. Detection can reveal suspicious access patterns or regression, but it cannot make the unsafe route safe by itself.

Translate the invariant into a defender question: did this subject retrieve an object outside their permitted tenant/ownership/sharing context? Notice that a web status alone does not answer it. The application may need to emit an authorization decision and relevant context.

## 3. Define useful telemetry

Potential fields include event time with timezone, request correlation ID, authenticated subject label, effective role, tenant context, resource type/identifier, resource owner/tenant, action, policy decision, outcome, route and service/build version. Some fields may be unavailable or require application changes.

Use pseudonymous identifiers where appropriate. Avoid recording passwords, bearer tokens, full cookies or protected response bodies. More logging can create a new sensitive-data problem. Minimize content, restrict access and follow retention rules.

Fictional normalized events:

```json
[
  {"request_id":"lab-r1","subject":"owned-B","tenant":"lab-blue","resource_tenant":"lab-blue","action":"read-export","decision":"allow","outcome":"returned"},
  {"request_id":"lab-r2","subject":"owned-B","tenant":"lab-blue","resource_tenant":"lab-red","action":"read-export","decision":"deny","outcome":"blocked"}
]
```

These invented fields are a teaching schema. The second event demonstrates a successful deny, not unauthorized access. Shared resources, service identities and administrator permissions need additional policy context.

## 4. Design an analytic without pretending it is deployed

Plain-language candidate: find requests where the effective subject context and resource context differ, then evaluate whether a documented sharing, delegated-service or administration rule permits that difference. Prioritize cases with a successful protected result despite an unexpected policy outcome. Repeated denied attempts can be another signal with different meaning.

Pseudocode:

```text
for each authorization event:
    resolve effective subject policy and resource policy
    if outcome exposes a protected result and policy says deny:
        flag a possible authorization inconsistency
    else if repeated denies exceed a locally tuned pattern:
        flag for contextual review, not automatic compromise labeling
```

This is a proposed analytic. It has not been run against a company's data. Detection logic depends on accurate events; a missing or incorrectly logged decision can defeat it. Do not invent a universally correct threshold.

## 5. Test the idea with synthetic cases

Create a paper dataset with an allowed owner read, a denied peer read, an allowed documented share, an authorized administrative read, a stale-client retry and an inconsistent successful forbidden read. Predict which should alert and why. Then examine whether the analytic has enough fields to distinguish them.

Define true/false positives and false negatives. A false positive flags legitimate behavior; a false negative misses suspicious behavior. Precision asks how many flagged results are relevant; recall asks how much of the relevant activity was found. These measures need a known labeled dataset, not intuition alone.

Do not claim a query is validated until it runs on an authorized suitable dataset and its outputs are reviewed. Executing a test script or launching a SIEM/lab remains subject to the user's execution permission.

## 6. Triage a signal

An analyst checks identity, role, resource ownership, sharing state, time, route, deployment version and correlated events. A correlation ID helps join records across services. NAT, proxies and shared IPs complicate attributing activity to a person; an IP address alone is weak identity evidence.

Ask whether the response actually contained protected data, whether a permitted administrator acted, whether policy changed, and whether the event is a duplicate or telemetry error. Avoid collecting extra customer content merely to make triage more convincing.

## 7. Response and remediation

In an actual organization, containment might restrict a route or capability while preserving evidence and business continuity. Remediation repairs the invariant. Recovery verifies authorized behavior and closes unintended access. Lessons improve regression coverage, monitoring and deployment assurance.

The bounty agent recommends actions; it does not operate the company's production systems or claim that containment happened. Owner-assisted questions can be precise: “Please inspect policy-decision and export-result events for these request IDs and determine whether the fixed build enforces resource ownership.”

## 8. Record positive controls and unknowns

An observed deny on the document route is `OBSERVED_EFFECTIVE` for that tested condition. A failed export boundary is `OBSERVED_WEAKNESS`. A sibling route that may share code is `INFERRED_RISK`. Whether the SOC alerted is `NOT_ASSESSED` unless evidence exists.

This vocabulary supports honest risk communication. It lets a student understand strengths and gaps without pretending a narrow external test is a full audit of governance, monitoring or incident response.

## 9. Exercises

1. A report contains only a response status and an IP. Which fields are missing to assess authorization? Answer: subject/role, resource ownership/sharing/tenant, actual content/outcome, intended policy and timing at minimum.
2. A control request is denied. Does that show the SOC saw it? Answer: no; application enforcement and monitoring visibility are separate questions.
3. A query produces many alerts from a migration service. What next? Answer: investigate the service's authorized policy/context and refine the analytic using evidence; do not globally suppress all unusual activity.
4. A proposed detection works on six fictional rows. Is it production-ready? Answer: no; schema quality, real baseline behavior, scale, tuning, access and operational review remain untested.

Create a [detection design](../templates/detection-design.md) and a [control matrix](../templates/control-assessment-matrix.md), then explain how both complement the root-cause fix.
