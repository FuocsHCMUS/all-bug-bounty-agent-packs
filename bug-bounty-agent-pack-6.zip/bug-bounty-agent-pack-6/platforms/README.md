# Platform setup

Open the pack root as the workspace. Native `AGENTS.md` is the shared instruction source. The other files are routing adapters; they do not auto-install tools, change global settings, grant shell access, or create workers.

| Product | Start with | Supplied adapter |
| --- | --- | --- |
| Claude Code | [Claude Code](claude-code.md) | .claude/skills/bounty-research-claude/SKILL.md |
| Codex | [Codex](codex.md) | .agents/skills/bug-bounty-agent-pack-6/SKILL.md |
| OpenCode | [OpenCode](opencode.md) | Shared .agents/skills wrapper |
| Cline | [Cline](cline.md) | .clinerules/00-bounty-pack.md |
| Cursor | [Cursor](cursor.md) | .cursor/rules/00-bounty-pack.mdc |
| Google Antigravity | [Antigravity](antigravity.md) | .agents/rules/00-bounty-pack.md plus shared skill wrapper |

Do not copy this pack over an existing project's instructions. Open it separately, or review a small routing addition with the user. If an agent cannot discover skills, explicitly ask it to read the root SKILL.md and master prompt. This manual fallback requires no plugin installation.

File detection is only the first step. Run the paper scenarios in [evals/scenarios.md](../evals/scenarios.md) before trusting a setup with live work. Keep native approval controls enabled.
