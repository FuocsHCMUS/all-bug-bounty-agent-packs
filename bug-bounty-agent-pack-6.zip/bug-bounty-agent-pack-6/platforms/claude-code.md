# Claude Code

Current [official memory documentation](https://code.claude.com/docs/en/memory) documents native AGENTS.md support from v2.1.277, with version/session qualifications. Default instruction selection uses CLAUDE files if present and otherwise AGENTS files. A CLAUDE.local.md in the working directory or an ancestor can also prevent the fallback. Organization policy or a disabled built-in plugin can change loading.

1. Open this pack root and start a fresh session.
2. Confirm AGENTS.md loading with `/memory` where the installed version lists it, and inspect Project instructions in `/config`. Older support versions may require an explicit behavior check. Check ancestor instruction files too.
3. Read root SKILL.md explicitly, or use the supplied `.claude/skills/bounty-research-claude/` skill.
4. Keep execution permissions interactive. Do not use permission-bypass flags.

This pack intentionally contains no root CLAUDE.md. For older/incompatible sessions, an optional root CLAUDE.md containing the following real import is a documented fallback:

```text
@AGENTS.md
```

Create it only if needed. A prose instruction to read a file is weaker than an actual import. Avoid Windows symlinks for this fallback. Do not edit global settings automatically.

Current documentation also notes older-session limitations around the initial support release; consult the live memory page for the installed version. Do not promise native loading solely from the file's existence. If organization settings exclude project instructions, use an allowed manual workflow rather than bypassing those settings.

The Claude wrapper is named differently from the shared wrapper. Products discovering both may list both; activate one, not both. Resolve any deeper document links relative to the document that contains them.
