# Cline

[Cline's rules documentation](https://docs.cline.bot/customization/cline-rules) lists AGENTS.md and .clinerules/ support. This pack includes `.clinerules/00-bounty-pack.md` as a small route to the canonical files.

Open the pack root and inspect the active rules in Cline. Start with the master prompt or explicitly ask it to read AGENTS.md and SKILL.md. Do not rely on SKILL.md auto-discovery if the installed version does not show it.

Keep command execution and browser/tool actions subject to review. Do not enable broad auto-approval to simulate autonomy. The agent can research and prepare files while testing execution remains gated. Confirm its browser uses a dedicated profile and that it does not contact targets merely to complete intake.

Plan/Act interfaces are workflow aids, not program permission. Moving to Act mode does not approve a new target, test method, budget, or submission. The approved operation must still be concrete and recorded. No additional Cline extension or MCP server is needed to use the pack.
