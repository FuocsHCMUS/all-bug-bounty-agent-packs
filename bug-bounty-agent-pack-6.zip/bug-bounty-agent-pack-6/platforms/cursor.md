# Cursor

[Cursor's rules documentation](https://cursor.com/docs/rules) supports root/nested AGENTS.md and .cursor/rules files. The supplied `.cursor/rules/00-bounty-pack.mdc` has a brief always-applied route to the canonical pack instructions.

Open this folder as the project. Confirm the rule appears in the current product's rules UI, then ask the agent to read root AGENTS.md and SKILL.md. The detailed playbooks should be loaded only for the selected task.

Keep terminal and external action approvals enabled. A file being attached to context does not grant permission to execute its commands. Do not turn on broad background execution or upload case evidence to a remote agent without reviewing confidentiality and data destinations.

No Cursor-specific skill API is required; explicit file reading works. Run the evaluation scenarios after a product upgrade or a rule-format change. If the UI does not indicate the adapter loaded, use the explicit master prompt rather than inventing a configuration key.
