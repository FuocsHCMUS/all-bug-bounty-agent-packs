# Diagnose instruction and skill loading

## Establish facts before changing configuration

1. Confirm the opened workspace and current working directory are the pack root.
2. Ask which instruction files are actually in context; inspect the product's native context/rules UI where available. A confident answer alone is not proof.
3. Inspect only relevant project and ancestor instruction paths, plus the active product's settings when necessary and permitted. Avoid unrelated home-directory searches or secret configuration dumps.
4. Check whether the runtime applies nested instructions only after opening a file. Explicitly read root AGENTS.md and SKILL.md to provide a manual fallback for this session.
5. Check the installed product/version's official discovery and precedence documentation. Do not assume all products interpret imports or Markdown links the same way.

## Common causes

- **Wrong root:** opening the parent repository can leave the nested pack undiscovered. Open the pack directly or explicitly read its files.
- **Claude selection:** an ancestor CLAUDE.md/CLAUDE.local.md, older version, built-in plugin state, or managed policy can affect native AGENTS.md loading. Use the [Claude guide](claude-code.md) and current official docs. Do not overwrite the ancestor's user instructions.
- **Skill path:** a root SKILL.md is a portable entrypoint, but native discovery usually expects a platform-specific skill directory. Use the supplied wrapper or explicit reading.
- **Duplicate skills:** OpenCode or another product may discover both shared and Claude wrappers. Choose one entry for a task; they route to the same canonical files.
- **Frontmatter:** Cursor and Antigravity modular rules use different metadata. Keep each supplied format in its own directory; do not rename one format into another.
- **Managed settings:** organization restrictions can disable project features. Do not bypass them with a plugin or unrestricted shell configuration.

## Minimal remedies

Prefer opening the correct folder and explicit file reading. If a file change is needed, prepare a small local adapter/import diff for review, preserving existing content and precedence. A documented Claude legacy root import is an option for incompatible sessions. Machine/global settings, new plugins/MCP servers, and external skill registration remain separate user decisions. This pack never requires a universal allow policy.

After a remedy, verify file loading again and run paper evaluation scenarios. Do not start a live hunt to test whether the instructions loaded correctly.
