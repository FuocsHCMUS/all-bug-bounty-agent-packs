# Authorization and tenant isolation

## Mechanism

Authentication establishes an identity. Authorization decides whether that identity may perform an action on a particular object in its current state. Object ownership, role, tenant, sharing state, and purpose may all matter. An object identifier is a reference, not a permission token unless the product deliberately treats it as a capability.

## Model before testing

Build rows for two tester-owned accounts A/B, roles, tenant memberships, objects A1/B1, actions read/update/delete/export/share, and membership states. Write the expected allow/deny result. Distinguish object-level failure, function-level failure, property-level failure, and tenant-boundary failure. UI-hidden actions still need server enforcement.

## Minimal proof design

Within an approved batch, demonstrate A's allowed access to A1, B's allowed access to B1, then one forbidden comparison using the other controlled identity. Use unique harmless synthetic markers so response content can be attributed. Avoid deletion or writes when a read-only proof establishes the issue. An update test needs explicit permission and a reversible owned field.

Check session separation, intended public access, sharing links, administrator privileges, caching, and object ownership. A 200 response containing an error is not proof. A predictable ID is not a finding by itself. Do not enumerate IDs or real tenants.

## Fix and defense

Enforce subject/action/object/tenant policy at the server's data-access boundary and every derived artifact path. Scope queries to authorized resources; avoid trusting tenant identifiers supplied by the client. Random IDs can reduce guessing but do not repair missing checks.

Regression tests should cover allowed owners, forbidden peers, removed members, role changes, and derived exports where relevant. SOC ideas include correlating subject, tenant, resource owner, route, and authorization outcome without logging protected content. Record successful denies as positive control observations with their exact coverage.
