# Authentication, sessions, recovery, and OAuth/OIDC

## Understand the trust model

A session binds later requests to an authenticated subject. Password recovery replaces a prior proof of identity with another trusted channel. OAuth delegates access; OpenID Connect adds identity assertions. Tokens have an issuer, audience, lifetime, intended use, and validation rules. Knowing their names does not prove implementation correctness.

Map registration, login, logout, session revocation, password change, recovery, MFA enrollment/removal, account linking, and organization switching using owned accounts. For federation, identify which system is the client and which is the identity provider. A redirect to an external identity provider does not make that provider in scope.

## Questions for a bounded plan

Does logout revoke the documented session or only remove a local cookie? Do recovery links expire and become unusable after their intended use? Does changing a role or membership affect existing sessions as promised? Are authorization responses bound to the initiating session and expected issuer/client? Are tokens validated for their intended audience and purpose?

Use own accounts and user-controlled mailboxes. Do not trigger victim recovery messages, brute force codes, stuff credentials, steal sessions, or weaken MFA. For federation behavior, prefer standards/configuration review and a program-provided test tenant. Do not send test tokens to third-party decoders or paste them into chat.

## Evidence and false positives

Compare documented semantics, exact token/session type, expiry, and server results. Access tokens may remain valid by design for a documented short lifetime; a signed token remaining cryptographically valid is not proof an operation remains authorized. Cookie flags alone do not establish account takeover.

## Fix and SOC lesson

Bind flows to the correct session and client, validate token claims and cryptographic trust, enforce lifecycle changes at the right boundary, and protect recovery as an authentication mechanism. Log safe event identifiers for login/recovery/MFA/session changes, then correlate suspicious state changes. Do not log raw tokens or recovery capabilities.
