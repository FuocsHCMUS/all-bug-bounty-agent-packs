# API and GraphQL boundaries

## Normal model

An API is a contract between clients and a server. REST routes and GraphQL fields expose operations, but authorization must apply to the operation and data, not only to the transport endpoint. A valid schema does not prove the caller may access every field.

Map documented operations, object identifiers, input properties, role requirements, pagination, asynchronous jobs, exports, and error semantics. For GraphQL, distinguish schema visibility from data access. Introspection being enabled is not automatically a reportable issue.

## Hypotheses

Ask whether collection and single-object routes apply the same ownership rule; whether read and update properties have different authorization; whether server-managed fields can be changed through an input object; whether nested resolvers preserve tenant context; and whether exports/background jobs use the same policy as interactive views.

Use a small role/object/property matrix and owned synthetic records. A test changing a sensitive property is a state mutation requiring explicit approval, even if a tool calls it a harmless API check. Avoid broad discovery, expensive nested queries, batch amplification, or resource-exhaustion experiments. Do not treat GraphQL as a way to pack an unbounded operation into one HTTP request.

## Evidence

Record authenticated subject, object ownership, operation/field, expected restriction, returned protected property, and negative control. Verify the result persists if the claim concerns a write; avoid unnecessary follow-ups if the first evidence already proves a read boundary failure. Distinguish a client's cached object from the server response.

## Fix and learning

Apply consistent object/function/property authorization, explicit input field allowlists, tenant-aware data access, and bounded query cost. Relevant SOC signals include operation names, resolver/route authorization outcomes, tenant context, unusual object fan-out, and background job ownership. Use OWASP API guidance as a taxonomy and methodology reference, not a substitute for product-specific proof.
