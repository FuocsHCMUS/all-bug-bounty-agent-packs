# Input handling and interpreter boundaries

## Root concept

Many injection flaws occur when data is interpreted as instructions in a different language: SQL, a shell, a template language, HTML/JavaScript, or another parser. Encoding, validation, parameterization, and sanitization solve different parts of this problem. The relevant context matters.

Trace input -> transformations -> storage -> interpreter -> output. Identify who controls the input, what grammar interprets it, and what privilege the interpreter has. Reflection alone is not execution. An error alone is not proof of query control. A search box accepting punctuation is not a vulnerability.

## Research approach

Use authorized source review and local synthetic parser models first. For a live test, require class-specific program permission and a concrete minimal benign marker. Do not use database extraction, command execution, file reads, persistent browser scripts affecting other users, or time-delay stress as generic proof. If proof requires a harmful effect, stop and describe owner-assisted validation.

For browser rendering, distinguish text, HTML attributes, URLs, script contexts, and the actual rendering path. Stored input needs careful account isolation and cleanup; do not plant content where employees or real users may encounter it. Browser-side alerts or screenshots without provenance can be misleading.

## Evidence and alternatives

Record the input context, transformations, observed interpretation, execution boundary if any, control input, and exact permitted effect. Consider intentional markup, encoded output, client-only rendering, error sanitization, and test artifacts. Do not equate missing CSP with demonstrated XSS.

## Remediation

Separate data from instructions through parameterized interfaces; avoid shells where possible; use context-aware output encoding and safe templates; validate structure; apply least privilege. Defense in depth can include CSP or restricted execution, but it does not replace fixing the interpretation boundary. SOC lessons should focus on safe structured error/operation events and anomaly patterns without logging secrets or copying dangerous inputs into analyst consoles.
