# Server-side URL fetching and callbacks

## Mechanism

A server fetching a user-supplied URL acts from its own network position and identity. The security decision must constrain where it connects and what it sends, including after DNS resolution and redirects. Seeing a submitted URL in a page is not proof the server fetched it.

Map legitimate fetch features: import, previews, webhook verification, document conversion, or image retrieval. Identify accepted protocols, credentials, redirect behavior, network restrictions, content use, and whether fetching is client-side or server-side.

## Safe proof design

Use only an explicitly approved user-controlled endpoint or program-provided callback service. Obtain approval for the callback destination and any data that might leave the target. A third-party OAST service is a data recipient, not a free implementation detail. A minimal callback can demonstrate server-side fetching; it does not automatically demonstrate sensitive internal access.

Do not probe cloud metadata, localhost services, private networks, internal administrative routes, arbitrary ports, or third-party infrastructure. Do not attempt credential retrieval or internal pivots. If the meaningful impact depends on such access, explain the conditional risk and ask the owner to validate internally.

## Evidence and alternatives

Record feature, approved destination, timestamp/correlation marker, expected user behavior, observed request source/headers where permitted, and negative control. A browser prefetch, DNS lookup alone, security scanner fetch, or callback service artifact can produce misleading signals. Match the evidence to the claim.

## Fix and defense

Constrain schemes/destinations, normalize and validate consistently, enforce network egress rules, revalidate redirects and resolved destinations, avoid forwarding credentials, and isolate fetch workers. Telemetry can connect feature invocation, destination classification, redirect chain, and policy decisions. Explain DNS and private-address concepts to the user before discussing SSRF mechanics.
