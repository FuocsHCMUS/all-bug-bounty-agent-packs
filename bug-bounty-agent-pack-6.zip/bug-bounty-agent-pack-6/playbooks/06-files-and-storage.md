# Files, archives, downloads, and storage

## Boundaries

A filename is user-controlled data unless proven otherwise. Upload processing, archive extraction, storage access, download authorization, content rendering, and file deletion each have separate security decisions. Public object storage is not automatically a leak if the content is intentionally public.

Map who can upload, which parser processes content, where files are stored, which identities can retrieve them, whether previews/exports inherit permissions, and how links expire or revoke. Identify path normalization and content-type expectations through source/configuration evidence where authorized.

## Minimal experiments

Use tiny inert files and owned objects. Compare access to two synthetic records under approved identities. For path concerns, prefer a local fixture with a harmless sentinel rather than production filesystem reads. Archive handling tests need explicit approval and size limits; no decompression bombs, massive files, malware, executable uploads, or overwrite attempts on real systems.

Do not list storage buckets broadly, guess other customers' keys, download backups, or use exposed credentials. If an unexpected sensitive file appears, stop and preserve minimum private evidence. A signed URL can be a deliberate capability; assess its documented sharing and expiry behavior.

## Evidence and false positives

Record owner, file identity/hash, intended access, link issuance/expiry, synthetic marker, actual response, and negative control. A storage key name is not protected content. Content-Disposition and MIME behavior need context; one missing header does not establish arbitrary code execution.

## Fix and SOC lesson

Authorize object access and derived artifacts, isolate storage from executable paths, use safe archive extraction, bound resource use, validate intended content, and serve risky formats under appropriate isolation. Useful telemetry includes upload owner, storage object ID, processing job, retrieval authorization, and revocation events, without logging whole file contents.
