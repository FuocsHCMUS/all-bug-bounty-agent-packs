# Caches, browser origins, and transport controls

## Different layers, different guarantees

TLS protects a connection to a verified endpoint; it does not authorize access to an object. The browser's same-origin policy constrains script access; CORS selectively relaxes it. A cache reuses a response according to its keys and rules. These mechanisms interact but are not interchangeable.

Explain scheme/host/port origins and the difference between a site and an origin before testing cookies, cross-origin behavior, or caching. Identify CDN/proxy/browser layers and the intended privacy of the response.

## Research questions

Does private content vary by identity/tenant at every caching layer? Does cross-origin response access require inappropriate credentials or trust? Do cookie settings match the application's use? Is a security header applicable to this resource, or is it an API/download whose risks differ from an HTML page?

Use synthetic data and a dedicated profile. Cache behavior experiments can affect other users: prefer staging or a clearly isolated test key with explicit program permission. Do not perform shared-cache poisoning, request smuggling, parser desynchronization, connection flooding, or victim targeting in production as a generic check. Study those classes through local models and authorized source review.

## Evidence

Record origin, identity, resource sensitivity, response content, cache signals, controls, and environmental assumptions. A permissive CORS header without readable sensitive data and relevant browser conditions may have no demonstrated impact. A missing header is usually a hardening observation until a concrete security consequence is shown.

## Fix and defense

Use correct cache variation/privacy rules, avoid caching private data under shared keys, validate cross-origin trust deliberately, and apply context-appropriate cookie/browser protections. SOC learning can connect edge and application logs using request IDs, cache result, identity context, and origin policy decisions. Do not conclude that a visible CDN implies effective application authorization.
