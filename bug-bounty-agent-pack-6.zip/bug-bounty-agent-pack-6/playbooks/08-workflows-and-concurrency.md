# Business workflows, replay, and concurrency

## Model valid states

Business logic bugs violate product rules: a capability remains valid after revocation, a one-time action can be repeated, or an operation runs from an invalid state. First establish the intended rule from documentation and product behavior. An unusual sequence is not automatically a security issue.

Draw states and transitions for invitation, acceptance, membership, approval, export, cancellation, expiry, and deletion as relevant. Attach actor/role prerequisites and side effects to each edge. Identify whether authorization is checked when work is queued, when it runs, or when its result is downloaded.

## Research questions

Does a permission change revoke a derived link as promised? Is an operation idempotent when repeated? Can stale clients invoke a transition after its precondition changes? Are async jobs bound to the correct owner/tenant throughout their lifetime?

Use paper models and a local synthetic state machine first. Financial operations, discounts, inventory, real subscriptions, mass notifications, and concurrency experiments can have real effects. Do not race production requests or create duplicate charges/orders. A permitted staging concurrency test still needs exact request/concurrency limits, no real money, cleanup, and a clear stop rule.

## Evidence and alternatives

Distinguish UI lag from persistent server state, asynchronous eventual consistency from unauthorized access, documented grace periods from broken revocation, and a harmless duplicate response from a duplicated effect. Record before/after state, actor, timestamp, intended invariant, control, and allowed proof. Do not increase load until a timing issue appears.

## Fix and SOC lesson

Enforce server-side state preconditions, atomic transitions, idempotency where needed, capability lifetimes, and authorization at the meaningful lifecycle boundaries. Correlate transition history, actor, job ID, object state, and duplicate-effect indicators. Detection should distinguish retries from actual repeated effects.
