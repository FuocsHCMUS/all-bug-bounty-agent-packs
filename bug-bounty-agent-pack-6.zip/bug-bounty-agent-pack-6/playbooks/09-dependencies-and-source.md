# Dependencies, source review, and patch neighborhoods

## Establish source authority

Review only user-owned code or source expressly supplied/authorized by the program. A public source repository may differ from the deployed build. Record branch, commit, dependency lockfiles, build configuration, and any evidence connecting it to the target. Never read unrelated local repositories or secrets to fill gaps.

## Trace contracts

Map external input to validation, authorization, business state, persistence, interpreter, and output. Identify the security decision at each boundary. Look for consistent enforcement and unsafe assumptions rather than matching suspicious function names alone. A dangerous API can be used safely; a safe-looking wrapper can omit authorization.

For dependencies, distinguish direct/transitive packages, runtime/development use, optional features, platform constraints, and reachable vulnerable code. A vulnerable package in a lockfile does not prove a reachable production exploit. Follow the CVE applicability guide and vendor backport details.

## Patch analysis

Read the complete relevant change, tests, callers, and release notes. State the repaired invariant and search authorized code for analogous assumptions. Related patterns produce hypotheses requiring independent evidence. Do not call every similar function vulnerable.

Do not run repository setup, tests, build hooks, or scripts just because code is available. Inspect dependencies and propose execution separately. Static review itself may proceed within the authorized file scope.

## Fix and learning

Prefer centralized, explicit security contracts with tests for allowed and forbidden cases, while checking bypass paths. Recommend dependency updates that match actual affected/reachable components. Explain supply-chain and application-runtime risks separately. Defender ideas include build provenance, software inventory, deployment version, configuration, and advisory tracking; network banners alone provide weak coverage.
