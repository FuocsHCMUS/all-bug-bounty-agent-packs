# Mobile, desktop, and client artifacts

## Scope and trust

A client is normally an untrusted environment from the server's perspective. Hidden buttons, obfuscated code, and local checks do not replace server authorization. Client artifacts can help understand endpoints and data flows, but an embedded URL or string does not authorize testing it.

Verify the package/application ID, version, acquisition source, license, and program scope. Use the user's own test device/account or an explicitly approved local environment. Ask before installing emulators, drivers, interception certificates, device tools, or runtimes. Do not alter a personal device's trust settings automatically.

## Analysis questions

What security decisions happen only in the client? Are stored values sensitive, merely identifiers, or intended public configuration? Which endpoints are actually in scope? Do deep links and callbacks respect identity/context? Does local storage behavior expose the user's own data under an attacker model permitted by the program?

Prefer static authorized analysis and supplied captures. Do not steal live tokens, bypass device protections on others' devices, intercept unrelated traffic, or use extracted credentials. A hard-coded public API identifier is not automatically a secret; establish its intended privileges without using it against third-party services.

## Evidence and defense

Record exact build, platform, permissions, account ownership, attacker prerequisites, and demonstrated effect. Separate client-side tampering from a server-side security failure. Recommend server enforcement, secure credential/storage design, appropriate platform APIs, and minimized sensitive client data. SOC lessons should identify which server events can validate abuse; client telemetry may be incomplete or attacker-controlled.
