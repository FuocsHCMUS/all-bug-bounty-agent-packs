# In-scope AI feature boundaries

## What makes a security issue

An AI feature may retrieve private documents, call tools, or act using an application's identity. The important boundaries are data access, tenant isolation, tool permissions, external actions, and instruction/data separation. A strange answer, hallucination, or generic prompt refusal bypass is not automatically a reportable security vulnerability.

Confirm that AI testing is explicitly allowed and that the program defines relevant categories. Use only tester-owned documents, synthetic records, and approved tools/destinations. Do not query for other users' conversations, extract real secrets, invoke consequential actions, or test unrelated model providers.

## Research model

Map user input, retrieved content, model context, authorization checks, tool definitions, action approval, and output. Ask whether untrusted retrieved text can cross into instruction authority; whether retrieval filters respect identity/tenant; whether a tool uses excessive privileges; and whether a user-visible confirmation covers the actual action.

Use inert canaries and local paper models first. If an approved live test is needed, design a benign observable result with no secret disclosure or external side effect. A model repeating an instruction from a document does not alone prove an application security boundary failed.

## Evidence and fix

Record feature/build, controlled input and document ownership, allowed capabilities, actual effect, negative control, and limits. Distinguish model behavior from application authorization. Recommend enforcement outside the model: least-privilege tools, server-side access checks, data/instruction separation, narrow action approvals, and egress controls.

SOC ideas include safe tool-call audit records, retrieved-document IDs, identity context, action-approval IDs, and denied cross-tenant retrieval. Avoid logging full private prompts or document contents by default. Apply the same prompt-injection protections to the researching agent itself.
