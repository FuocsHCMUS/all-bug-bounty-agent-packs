# Testing and analysis playbooks

These playbooks describe how to reason about a class and design a permitted minimal proof. They do not authorize requests or replace AGENTS.md. Start with product expectations and controlled data. Use the relevant playbook, not the whole catalog at once.

| Surface | Playbook |
| --- | --- |
| Object, role, and tenant boundaries | [Authorization](01-authorization-and-tenants.md) |
| Login, recovery, sessions, federation | [Identity](02-authentication-sessions-and-oauth.md) |
| REST, GraphQL, schemas, properties | [APIs](03-api-and-graphql.md) |
| Queries, templates, browser rendering | [Input and interpreters](04-input-and-interpreters.md) |
| Server URL fetchers and callbacks | [SSRF and URL handling](05-server-side-fetching.md) |
| Upload, download, archive, storage | [Files](06-files-and-storage.md) |
| Cache keys, browser origin, transport | [Web boundaries](07-cache-browser-and-transport.md) |
| State machines, concurrency, replay | [Business logic](08-workflows-and-concurrency.md) |
| Source, libraries, patch context | [Dependencies and source](09-dependencies-and-source.md) |
| Authorized mobile/desktop artifacts | [Clients](10-mobile-and-client-artifacts.md) |
| In-scope AI features and tool permissions | [AI features](11-ai-feature-boundaries.md) |

When learning a new class, use the concept chain in [learning/02-security-concepts.md](../learning/02-security-concepts.md). For observed findings, use [validation](../references/06-validation-and-evidence.md) before [reporting](../references/07-reporting-and-triage.md).
