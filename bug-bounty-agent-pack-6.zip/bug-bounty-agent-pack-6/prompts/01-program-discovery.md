# Public program discovery

Read AGENTS.md and references/01-authorization-and-permissions.md. Research public HackerOne, Bugcrowd, or official company program pages using ordinary browsing. Do not start target testing.

Produce a dated shortlist with official URL, public/private status, participation requirements, allowed assets and key exclusions, test-account access, automation and AI restrictions, relevant technology evidence, disclosure requirements, beginner suitability, and unknowns. Verify important claims from the current program page. Do not invent payout ranges or invite eligibility.

Recommend one manageable program based on clarity, learnability, allowed safe experiments, and the user's interests. Explain the tradeoffs. Prepare intake questions and a research-only engagement draft. If access requires login or accepting terms, ask the user to handle that step. A shortlist is not approval to test its assets.
