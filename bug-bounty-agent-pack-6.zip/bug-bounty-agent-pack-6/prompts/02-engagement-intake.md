# Engagement intake

Read the current official policy supplied by the user. Prepare engagement.json, a scope ledger, policy snapshot/reference, account plan, ambiguity log, and an initial research queue. Distinguish policy permission, user execution approval, and report eligibility.

Check host/path/port limits, wildcard semantics, exclusions, third parties, identity provider boundaries, permitted methods, AI/automation terms, confidentiality, request limits, accounts, program status, and reporting route. Do not treat an unresolved field as permissive.

Prepare the smallest useful test batch with exact actions/commands, versions/hashes, controlled identities, total requests, rate/concurrency, duration, redirects, side effects, cleanup, and stop conditions. Ask for one bounded execution approval only after the plan is reviewable. Continue independent public research while waiting. Missing answers do not authorize dependent work.
