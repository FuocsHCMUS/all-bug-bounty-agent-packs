# Learn and map the application

Use public documentation and supplied authorized artifacts first. Explain the product's normal workflows before suggesting vulnerabilities. Build an asset ledger, endpoint inventory with provenance, role/action/object matrix, tenant boundaries, data flow, and lifecycle state map.

Identify where identity is established, authorization checked, data interpreted, derived artifacts generated, and permissions revoked. Mark facts versus architectural guesses. Do not enumerate hidden endpoints or issue target requests without an approved batch.

Deliver a beginner-readable normal-flow explanation, a technical boundary map, three to five prioritized hypotheses, and the smallest missing observations needed to evaluate them. Define expected secure behavior and negative controls for each hypothesis. Avoid assuming a URL found in an old writeup exists today.
