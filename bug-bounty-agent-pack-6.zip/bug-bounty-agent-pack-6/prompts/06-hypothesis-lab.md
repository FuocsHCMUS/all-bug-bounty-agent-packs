# Creative hypothesis lab

Read references/05-creative-research.md and the current application map. Generate a small set of product-specific hypotheses using ownership, roles, lifecycle revocation, derived data, async work, representation, caching, and patch neighborhoods where relevant.

For each idea state: known facts, assumptions, security invariant, competing explanation, expected safe result, candidate failure result, negative control, falsification criterion, minimum experiment, cost, risk, and permission status. Rank by useful evidence and safe learning value rather than dramatic hypothetical impact.

Do not execute. Select one or two ideas for a concrete bounded plan. Explain why the others should wait or be rejected. Label attack-chain edges observed, lab-only, or hypothetical; do not claim novel zero-days from a literature search gap.
