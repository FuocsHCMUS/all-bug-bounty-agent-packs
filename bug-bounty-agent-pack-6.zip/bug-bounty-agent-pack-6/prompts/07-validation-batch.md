# Validate one approved batch

Read the current case, scope ledger, approval text, plan hash/version, and references/06-validation-and-evidence.md. Verify both program and user gates. If approval is absent, expired, ambiguous, or mismatched, prepare a concrete request and do not execute.

Within an approved batch, establish baseline and negative controls using tester-owned identities and synthetic data. Enforce shared request/time/concurrency limits, redirects, data minimization, and cleanup. Track actual operations and stop on sufficient proof or any safety signal.

Report exact observed behavior, alternate explanations considered, evidence paths, budget spent, cleanup, and outcome: confirmed, rejected, or inconclusive. Explain limits. Do not expand the batch or repeat it with a more invasive method just because the first result was negative.
