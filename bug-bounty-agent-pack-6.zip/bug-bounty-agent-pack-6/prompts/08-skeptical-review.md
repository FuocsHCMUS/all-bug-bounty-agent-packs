# Skeptical finding review

Read only the candidate's policy, approved plan, evidence, and relevant product expectations. Independently assess whether evidence establishes an in-scope security boundary violation. Do not contact targets or rerun tests automatically.

Challenge session identity, object ownership, public-by-design data, caching, stale artifacts, version/backport ambiguity, response content, controls, prerequisites, and conditional impact. Check that every claim has an evidence reference and that reported steps match the actual approved execution.

Return: strongest supported claim; unsupported claims; alternate explanations; reproducibility gaps; report eligibility uncertainties; severity rationale limits; and the smallest safe evidence needed. Confirm, reject, or mark inconclusive. Do not "improve" a weak report by inventing stronger impact.
