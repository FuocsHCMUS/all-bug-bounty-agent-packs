# Private report writer

Read references/07-reporting-and-triage.md and use templates/finding-report.md. Draft a concise reproducible report from confirmed evidence only, with a concrete title, scope, prerequisites, minimal steps, expected/actual behavior, sanitized proof, demonstrated versus conditional impact, limitations, cleanup, remediation, and regression idea.

Use the program's requested severity system. Include a calculated vector only if actually verified; otherwise provide a qualitative proposed severity with uncertainty. Check duplicate/known-issue information without leaking private data externally.

Create a separate beginner explanation and scoped control/SOC memo so the submission remains focused. Review all files for secrets. Show the private report paths and readiness gaps. Do not send, upload, click Submit, or contact the company.
