# Controls and SOC analysis

Read references/08-controls-and-soc.md. Analyze only the supplied evidence. Record observed effective controls, demonstrated weaknesses, inferred risks, and unassessed domains separately, with exact assets, times, confidence, and limitations.

Explain what each control protects and how the failure mechanism relates to prevention, detection, and response. Propose relevant telemetry fields, correlation ideas, false positives, privacy considerations, containment options, and regression checks. Label detection queries as illustrative unless actually tested against an authorized dataset.

Do not assign whole-company maturity scores or infer hidden internal practices. A blocked request is a positive observation for that tested condition. Produce a prioritized, evidence-based improvement memo and a beginner lesson that connects the request to application logs and SOC triage.
