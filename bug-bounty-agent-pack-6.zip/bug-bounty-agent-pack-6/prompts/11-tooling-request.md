# Prepare a tool or integration request

Read references/10-windows-python-and-tools.md and references/11-optional-integrations.md. Identify the specific task current tools cannot accomplish. Prefer a standard-library or already-available option.

For lightweight portable acquisition or trusted workspace-local Python dependencies, proceed within the user's preparation permission and record provenance, versions/hashes, size, license, paths, and dependencies. Do not run the acquired tool or PoC automatically.

For execution, machine changes, source builds, large acquisitions, MCP/plugins/skills, or data-collecting integrations, present the exact reviewed commands/config diff, permissions, data destinations, costs, side effects, verification, cleanup/rollback, and fallback. Ask for the narrow missing approval once the proposal is concrete. Do not change global settings or install into system Python.
