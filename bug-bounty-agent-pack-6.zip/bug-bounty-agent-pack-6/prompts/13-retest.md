# Retest an authorized fix

Read the original finding, accepted scope, new build/fix information, current policy, and explicit retest authorization. Prepare a bounded retest plan using the original controlled identities and synthetic records or approved replacements. Ask for execution approval if not already covered.

Verify that legitimate use still works and that the formerly forbidden behavior is denied. Check only documented adjacent paths needed to assess the fix; do not turn retesting into a new broad hunt. Record build, time, request budget, evidence, state differences, and cleanup.

Conclude fixed for tested paths, still reproducible, or inconclusive. Explain coverage and remaining unknowns. Prepare the user's reply to triage as a draft; do not send it automatically.
