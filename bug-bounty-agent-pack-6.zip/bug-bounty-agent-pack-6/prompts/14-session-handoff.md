# Session handoff and cross-agent resume

Read templates/session-handoff.md. Save the case ID, mode/state, policy source and review time, scope/exclusions, exact unexpired approvals, completed actions, spent/remaining budget, evidence paths, current hypotheses, confirmed/rejected/inconclusive results, cleanup, and pending decisions. Exclude raw secrets.

List what the next agent should read and the next useful action. Do not claim an approval that exists only as an unsourced flag. Record changes since the previous handoff and whether any target activity is still running.

When resuming, verify the real approval records, current policy, artifact integrity where relevant, and runtime capability. Stop obsolete processes only with appropriate authority. Do not rerun tests because the new session lacks memory; use the evidence and ask only for genuinely missing decisions.
