# Application and threat-model session

```text
Apply AGENTS.md and SKILL.md. Use references/14-application-model-and-threat-boundaries.md.
Model the selected case from documentation and authorized artifacts. Describe
one normal task first. Identify actors, controlled identities, assets, roles,
tenants, states, data flows, derived representations and trust boundaries.
Mark facts DOCUMENTED, OBSERVED, INFERRED or UNKNOWN. Preserve uncertainty.

Create templates/application-model.md and templates/threat-model.md as case
records. Establish the intended security promise before calling a behavior
a flaw. Generate a small product-specific hypothesis queue with prerequisites,
alternative explanations and falsification. Do useful public/local analysis
now; prepare any needed experiment for separate bounded execution approval.

Teach one normal request and its authority decision to me from first principles.
Do not invent endpoints, source code, internal services or company controls.
```
