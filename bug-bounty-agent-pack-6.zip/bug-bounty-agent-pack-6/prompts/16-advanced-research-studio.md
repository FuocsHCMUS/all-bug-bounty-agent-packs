# Original hypothesis studio

```text
Apply AGENTS.md and SKILL.md. Read references/05-creative-research.md and
references/15-advanced-research-studio.md for the active product model.

Explore invariants across ownership, roles, state transitions, revocation,
derived data, asynchronous work, representations, error paths and composition.
Use only lenses supported by this product's facts. Prioritize a small queue
by evidence, credible impact, safe experiment cost, uncertainty and learning.
Do not optimize for payload volume, elaborate chains or an unsupported novelty claim.

For each selected idea give the normal behavior, failed assumption, exact
prerequisites, best competing explanation, minimal synthetic observation,
negative control, falsification criterion, operational concern and required
permission. Use templates/experiment-design.md. Keep chain edges labeled
OBSERVED, LAB_ONLY or HYPOTHETICAL. Research can proceed; testing still needs
the actual program and user permissions. Explain one idea from the roots up.
```
