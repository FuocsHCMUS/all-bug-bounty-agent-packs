# Defense and detection session

```text
Apply AGENTS.md and SKILL.md. Use references/08-controls-and-soc.md and
learning/07-soc-and-detection-workbook.md for this reviewed result.

Identify the violated invariant and primary repair. Explain defense in depth
separately. Record effective controls, demonstrated weaknesses, inferred risks
and unknowns in templates/control-assessment-matrix.md. Limit conclusions to
the sampled routes, identities, environment, states and evidence.

Prepare templates/detection-design.md with normal/suspicious behavior, needed
events and fields, privacy limits, a proposed analytic, synthetic positive and
negative examples, false positives, tuning assumptions, triage and response.
Label queries unvalidated unless they ran on an authorized suitable dataset.
Do not infer internal logging, SOC staffing or company-wide maturity.

Teach event -> analytic -> alert -> investigation -> response, connecting each
stage to the finding. Include one exercise and explain its answer.
```
