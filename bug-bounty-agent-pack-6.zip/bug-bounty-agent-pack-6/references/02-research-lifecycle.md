# Research lifecycle and case state

## State machine

| State | Meaning | Allowed next step |
| --- | --- | --- |
| RESEARCH_ONLY | No active permission established | Public policy/source research and local preparation |
| INTAKE | Program chosen; collecting scope and constraints | Resolve eligibility, AI rules, assets, test-account needs |
| PLAN_READY | Exact test batch is reviewable | Request execution approval |
| AWAITING_APPROVAL | Dependent execution paused | Continue independent analysis; wait for a human answer |
| APPROVED_BOUNDED | Program and user gates satisfied | Execute only the approved batch |
| VALIDATING | Approved experiment in progress | Track requests, observations, stop conditions |
| CANDIDATE | A suspicious observation exists | Negative control, alternate explanations, review |
| CONFIRMED | Permitted evidence demonstrates a boundary violation | Draft a report; stop unnecessary exploitation |
| REJECTED | Evidence contradicts the hypothesis | Record why and what could change the conclusion |
| INCONCLUSIVE | Evidence is insufficient or safe proof unavailable | Record limits; suggest owner-assisted verification |
| REPORT_DRAFT | Private report ready for user review | User submits or explicitly authorizes submission |
| PAUSED_SAFETY | Scope/data/service issue occurred | Resolve cause, revise plan, obtain needed approval |
| RETEST_READY | Fix and retest authorization available | Reproduce only the original bounded proof and controls |
| CLOSED | Reporting/cleanup/learning recorded | Archive locally under agreed retention rules |

These are research states; a case may contain hypotheses in different states. Do not let a confirmed issue promote the whole engagement into unrestricted execution.

## Stage 1: Select a suitable program

Prefer clear scope, stable public policies, an application the user can learn, legal access to test accounts, and tests that do not require dangerous production effects. Evaluate invitation/region/age/identity requirements, exclusions, duplicate likelihood, known-issue lists, permitted automation, confidentiality, and the user's current skill level. Do not rank only by bounty amount. Label unavailable facts as unknown. Save a shortlist with source URLs and dates; do not imply you joined a private program.

## Stage 2: Learn the product

Describe normal user tasks: registration, login, profile editing, project creation, collaboration, export, billing, deletion, and recovery. Build a role/action/object matrix. Map where data enters, which components process it, where it persists, and what identities cross boundaries. Prefer documentation and the user's allowed captures before touching a target.

Create an asset ledger with scope evidence and an endpoint ledger with discovery provenance. An endpoint found in a writeup is not proof it exists now. Record how it was found and whether it has actually been exercised.

## Stage 3: Create a small research queue

Each hypothesis needs a mechanism, prerequisites, evidence, expected secure behavior, candidate failure behavior, negative control, falsification criterion, minimum useful experiment, cost, risk, and approval status. Keep the active queue small enough to learn from each result. Do not launch every tool because it is available.

An internal prioritization aid may compare impact, supporting evidence, product-specific plausibility, time, duplicate likelihood, and operational risk. This ranking is a work-allocation heuristic, not CVSS, a bounty estimate, or a scientific risk score. A high-risk experiment should be redesigned, not justified by a large hypothetical payout.

## Stage 4: Validate with minimal proof

Review a bounded batch with the user. Track the actual request count and state changes, including browser background traffic and tool retries where measurable. Use local synthetic data and negative controls. If an assumption is disproved, update the hypothesis rather than adding arbitrary payloads. If evidence is sufficient, stop. If proof would require harmful access, label the candidate incomplete and explain the safer verification request.

## Stage 5: Challenge the conclusion

Ask whether the response is cached, intentionally public, from a different test account, stale, mocked, or blocked. Check content and identity, not status codes alone. Distinguish access to an object identifier from access to protected data. Distinguish a browser-side restriction from a server authorization control. Consider program exclusions and existing disclosures without sending private proof to a search engine.

## Stage 6: Report, teach, and close

Produce a private reproducible report, sanitized evidence index, proposed severity rationale, remediation with a regression idea, a control-observation memo, a SOC lesson, and a session handoff. Use precise limitations: "Observed on these two test objects" is stronger evidence than an unsupported "all customers affected."

Retest only with current authorization. A fix can stop one proof while leaving a related path unresolved; describe the actual tested coverage. Cleanup should remove tester-created records only where allowed, stop local processes, and record any artifact that could not be removed. Never delete production data to conceal a test.

## Session cadence

Start by loading the case handoff, current policy, approval ledger, and remaining budget. During work, update records when an observation changes the plan. End with a concise progress summary and next action. Avoid generating long teaching material while a service incident needs immediate attention; stabilize first, teach from the documented event later.
