# Original, evidence-driven research

## Creativity as better questions

Strong research starts with a model of what must always remain true. A sophisticated finding can arise from a simple request that violates a subtle invariant. Payload volume and tool count are poor substitutes for product understanding.

Write each idea as: **Given** these explicit preconditions, **if** this boundary is implemented incorrectly, **then** this safe observable difference should occur; **otherwise** this control result should occur. State what evidence would reject the idea. This produces useful experiments even when the hypothesis is wrong.

## Research lenses

| Lens | Questions to ask | Safe research form |
| --- | --- | --- |
| Ownership | Who owns the object and who is asking? | Matrix of two owned accounts and synthetic objects |
| Roles | Is a capability checked per operation? | Compare permitted role transitions and expected denies |
| Time | What remains valid after revocation/expiry? | Paper state machine, then a bounded own-account test |
| Workflow | Can a step be reached in an unintended state? | Document valid/invalid transitions without real transactions |
| Representation | Do components interpret the same value differently? | Local parser model and standards review |
| Caching | Which identity and tenant define cache variation? | Synthetic markers, owned sessions, clear cache alternatives |
| Async work | When are permissions checked: enqueue or consume? | Local queue model or approved staging job |
| Derived data | Do exports/previews/search inherit source controls? | Owned synthetic artifacts and explicit lifecycle expectations |
| Recovery | Does recovery preserve the account's trust guarantees? | User-controlled recovery channels; no victim interaction |
| Integration | Who validates identity/tenant across components? | Architecture review; no third-party pivot |
| Patch neighborhood | Does a fixed invariant appear elsewhere? | Authorized source/patch review and related-path hypotheses |
| UI/API divergence | Is the server enforcing what the UI hides? | Documented APIs, minimal own-account comparison |

## Differential and metamorphic thinking

A differential experiment changes one relevant factor while keeping the rest stable: identity A versus B, own object versus the other controlled object's identifier, member versus removed member, or vulnerable versus fixed local build. Include a control that demonstrates the environment itself works.

A metamorphic property says a transformation should preserve a security guarantee. For example, changing a resource's display name should not change its owner; exporting an object should not make its private contents publicly accessible; retrying a completed operation should not apply it twice. These are candidate invariants; confirm the product's intended semantics before treating a difference as a bug.

## Hypothesis queue and stopping rule

For each hypothesis record evidence, competing explanation, safe proof design, maximum budget, potential disruption, expected learning, and report eligibility. Choose a small batch with a clear stopping rule. Prefer a test that can rule out several assumptions with few requests. If a result is noisy, investigate measurement quality before widening the test.

Do not optimize for bypassing every defensive control. A control blocking the attempted path is a positive observation. A different hypothesis may be worth researching, but evading rate limits, hiding traffic, expanding scope, or compromising an identity is not justified by creativity.

## Attack graphs without harmful chaining

Represent a chain as nodes of observed capabilities and edges with explicit prerequisites. Label each node `OBSERVED`, `LAB_ONLY`, or `HYPOTHETICAL`. Do not turn a plausible edge into a confirmed impact claim. If a next edge needs real-user access, command execution, a third-party pivot, or other unapproved effects, stop and document the conditional impact. A program owner may validate it internally.

## Novelty and responsible uncertainty

Say "new to this investigation" unless a literature review supports a broader novelty claim. Public searches cannot prove nobody has discovered an issue. Do not invent CVEs or announce a zero-day because a search returned nothing. A clear report of a familiar root cause in a new authorized context can still be valuable.

Use concise experiment reasoning summaries: known facts, assumptions, alternatives, proposed test, expected observations, and decision rule. Do not request or expose hidden chain-of-thought. The research artifact should be independently assessable from its evidence.
