# Validation and evidence

## Build a proof, not a story

A useful finding links five things: intended security property, attacker prerequisites, permitted action, observed boundary violation, and resulting impact. The evidence should let another authorized tester reproduce the same result without trusting the agent's confidence.

Prefer small reversible tests on synthetic data. Create two tester-owned identities where permitted. Establish that A can access A's object, B can access B's object, and the product requires isolation between them. Test only the approved comparison. A denial is meaningful only if the control requests show both objects and sessions were valid.

## Before execution

- Verify current scope, exclusions, AI/data conditions, and a matching user approval.
- Review code and dependencies, including subprocesses, callbacks, redirects, retries, concurrency, telemetry, and automatic update behavior.
- Record tool/version or script hash. Disable uncontrolled discovery, templates, active scanners, and background traffic outside the plan.
- Establish total and per-host request budgets, execution duration, account limits, cleanup, and stop signals. Unspecified limits block execution.
- Define the expected secure result, failure indicator, negative control, and alternate explanations.
- Use a separate browser profile with only test accounts. Never reuse a profile containing personal banking, email, or unrelated company credentials.

## During execution

Log the smallest request/response set that supports the claim, with timestamps and stable case IDs. Avoid putting credentials in terminal history, screenshots, filenames, or query parameters. Store private originals only when necessary and allowed. Use redacted derivatives for reports. Do not automatically replay HAR files; they may contain secrets, mutations, and third-party requests.

Stop after sufficient proof. A real person's email or secret appearing unexpectedly triggers a stop, not an enumeration task. Do not "verify" credentials by logging in. Preserve only minimal evidence and ask the user how to proceed under the program's process.

## Common alternate explanations

| Suspicion | Check before concluding |
| --- | --- |
| Cross-user data access | Are both sessions really different? Is the data intended public? |
| Cache leak | Is the marker unique? Did the browser or proxy reuse a local response? |
| Authorization bypass | Did the returned body contain protected data or only an error shell? |
| Stored input execution | Was there actual permitted execution in the relevant context, not only reflection? |
| CVE exposure | Is the vulnerable build/configuration/path actually present? |
| Race | Is a duplicate state persistent, or only a transient display? Was the test permitted? |
| Missing control | Is the control applicable at this layer? Is an equivalent control elsewhere? |
| Sensitive artifact | Is it real, current, private, and from the authorized asset? Do not access more to answer casually. |

## Evidence record

Record: case/finding ID; acquisition time and timezone; actor/test-account labels; scope and approval references; tool/version/hash; action; expected result; actual result; sanitized request/response; status/body distinction; negative controls; reproduction count; cleanup; source artifact paths; hashes; and limitations.

Prefer exact minimal excerpts over giant screenshots. A screenshot can illustrate a UI state but may hide request identity and caching. A response body can demonstrate content but may need request/session provenance. Explain how pieces support each other. Do not describe a synthetic demonstration as observed production evidence.

## Integrity and retention

Use SHA-256 manifests to detect file changes, not to claim authenticity or a legally complete chain of custody. Keep raw originals separate from edited/redacted copies. Record when redaction changes a file and preserve a mapping privately if needed. Avoid uploading report videos to public/unlisted hosts without permission; access controls can change and URLs can leak.

Agree a retention period with the user and program. Do not silently delete evidence or keep it indefinitely. Git ignore patterns are a convenience, not encryption or access control. Check staged files before any commit; do not commit cases, tokens, HARs, packet captures, or private program details.

## Validation outcome

Use `CONFIRMED`, `REJECTED`, or `INCONCLUSIVE`, with a short evidence-based rationale. State observed and conditional impact separately. If a safer proof is unavailable, write what the program owner can inspect internally. A blocked experiment is not a successful exploit; an unreproduced result is not proof the system is secure.
