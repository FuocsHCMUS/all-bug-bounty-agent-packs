# Private reporting, triage, and retesting

## Report the observed boundary violation

Lead with a concrete title: actor, operation, violated boundary, and affected resource. Explain the normal security rule before reproduction steps. Include the exact in-scope asset, policy reference, prerequisites, test accounts, synthetic data, minimum steps, expected versus actual results, sanitized evidence, demonstrated impact, limitations, cleanup, and remediation.

Avoid vague titles such as "critical vulnerability" or unsupported claims such as "complete company takeover." A response code alone rarely establishes impact. A report should still make sense if the reader cannot watch a video.

Use [templates/finding-report.md](../templates/finding-report.md) and the [fictional example](../examples/fictional-authorization-case.md).

## Severity rationale

Describe confidentiality, integrity, and availability effects individually. Explain required privilege, victim interaction, exposure, affected data sensitivity, and the confidence/limits of the proof. Use the program's preferred severity taxonomy. If using CVSS, include the version, complete vector, rationale for each metric, and the source/calculator checked. Do not invent a score without calculating it.

Separate demonstrated impact from plausible downstream impact. An owned test object's exposure proves an authorization defect under those conditions; it does not prove the total number of affected customers or that administrator credentials are accessible. Do not access extra records to estimate scale. A critical label needs correspondingly strong evidence and permitted verification.

## Eligibility and duplicates

Check the current exclusion list, known-issue list, and public disclosures. Group multiple manifestations of one root cause when that makes the report clearer. Do not submit several minimally different reports to inflate volume. Similar symptoms can have distinct root causes; explain the evidence when proposing separate findings.

Public duplicate research must not leak private details into search engines or external models. A private program's existence may itself be confidential. Keep duplicate likelihood as an internal planning uncertainty, not a guarantee about the program's triage result.

## Remediation that matches the mechanism

Name where enforcement belongs: server authorization, object ownership, tenant scoping, interpreter separation, lifecycle revocation, or another specific boundary. Give a primary fix and relevant defense in depth. A WAF rule, UI hiding, random identifiers, or generic "sanitize input" advice may not repair the root cause.

Propose a regression test with an allowed request and a forbidden counterpart, including relevant roles and state transitions. Do not provide an unbounded offensive regression harness. Specify that fix verification is limited to the original proof and identified adjacent paths.

## Triage communication

Prepare concise replies: question received, evidence that addresses it, any new observation, remaining uncertainty, and a proposed bounded next step. Do not respond defensively to "not reproducible"; first examine account state, stale links, caching, changed builds, prerequisites, and reproducibility. Do not raise impact claims just to contest a rating.

All communication remains a draft unless the user explicitly authorizes sending. Show the exact text and recipients first if approval is needed. Do not submit a report while still asking the user what it should contain. Do not publish, threaten disclosure, or pressure payment.

## Retest and closure

Check scope and retest instructions again. Reuse synthetic artifacts if safe and still valid. Reproduce the original baseline, then verify the formerly forbidden action is denied without breaking permitted use. A fix may change endpoint behavior; record that rather than forcing the old request until something breaks.

Conclude `FIX_VERIFIED_FOR_TESTED_PATHS`, `STILL_REPRODUCIBLE`, or `INCONCLUSIVE`. Include build/date, cases tested, evidence, untested boundaries, and cleanup. Do not equate one fixed path with company-wide security assurance.
