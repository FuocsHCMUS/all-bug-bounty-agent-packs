# Observed controls, risk, and SOC learning

## Assess only what the evidence supports

An external bounty investigation samples observable behavior. It normally cannot establish the company's internal governance, incident response maturity, detection coverage, patch process, or overall security posture. Use a scoped control memo rather than a company-wide score.

| Label | Meaning | Example |
| --- | --- | --- |
| OBSERVED_EFFECTIVE | A control behaved correctly in the tested condition | Account B was denied access to A's synthetic object in the control request |
| OBSERVED_WEAKNESS | Evidence demonstrates a specific control failure | One export route returned A's synthetic object to B |
| INFERRED_RISK | A plausible risk remains untested | Another export path may share the same authorization helper |
| NOT_ASSESSED | No adequate evidence | Whether the company's SOC received or acted on the event |

Record asset, route, identity, time, sample size, evidence link, confidence, limitations, and next validation needed. "Effective for these cases" does not mean the entire control is universally effective.

## Control domains to consider

1. **Asset and exposure management:** documented asset ownership, clear scope, stale surfaces observed through allowed evidence. Do not infer an entire inventory from public search results.
2. **Identity and session management:** login flows, session invalidation, recovery, device/session visibility, tenant context. Only use controlled identities.
3. **Authorization and isolation:** object, function, property, role, and tenant boundaries; derived exports/search/preview behavior.
4. **Input and interpreter boundaries:** structured validation, parameterization, rendering contexts, safe file handling, parser agreement.
5. **Data protection:** appropriate response minimization, secret exposure, storage/access behavior, retention signals. Do not collect private data to fill the checklist.
6. **Dependency and patch exposure:** vendor applicability evidence and observed mitigation. A banner alone is weak evidence of patch quality.
7. **Browser and transport defenses:** TLS behavior, applicable cookie settings, CSP/HSTS/CORS behavior with context. Header presence is not complete protection.
8. **Abuse controls and resilience:** documented limits and observed enforcement in permitted tests. Do not stress test to grade resilience.
9. **Logging and detection:** distinguish telemetry you can actually observe from telemetry you recommend the owner inspect.
10. **Security response and disclosure:** clarity of the published process and the response actually received by the user. Do not invent internal escalation behavior.

## From finding to detection idea

For an authorization issue, useful application telemetry may include timestamp, authenticated subject identifier, tenant identifier, resource type, requested object identifier, ownership decision, result, route, request correlation ID, and service/build version. Minimize personal data; never log passwords, full cookies, raw bearer tokens, or sensitive response bodies merely for detection.

A candidate detection could identify a subject requesting synthetic object identifiers owned by several other tenants with repeated denied decisions. This is a proposed analytic, not proof the company collects those fields. Evaluate false positives such as legitimate administration, service identities, migration jobs, and stale client retries. Scope tuning and retention matter.

For a revocation bug, correlate membership removal, capability issuance, and later capability use. For unsafe rendering, correlate input source and rendering/sanitization events where available. For a dependency issue, combine asset inventory, build data, advisory applicability, and deployment records instead of relying on network banners alone.

## SOC workflow lesson

Explain the sequence: event collection -> normalization -> analytic -> alert -> triage -> investigation -> containment -> recovery -> lessons. An alert is a hypothesis needing context, just like a scanner result. Show how the report's reproduction steps could help a defender find correlated logs without giving the agent access to the company's monitoring systems.

Use synthetic examples for queries and log records. Label unexecuted query suggestions and specify required field mapping. Never claim a Sigma/SIEM query was validated unless it ran against a suitable authorized dataset. Detection ideas should complement fixing the vulnerability, not replace the fix.

## Risk communication

Explain likelihood assumptions, impact, exposure, existing control evidence, and uncertainty. Use `high concern under these conditions` only with a concrete rationale; do not turn a speculative chain into a confirmed high-risk finding. Recommend specific next checks an internal team could perform, ordered by value and cost.
