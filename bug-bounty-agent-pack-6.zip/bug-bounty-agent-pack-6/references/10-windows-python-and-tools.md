# Windows 11, Python 3.14+, and local tools

## Principles

Keep dependencies and acquisitions within this workspace. Use native PowerShell paths and commands. Do not modify the machine's execution policy, PATH, registry, Defender, firewall, certificates, services, or Python installation to make a tool convenient. Ask before machine installations or runtime changes. Do not assume Unix commands, Docker, WSL, administrator rights, or Python wheels exist.

The user permits local Python dependency setup. Prefer the standard library whenever it meets the task. This documentation pack includes no executable helper and requires no third-party library. Prepare scripts only when a concrete investigation benefits from them; review their execution separately.

## Interpreter and virtual environment

Review commands before execution under the relevant permission rule:

```powershell
python --version
python -m venv .venv
.\.venv\Scripts\python.exe -m pip --version
```

Activation is optional. Calling the full interpreter path avoids changing PowerShell execution policy and avoids installing into the wrong Python. For a needed package, replace the package/version with a reviewed choice:

```powershell
.\.venv\Scripts\python.exe -m pip install --only-binary=:all: "reviewed-package==reviewed-version"
```

That last line is a syntax example, not a runnable dependency declaration. Do not run placeholder names. Record the actual pinned choice, origin, reason, license, and any transitive dependencies. Export versions after installation if useful, then review for private URLs/credentials before sharing. Do not upgrade every package or pip by habit.

If Python 3.14 lacks a compatible wheel, use a standard-library alternative or another reviewed tool. Explain the compatibility failure. Ask before installing compilers, another interpreter, or a source build. Do not assume Python 3.15 or a future version is backward compatible without checking.

## Portable acquisition record

For every downloaded archive/repository, record tool name, task it enables, official URL, version/commit, checksum, license, expected compressed/extracted size, exact workspace destination, dependency requirements, network behavior, and inspection result. The user's blanket permission covers lightweight portable acquisition. Ask when size is substantial, unclear, or likely to trigger a large dependency chain. Do not run the acquired code automatically.

Reject archives with absolute paths, `..` traversal, unexpected symlinks/junctions, or files targeting trusted instruction locations. Inspect extraction paths before writing. Avoid recursive cloning unless the user understands the additional acquisitions. Do not use a downloaded repo as the top-level agent workspace.

## Tool categories and decisions

| Category | When it helps | Decision |
| --- | --- | --- |
| Built-in browser/editor | Read policies, inspect user-supplied artifacts | Start here |
| Offline parsers/hashers | Normalize evidence and create local records | Prepare only when useful; review/approve script execution |
| Intercepting proxy | Understand approved manual request flows | Check existing install first; install/run require appropriate approval |
| Dependency/source analyzer | User-owned or program-authorized source | Review data exposure and file scope |
| Broad scanner/fuzzer | Only explicit program-permitted, bounded tests | Never a default discovery step |
| Exploit framework/public PoC | Understand an advisory, preferably in a lab | Inspect source; separate execution approval; avoid harmful modules |
| Packet capture | A narrow authorized local diagnostic | Can collect unrelated secrets; ask about scope and drivers |

Do not download a toolkit bundle simply because it is popular. Tool names and recommendations change; verify current official releases and Windows/Python compatibility when actually needed.

## Future helper design

Use [script review](../templates/script-review.md) before executing a helper. Case creation can use ordinary file operations; a script is optional. If a future helper validates configuration, explain that structural validity cannot establish owner permission, genuine user approval, URL-scope correctness or enforced traffic limits. Keep actual records available.

An evidence manifest should describe stable files without modifying its own input tree. Pause writers while taking a snapshot, record relative paths and digests, and keep the manifest outside the tree it describes. Filesystem hashes do not establish truth or a complete legal chain of custody.

For Python 3.14+, check wheel and extension compatibility before selecting a dependency. Use a supported package version; do not silently downgrade the user's interpreter, install a compiler, switch to a custom index, or substitute an unreviewed fork. Explain an incompatible dependency and choose the simplest reviewed alternative.

## Process cleanup

Record any process started, port bound, files created, and shutdown command. Bind local labs to loopback, isolate them, and stop after use. A loopback service can still be reachable by local processes; it is not a full sandbox. Verify resolved paths before any recursive removal. Use `Remove-Item -LiteralPath` only on a verified workspace path and preserve evidence the user still needs.
