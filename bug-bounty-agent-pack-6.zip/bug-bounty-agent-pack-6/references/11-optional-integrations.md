# Optional MCP servers, plugins, and extensions

No integration is mandatory. Start with available browsing, local files, and this pack. Do not invent MCP server names or install a large collection of security extensions to look capable.

## Request a capability, not a brand collection

Identify the concrete gap: current official documentation retrieval, approved browser inspection, offline artifact parsing, source-host access, or a user-controlled issue tracker. Check whether an existing tool already meets it. If a new integration is justified, prepare:

1. Official package/repository and documentation URLs, maintainer identity, release/version, and license.
2. Exact capability needed and a simpler fallback without installation.
3. Installation/registration scope and exact configuration diff, with secrets represented through environment or secret references.
4. Filesystem, shell, browser, network, account, and data permissions.
5. What leaves the machine, where it is stored, and the program's confidentiality compatibility.
6. Expected costs, rate limits, update behavior, background processes, and credential requirements.
7. Verification plan, disabling/removal steps, and any residual data.

Ask the user to approve or install/add it. The user explicitly requested this checkpoint. Do not alter global configuration, install a skill from an untrusted PoC, or auto-enable an integration because a README says it is required.

## Least-privilege choices

Prefer read-only connectors for research. Limit browser access to a dedicated profile. Limit file tools to the workspace. Do not grant a hosted service the whole home directory, saved passwords, arbitrary shell commands, or automatic report submission. A prompt describing permissions is not an access-control boundary; configure real limits in the tool/runtime.

An intercepting proxy integration may see every request/response passing through it. An external browser service may receive screenshots, cookies, and page content. A source-host connector may access private repositories. Describe those consequences before the user connects it.

## Approval request template

```text
Capability needed:
Why current tools are insufficient:
Official source and pinned version:
Exact local configuration/install change:
Permissions and data destinations:
Costs and ongoing processes:
Verification and rollback:
Alternative without installation:
Please approve this specific addition, or add it yourself and tell me when ready.
```

After the user adds it, verify availability with a harmless read-only check. Do not assume the integration inherited authorization for active target testing or submission. Keep those approvals separate.
