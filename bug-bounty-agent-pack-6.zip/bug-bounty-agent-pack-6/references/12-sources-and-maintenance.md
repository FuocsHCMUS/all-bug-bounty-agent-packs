# Sources, compatibility, and maintenance

Checked: **2026-11-03**. Platform and research sources below were opened during pack 6 authoring unless a retrieval limitation is explicitly recorded. Verify live behavior and terms for the product/program actually used. The workflows, workbooks and examples are original guidance; linked standards and product manuals remain the authoritative reference for their own contents.

## Agent configuration sources

| Platform | Official source | Configuration conclusion |
| --- | --- | --- |
| Claude Code | [Memory and project instructions](https://code.claude.com/docs/en/memory) | Native AGENTS.md support is documented, with version/configuration and CLAUDE-file caveats. No root CLAUDE.md is required for this pack's default setup. |
| Claude Code skills | [Skills](https://code.claude.com/docs/en/skills) | Use a project .claude/skills wrapper when native skill discovery is wanted. |
| Codex | [AGENTS.md instructions](https://learn.chatgpt.com/docs/agent-configuration/agents-md), [build skills](https://learn.chatgpt.com/docs/build-skills) | AGENTS.md and project .agents/skills are documented. Keep startup instructions small. |
| OpenCode | [Rules](https://opencode.ai/docs/rules/), [skills](https://opencode.ai/docs/skills/) | AGENTS.md and native/cross-compatible project skills are documented. Major-version config differs; the pack does not hard-code shell permission JSON. |
| Cline | [Rules](https://docs.cline.bot/customization/cline-rules) | AGENTS.md and .clinerules/ are documented. Keep task execution approvals enabled. |
| Cursor | [Rules](https://cursor.com/docs/rules) | AGENTS.md plus .cursor/rules/*.mdc adapters are supported. |
| Google Antigravity | [Rules](https://antigravity.google/docs/rules/), [skills](https://antigravity.google/docs/skills) | Current docs use .agents/ with legacy .agent/ compatibility; AGENTS.md is supported. Rule frontmatter needs a valid trigger. |

Claude Code memory documentation was also retrieved through Context7 to cross-check the native AGENTS.md qualifications. No Context7 or other new MCP setup is required to use the pack. The six platform applications were not launched for end-to-end testing.

## Security research sources

- [HackerOne safe harbor overview](https://docs.hackerone.com/en/articles/8494502-safe-harbor-overview-faq): scope remains explicit; read the selected program's current terms.
- [Bugcrowd finding a program](https://docs.bugcrowd.com/researchers/participating-in-program/finding-program/): program scope and participation constraints.
- [Bugcrowd code of conduct](https://www.bugcrowd.com/resources/hacker-resources/code-of-conduct/): conduct and confidentiality, including GenAI considerations. Consult the live wording.
- [Bugcrowd public disclosure policy](https://docs.bugcrowd.com/researchers/disclosure/disclosure/): additional reading; this individual page was not reopened in the pack 6 authoring pass. The consulted Code of Conduct addresses confidentiality; always read the selected brief's current rules.
- [OWASP WSTG](https://owasp.org/www-project-web-security-testing-guide/): testing methodology. Cite the version/section actually used rather than an unstable latest section number.
- [OWASP API Security Project](https://owasp.org/www-project-api-security/): API authorization and related risk categories.
- [FIRST CVSS](https://www.first.org/cvss/): severity framework; [FIRST EPSS](https://www.first.org/epss/): exploitation-probability estimates.
- [CVE Program](https://www.cve.org/) and [NVD vulnerabilities](https://nvd.nist.gov/vuln): recommended lookup destinations. The CVE landing page required JavaScript and NVD returned no readable text through the authoring browser. No individual CVE or current database content was verified or claimed applicable.
- [CISA KEV catalog](https://www.cisa.gov/known-exploited-vulnerabilities-catalog): recommended prioritization source. The authoring browser received a 403 on the catalog page; no current catalog contents/count were used.
- [PortSwigger Web Security Academy](https://portswigger.net/web-security): a source of structured web-security lessons and controlled labs; no lab was launched during authoring.

Direct attempts to retrieve two guessed HackerOne conduct/Bugcrowd terms URLs failed. They are not cited as verified policies. The reachable official safe-harbor, program-selection and conduct sources above support the program-specific intake workflow. Do not substitute guessed URLs or directory summaries for the actual selected program policy.

## Windows and Python sources

- [Python 3.14 venv documentation](https://docs.python.org/3.14/library/venv.html): local environments isolate dependency sets; direct interpreter invocation avoids requiring activation.
- [pip install documentation](https://pip.pypa.io/en/stable/cli/pip_install/): reference for installation options, including wheel-only selection. The pack does not pin a universal dependency set or install any package.

When a specific tool/library becomes necessary, check its current official Windows/Python support, release provenance and dependency requirements. A general Python 3.14 target is not proof every security tool is compatible.

## Maintenance procedure

1. Reopen official documentation for the product version actually installed.
2. Verify instruction discovery, precedence, skill paths, and rule frontmatter. Use native context/settings inspection and behavior tests.
3. Change canonical AGENTS.md/SKILL.md first. Update small adapters only where routing changes.
4. Never add broad tool auto-approval as a compatibility fix.
5. Check local references, JSON and skill metadata with permitted local operations, then use the offline scenarios. Any new script/tool execution follows the user's approval preference.
6. Record what was tested, product/version, date, and limitations in a new verification note.

This pack's authoring checks do not establish that each desktop product was launched or obeyed every instruction. Be explicit about that distinction when distributing it.
