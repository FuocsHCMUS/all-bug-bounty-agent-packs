# Program discovery and intake decisions

Use with [discovery](../prompts/01-program-discovery.md), [intake](../prompts/02-engagement-intake.md) and [permissions](01-authorization-and-permissions.md). The goal is a suitable, documented engagement, not a large target list.

## Separate four questions

1. **Does a program exist?** A public directory or search result can supply a lead. It can be stale or describe a closed/private program.
2. **May this researcher participate?** Invitation, age, geography, identity, contract, employment conflict and account requirements may matter. Do not fabricate eligibility or accept terms for the user.
3. **What is authorized?** The current owner policy controls the assets, methods, conditions, disclosure route and exclusions.
4. **What may this agent execute?** The user's actual permission controls scripts, tools, accounts, software changes, data destinations and communications. Public scope does not waive this permission.

Keep these answers in separate fields. A reward table answers none of the other questions. A vulnerability disclosure policy may authorize limited research without promising payment. A public hostname may still be excluded from a particular program.

## Discovery procedure

Read public listings and linked official policies through ordinary browsing. Prefer the company's own security policy or its verified program page. HackerOne and Bugcrowd are starting points, not automatic authority for all companies shown there. Distinguish published reports used for learning from the current engagement terms. A historical writeup can describe an asset that is no longer included.

For each candidate, record:

- Program identity, platform, official policy URL, retrieval date and current status.
- Public/private/VDP classification and evidence that the user may join.
- Asset types, precise inclusions, explicit exclusions and environment distinctions.
- Permitted and prohibited methods, automation/scanner rules and any required traffic identification.
- AI assistance, confidential data handling, external services and subcontractor/delegation rules.
- Account creation or test-account requirements, test-data restrictions and known issues.
- Submission/disclosure process and any reporting prerequisites.
- Practical learning value: understandable product, usable documentation, feasible controlled accounts, relevant skills.
- Unknowns with a next resolution step; inaccessible policy means unresolved, not permissive.

Do not query search engines with private program names or raw evidence from restricted work. Public research should use public facts. If login is needed, stop that dependent step and ask the user to handle access or supply an authorized policy excerpt.

## Shortlist quality

Compare programs on clarity, account feasibility, operational risk, useful learning, available time and likely evidence quality. Reward size may be mentioned only if actually sourced and current. Do not treat a high advertised maximum as expected earnings. Duplicate likelihood is a hypothesis based on public signals, not insider knowledge.

Recommend one program and explain why its constraints fit the student's current level. If no suitable program is established, recommend a learning exercise or authorized lab rather than forcing a live target choice. Discovery can finish successfully without a target selected.

## Turn prose into scope records

Quote only short essential policy language and link the full policy. Record the exact interpretation separately so an inference is not presented as an owner's statement. For every asset, identify scheme, hostname or identifier, port, path restrictions, wildcard semantics, tenant, third-party ownership, exclusions and evidence source.

Examples are fictional:

| Policy expression | Safe interpretation task |
| --- | --- |
| `https://app.example.invalid` | Determine whether only HTTPS/443 and specific routes are covered; do not infer all ports |
| `*.example.invalid` | Check apex and nesting semantics, exclusions and ownership; wildcard text is insufficient by itself |
| Mobile application package | Check whether backend APIs are separately listed and whether binaries may be analyzed |
| Public repository | Determine allowed versions/branches and whether deployed services are separately in scope |
| Company-owned cloud tenant | Verify tenant/resource identities; a provider's entire service is not included |

DNS resolution and certificates help identify architecture. They do not grant infrastructure-wide permission. A redirect into an external identity provider may be ordinary product behavior; it is still a new destination for active testing. Credentials and active test inputs must not follow an uncontrolled redirect.

## AI and confidentiality intake

Ask what data the selected runtime sends to its model provider, enabled tools, browser, MCP services and telemetry. Read the program's AI terms rather than assuming public participation permits all processing. If required data handling cannot be met, continue with public theory and request a permitted environment. Do not summarize private findings into a third-party search query as a workaround.

The pack's optional role definitions do not imply permission to use external agents or contractors. A single agent can perform all perspectives sequentially. Approved parallel work uses the same total traffic and data limits.

## Establish a workable experiment budget

There is no universal safe scanning rate. Derive limits from the specific policy and the proposed experiment, then obtain the needed user execution permission. Include background browser activity, retries, redirects, tool discovery requests and worker traffic in the estimate. An upper bound is a ceiling, not a target.

If a tool cannot constrain scope, redirects, request count or concurrency adequately, redesign the task or select a simpler manual procedure. Do not approve an opaque tool and hope prompt text restrains it. Document which controls are technical and which depend on operator behavior.

## Intake exit criteria

The case may reach `PLAN_READY` when the policy is current, the asset/method interpretation is supported, eligibility and AI/data rules are resolved for the planned work, controlled identities are available when needed, and a concrete reversible experiment is reviewable. This does not make the batch executable. It becomes executable only when the independent program and user gates are satisfied.

Deliver a shortlist or intake memo, scope ledger, unanswered questions, normal-product learning plan and next experiment proposal. Use the [program-shortlist template](../templates/program-shortlist.md). Record a policy change as an event; pause affected execution and preserve useful independent work.
