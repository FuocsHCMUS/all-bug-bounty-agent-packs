# Model the application before choosing a test

Use [application-model.md](../templates/application-model.md), [threat-model.md](../templates/threat-model.md) and the relevant [playbook](../playbooks/README.md). This is a scoped research model, not a claim to know the company's internal architecture.

## Begin with normal work

Describe one ordinary task as a beginner would: a user creates a private project, invites a colleague, uploads a synthetic document, previews it, exports it, removes the colleague, and deletes the project. Identify which steps are known from documentation and which were observed in approved activity. Do not turn guessed endpoints into an asset inventory.

Represent the basic path:

```text
user/browser -> public edge -> application/API -> authorization decision
             -> database/object store -> background processor -> export/result
```

This diagram is a starting hypothesis. Some applications omit layers or combine them. Label unknown components. Infrastructure complexity is not itself evidence of a weakness.

## Actors, authority and objects

An actor is a user, service, administrator or external integration that performs an action. A role is a collection of permissions in a context. An object is a resource such as a project, file or invoice. A tenant is an organization's boundary in a shared service. A capability is authority conveyed through a token or reference under explicit rules.

Build a matrix before testing:

| Actor/state | Own private object | Peer object | Other tenant | Derived export |
| --- | --- | --- | --- | --- |
| Owner | Expected allowed actions | Only documented shared actions | Expected deny | Authorized scope only |
| Member | Role-dependent | Role-dependent | Expected deny | Must inherit relevant restrictions |
| Removed member | Depends on documented revocation guarantee | Expected deny after that guarantee | Expected deny | Must examine lifetime semantics |
| Anonymous | Only intended public material | Only intended public material | No private access | Link/capability semantics matter |

These cells express questions, not a universal product specification. Some products intentionally support public links or delayed revocation. Establish the promise before calling behavior a bug. Use only owned accounts and synthetic objects for comparative evidence.

## Follow data and authority separately

For each step, record where data comes from, what it means, who controls it, which validation happens, where authority is checked, what persists, and who can observe the result. Data movement and permission movement are not identical. A job identifier may refer to work while an attached credential authorizes retrieval. A client-supplied tenant identifier is a claim the server must validate, not a trusted tenant boundary.

Inspect derived representations: search result, notification, thumbnail, preview, export, audit event, downloaded file, cached response and background job result. Ask whether the original object's restriction survives every transformation. A private source object does not imply every representation is private; equally, a public derivative may be intentional. Record the evidence for the intended relationship.

## Describe trust boundaries precisely

Useful boundaries include anonymous/authenticated, low/high privilege, one tenant/another, user input/interpreter, application/network, file name/filesystem, retrieved document/AI instructions, and queued work/current authorization. A boundary failure explains why an otherwise valid operation becomes unsafe in a new context.

For each boundary write: **producer -> representation -> consumer -> trusted assumption -> required check**. For example, browser -> object identifier -> export service -> requester owns object -> verify subject/action/object/tenant before generating the export. This structure yields more precise hypotheses than a generic list of vulnerability names.

## State machines expose time-dependent assumptions

List states such as draft, active, shared, revoked, expired and deleted. List valid transitions, actor permissions, side effects and documented timing. Ask when the security decision occurs: request time, queue insertion, job execution, result retrieval, or every stage.

Example paper model:

```text
private -> shared-with-B -> membership-revoked -> export-link-expired
```

If membership and export-link revocation are separate by design, the model must reflect that. A result observed between two transitions does not prove a permanent bypass. Account for clocks, caches, eventual consistency and stale clients before concluding.

## Threat hypotheses from business meaning

Identify what must remain true: only an authorized owner changes a billing destination; a completed operation is not applied twice; a revoked identity cannot access data beyond the promised lifetime; a search result reveals no more than the source policy permits. Specify the protected asset and credible consequence. A surprising UI state without a security consequence may be an ordinary bug.

Ask what an attacker would need: identity, role, knowledge of an identifier, user interaction, timing, configuration, a prior vulnerability or an unusual deployment. These are prerequisites to record, not permissions to obtain them through attacks. Preserve a conditional chain on paper when safe validation is unavailable.

## Source-assisted and black-box evidence

User-authorized source may show an omitted check, a relevant helper and its callers. Trace enough context to identify the actual entry point, policy and sink. A suspicious function alone may be unused. Conversely, a correct helper does not establish that every route calls it. Compare tests and deployment versions when known.

Black-box evidence can show a behavior without proving the exact internal implementation. Write “consistent with missing authorization at the export boundary” if the internal cause is inferred. Do not invent database queries, microservices or framework internals to make an explanation sound complete.

## Outputs and teaching

Deliver a normal-flow narrative, actor/action/object matrix, data-flow sketch, state table, boundary inventory, open assumptions and small hypothesis queue. Mark each statement `DOCUMENTED`, `OBSERVED`, `INFERRED` or `UNKNOWN`. Explain one full path to the student before listing advanced variants.

Ask: where is the server deciding authority? Which facts would distinguish an ownership failure from intended sharing? Which derivative needs its own check? If the student cannot locate the trust decision, return to the normal flow instead of adding payloads.
