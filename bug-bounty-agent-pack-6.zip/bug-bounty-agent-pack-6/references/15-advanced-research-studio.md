# Advanced research studio

Read after [creative research](05-creative-research.md) and [application modeling](14-application-model-and-threat-boundaries.md). This studio helps invent better questions. It is not a payload catalog or permission to execute increasingly invasive techniques.

## Write a useful research question

Use this contract:

> Under documented state S, controlled actor A should not perform action X on object O. Evidence E suggests that representation or transition R may lose this rule. If the hypothesis is correct, a minimal approved experiment should reveal synthetic marker M or a reversible state difference. Control C should remain unchanged. Observation F would reject the hypothesis.

Make every letter concrete in a real worksheet. A hypothesis with no rejection condition tends to attract confirmation bias. A claim that “some advanced bypass probably exists” is too vague to guide useful work.

## Research lenses with worked paper examples

### 1. Derivation and inheritance

Question: does a security property survive a transformation? A private document can become a thumbnail, PDF export, search snippet or notification. On paper, map original policy to each derived representation, who creates it, where it is stored and how access is checked. An approved experiment would use owned synthetic content and compare the allowed and forbidden identities on one relevant derivative.

Competing explanations include intended public sharing, cached authorized data, a privileged test identity or a fixture containing the same marker. The claim must survive those alternatives. If the document and preview are protected but export is not, record both the successful controls and the observed exception.

### 2. Revocation and temporal consistency

Question: what remains authoritative after a transition? Model membership removal, session logout, key rotation, link expiry and job cancellation independently. Determine the product's documented revocation point. A token accepted before that point is not evidence it survives afterward.

Prefer an approved staging or controlled-account timeline with exact timestamps. Avoid repeatedly hammering endpoints while waiting for expiry. Distinguish a bounded cache delay from a persistent policy failure. Explain whether the proposed fix is invalidating a capability, shortening its lifetime or checking current authority at use time.

### 3. Representation and canonicalization

Question: do two components interpret one input differently? Model parsing, normalization, validation, lookup and rendering as separate stages. Use harmless local strings and standards review to find inconsistent assumptions. The interesting property is whether the checked value is the same value later used for a security-sensitive decision.

Do not transfer parser/desynchronization experiments to shared production infrastructure. Such classes can affect other users or availability. Source review, local model comparisons and owner-provided staging are appropriate first routes. A parser difference without a crossed security boundary is an observation, not a vulnerability.

### 4. Work queued under old authority

Question: which identity authorizes an asynchronous job? Compare enqueue time, processing time and result access. A worker may legitimately use a service identity while still needing to preserve the original user's authorized scope. Record the expected policy at each stage.

A paper experiment can explore whether an export queued before removal should finish and who may retrieve it afterward. Product semantics decide the expected result. Avoid creating expensive jobs or large exports to infer internal behavior.

### 5. Composition of ordinary capabilities

Question: can two individually permitted actions compose into an unintended result? Draw a graph of capabilities and explicit prerequisites. Label nodes `OBSERVED`, `LAB_ONLY` or `HYPOTHETICAL`. Include which actor controls each object and whether the next edge crosses scope or affects another party.

A plausible chain can justify internal owner review without executing its harmful edge. The report should separate the observed primitive from conditional downstream impact. Never turn “could combine with another unknown flaw” into confirmed takeover.

### 6. Patch neighborhoods and variant analysis

Question: where else does the repaired invariant occur? From an authorized source patch, identify the root cause, callers, sibling flows, generated artifacts, alternate entry points and regressions. Look for the same assumption in context rather than string-matching an old vulnerable function name.

A neighboring route may have a different policy, fixed helper or unreachable code. Document those differences. Variant analysis is a hypothesis generator; a patch diff does not establish a new vulnerability automatically.

### 7. Metamorphic security properties

A metamorphic relation describes a transformation that should preserve a property. Changing a display name should not change an owner; formatting a permitted filter should not add tenant authority; exporting an object should not broaden its sharing scope; a documented idempotent retry should not duplicate an effect.

Check the semantics first. Not every API promises idempotency, and some “copies” intentionally create new ownership. Model the normal output and an invariant, then design one factor change and an appropriate control. For write operations, use synthetic staging data and explicit permission.

### 8. Error paths and partial failure

Question: do failures preserve the same guarantees as success? A timeout, cancellation or retry can leave state partially changed. Reason about transaction boundaries, compensation, visibility and duplicate work. Start with documentation and local models. Avoid inducing production failures, exhausting resources or triggering real charges.

An internal remediation suggestion may include atomic state transitions, durable idempotency records, constrained compensation and authorization on result retrieval. State which are hypotheses about the implementation.

## Design the smallest informative experiment

Choose a single variable, such as requester identity, ownership, state or representation. Establish a baseline that shows the product works. Include a forbidden comparison and a negative control that rules out the main alternative explanation. Choose a synthetic marker that cannot appear accidentally in ordinary content.

Record expected secure behavior, suspected failure behavior, what would falsify the idea, request/time/data cost, side effects, cleanup and stop rule. If the only proof requires reading someone else's data, code execution on production or a third-party pivot, preserve the hypothesis and ask for owner-assisted validation instead.

## Rank without false precision

Use a qualitative comparison of supporting evidence, business consequence, reachable prerequisites, novelty relative to known issues, experiment cost, learning value and operational risk. Do not multiply arbitrary scores and call the output scientific. High hypothetical impact does not offset unacceptable test risk. Favor a question that can resolve multiple assumptions with a few controlled observations.

Use timeboxed reasoning: define what additional reading would change the decision, then stop when the necessary fact is unavailable. Record rejected paths so future sessions do not rediscover them. A cleanly rejected idea is useful research.

## Novelty and ethics of interpretation

Say “new to this investigation” unless published-source comparison supports a stronger novelty claim. Do not claim a zero-day from a novel payload shape or absence from a quick search. A program-specific logic flaw can be valuable without a CVE or elaborate exploit.

Creativity belongs in modeling, experiments and repairs. It does not authorize stealth, identity rotation to evade limits, data collection to prove scale, persistence, security-tool disabling or out-of-scope infrastructure. A control that works is a result worth explaining.

## Deliverables

Produce a small [hypothesis queue](../templates/hypothesis.md), [threat model](../templates/threat-model.md), [experiment design](../templates/experiment-design.md), and a research journal entry. Explain the selected idea from its simplest prerequisite; include the best competing explanation and why this experiment distinguishes them. Load the [research-studio prompt](../prompts/16-advanced-research-studio.md) when a dedicated session is useful.
