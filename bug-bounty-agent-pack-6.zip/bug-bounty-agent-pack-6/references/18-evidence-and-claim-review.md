# Evidence and claim review

Use with [validation](06-validation-and-evidence.md), [reporting](07-reporting-and-triage.md), [claim matrix](../templates/claim-evidence-matrix.md) and [skeptical review prompt](../prompts/08-skeptical-review.md).

## A claim is an assertion, not a file attachment

A screenshot may show a surprising screen; a request capture may show bytes. Neither automatically explains who was authenticated, who owned the resource, whether it was private, or which action caused the result. State the claim first, then identify the minimum artifacts that support it.

Useful claim ladder:

1. **Observation:** this recorded response contained synthetic marker M.
2. **Context:** the request used controlled account B; M was stored in account A's documented private object.
3. **Boundary failure:** B obtained protected content despite the established expected deny.
4. **Demonstrated impact:** confidentiality failed for this tested object/path.
5. **Conditional impact:** more objects or a wider workflow could be affected if additional assumptions hold.

Do not skip directly from an HTTP status to a company-wide breach claim. Every increase in claim breadth needs evidence. Lack of customer-scale exploitation is appropriate, not a weakness to fix by collecting more data.

## Evidence record

Record timestamps with timezone, case/batch ID, policy source, tool/version, code revision or manual procedure, controlled identity labels, object ownership, intended state, sanitized input/output, result, negative control and cleanup. Capture enough surrounding context for independent review without retaining unnecessary secrets.

Separate raw private artifacts from redacted report copies. Redaction should remove secrets while preserving claim-relevant identity/ownership labels. Do not replace response content with invented “cleaner” evidence. If a screenshot is annotated, keep the original private file and describe the annotation. A digest detects changes to a file; it does not prove the file's provenance or the claim's truth.

## Competing explanations checklist

- Was the object intentionally public or accessible through an authorized share link?
- Was the requester still an owner, administrator or member through another membership?
- Were the two account sessions actually isolated?
- Did a browser cache or local test fixture produce the visible content?
- Did the endpoint return an application error inside a nominally successful status?
- Did the response contain only an identifier or harmless metadata rather than protected data?
- Was a documented grace period or eventual-consistency condition still in effect?
- Was the behavior from a lab, mock, outdated deployment or a different host?
- Does policy exclude the observation, or is the intended security promise still unclear?

Choose controls that answer the leading alternatives. Do not run every control by habit; each target action still spends the approved budget and must fit the batch. If evidence is already sufficient, stop adding proof.

## Reproducibility without overcollection

Write steps a reviewer can follow with their own authorized accounts. Use stable labels instead of live credentials. Include the normal baseline, one forbidden comparison and the interpretation. If repetition is needed to exclude noise, bound it in the plan; do not repeatedly trigger side effects or costs.

Timing and race hypotheses require particular care. A single inconsistent result can come from measurement error, stale data or nondeterminism. Prefer source analysis and staging. Never increase production concurrency simply to obtain a convincing screenshot.

## Claim-evidence matrix

For each major report sentence, record support, confidence, alternative explanation and status: `SUPPORTED`, `QUALIFIED`, `HYPOTHETICAL`, `UNSUPPORTED` or `NOT_ASSESSED`. Keep impact and internal root cause separate. Black-box proof can support a boundary failure while the exact internal function remains inferred.

Edit unsupported sentences before sharing the report. Move useful hypothetical consequences to a clearly conditional paragraph. Remove speculation that does not help a reviewer assess the actual issue. Distinguish a candidate awaiting proof from a confirmed issue awaiting submission.

## Severity review

Tie proposed severity to the actor's real starting privilege, required interactions, protected asset, demonstrated action, environmental constraints and credible consequence. Do not inherit an alarming CVE score for a different deployment. Use the program's convention and explain uncertain metrics. Bounty value and technical severity are not interchangeable.

## Report-readiness decision

`READY_FOR_USER_REVIEW` means the report is privately drafted, its claim is supported and scoped, evidence is redacted, limitations are visible, cleanup is documented and the submission destination is identified. It does not mean an agent may send it. The default user submits personally. A later direct instruction may authorize sending the concrete report; record it and avoid redundant permission requests for the same approved action.

If a strong concern remains unconfirmed, prepare a candidate memo with the exact missing fact and suggested owner-assisted check. Do not present it as a proved exploit. If no issue remains, close with negative results, coverage limits and lessons. Honest null results protect future research quality.

## Retest and closure

Retesting requires current scope and applicable execution permission. Compare the original minimal proof and its controls on the intended fixed build. A denial response alone may mask a different data leak; examine the security property. A changed response proves only the tested path's behavior.

Record fixed, partially fixed, not reproduced or inconclusive with reasons. Retain only agreed evidence, stop local processes, document residual artifacts and save the handoff. Do not erase audit traces or production data to conceal the investigation.
