# Scripts are prepared only when useful

This pack ships no executable scripts. Its workflows, templates and paper exercises need no package installation or script execution.

If a later investigation would benefit from a helper, first explain its purpose, inputs, outputs, data sensitivity, network behavior, filesystem scope and alternatives. Write reviewable code inside this workspace. Prefer Python's standard library and Python 3.14-compatible APIs; prepare needed trusted dependencies in a local virtual environment under the permission already granted.

Present the exact code/command, version or hash, tests, expected side effects and cleanup before asking to execute it. A direct user instruction approving that concrete operation counts; do not ask twice. Permission to download code or install dependencies is not permission to execute the resulting testing script. Use [script review](../templates/script-review.md) and [execution approval](../templates/execution-approval.md).
