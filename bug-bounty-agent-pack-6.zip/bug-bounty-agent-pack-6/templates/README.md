# Case templates

Copy only templates needed for the active case. Fields in square brackets are intentional user-fillable fields, not claims of completed work. JSON uses empty arrays and null values so incomplete authorization is explicit.

| File | Purpose |
| --- | --- |
| [engagement.json](engagement.json) | Machine-readable draft and execution summary |
| [scope-ledger.md](scope-ledger.md) | Asset/method scope evidence and exclusions |
| [execution-approval.md](execution-approval.md) | Exact reviewable operation and human decision |
| [hypothesis.md](hypothesis.md) | Falsifiable research idea |
| [source-card.md](source-card.md) | Writeup/advisory/paper learning record |
| [cve-applicability.md](cve-applicability.md) | Build/configuration/path-specific CVE assessment |
| [evidence-index.md](evidence-index.md) | Private evidence provenance and redaction map |
| [finding-report.md](finding-report.md) | Focused private vulnerability report |
| [control-observations.md](control-observations.md) | Scoped positive/negative/unknown control analysis |
| [lesson-card.md](lesson-card.md) | Beginner concept and learning record |
| [session-handoff.md](session-handoff.md) | State, approvals, budgets, and next action |
| [tool-acquisition.md](tool-acquisition.md) | Portable download or dependency provenance |
| [retest.md](retest.md) | Fix verification with limited coverage |
| [program-shortlist.md](program-shortlist.md) | Current public-program comparison and intake recommendation |
| [application-model.md](application-model.md) | Normal tasks, roles, data flow, derivatives and states |
| [threat-model.md](threat-model.md) | Assets, trust assumptions and conditional paths |
| [experiment-design.md](experiment-design.md) | One-variable experiment, controls, limits and rejection |
| [writeup-translation.md](writeup-translation.md) | Distill a source into prerequisites and transferable reasoning |
| [claim-evidence-matrix.md](claim-evidence-matrix.md) | Review each important report claim |
| [coverage-matrix.md](coverage-matrix.md) | Actual coverage, negative results and gaps |
| [research-journal.md](research-journal.md) | Dated facts, interpretations, decisions and learning |
| [control-assessment-matrix.md](control-assessment-matrix.md) | Scoped strengths, weaknesses, inferred risks and unknowns |
| [detection-design.md](detection-design.md) | Proposed telemetry, analytic and synthetic evaluation |
| [script-review.md](script-review.md) | Review executable behavior before requesting execution |
| [report-bundle-checklist.md](report-bundle-checklist.md) | Private report readiness and user delivery |

Do not check secrets into Git. A filled approval record must link to a real human decision; agents cannot authorize themselves by editing these files.

## Engagement JSON conventions

Create a case with ordinary file operations, copy the draft and fill its actual case_id. To record an asset, use an object with nonempty `type`, `value`, and `scope_evidence` strings, for example a fictional record `{"type":"hostname","value":"app.example.invalid","scope_evidence":"scope-ledger.md, policy section 2"}`. Apply the same format to exclusions. This is a record format, not automatic URL matching or scope enforcement.

Methods, account labels, and stop conditions are arrays of nonempty strings. Do not put credentials into account labels. Execution modes require positive request/rate/concurrency/duration/response limits, a nonnegative retry limit, an actual approval summarized by plan/record paths and timezone-bearing timestamps, and stop conditions. Live-testing additionally requires reviewed program details, eligibility/AI review flags, assets, methods, and controlled account labels.

The pack has no configuration validator or enforcement helper. Even a structurally complete live-testing file can be unauthorized, outdated or wrong. The agent must review actual policies, genuine user decisions, code revisions, timestamps, scope and runtime limits before action. Never infer permission from an edited flag.
