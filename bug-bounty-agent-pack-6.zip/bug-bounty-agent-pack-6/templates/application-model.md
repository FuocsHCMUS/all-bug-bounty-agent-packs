# Application model

Case: [ID]. Version/time/environment: [known facts]. Sources: [links or authorized artifact IDs].

## Normal task

[Describe an ordinary user goal and the normal steps before discussing an exploit.]

## Actors and assets

| Actor / controlled identity label | Role / tenant / state | Intended actions | Protected objects | Evidence |
| --- | --- | --- | --- | --- |
| [label; no credentials] | [facts] | [documented policy] | [synthetic objects] | [source] |

## Data flow and authority

| Step | Producer -> consumer | Data / representation | Authority claim | Required check | DOCUMENTED / OBSERVED / INFERRED / UNKNOWN |
| --- | --- | --- | --- | --- | --- |
| [step] | [boundary] | [field/artifact] | [who says what] | [policy] | [evidence/confidence] |

## Lifecycle

| State / transition | Who may act | Expected security guarantee | Timing / side effects | Unresolved assumptions |
| --- | --- | --- | --- | --- |
| [state] | [actor] | [invariant] | [known behavior] | [questions] |

## Derived representations

[Preview, export, search, notification, cache or background result; expected policy inheritance and evidence.]

## Research queue

[Link a small set of hypotheses with competing explanations. Name the next useful fact to resolve. This model does not authorize experiments.]
