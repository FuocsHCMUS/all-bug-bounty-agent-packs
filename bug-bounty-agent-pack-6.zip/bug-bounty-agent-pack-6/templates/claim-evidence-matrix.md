# Claim-to-evidence review

Case / finding / reviewer perspective / date: [record].

| Report claim | Evidence IDs and context | Best alternative explanation | Confidence and limits | SUPPORTED / QUALIFIED / HYPOTHETICAL / UNSUPPORTED / NOT_ASSESSED | Edit or next fact |
| --- | --- | --- | --- | --- | --- |
| [one important assertion] | [artifact + identity/ownership/time] | [plausible alternative] | [reasoned assessment] | [state] | [specific action] |

## Report verdict

[READY_FOR_USER_REVIEW / CANDIDATE_NEEDS_EVIDENCE / REJECTED / INCONCLUSIVE]. State which security property is demonstrated, which impact is conditional, and which internal cause remains inferred.

## Remaining obligations

[Redaction, cleanup, severity review, current policy, report destination and user review. Report readiness does not imply submission authority.]
