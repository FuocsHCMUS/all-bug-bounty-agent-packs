# Observed control assessment

Case, sampled environment, date, identities and methods: [record]. This memo concerns observed behavior, not a company-wide audit.

| Domain / control | Intended protection | Observation and evidence | OBSERVED_EFFECTIVE / OBSERVED_WEAKNESS / INFERRED_RISK / NOT_ASSESSED | Confidence / sample limits | Root-cause fix or next check | Suggested telemetry |
| --- | --- | --- | --- | --- | --- | --- |
| [control] | [asset/invariant] | [specific result] | [label] | [limits] | [practical action] | [owner-visible fields; proposed if unknown] |

Consider identity, sessions, object/function/property authorization, tenant isolation, data minimization, files/derivatives, interpreter boundaries, dependency exposure, browser/transport controls, workflow integrity, abuse limits, logging and disclosure process. Fill only supported rows; mark the rest NOT_ASSESSED.

## Risk explanation

[Likelihood assumptions, demonstrated consequence, exposure, successful controls, uncertainty and conditional concerns. Distinguish “high concern if X is true” from confirmed high impact.]

## Beginner explanation

[Explain what the control does, where the check belongs, how the observation supports the conclusion, what a repair changes and what a defender could inspect.]
