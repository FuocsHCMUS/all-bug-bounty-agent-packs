# Investigation coverage

Case / time window / actual methods: [record]. A tested sample is not exhaustive assurance.

| Asset / route / representation | Identity / role / tenant / state | Question / expected invariant | Source or batch | NOT_TESTED / OBSERVED / NO_ISSUE_IN_SAMPLE / CANDIDATE / CONFIRMED / INCONCLUSIVE | Evidence | Limits / next useful fact |
| --- | --- | --- | --- | --- | --- | --- |
| [specific item] | [controlled labels] | [question] | [record] | [state] | [IDs] | [limits] |

## Known gaps

[Unvisited paths, unavailable roles, unknown builds, restricted methods and owner-assisted questions. Do not claim “no vulnerabilities” from finite coverage.]

## Avoid duplicate work

[Prior rejected hypotheses, already consumed budget, tests that should not be repeated, approvals still valid and changes that require review.]
