# Proposed defensive analytic

Finding / invariant / environment: [record]. Status: PROPOSED_UNVALIDATED unless an authorized dataset evaluation is recorded.

## Signal and data contract

- Normal behavior and suspicious deviation: [plain language].
- Required event sources: [application/auth/queue/storage/etc.].
- Required fields: [timestamp/timezone, request ID, subject/role/tenant, resource owner/type, action, decision and outcome].
- Fields to exclude or pseudonymize: [tokens, passwords, sensitive content and unnecessary identifiers].
- Collection/visibility gaps: [unknowns].

## Analytic

[Pseudocode or query with an explicit schema mapping, time-window assumptions and tuning variables. Label invented fields. No claim this company collects or detects the signal.]

## Evaluation

[Synthetic positive case, ordinary negative case, administrator/shared-object edge cases, replay/stale-client noise, expected alerts and false-positive review. Include approved evaluation evidence if actually run.]

## Triage and response

[How an analyst verifies identity/ownership/context, minimizes further access, routes the issue, contains exposure and checks recovery. Root-cause repair remains necessary.]
