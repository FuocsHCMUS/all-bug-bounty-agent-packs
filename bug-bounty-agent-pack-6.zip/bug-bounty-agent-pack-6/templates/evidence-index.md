# Private evidence index

- Case/finding: [id]
- Handling/retention requirements: [rules]
- Raw originals and redacted-copy locations: [paths]
- Redaction reviewer/date: [record]

| ID | Acquisition time/offset | Actor/account label | Action and approval | Relative file | SHA-256 | What it proves | Limits/redactions |
| --- | --- | --- | --- | --- | --- | --- | --- |
| [E-01] | [time] | [owned identity] | [plan/step] | [path] | [hash] | [claim] | [limits] |

## Reproduction context

Record tool/version/hash, environment/build, session separation, object ownership, request/response pairing, negative controls, and cleanup. Do not store raw tokens in this index. A hash detects content changes; it does not establish truth or provenance by itself.
