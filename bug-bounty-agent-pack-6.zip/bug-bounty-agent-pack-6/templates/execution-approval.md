# Execution plan and approval record

## Reviewable operation

- Case/plan/batch ID: [id]
- Purpose and hypothesis: [bounded question]
- Program permission evidence and current review time: [source]
- Exact hosts, ports, paths, tenants, accounts, and destinations: [allowlist]
- Explicit exclusions: [list]
- Tool/version/source or script SHA-256: [identity]
- Exact commands/manual actions, working directory, inputs: [reviewed content]
- Network activity, callbacks, redirects, retries, and background traffic: [behavior]
- Data read/written, synthetic markers, side effects: [details]
- Total request budget, per-host rate, concurrency, duration, retry budget: [values]
- Maximum response/data retention budget: [values]
- Secure expected result, candidate failure, negative control: [decision rule]
- Stop conditions: [case-specific signals]
- Cleanup and rollback: [steps and ownership]
- Alternatives if not approved: [useful research]

## Human decision

- Exact approval/denial text or trusted transcript reference: [record]
- Human and time with timezone: [record]
- Approved subset and expiry: [bounds]
- Changes requiring new approval: [code, targets, method, data recipient, cost, risk]

No approval is assumed from an empty field, silence, or an agent-written flag. Approval of this plan does not override program restrictions.

## Execution accounting

| Time | Action | Requests/budget | Observation | Evidence | Stop/continue rationale |
| --- | --- | --- | --- | --- | --- |
| [time] | [actual step] | [count] | [fact] | [path] | [decision] |
