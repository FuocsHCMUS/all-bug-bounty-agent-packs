# Minimal experiment design

Experiment ID / hypothesis / case: [record]. State: [DRAFT / PLAN_READY / APPROVED_BOUNDED / EXECUTED / STOPPED]. An experiment label is not approval.

- Security invariant and source: [expected guarantee].
- Preconditions: [product/build/feature, identity/role, ownership, state, knowledge].
- Supporting facts: [evidence IDs].
- Best competing explanation: [alternative].
- One variable to change: [identity, state, representation or other factor].
- Secure expected observation: [specific result].
- Suspected failure observation: [synthetic marker or reversible effect].
- Negative control: [why it distinguishes the alternative].
- Falsifying observation: [what would reject the idea].

## Procedure and limits

[Exact reviewed commands/code or manual actions, target/destination checks, redirects, identities, synthetic objects, requests, rate, concurrency, duration, retries, response/data budget and expiry. Include background traffic where relevant.]

## Effects and recovery

[Writes, jobs, emails, network callbacks, costs, ports, files, cleanup and restoration. If unavailable, say so. Prefer a lower-risk alternative.]

## Authority

- Program permission record: [policy + method/asset evidence].
- User execution approval record: [actual text/time and plan reference, or PENDING].
- Abort conditions: [specific signals plus canonical defaults].

## Outcome

[Actual observations, controls, budget consumed, artifacts, cleanup, claim supported and limitations. Leave as unexecuted until real evidence exists.]
