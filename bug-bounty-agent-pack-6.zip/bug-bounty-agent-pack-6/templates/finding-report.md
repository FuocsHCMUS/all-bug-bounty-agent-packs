# [Actor] can [forbidden action] on [protected resource] through [specific path]

## Summary

[Concrete observed boundary failure and demonstrated consequence.]

## Scope and prerequisites

- In-scope asset and policy reference: [source]
- Build/time/environment: [known facts]
- Required privilege, owned test accounts, and synthetic objects: [labels]
- Testing authorization and limits: [record]

## Intended security property

[Who should be allowed to do what, under which state and tenancy.]

## Minimal reproduction

1. [Establish legitimate baseline using controlled data.]
2. [Perform the single approved forbidden comparison.]
3. [Observe the protected synthetic marker or allowed state effect.]
4. [Show negative control and cleanup where relevant.]

## Expected and actual results

- Expected: [policy behavior]
- Actual: [observed content/state, not just status]
- Sanitized request/response and evidence IDs: [minimal proof]

## Impact and severity rationale

- Demonstrated impact: [evidence-backed]
- Conditional downstream impact and prerequisites: [clearly labeled]
- Proposed program severity and rationale: [bounded]
- CVSS version/vector only if calculated and checked: [optional]

## Limitations

[Sample coverage, unavailable proof, uncertainty, untested paths.]

## Remediation and regression idea

[Repair the invariant at the relevant server/component boundary. Add allowed/forbidden tests and applicable state transitions.]

## Cleanup and private attachments

[Created artifacts, removal status, redacted attachment list.]

This is a private draft for user review. Do not submit, publish, or contact anyone without explicit instructions.
