# Public program shortlist

Research date/time and timezone: [record]. Student's present skills/time: [record]. Sources are public unless explicitly marked otherwise.

| Program and official URL | Status / eligibility evidence | Exact scope summary | AI / automation / data rules | Controlled-account feasibility | Learning fit / risk | Unknowns |
| --- | --- | --- | --- | --- | --- | --- |
| [candidate] | [source + date] | [assets and exclusions] | [source or unresolved] | [requirements] | [reasoned comparison] | [missing fact + next step] |

## Recommendation

[Choose one with reasons grounded in policy clarity, learning value, feasible evidence and operational risk. Do not promise access, reward or findings. If none is suitable, recommend a learning-only task.]

## Intake next steps

[Policy verification, user-handled account actions if needed, exact scope record, normal-product model and proposed first question. No active testing is approved by this shortlist.]
