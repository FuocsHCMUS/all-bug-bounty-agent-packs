# Private report bundle

Finding/case and intended program destination: [record]. Status: [DRAFT / READY_FOR_USER_REVIEW / CANDIDATE / CLOSED].

- [ ] Scope, policy date, environment and controlled-account prerequisites are identified.
- [ ] Report title states actor, forbidden action, protected resource and path.
- [ ] Expected invariant is supported by product semantics.
- [ ] Minimal reproduction includes legitimate baseline, forbidden comparison and meaningful control.
- [ ] Actual output proves the stated consequence; status codes alone are not proof.
- [ ] Claim matrix separates supported impact, inferred cause and conditional chain.
- [ ] Severity rationale matches the demonstrated prerequisites and program convention.
- [ ] Evidence IDs resolve to private originals and redacted reporting copies.
- [ ] No credentials, unrelated personal data, private program leaks or unneeded customer content appear in shareable copies.
- [ ] Remediation repairs the invariant; regression idea and optional telemetry are specific.
- [ ] Cleanup, retention, residual artifacts and untested coverage are stated.
- [ ] Control observations and a beginner lesson are included as local companion notes.
- [ ] Submission authority is explicit; default delivery is a private draft for the user.

## Files for user review

[Report, sanitized attachments/evidence index, control memo, lesson, retest plan and handoff. Distinguish which files belong in an external submission from private working notes.]

## Final summary

[Confirmed claim, uncertainty, what was actually tested, cleanup and next action. If nothing is confirmed, say so.]
