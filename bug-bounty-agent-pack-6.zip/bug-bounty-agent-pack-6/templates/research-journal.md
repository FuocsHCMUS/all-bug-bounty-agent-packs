# Research journal

Case: [ID]. Entries use timestamps with timezone. Keep facts, interpretations and next decisions separate.

## Entry [time / topic]

- Question and why it matters: [record].
- Source or approved batch: [record].
- Actual observation: [artifact/source evidence; no invented requests].
- Interpretation and confidence: [what follows and what does not].
- Competing explanation / falsification: [record].
- Decision: [continue reading / prepare experiment / reject / candidate / stop].
- Permission and spent budget: [applicable records; zero if no target activity].
- Cleanup / data concerns: [record].
- Lesson and next useful fact: [record].

Rejected ideas belong here too. Do not silently delete them and rediscover them next session. Preserve confidential source restrictions when reusing lessons elsewhere.
