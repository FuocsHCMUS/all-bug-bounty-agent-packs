# Fix retest

- Original finding/report and accepted behavior: [IDs]
- Current program policy and retest authorization: [records]
- Fixed build/commit/configuration evidence: [facts]
- Approved bounded plan and identities: [record]
- Legitimate baseline results: [evidence]
- Original forbidden action result: [evidence]
- Explicit adjacent paths tested: [coverage]
- Untested paths and uncertainty: [limits]
- Request/time budget spent: [counts]
- Cleanup: [status]
- Conclusion: [FIX_VERIFIED_FOR_TESTED_PATHS/STILL_REPRODUCIBLE/INCONCLUSIVE]
- Proposed triage reply for user review: [draft]
