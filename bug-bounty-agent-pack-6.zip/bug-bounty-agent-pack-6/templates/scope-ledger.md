# Scope ledger

- Case ID: [case]
- Official program/policy URL: [source]
- Reviewed at, with timezone: [time]
- Policy snapshot/hash and retention constraints: [record]
- Eligibility and account requirements: [facts or unknown]
- AI/automation/confidentiality rules: [facts and source]
- Policy conflicts/ambiguities: [questions; dependent actions paused]

| Asset/type | Exact host/path/port or identifier | Inclusion evidence | Exclusions | Third-party/tenant notes | Permitted methods | Status |
| --- | --- | --- | --- | --- | --- | --- |
| [asset] | [value] | [policy section] | [limits] | [ownership] | [methods] | [research-only/cleared/unclear] |

## URL and boundary review

Record wildcard semantics, apex/nesting, IDN/punycode, redirect origins, CNAME/shared infrastructure, path restrictions, and credentials that must never cross origins. Do not infer IP-wide permission from a hostname.

## Changes

| Time | Policy change | Affected plans/approvals | Action |
| --- | --- | --- | --- |
| [time] | [change] | [ids] | [pause/review] |
