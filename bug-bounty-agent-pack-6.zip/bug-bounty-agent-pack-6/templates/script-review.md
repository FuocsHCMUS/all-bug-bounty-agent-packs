# Script or tool execution review

Case / operation / intended question: [record]. Prepared file or artifact: [workspace path]. Revision/hash: [actual value when available].

## Inspect before requesting execution

- Origin, license, version/commit and provenance: [record].
- Inputs and trust level: [record].
- Imports/dependencies and Python 3.14 compatibility: [record].
- Subprocesses, dynamic code, install/build hooks and hidden defaults: [record].
- Network destinations, redirects, callbacks, DNS and credential handling: [record].
- File reads/writes, archive paths, ports, processes and persistence: [record].
- Scope, count, retry, concurrency and response-size enforcement: [record].
- Sensitive output, logs, retention and redaction: [record].
- Tests or dry-run capabilities and their limits: [record].
- Cleanup and failure behavior: [record].

## Concrete requested batch

[Exact command/manual action, code revision, target/method, identities, budgets, expiry, effects, expected result, negative control and stop conditions. Link execution-approval.md.]

## Permission interpretation

[Which parts are already authorized, which need a new answer, and why. Portable acquisition and necessary trusted local pip dependencies are preauthorized preparation; script/tool execution and system/integration changes are separate. A direct human approval of this exact prepared operation should not trigger another identical approval request.]
