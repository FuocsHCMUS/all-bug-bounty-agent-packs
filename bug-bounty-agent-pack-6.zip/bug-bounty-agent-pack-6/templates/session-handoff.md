# Session handoff

- Case ID, date/timezone, current mode and state: [values]
- Current policy URL/review time/snapshot: [record]
- Scope and exclusions: [summary and ledger path]
- AI/confidentiality constraints: [rules]
- Human approvals, plan/hash, expiry, and source: [records]
- Budget spent/remaining and reset semantics: [actual counts]
- Commands/actions actually completed: [facts]
- Active processes, ports, unfinished jobs: [state or none]
- Confirmed findings and evidence paths: [IDs]
- Candidate/rejected/inconclusive hypotheses and why: [queue]
- CVE/source cards and unresolved facts: [paths]
- Private report drafts: [paths]
- Cleanup/retention obligations: [status]
- Lessons and concepts needing review: [notes]
- Pending user decisions: [specific missing authority/info]
- Next useful action and files to read: [one concrete step]

On resume, revalidate current policy and real approval records before execution. Do not repeat completed target work just to rebuild context.
