# Scoped research threat model

Case, date and scope: [record]. Modeling basis: [documentation / authorized source / approved observations].

## Protected assets and promises

[Confidentiality, integrity, availability or authority that matters to the product. State the intended behavior and its source.]

## Actors and starting capabilities

[Anonymous, normal user, member, administrator, service, integration. Separate hypothetical attacker capability from actual controlled test identities.]

## Trust boundaries

| Producer | Representation | Consumer | Trusted assumption | Security check | Evidence / unknowns |
| --- | --- | --- | --- | --- | --- |
| [actor/component] | [data/authority] | [component] | [assumption] | [required behavior] | [source] |

## Hypothetical paths

| Path / invariant | Prerequisites | OBSERVED / LAB_ONLY / HYPOTHETICAL | Safe evidence route | Scope / operational concern |
| --- | --- | --- | --- | --- |
| [idea] | [conditions] | [status for each edge] | [source review, local model, controlled comparison] | [constraint] |

## Controls and limits

[Observed successful controls, known weaknesses, untested boundaries and model uncertainties. No whole-company maturity verdict.]

## Prioritized next question

[A falsifiable hypothesis, best alternative explanation and minimum useful observation. Link approval plan separately.]
