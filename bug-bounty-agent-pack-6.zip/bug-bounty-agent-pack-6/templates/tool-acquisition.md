# Tool/dependency record

- Task and why existing tools are insufficient: [need]
- Official origin, maintainer, license: [sources]
- Version/tag/commit and SHA-256: [identity]
- Expected compressed/extracted size: [budget]
- Exact workspace destination: [path]
- Acquisition command and time: [record]
- Dependencies, Python 3.14/Windows compatibility: [facts]
- Code/install hook/source build review: [result]
- Network/telemetry/callback/update behavior: [destinations]
- Credential/filesystem privileges required: [permissions]
- Execution approval reference: [pending or record]
- Proposed command and bounded purpose: [reviewable]
- Cleanup/rollback: [steps]

Portable acquisition and trusted local dependency setup do not approve running the tool or PoC. Adding an agent integration requires a separate approval.
