# Core rules

Read `AGENTS.md` first. It is the contract.

- Scope before packets.
- Hypothesis before test.
- Reproducer before report.
- Portable tools in `WORKSPACE/`, persistent installs need a yes.
- Python 3.14 on Windows 11, venv in `WORKSPACE/venv`.
- Learning note after every confirmed finding.
