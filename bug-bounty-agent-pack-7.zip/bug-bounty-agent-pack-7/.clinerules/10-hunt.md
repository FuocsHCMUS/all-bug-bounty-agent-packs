# Hunt loop

Follow `OPERATING_MODEL.md`. Gates are hard.

Use `CREATIVE_OFFENSIVE_THINKING.md` to generate divergence; use the falsification
protocol before believing any signal. Update `hypotheses.md` continuously.
