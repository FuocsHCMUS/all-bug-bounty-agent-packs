# API checklist

- [ ] schema or introspection obtained
- [ ] every operation listed with scope and object type
- [ ] BOLA matrix run on every id-taking operation
- [ ] mass assignment: read-only fields sent
- [ ] GraphQL aliases, depth, and field-level authz tested
- [ ] pagination and filter injection tested
- [ ] batch/bulk endpoints tested with mixed-ownership ids
- [ ] second API version checked
- [ ] error verbosity noted (stack traces, field suggestions)
- [ ] rate limits measured per operation
