# Pre-submit checklist

- [ ] title is asset + class + impact, no adjectives
- [ ] impact in the first two lines
- [ ] severity vector justified per non-obvious metric
- [ ] preconditions listed
- [ ] reproduction is numbered and copy-pasteable
- [ ] raw request block present (API bugs)
- [ ] evidence folder hashed and complete
- [ ] second cold run passed
- [ ] impact does not exceed what the reproducer shows
- [ ] fix is specific and systemic
- [ ] dup score computed and below threshold, or specialization added
- [ ] known-issue list re-checked
- [ ] no "potentially", "possibly", "might"
- [ ] learning note written
- [ ] posture entry updated
