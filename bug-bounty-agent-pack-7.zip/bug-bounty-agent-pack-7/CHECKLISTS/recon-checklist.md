# Recon checklist

- [ ] scope.md complete, in/out of scope both populated
- [ ] certificate transparency pulled
- [ ] DNS history and passive DNS pulled
- [ ] ASN and netblocks mapped
- [ ] Wayback and Common Crawl URLs harvested
- [ ] org repos, forks, and Actions listed
- [ ] mobile apps identified (APK/IPA)
- [ ] JS bundles fetched from every live host
- [ ] endpoints and feature flags extracted from bundles
- [ ] live hosts probed and screenshotted
- [ ] assets classified and ranked
- [ ] WORKSPACE/NOTES.md updated with tool provenance
- [ ] rate ceiling recorded in scope.md
