# Session close checklist

- [ ] hypotheses.md updated, statuses accurate
- [ ] evidence hashed, captures pruned
- [ ] open blockers written as capability requests
- [ ] learning notes written for confirmed findings
- [ ] posture.md updated
- [ ] skill ladder updated
- [ ] retro appended
- [ ] WORKSPACE/NOTES.md current
- [ ] next-session entry point named in one line
