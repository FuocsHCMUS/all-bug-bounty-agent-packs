# Triage-proof checklist

Would a triager ask a question? Then the report fails.

- [ ] can they reproduce with only what is written?
- [ ] is the account tier stated and obtainable?
- [ ] is every non-default config stated?
- [ ] is the victim account distinct from the attacker account?
- [ ] is the marker unambiguous?
- [ ] is the timing window stated for races?
- [ ] is the environment (region, plan, browser) stated?
- [ ] does the chain hold if a hop is slow?
- [ ] is the impact limited to what a single victim loses, or is the count justified?
- [ ] are assumptions explicit?
