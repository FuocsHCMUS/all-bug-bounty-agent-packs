# Web test checklist

- [ ] every flow walked once as intended, all requests captured
- [ ] authz question asked per request (who authorizes, what object, what state, what writes)
- [ ] three lenses cited per surface
- [ ] parameter semantics: add, remove, duplicate, reorder, retype
- [ ] route semantics: slash, case, extension, method swap, `..;/`
- [ ] content-type negotiation swapped
- [ ] hypotheses logged before each burst
- [ ] 403s retried with a different verb and a different token
- [ ] old API versions probed
- [ ] mobile UA and old client version probed
- [ ] dead hypotheses parked with revive-if
