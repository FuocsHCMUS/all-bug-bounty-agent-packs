# CLAUDE.md

Shim. The contract is `AGENTS.md`.

Read in order: `AGENTS.md` → `OPERATING_MODEL.md` → `TOOLING_POLICY.md` →
`SCOPE_AND_RULES.md` → `SKILLS/00-index.md`.

Resume an existing target from `STATE/targets/<slug>/hypotheses.md`.
