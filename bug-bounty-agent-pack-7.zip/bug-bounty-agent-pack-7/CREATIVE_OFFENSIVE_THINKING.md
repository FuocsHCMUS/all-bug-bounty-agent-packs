# CREATIVE_OFFENSIVE_THINKING.md — the anti-rulebook

Checklists find checklist bugs. These lenses find the rest. Apply at least three per
target and cite the lens id in the hypothesis ledger.

Rules of use:
- A lens is a question generator, not a conclusion.
- Combine two unrelated lenses to force novelty.
- After generating, run §Falsification before believing anything.

---

## A. Author-mind lenses

**A1 — The tired commit.** Find commits at 02:00, Fridays, and the day before a release.
Look at what they touched. The fix you are looking for is usually one commit after that.

**A2 — The happy path leak.** Re-read the feature description. Every assumption in it is
a boundary you can violate: single user, single tenant, single currency, single file,
single request.

**A3 — The unowned field.** Fields added by an integration team, a contractor, or an
acquired product. Nobody owns their validation.

**A4 — Copy-paste archaeology.** Grep for the same function across the repo. The one
instance where the guard was dropped is the bug.

**A5 — The feature flag nobody turned off.** Beta paths, legacy paths, `?debug=1`,
`X-Internal: true`, shadow APIs, `/v1` behind `/v2`.

**A6 — The docs lie.** Where docs and behavior disagree, behavior wins and the gap is
usually load-bearing. Test both readings.

## B. Trust lenses

**B1 — Boundary census.** Draw every boundary: browser↔edge, edge↔app, app↔queue,
app↔db, service↔service, tenant↔tenant, user↔admin. Rank by who authenticates whom.
The boundary with the weakest authenticator is the target.

**B2 — Confused deputy.** Where does a component act with more privilege than the caller?
Uploaders, importers, PDF renderers, webhook senders, backup agents, CI runners.

**B3 — Second-order effect.** Data you control that is later consumed by a different
component: filenames into a shell, CSV into Excel, Markdown into a renderer, JSON into a
template, a URL into a fetcher.

**B4 — Implicit trust in a header.** `X-Forwarded-For`, `X-Original-URL`,
`X-Rewrite-URL`, `Host`, `Referer`, `Origin`, `X-User-Id`, `X-Tenant`.

**B5 — The admin's convenience.** Impersonation, "view as", support tooling, god-mode
tokens, `/act-as/`, magic links.

## C. State lenses

**C1 — State machine inversion.** Enumerate legal transitions. Try the illegal ones:
skip, repeat, reverse, interleave, replay.

**C2 — TOCTOU.** Two requests between check and use: balance, coupon, invite seat,
username claim, file write, quota.

**C3 — Split state.** Multi-step flows where step 2 does not re-verify step 1's subject.
Email change, MFA enrollment, password reset, org invite.

**C4 — Orphan state.** Objects created then abandoned: draft, pending, unverified,
soft-deleted, archived. They usually skip validation and stay reachable.

**C5 — Idempotency keys.** Who supplies them, are they scoped per user, can they be
replayed across accounts.

## D. Parser lenses

**D1 — Two parsers, one string.** Send input read by two components with different
grammars: URL parser vs router, JSON parser vs validator, regex vs DB, markdown vs
sanitizer, YAML vs loader.

**D2 — Canonicalization gap.** Case, unicode normalization, trailing dot, double slash,
`..;/`, percent double-encoding, semicolon params, null bytes.

**D3 — Type confusion.** Send the type the validator did not expect: array where string,
object where array, `true` where int, `null` where required, numeric string where id.

**D4 — Depth and size.** Deeply nested JSON, 10k-key objects, 1MB header, huge multipart
part count, zip with 100k entries.

**D5 — The error message.** Deliberately break the parser. The stack trace names the
framework, the ORM, the file, sometimes the query.

## E. Data lenses

**E1 — Follow the data.** Where does this field end up? Export, webhook, email, PDF,
search index, analytics, S3, another tenant.

**E2 — Follow the money.** Pricing, refunds, proration, tax, currency rounding, trial
extension, seat math, gift credit.

**E3 — Identifier semantics.** Sequential, UUIDv1, ULID, hash of email, base64 of
`id:tenant`. Decode everything. UUIDv1 leaks time and MAC.

**E4 — Bulk endpoints.** Anything with `?ids=`, `filter`, `expand`, `include`, `sort`,
`search`, `export`. They are built for volume and validated for none.

## F. Observability lenses (also feed the SOC notes)

**F1 — The blind spot.** Which action produces no log? Test it twice and check what the
product's own audit view shows.

**F2 — Alert threshold.** What volume is needed before a human looks? Race 5 times, not 50.

**F3 — Detection cost.** A bug that looks like normal traffic is worth more than a loud one.

## G. Meta lenses

**G1 — Version skew.** Two versions of the same service deployed. Old one behind a header,
a region, a mobile UA.

**G2 — Differential.** Same feature, two tenants, two plans, two roles, two regions. The
difference is the spec.

**G3 — Test the test.** If the app has a public test/sandbox mode, its validation is often
weaker and shares the backend.

**G4 — Supply side.** Third-party scripts, CDN, status page, docs portal, changelog,
marketing subdomain — softer than the product, same brand trust.

**G5 — Invert the report.** Take a public disclosure for this vendor. Find the sibling
feature that shares the same helper. The fix rarely covered it.

---

## Falsification protocol

Before calling something a finding:

1. Name three reasons it might be a false positive.
2. Test each. Cold session, different account, different browser.
3. If two survive, the finding is likely real — tighten the reproducer.
4. If all three die, log it as `dead` with the reason. That reason is reusable knowledge.

## Novelty protocol

1. Describe the primitive in one sentence, no product names.
2. Search for that sentence's keywords.
3. If prior art exists, read it, then find the *difference* — usually the precondition.
4. If no prior art, build the minimal rig, then a technique card.

## Divergence drills (when stuck 30+ min)

- Pick a random lens letter and force three hypotheses.
- Re-read the last 200 lines of the main JS bundle.
- Open the mobile app and diff its calls against web.
- Ask: what would break if this were multi-tenant tomorrow?
- Ask: what did the last release *remove*?
- Ask: which of these five endpoints would a support agent use at 3am?
