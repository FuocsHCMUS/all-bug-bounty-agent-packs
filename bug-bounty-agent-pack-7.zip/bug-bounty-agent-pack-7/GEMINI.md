# GEMINI.md

Shim. The contract is `AGENTS.md`. Read it before any other file.

Slash-command equivalents live in `.antigravity/agent.md`.
