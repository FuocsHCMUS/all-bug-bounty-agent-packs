# INSTALL.md — wiring per agent

Place this folder at the repo root of a dedicated hunting repo. One repo per program, or
one repo with `STATE/targets/<slug>/` per program.

All agents read `AGENTS.md`. Shims exist so older builds that only look for their own
filename still land on the contract.

## ClaudeCode

- `AGENTS.md` at repo root is picked up natively. `CLAUDE.md` here is a 4-line shim for
  older builds; keep it.
- Put reusable commands in `.claude/commands/` if you want slash commands, e.g.
  `hunt.md` → "read AGENTS.md, then resume STATE/targets/$1/hypotheses.md".
- Permission mode: allow `Read`, `Edit`, `Write` inside the repo; ask on `Bash`.
- Suggested: `claude --permission-mode acceptEdits` for long sessions.

## Codex

- `AGENTS.md` at repo root is the contract.
- `.codex/config.toml` here sets sandbox to workspace-write and lists approval rules.
- Run with the repo as cwd so the config is discovered.

## opencode

- Reads `AGENTS.md` plus `.opencode/opencode.json` (agent definitions, permissions).
- The JSON here defines two agents: `hunt` (write-capable, bash ask) and `research`
  (read-only, network-heavy).

## Cline

- `.clinerules/` is auto-loaded. `00-core.md` restates the hard rules, `10-hunt.md` the loop.
- Enable "Auto-approve: read + edit inside workspace", leave bash on ask.

## Cursor

- `.cursor/rules/*.mdc` with `alwaysApply` for core, `globs` for skills.
- Cursor reads `AGENTS.md` too in recent builds; the rules files are the fallback.

## Antigravity

- `.antigravity/agent.md` defines the agent profile (role, tools, artifacts).
- `GEMINI.md` shim at root for Gemini-lineage loaders.

## Universal setup checklist

1. `git init` (or clone your hunting repo) and drop this folder in.
2. Add `.gitignore`: `WORKSPACE/bin/`, `WORKSPACE/tools/`, `WORKSPACE/venv/`,
   `WORKSPACE/captures/`, `*.pyc`, `.env`.
3. `py -3.14 -m venv WORKSPACE\venv` and activate.
4. Confirm the agent reads `AGENTS.md` (ask it to summarize §2).
5. Create the first target with `SCRIPTS/bb.py init <slug> <program-url>`.
6. Approve or refuse the MCP asks in `TOOLING_POLICY.md`.

## MCP servers worth having

| Server | Unlocks | Cost |
|---|---|---|
| chrome-devtools-mcp | DOM, network, console, storage | node, persistent |
| playwright-mcp | deterministic browser state | node, persistent |
| burp-mcp | proxy history in context | Burp Pro |
| fetch | byte-exact HTTP, header control | small |
| sqlite | queryable findings index | small |
| memory | cross-session facts | small |

Ask before adding each. Config goes in the agent's own MCP file, not here.

## Environment variables

```
BB_PACK_ROOT=.        # repo root
BB_PROXY=http://127.0.0.1:8080
BB_OUT=STATE
PYTHONUTF8=1
```
