# MAP.md — folder map and reading order

```
.
├── AGENTS.md                          contract: read first, obey always
├── SKILL.md                           trigger table for every module
├── OPERATING_MODEL.md                 loop, gates, timeboxes, stop conditions
├── CREATIVE_OFFENSIVE_THINKING.md     30 lenses + falsification protocol
├── TOOLING_POLICY.md                  install asks, portable-first, Python rules
├── INSTALL.md                         per-IDE wiring, MCP proposals
├── SCOPE_AND_RULES.md                 scope parsing, rate discipline, dup economics
├── MAP.md                             this file
├── VERSION
├── CLAUDE.md  GEMINI.md               thin shims to AGENTS.md
├── .cursor/rules/                     Cursor rule files
├── .clinerules/                       Cline rule files
├── .opencode/                         opencode config
├── .codex/                            Codex config
├── .antigravity/                      Antigravity agent profile
├── SKILLS/                            00-index + 23 modules
├── WORKFLOWS/                         6 runbooks
├── PLAYBOOKS/                         10 vuln-class recipes
├── TEMPLATES/                         7 output formats
├── CHECKLISTS/                        5 gate checklists
├── REFERENCE/                         primers, taxonomy, glossary, sources, path
├── SCRIPTS/                           stdlib-first CLI
├── STATE/                             targets, findings, learning
└── WORKSPACE/                         portable tools, venvs, captures
```

## Reading order

**Agent, cold start:** AGENTS → OPERATING_MODEL → TOOLING_POLICY → SCOPE_AND_RULES →
SKILLS/00-index → pick a skill.

**Agent, resuming:** STATE/targets/<slug>/hypotheses.md → scope.md → posture.md → resume
at the highest-status open hypothesis.

**Human, cold start:** REFERENCE/http-primer-for-beginners → REFERENCE/vuln-taxonomy →
REFERENCE/cve-cwe-cvss-primer → REFERENCE/learning-path-cyber.

## Which files are load-bearing

Deleting `AGENTS.md`, `OPERATING_MODEL.md`, or `SCOPE_AND_RULES.md` breaks the pack.
Everything in `REFERENCE/` is optional enrichment.
