# OPERATING_MODEL.md — the loop, gates and timeboxes

## Why a loop

Ad hoc testing converges on whatever the last writeup said. A loop with gates forces
divergence: you cannot move forward without a written reason, so you cannot drift into
checklist recitation.

## Stages

### 0. INTAKE
Read program policy. Extract scope, out-of-scope, credential rules, rate limits,
disclosure terms, payout table, known-issue list.
Gate: `scope.md` exists and lists at least one in-scope asset and the auth model.
Timebox: 20 min. Output: `STATE/targets/<slug>/scope.md`, `profile.md`.

### 1. SURFACE
Enumerate. Passive first (certs, DNS, ASN, archives, JS, mobile binaries, job posts),
active second (probe, crawl, parameter discovery).
Gate: inventory with at least 5 distinct asset classes OR a note explaining why the
program is a single-host program.
Timebox: 90 min. Output: `assets.md`, ranked by (reachability × privilege × novelty).

### 2. HYPOTHESIS
For each ranked surface, write 2–4 hypotheses. Name the class and the lens used.
Gate: every hypothesis names the trust boundary it crosses.
Timebox: 15 min per surface. Output: rows in `hypotheses.md`.

### 3. PROOF
Build the minimal rig. Read-only first. Confirm the signal is real, not a scanner artifact.
Gate: reproducible request/response pair, twice, cold.
Timebox: 20 min per hypothesis, then park.

### 4. IMPACT
Ask: whose data, whose money, whose action, how many, how quietly.
Gate: a named victim class and a named asset that changes hands.
Timebox: 30 min. Output: impact section draft.

### 5. REPORT
Tighten, dedupe, write. Apply `CHECKLISTS/pre-submit-checklist.md`.
Gate: all checklist boxes ticked.
Timebox: 45 min. Output: report draft + evidence folder.

### 6. LEARNING
Root concept, failed boundary, SOC view, drills, maturity read.
Timebox: 25 min. Output: `STATE/learning/<slug>-<id>.md`, ladder update.

### 7. RETRO
What lens paid? What tool was missing? What would have cut time in half?
Output: appended lines in `STATE/targets/<slug>/retro.md`.

## Gate rules

- No PROOF without HYPOTHESIS text.
- No REPORT without double-run reproducer.
- No submission without dup-risk score.
- No closing a target without a posture entry.

## Timebox ledger

Track in `hypotheses.md`. Two timeouts on the same surface = the surface is exhausted at
current depth; escalate depth or move.

## Parallelism

Safe to parallelize: passive recon, JS bundle fetch, screenshotting, CVE feed polling,
static reads.
Not safe: rate-limited active fuzzing on the same host, state-mutating tests, anything
that changes a shared account.

## Stop conditions

See AGENTS.md §13. Additional: if the program's known-issue list already covers your
chain end-to-end, stop and re-aim rather than submit.

## Restart protocol

On context loss: read `hypotheses.md`, sort by status (`confirmed` → `probing` → `open`),
resume at the top. Never restart recon from scratch; check `assets.md` freshness first.
