# PB — Authentication bypass

## Preconditions
Login endpoint, at least one valid account, password reset flow.

## Recipes

**Response manipulation.** Intercept the login response. Flip `"success":false` → `true`,
`"mfa_required":true` → `false`, `"role":"user"` → `"admin"`. If the client trusts the body
and the server sets no session, this is a full bypass.

**Step skip.** Complete step 1 of a two-step flow, then request the post-login page
directly. Check whether the session is issued at step 1 or step 2.

**Token confusion.** Swap `access_token` for `id_token`, or a refresh token into the access
slot. Test a token from another client id.

**JWT edge cases.** `alg:none`, `alg:HS256` with the public key as secret, `kid` traversal
to `/dev/null`, `jku` pointing at a collaborator host, expired token with a fresh `iat`,
`sub` swap between two accounts.

**Reset poisoning.** Send the reset request with `Host: evil.tld` and `X-Forwarded-Host`.
If the link in the mail uses the header, the token goes to you. Also test the reset link
for reuse after a successful reset.

**Case and unicode.** `Admin@x.tld`, `admin@x.tld.`, `admin@x.tld ` (trailing space),
`ADMIN@x.tld` — look for a case-insensitive lookup that issues a token for the wrong record.

**MFA edges.** Enroll a new factor without re-auth, disable without re-auth, reuse a backup
code, race two verifications with the same code, and try an empty `code` value.

## Signals
Session cookie set before MFA completes; `mfa_required` present in the response body;
different error strings for wrong password vs unknown user.

## Failure modes
Session issued only after full MFA and rotated on every step; reset tokens single-use.
