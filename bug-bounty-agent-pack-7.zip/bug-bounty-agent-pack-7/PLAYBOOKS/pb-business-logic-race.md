# PB — Business logic and races

## Preconditions
Money, quota, seats, credits, trials, or a limited resource.

## Recipes

**Negative and zero.** `-1`, `0`, `0.001`, `1e-9`, huge values, float where int expected.
Refund more than paid. Buy 0 items. Extend a trial by `-30` days.

**Rounding.** Currency with 2 decimals, 100× quantity of a $0.005 item. Check who absorbs
the fraction and whether it is repeated per line.

**Coupon stacking.** Apply two coupons, then a coupon plus a referral credit, then a
coupon on an already-discounted item. Check whether the discount applies to the pre-discount
total.

**Seat math.** Invite beyond the plan limit, downgrade with members present, remove a member
and re-add during a billing cycle.

**Race conditions.** Send N parallel requests with the same idempotency key or none:
redeem a coupon, claim a username, accept an invite, withdraw, vote, transfer.

**Single-packet attack.** Where the client allows, put the requests in one TCP segment to
shrink the window. Otherwise use 20–30 parallel connections.

**State inversion.** Cancel after ship, refund after delivery, downgrade after using a
premium feature, unsubscribe then resubscribe to reset a counter.

## Signals
A balance that goes up when it should go down; two objects with the same unique field;
a 200 on the Nth request where the first N-1 returned 409.

## Failure modes
Serialized writes with a DB constraint; per-request idempotency with a server-side lock.
