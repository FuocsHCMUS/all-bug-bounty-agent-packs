# PB — Cloud and storage misconfiguration

## Preconditions
Cloud-hosted assets in scope; bucket or container names derivable from the brand.

## Recipes

**Bucket enumeration.** `brand`, `brand-dev`, `brand-backup`, `brand-assets`,
`brand-media`, `brand-static`, `brand-logs`, `brand-uploads`, plus `-staging`, `-test`,
`-prod`. Check list, read, write separately.

**S3 signals.** `NoSuchBucket` vs `AccessDenied` vs a listing XML. A listing means public
read. Try `PUT` with a small object for public write.

**Other providers.** GCS `storage.googleapis.com/<name>`, Azure
`<name>.blob.core.windows.net/<container>?restype=container&comp=list`,
DigitalOcean Spaces, Backblaze.

**Container images.** Public registries: pull, inspect layers, grep for `.env`, keys,
`id_rsa`, CI tokens.

**Exposed services.** `:2375` Docker API, `:9000` Portainer, `:8080` Jenkins,
`:3000` Grafana, `:5601` Kibana, `:9200` Elasticsearch, `:8500` Consul, `:2379` etcd.

**Serverless.** Function URLs, API Gateway stages (`/dev`, `/stage`), permissive CORS
`Access-Control-Allow-Origin: *` with credentials.

**IaC leaks.** Public Terraform state, `terraform.tfstate` in a bucket, CloudFormation
outputs in a public repo.

## Signals
Listing XML, `AccessDenied` with a bucket name that exists, `X-Amz-Bucket-Region` header
confirming existence.

## Failure modes
Block Public Access on everything; OAC-only distributions.
