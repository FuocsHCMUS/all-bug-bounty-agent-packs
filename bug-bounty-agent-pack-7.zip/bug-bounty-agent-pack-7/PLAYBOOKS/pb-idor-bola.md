# PB — IDOR / BOLA

## Preconditions
Two accounts, two tenants if possible, object ids observed.

## Recipes

**Vertical first.** Take your own object id, call the endpoint as the *other* account.
Then as anonymous. Then with no auth header at all.

**Horizontal with mixed pairs.** `/orgs/A/items/B` where A belongs to you and B does not.
Then the reverse. Then both foreign.

**Nested relation swap.** Update a child's `parent_id` to a foreign parent, then read the
child through the new parent.

**Verb matrix.** `GET` works and is guarded → try `HEAD`, `PUT`, `PATCH`, `DELETE`,
`OPTIONS` on the same path.

**Bulk leak.** `?ids=own,foreign,deleted,999999` — partial results confirm existence and
often return full objects for the foreign ones.

**Soft-deleted.** Delete an object, then read it by id. Restore it into your own account.

**Export/import.** Trigger an export of a foreign object; check whether the export job
takes an id from the body rather than the session.

**Header identity.** Add `X-User-Id`, `X-Org-Id`, `X-Tenant` set to a foreign value.

## Signals
`403` on the list endpoint but `200` on the item endpoint; `404` for foreign ids vs `403`
for existing-but-forbidden (existence oracle).

## Failure modes
Centralized authz middleware on every route; opaque ids with a signed tenant claim.
