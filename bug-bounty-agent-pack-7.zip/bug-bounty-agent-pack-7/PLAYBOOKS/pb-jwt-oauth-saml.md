# PB — Token and federation

## Preconditions
JWT, OAuth/OIDC, or SAML in the flow.

## Recipes

**JWT structural.** Decode. Check `alg`, `kid`, `jku`, `x5u`, `typ`, and every claim.
`alg:none` with an empty signature. `HS256` signed with the RSA public key as the secret.
`kid` = `../../../../dev/null`, or a path into a known file. `jku` to your host serving a
JWKS. Expired `exp` with a future `iat`. `aud`/`iss` from another environment.

**Claim trust.** Change `sub` to another user's id, `role` to `admin`, `tenant` to another
org, `email_verified` to `true`, `plan` to `enterprise`.

**Signature stripping.** Some parsers accept a token with the signature segment removed
entirely. Try `header.payload.`.

**OAuth redirect.** `redirect_uri` exact? Try a path append, `../`, a subdomain,
`@evil.tld`, an open redirect on an allowed host, and the `state`-less variant.

**PKCE downgrade.** Remove `code_challenge`; check whether the server still accepts the
exchange without a verifier.

**Code reuse and mix-up.** Redeem the same code twice; redeem a code issued to client A at
client B's endpoint.

**SAML.** Signature wrapping (move the signed assertion, add a forged one), comment
truncation in the NameID, unsigned assertion accepted, `Recipient`/`Audience` unvalidated,
XXE in the metadata upload.

## Signals
`alg:none` accepted; `redirect_uri` prefix match; the app logs you in after a claim edit
with no re-issue.

## Failure modes
Strict allowlist with exact match, `alg` pinned, assertion encrypted.
