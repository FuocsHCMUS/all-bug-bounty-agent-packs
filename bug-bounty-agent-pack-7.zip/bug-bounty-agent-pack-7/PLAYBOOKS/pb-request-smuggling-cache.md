# PB — Request smuggling and cache deception/poisoning

## Preconditions
A CDN or reverse proxy in front of an origin; HTTP/1.1 edge.

## Recipes

**Detect the pair.** Note `Server` and any `Via`/`X-Cache` headers. Different proxy and
origin software is the precondition.

**CL.TE.** `Content-Length` short, `Transfer-Encoding: chunked` with a body that leaves a
remainder in the socket.

**TE.CL.** Reverse: chunked with a trailing `Content-Length` that the origin honors.

**TE.TE obfuscation.** `Transfer-Encoding: chunked`, then `Transfer-Encoding: xchunked`,
`Transfer-Encoding : chunked`, `Transfer-Encoding:\tchunked`, double `TE` headers.

**Timing signal.** Send two requests on one connection. A smuggled prefix makes the second
response either 404 instantly or hang — that is the tell.

**Cache poisoning.** Unkeyed input: `X-Forwarded-Host`, `X-Host`, `X-Forwarded-Scheme`,
`X-Original-URL`. Poison the cache for `/`, then request it clean and check whether the
poisoned response is served.

**Cache deception.** Append `/anything.css` or `/.json` to an authenticated page. If the
CDN caches it, the next anonymous request gets the victim's HTML.

## Signals
`X-Cache: HIT` on a resource that should be private; a 404 immediately after a smuggled
prefix; the poison persisting after cache expiry.

## Failure modes
HTTP/2 end-to-end with normalization; per-user cache keys.
