# PB — Subdomain takeover

## Preconditions
Dangling DNS record pointing at a claimable service.

## Recipes

1. Collect CNAMEs from certificates, DNS, and archives.
2. Resolve each. A CNAME to a third-party with `NXDOMAIN` or a provider "not found" page
   is a candidate.
3. Fingerprint the provider from the CNAME target and the error page.
4. Verify by **claiming**, not by banner: create the resource under your account with the
   exact name.
5. Serve a marker, fetch the hostname, confirm your marker.
6. Escalate: does the parent domain set cookies with `Domain=.parent.tld`? A takeover then
   yields cookie injection into the apex. Does the host appear in a CSP allowlist or an
   OAuth `redirect_uri` allowlist?

**Provider targets worth checking:** S3 website endpoints, GitHub Pages, Heroku,
Netlify, Vercel, Azure `cloudapp.azure.com` / Traffic Manager, Fastly, ReadTheDocs,
Surge, Unbounce, Pantheon, Tumblr, Zendesk.

## Signals
`NoSuchBucket`, "There isn't a GitHub Pages site here", "No such app" (Heroku),
`404 Not Found` from the provider's edge with the provider's branding.

## Failure modes
Wildcard `*.provider` DNS with a catch-all; provider reserving the name.
