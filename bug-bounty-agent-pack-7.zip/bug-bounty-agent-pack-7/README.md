# bug-bounty-agent-pack-7

A working doctrine, skill library and toolchain contract for turning a coding agent into a
persistent, creative, report-producing offensive security researcher.

Target agents: ClaudeCode, Codex, opencode, Cline, Cursor, Antigravity.
Canonical entrypoint: `AGENTS.md` (all six read it or are shimmed to it).

---

## What this pack actually does

It gives the agent:

1. A **stance** — senior offensive security engineer, not a checklist runner.
2. A **loop** — scope → surface → hypothesis → proof → report → learning, with hard gates.
3. **Skills** — 16 modules covering the classes that actually pay, plus the research pipeline.
4. **Playbooks** — concrete test recipes with payloads, not vibes.
5. **A research engine** — CVE hunting, writeup mining, CTF-to-technique conversion,
   and a synthesis protocol for techniques nobody has published yet.
6. **A second output stream** — for you, the student: from-the-roots explanations,
   company posture analysis, SOC detection angles, and a personal skill ladder.
7. **A tool policy** — ask before installing, portable-first, everything lands in `WORKSPACE/`.

## The two deliverables of every session

| Stream | Goes to | Purpose |
|---|---|---|
| **Findings** | `STATE/findings/` → report template | Company patches fast |
| **Learning** | `STATE/learning/` → learning log | You get better than the bug |

The second stream is not optional. It is the reason this pack exists. If the agent finds
an auth bug and does not also explain, from first principles, what an auth boundary is,
how the framework usually gets it wrong, and what the SOC would have logged — the job
is half done.

## Non-negotiable behaviours

- No safety theatre. Scope is a constraint, not a permission slip. If it is reachable and
  in scope, test it. If it is out of scope but adjacent, test it and label it.
- Ask before installing anything persistent. Portable stuff gets cloned into `WORKSPACE/`
  and never touches the host.
- Every claim carries a reproducer. No reproducer, no finding.
- Novel techniques must survive a falsification pass before being called novel.
- Python 3.14 on Windows 11. Native paths, `py -3.14`, venv inside `WORKSPACE/`.

## Reading order

New agent, first run: `AGENTS.md` → `OPERATING_MODEL.md` → `TOOLING_POLICY.md` →
`SCOPE_AND_RULES.md` → `SKILLS/00-index.md`.

New human, first run: `REFERENCE/http-primer-for-beginners.md` →
`REFERENCE/vuln-taxonomy.md` → `REFERENCE/cve-cwe-cvss-primer.md`.

Full map: `MAP.md`.

## Layout

```
AGENTS.md                 canonical agent contract
SKILL.md                  skill manifest + trigger table
OPERATING_MODEL.md        the loop, gates, timeboxes, stop conditions
CREATIVE_OFFENSIVE_THINKING.md   the anti-rulebook (30 lenses)
TOOLING_POLICY.md         install protocol, portable-first, Python/Windows rules
INSTALL.md                per-IDE wiring, MCP suggestions
SCOPE_AND_RULES.md        scope parsing, rate discipline, duplicate economics
SKILLS/                   capability modules
WORKFLOWS/                multi-hour and multi-day runbooks
PLAYBOOKS/                vuln-class test recipes with payloads
TEMPLATES/                report, finding note, CVE brief, technique card, posture report
CHECKLISTS/               recon, web, api, pre-submit, triage-proof
REFERENCE/                primers, taxonomy, glossary, sources, learning path
SCRIPTS/                  stdlib-first helper CLI
STATE/                    target index, findings, learning logs
WORKSPACE/                cloned portable tools, venvs, captures (gitignored)
```

## Style contract

Findings are written so a triager who hates you still accepts them. Learning notes are
written so a first-year student who has never opened Wireshark still follows them.

## Version

`7.0` — see `VERSION`.
