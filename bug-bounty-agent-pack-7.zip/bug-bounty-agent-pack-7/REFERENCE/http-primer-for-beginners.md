# HTTP primer, from the socket up

Read this before the taxonomy. Every bug in this pack is a violation of something described
here, so the vocabulary matters.

## 1. Packets, ports, connections

Two programs talk over TCP. One listens on a port (443 for TLS, 80 for plain, 8080 for a
proxy). The client opens a connection to `ip:port`, and from then on bytes flow both ways
until either side closes. A connection is identified by the four-tuple
`(client ip, client port, server ip, server port)` — that is why two requests on the same
connection are different from two requests on two connections, and why "single-packet
attack" (many requests in one segment) changes timing behavior.

TLS wraps the connection: a handshake agrees on keys, then everything after is encrypted.
The client verifies the server's certificate against a CA list. A proxy that wants to read
traffic must be trusted by the client, which is why Burp installs a CA.

## 2. Requests

```
GET /path?query=1 HTTP/1.1
Host: example.com
Cookie: session=abc
Accept: */*
```

- **Method** — the verb. `GET` should read, `POST` should create, `PUT` replace,
  `PATCH` partially update, `DELETE` remove. Apps lie about this constantly; that gap is
  a testing surface.
- **Path** — the resource. Routers match on it, often with patterns like `/user/:id`.
- **Query** — `?a=1&b=2`. Parsed into a map. Duplicate keys, missing values, and encoded
  delimiters all behave differently per parser — that is parameter pollution.
- **Headers** — metadata. `Host` selects the virtual host. `Cookie` carries session state.
  `Authorization` carries tokens. `Content-Type` tells the parser how to read the body.
  `X-Forwarded-For` and friends claim the client's origin.
- **Body** — payload. JSON, form-encoded, multipart, XML, binary.

## 3. Responses

Status codes: `2xx` success, `3xx` redirect, `4xx` client error, `5xx` server error.
`401` = not authenticated, `403` = authenticated but forbidden, `404` = not found.
The distinction between 403 and 404 is an information leak: it tells you the object exists.

Headers carry security state: `Set-Cookie` issues sessions, `Location` redirects,
`Content-Security-Policy` restricts script sources, `Access-Control-Allow-Origin` decides
which origins may read the response.

## 4. State

HTTP is stateless; every request stands alone. Applications fake continuity with cookies
and tokens. Everything that makes an app work — the cart, the draft, the wizard step — is
server-side state keyed by something the client sends. Whoever can guess or steal that key
becomes the user.

## 5. Trust boundaries

A boundary is where data crosses from a context with fewer privileges to one with more.
Browser → edge → app → database; app → queue → worker; tenant → tenant; user → admin.
Every vulnerability in this pack is a boundary where the receiving side believed something
about the sender that was not true.

## 6. Why this matters

You cannot find a parser differential until you know that two parsers exist. You cannot
find a smuggling bug until you know what a connection is. Learn the layer below the one
you are testing, always.
