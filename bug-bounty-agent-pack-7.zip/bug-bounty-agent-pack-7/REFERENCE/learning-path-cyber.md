# Learning path for a cyber student

Ordered so each rung makes the next one legible. Do not skip; the skips show up later as
gaps you cannot name.

## Rung 0 — How machines talk
- Packets, ports, TCP handshake, DNS resolution, TLS. Build a two-process echo server and
  watch it in Wireshark.
- Filesystem permissions, users, processes, environment variables on Linux and Windows.
- Drill: capture your own HTTP traffic and label every header.

## Rung 1 — How the web is built
- HTML, CSS, JS basics. Then a request lifecycle: DNS → TCP → TLS → request → response →
  render.
- Cookies, sessions, `SameSite`, CORS, CSP, redirects.
- Drill: build a login form with a server session, then break the session handling yourself.

## Rung 2 — How the web breaks
- PortSwigger Academy, in order, Apprentice → Practitioner. Every lab, no skipping.
- One bug class per week. Write a technique card after each.
- Drill: reproduce three labs from memory with no notes.

## Rung 3 — Reading real systems
- Read open-source apps: find a middleware, trace a request through it, find where authz
  is checked and where it is not.
- Read patch commits for CVEs in that app.
- Drill: predict a bug from the code, then confirm it.

## Rung 4 — Working a program
- Start on a VDP with wide scope. Duplicates are cheap tuition.
- One target per month, full loop, report every finding even if low.
- Drill: submit five reports and read the triage feedback carefully.

## Rung 5 — Depth
- Chains, races, parser differentials, mobile, cloud.
- Drill: take a public disclosure and find the sibling feature the fix missed.

## Rung 6 — Blue side
- Build detections for the bugs you found. Write Sigma rules, then run them against your
  own traffic.
- Learn the SOC triage flow: alert → enrich → scope → contain.
- This rung is what makes you employable on both sides.

## Rung 7 — Systems thinking
- Read the SDLC of the companies you test. Where would a lint rule have caught this?
- Design a secure pattern for the class you just broke.
- Teach it: write the learning note that a beginner could follow.

## Weekly cadence
- 3 lab days, 1 reading day, 1 target day, 1 writing day, 1 rest day.
- Track hours per rung in `STATE/learning/skill-ladder.md`.
- A rung is done when you can teach it, not when you finish the material.
