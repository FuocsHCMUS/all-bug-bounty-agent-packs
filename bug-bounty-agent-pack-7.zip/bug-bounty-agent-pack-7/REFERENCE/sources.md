# Sources

## Program directories
- HackerOne directory: https://hackerone.com/directory/programs
- HackerOne hacktivity (public disclosures): https://hackerone.com/hacktivity
- Bugcrowd program list: https://www.bugcrowd.com/bug-bounty-list/
- Intigriti: https://www.intigriti.com/programs
- YesWeHack: https://yeswehack.com/programs
- disclose.io (policy standard): https://disclose.io/
- CISA VDP list (gov): https://www.cisa.gov/vulnerability-disclosure-policy-template

## Advisories and CVE data
- NVD: https://nvd.nist.gov/
- GitHub Security Advisories: https://github.com/advisories
- CVE.org: https://www.cve.org/
- OSV: https://osv.dev/
- Debian security tracker: https://security-tracker.debian.org/tracker/
- Ubuntu CVE tracker: https://ubuntu.com/security/cves

## Technique and writeup corpora
- PortSwigger Web Security Academy: https://portswigger.net/web-security
- OWASP WSTG: https://owasp.org/www-project-web-security-testing-guide/
- OWASP Cheat Sheet Series: https://cheatsheetseries.owasp.org/
- HackTricks: https://book.hacktricks.wiki/
- PayloadsAllTheThings: https://github.com/swisskyrepo/PayloadsAllTheThings
- ProjectDiscovery blog: https://projectdiscovery.io/blog
- Assetnote research: https://www.assetnote.io/resources/research
- Sam Curry's blog: https://samcurry.net/
- Critical Thinking podcast / bug bounty episodes
- CTFtime writeup archive: https://ctftime.org/writeups
- pwn.college: https://pwn.college/

## Learning
- PortSwigger Academy (free, best structured web path)
- TryHackMe and HackTheBox for lab reps
- OverTheWire for Linux and shell fundamentals
- Wireshark's own sample capture library
- Beej's guide to network programming

## Rule for using sources
Read for the primitive. If you can only repeat the payload, you learned nothing. If you can
restate the precondition and the invariant it breaks, you can apply it anywhere.
