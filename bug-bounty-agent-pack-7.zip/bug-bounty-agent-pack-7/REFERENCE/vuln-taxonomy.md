# Vulnerability taxonomy

Grouped by the boundary that fails. Every class here has a playbook or skill.

## Identity and access
- **Authentication bypass** — reach a session without credentials.
- **Session fixation / rotation failure** — force or keep a session across a privilege change.
- **IDOR / BOLA** — act on an object you do not own by supplying its identifier.
- **BFLA** — call a function your role should not reach.
- **Privilege escalation** — vertical (role) or horizontal (peer), including via mass assignment.
- **Tenant isolation failure** — cross-org read or write.

## Input handling
- **SQL / NoSQL / LDAP / XPath injection** — data becomes query syntax.
- **Command injection** — data becomes shell.
- **SSTI** — data becomes template code.
- **Expression injection** — SpEL, OGNL, EL.
- **XXE** — external entity resolution in XML.
- **Deserialization** — data becomes an object graph.
- **Prototype pollution** — data becomes an object's prototype.
- **Header injection / CRLF** — data becomes a header or splits a response.
- **Log injection** — data becomes a log line.

## Output handling
- **Reflected / stored / DOM XSS** — data becomes script.
- **HTML injection** — data becomes markup.
- **CSV formula injection** — data becomes a spreadsheet formula.
- **Markdown injection** — data becomes rendered markup in a viewer.
- **Open redirect** — data becomes a `Location`.
- **Content spoofing** — data becomes visible text in a trusted frame.

## Server-side reach
- **SSRF** — the server fetches for you, including metadata and internal services.
- **Path traversal / zip-slip** — the filesystem is addressable.
- **File inclusion** — local or remote code inclusion.
- **Request smuggling** — desync between proxy and origin.
- **Cache poisoning / deception** — shared cache serves the wrong body to the wrong user.

## Resource and logic
- **Race condition / TOCTOU** — check and use separated.
- **Business logic abuse** — negative values, coupon stacking, seat math, state inversion.
- **Resource exhaustion** — unbounded depth, size, or fan-out.
- **Rate-limit bypass** — key rotation, header spoofing, parallel connections.

## Configuration and platform
- **Subdomain takeover** — dangling record to a claimable service.
- **Cloud storage misconfiguration** — list, read, or write on a bucket.
- **Exposed service / default credentials** — admin panel on a public port.
- **CORS misconfiguration** — arbitrary origin with credentials.
- **CSP weakness** — `unsafe-inline`, JSONP on an allowlisted host.
- **Secret exposure** — key in a bundle, image layer, or repo.

## Supply chain
- **Dependency confusion** — internal scope unclaimed publicly.
- **CI compromise** — `pull_request_target`, self-hosted runner, secret in a fork build.
- **Typosquat / malicious `postinstall`**.
- **Unsigned artifact / HTTP installer**.

## Crypto
- **Weak token generation** — `Math.random`, timestamp, counter.
- **Static IV / ECB** — pattern leakage.
- **JWT `alg` confusion, `kid` traversal, `jku` abuse**.
- **Signature stripping**.
- **Hash-before-compare misuse, timing-unsafe comparison**.
