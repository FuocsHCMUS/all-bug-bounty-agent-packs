# SCOPE_AND_RULES.md — scope as a constraint, not a permission slip

## Parse, don't skim

`scope.md` fields, mandatory:

```
program: <name>
platform: <h1|bc|intigriti|direct|vdp>
policy_url: <url>
in_scope:        # exact hosts, wildcards, apps, IPs, repos
out_of_scope:    # exact, plus inferred (see below)
auth_model:      # how accounts are issued, how many, tiers
rate_limit:      # stated or measured
known_issues:    # from policy + public disclosures
payout_table:    # classes and ranges
disclosure:      # private / coordinated / public date
notes:           # quirks, restrictions, test-data rules
```

Inference rules when policy is silent:
- `*.example.com` in scope does **not** automatically include `example.com` apex or
  `example.co.uk` — test and label.
- Third-party SaaS embedded in scope (`*.zendesk.com`) is usually in scope for the
  integration surface only.
- Out-of-scope lists often include "self-XSS", "missing headers", "rate limiting",
  "SPF/DMARC", "clickjacking without chain". Read it twice.
- Mobile apps are in scope only if named. So is source code.

## Reachability discipline

Before the first active request, decide:

1. Which assets are read-only safe?
2. Which need an account, and how is it obtained (self-signup, invite, provided)?
3. Which mutate shared state (org settings, webhooks, billing)?
4. What is the rollback for each mutation?

## Rate discipline

- Default ceiling: 5 req/s per host, 1 req/s on auth endpoints, 20 concurrent on static.
- Back off on `429`/`503` with jitter, then halve the rate for the rest of the session.
- Fuzzers: `-rate 40 -t 10` is a starting point; measure before scaling.
- Record the observed ceiling in `scope.md` — the next session inherits it.

## Duplicate economics

Before writing a report, answer:

- Is this class on the vendor's public disclosure list?
- Does the endpoint appear in any public writeup for this vendor?
- Is it the first-order version of a known chain (e.g. another `?url=` SSRF)?
- How long has the endpoint existed? Long-lived + obvious = already found.

If dup risk is high, do not abandon — **specialize**: same class, harder surface, or
chain to higher impact. Duplicates are a signal to go deeper, not to stop.

## Evidence hygiene

- Never mix accounts between findings.
- Timestamp every capture; note the account and role used.
- Redact your own PII, keep the vendor's PII that proves impact.
- Keep the raw bytes. Screenshots are decoration.

## Disclosure posture

Private by default. Public after fix or after the program's window. If the vendor is
silent past their stated SLA, escalate politely through the platform, then disclose on
the platform's schedule.

## Boundaries worth testing that policies rarely mention

- GraphQL introspection and playground
- Swagger/OpenAPI/AsyncAPI docs
- `/.well-known/` (security.txt, jwks.json, openid-configuration)
- Status page and changelog feeds
- Staging/preview hostnames derived from prod
- Mobile API versions behind old app builds
- Webhook receivers and their retry consoles
