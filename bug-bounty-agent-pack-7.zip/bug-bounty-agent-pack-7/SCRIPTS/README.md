# SCRIPTS

Stdlib-first helpers. Python 3.14 on Windows 11: run with `py -3.14`.

| script | purpose |
|---|---|
| `bb.py` | scaffold a target, log and update hypotheses |
| `probe.py` | byte-exact HTTP replay with raw capture (needs httpx) |
| `jsx.py` | extract endpoints, params, secrets from JS bundles |
| `diffz.py` | score two responses for meaningful deltas |
| `ids.py` | classify an identifier to pick the IDOR approach |
| `index_findings.py` | rebuild the findings index |

All write into `STATE/`. None need admin. `probe.py` needs `pip install httpx` inside the
`WORKSPACE/venv` — that is a portable, no-ask install.
