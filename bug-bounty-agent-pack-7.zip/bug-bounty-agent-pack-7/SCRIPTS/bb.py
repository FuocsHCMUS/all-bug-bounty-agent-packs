#!/usr/bin/env python3
"""bb.py — target scaffolding and ledger helpers. Stdlib only.

Usage:
  py -3.14 SCRIPTS/bb.py init <slug> <program-url>
  py -3.14 SCRIPTS/bb.py hyp <slug> "<surface>" "<hypothesis>" <class> <lens>
  py -3.14 SCRIPTS/bb.py status <slug> <hyp-id> <status> ["note"]
  py -3.14 SCRIPTS/bb.py show <slug>
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STATE = ROOT / "STATE" / "targets"

STATUSES = {"open", "probing", "confirmed", "dead", "parked"}


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def target_dir(slug: str) -> Path:
    d = STATE / slug
    if not d.exists():
        sys.exit(f"no such target: {slug}")
    return d


def ledger(slug: str) -> Path:
    return target_dir(slug) / "hypotheses.json"


def load(slug: str) -> list[dict]:
    p = ledger(slug)
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else []


def save(slug: str, rows: list[dict]) -> None:
    ledger(slug).write_text(json.dumps(rows, indent=2), encoding="utf-8")


def cmd_init(slug: str, url: str) -> None:
    d = STATE / slug
    for sub in ("evidence", "notes"):
        (d / sub).mkdir(parents=True, exist_ok=True)
    (d / "scope.md").write_text(
        f"# Scope — {slug}\n\n- **program:** {url}\n- **platform:** \n"
        "- **auth_model:** \n- **rate_limit:** \n\n## In scope\n- \n\n"
        "## Out of scope\n- \n\n## Known issues\n- \n", encoding="utf-8")
    (d / "profile.md").write_text(f"# Profile — {slug}\n\n", encoding="utf-8")
    (d / "surface.md").write_text(f"# Surface — {slug}\n\n| asset | class | boundary | rank |\n|---|---|---|---|\n", encoding="utf-8")
    (d / "posture.md").write_text(f"# Posture — {slug}\n\n", encoding="utf-8")
    save(slug, [])
    print(f"initialised {d}")


def cmd_hyp(slug: str, surface: str, hyp: str, cls: str, lens: str) -> None:
    rows = load(slug)
    hid = f"H-{len(rows) + 1:03d}"
    rows.append({
        "id": hid, "surface": surface, "hypothesis": hyp, "class": cls,
        "lens": lens, "status": "open", "evidence": [], "revive_if": "",
        "created": now(), "note": "",
    })
    save(slug, rows)
    print(f"{hid} logged")


def cmd_status(slug: str, hid: str, status: str, note: str = "") -> None:
    if status not in STATUSES:
        sys.exit(f"status must be one of {sorted(STATUSES)}")
    rows = load(slug)
    for r in rows:
        if r["id"] == hid:
            r["status"] = status
            r["note"] = note
            r["updated"] = now()
            save(slug, rows)
            print(f"{hid} -> {status}")
            return
    sys.exit(f"no hypothesis {hid}")


def cmd_show(slug: str) -> None:
    rows = load(slug)
    order = {"confirmed": 0, "probing": 1, "open": 2, "parked": 3, "dead": 4}
    for r in sorted(rows, key=lambda x: order.get(x["status"], 9)):
        print(f"[{r['status']:9}] {r['id']} {r['class']:22} {r['surface']}")
        print(f"            {r['hypothesis']}")
        if r.get("note"):
            print(f"            note: {r['note']}")


def main(argv: list[str]) -> None:
    if len(argv) < 2:
        print(__doc__)
        return
    cmd, *rest = argv[1:]
    if cmd == "init" and len(rest) == 2:
        cmd_init(*rest)
    elif cmd == "hyp" and len(rest) == 5:
        cmd_hyp(*rest)
    elif cmd == "status" and len(rest) >= 3:
        cmd_status(rest[0], rest[1], rest[2], rest[3] if len(rest) > 3 else "")
    elif cmd == "show" and len(rest) == 1:
        cmd_show(rest[0])
    else:
        print(__doc__)


if __name__ == "__main__":
    main(sys.argv)
