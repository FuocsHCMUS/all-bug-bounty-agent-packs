#!/usr/bin/env python3
"""diffz.py — compare two captured responses and surface the interesting deltas.

Usage:
  py -3.14 SCRIPTS/diffz.py a.resp b.resp

Stdlib only. Scores on length delta, status delta, and token overlap change.
"""
from __future__ import annotations

import sys
from pathlib import Path


def load(p: Path) -> tuple[int, str]:
    raw = p.read_text(encoding="utf-8", errors="ignore")
    status = 0
    for line in raw.splitlines()[:1]:
        parts = line.split()
        if len(parts) >= 2 and parts[1].isdigit():
            status = int(parts[1])
    return status, raw


def main(argv: list[str]) -> None:
    if len(argv) != 3:
        print(__doc__)
        return
    a, b = Path(argv[1]), Path(argv[2])
    sa, ta = load(a)
    sb, tb = load(b)
    print(f"A: {sa} {len(ta)}B   B: {sb} {len(tb)}B")
    print(f"status delta: {sb - sa}   length delta: {len(tb) - len(ta)}B")
    if sa != sb:
        print("!! status differs — strong signal")
    wa, wb = set(ta.split()), set(tb.split())
    only_b = sorted(wb - wa)[:40]
    only_a = sorted(wa - wb)[:40]
    if only_b:
        print("\n++ only in B:")
        for w in only_b:
            print("  ", w[:120])
    if only_a:
        print("\n-- only in A:")
        for w in only_a:
            print("  ", w[:120])


if __name__ == "__main__":
    main(sys.argv)
