#!/usr/bin/env python3
"""ids.py — classify identifier shape, which decides the IDOR attack.

Usage:
  py -3.14 SCRIPTS/ids.py 1 550e8400-e29b-11d4-a716-446655440000 dGVuYW50OjQy

Prints: shape, guessability, and the likely test order.
"""
from __future__ import annotations

import base64
import re
import sys
import uuid

RULES = [
    ("sequential-int", lambda s: s.isdigit() and len(s) <= 12,
     "trivial", "decrement/increment, check neighbours"),
    ("uuid4", lambda s: _uuid_v(s) == 4, "unguessable",
     "harvest from other surfaces, not brute force"),
    ("uuid1", lambda s: _uuid_v(s) == 1, "time-ordered",
     "recover timestamp, narrow the space, try siblings"),
    ("ulid", lambda s: bool(re.fullmatch(r"[0-9A-HJKMNP-TV-Z]{26}", s)),
     "time-ordered", "sort by time, take neighbours"),
    ("base64", lambda s: _is_b64(s), "decodable",
     "decode, look for id:tenant, re-encode a foreign value"),
    ("hash-hex", lambda s: bool(re.fullmatch(r"[0-9a-f]{16,64}", s)), "opaque",
     "look for the source value (email/id) and its hash function"),
    ("composite", lambda s: ":" in s or "|" in s or "_" in s, "structural",
     "swap one segment, keep the rest"),
    ("slug", lambda s: bool(re.fullmatch(r"[a-z0-9\-]{3,60}", s)), "guessable",
     "wordlist the pattern"),
]


def _uuid_v(s: str) -> int:
    try:
        return uuid.UUID(s).version
    except ValueError:
        return 0


def _is_b64(s: str) -> bool:
    if len(s) < 4 or len(s) % 4:
        return False
    try:
        raw = base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))
        return sum(32 <= c < 127 for c in raw) / max(len(raw), 1) > 0.8
    except Exception:
        return False


def main(argv: list[str]) -> None:
    if len(argv) < 2:
        print(__doc__)
        return
    for value in argv[1:]:
        print(f"\n{value[:80]}")
        matched = False
        for name, test, guess, action in RULES:
            try:
                if test(value):
                    print(f"  shape: {name}  guessability: {guess}")
                    print(f"  test: {action}")
                    matched = True
                    break
            except Exception:
                continue
        if not matched:
            print("  shape: unknown — treat as opaque, harvest from other surfaces")
        if _is_b64(value):
            try:
                print("  decoded:",
                      base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))[:120])
            except Exception:
                pass


if __name__ == "__main__":
    main(sys.argv)
