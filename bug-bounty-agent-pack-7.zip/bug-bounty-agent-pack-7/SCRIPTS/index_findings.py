#!/usr/bin/env python3
"""index_findings.py — build STATE/findings/INDEX.md from finding notes.

Reads the header block of each STATE/findings/F-*.md and emits a sorted table.
Stdlib only.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FIND = ROOT / "STATE" / "findings"
FIELD = re.compile(r"^-\s+\*\*(asset|class|status|severity \(draft\)|dup risk):\*\*\s*(.*)$")


def main() -> None:
    rows = []
    for p in sorted(FIND.glob("F-*.md")):
        data = {"id": p.stem, "asset": "-", "class": "-", "status": "-",
                "severity": "-", "dup": "-"}
        for line in p.read_text(encoding="utf-8", errors="ignore").splitlines()[:25]:
            m = FIELD.match(line)
            if m:
                key = m.group(1).split(" ")[0]
                data[key] = m.group(2).strip() or "-"
        rows.append(data)
    order = {"confirmed": 0, "probing": 1}
    rows.sort(key=lambda r: (order.get(r["status"], 9), r["id"]))
    out = FIND / "INDEX.md"
    lines = ["# Findings index", "",
             "| id | asset | class | severity | status | dup |", "|---|---|---|---|---|---|"]
    for r in rows:
        lines.append(f"| [{r['id']}]({r['id']}.md) | {r['asset']} | {r['class']} "
                     f"| {r['severity']} | {r['status']} | {r['dup']} |")
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"{len(rows)} findings indexed -> {out}")


if __name__ == "__main__":
    main()
