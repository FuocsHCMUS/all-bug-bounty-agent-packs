#!/usr/bin/env python3
"""jsx.py — pull endpoints, params and secret-shaped strings out of JS bundles.

Usage:
  py -3.14 SCRIPTS/jsx.py STATE/targets/<slug>/evidence/bundles/*.js

Stdlib only. Writes jsx-report.txt next to the first input.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

PATTERNS = {
    "endpoint": re.compile(r"""["'`](/[a-zA-Z0-9_\-./{}$:]{3,120})["'`]"""),
    "url": re.compile(r"""https?://[a-zA-Z0-9.\-]+(?:/[^\s"'`<>]{0,80})?"""),
    "param": re.compile(r"""[?&]([a-zA-Z_][a-zA-Z0-9_]{1,30})="""),
    "aws": re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"),
    "google": re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b"),
    "gh": re.compile(r"\bgh[pousr]_[0-9A-Za-z]{36,}\b"),
    "slack": re.compile(r"\bxox[baprs]-[0-9A-Za-z\-]{10,}\b"),
    "stripe": re.compile(r"\b(?:sk|pk)_(?:live|test)_[0-9A-Za-z]{16,}\b"),
    "jwt": re.compile(r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{5,}"),
    "flag": re.compile(r"""["'`](?:VITE_|REACT_APP_|NEXT_PUBLIC_|FEATURE_)[A-Z0-9_]+["'`]"""),
    "graphql": re.compile(r"\b(?:query|mutation|subscription)\s+[A-Za-z_][A-Za-z0-9_]*"),
    "route": re.compile(r"""["'`](/(?:api|internal|admin|v\d)/[^"'`]{0,80})["'`]"""),
}


def main(argv: list[str]) -> None:
    if len(argv) < 2:
        print(__doc__)
        return
    hits: dict[str, set[str]] = {k: set() for k in PATTERNS}
    files = []
    for raw in argv[1:]:
        p = Path(raw)
        if not p.is_file():
            continue
        files.append(p)
        text = p.read_text(encoding="utf-8", errors="ignore")
        for name, rx in PATTERNS.items():
            for m in rx.finditer(text):
                hits[name].add(m.group(0) if name != "param" else m.group(1))
    if not files:
        sys.exit("no readable input files")
    out = files[0].parent / "jsx-report.txt"
    with out.open("w", encoding="utf-8") as fh:
        for name, values in hits.items():
            fh.write(f"\n## {name} ({len(values)})\n")
            for v in sorted(values):
                fh.write(f"{v}\n")
    print(f"wrote {out}")
    for name, values in hits.items():
        print(f"{name:9} {len(values)}")


if __name__ == "__main__":
    main(sys.argv)
