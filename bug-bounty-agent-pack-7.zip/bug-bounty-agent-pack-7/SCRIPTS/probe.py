#!/usr/bin/env python3
"""probe.py — thin byte-exact HTTP client for replay and diffing.

Requires: httpx (pip install httpx, inside WORKSPACE venv).
Usage:
  py -3.14 SCRIPTS/probe.py --url https://t/api --method POST \
      --header 'Content-Type: application/json' --data '{"a":1}' \
      --proxy http://127.0.0.1:8080 --save STATE/targets/t/evidence/r1

Prints a one-line summary and stores raw request/response bytes.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--method", default="GET")
    ap.add_argument("--header", action="append", default=[])
    ap.add_argument("--data")
    ap.add_argument("--proxy")
    ap.add_argument("--save")
    ap.add_argument("--timeout", type=float, default=30.0)
    ap.add_argument("--follow", action="store_true")
    a = ap.parse_args()

    try:
        import httpx
    except ImportError:
        raise SystemExit("pip install httpx inside WORKSPACE/venv first")

    headers = {}
    for h in a.header:
        k, _, v = h.partition(":")
        headers[k.strip()] = v.strip()

    body = a.data.encode() if a.data else None
    with httpx.Client(proxy=a.proxy, timeout=a.timeout, follow_redirects=a.follow,
                      verify=False) as c:
        r = c.request(a.method, a.url, headers=headers, content=body)

    print(f"{r.status_code} {len(r.content)}B {r.http_version} "
          f"ct={r.headers.get('content-type', '-')}")

    if a.save:
        out = Path(a.save)
        out.parent.mkdir(parents=True, exist_ok=True)
        hdrs = "\r\n".join(f"{k}: {v}" for k, v in headers.items())
        (out.with_suffix(".req")).write_bytes(
            f"{a.method} {a.url} HTTP/1.1\r\n{hdrs}\r\n\r\n".encode()
            + (body or b""))
        (out.with_suffix(".resp")).write_bytes(
            f"HTTP/1.1 {r.status_code}\r\n".encode()
            + str(r.headers).encode() + b"\r\n\r\n" + r.content)
        (out.with_suffix(".meta.json")).write_text(
            json.dumps({"url": a.url, "method": a.method,
                        "headers": headers, "status": r.status_code,
                        "length": len(r.content)}, indent=2), encoding="utf-8")
        print(f"saved {out}.*")


if __name__ == "__main__":
    main()
