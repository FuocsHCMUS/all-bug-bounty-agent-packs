# SKILL.md — capability manifest

Front-matter style manifest so any agent runtime that parses skill files can load them.
Each entry: trigger → file → output artifact.

## Identity block

```yaml
name: bug-bounty-agent-pack
version: 7.0
role: senior-offensive-security-engineer
modes: [recon, hunt, exploit-craft, research, report, teach]
requires: python>=3.14, git, curl, a browser with devtools
optional: burp-suite, ffuf, nuclei, subfinder, amass, httpx, katana, mitmproxy
```

## Trigger table

| Trigger | Load | Produces |
|---|---|---|
| New program, no data | `SKILLS/01-scope-intake.md` | scope.md, target profile |
| Scope parsed | `SKILLS/02-recon-asset-discovery.md` | asset inventory |
| Assets known | `SKILLS/03-fingerprinting-attack-surface.md` | surface map, ranked |
| Surface mapped | `SKILLS/04-web-app-testing.md` | hypotheses |
| API / GraphQL present | `SKILLS/05-api-and-graphql.md` | schema, hypotheses |
| Login, token, OAuth, SAML | `SKILLS/06-auth-session-identity.md` | auth hypotheses |
| Objects with ids | `SKILLS/07-access-control-idor.md` | BOLA hypotheses |
| Input reaches parser | `SKILLS/08-injection-classes.md` | injection hypotheses |
| URL fetchers, webhooks, importers | `SKILLS/09-ssrf-cloud-metadata.md` | SSRF chain |
| Upload, export, archive, path | `SKILLS/10-file-handling.md` | file hypotheses |
| Rich client, postMessage, DOM sinks | `SKILLS/11-client-side-and-browser.md` | client hypotheses |
| Tokens, keys, crypto, config | `SKILLS/12-crypto-and-secrets.md` | secret findings |
| APK, IPA, Electron, desktop | `SKILLS/13-mobile-and-thick-client.md` | client findings |
| GitHub org, CI, registries | `SKILLS/14-cicd-supply-chain.md` | supply-chain findings |
| Hosts, ports, cloud, edge | `SKILLS/15-infra-network-edge.md` | infra findings |
| "What CVEs touch this stack" | `SKILLS/16-cve-research-pipeline.md` | cve briefs |
| Need new ideas | `SKILLS/17-writeup-and-ctf-mining.md` | technique cards |
| Idea has no prior art | `SKILLS/18-novel-technique-synthesis.md` | validated primitive |
| Confirmed bug | `SKILLS/19-exploit-craft-and-chaining.md` | impact chain |
| Chain built | `SKILLS/20-triage-and-report-writing.md` | report |
| Pre-submit | `SKILLS/21-duplicate-prediction-and-scoring.md` | dup risk score |
| Any confirmed finding | `SKILLS/22-company-security-posture-analysis.md` | posture.md |
| End of session | `SKILLS/23-learning-notes-for-student.md` | learning log |

## Modes

- **`recon`** — breadth. Cheap, parallel, read-only. Output is inventory, never findings.
- **`hunt`** — depth. Serial per surface. Output is hypotheses and proofs.
- **`craft`** — chain building, payload engineering, reliability work.
- **`research`** — CVE, writeup, CTF mining, synthesis. Runs when hunt stalls.
- **`report`** — writing, tightening, dedup checks.
- **`teach`** — learning notes and posture analysis. Runs alongside every other mode.

## Capability contracts

Each skill file declares: `Preconditions`, `Steps`, `Signals`, `Outputs`, `Failure modes`.
Skills are composable. A skill may hand off to any other skill; it may not hand off to a
report without a reproducer.

## Degradation

If a tool is missing, the skill must name a stdlib or browser-only fallback in a
`## Fallback` block and continue. Never stop the loop because `nuclei` is absent.
