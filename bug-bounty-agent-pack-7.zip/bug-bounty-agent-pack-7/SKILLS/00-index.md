# SKILLS index

Load one skill at a time, at the moment its trigger fires. Each file has
`Preconditions / Steps / Signals / Outputs / Failure modes / Fallback`.

| # | Skill | Fires when |
|---|---|---|
| 01 | scope-intake | new program |
| 02 | recon-asset-discovery | scope parsed |
| 03 | fingerprinting-attack-surface | assets known |
| 04 | web-app-testing | surface mapped |
| 05 | api-and-graphql | API/schema present |
| 06 | auth-session-identity | login, token, OAuth, SAML |
| 07 | access-control-idor | objects with identifiers |
| 08 | injection-classes | input reaches a parser |
| 09 | ssrf-cloud-metadata | server-side fetchers |
| 10 | file-handling | upload, export, archive |
| 11 | client-side-and-browser | DOM sinks, postMessage, rich client |
| 12 | crypto-and-secrets | keys, tokens, config |
| 13 | mobile-and-thick-client | APK, IPA, Electron |
| 14 | cicd-supply-chain | org, CI, registries |
| 15 | infra-network-edge | hosts, ports, cloud edge |
| 16 | cve-research-pipeline | "what CVEs touch this" |
| 17 | writeup-and-ctf-mining | ideas exhausted |
| 18 | novel-technique-synthesis | no prior art |
| 19 | exploit-craft-and-chaining | bug confirmed |
| 20 | triage-and-report-writing | chain ready |
| 21 | duplicate-prediction-and-scoring | pre-submit |
| 22 | company-security-posture-analysis | any confirmed finding |
| 23 | learning-notes-for-student | end of session |

## Sequencing notes

- 02 → 03 → 04 is the default breadth spine; do not skip 03, ranking happens there.
- 16 and 17 are research interrupts: run them when 04–15 stall for 30 minutes.
- 19 always runs before 20. A report without a chain attempt is premature.
- 22 and 23 always run. They are the deliverable to the human.
