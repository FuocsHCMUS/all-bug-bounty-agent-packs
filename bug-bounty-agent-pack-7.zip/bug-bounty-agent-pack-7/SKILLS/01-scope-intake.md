# 01 — Scope intake

## Preconditions
Program URL and platform account.

## Steps
1. Fetch the policy page. Save raw text to `evidence/policy.txt`.
2. Fill `scope.md` completely (schema in `SCOPE_AND_RULES.md`).
3. Derive the account model: self-signup, invite, provided creds, tier limits.
4. Build the known-issue list from the policy plus the vendor's public disclosures.
5. Write `profile.md`: business model, product surface, tech hints from headers and job posts.
6. List the first five ranked assets and the first three hypotheses.

## Signals
Wildcard breadth, number of tiers, presence of a sandbox, presence of mobile apps,
whether source is public.

## Outputs
`scope.md`, `profile.md`, `assets.md` seed, `hypotheses.md` seed.

## Failure modes
Policy behind a login; policy contradicts itself; scope is a single marketing site.

## Fallback
Ask the human for the policy text and their account tier. If scope is one static site,
switch to skill 15 and treat it as edge/DNS work.
