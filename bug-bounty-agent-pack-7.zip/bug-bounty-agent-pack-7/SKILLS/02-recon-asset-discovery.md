# 02 — Recon and asset discovery

## Preconditions
`scope.md` exists with in-scope patterns.

## Steps
1. Passive: crt.sh and Cert Spotter for subdomains; DNS history; ASN and netblock; Wayback
   and Common Crawl for URLs and parameters; GitHub org repos and Actions logs; npm/PyPI
   packages under the vendor scope; job posts naming internal tooling.
2. Active: resolve, probe HTTP/HTTPS on 80/443/8080/8443, grab titles and TLS SANs.
3. Pull JS bundles from every live host; extract endpoints, keys, feature flags.
4. Screenshot every live host into `evidence/shots/`.
5. Dedupe, tag by class (app, api, static, docs, admin, cdn, third-party).
6. Rank: reachability × privilege reachable × novelty × data value.

## Signals
`X-Powered-By`, `Server`, cookie names, `Set-Cookie` flags, redirect chains, 401 vs 403
vs 200 on the same path, framework-specific 404 pages.

## Outputs
`assets.md` with rank, class, evidence path. `WORKSPACE/NOTES.md` tool provenance.

## Failure modes
Wildcard DNS to a parking page; Cloudflare masking origin; rate-limit wall.

## Fallback
Certificate transparency via `crt.sh` JSON, `dig`/`nslookup`, and manual Wayback queries.
No fuzzers needed for a first pass.
