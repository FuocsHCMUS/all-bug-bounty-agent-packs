# 03 — Fingerprinting and surface mapping

## Preconditions
Live assets with response data.

## Steps
1. Identify stack per host: framework, ORM, auth provider, CDN, WAF, cloud, build tool
   fingerprints in HTML/JS.
2. Map auth: where sessions are issued, cookie flags, token storage, SSO provider, MFA.
3. Map roles: anonymous, user, member, admin, support, service. Note what each can reach.
4. Map data flows: upload → storage → render, form → queue → worker, webhook in/out.
5. Enumerate parameters per endpoint from archives, JS, and HTML forms.
6. Write the surface map with a trust-boundary column.

## Signals
GraphQL at `/graphql` or `/v1/graphql`; `/api/`, `/internal/`, `/admin/`; `swagger.json`;
`.map` files; `__NEXT_DATA__`; feature-flag endpoints; `/actuator/`.

## Outputs
`surface.md` with boundary column; ranked shortlist of 5.

## Failure modes
Everything behind SSO with no self-signup; heavy client-side rendering with no data in HTML.

## Fallback
Read the JS bundle for route tables — client routers leak the whole map.
