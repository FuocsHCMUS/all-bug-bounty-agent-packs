# 04 — Web application testing

## Preconditions
Ranked surface, at least one authenticated context.

## Steps
1. Walk the primary flows as the app intends, recording every request.
2. For each request, run the four questions: who authorizes this, what is the object,
   what is the state, what does it write.
3. Apply lenses A2, B1, C1, D3 to each flow.
4. Probe parameter semantics: add, remove, duplicate, reorder, change type.
5. Probe route semantics: trailing slash, case, extension, method swap, `..;/`.
6. Probe content negotiation: `Accept`, `Content-Type` swaps, JSON↔form↔XML.
7. Log hypotheses before each burst.

## Signals
Different body with same status; reflected parameter in an unexpected place; 200 with
empty array instead of 403; verbose validation errors.

## Outputs
`hypotheses.md` rows with lens ids, evidence for confirmed rows.

## Failure modes
WAF blocking payload shapes; SPA where state lives in the client.

## Fallback
Compare with the mobile API (skill 13) — it usually skips the WAF rules.
