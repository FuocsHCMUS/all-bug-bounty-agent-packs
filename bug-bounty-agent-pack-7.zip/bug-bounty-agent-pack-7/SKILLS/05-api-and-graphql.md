# 05 — API and GraphQL

## Preconditions
API base discovered; at least one token.

## Steps
1. Fetch `/openapi.json`, `/swagger.json`, `/v2/api-docs`, `/graphql` introspection.
2. Enumerate operations, then for each: required scope, object type, write vs read.
3. Test BOLA on every operation taking an id (skill 07).
4. Test mass assignment: send fields the schema marks read-only.
5. GraphQL specifics: alias batching, fragment recursion, `__typename` probing,
   depth/cost limits, field-level authz, nested BOLA, mutations with object ids,
   introspection-off fallback via field suggestion errors.
6. Test pagination and filter injection: `first`, `after`, `order`, `where`, `search`.
7. Check for a second, older API version still routed.

## Signals
Field suggestions in errors, `"data": null` with errors, inconsistent authz between
list and single-object queries, `@deprecated` fields still resolvable.

## Outputs
`schema.md`, hypotheses with object graph.

## Failure modes
Introspection disabled and no schema leak.

## Fallback
Crawl the SPA for operation names; GraphQL operation names appear in JS verbatim.
