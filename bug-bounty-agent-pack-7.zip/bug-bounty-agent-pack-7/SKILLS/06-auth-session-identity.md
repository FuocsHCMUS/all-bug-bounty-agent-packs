# 06 — Auth, session, identity

## Preconditions
Login flow, token issuance, and at least two accounts.

## Steps
1. Map the full auth state machine: register → verify → login → MFA → session → refresh
   → logout → reset.
2. For each transition, test: skip, repeat, reverse, interleave with a second account.
3. Session: cookie flags, rotation on privilege change, fixation, concurrent sessions,
   logout invalidation scope.
4. JWT: `alg` handling, `kid` path traversal, `jku`/`x5u` SSRF, claim trust, `sub` swap,
   expiry enforcement server-side, `aud`/`iss` checks.
5. OAuth/OIDC: `redirect_uri` matching (prefix, path traversal, subdomain, open redirect),
   `state` CSRF, PKCE downgrade, implicit flow, `response_mode`, token in fragment.
6. SAML: signature wrapping, XSW variants, comment truncation, unsigned assertion,
   `Recipient`/`Audience` validation, XXE in metadata.
7. Password reset: token entropy, host header poisoning, reset-link reuse, email
   case/unicode tricks, reset while session active.
8. MFA: enrollment without re-auth, disable without re-auth, backup-code reuse,
   race on code verification, response manipulation on the verify step.

## Signals
Token in URL, no rotation after email change, `redirect_uri` accepts a prefix,
`alg:none` accepted, reset token in the Referer.

## Outputs
`auth-map.md`, hypotheses, evidence per confirmed step.

## Failure modes
MFA enforced everywhere with no bypass surface; hardware-key-only accounts.

## Fallback
Test the mobile auth flow — often a separate, older implementation.
