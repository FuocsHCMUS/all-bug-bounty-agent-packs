# 07 — Access control and IDOR/BOLA

## Preconditions
Two accounts on different tiers/tenants; object identifiers observed.

## Steps
1. Classify identifiers: sequential, UUID, ULID, hash, composite (`org:item`), path-encoded.
2. Build the object graph: which object contains which, which grants which.
3. For each object endpoint, run the matrix: own / other-user / other-tenant / deleted /
   unverified / archived — across read, list, update, delete, share, export.
4. Test id substitution in body, path, query, header, and nested relation
   (`/orgs/1/users/2` with mismatched pair).
5. Test verb confusion: `PUT` on a read route, `PATCH` with partial body, `DELETE` on a
   collection member without ownership check.
6. Test bulk endpoints with mixed-ownership id arrays — partial results leak existence.
7. Test parent-child reassignment: move object to another org, then read as the new owner.

## Signals
200 with another user's data; 403 on list but 200 on item; different error strings for
"not found" vs "forbidden" (existence oracle).

## Outputs
Matrix table in `evidence/<id>/matrix.md`, hypotheses, chain notes.

## Failure modes
All ids are opaque and authz is centralized in a middleware.

## Fallback
Look for a GraphQL layer — field resolvers frequently miss the middleware.
