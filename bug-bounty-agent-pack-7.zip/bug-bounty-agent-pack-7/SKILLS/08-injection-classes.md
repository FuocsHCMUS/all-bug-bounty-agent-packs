# 08 — Injection classes

## Preconditions
Input reaching a parser, with a stable baseline response.

## Steps
1. Determine the sink type from behavior: SQL, NoSQL, LDAP, template, command, expression,
   XPath, header, log, ORM `where`, search DSL.
2. Baseline: boolean true, boolean false, syntax error, time delay. Record all four.
3. SQL: `'`, `''`, `\`, `'--`, numeric context, `ORDER BY` position, `LIKE` wildcards,
   `LIMIT` injection, stacked queries where supported, second-order via stored value.
4. NoSQL: `{"$ne":null}`, `{"$gt":""}`, `{"$regex":"^a"}`, array wrapping, `$where`.
5. Template (SSTI): `${7*7}`, `{{7*7}}`, `<%= 7*7 %>`, `#{7*7}`, `*{7*7}`, then
   engine-specific escalation.
6. Command: `;id`, `|id`, `$(id)`, backticks, newline, Windows `& whoami`.
7. LDAP: `*)(uid=*`, `)(|(uid=*`, null byte.
8. Expression/SpEL/OGNL: `T(java.lang.Runtime)`, `@java.lang.Runtime@`.
9. Blind variants: time, boolean, out-of-band (DNS/HTTP callback).

## Signals
Time delta over 3s, error text change, response length change, callback hit.

## Outputs
`evidence/<id>/payloads.txt` with result per payload.

## Failure modes
WAF normalizing payloads; ORM parameterizing everything.

## Fallback
Second-order: store the payload, trigger the consumer (report, export, admin view).
