# 09 — SSRF and cloud metadata

## Preconditions
A server-side fetcher: URL import, webhook, avatar, PDF, RSS, proxy, preview, OAuth jku.

## Steps
1. Confirm outbound: point at a collaborator host, check DNS and HTTP hit.
2. Classify: full URL control, host-only, path-append, scheme-restricted.
3. Bypass host allowlists: `127.0.0.1`, `127.1`, `0.0.0.0`, `[::1]`, `2130706433`,
   `0177.0.0.1`, `localtest.me`, `127.0.0.1.nip.io`, DNS rebinding.
4. Bypass path allowlists: `@`, `#`, `?`, `..;/`, double-encode, redirect chains,
   `http://allowed.com@evil.com`, `http://evil.com/allowed.com`.
5. Cloud metadata: AWS `169.254.169.254/latest/meta-data/iam/security-credentials/`,
   IMDSv2 token flow, GCP `metadata.google.internal/computeMetadata/v1/`,
   Azure `169.254.169.254/metadata/instance?api-version=2021-02-01` with `Metadata: true`.
6. Internal services: Redis `dict://`, gopher where allowed, Docker `2375`, k8s API,
   Elasticsearch, Prometheus, `/actuator/env`.
7. Escalate: metadata creds → cloud API enumeration → bucket or role abuse.

## Signals
Different body length on internal vs external target; TLS errors naming an internal host;
redirect followed to an internal address.

## Outputs
`evidence/<id>/chain.md` with each hop and the credential material found.

## Failure modes
Egress-proxied fetcher with strict allowlist; response not returned (blind only).

## Fallback
Blind SSRF still matters: use it to hit internal-only state changers (cache purge, job
trigger) and prove impact by side effect.
