# 10 — File handling

## Preconditions
Upload, import, export, archive, or path-parameterized download.

## Steps
1. Upload: extension vs content-type vs magic bytes — which is enforced, and where.
2. Filename: traversal (`../`), absolute path, `..\` on Windows, unicode dot, null byte,
   trailing dot/space, overlong name, `;` params.
3. Content: polyglot (GIF+PHP, SVG+JS), `Content-Type` override, `Content-Disposition`
   injection, ZIP with nested traversal (zip-slip), symlink entries, XXE in SVG/DOCX/XLSX.
4. Storage: is the file served from the app origin, a CDN, or S3? Same-origin serving of
   HTML/SVG = stored XSS. Guessable object keys = enumeration.
5. Import parsers: CSV formula injection (`=cmd|' /C calc'!A0`), CSV delimiter confusion,
   XML external entities, JSON depth, huge row counts.
6. Export: does it leak other tenants' rows, or include fields the UI hides?
7. Delete/replace: does replacing keep the old key live? Does delete orphan the CDN copy?

## Signals
File served with `text/html` or `image/svg+xml` from the app origin; original filename
reflected in a header; predictable storage key.

## Outputs
`evidence/<id>/files/` with the payloads and their served URLs.

## Failure modes
Signed-URL-only CDN with `Content-Disposition: attachment` everywhere.

## Fallback
Target the import parser instead of the storage layer.
