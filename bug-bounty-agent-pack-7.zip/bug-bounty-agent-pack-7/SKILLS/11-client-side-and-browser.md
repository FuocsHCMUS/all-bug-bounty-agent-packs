# 11 — Client-side and browser

## Preconditions
Rich client, postMessage, DOM sinks, or an extension.

## Steps
1. Grep bundles for sinks: `innerHTML`, `outerHTML`, `document.write`, `insertAdjacentHTML`,
   `eval`, `new Function`, `srcdoc`, `dangerouslySetInnerHTML`, `v-html`.
2. Trace sources to sinks: `location`, `document.referrer`, `postMessage`, `localStorage`,
   `name`, `opener`, hash, query.
3. postMessage: origin check present? `*` target? sensitive action on message? wildcard
   listener on a page that can be framed?
4. DOM XSS: test `#` and `?` payloads against each sink, including `javascript:` in
   href builders and `data:` in iframes.
5. Prototype pollution: `__proto__`, `constructor.prototype` via merge/query parsers, then
   look for a gadget that reads the polluted key.
6. Client storage: tokens in `localStorage`, PII in IndexedDB, stale session after logout.
7. CSP: report-only? `unsafe-inline`? missing `object-src`? JSONP or CDN allowlisted with
   a takeover-able host?
8. Clickjacking with a real action (not just a missing header) — one-click payout, one-click
   key reveal.

## Signals
Reflected hash value in a template; `postMessage` handler without `event.origin` check;
`innerHTML` on a server-supplied string.

## Outputs
`evidence/<id>/` with the URL, the DOM state, and the executed marker.

## Failure modes
Fully server-rendered with escaping everywhere; strict CSP with nonces.

## Fallback
Hunt the sink reachable from the `Referer` — it crosses origins.
