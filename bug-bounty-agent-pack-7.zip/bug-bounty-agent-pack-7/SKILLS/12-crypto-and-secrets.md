# 12 — Crypto and secrets

## Preconditions
Bundles, configs, mobile binaries, or tokens in hand.

## Steps
1. Grep everything for key shapes: `AKIA`, `ASIA`, `AIza`, `ghp_`, `xox[baprs]-`,
   `sk_live_`, `SG.`, `-----BEGIN`, `eyJ` (JWT), `mongodb+srv`, `postgres://`.
2. Test each candidate key against its service (read-only calls).
3. Classify: public (maps, analytics) vs privileged (server, storage, mail).
4. Crypto in the app: ECB patterns, static IV, `Math.random()` for tokens, MD5 for
   passwords, homebrew XOR, predictable reset tokens, timing-unsafe comparisons.
5. TLS and headers: HSTS on the apex, mixed content, `Secure`/`SameSite` on cookies,
   `__Host-` prefix misuse.
6. Signing: client-side signature checks bypassed by patching; server trusting a client
   hash; HMAC key in the binary.

## Signals
`AIza` (Google) with Maps *and* other APIs enabled; JWT signed with a key found in the bundle;
`Math.random()` feeding a coupon or token.

## Outputs
`secrets.md` with key, source, service, capability, blast radius.

## Failure modes
Keys rotated and short-lived; everything behind a BFF.

## Fallback
Check git history and old bundle versions for keys removed from the current build.
