# 13 — Mobile and thick client

## Preconditions
APK/IPA or Electron/desktop build in scope.

## Steps
1. Extract: `apktool d`, `jadx`, `unzip` the IPA, `asar extract` for Electron.
2. Read `AndroidManifest.xml` / `Info.plist`: exported components, deep-link schemes,
   `usesCleartextTraffic`, ATS exceptions, custom URL handlers.
3. Pull strings, endpoints, and keys. Diff against the web API surface — the mobile API is
   usually broader and less guarded.
4. Test deep links: parameter injection into a WebView, `intent://` redirects, OAuth
   callback hijack via a competing scheme.
5. Test the API as the app does: mobile UA, `X-Client-Version`, older version numbers to
   unlock legacy behavior.
6. Storage: `SharedPreferences`, Keychain accessibility class, plaintext tokens on disk.
7. Root/jailbreak checks: what changes if the check is bypassed (often nothing — that is
   a finding about their threat model).
8. Electron: `nodeIntegration`, `contextIsolation`, `webSecurity`, custom protocol handlers,
   `shell.openExternal` with attacker input.

## Signals
`android:exported="true"` with an intent filter; hardcoded staging host; version-gated
behavior returning more fields on old versions.

## Outputs
`client.md`, endpoint diff vs web, hypotheses.

## Failure modes
Obfuscated with string encryption; certificate pinning (note it, work around with a
patched build in `WORKSPACE/`).

## Fallback
Run the app under mitmproxy with a Frida unpinning script in `WORKSPACE/`.
