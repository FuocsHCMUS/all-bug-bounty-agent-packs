# 14 — CI/CD and supply chain

## Preconditions
Public org, repos, package names, or registry presence.

## Steps
1. Enumerate org repos, forks, and Actions workflows. Look for `pull_request_target` with
   checkout of PR head, `workflow_run` chains, and secret usage in forks.
2. Check for self-hosted runner labels on public repos — a PR that runs on a runner is code
   execution on their infra.
3. Package hygiene: dependency confusion (internal scope names unclaimed on npm/PyPI),
   typosquat candidates, `postinstall` in deps, lockfile absence.
4. Artifact trust: unsigned releases, `curl | bash` installers over HTTP, checksum files
   hosted on the same origin.
5. Registry permissions: can you publish to a namespace the vendor uses? Is the scope public?
6. CI logs: leaked env vars, `set -x` with secrets, artifact URLs without auth.
7. Container images: `latest` tags, root user, secrets baked in layers.

## Signals
`pull_request_target` + `actions/checkout` with `ref: ${{ github.event.pull_request.head.sha }}`;
internal package scope with no public registry entry.

## Outputs
`supply.md` with the exploitable path and required precondition (usually a merged PR).

## Failure modes
Private everything; branch protection with required review.

## Fallback
Dependency confusion still works if the internal scope is unclaimed — that is a
configuration finding, not a code finding.
