# 15 — Infrastructure, network, edge

## Preconditions
Hosts and netblocks in scope.

## Steps
1. Port and service discovery on in-scope IPs only.
2. Identify edge: CDN, WAF, load balancer, origin exposure (direct-IP bypass of the WAF).
3. Subdomain takeover: dangling CNAME to S3, Azure, Heroku, GitHub Pages, Fastly, Netlify,
   Vercel, ReadTheDocs, Surge, Unbounce. Verify by claiming, not by banner alone.
4. DNS: zone transfer, wildcard behavior, `NS`/`MX`/`TXT` hygiene, SPF `~all` vs `-all`,
   DMARC `p=none`, dangling TXT verification records.
5. Cloud storage: bucket naming from the brand, list permissions, ACLs, website endpoints.
6. Non-HTTP: FTP, Redis, Elasticsearch, Docker, k8s API, Jenkins, Grafana, Kibana on
   in-scope hosts.
7. TLS: expired, weak protocols, SAN overreach, wildcard on a shared host.
8. Default creds on exposed admin panels (Grafana, Jenkins, RabbitMQ, Tomcat manager).

## Signals
`Server: AmazonS3` with `NoSuchBucket`; CNAME to `*.herokudns.com` returning 404;
`X-Powered-By` on an admin port.

## Outputs
`infra.md`, takeover candidates with verification steps.

## Failure modes
Everything behind Cloudflare with no origin leak; strict egress.

## Fallback
Historical DNS and certificate records to find pre-CDN origins.
