# 17 — Writeup and CTF mining

## Preconditions
A stalled surface or a class you want to sharpen.

## Steps
1. Pick the class, not the vendor. Search for recent writeups of that class.
2. Read for the *primitive*, not the payload: what property of the system did it abuse?
3. Extract: precondition, primitive, bypass technique, detection difficulty.
4. Write a `TEMPLATES/technique-card.md` with the product names stripped out.
5. Map the primitive onto your current target's equivalent component.
6. Check CTF archives for the same primitive in a harder variant — CTFs are where the
   technique is pushed past what production allows.
7. Note the anti-technique: what defense kills it, and whether the target has that defense.

## Signals
A primitive that generalizes across three unrelated products is worth keeping.

## Outputs
Technique cards in `STATE/techniques/`, hypotheses referencing card ids.

## Failure modes
Writeups that only show payloads with no reasoning; paywalled posts.

## Fallback
Read the patch commits of the products involved — they describe the same bug precisely.
