# 18 — Novel technique synthesis

## Preconditions
A primitive with no satisfying prior art.

## Steps
1. State the primitive in one sentence with no product names.
2. Reduce to the smallest rig: two components, one boundary, one controllable input.
3. Enumerate the invariant the developer believes holds. Break exactly that.
4. Generate five variants by mutating one dimension at a time: encoding, order, type,
   timing, identity.
5. Run the falsification protocol (`CREATIVE_OFFENSIVE_THINKING.md`).
6. If it survives, generalize: which other boundary shapes does the primitive fit?
7. Write the technique card only after the third successful reproduction.
8. Search for prior art *now*, and record the delta honestly.

## Signals
The technique survives a different account, a different browser, and a cold session.

## Outputs
`TEMPLATES/technique-card.md`, a working rig in `WORKSPACE/rigs/<name>/`.

## Failure modes
The primitive only works because of an unrelated caching quirk; it is not general.

## Fallback
Publish it as a "case note" rather than a technique — still valuable, honestly labeled.
