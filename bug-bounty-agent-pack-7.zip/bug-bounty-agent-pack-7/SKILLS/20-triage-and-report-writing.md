# 20 — Triage and report writing

## Preconditions
Working chain, evidence folder, dup score.

## Steps
1. Title: asset + class + impact. No adjectives.
2. First paragraph: what an attacker gets, in one sentence, with the number of accounts
   or the data class.
3. Severity with the CVSS vector, then a one-line justification for each metric that is
   not obvious.
4. Preconditions: accounts, roles, config, browser.
5. Reproduction: numbered, copy-pasteable, minimal. Raw request blocks for API bugs.
6. Evidence: the request/response pair, the marker, the timestamps.
7. Impact: the ladder, trimmed to what you proved.
8. Fix: the specific change, plus the systemic fix. Name the file/function if you know it.
9. References: the CWE, the analogous public case, the framework doc.
10. Read it aloud once. Cut every "potentially".

## Signals
A triager can reproduce without asking a question — that is the bar.

## Outputs
`STATE/findings/<id>.md`, submitted report text.

## Failure modes
Impact depends on a config you cannot see; the vendor's template forces fields you lack.

## Fallback
Add an "Assumptions" section listing what you could not verify, and say what you would
need to verify it.
