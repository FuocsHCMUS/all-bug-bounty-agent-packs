# 21 — Duplicate prediction and scoring

## Preconditions
Report draft ready.

## Steps
1. Search the vendor's public disclosures for the same class on the same asset family.
2. Search general writeups for the same endpoint pattern.
3. Age check: how old is the endpoint? Old + obvious = high dup risk.
4. Depth check: is this first-order (low) or does it need a non-obvious precondition (low)?
5. Score 0–10 across: recency of similar reports, obscurity of the surface, precondition
   difficulty, impact uniqueness.
6. Score ≥7 → specialize before submitting: harder surface, or add a chain hop.
7. Record the score in the report's internal header (not the submitted text).

## Signals
The class appears in the vendor's "known issues" list but on a different asset — that is
a sibling, usually still valid.

## Outputs
`dup-score.md` with the four sub-scores and the decision.

## Failure modes
Vendor discloses nothing publicly; you are guessing.

## Fallback
Submit anyway, but lead with the unusual precondition so the triager sees the delta fast.
