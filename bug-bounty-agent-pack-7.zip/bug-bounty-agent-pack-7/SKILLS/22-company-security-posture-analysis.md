# 22 — Company security posture analysis

## Preconditions
At least one confirmed finding.

## Steps
1. Score nine domains 0–5 (0 absent, 5 strong): input handling, authz design, auth/session,
   secret management, transport/headers, logging and detection, SDLC and review, dependency
   hygiene, cloud/infra config.
2. For each domain, cite the concrete evidence — a finding, an observation, a header, a
   commit pattern. No evidence, no score.
3. Write the top three strengths as precisely as the weaknesses. Strength is also
   diagnostic: it shows where they invested.
4. Rank risks: `high` (exploitable now, data loss), `elevated` (needs a precondition),
   `structural` (design-level, will recur).
5. Derive the systemic fix per risk: the lint rule, the middleware, the test, the review
   gate — not just the patch.
6. Note the detection gap: for each risk, what would have caught it, and does that alert
   plausibly exist.

## Outputs
`posture.md` per `TEMPLATES/posture-report.md`.

## Failure modes
Small surface yields thin evidence — say so and score with wider error bars.

## Fallback
Score only the domains you have evidence for; leave the rest `unknown`, never guess.
