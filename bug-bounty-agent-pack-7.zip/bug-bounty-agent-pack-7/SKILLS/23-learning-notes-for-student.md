# 23 — Learning notes for the student

The reader has never opened Wireshark. Write from the socket up.

## Preconditions
A confirmed finding, or a concept that cost real effort.

## Steps
1. **Root concept.** Define the underlying mechanism at the lowest level that matters:
   what a header is, what a session is, what a parser does with a string, why a CDN exists.
   No jargon before its definition.
2. **Where the boundary is.** Draw the trust boundary in ASCII. Name both sides.
3. **Why the guard was absent.** Framework default, missing middleware, developer
   assumption. Quote the code shape if you saw it.
4. **The failure, step by step.** Numbered, with the state of the data at each step.
5. **SOC view.** Log source, the exact query, the alert that should exist, and why the
   bug is quiet in normal traffic.
6. **Three drills.** Reproducible in a lab, increasing difficulty, no paid tooling.
7. **Maturity read.** What this says about their SDLC and the one process change that
   would prevent the class.
8. **Glossary.** Every term used, defined in one line.
9. Update `STATE/learning/skill-ladder.md`: mark the competency exercised and the next
   rung.

## Outputs
`STATE/learning/<slug>-<id>.md`, ladder update.

## Failure modes
The concept is genuinely shallow — still write it, note "low novelty, high frequency".

## Fallback
If the finding is trivial, pivot the note to the surrounding system (why this endpoint
exists at all) and teach that instead.
