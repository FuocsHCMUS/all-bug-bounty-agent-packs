# STATE

Working memory. Survives context loss.

```
STATE/
├── targets/<slug>/
│   ├── scope.md  profile.md  surface.md  posture.md
│   ├── hypotheses.json      (managed by SCRIPTS/bb.py)
│   ├── evidence/<finding-id>/
│   └── notes/
├── findings/F-*.md          one per finding
├── learning/                learning notes + skill-ladder.md
└── techniques/              technique cards
```

Rules: never overwrite a capture, always append. Hash evidence files in a `manifest.txt`
inside the finding's evidence folder.
