# F-001 — Example: order export honours `org_id` from the body

- **asset:** api.example.tld
- **class:** BOLA
- **lens:** B1, C1
- **boundary crossed:** tenant → tenant
- **status:** confirmed
- **dup risk:** 3/10
- **severity (draft):** High

## Hypothesis
`POST /v2/exports` builds the export from the `org_id` in the JSON body and never compares
it to the session's org.

## Test
1. As org A, `POST /v2/exports {"org_id":"A","type":"orders"}` → 202.
2. Same request with `"org_id":"B"` → 202, and the resulting file contains B's orders.

## Signal
Foreign order ids present in the CSV, confirmed against B's UI.

## Impact
Any user of any tenant can export every other tenant's order data: names, addresses, totals.

## Chain ideas
Export → harvested customer emails → password reset enumeration.
