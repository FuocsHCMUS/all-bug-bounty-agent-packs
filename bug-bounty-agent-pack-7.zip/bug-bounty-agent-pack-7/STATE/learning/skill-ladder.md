# Skill ladder

Mark each competency `none | seen | drilled | taught`. Next rung = lowest score.

| Competency | State | Next rung |
|---|---|---|
| HTTP request anatomy | none | label every header in a capture |
| TLS and proxying | none | install a CA in a throwaway profile |
| Session mechanics | none | build and break a session yourself |
| Authz design | none | read a middleware, find the gap |
| Parser differentials | none | send one string to two parsers |
| Race conditions | none | single-packet attack on a lab |
| Cloud metadata | none | reach IMDS through a proxy lab |
| JS bundle analysis | none | map a SPA's routes from its bundle |
| Mobile client | none | unpin and intercept an app |
| CI supply chain | none | trigger a workflow on a fork |
| Report writing | none | get one report accepted first try |
| Detection engineering | none | write a Sigma rule for your last bug |
| Teaching | none | write a note a beginner finishes |
