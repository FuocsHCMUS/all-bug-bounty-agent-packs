# F-<nn> — <short title>

- **asset:**
- **class:**
- **lens:**
- **boundary crossed:**
- **status:** probing | confirmed | reported
- **dup risk:** /10
- **severity (draft):**

## Hypothesis
One sentence, testable.

## Test
Requests, in order, with results.

## Signal
What confirmed it. Marker, delta, or callback.

## Impact
Who loses what.

## Chain ideas
Next rung, and what capability it needs.

## Dead ends inside this finding
What did not work, so it is not retried.
