# Learning note — <concept>

> Written for a reader who has never opened Wireshark.

## 1. The root concept
Start below the abstraction. Define every term before using it.

## 2. The boundary
```
[untrusted] --(X)--> [trusted]
```
Name both sides and what crosses.

## 3. Why the guard was absent
Framework default, missing middleware, developer assumption. Quote the code shape.

## 4. The failure, step by step
Numbered, with the data state at each step.

## 5. SOC view
- Log source:
- Query:
- Alert that should exist:
- Why it is quiet in normal traffic:

## 6. Drills
1. easy
2. medium
3. hard

## 7. Maturity read
What this says about the SDLC, and the one process change that prevents the class.

## 8. Glossary
term — one-line definition.
