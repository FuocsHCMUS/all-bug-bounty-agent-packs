# Posture analysis — <company>

Evidence base: <n> findings, <m> observations, <date range>.

## Scores (0 absent – 5 strong)

| Domain | Score | Evidence |
|---|---|---|
| Input handling | | |
| Authorization design | | |
| Auth and session | | |
| Secret management | | |
| Transport and headers | | |
| Logging and detection | | |
| SDLC and review | | |
| Dependency hygiene | | |
| Cloud and infra config | | |

## Strengths (be as precise as with weaknesses)
1. …

## Risks

### High — <name>
- Evidence:
- Exploit path:
- Systemic fix:
- Detection gap:

### Elevated — <name>
…

### Structural — <name>
…

## Maturity read
Where they are on the crawl→walk→run curve, and the single process change with the
highest leverage.

## What a SOC would need to catch this
Log sources, queries, alerts that do not exist yet.
