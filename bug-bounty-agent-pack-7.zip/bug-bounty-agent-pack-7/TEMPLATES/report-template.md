# <Asset> — <Class> leading to <Impact>

**Severity:** <Critical|High|Medium|Low> — CVSS `AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:N` (7.2)

**Dup risk (internal):** 4/10

## Summary
One paragraph. What an attacker gets, how many accounts, what data or action. No adjectives.

## Preconditions
- Account: <tier, role>
- Config: <feature flag, setting>
- Browser/client: <if relevant>

## Steps to reproduce
1. …
2. …
3. …

```http
POST /api/v2/... HTTP/1.1
Host: target.tld
Authorization: Bearer <token>

{"...":"..."}
```

**Expected:** …
**Actual:** …

## Evidence
- `evidence/<id>/req.txt`, `resp.txt` (hashes in `manifest.txt`)
- Marker observed: `<value>` at `<timestamp>`
- Second cold run: pass/fail

## Impact
Ladder, trimmed to what is proven:
- Direct: …
- Chained: … (requires …)
- Blast radius: N accounts / data class / reversibility

## Root cause
Named boundary and the missing guard. File/function if known.

## Fix
1. Specific: …
2. Systemic: lint rule / middleware / test / review gate.

## References
- CWE-…
- <analogous public case>
- <framework doc>

## Assumptions
What could not be verified and what would verify it.
