# Scope — <program>

- **program:** <name>
- **platform:** <h1|bc|intigriti|direct|vdp>
- **policy_url:** <url>
- **auth_model:** <self-signup|invite|provided|none>
- **rate_limit:** <stated or measured>
- **disclosure:** <private|coordinated|public>

## In scope
- …

## Out of scope
- …

## Known issues
- …

## Payout table
| class | range |
|---|---|

## Notes and quirks
- …
