# Target profile — <program>

## Business
What they sell, who pays, what data they hold, what a breach costs them.

## Surface classes
- app: …  api: …  admin: …  docs: …  mobile: …  infra: …  repos: …

## Auth model
Registration, tiers, SSO, MFA, invite flow, service accounts.

## Stack hints
Headers, cookies, framework errors, JS build tool, cloud, CDN, WAF.

## Recent change
Last release notes, last public disclosure, last job post naming tooling.

## Highest-value assets
1. …
2. …
3. …

## Known issues (do not resubmit)
- …
