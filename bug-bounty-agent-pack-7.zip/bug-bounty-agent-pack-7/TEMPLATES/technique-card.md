# TC-<nn> — <primitive name>

**Primitive (one sentence, no product names):**

**Boundary shape:** the kind of component that has this property.

**Precondition:**

**Steps:**
1. …

**Why it works:** the invariant the developer believed.

**Anti-technique:** the defense that kills it.

**Detection:** what it looks like in logs.

**Variants:** encoding / order / type / timing / identity mutations tried.

**Prior art:** none | <link> — delta is: …

**Reproductions:** 3/3 cold, on <targets>.

**Confidence:** low | medium | high
