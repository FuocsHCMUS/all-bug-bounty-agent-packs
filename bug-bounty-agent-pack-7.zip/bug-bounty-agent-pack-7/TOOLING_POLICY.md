# TOOLING_POLICY.md — install protocol

## Core rule

**Portable → just do it. Persistent → ask first.**

"Portable" means it can live entirely inside `WORKSPACE/` and be deleted with the folder:
git clone, single static binary, Go/Rust build, pip package in a local venv, JS file
loaded by a headless browser.

"Persistent" means it touches the host: winget/choco/MSI installers, Docker Desktop,
services, PATH edits, registry, browser extensions, global pip, MCP servers, IDE plugins,
scheduled tasks.

## Ask format

```
INSTALL ASK
what: ffuf (static binary, 8 MB)
why:  parameter fuzzing on /api/v2/* — nothing portable covers it
cmd:  curl -L -o WORKSPACE/bin/ffuf.exe <release-url>
if no: ffuf.py fallback at half speed
```

Wait for a yes. Batch multiple asks into one message. Never ask twice for the same thing
in a session.

## Always allowed without asking

- `git clone` into `WORKSPACE/tools/`
- `pip install` into `WORKSPACE/venv`
- writing scripts in `SCRIPTS/` or `WORKSPACE/`
- downloading wordlists into `WORKSPACE/wordlists/`
- `npx`/`uvx` one-shots that cache in user space and install nothing permanent
- reading anything local

## Ask-first list (examples, not exhaustive)

- winget / choco / scoop installs
- Docker Desktop, WSL distro install
- Burp Suite, mitmproxy, Fiddler as system CA
- global `pip install`, `npm -g`
- any MCP server (also list the config block you would add)
- IDE plugins, browser extensions, VS Code extensions
- Python versions, Node versions, SDKs
- anything requiring admin/UAC

## Directory contract

```
WORKSPACE/
├── bin/          static binaries (gitignored)
├── tools/        cloned repos (gitignored)
├── venv/         python venv (gitignored)
├── wordlists/    SecLists subset, custom lists
├── captures/     pcaps, HAR, raw dumps
└── NOTES.md      what is installed, version, source URL, date
```

`WORKSPACE/NOTES.md` is the provenance record. Every clone/binary gets a line. It is how
the next session knows what exists without re-downloading.

## Python 3.14 on Windows 11

- Interpreter: `py -3.14`. Verify with `py -3.14 -V` before any script run.
- venv: `py -3.14 -m venv WORKSPACE\venv` → `WORKSPACE\venv\Scripts\activate`
- Missing libs: `pip install <pkg>` inside the venv, no ask needed. Pin in
  `WORKSPACE/requirements.txt`.
- Unicode output: `py -3.14 -X utf8 script.py` or `PYTHONUTF8=1`.
- Long paths: `git config --global core.longpaths true` (ask once), keep depth shallow.
- Prefer stdlib: `urllib.request`, `http.client`, `json`, `re`, `pathlib`, `hashlib`,
  `concurrent.futures`, `ssl`, `socket`, `zipfile`, `base64`, `argparse`.
- Third-party when it earns it: `httpx`, `requests`, `beautifulsoup4`, `lxml`,
  `dnspython`, `pyjwt`, `cryptography`, `playwright`.
- Free-threaded build (`py -3.14t`) is fine for I/O fan-out; measure before trusting it.
- Never assume `curl` flags match Linux. Windows `curl.exe` exists but `-k`/`--path-as-is`
  behavior differs; prefer `httpx` or a raw socket when byte-exactness matters.

## MCP proposals

Propose with: name, what it unlocks, config snippet, and the fallback if refused.
High value: chrome-devtools-mcp (DOM, network, console), playwright-mcp (scripted browser
state), burp-mcp (proxy history into context), filesystem, memory, sqlite (findings index),
fetch (raw HTTP with byte control).

## Proxy discipline

- Default: Burp at `127.0.0.1:8080` for manual work; scripts use `--proxy` explicitly.
- Scope filter in Burp mirrors `scope.md`. If a host is not in the filter, the request is
  probably out of scope — verify before reporting.
- Install the Burp CA into the test browser profile only, never system-wide without asking.

## Cleanup

At target close: `WORKSPACE/tools/*` stays (reusable), `WORKSPACE/captures/` pruned to
evidence-backed files, `NOTES.md` updated. Nothing persistent is removed without asking.
