# WF-01 — New target, day one

1. Skill 01. Scope, profile, known issues. 20 min.
2. Skill 02 passive only. Certificates, DNS history, archives, org repos. 40 min.
3. Skill 03 on the top five assets. Auth map, roles, data flows. 40 min.
4. Read every JS bundle from the main app. Endpoint and flag extraction. 40 min.
5. Write ten hypotheses with lens ids. Rank by cheapness × impact.
6. Skill 04 on the top three. Read-only.
7. Park everything unproven in the ledger with a revive-if.
8. Session log: what is unexplored, what capability you need.

Do not fuzz on day one. You do not yet know what normal looks like.
