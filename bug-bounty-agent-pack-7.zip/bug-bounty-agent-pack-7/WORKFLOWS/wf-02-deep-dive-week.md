# WF-02 — Deep dive, one surface, one week

Day 1: exhaustive request capture of every flow on the surface. Build the state machine.
Day 2: authz matrix across four accounts and two tenants. Every object, every verb.
Day 3: parser work. Type confusion, canonicalization, second-order.
Day 4: research interrupt — skill 16 on the components, skill 17 on the classes found.
Day 5: chain building on the best two candidates. Reliability runs.
Day 6: report, dup score, submit.
Day 7: posture analysis and learning notes. Retro.

Rule: one surface, no drifting. New surfaces get their own week.
