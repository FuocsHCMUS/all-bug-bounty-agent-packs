# WF-04 — Writeup to technique

1. Choose the class, not the vendor.
2. Read three writeups of that class. Extract only: precondition, primitive, bypass, detection.
3. Write one technique card with product names stripped.
4. Abstract to the boundary shape: what kind of component has this property?
5. Find that shape on the current target.
6. Write the hypothesis with the card id.
7. Test. If it fails, record the defense that killed it — that is the anti-technique field.
8. Update the card with the anti-technique. Cards get better with failures.
