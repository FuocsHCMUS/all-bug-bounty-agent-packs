# WF-05 — Post-finding analysis

Runs within 24h of a confirmation.

1. Freeze evidence. Copy to `evidence/<id>/`, hash the files.
2. Skill 19: build the ladder, even if you already reported.
3. Skill 22: posture score across all nine domains, citing evidence.
4. Skill 23: learning note, from the socket up.
5. Detection gap: write the query that would have caught it. Note whether the product's
   own audit view shows the action.
6. Systemic fix: the lint rule, test, or middleware that prevents the class.
7. Retro: which lens paid, which tool was missing, what would have halved the time.

Deliver all four artifacts to the human in one message.
