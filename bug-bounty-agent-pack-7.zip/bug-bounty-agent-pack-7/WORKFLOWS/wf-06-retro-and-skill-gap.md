# WF-06 — Retro and skill gap

Weekly, or at target close.

1. Read the week's hypotheses. Sort by status.
2. For each `dead`: was it killed by a missing capability, a wrong model, or a real defense?
3. Missing capability → add to the capability request list for the human.
4. Wrong model → name the assumption and the lens that would have caught it.
5. Real defense → add the anti-technique to the relevant playbook.
6. Score yourself on the six modes: recon, hunt, craft, research, report, teach.
   Lowest score gets next week's study block.
7. Update `STATE/learning/skill-ladder.md`.
8. Write three sentences on what you will do differently.
