# WORKSPACE

Everything portable lands here and dies with the folder.

```
WORKSPACE/
├── bin/         static binaries
├── tools/       cloned repos
├── venv/        python venv
├── wordlists/   SecLists subset
├── captures/    pcaps, HAR
├── rigs/        minimal reproductions for novel primitives
└── NOTES.md     provenance: what, version, source, date
```

`NOTES.md` example line:
`ffuf 2.1.0 — github.com/ffuf/ffuf — 2026-11-04 — static release binary`

Nothing here is committed except this README.
