---
name: bug-bounty-agent-pack-8
description: Use when an agent is asked to research bug bounty programs, plan scoped tests, analyze CVE applicability or supplied evidence, draft findings, or teach the cybersecurity concepts behind an engagement.
---

# Workspace pack entry

Resolve this skill's directory and go up three levels to the pack root. Read [the root skill](../../../SKILL.md) and [workspace instructions](../../../AGENTS.md), then follow the task-specific links there. The root skill contains the maintained workflow; this file supplies native discovery without duplicating the pack.

The pack must travel with this entry. Do not install this small entry alone in a global skills directory. For a standalone installation, copy the entire pack to its own workspace and open that folder. If the agent cannot read files, supply the root skill and the relevant references manually.
