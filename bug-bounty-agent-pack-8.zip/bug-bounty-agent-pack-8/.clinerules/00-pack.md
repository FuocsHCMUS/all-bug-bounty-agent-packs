# Bug bounty pack entry

Read `AGENTS.md` at the workspace root, then `SKILL.md` and the relevant task prompt in `PROMPTS.md`. Use file tools to load references when needed. Keep pack documents and session artifacts in English. Apply the root execution approval and evidence requirements. The root files are the maintained source; do not duplicate the entire reference library into this rule.
