# Additions beyond the original request

The requested core is preserved: English multi-agent instructions, creative bug bounty research, CVE/writeup learning, report preparation, detailed beginner teaching, and Windows/Python/tool preferences. The pack adds:

1. **Progressive loading:** short persistent instructions plus an on-demand reference library, so a large pack does not consume every context window.
2. **Native loading verification:** current per-client details, especially Claude's direct `AGENTS.md` support and its version/precedence conditions.
3. **Research-only starting mode:** compare programs and prepare hypotheses before a testing engagement exists.
4. **Falsifiable hypothesis ledger:** track invariants, alternatives, controls, outcomes, and why an idea was rejected.
5. **CVE applicability matrix:** separate product identity, build/backport, features, configuration, reachability, lab proof, and target validation.
6. **Patch-to-invariant research:** derive related hypotheses from what a patch actually repairs.
7. **Mechanism learning from CTFs:** record which assumptions transfer to production and which do not.
8. **Explicit chain evidence:** represent each proposed exploit-chain edge as demonstrated, inferred, contradicted, or untested.
9. **Coverage accounting:** record tested actor/resource/action combinations and preserve unknown areas.
10. **Negative results as learning:** save useful disprovals instead of repeating the same dead ends.
11. **Separate triager and student artifacts:** concise report drafts and deep explanatory lessons share the same evidence references.
12. **Defensive/SOC companion:** prevention, telemetry, detection hypotheses, false positives, investigation, and response discussions.
13. **Scoped posture observations:** record observed strengths and weaknesses without unsupported company-wide grading.
14. **Fix and retest design:** pair root-cause recommendations with allowed/denied regression cases.
15. **Durable session memory:** state, approvals, activity, evidence, and handoffs support work across agents and context resets.
16. **Offline helpers:** session scaffolding and evidence manifests without target traffic or third-party Python dependencies.
17. **Windows 3.14 compatibility guidance:** conventional versus free-threaded builds, workspace environments, native-wheel limitations, and portable tool provenance.
18. **Integration request templates:** prepare concrete MCP/plugin/skill additions for the user instead of silently installing them.
19. **Fictional worked example:** a small export authorization inconsistency taught from normal operation through detection and retest.
20. **Behavioral scenarios and honest validation:** test important decisions and distinguish documentation checks from six-client execution testing.

The pack supports ambitious offensive reasoning. It retains scope, minimal proof, evidence quality, and execution boundaries because those make research attributable and reviewable; it does not contain instructions to bypass host policies or attack arbitrary third parties.
