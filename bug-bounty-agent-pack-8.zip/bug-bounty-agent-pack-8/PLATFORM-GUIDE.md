# Agent loading and compatibility

Checked against primary documentation on **2026-11-03**. Documentation compatibility is not an end-to-end execution test. Start each tool with this folder as its workspace and verify loaded instructions in the installed version.

## Shared layout

`AGENTS.md` is the canonical always-needed agreement. `SKILL.md` is the manual workflow entry. The native discovery entry is `.agents/skills/bug-bounty-agent-pack-8/SKILL.md`. The long prompt and reference library are read on demand. No global settings, permission bypass flags, or system integrations are installed by this pack.

| Agent | Instructions | This pack's setup |
| --- | --- | --- |
| Claude Code | Current versions support `AGENTS.md`, with version/settings conditions | Use root `AGENTS.md`; see Claude note below |
| Codex | Root/path-scoped `AGENTS.md`; repo skills in `.agents/skills` | Open this folder; invoke `$bug-bounty-agent-pack-8` if discovered |
| OpenCode | `AGENTS.md`; compatible `.agents/skills` discovery | Root instructions plus shared native skill entry |
| Cline | `AGENTS.md`; `.clinerules/` and `.cline/rules/` | Root instructions; small native bridge also provided |
| Cursor | `AGENTS.md`; `.cursor/rules/*.mdc` | Root instructions; small `.mdc` bridge also provided |
| Antigravity | `AGENTS.md`/`GEMINI.md`; `.agents/rules`; `.agents/skills` | Root instructions plus shared native skill entry |

## Claude Code

Direct `AGENTS.md` support begins at **v2.1.277**. By default a project-path `CLAUDE.md` or `CLAUDE.local.md` can cause Claude to load those instead. The Project instructions setting can change this. Before v2.1.281 some sessions had additional restrictions; the first session after upgrading an old version may also differ. Check `/memory`; older affected versions may not show a directly loaded file. [Official memory guide](https://code.claude.com/docs/en/memory#agents-md).

The pack intentionally ships **no root `CLAUDE.md`**. If your session requires it, manually create a tiny bridge next to `AGENTS.md` containing `@AGENTS.md`; inspect existing instructions first. This is a compatibility option, not a requirement for current supported sessions. Do not overwrite an existing project file.

For native slash-command skills Claude documents `.claude/skills/<name>/SKILL.md`. This pack's `.agents` entry should not be assumed to be a Claude skill. Root instructions plus manual `SKILL.md` reading are sufficient. If you want native discovery, ask the agent to prepare a local `.claude/skills/bug-bounty-agent-pack-8/` copy of the shared entry, preserving its depth and relative paths, then approve adding that skill. Avoid duplicate discovery in other agents. [Claude skills](https://code.claude.com/docs/en/skills).

## Codex

Codex discovers project `AGENTS.md` files along its project path, with nearer instructions taking precedence and a default combined instruction limit of 32 KiB. Keep the always-loaded file small. The pack's extra references are intentionally separate. [Codex instructions](https://developers.openai.com/codex/guides/agents-md).

The shared skill entry is in the documented `.agents/skills` location. Do not copy only the bridge to a user-wide skills directory; it depends on the rest of the pack. If discovery is unavailable in a projectless session, explicitly ask Codex to read root `SKILL.md`. [Codex skills](https://developers.openai.com/codex/skills).

## OpenCode

Use the root `AGENTS.md` and shared skill entry. OpenCode documents `.agents/skills`, `.opencode/skills`, and Claude-compatible locations. It does not automatically inline ordinary file references from `AGENTS.md`; the pack tells the agent to read referenced files. `adapters/opencode/opencode.example.json` is optional configuration to merge after inspection, not a replacement for your existing settings. [Rules](https://docs.opencode.ai/docs/rules/), [skills](https://docs.opencode.ai/docs/skills/).

## Cline

Enable the root `AGENTS.md` in the Rules panel. Current documentation also supports `.clinerules/` and `.cline/rules/`; the included `.clinerules/00-pack.md` points to the same instructions. If both sources are active the bridge only routes to the canonical file. Use Plan mode to prepare a batch; confirm execution through the installed client's controls. [Cline rules](https://docs.cline.bot/customization/cline-rules).

## Cursor

The root `AGENTS.md` is supported. `.cursor/rules/00-bug-bounty-pack.mdc` is a native bridge with `alwaysApply: true`. Its file references tell the agent what to read; they do not inline the whole reference library. Plain `.md` files in `.cursor/rules` are not a substitute for `.mdc`. Verify the active rule list and avoid loading duplicate full copies. [Cursor rules](https://prod.cursor.com/docs/rules).

## Google Antigravity

Current documentation supports root `AGENTS.md` and `.agents/skills`. Start at the pack root: nested rules below the workspace are not automatically applied in every surface. A modular rule would require valid `trigger` frontmatter; none is necessary for root `AGENTS.md`. Older builds may differ, so use explicit file reading if discovery fails. [Rules](https://antigravity.google/docs/rules/), [skills](https://antigravity.google/docs/skills).

## Loading smoke test

Ask the agent to identify the pack root, the actual files it loaded, the execution approval rule, the CVE evidence rule, and the path for a handoff. Inspect its file/rule viewer if available. Then give it the banner-only scenario in `tests/behavior-scenarios.md`. Passing this is a useful check, not a guarantee of future compliance. Model permissions remain controlled by the host application.
