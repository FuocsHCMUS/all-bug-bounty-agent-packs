# Task prompt library

Open the selected file and give its task block to the agent, together with the relevant input. The agent should read root `AGENTS.md` and `SKILL.md` first. Square-bracket fields are intentional inputs. Missing values stay unknown; they are not permission to invent facts.

| Task | File | Main output |
| --- | --- | --- |
| Public program shortlist | [01](prompts/01-program-research.md) | Sourced comparison and intake candidates |
| Engagement intake | [02](prompts/02-engagement-intake.md) | Scope snapshot, account plan, first batch |
| Application/surface map | [03](prompts/03-surface-map.md) | Actors, resources, transitions, coverage matrix |
| CVE applicability | [04](prompts/04-cve-research.md) | Applicability matrix and evidence gaps |
| Writeup/CTF learning | [05](prompts/05-writeup-learning.md) | Source card, mechanism lesson, adapted hypothesis |
| Creative hypotheses | [06](prompts/06-hypothesis-workshop.md) | Prioritized falsifiable experiments |
| Candidate validation | [07](prompts/07-validation.md) | Supported conclusion or precise next test |
| Report preparation | [08](prompts/08-report.md) | User-reviewable platform report draft |
| Posture and SOC review | [09](prompts/09-posture-review.md) | Evidence-scoped controls analysis |
| Beginner lesson | [10](prompts/10-teach-back.md) | Foundation-to-mechanism teaching note |
| Resume/handoff | [11](prompts/11-resume.md) | Reconciled state and next bounded action |
| Fix retest | [12](prompts/12-retest.md) | Allowed/denied comparisons and residual gaps |

For an all-in-one persona use [SUPER-AGENT-PROMPT.md](SUPER-AGENT-PROMPT.md), then select a task here. A prompt is a request, not a guarantee that a client has the required tools. If browsing, file access, accounts, or test capability is missing, explain the limitation and finish the useful artifacts supported by available inputs.
