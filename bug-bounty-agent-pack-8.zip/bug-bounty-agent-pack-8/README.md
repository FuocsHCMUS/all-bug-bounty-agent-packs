# Bug Bounty Agent Pack 8

An English research, testing, reporting, and learning workspace for Claude Code, Codex, OpenCode, Cline, Cursor, and Google Antigravity. Built for a beginner who wants a senior research partner: technically curious, evidence driven, able to explain the foundations, and persistent across sessions.

This is an instruction pack, not an autonomous exploitation service. It contains no live scanner, exploit downloader, credential collector, or automatic submission integration. Finding a vulnerability, getting a bounty, and tool compatibility are not guaranteed by a prompt.

## Start

1. Open **this folder** as the agent's workspace. Instructions in a child folder may not load when the parent folder is the workspace.
2. Read [START-HERE.md](START-HERE.md) and the relevant row of [PLATFORM-GUIDE.md](PLATFORM-GUIDE.md).
3. Give the agent the starter prompt below. You can begin with public program research before selecting a target.
4. Use [SUPER-AGENT-PROMPT.md](SUPER-AGENT-PROMPT.md) for the full persona and output contract, and [PROMPTS.md](PROMPTS.md) to select a specific task.
5. Keep each engagement in its own `sessions/<session-id>/` folder. Runtime material stays local by default.

```text
Read AGENTS.md and SKILL.md in this workspace. Adopt SUPER-AGENT-PROMPT.md.
I am a beginner using Windows 11 and Python 3.14.x or later.
Start with public program research and explain your decisions from first principles.
Use prompts/01-program-research.md. Prepare a comparison of suitable public programs
and a draft intake record. Do not send testing traffic yet.
Keep all pack documents, session notes, and technical reports in English.
```

Already have a program? Replace the last task with:

```text
Use prompts/02-engagement-intake.md for this program: [paste program policy URL].
My requested assets and goals are: [describe them].
Prepare the scope snapshot, account plan, hypotheses, and a concrete first test batch.
Show any script/tool execution request before running it.
```

Bracketed values in prompt/templates are intentional user inputs, not completed research.

## What is included

| Area | Purpose |
| --- | --- |
| [AGENTS.md](AGENTS.md), [SKILL.md](SKILL.md) | Durable operating instructions and on-demand workflow router |
| [.agents/skills/bug-bounty-agent-pack-8/SKILL.md](.agents/skills/bug-bounty-agent-pack-8/SKILL.md) | Native skill entry for compatible agents; points back to the pack |
| [SUPER-AGENT-PROMPT.md](SUPER-AGENT-PROMPT.md) | Senior offensive researcher, skeptical reviewer, security educator |
| [PROMPTS.md](PROMPTS.md), `prompts/` | Copyable task prompts, from public research to retest and handoff |
| `references/` | Research methods, technical playbooks, CVE triage, evidence, SOC, learning |
| `templates/` | Markdown worksheets, JSON records, and CSV ledgers |
| `examples/` | Fictional own-account finding and a worked learning note |
| `scripts/pack_tools.py` | Offline session scaffolding, package checks, SHA-256 evidence manifests |
| `tests/` | Offline helper tests and behavioral evaluation scenarios |
| [TOOLING.md](TOOLING.md) | Windows, Python, portable tools, and optional integration requests |
| [SOURCES.md](SOURCES.md) | Primary-source links and verification notes, checked 2026-11-03 |
| [EXPANDED-IDEAS.md](EXPANDED-IDEAS.md) | Additions beyond the original request |

## Working agreement

Public research, reading supplied source, local note writing, lightweight portable downloads, and workspace Python dependencies can proceed under the user's stated permission. Running a script or tool requires an execution approval, which may cover a concrete bounded batch. Download permission does not imply permission to execute downloaded code. System installs and adding MCP servers, plugins, or skills require the user's confirmation. Details and examples are in [TOOLING.md](TOOLING.md).

Live testing also needs a current program scope and an agreed test batch. Program listing is not authorization for every asset owned by a company. The pack supports creative hypotheses and local experiments while keeping the proof attributable and limited to the demonstrated boundary.

## Quality bar

Every important claim has an evidence reference, an uncertainty label, and a next decision. A finding includes reproduction, a control comparison, demonstrated impact, a practical fix, a retest, and a beginner explanation. A company assessment distinguishes observed strengths, confirmed weaknesses, plausible risks, and untested areas. An empty finding list is an honest result, not a reason to manufacture impact.

See [VALIDATION.md](VALIDATION.md) for what was actually checked. Instruction discovery and model behavior must still be smoke-tested in your installed agent version.
