---
name: bug-bounty-agent-pack-8
description: Use when an agent is asked to research bug bounty programs, plan scoped tests, analyze CVE applicability or supplied evidence, draft findings, or teach the cybersecurity concepts behind an engagement.
---

# Bug bounty research and learning

Use [AGENTS.md](AGENTS.md) for the workspace agreement and [SUPER-AGENT-PROMPT.md](SUPER-AGENT-PROMPT.md) for the full role. This skill is a router: select the relevant method instead of loading every file.

## Choose the work

| User intent | Prompt | Reference |
| --- | --- | --- |
| Find public programs | [Program research](prompts/01-program-research.md) | [Scope](references/engagement-and-scope.md) |
| Start an engagement | [Intake](prompts/02-engagement-intake.md) | [Workflow](references/hunting-workflow.md) |
| Understand an application | [Surface map](prompts/03-surface-map.md) | [Web/API playbook](references/web-api-playbook.md) |
| Research known weaknesses | [CVE triage](prompts/04-cve-research.md) | [CVE method](references/cve-applicability.md) |
| Learn from a writeup/CTF | [Source learning](prompts/05-writeup-learning.md) | [Research synthesis](references/research-and-creativity.md) |
| Create new test ideas | [Hypothesis workshop](prompts/06-hypothesis-workshop.md) | [Advanced concepts](references/advanced-research.md) |
| Validate an observation | [Validation](prompts/07-validation.md) | [Evidence](references/evidence-and-validation.md) |
| Prepare a submission draft | [Report](prompts/08-report.md) | [Reporting](references/reporting-and-severity.md) |
| Assess controls and teach | [Posture](prompts/09-posture-review.md), [Lesson](prompts/10-teach-back.md) | [Posture/SOC](references/posture-and-soc.md), [Foundations](references/foundations.md) |
| Continue or retest | [Resume](prompts/11-resume.md), [Retest](prompts/12-retest.md) | [Workflow](references/hunting-workflow.md) |

## Research and engagement output spine

Use the following spine for investigations, evidence reviews, and engagements:

1. State the question and the assets/evidence available.
2. Separate observed facts, inferences, and unknowns.
3. Choose a testable hypothesis and its strongest alternative explanation.
4. Prepare the smallest discriminating next action, including any execution request.
5. Record the result and evidence references; update the hypothesis state.
6. Produce the relevant report/lesson/handoff artifact.

For engagements use [templates/session-state.json](templates/session-state.json); for findings use [templates/finding.md](templates/finding.md); for saved lessons use [templates/learning-note.md](templates/learning-note.md). Use [TOOLING.md](TOOLING.md) for execution and installation decisions. If scope or execution approval is missing, finish research and draft artifacts that do not depend on it.

## Concept-only teaching

For a request such as “Explain authentication versus authorization,” read the relevant foundations section and give a focused lesson with definitions, normal flow, a tiny fictional example, a counterexample, and comprehension questions. No engagement intake, target scope, hypothesis ledger, finding state, session folder, or tool installation is needed. Save a lesson file when the user requests one or when working inside an existing learning session.

## Example

User: “This banner looks like a vulnerable product. Find out whether the CVE applies.”

Create a CVE applicability worksheet. Obtain the vendor advisory and actual product/build evidence, distinguish origin from edge/CDN, list feature/configuration prerequisites, and identify backport uncertainty. Record `candidate` until the deployment conditions and a suitable proof are supported. Propose a local reproduction or approved minimal test, rather than treating a banner as a finding. Explain version identity, code reachability, and exposure in beginner terms.

## Common mistakes

Avoid copying payloads without understanding prerequisites, interpreting status codes as business impact, generalizing one failed check into company security maturity, or spending an entire session collecting URLs without a prioritized hypothesis. A concise, well-supported negative result is useful research.
