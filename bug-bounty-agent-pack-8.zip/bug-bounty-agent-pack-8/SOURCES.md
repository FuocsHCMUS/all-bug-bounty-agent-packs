# Primary sources and freshness

Checked **2026-11-03**, user timezone Asia/Saigon. Links document product formats and research methods, not authorization for a target. The pack's technical examples are original synthetic illustrations. Source availability and client behavior can change; verify relevant pages again when starting a real task.

| Topic | Source | Use / verification note |
| --- | --- | --- |
| Claude instruction loading | [Claude memory](https://code.claude.com/docs/en/memory#agents-md) | Read directly and cross-checked through Context7; version/default conditions in platform guide |
| Claude skills | [Claude skills](https://code.claude.com/docs/en/skills) | Project skill format and `.claude/skills` |
| Codex instructions | [Codex AGENTS.md](https://developers.openai.com/codex/guides/agents-md) | Redirected to official ChatGPT Learn; project discovery and size limits |
| Codex skills | [Codex skills](https://developers.openai.com/codex/skills) | Redirected to official ChatGPT Learn; `.agents/skills` discovery |
| OpenCode rules | [OpenCode rules](https://docs.opencode.ai/docs/rules/) | `AGENTS.md`, optional instructions configuration, explicit file reading |
| OpenCode skills | [OpenCode skills](https://docs.opencode.ai/docs/skills/) | Project skill locations/frontmatter |
| Cline rules | [Cline rules](https://docs.cline.bot/customization/cline-rules) | `AGENTS.md`, `.clinerules`, `.cline/rules`, Rules panel |
| Cursor rules | [Cursor rules](https://prod.cursor.com/docs/rules) | `AGENTS.md` and `.mdc` project rules |
| Antigravity rules | [Antigravity rules](https://antigravity.google/docs/rules/) | Current root rules and `.agents` paths; older surfaces may differ |
| Antigravity skills | [Antigravity skills](https://antigravity.google/docs/skills) | Project skill customization |
| Windows Python | [Python 3.14 on Windows](https://docs.python.org/3.14/using/windows.html) | Interpreter selection and virtual environments |
| HackerOne program intake | [Security page](https://docs.hackerone.com/en/articles/8490833-security-page) | Program scope/testing information |
| Bugcrowd program intake | [Reviewing bounty briefs](https://docs.bugcrowd.com/researchers/participating-in-program/reviewing-bounty-briefs/) | Targets, scope, program expectations |
| Structured web testing | [OWASP WSTG](https://owasp.org/projects/web-security-testing-guide) | Learning and coverage reference; pin a version when citing individual test IDs |
| Browser/application learning | [PortSwigger learning paths](https://portswigger.net/web-security/learning-paths) | Optional practice curriculum; no lab was executed during pack creation |
| Access-control concepts | [PortSwigger access control](https://portswigger.net/web-security/access-control) | Further reading for object/function authorization |
| Dependency advisories | [OSV](https://osv.dev/) | Ecosystem-oriented vulnerability records |
| Dependency advisories | [GitHub Advisory Database](https://docs.github.com/en/code-security/concepts/vulnerability-reporting-and-management/github-advisory-database) | Maintainer/ecosystem advisory context |
| Known exploitation | [CISA KEV official mirror](https://github.com/cisagov/kev-data) | Main CISA catalog returned 403 during research; official mirror was read instead |
| Exploitation likelihood | [FIRST EPSS](https://www.first.org/epss/) | Model context; not target vulnerability proof |
| Technical severity | [FIRST CVSS v4 specification](https://www.first.org/cvss/v4.0/specification-document) | Versioned severity metrics; use official tooling for scores |
| Security telemetry | [OWASP Logging Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html) | Further reading for security event design |

No live company target was selected, scanned, exploited, or assessed while authoring this pack. No real CVE applicability, current bounty amount, or company security maturity claim is made by the examples. NVD's landing page returned no readable text in this research session; it remains a potential research destination, not evidence for a specific claim here.
