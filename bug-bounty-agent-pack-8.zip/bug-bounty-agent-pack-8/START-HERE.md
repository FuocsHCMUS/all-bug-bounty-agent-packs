# Start here

## Your first session

Open this pack folder in your coding agent. Ask it to read `AGENTS.md` explicitly once, then identify its pack root, selected prompt, intended output, and any missing inputs. Verify file loading using the agent's instruction/rule viewer when available. A confident answer about the pack is weaker evidence than a visible loaded-file entry.

You do not need to install six agents or any security tool to start. A file reader and public web research are enough for program selection, CVE research, writeup analysis, report review, and lessons. Agents without browsing can work from supplied policy/advisory documents and label their freshness unknown.

Choose one starting mode:

- **Learning:** use `prompts/10-teach-back.md` with “Explain how a browser request reaches an API and where authorization belongs.”
- **Public research:** use `prompts/01-program-research.md` to compare a few programs. This creates candidate records, not test traffic.
- **Existing program:** supply its current policy URL and requested assets to `prompts/02-engagement-intake.md`.
- **Existing evidence:** supply sanitized requests, responses, code, and account ownership to `prompts/07-validation.md`.
- **Local practice:** use the fictional example in `examples/`. Nothing there is a real company finding.

## Session setup

The agent can create the folders manually, or propose this offline helper for your approval:

```powershell
py -3.14 .\scripts\pack_tools.py init-session --id learning-001
```

This creates a new `sessions/learning-001/`, copies the working templates, and sets status to `research_only`. It does not contact any host. It refuses an existing session and invalid IDs. It does not verify a program policy or grant any test approval.

Populate `scope.json` from the current policy and your explicit decisions. Leave unknowns as null or empty lists. A program URL alone is insufficient to fill assets or methods. Keep credentials outside these records; use account labels such as `owner-A` and `owner-B`.

## Before a live test

Ask for one concrete test batch: exact host/path boundary, accounts, hypothesis, command/tool, requests/concurrency/time limit, expected result, and stopping condition. Check that it matches the program policy. Confirm the batch if you want it executed. An approved portable download or `pip` install does not approve the test batch.

Do not provide broad “find anything anywhere” approval. A bounded batch makes results interpretable, repeatable, and easy to stop or extend. The agent should research and prepare while waiting rather than repeatedly asking the same question.

## Useful follow-ups

```text
Show the evidence that supports that conclusion, then the best alternative explanation.
Explain every new term before using it. Walk through the normal request first.
Which parts of this chain were demonstrated, and which are still hypothetical?
Teach me what a SOC analyst could observe and what cannot be inferred externally.
Save a handoff and give me the next three most useful actions.
```

## Expected first deliverable

You should receive an intake or research note, a source list with dates, a prioritized hypothesis table, a proposed next batch, and a short beginner lesson. If there is no confirmed vulnerability, the agent should say so plainly. The pack's success is the quality of investigation and learning, not a promise of findings.
