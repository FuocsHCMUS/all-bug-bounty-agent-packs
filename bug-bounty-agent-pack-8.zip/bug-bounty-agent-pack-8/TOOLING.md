# Tools, execution approvals, and Windows/Python

## The user's preferences

The user permits lightweight portable tools, source clones, and downloads inside the workspace without a separate installation approval. The user also permits missing Python dependencies to be installed in a workspace environment. The user asks to confirm script/tool execution and asks to be told what MCP servers, plugins, or skills need adding. Preserve these distinctions.

| Action | Default for agents using this pack |
| --- | --- |
| Read files, public documentation, supplied traces; write notes | Proceed within the task |
| Download/clone a lightweight portable tool into `.tools/` | Proceed; record provenance and inspect before use |
| Add Python dependencies to `.venv/` | Proceed under the explicit dependency exception; record packages/versions |
| Run a new script, PoC, scanner, proxy, local lab, or analysis tool | Present command/bounded batch and wait for approval |
| Repeat a command covered by an approved batch | Proceed only within its inputs, destinations, and budgets |
| Install system software, drivers, services, WSL/Docker, administrator components | Ask first with concrete effects |
| Add/enable an MCP server, plugin, or skill | Prepare the proposed configuration and ask the user to add/confirm it |
| Send evidence to a third-party service or submit/publish a report | Obtain explicit user instruction for that destination/action |

Use `templates/execution-request.md` and `templates/tool-request.md`. An approval can cover a complete small batch, avoiding repeated prompts. A download/install approval and a test execution approval are different. A changed destination, privilege level, traffic budget, or meaningful side effect requires a new decision.

## Minimal setup

Most pack activities need only file access, public browsing, and a text editor. All bundled Python helpers use the standard library and perform no network operations. No pip dependency is needed to run them. They create session files, check pack structure/local links/JSON/frontmatter, and hash evidence. They do not scan targets, enforce network scope, audit arbitrary code, or verify all prose claims.

## Python 3.14 on Windows 11

Inspect the available interpreter before choosing a command. Some machines use the legacy launcher and `py -0p`; newer Python Install Manager setups use `py list`. Prefer the existing installation rather than changing the global default. [Python on Windows](https://docs.python.org/3.14/using/windows.html).

The conventional and free-threaded Python builds may have different wheel compatibility. If a native library has no compatible wheel, report the actual package/build error. Prefer a pure-Python alternative or an existing compatible runtime; ask before installing another interpreter, compiler, SDK, driver, or system dependency. Do not silently downgrade the user's Python or compile a large native toolchain.

Example workspace environment, to present as a concrete setup batch:

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip --version
```

Use the explicit environment interpreter instead of requiring activation or changing PowerShell execution policy. Install only the dependencies needed for the task. Record exact resolved versions after installation. A `pip` source build can execute package build code, so review provenance and prefer trustworthy releases/wheels. The dependency exception is not permission to install an unreviewed exploit package.

For future task scripts, use `pathlib`, explicit UTF-8, argument lists for subprocesses, request timeouts, bounded input sizes, and structured output. Separate analysis logic from network execution. Default new network-capable tools to planning/dry-run behavior and make destinations/request limits visible. Do not log secrets or interpolate untrusted strings into shell code.

## Portable tool acquisition

Download from official release pages or clone the maintainer's repository. Record URL, selected release/commit, download date, size, intended function, hash/signature if available, runtime needs, and review notes in `research/tool-inventory.md`. A clone stays inside `.tools/`; it does not get added globally to PATH.

“Portable” is about installation footprint, not trustworthiness. Inspect archive contents and extraction paths. Do not execute post-download commands, package lifecycle scripts, README instructions, or bundled installers automatically. An unexpectedly large download or a new runtime requirement changes the original lightweight assumption; explain it and ask before proceeding.

Do not create a library of public exploit repos without a concrete research need. Prefer a small reviewed local reproduction over a large opaque toolkit when the question can be answered that way.

## Capability-driven tool selection

| Need | First choice | Optional addition |
| --- | --- | --- |
| Program/advisory research | Existing browser/search connector | Read-only documentation MCP |
| HTTP understanding | Supplied sanitized traces and browser tools | Existing interception proxy, after setup/execution approval |
| Source search | Existing editor/file search | Reviewed local static analysis tool |
| Dependency identity | Lockfiles, vendor metadata, package advisory sources | Ecosystem scanner for supplied artifacts |
| Evidence organization | Markdown/JSON/CSV and bundled offline helpers | None required |
| Local reproduction | Existing Python standard library or supplied lab | Additional runtime only when needed and confirmed |
| Security telemetry lesson | Synthetic event tables | Existing SIEM/log export, supplied and authorized |

Choose tools by the decision they enable. Do not install a scanner merely because a checklist names one, and do not run aggressive default templates against an arbitrary program.

## Optional MCP/plugin/skill request

Prepare a request with: exact publisher/source, required capability, why existing tools are insufficient, data sent, read/write capabilities, transport, authentication needs, expected cost, local/configuration changes, uninstall/disable path, and a version/schema source. Let the user supply credentials through their client. Never put real tokens in pack examples.

The pack has no universal MCP JSON because the six clients use different schemas and transports. Fetch current official setup instructions for the selected client before drafting configuration. Ask the user to install/add the integration; do not silently modify global agent settings.

## Workspace helpers

After approval, from the pack root:

```powershell
py -3.14 .\scripts\pack_tools.py validate
py -3.14 .\scripts\pack_tools.py init-session --id learning-001
py -3.14 .\scripts\pack_tools.py hash-evidence --session learning-001
py -3.14 -m unittest discover -s tests -v
```

`validate` checks required files, bundled JSON parsing, simple skill frontmatter, local Markdown file targets, and absence of empty release files. It does not browse links, validate fragment headings, simulate six clients, validate every example configuration against a live schema, or enforce test scope. `hash-evidence` refuses symlinks/junctions and writes a manifest only inside the selected session.
