# Validation record

Checks performed on **2026-11-03** on Windows with Python **3.14.8**. See the [behavioral evaluation record](tests/behavior-results.md) for the independent read-through and resulting corrections.

## Results

- Conventional Python 3.14: 10 tests run, 9 passed, 1 skipped because this Windows session could not create a symlink.
- Free-threaded Python 3.14: the same 9 passed and 1 skipped.
- Pack validation: required files, JSON, simple frontmatter, and local file links passed with zero errors at the final check.
- Official skill-creator validation: root skill and native discovery entry both passed. The external validator needed Python UTF-8 mode for the root file on this Windows locale; the pack's helpers read text explicitly as UTF-8.
- The optional official-validator dependency was PyYAML 6.0.3, installed only in this pack's `.venv`. Bundled helpers and tests require no third-party packages.

## Implemented verification

- Python standard-library tests exercise actual CLI behavior in temporary workspaces: research-only session defaults, refusal to overwrite sessions, path/device-name rejection, preflight template checks, byte-accurate evidence hashes, empty/missing session behavior, broken-link/JSON detection, and linked evidence refusal where Windows permits creating links.
- `pack_tools.py validate` checks required entry files, bundled JSON parsing, simple skill frontmatter, local Markdown file targets, and empty release files. It ignores runtime folders.
- The official skill-creator validator checks both root and native-entry skill manifests with PyYAML in a workspace environment.
- A read-only behavioral evaluation uses realistic missing-scope, CVE, execution-permission, fictional-evidence, and handoff scenarios. It does not run live tools or targets.
- Primary product documentation was read to verify the loading formats described in `PLATFORM-GUIDE.md`.

## Limits

No live bounty target was tested. The six clients were not all installed or smoke-tested. File discovery is documentation-checked, not guaranteed in every build/settings combination. Tests do not prove that a language model always follows instructions. No network-scope enforcement is provided by the helpers. Local-link checks do not verify remote URLs or heading fragments. Hashes detect byte changes, not provenance/authenticity. Filesystem checks are ordinary workspace hygiene, not a hardened sandbox against a concurrently malicious local process.

All examples are fictional. No real vulnerabilities, CVE applicability, company grades, or bounty outcomes are claimed.
