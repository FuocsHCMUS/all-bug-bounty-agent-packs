# Fictional example: export delivery omits a tenant boundary

**Entirely fictional, for learning.** No company, host, CVE, or live finding is represented. The observations below are stipulated training data, not actual tool output. No exploit script or real credentials are provided.

## Scenario

The practice application has two separate tenants. `member-A` belongs only to tenant A and `member-B` only to tenant B. Each creates one private synthetic note. Sharing is disabled. A's note contains `A-TRAINING-MARKER`; B's contains `B-TRAINING-MARKER`.

The normal detail view and a delayed export use different application paths. The expected invariant is that only a permitted tenant member can receive the private note through either path.

## Stipulated evidence

| ID | Training observation | What it supports |
| --- | --- | --- |
| DEMO-E1 | A reads A's private note successfully | Baseline and synthetic marker |
| DEMO-E2 | B reads B's own private note successfully | B's session is valid |
| DEMO-E3 | B's detail request for A's note is denied | Narrow strength in the detail path |
| DEMO-E4 | A's synthetic export is delivered to B through the export path | Candidate boundary inconsistency |
| DEMO-E5 | Setup review confirms distinct tenants, no sharing, and B's identity | Removes major alternative explanations |
| DEMO-E6 | The same minimal controlled export comparison repeats | Reproducibility under these conditions |

No raw HTTP trace exists in this example. A real report would need sanitized artifacts demonstrating the same propositions. These labels are placeholders for instructional observations, not fabricated collection evidence.

## Example report summary

Under the fictional setup, tenant B's member can receive tenant A's private synthetic export through a delivery path even though the detail path denies the same boundary crossing. The demonstrated effect is one controlled cross-tenant private-object read. Broad tenant enumeration, modifications, account takeover, and historical compromise are untested.

## Root-cause hypothesis

The export path may resolve jobs or objects without binding them to the requesting actor's tenant, or it may use stale authority at delivery. Without source, these remain alternative explanations. The evidence supports the boundary failure; it does not identify an internal function by name.

## Suggested fix and retest

Enforce actor/tenant/resource/action policy when resolving the export and before the protected delivery, consistent with intended product semantics. Keep ownership and permission context attached to asynchronous jobs. Verify A can still receive A's export, B can receive B's, B cannot receive A's private export, and explicit sharing behaves as documented. Test relevant delayed/revoked cases if the fix affects job authority.

## Posture observations

- `observed_strength`: detail denied B's request for A's private note in this role/tenant setup.
- `confirmed_weakness` within the fictional exercise: export delivery violated the tested tenant boundary.
- `plausible_risk`: equivalent alternate paths may be inconsistent; this is an untested hypothesis.
- `not_assessed`: monitoring, internal architecture, patch program, encryption, and historical access.

No company-wide grade follows from these observations. See the [worked lesson](fictional-export-lesson.md).
