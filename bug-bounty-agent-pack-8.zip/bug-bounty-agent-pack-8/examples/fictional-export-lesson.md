# Worked lesson: why a correct detail view can coexist with a broken export

This is a fictional learning exercise. Its observations are defined in [the example finding](fictional-export-finding.md), not collected from a real target.

## Prerequisites

An **actor** is the identity taking an action. A **tenant** is an organizational/customer boundary. A **resource** is the object being accessed. **Authorization** decides whether the actor may perform the requested action on that resource. An **export job** creates a downloadable representation, sometimes in a background worker.

Authentication tells the system that B is B. It does not decide whether B may receive A's note. That second question belongs to authorization.

## Normal system

```text
member-A -> detail API -> policy(A, note-A, read) -> allow
member-B -> detail API -> policy(B, note-A, read) -> deny

member-A -> export request -> job -> worker -> delivery policy -> export to A
```

The invariant is broader than “the detail endpoint checks ownership.” It is “private note A is delivered only to an authorized actor through every representation and delivery path.” The export contains the same protected information in a different form.

## What changed

The fictional detail path denies B, while export delivery gives B the synthetic A marker. If identity, tenancy, private status, and sharing conditions are confirmed, the two paths disagree about the same boundary. The issue is the server's decision, not the existence of a downloadable file or a readable job identifier.

The smallest useful proof is the controlled marker and valid account comparison. There is no need to retrieve other users' documents or enumerate a production system to understand the mechanism.

## Alternative explanations

If A intentionally shared the export with B, the observation may be correct behavior. If both accounts belong to A's tenant, the intended boundary was never tested. If the tool reused A's session, the apparent bypass is a test error. If the output is a public sample export with the same generic text, it does not prove access to A's private object. Distinct markers and setup evidence help distinguish these cases.

## Repair

One repair pattern is tenant-bound object lookup followed by an action-specific policy decision. An asynchronous path also needs a clear product rule for whether authority is checked at creation, execution, or delivery. The right design depends on intended sharing and revocation semantics.

Hiding the export button or randomizing its ID may reduce accidental discovery but does not enforce the policy. Logging can help detect misuse but does not repair the unauthorized delivery.

## SOC perspective

A proposed event should identify actor, active tenant, resource tenant, action, endpoint/job, policy result, event time, and correlation ID. A detector could examine successful private deliveries without a valid relationship. It must account for legitimate sharing, support delegation, and the membership state at the relevant time.

Without those logs, an external tester cannot say whether the company alerted. A useful recommendation states the needed telemetry and a synthetic validation plan instead of claiming the SOC failed.

## Practice without network traffic

Create a paper table with A/B actors, A/B private notes, detail/export actions, and allow/deny expectations. Add an explicit shared-note relationship and update only the expected rows it changes. Then add a revoked membership and explain the intended rule at delayed delivery. The exercise trains policy reasoning before tools.

## Questions

1. Why does a valid login not answer whether B may receive A's export?
2. Why is the detail denial a strength observation rather than proof of sound authorization everywhere?
3. What condition could make cross-tenant export delivery intended behavior?

## Answers

1. Login establishes B's identity; authorization still needs to evaluate B's relationship to this resource and action.
2. It covers one endpoint, role, state, tenant relationship, and time. The export is a separate path.
3. An intended explicit sharing or delegated-authority relationship may permit it; the policy and setup decide.
