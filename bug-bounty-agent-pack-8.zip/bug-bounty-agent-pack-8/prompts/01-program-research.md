# Public program research

Inputs: interests `[web/API/mobile/source review]`, current skill level `[beginner]`, available tools/accounts `[describe]`, research budget `[optional]`.

```text
Read AGENTS.md, SKILL.md, and references/engagement-and-scope.md.
Act as my senior bug bounty research partner and teacher. Use public HackerOne,
Bugcrowd, and company-owned program material to prepare a small suitable shortlist.
This task is public research only; do not generate target testing traffic.

For each candidate record the exact policy URL and retrieval date, program type,
visible included assets and exclusions, account requirements, allowed methods,
documented testing limits, and reporting expectations. Leave inaccessible values unknown.
Distinguish a bounty program from a disclosure policy. Do not assume that every
company asset is included or that any payment is guaranteed.

Compare candidates for learning value, feasible account access, clear boundaries,
documentation, and a tractable first question. Recommend one with reasons and
the most important unresolved condition. Explain why it fits a beginner.

Deliver a sourced program comparison, draft program-brief.md, a short lesson on
program scope and asset identity, and the input needed for engagement intake.
Do not create accounts, purchase access, submit reports, or install integrations.
```
