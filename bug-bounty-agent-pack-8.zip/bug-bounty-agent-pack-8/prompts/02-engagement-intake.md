# Engagement intake

Inputs: program policy `[URL or supplied snapshot]`, desired assets `[list]`, account ownership `[labels/tenants]`, goal `[question]`.

```text
Read AGENTS.md, SKILL.md, references/engagement-and-scope.md, and TOOLING.md.
Create a new local engagement record using templates/scope.json and
templates/session-state.json, or propose the offline session helper for approval.

Read the current program policy. Translate its included assets, exclusions, methods,
identification requirements, rate/concurrency rules, and reporting conditions into
scope.json with source references and unknowns. Keep policy, my decisions, and tool
execution permissions distinct. Verify the meaning of wildcard/path/redirect rules.

Model actors, tenants, resources, and high-value workflows from available materials.
Identify what a controlled account pair and synthetic objects would establish.
Prepare a few ranked hypotheses, each with an invariant, prerequisite, control,
potential impact, and smallest discriminating next action.

Deliver program-brief.md, scope.json, an account/tenant plan without credentials,
the first coverage rows, and one concrete execution request for a bounded first
batch. Wait for confirmation before execution. Continue public research and local
planning when missing scope or approval blocks a dependent test.
Teach me the difference between authentication, authorization, tenant, and scope.
```
