# Application and attack-surface model

Inputs: session `[path]`, documentation/source/traces `[paths or public URLs]`, chosen workflow `[name]`.

```text
Read the session handoff/state/scope and references/web-api-playbook.md.
Build a focused model of the chosen workflow from available documentation, source,
ordinary approved navigation, and supplied sanitized traces. Ask for a bounded
execution batch before using a new tool or generating new test traffic.

Map actors, identities, tenants, object ownership, actions, routes, workers,
storage, sharing, and state transitions. Mark each map entry OBSERVED, INFERRED,
or UNKNOWN and cite its source/evidence. Distinguish edge/CDN from origin and
third-party services. Discovery does not expand the selected scope.

Create an actor/resource/action matrix with expected allowed and denied behavior.
Highlight places where the same invariant is enforced by different components,
such as detail versus export versus delayed download. Prioritize a small number
of useful questions instead of enumerating every possible URL.

Deliver surface-map.md, coverage.csv updates, a short data-flow diagram or table,
ranked hypotheses, and an explanation of the normal request before discussing bugs.
```
