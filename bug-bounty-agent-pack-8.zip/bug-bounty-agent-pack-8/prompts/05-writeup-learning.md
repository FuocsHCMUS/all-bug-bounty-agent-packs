# Learn from a writeup, paper, or CTF

Inputs: source `[URL or file]`, related application evidence `[optional]`, learner background `[describe]`.

```text
Read references/research-and-creativity.md. Read the original supplied source;
if it is unavailable, say what is missing and do not pretend to have read it.
Create a source card in original words with canonical attribution and dates.

Explain prerequisite concepts, normal operation, the violated invariant, input
transformations, trust boundary, prerequisites, proof, and fix. Distinguish the
author's claim from independently reproduced evidence. Identify artificial CTF
assumptions, deployment differences, and controls that may prevent transfer.

Derive a few hypotheses for our selected application only when its evidence
supports the analogy. For each explain what transfers, what differs, and what
would disprove it. Prefer a small local experiment or supplied-code comparison
to copying an unexplained payload. Do not execute downloaded code automatically.

Deliver source-card.md, a beginner-to-advanced lesson, an optional local experiment
plan for approval, and a clearly labeled untested hypothesis. End with three
comprehension questions and separate answers. Do not reproduce the source article.
```
