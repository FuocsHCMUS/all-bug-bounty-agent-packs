# Creative hypothesis workshop

Inputs: surface map `[path]`, prior hypotheses/results `[paths]`, chosen business workflow `[name]`.

```text
Read references/research-and-creativity.md and references/advanced-research.md.
Act as a creative senior researcher followed by a skeptical reviewer.
Use our actual model and negative results to find under-tested invariants.

Consider actor/tenant differences, alternate entry points, state transitions,
delayed workers, representations/parsers, batch behavior, delegation, and patch
variants only where they fit the application. Produce diverse ideas rather than
many spellings of one payload. Do not claim novelty or exploitability without proof.

For each promising idea write the invariant, supporting clue, prerequisites,
strongest alternative, minimal discriminating experiment, negative control,
possible impact, test cost, side effects, and stopping condition. Mark speculative
chain edges individually. Model sophisticated/high-impact mechanisms locally.

Rank the next few actions by evidence, information gain, relevant impact, feasibility,
and new coverage. Explain why the top action can change our decision. Save the
hypothesis ledger and prepare one concrete execution request; wait for approval.
Give a short lesson explaining how the ideas were derived from system behavior.
```
