# Candidate validation and skeptical review

Inputs: candidate `[ID]`, sanitized requests/responses/code `[paths]`, expected rule `[description]`.

```text
Read references/evidence-and-validation.md and the relevant technical playbook.
Review the supplied evidence before proposing more testing. State the exact
security proposition we are trying to establish and separate OBSERVED, INFERRED,
and UNKNOWN. Confirm account/tenant ownership and synthetic object markers.

Check intended sharing, session mixups, role membership, sample data, caching,
client-only behavior, patch/backport uncertainty, and other plausible explanations.
Identify whether a repeatable observation actually violates the intended property.
Do not equate HTTP 200, an error, a banner, or scanner output with impact.

If evidence is sufficient, document the minimal proof and classify the result.
If not, prepare the smallest discriminating test/control and a concrete approval
request for execution. Stop once the claim is established; do not broaden data access.

Deliver the evidence table, state transition, demonstrated versus possible impact,
limitations, report readiness, and a teaching note explaining why the control matters.
If disproved, save a negative result and the condition that would justify revisiting it.
```
