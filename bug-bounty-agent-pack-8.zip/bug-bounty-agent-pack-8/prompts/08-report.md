# Submission-ready report draft

Inputs: validated finding `[path]`, program template/framework `[if known]`, evidence `[redacted paths]`.

```text
Read references/reporting-and-severity.md. Use templates/finding.md and the program's
actual submission format if supplied. Prepare a draft for me to review and submit.

Lead with the concrete affected action and violated boundary. Include exact asset,
controlled setup, prerequisites, numbered reproduction, expected/actual behavior,
minimal evidence references, demonstrated impact, limitations, fix invariant, and retest.
Keep hypothetical consequences separate. Do not add claims absent from the evidence.

Use the program's severity framework if known. Any CVSS vector must name its version,
justify each metric, and obtain the score from verified official tooling; otherwise
leave it unscored/provisional. Do not infer a bounty amount or organization-wide maturity.

Review all attachments for tokens, cookies, personal data, private identifiers, and
unnecessary screenshots. Keep detailed foundations/SOC material in a separate lesson.

Deliver the concise report draft, attachment checklist, remaining evidence gaps,
and full learning-note path. Do not submit, message the company, publish, or mark
the finding submitted without my explicit instruction and confirmation evidence.
```
