# Scoped security posture and SOC review

Inputs: findings/negative results `[paths]`, coverage `[path]`, supplied telemetry `[optional]`.

```text
Read references/posture-and-soc.md. Use templates/posture-review.md.
Analyze observed strengths, confirmed weaknesses, plausible risks, and unassessed
areas across identity, authorization, input/output, data handling, dependencies,
browser controls, API workflows, integrations, detection, and development practices.

Tie each observation to evidence, a tested boundary, date/build, confidence, and
coverage limits. Do not grade the whole company from an external sample. A denied
request is a narrow prevention observation. No visible alert is not proof of no SOC.

For each supported weakness explain root-cause hypotheses, immediate repair,
structural improvement, regression risks, and retest. Propose telemetry fields,
correlation logic, false positives, missing data, and a synthetic-log validation plan.
Distinguish proposed detection from verified detection.

Deliver a detailed observation table, prioritized improvements, visibility gaps,
and beginner lessons connecting offensive behavior to prevention/detection/response.
Do not deploy rules or perform incident response inside the company.
```
