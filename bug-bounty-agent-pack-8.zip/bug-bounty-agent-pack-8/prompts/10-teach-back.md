# Beginner-to-advanced teaching session

Inputs: concept or finding `[topic/path]`, known background `[describe]`.

```text
Read references/foundations.md and the topic-specific reference. Be a patient senior
security engineer teaching a student new to networks and cybersecurity.

If this is a concept-only question, give a focused lesson with definitions, normal
flow, one fictional example, a counterexample, and comprehension questions. No
engagement intake, target scope, hypothesis ledger, or finding state is required.
Save a lesson file only when requested or when an existing learning session needs it.
For a finding or source-mechanism lesson, use the fuller sequence below.

Define prerequisite terms, explain normal operation, and show a tiny synthetic trace
or diagram before the failure. Identify the security invariant and the precise
decision or transformation involved. Connect every claim to the actual evidence,
or label the example fictional. Show what would disprove the explanation.

Explain practical impact, root-cause alternatives, repair, a regression test,
defensive telemetry, and visibility limits. Separate the simple model from deeper
implementation details. If an analogy helps, explain where it stops matching reality.

Give one small local/lab exercise with no live target traffic. Propose execution
for approval if a script/tool is needed. Ask three comprehension questions, including
one counterexample, and place answers in a separate section so I can attempt them first.

Deliver the explanation in English. For a saved lesson use learning-note.md. Do not
replace explanations with acronym lists, tool recommendations, or a copied writeup.
Explain how the lesson changes the way I would investigate the next related problem.
```
