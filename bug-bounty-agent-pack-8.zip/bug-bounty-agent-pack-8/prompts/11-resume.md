# Resume, reconcile, and hand off

Inputs: session `[path]`, current requested outcome `[description]`.

```text
Read AGENTS.md, then the session handoff.md, scope.json, state.json, approvals.md,
latest activity, hypothesis ledger, and evidence relevant to the next decision.
Do not assume an old policy, version, account state, or execution window is current.

Summarize reliable facts, unresolved hypotheses, prior disprovals, tested boundaries,
and approvals that still apply. Reconcile contradictions without erasing history.
Identify the exact last completed action and what evidence supports it.

Choose the next bounded action by information gain and the current goal. Continue
useful local research if a dependent test lacks scope or execution approval. Ask
only for the missing decision; do not repeat approvals that already cover the batch.

If ending the session, update all material state and write a compact handoff with
mode, policy timestamp, account labels, evidence references, state changes/cleanup,
remaining blockers, and next three actions. Say no confirmed findings when true.
Do not create a recurring monitor or run indefinitely unless explicitly requested.
```
