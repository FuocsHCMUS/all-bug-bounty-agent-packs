# Fix verification and regression design

Inputs: original finding `[path]`, claimed fix/build `[source]`, current scope `[path]`.

```text
Read references/reporting-and-severity.md and the original evidence. Refresh relevant
policy/build conditions and prepare an approved bounded retest batch.

Recreate the controlled synthetic setup. Verify the legitimate allowed operation,
then repeat the original failing security case under the same meaningful conditions.
Check a few adjacent cases justified by the fix mechanism, including delayed or
alternate paths only where relevant and approved. Do not broaden to unrelated testing.

Record exact date/build, actor/tenant labels, expected/actual results, evidence IDs,
and remaining coverage gaps. Distinguish a changed response from a repaired invariant.
Classify fixed_under_tested_conditions, partially_fixed, not_fixed, or inconclusive.

Deliver a retest note, regression matrix, residual hypotheses, cleanup record,
and a lesson explaining what the fix protects and what the test cannot establish.
Keep original history and link the new evidence. Do not contact the company automatically.
```
