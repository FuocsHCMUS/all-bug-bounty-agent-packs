# Advanced research directions

This reference develops reasoning methods for advanced topics. It does not supply production exploit chains or instructions for indiscriminate scanning. Use source analysis and isolated models to determine whether a sophisticated idea is plausible before proposing a scoped experiment.

## Parser disagreement

A request may be interpreted by a browser, reverse proxy, routing layer, framework, and application. Each interpretation creates an assumption about resource identity, length, encoding, and structure. A disagreement can turn a check at one layer into the wrong check for another.

Model each stage as a function from bytes to a structured representation. List the transformations, where validation occurs, and which representation the security decision uses. Create a local table of synthetic inputs and each parser's output. Investigate differences using official parser behavior and source. Do not conclude exploitable disagreement until an attacker-controlled input can cross a security boundary in a consistent deployment.

## Time and asynchronous authorization

An API can verify permission when it queues a job, while a worker later delivers a result after membership has changed. The key question is not simply “was a check present?” but “which state did the check use, and at what time did the protected effect occur?”

Draw a timeline with request, authorization, enqueue, state change, execution, and delivery. Name the invariant the product intends. Build a local deterministic schedule rather than relying on large concurrent request bursts. Compare valid and revoked synthetic identities. The report should distinguish a product's intended snapshot semantics from a true permission bypass.

## Concurrency and atomicity

Two requests can both observe a condition before either updates it. Atomicity means related operations behave as an indivisible unit for the property being protected. Idempotency means repeating one logical operation does not repeat its effect.

Use a local state machine to identify the read/check/write window and the resource that must be protected. Explain whether a transaction, uniqueness constraint, compare-and-swap, lock, or idempotency key would enforce the invariant. A local two-operation interleaving is more informative than high-volume live traffic. Do not test real balances or scarce inventory merely to observe an effect.

## Identity and delegated authority

Systems combine user identities, service identities, scopes, audiences, organizations, and impersonation features. Confused authority occurs when a component uses its own privilege for a caller without preserving the caller's limits.

Trace who requested an action, who authorizes it, whose credential performs it, and whose resource changes. Compare token audience and purpose against the receiving service's expected role. Use conceptual token labels instead of collecting real credentials. A token accepted by a service is not automatically a bug; the intended trust contract matters.

## Patch variants and adjacent paths

Read the patch as an invariant repair, then inspect equivalent transformations or alternate entry points in supplied source. Ask whether the repair applies to batch, asynchronous, import/export, versioned API, and error-handling paths. A suspicious neighboring path is a hypothesis. Validate locally with a small regression fixture before suggesting a live check.

## Supply chain and dependency reachability

A component can be present, loaded, reachable, configured dangerously, and exposed to an attacker at different levels. Draw these as separate layers. Lockfiles help identity; call graphs and configuration help reachability; actual controlled traces help deployment behavior. Build-time exposure and runtime exposure also differ.

For open-source dependencies, use the ecosystem's official advisory/range semantics and patch information. Avoid installing a full build toolchain merely to chase a version match. Prepare a compatibility request if a native dependency does not support Python 3.14 or the current Windows architecture.

## Memory safety and native components

When source or a local lab includes native code, start with ownership, bounds, lifetime, integer conversion, and parser-state invariants. A crash is an observable availability effect, not proof of code execution. Preserve the minimal synthetic input, exact build, symbol/diagnostic information, and reproduction conditions in the local environment.

Use existing permitted analysis tools or propose the required setup. This pack does not authorize crash testing production services or developing weaponized exploit chains. The useful artifact is a precise cause/effect explanation, minimal local reproduction, and a fix/retest strategy.

## Cloud, containers, and mobile

For supplied configurations, trace identity, resource policy, secrets handling, metadata access, and trust between workloads. For mobile, separate client-side restrictions from server-enforced policy, and distinguish local storage concerns from remote account impact. For containers, distinguish image contents, runtime configuration, and host boundaries.

Do not infer access to the company's cloud account, internal network, signing material, or production images from a public application being in a bounty program. Ask for the specific supplied artifact or local lab. A source/configuration review can still produce valuable learning and a scoped candidate without live access.

## Research output

Write a short theory of the mechanism, prerequisites, local model, expected observations, alternative explanations, and evidence gaps. If results support a new technique, label the claim's scope: new to this application, new variant of a known mechanism, or novelty not independently established. Keep curiosity high and certainty proportional to evidence.
