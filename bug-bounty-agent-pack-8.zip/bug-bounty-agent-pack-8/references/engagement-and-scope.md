# Program research, intake, and scope

## Finding a suitable program

Use public HackerOne security pages, Bugcrowd bounty briefs, and company-owned disclosure pages. Record actual page URLs and retrieval dates. Prefer a small shortlist whose allowed assets, available account model, documentation, and test conditions suit the learner. Distinguish a paid bounty program from a vulnerability disclosure policy; neither implies a guaranteed payment.

Compare: target type, allowed techniques, exclusions, account requirements, testing identification, rate limits, known-issue policy, report language, disclosure process, and whether the necessary feature is available without payment. Unknown values stay unknown. Do not invent program statistics, response times, or rewards. Where public access is incomplete, ask the user to supply the relevant policy text rather than bypassing login.

HackerOne's security page documents scope and testing requirements; Bugcrowd's bounty brief describes targets and program conditions. These are the starting documents for intake, not a blanket scope for all company infrastructure. [HackerOne](https://docs.hackerone.com/en/articles/8490833-security-page), [Bugcrowd](https://docs.bugcrowd.com/researchers/participating-in-program/reviewing-bounty-briefs/).

## Translate prose into an engagement record

Create `scope.json` and a readable `program-brief.md` containing:

- Canonical program/policy URL, capture date, and source snapshot reference.
- Exact included asset expressions and exclusions, retaining the policy's wording where a short excerpt is necessary.
- Asset type: hostname, API base path, mobile app identifier, repository, or supplied lab.
- Allowed methods, disallowed methods, required request identifiers, documented rate/concurrency limits.
- Account/tenant labels and who controls them, never plaintext credentials.
- User-approved action batch, time window if supplied, and reference to approval text.
- Reporting channel, confidentiality requirements, and unresolved scope questions.

Keep policy rules, user approvals, and tool permissions separate. The user can approve execution of a command; that does not change the program's target list. A tool's availability also does not establish that its use fits the program.

## Asset interpretation problems

| Situation | Decision |
| --- | --- |
| `example.test` is listed | Do not infer `api.example.test` is included |
| A wildcard is listed | Read its definition and exclusions; do not silently include the apex or other asset types |
| A hostname points to a CDN | Shared IPs and neighboring tenants are not implied targets |
| An in-scope URL redirects | Verify the destination against scope before following during a test |
| A link contains an external service | A navigable link does not authorize testing that service |
| Public API is in scope but admin is excluded | Preserve the exclusion in the proposed batch |
| Source code references an internal hostname | Treat it as a lead, not an authorized network destination |
| Program rules changed | Refresh the snapshot and reconcile the planned batch before continuing |

Do not use a homemade string-suffix matcher as the final scope decision. Hostnames need canonicalization; URLs have ports, paths, encodings, redirects, and userinfo traps; wildcard semantics vary by policy. This pack deliberately stores explicit scope without pretending its offline helpers enforce live traffic boundaries.

## Requesting a first batch

Use `templates/execution-request.md`. Include a narrow question, one selected surface, controlled accounts, synthetic resources, precise command/tool configuration, method/redirect behavior, maximum requests, timeout, outputs, and stop conditions. If the policy does not give a rate, propose a conservative limit for approval; label it a proposed operating limit, not a policy quote.

The next agent should find the approved batch in `approvals.md`, not infer it from “continue.” The current conversation still controls authorization; records preserve it for reliable resumption.

## When information is missing

Continue program comparison, code reading, documentation research, threat-boundary mapping, local worksheet preparation, or lessons. Mark dependent live tests blocked with the exact missing field. A pause on one test is not a reason to abandon all useful research.
