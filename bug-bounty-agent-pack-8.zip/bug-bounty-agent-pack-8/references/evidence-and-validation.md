# Evidence and validation

## Evidence structure

Give each important artifact a stable ID, such as `E-001`. Record its relative path, collection time in UTC, relevant local timezone if useful, method of collection, account/tenant labels, object labels, tool/build context, and the claim it supports. Keep raw material separate from report-ready redacted copies. A filename is not enough context to interpret a trace later.

Use evidence types deliberately: source excerpt, policy snapshot, request/response pair, browser observation, local test output, state comparison, patch reference, or owner-supplied inventory. Label simulated and fictional artifacts so they cannot be confused with target observations.

## A useful experiment has five parts

1. **Baseline:** a valid action whose expected result is known.
2. **Changed condition:** one actor, resource, method, state, or representation difference.
3. **Observation:** the actual response and business effect.
4. **Control:** an outcome that distinguishes the hypothesis from a competing explanation.
5. **Decision:** advance, narrow, disprove, or block the hypothesis.

For a synthetic cross-tenant object test, use distinct markers per account. Confirm that B can read B's own object, that A's object is private, and that the questionable response is A's marker under B's actual identity. If the tokens were mixed or the resource was shared, the observation does not establish the intended boundary failure.

## Validation questions

- Was the target and method included in the recorded scope?
- Is the observed behavior repeatable under the stated prerequisites?
- Are account and tenant relationships unambiguous?
- Does the result violate an intended security property?
- Is the effect in the server or only in a local client representation?
- Could caching, sharing, sample data, role membership, or token mixups explain it?
- Is the impact directly demonstrated with minimal synthetic data?
- Are speculative consequences explicitly separated?
- Could another researcher reproduce the result using the draft without secret tokens?

These are evidence quality questions, not a demand for exhaustive exploitation. Once the minimum necessary proof exists, prepare the report rather than collecting more sensitive material.

## Redaction

Replace tokens, cookies, API keys, private identifiers, email addresses, and unnecessary personal data with stable labels such as `[SESSION_B]` or `[OBJECT_A]`. Keep enough structure to explain the request. Review screenshots, URLs, query strings, filenames, browser tabs, and embedded metadata as well as the body text.

Automated substitution is not a guarantee that evidence is clean. A HAR may contain secrets in many places. Do not send raw evidence to a public paste service or external AI/tool endpoint without an explicit user decision about what is being shared. Work from redacted copies when asking for report review.

## Integrity and retention

The offline helper can generate a SHA-256 manifest for an explicitly selected evidence directory. A hash detects later byte changes; it does not prove authenticity, timestamp, origin, or absence of tampering before the hash. Keep collection context and original-to-redacted mapping separately.

Preserve successful and failed experiments with concise notes. Mark superseded evidence rather than silently changing the artifact behind an old claim. Runtime folders are ignored by the pack's `.gitignore`; this does not protect files uploaded elsewhere or included manually in an archive.

## Contradictory observations

Do not average contradictory results into confidence. Check session identity, deployment variation, feature flags, data state, async timing, and test setup. Record each condition. If the contradiction remains unresolved, narrow the claim or keep it as a candidate. A report can honestly state reproducibility limits.

## Evidence sufficiency

Strong evidence supports a specific proposition. A screenshot of a page may prove rendering but not the identity that requested it. A request trace may prove a response but not a downstream state change. A patch may prove the maintainer changed code but not that a target deployed it. Write the proposition first, then choose evidence that actually addresses it.
