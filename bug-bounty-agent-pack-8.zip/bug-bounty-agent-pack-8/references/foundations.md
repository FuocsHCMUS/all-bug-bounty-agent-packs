# Foundations: from a network request to a security finding

Read the section needed for the current lesson. The agent should explain prerequisite terms before applying a technique. These examples use fictional objects and no live target.

## 1. Computer, process, service, and network

A **process** is a running program. A **service** is functionality a program offers, often over a network. A server can mean the physical/virtual computer or the program responding to requests; clarify which meaning is intended.

An **IP address** identifies a network interface in a routing context. A **port** helps a machine direct transport traffic to the right program. A **hostname** is a human-friendly name; **DNS** is a system for resolving names to records such as IP addresses. One hostname can resolve to several addresses, and one address can serve many unrelated hostnames. This matters because a discovered IP does not identify every service or customer behind it.

**TCP** provides an ordered byte stream with connection state. **UDP** sends datagrams without the same stream guarantees. Protocols build rules on top: some web traffic uses HTTP over TCP with TLS, while HTTP/3 uses QUIC over UDP. For the beginner, the key distinction is that layers solve different problems. A transport connection being possible does not establish who may read an application object.

Prediction question: if two websites share an IP, does permission to test one include the other? No. Network co-location is not an application ownership or authorization decision.

## 2. DNS, TLS, HTTP, and the application

A simplified browser flow is:

```text
URL -> DNS resolution -> transport connection -> TLS for HTTPS
    -> HTTP request -> edge/proxy -> application -> data/worker services
    <- HTTP response <- edge/proxy <- application
```

**TLS** protects communication between the endpoints of a TLS connection and authenticates the server name according to the certificate trust model. A CDN may terminate one TLS connection and start another to an origin service. TLS does not decide whether account B may read account A's invoice.

**HTTP** defines requests and responses. A request includes a method, target, headers, and sometimes a body. A response includes a status code, headers, and often a body. A `200` means a successful HTTP response according to the server; you still need to inspect what action occurred. A `403` is a useful observation of denied access, but it does not prove every endpoint enforces the same rule.

An **API** exposes structured operations to clients. A web UI is one client. Server-side authorization must hold when a request reaches the API independently of the UI, because hiding a button does not remove the underlying operation.

## 3. URL, origin, site, and routing

A URL contains a scheme, host, optional port, path, query, and possibly a fragment. The fragment is usually handled by the client rather than sent as part of the HTTP request target. A query parameter can select a resource, filter results, or influence processing; its meaning is application-specific.

An **origin** is the scheme/host/port tuple used by browser security mechanisms. **Site** is a different browser concept used by mechanisms such as SameSite cookies; do not use origin and site interchangeably. A **route** maps a request to application handling logic.

Different layers may normalize or interpret paths differently. The research question is whether a security decision is made on the same interpretation used for the protected effect. Learn this first with an offline example instead of assuming that unusual URL strings imply a vulnerability.

## 4. Identity, authentication, authorization, and tenants

**Authentication** answers “who is this actor?” **Authorization** answers “may this actor perform this action on this resource under these conditions?” **Accounting/auditing** records relevant activity. A correct login does not prove the later object authorization is correct.

A **tenant** is an organizational or customer boundary in a shared system. A **role** is a named set of permissions. A **resource** is something being acted on: a document, job, attachment, account, or configuration. A user can belong to multiple tenants; knowing the user ID is not enough to infer the relevant tenant.

The core policy question can be written as:

```text
allow(actor, tenant, resource, action, current_state)
```

The implementation may use ACLs, role rules, attributes, ownership, relationship graphs, or a policy service. The learner should focus first on the intended decision. An **IDOR/BOLA** concern is about a missing or incorrect object-level decision, not merely an identifier being guessable.

Example: A and B each create a private note in separate tenants. B can read B's note. If B can also read A's private synthetic note without an intended sharing relationship, investigate an object authorization failure. Check identity, tenancy, sharing, and caching before concluding.

## 5. Cookies, sessions, and tokens

A **cookie** is browser-managed state sent according to its attributes and request context. A **session** is an application mechanism for connecting requests to identity/state. A **token** is a value representing authority or a claim; it may be opaque or structured. Not every token is a JWT, and a JWT's readable fields are not proof that its signature or intended audience is being verified.

Distinguish access tokens, refresh tokens, reset tokens, invitation tokens, and CSRF tokens by purpose. Reusing one purpose as another can be a design problem, but prove the actual receiving behavior rather than relying on similar formatting.

Record token labels instead of values in reports. When comparing A and B, isolate cookie jars or browser profiles and verify the authenticated identity. Many apparent cross-account bugs are test setup errors involving mixed sessions.

## 6. Input, parsing, validation, and interpretation

**Parsing** converts raw input into structure. **Validation** checks whether that structure meets expected rules. **Normalization** converts equivalent representations into a common form. **Encoding** expresses data for a particular context. **Sanitization** transforms content to remove or limit unwanted behavior. These solve different problems.

An **interpreter** gives structured input meaning, such as a database executing a query or a browser interpreting HTML/script. A **source** is where untrusted data enters; a **sink** is where a sensitive operation or interpretation occurs. A source-to-sink path shows how data reaches that operation.

Injection occurs when attacker-controlled data can alter intended instructions or structure at such a boundary. A generic “filter bad characters” approach often misses context. The fix depends on the interpreter: parameterization, safe APIs, context-aware encoding, constrained data types, or removing unnecessary interpretation.

Exercise: explain why HTML encoding is not a universal fix for an SQL query. They are different grammars and sinks; the control must match the context.

## 7. State machines, races, and background jobs

A **state machine** describes allowed states and transitions. An invitation might be created, accepted, revoked, or expired. A security rule can require that only a valid current invitation grants membership.

A **race condition** occurs when timing/interleaving changes behavior in a way that violates an intended property. An **atomic** operation protects a related action as one unit for the property that matters. **Idempotency** means repeating one logical operation has the same intended effect as performing it once.

An **asynchronous job** runs later, often in another process. Permission checked when a job is queued may not answer whether delivery is allowed after a membership change. Draw the timeline before testing. A surprising delayed result can be intended snapshot behavior or a bug; product semantics and evidence decide.

## 8. Vulnerability, exploit, exposure, and risk

A **weakness** is a flaw or missing property. A **vulnerability** is a security-relevant weakness under applicable conditions. An **exploit** is a way to exercise a vulnerability. **Exposure** concerns whether the relevant actor/input can reach it. **Impact** is what confidentiality, integrity, availability, or business property can be affected.

**Risk** combines context about likelihood and consequence; it is not identical to a severity score. A critical advisory on an unused component can be less relevant to this engagement than a demonstrated cross-tenant read. A low-complexity exploit still requires its prerequisites to be true.

A **false positive** is a reported issue unsupported by the actual conditions. A **false negative** is a missed real issue. Negative tests reduce uncertainty only for the tested conditions; they cannot prove the absence of all vulnerabilities.

## 9. CVE, CWE, CVSS, EPSS, and KEV

- **CVE:** identifier/record for a vulnerability, not an exploit guarantee.
- **CWE:** a classification of weakness mechanisms, not a unique incident.
- **CVSS:** a structured technical severity framework with explicit version/metrics.
- **EPSS:** a model estimate about exploitation activity, requiring date/context.
- **KEV:** a catalog of vulnerabilities with known exploitation evidence, not an exhaustive inventory of all exploitable flaws.

Use `cve-applicability.md` for current-source research and `reporting-and-severity.md` for scoring practice. Do not combine these labels into one certainty measure.

## 10. Defense, detection, and response

**Prevention** tries to stop an unwanted action. **Detection** tries to recognize it. **Response** contains, investigates, and recovers. A denied request shows a prevention result; without logs you may not know whether anyone was alerted. A successful test does not prove no detector exists.

**Telemetry** is collected observation data. A **log** records events. A **SIEM** helps collect/correlate/search security events. A **SOC** is the people/process/tooling function that investigates and responds. Detection requires context: actor, action, resource, tenant, decision, time, and correlation IDs can be more useful than only an HTTP status.

Never log raw secrets just to improve detection. A useful rule should specify the behavior, relevant fields, aggregation/time window, expected normal exceptions, and validation method. See `posture-and-soc.md`.

## Learning sequence

For the first few sessions, work in this order: request/response -> identity/session -> object authorization -> workflow state -> source-to-sink interpretation -> CVE applicability -> defensive telemetry. Move deeper based on comprehension rather than a rigid calendar.

Ask the learner to predict a controlled experiment's result before revealing it. Then ask them to explain the failed assumption and propose a fix. Correct answers should refer to the actual boundary, not merely repeat a vulnerability acronym.
