# Hunting workflow and durable state

## Research loop

Use this loop: **question -> model -> hypothesis -> discriminating experiment -> observation -> review -> artifact -> next question**. It works for a live authorized engagement, a local lab, or an analysis-only session. The available evidence and execution permissions determine which experiments are possible.

### Intake

Read current instructions and session state. Capture scope and account ownership. Explain the application at a level the learner understands. Write the desired session outcome as an answerable question, such as “Do exports enforce the same tenant check as object detail?”

### Mapping

Build `surface-map.md` with actors, tenants, object types, actions, endpoints, asynchronous jobs, sharing semantics, feature gates, and relevant third parties. Track which entries came from documentation, ordinary navigation, supplied traces, or inference. A discovered URL is a map entry, not a finding.

### Selection

Write a small hypothesis table with evidence, invariant, prerequisites, test, control, potential impact, cost, and expected information gain. Choose the next action because it can change a decision. “Collect more endpoints” needs a specific reason, such as resolving whether exports use a separate service.

### Preparation and execution

Define the smallest test batch and request execution approval. Preserve an unmodified baseline and record one changed variable. Record start/end time, input object labels, account labels, exact tool version/options, command, request/response paths, and observed side effects. Do not place bearer tokens in activity logs.

### Review

Check alternate explanations and whether the observation actually violates a security property. A control should challenge the same claimed boundary, not just produce any different status code. Reproduce only enough to establish reliability within the approved budget; uncontrolled repetition is not stronger evidence.

### Delivery

Create a report for validated findings. For candidates, prepare a clearly labeled investigation note. For negative results, document the tested invariant, conditions, and evidence. Add a learning note and a scoped posture observation. Save a handoff even when no finding exists.

## Finding state transitions

| State | Meaning | Evidence needed to advance |
| --- | --- | --- |
| `hypothesis` | A testable idea | Concrete observation or code path supporting concern |
| `candidate` | A plausible weakness with partial evidence | Repeatable behavior with stable prerequisites |
| `reproduced` | The behavior repeats under recorded conditions | Security property violation and practical impact supported; alternatives reviewed |
| `validated` | The claim is supported within its stated scope | Complete concise report and evidence references |
| `drafted` | User-reviewable report exists | User submission confirmation or authorized submission receipt |
| `submitted` | Submission is confirmed | Program response and fix/retest evidence |
| `resolved` | Resolution is documented | Record whether fixed, accepted risk, duplicate, or other outcome |
| `disproved` | Evidence contradicts the hypothesis | Keep reason and coverage limit |
| `blocked` | A required input/action is unavailable | Record blocker, previous state, and unblocking condition |

`blocked` may occur from any investigation state. It does not erase previous evidence. A retest can reopen a resolved record with new evidence rather than deleting its history.

## Session files

- `scope.json`: scope snapshot and explicit unresolved conditions.
- `state.json`: mode, status, selected hypothesis, evidence index, next actions.
- `program-brief.md`: readable policy interpretation.
- `activity.md`: append-only action/outcome notes with times and evidence refs.
- `approvals.md`: exact approved execution batches and boundaries.
- `hypotheses.csv`: ideas, controls, state, decisions, and next steps.
- `coverage.csv`: actor/resource/action/surface combinations actually assessed.
- `sources.csv`: research URLs, retrieval times, claims, reliability, and local references.
- `findings/`, `lessons/`, `evidence/`, `reports/`: separated artifacts.
- `handoff.md`: compact context for the next session.

Treat these as research tools, not clerical goals. Update the information that changes the next decision. Avoid endlessly rewriting the same overview.

## Managing dead ends

Record why an idea failed: prerequisite absent, behavior intended, patched implementation, wrong product identity, insufficient access, unrepeatable measurement, or flawed original hypothesis. Distinguish “not observed in these tests” from “impossible.” Revisit only when new evidence changes a prerequisite or when the previous test was demonstrably weak.

If progress stalls, ask: Is the model wrong? Are all ideas variants of the same assumption? Is the valuable boundary in an asynchronous path, a different role, or a state transition? Would source or documentation answer faster than more requests? Would another program better fit available accounts? Explain the decision rather than blindly broadening the scan.

## Handoff contract

Record current mode and policy timestamp, approved and expired batches, account labels, reliable facts, unresolved hypotheses, command/output references, state changes requiring cleanup, last completed action, and the next three useful actions. Include “no confirmed findings” when true. A resumed agent verifies stale conditions before using old approvals or version claims.
