# Evidence-based posture observations and SOC lessons

## Scope the conclusion

A bounty engagement is usually an external sample of behavior, not a full audit. It may reveal a well-enforced check or a broken boundary without showing internal deployment, monitoring, staffing, incident response, secure development, or governance. Assess what you observed and state what you could not assess.

Use categories `observed_strength`, `confirmed_weakness`, `plausible_risk`, and `not_assessed`. Pair each with `high`, `medium`, or `low` confidence justified by evidence, plus an explicit coverage statement. Do not turn these into an invented company-wide grade.

## Domains to consider

| Domain | Useful observation | What external evidence cannot establish alone |
| --- | --- | --- |
| Identity/session | Observed revocation and role-transition behavior | All identity-provider policies or recovery processes |
| Authorization/tenant isolation | Controlled actor/object/action comparisons | All endpoints, all roles, or all customer tenants |
| Input/output boundaries | Specific source-to-sink behavior | All parsers and renderers across the organization |
| Data protection | Minimal observed data exposure or access restriction | Encryption/key management and retention internally |
| Dependency/patch handling | Trusted build evidence and advisory applicability | Entire asset inventory or organization patch SLA |
| Browser controls | Actual observed header/cookie behavior | Exploitability from a header alone |
| API/business logic | Workflow invariant upheld or violated | All business policies and fraud controls |
| Integrations/cloud | Supplied configuration or allowed benign callback | Broad internal reachability or cloud privileges |
| Detection/response | Owner-supplied telemetry or documented alert result | No alert exists because the tester saw none |
| Secure development | Supplied regression test/patch evidence | Organization-wide review or training maturity |

## Turning a finding into a defense lesson

For a controlled cross-tenant read, the prevention problem is the resource authorization decision. A possible telemetry event would include request ID, pseudonymous actor ID, active tenant, resource tenant, action, policy decision, endpoint, timestamp, and reason category. The actual product may use different fields; mark this as a proposed schema until logs are supplied.

A useful detection hypothesis is “successful private-object reads where the actor's authorized tenant relationship does not permit the resource tenant.” It needs a reliable ownership/policy join. A rule looking only for many `403` responses may miss a successful bypass. Conversely, cross-tenant support roles or explicit sharing can be legitimate; the rule needs those exceptions.

Do not claim detection success without running a permitted replay against supplied or synthetic logs and checking the expected events. Do not claim detection failure without access to relevant telemetry and an agreed validation method.

## Synthetic detection design

Create a tiny local event set: permitted same-tenant read, denied cross-tenant read, explicit shared-object read, support-role read with an approved reason, and unexpected successful private cross-tenant read. Define the expected classification for each. Write pseudocode or a platform-specific query only after the actual field names and semantics are known.

```text
for each successful private-resource read:
    load actor's permitted relationships at event time
    account for explicit sharing and approved delegated roles
    flag when no relationship authorizes this action on this resource
```

This is a conceptual detection model, not a ready-to-deploy universal SIEM rule. Explain required joins, historical membership state, missing fields, delayed events, and false positives.

## Investigation and response discussion

Explain how defenders could identify the affected route/build, preserve relevant logs, establish which accounts/resources were touched, assess data sensitivity, limit further exposure, deploy the fix, verify allowed/denied behavior, and monitor recurrence. These are recommendations; the agent does not perform incident response inside a company without an explicit engagement.

Discuss what evidence is unavailable. A tester's synthetic proof can identify a vulnerable boundary but cannot determine historical compromise across all users. Avoid telling the company it was breached when the evidence only shows a test result.

## Root cause and systemic improvement

Separate the local repair from broader opportunities. A local fix may add tenant binding to one export resolver. A structural improvement may centralize object policy, bind jobs to requesting authority, or add a regression matrix across detail/export/download paths. Prioritize changes by evidence, implementation cost, expected coverage, and regression risk.

For an observed strength, explain the mechanism and the tested boundary. Example: “The detail endpoint denied B's request for A's synthetic private note in the tested role/tenant combination.” This is valuable learning without claiming all authorization is strong.

## Observation artifact

Use `templates/posture-review.md`. For each row include evidence IDs, boundary, date/build, observation category, confidence, coverage, risk/benefit, improvement, and a way to verify the recommendation. End with unassessed domains and the specific information required to assess them.

OWASP's logging guidance is a useful reference for selecting security events, preserving context, and avoiding sensitive data in logs. Keep detection recommendations tied to the demonstrated behavior and available telemetry. [OWASP Logging Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html).
