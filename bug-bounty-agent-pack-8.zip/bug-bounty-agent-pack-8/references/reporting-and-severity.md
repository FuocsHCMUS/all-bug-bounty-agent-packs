# Reporting, severity, and retesting

## Write for the triager

Lead with the affected action and security boundary: “A member of tenant B can download tenant A's private synthetic export through the export delivery endpoint.” Avoid leading with a tool name, a dramatic label, or a CVE whose deployment applicability is unresolved.

Use `templates/finding.md`. Keep the submission draft concise and put extensive learning material in a separate note. The triager needs a reproducible claim, prerequisites, expected/actual behavior, minimal evidence, demonstrated impact, and a practical fix. The student needs the fuller conceptual explanation; both can reference the same evidence IDs.

## Impact reasoning

Describe the asset, permitted actor, prohibited actor, unauthorized action, and consequence. Separate what was demonstrated from what may be possible. For example, one controlled cross-tenant read establishes a specific confidentiality boundary failure; it does not establish mass enumeration, all tenants, arbitrary writes, or account takeover.

State limitations without minimizing a real issue. If no internal architecture is available, describe likely root causes as hypotheses. “Missing tenant binding in this resolver is consistent with the result” is more defensible than claiming the exact internal function is broken.

## Severity

Follow the program's severity framework when known. Use CVSS only with an explicit version and justified metrics; obtain the score from an official calculator or verified implementation rather than guessing. CVSS technical severity, exploitation likelihood, business context, and bounty amount are different concepts. [FIRST CVSS specification](https://www.first.org/cvss/v4.0/specification-document).

When evidence is incomplete, provide a provisional qualitative assessment and list the assumptions. Explain actor privileges, user interaction, attack conditions, affected confidentiality/integrity/availability, and downstream effects only to the extent supported. Do not copy a vendor's maximum score into a deployment-specific report without examining prerequisites.

## Report review

Check that a fresh reviewer can tell:

- Which exact asset and action are affected.
- What controlled account/resource setup is required.
- Which steps are normal preparation and which demonstrate the issue.
- What to expect and what actually happens.
- Which evidence IDs support the impact.
- What remains hypothetical or untested.
- How to enforce the missing invariant and verify the fix.

Remove secrets, irrelevant scanning output, repeated screenshots, unsupported novelty claims, and broad company judgments. Keep source attribution for borrowed research separate from the target evidence.

## Submission and follow-up

Draft platform-ready text and attachable evidence for the user. Do not mark `submitted` until there is confirmation or an authorized submission receipt. If the triager requests clarification, answer the exact evidence gap; do not expand testing automatically beyond scope/approval. Record correspondence supplied by the user without inventing a program response.

## Fix guidance

Describe the invariant first, then implementation examples. For authorization, bind every lookup and effect to the actor's permitted tenant/object/action. For injection, preserve data/instruction separation at the interpreter. For lifecycle bugs, enforce valid transitions and re-evaluate authority at the protected effect. For concurrency, protect the whole read/check/write invariant.

Offer defense in depth only after the root fix. Logging, alerts, rate limits, and UI restrictions can reduce harm but may not repair the violated property. Explain tradeoffs and likely regression risks without prescribing an internal architecture you cannot inspect.

## Retest

Use a refreshed policy snapshot and a concrete approved batch. Recreate the original controlled setup, confirm the normal allowed action still works, then repeat the previously failing security case. Test a few relevant adjacent cases justified by the fix, such as a queued delivery path if that was the source of inconsistency. Record build/date, exact evidence, residual gaps, and cleanup.

Classify: `fixed_under_tested_conditions`, `partially_fixed`, `not_fixed`, or `inconclusive`. A patch announcement or a changed status code alone is not a verified fix. Keep the original finding history and link the new evidence.
