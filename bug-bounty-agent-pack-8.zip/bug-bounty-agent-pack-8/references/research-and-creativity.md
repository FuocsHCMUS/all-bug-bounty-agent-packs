# Research synthesis and creative offensive thinking

## Read for mechanisms

A useful source can be a maintainer advisory, original bug bounty disclosure, conference paper, protocol specification, patch, public code review, or CTF writeup. Record the author, canonical URL, publication date when available, retrieval date, artifact version, and whether the claim was reproduced. Mirrors and summaries are discovery aids; prefer the original evidence.

For each source answer:

1. What security property should have held?
2. Which component made the relevant decision?
3. What input and state reached that decision?
4. Which assumption was violated?
5. What prerequisites made the technique work?
6. What output established success?
7. What alternative explanation was ruled out?
8. What did the fix change?
9. Which assumptions are likely to differ in a real deployment?
10. What new, testable question follows for our selected application?

Use `templates/source-card.md`. Summarize in original words and preserve attribution. Do not dump copied articles or treat a source's claimed impact as your own finding.

## Convert CTF knowledge into engineering knowledge

CTFs often guarantee a vulnerable path, simplify account relationships, expose debug output, and omit production controls. Production applications may use different versions, asynchronous processing, authorization services, feature gates, backports, and intermediaries. List these differences before transferring the technique.

Example: a challenge's predictable object ID is not automatically the vulnerability. The general issue may be a missing object authorization check. In a real program, ask whether the server binds the requested object to the actor and tenant, using controlled accounts and synthetic data. This retains the insight while discarding challenge-specific assumptions.

## Generate ideas from invariants

Start with a statement that should always be true:

- Only an authorized tenant member can read a private export.
- Revocation takes effect before a delayed action is delivered.
- Repeating a logical operation does not duplicate a protected side effect.
- Every parser agrees on which resource and identity a request describes.
- A public share grants only the stated object and action.
- Data remains data when it crosses rendering or query boundaries.

Then ask where multiple components enforce that property and where they may disagree. Favor a hypothesis with a concrete observation over “try more sophisticated payloads.”

## Useful transformations

| Transformation | Question | Benign discriminating experiment |
| --- | --- | --- |
| Actor | Does the result depend on role or tenant? | Compare controlled A/B accounts with one private synthetic object |
| Entry point | Do detail, preview, export, and download agree? | Compare the same object through documented surfaces |
| Time | Is authorization checked before and after a state change? | Model an owned membership revoke and delayed job |
| Representation | Do two parsers interpret a value identically? | Build an offline normalization model with synthetic strings |
| Cardinality | Does a batch path preserve single-object policy? | Use a tiny batch of owned and controlled test objects |
| Lifecycle | Do create, share, revoke, and restore preserve ownership? | Use a reversible synthetic state transition |
| Version | Did a patch fix the invariant in every relevant branch? | Review the patch and adjacent source paths |
| Boundary | Does a worker trust a value that the API normally verifies? | Trace supplied code and compare locally |

These are research dimensions, not blanket approval for every combination. Select the dimension most likely to distinguish competing explanations.

## Falsifiable novelty

Describe a new idea as “untested hypothesis” until evidence supports it. State why it differs from the source technique and what observation would refute it. A new payload spelling, encoding variant, or scanner template is not necessarily a new vulnerability class. A useful result can be a previously overlooked invariant failure without being globally novel.

Use the hypothesis worksheet to track a prior belief, observation, revised belief, and next action. You need not assign numerical probabilities; qualitative confidence tied to evidence is often clearer.

## Combining findings

Represent a proposed chain explicitly:

```text
precondition A --[observed transition]--> state B
state B --[untested transition]--> privilege C
privilege C --[inferred transition]--> business impact D
```

Assess each edge independently. The whole chain is not demonstrated if one necessary edge is unknown. Track whether an edge requires a different role, feature, deployment, or tenant than the preceding one. Avoid combining mutually exclusive conditions.

If validating an edge would expose private data or change privileged state, stop at the minimal available proof and report the limit. A precise incomplete chain is more credible than an unsupported complete story.

## Prioritize for learning and impact

Compare hypotheses using evidence strength, relevance to sensitive workflows, expected information gain, prerequisites, test cost, reversibility, coverage novelty, and likelihood of an actionable fix. Do not optimize for drama or CVE popularity. Sometimes an authorization inconsistency is more valuable than chasing an old library banner.

After each session ask what improved your model. Save one reusable pattern and one caution about where it does not apply. Over time, the user's own mechanism library becomes more useful than a folder of unexplained exploit links.
