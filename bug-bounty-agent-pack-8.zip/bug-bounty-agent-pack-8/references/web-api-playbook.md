# Web and API investigation playbook

Use this as a hypothesis library, not an instruction to run every test. Choose checks from the application model, supplied traces, available controlled accounts, and the approved batch. The examples describe synthetic resources and benign observations.

## First build the matrix

Define actors such as anonymous, member-A, member-B, administrator-A, and worker. Define resources such as private note, export job, attachment, invitation, shared document, and organization setting. Define actions such as create, read, edit, export, share, revoke, and delete. Record expected results for each actor/resource/action combination before testing.

Track resource ownership and tenant membership separately. Two accounts are not evidence of different tenants if both belong to the same organization. A deliberately public shared object is not a private-object authorization failure.

## 1. Authentication and session lifecycle

**Concept.** Authentication establishes identity; a session carries that identity between requests. Password reset, MFA, refresh, logout, role changes, and account disablement can alter the validity of that identity or its privileges.

**Invariant.** A session should have the intended lifetime and authority after a security-relevant transition.

**Questions.** Does logout invalidate the intended session type? Does removal from a tenant affect already-issued access? Are recovery tokens bound to the correct purpose and state? Does the API enforce a security step that the UI requires?

**Benign experiment.** Using one controlled account, record access to a synthetic private object, perform an intended logout/revocation, and check the same narrowly defined access within the approved batch. Interpret the result using the documented session model; stateless token lifetime can explain behavior without proving a bug.

**Evidence.** Token type labels, issuance/expiry metadata without the token value, server result, documented expectation, elapsed time, and control comparison. Explain authentication versus authorization to the learner.

## 2. Object, function, and property authorization

**Concept.** Object authorization decides whether an identity can act on a particular object. Function authorization decides whether it may perform an operation. Property authorization determines which fields it may read or modify.

**Invariant.** The server binds identity, tenant, object, action, and permitted fields on every relevant path.

**Benign experiment.** Account A creates a private synthetic note. B is a controlled account in a distinct tenant. Compare B's access to its own note with B's attempt to access A's note. Verify that the response contains A's synthetic marker and that sharing is disabled. A readable ID alone is not the issue; the missing policy decision is.

**Adjacent hypotheses.** The detail endpoint may enforce policy while an export worker, attachment download, alternate API version, or batch operation uses a different resolver. Test each path as a separate matrix row.

**False positives.** Shared roles, public templates, cached sample objects, accidental use of A's cookie, support impersonation enabled by the owner, or identical test data.

**Fix direction.** Centralized server-side policy with tenant-bound object resolution and checks at asynchronous consumption points. Add regression tests for allowed and denied cases rather than hiding object identifiers.

## 3. Business logic and workflow state

**Concept.** Security can depend on the order and validity of operations, not only on the syntax of input. An invitation, approval, entitlement, or export has states.

**Invariant.** Only allowed transitions occur, and the actor remains authorized when the action takes effect.

**Method.** Draw a transition table: current state, actor, action, required condition, next state, side effect. Look for an endpoint that skips a prerequisite or repeats an effect. Use synthetic actions with no real monetary consequence. Ask whether idempotency and replay behavior match the documented business rule.

**Evidence.** Before/after state, unique operation labels, timestamps, and side-effect count. A repeated success response is not proof of duplicate execution; confirm the actual synthetic state.

## 4. Browser execution and output handling

**Concept.** A browser interprets HTML, script, attributes, URLs, and CSS differently. Data entering a dangerous interpretation context can become code instead of remaining text.

**Invariant.** Untrusted data remains data in its actual output context.

**Method.** Trace input source, storage/transformations, render sink, output context, and browser behavior. Start with a harmless unique marker and inspect whether it is encoded, reflected, stored, or interpreted in a local lab or allowed owned view. Reflection alone does not establish script execution or cross-user impact.

**Evidence.** Relevant response/DOM context, browser conditions, account relationship, and controlled observation. Distinguish server rendering from client DOM transformations and self-only effects from a demonstrated victim context.

**Fix direction.** Context-aware encoding, safe templating, safe DOM APIs, and deliberate sanitization for permitted rich content. Explain CSP as an additional control whose effectiveness depends on configuration, not a substitute for fixing the sink.

## 5. Cross-origin requests and browser trust

**Concept.** An origin is scheme, host, and port. Browser rules determine when scripts can read cross-origin responses; cookies and request sending follow related but different rules.

**Invariant.** Sensitive actions and readable responses follow the intended origin and authentication model.

**Questions.** Can an untrusted origin read a sensitive authenticated response in the actual browser conditions? Does a state-changing request need an anti-CSRF token or equivalent protection? Is the endpoint using ambient cookies or an explicitly supplied token?

**Controls.** Compare a trusted origin and an owned untrusted origin only where the program allows the setup. Preserve actual browser behavior. Headers alone do not prove cross-origin data access; a request being sent is different from a script reading its response.

## 6. Server-side fetching and integrations

**Concept.** A URL previewer, webhook tester, document importer, or image fetcher asks the server to make a request. The server's network access and credentials may differ from the user's browser.

**Invariant.** The fetcher reaches only intended destinations and handles redirects, protocols, and response processing consistently.

**Method.** Trace who supplies the URL, who resolves it, whether a worker follows redirects, and how results return. Use only explicitly allowed controlled destinations and benign markers. Do not use cloud metadata, internal hosts, or sensitive file paths to expand proof. Model destination-validation differences locally when a live probe could cross an unapproved boundary.

**Evidence.** Controlled receiver timestamps, unique request marker, destination, redirect behavior, and observed result. A callback demonstrates a request, not arbitrary internal access or code execution.

## 7. Uploads, downloads, and path handling

**Concept.** File content, filename, storage key, MIME type, and download authorization are separate decisions. A worker may transform an upload after the initial request.

**Invariant.** Uploaded content is stored and processed as intended, and retrieval remains bound to the right actor/object.

**Method.** Use tiny benign files with unique content markers. Compare ownership checks across upload metadata, preview, original download, and export. Review normalization and storage paths in supplied code or a local model. Avoid sensitive system files and executable uploads to prove a concern when a harmless surrogate can establish the boundary.

**False positives.** Signed URLs with intended sharing semantics, public assets, expired links, scanner MIME guesses, and CDN-generated errors.

## 8. Injection, queries, and interpreters

**Concept.** An interpreter treats structured input as instructions: a database query, a template, a command, or a serialized object. Injection occurs when untrusted data crosses into that instruction role without the right separation.

**Invariant.** The application preserves the intended grammar and parameter boundaries.

**Method.** With source, trace input through validation/transformation to the interpreter and inspect parameterization. Without source, prefer benign differential behavior that distinguishes a parser concern from normal validation, then reproduce the suspected mechanism locally. An error message alone is a clue. Broad extraction or arbitrary command execution is unnecessary for the learning objective.

**Evidence.** A precise source-to-sink path or controlled differential with alternatives. Distinguish code presence from reachability and intended query-language features from unsafe interpretation.

## 9. Caches, intermediaries, and representation

**Concept.** A CDN/proxy may cache or normalize a request before the application sees it. A cache key determines which requests share a stored response.

**Invariant.** Security-relevant identity and representation differences are respected across layers.

**Method.** Identify cache metadata from ordinary traces; do not infer internals solely from one header. Explore identity/representation mismatches in an isolated cache model before considering live tests. Shared-cache poisoning or ambiguous request framing can affect other users, so this pack supplies conceptual analysis rather than a production payload recipe.

**Evidence.** Clearly labeled first/second request conditions, cache status observations, synthetic marker, and alternate explanations such as application-level caching.

## 10. GraphQL, WebSocket, and asynchronous paths

**Concept.** Different protocols can reach the same business objects through different authorization code paths. Subscriptions and queued jobs outlive the request that created them.

**Invariant.** Permission and tenant binding survive protocol changes, batch operations, delayed execution, and revocation.

**Method.** Map resolvers/messages/jobs to actor/resource/action rows. Compare the same benign object access via documented interfaces. Investigate whether permission is checked at enqueue, execution, and delivery. Do not use expensive queries or high-volume concurrency to infer a logic flaw.

## Checklist after any result

Can the claim be stated as a violated invariant? Did controlled accounts and unique synthetic markers remove ambiguity? Was the server effect confirmed? Are the control and alternate explanation documented? Is the impact narrower than the hypothesis? Does the report explain the normal behavior and fix? If any answer is missing, preserve the result as a candidate and identify the next discriminating action.
