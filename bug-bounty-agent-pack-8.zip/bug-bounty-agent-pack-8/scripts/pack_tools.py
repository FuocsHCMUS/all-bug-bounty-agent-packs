#!/usr/bin/env python3
"""Offline pack utilities. Standard library only; no network or tool execution."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
from urllib.parse import unquote, urlsplit


DEFAULT_ROOT = Path(__file__).resolve().parents[1]
IGNORED = {".git", ".venv", ".tools", "sessions", "research", "__pycache__"}
COPY_RECORDS = {
    "program-brief.md": "program-brief.md",
    "activity.md": "activity.md",
    "approvals.md": "approvals.md",
    "handoff.md": "handoff.md",
    "hypotheses.csv": "hypotheses.csv",
    "coverage.csv": "coverage.csv",
    "sources.csv": "sources.csv",
    "cve-candidates.csv": "cve-candidates.csv",
}
REQUIRED = [
    "README.md", "START-HERE.md", "AGENTS.md", "SKILL.md",
    "SUPER-AGENT-PROMPT.md", "PLATFORM-GUIDE.md", "PROMPTS.md", "TOOLING.md",
    "SOURCES.md", "EXPANDED-IDEAS.md", "VALIDATION.md",
    "templates/scope.json", "templates/session-state.json",
    ".agents/skills/bug-bounty-agent-pack-8/SKILL.md",
    ".agents/skills/bug-bounty-agent-pack-8/agents/openai.yaml",
    ".cursor/rules/00-bug-bounty-pack.mdc", ".clinerules/00-pack.md",
    "scripts/pack_tools.py", "tests/test_pack_tools.py",
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def is_link(path: Path) -> bool:
    return path.is_symlink() or path.is_junction()


def session_path(root: Path, session_id: str) -> Path:
    if (len(session_id) > 64 or
            not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", session_id)):
        raise ValueError("Session ID must be 1-64 lowercase letters/digits with single hyphens")
    reserved = {"con", "prn", "aux", "nul", "conin", "conout"}
    reserved.update(f"{prefix}{n}" for prefix in ("com", "lpt") for n in range(1, 10))
    if session_id in reserved:
        raise ValueError("Session ID is a reserved Windows device name")
    parent = root / "sessions"
    target = parent / session_id
    for path in (parent, target):
        if is_link(path):
            raise ValueError(f"Refusing symlink/junction: {path}")
    if not target.resolve().is_relative_to(root):
        raise ValueError("Session must remain inside the selected pack root")
    return target


def write_json(path: Path, data: object) -> None:
    """Replace a normal JSON file atomically using a temporary sibling."""
    if is_link(path):
        raise ValueError(f"Refusing symlink/junction output: {path}")
    name = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n",
                                         dir=path.parent, delete=False) as handle:
            name = handle.name
            json.dump(data, handle, ensure_ascii=True, indent=2)
            handle.write("\n")
        os.replace(name, path)
    finally:
        if name and Path(name).exists():
            Path(name).unlink()


def init_session(root: Path, session_id: str) -> Path:
    target = session_path(root, session_id)
    if target.exists():
        raise ValueError(f"Session already exists; nothing overwritten: {target}")
    templates = root / "templates"
    needed = [*COPY_RECORDS, "scope.json", "session-state.json"]
    for name in needed:
        source = templates / name
        if (not source.is_file() or is_link(source) or is_link(templates) or
                not source.resolve().is_relative_to(root)):
            raise ValueError(f"Missing or linked template: {source}")
    scope = json.loads((templates / "scope.json").read_text(encoding="utf-8"))
    state = json.loads((templates / "session-state.json").read_text(encoding="utf-8"))
    if not isinstance(scope, dict) or not isinstance(state, dict):
        raise ValueError("Scope and state templates must be JSON objects")
    scope.update(session_id=session_id, mode="RESEARCH_ONLY", approved_batches=[], included_assets=[])
    state.update(session_id=session_id, mode="RESEARCH_ONLY", status="research_only",
                 created_at_utc=utc_now(), updated_at_utc=utc_now())
    target.parent.mkdir(exist_ok=True)
    target.mkdir()  # exclusive: never merge into or overwrite an existing session
    for name in ("evidence", "findings", "lessons", "reports"):
        (target / name).mkdir()
    for source, destination in COPY_RECORDS.items():
        shutil.copyfile(templates / source, target / destination)
    write_json(target / "scope.json", scope)
    write_json(target / "state.json", state)
    return target


def regular_files(base: Path, *, release: bool = False) -> list[Path]:
    if is_link(base):
        raise ValueError(f"Refusing symlink/junction directory: {base}")
    result = []
    for directory, names, files in os.walk(base, followlinks=False):
        current = Path(directory)
        if release:
            names[:] = [n for n in names if n not in IGNORED and not n.startswith(".venv-")]
        for name in names + files:
            path = current / name
            if is_link(path):
                raise ValueError(f"Refusing symlink/junction: {path}")
        for name in files:
            path = current / name
            if release and (path.suffix in {".pyc", ".zip", ".log"} or name.startswith(".env")):
                continue
            if not path.is_file():
                raise ValueError(f"Expected regular file: {path}")
            result.append(path)
    return sorted(result)


def hash_evidence(root: Path, session_id: str) -> dict:
    session = session_path(root, session_id)
    evidence = session / "evidence"
    if not session.is_dir() or not evidence.is_dir():
        raise ValueError("Existing session/evidence directory required; no directories created")
    entries = []
    for path in regular_files(evidence):
        digest = hashlib.sha256()
        size = 0
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
                size += len(chunk)
        entries.append({"path": path.relative_to(session).as_posix(),
                        "bytes": size, "sha256": digest.hexdigest()})
    manifest = {"schema_version": 1, "session_id": session_id,
                "generated_at_utc": utc_now(), "algorithm": "SHA-256", "files": entries}
    write_json(session / "evidence-manifest.json", manifest)
    return manifest


def validate(root: Path) -> tuple[list[str], int]:
    errors = []
    for name in REQUIRED:
        if not (root / name).is_file():
            errors.append(f"Missing required file: {name}")
    paths = regular_files(root, release=True)
    for path in paths:
        relative = path.relative_to(root).as_posix()
        if not path.stat().st_size:
            errors.append(f"Empty release file: {relative}")
        if path.suffix == ".json":
            try:
                json.loads(path.read_text(encoding="utf-8"))
            except (ValueError, UnicodeError) as error:
                errors.append(f"Invalid JSON: {relative}: {error}")
        if path.suffix not in {".md", ".mdc"}:
            continue
        content = path.read_text(encoding="utf-8")
        if path.name == "SKILL.md":
            front = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|$)", content, re.S)
            if not front:
                errors.append(f"Missing skill frontmatter: {relative}")
            else:
                name = re.search(r"^name: ([a-z0-9]+(?:-[a-z0-9]+)*)$", front[1], re.M)
                description = re.search(r"^description: (.+)$", front[1], re.M)
                if (not name or name[1] != path.parent.name or len(name[1]) > 64 or
                        not description or not 1 <= len(description[1]) <= 1024):
                    errors.append(f"Invalid skill name/description: {relative}")
        # File-target check only: not a Markdown parser or fragment validator.
        for match in re.finditer(r"\[[^\]\n]+\]\(([^)\n]+)\)", content):
            raw = match[1].strip().strip("<>")
            parts = urlsplit(raw)
            if parts.scheme or parts.netloc or not parts.path:
                continue
            target = (path.parent / unquote(parts.path)).resolve()
            if not target.is_relative_to(root) or not target.exists():
                errors.append(f"Broken/outside local link: {relative}: {raw}")
    return errors, len(paths)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT,
                        help="Pack root; default is the parent of scripts/")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("validate", help="Check release structure, JSON, skills, and local file links")
    initialize = commands.add_parser("init-session", help="Create new research-only local records")
    initialize.add_argument("--id", required=True)
    hashing = commands.add_parser("hash-evidence", help="Hash existing session/evidence files offline")
    hashing.add_argument("--session", required=True)
    args = parser.parse_args()
    try:
        root = args.root.resolve(strict=True)
        if not root.is_dir():
            raise ValueError("Pack root must be an existing directory")
        if args.command == "init-session":
            print(f"Created research-only session: {init_session(root, args.id)}")
        elif args.command == "hash-evidence":
            result = hash_evidence(root, args.session)
            print(f"Hashed {len(result['files'])} evidence files; wrote evidence-manifest.json")
        else:
            errors, count = validate(root)
            for error in errors:
                print(error)
            print(f"Checked {count} release files; {len(errors)} errors")
            return 1 if errors else 0
    except (OSError, ValueError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
