# Activity ledger

Append material actions and outcomes. Do not put credentials, raw private data, or unredacted traces here.

| Time UTC | Action / hypothesis | Approval / mode | Inputs | Outcome | Evidence / next decision |
| --- | --- | --- | --- | --- | --- |
