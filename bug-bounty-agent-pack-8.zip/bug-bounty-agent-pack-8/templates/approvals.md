# Execution approvals

Preserve the user's actual decision and its scope. This file is a record, not a self-granted permission mechanism. Empty records authorize nothing.

| Approval ID | User decision reference / time | Commands or batch | Destinations / accounts | Limits / side effects | Validity / changes requiring renewal |
| --- | --- | --- | --- | --- | --- |
