# Execution request

- Request ID / session: [IDs]
- Decision to resolve: [answerable question]
- Why existing evidence is insufficient: [gap]
- Mode and policy snapshot: [references]
- Exact asset boundaries and destinations: [host/path/port or local-only]
- Actor/tenant/resource labels: [controlled setup]
- Tool/version/source review: [existing tool or provenance reference]
- Exact command(s) / configuration: [literal commands; omit secrets]
- Inputs / outputs: [paths and formats]
- Network behavior: [methods, redirects, callbacks; none if offline]
- Limits: [maximum requests, concurrency, duration, retries, response sizes]
- Dependencies / installation footprint: [workspace pip exception or separate request]
- Expected side effects / cleanup: [state changes and reversal]
- Stop conditions: [sufficient evidence, scope ambiguity, unexpected effect, budget reached]
- Approval requested: [this specific batch]
- Approval outcome / reference / time: [pending until user confirms]

Do not execute merely because this worksheet has been written. When approved, append the exact boundary and decision to `approvals.md`. Material changes require a new decision.
