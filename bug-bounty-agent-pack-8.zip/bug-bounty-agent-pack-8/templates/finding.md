# [Concrete action and violated boundary]

Template: all bracketed fields are author inputs, not findings.

- Finding ID / state: [ID; candidate/reproduced/validated/drafted/etc.]
- Session / program / policy snapshot: [references]
- Asset and affected action: [exact boundary]
- Observed date/build: [facts or unknown]
- Weakness class / related advisory: [supported classification; optional]
- Provisional severity / framework: [reasoned assessment; no guessed score]

## Summary

[Who can do what to which resource, under which conditions, and why this is a security problem.]

## Controlled setup and prerequisites

[Account/tenant labels, synthetic objects, intended sharing/roles, required configuration. No tokens.]

## Reproduction

1. [Prepare baseline and record expected valid behavior.]
2. [Change the specific condition under test.]
3. [Observe the minimal security-relevant effect.]
4. [Run the relevant negative control within approval.]

## Expected versus actual

- Expected: [security invariant]
- Actual: [direct observation with evidence IDs]

## Evidence

| ID | Redacted artifact | Proposition supported | Collection context |
| --- | --- | --- | --- |
| [E-ID] | [relative path] | [claim] | [date/accounts/build] |

## Impact and limitations

- Demonstrated: [specific asset/action consequence]
- Possible but untested: [clearly separate]
- Coverage and reproducibility limits: [conditions]
- Alternative explanations reviewed: [results]

## Remediation and retest

[Invariant to enforce, implementation options, regression risks, allowed/denied test cases.]

## Supporting material

- Source attribution: [original advisories/writeups where relevant]
- Full learning note: [path]
- Posture observation: [path]
- Submission: [draft until confirmed receipt/reference]
