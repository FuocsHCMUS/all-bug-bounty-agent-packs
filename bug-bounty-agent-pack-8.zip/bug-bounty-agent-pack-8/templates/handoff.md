# Session handoff

- Session / updated time: [ID / UTC]
- Mode / current goal: [state]
- Policy snapshot and freshness: [reference]
- Last completed action and evidence: [exact point]
- Account/tenant labels and synthetic objects: [no secrets]
- Applicable approvals and boundaries: [IDs; expired/uncertain approvals separately]
- Confirmed findings: [IDs, or none]
- Candidates and unresolved hypotheses: [state/evidence/gap]
- Disproved ideas worth preserving: [reason and revisit condition]
- Tested coverage and major gaps: [reference]
- Tool/dependency/provenance notes: [paths]
- State changes and cleanup: [done/pending]
- Blockers and unblocking conditions: [specific inputs]

## Next three actions

1. [Concrete action with purpose and approval status.]
2. [Concrete action.]
3. [Concrete action.]

## New lessons

[Useful concept/pattern and one limitation of applying it elsewhere.]
