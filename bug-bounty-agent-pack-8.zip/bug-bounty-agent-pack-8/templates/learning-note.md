# [Concept / finding] learning note

- Related finding / hypothesis / evidence: [IDs]
- Example status: [observed / supplied source / fictional lab]
- Learner prerequisites: [what is already understood]

## Vocabulary and prerequisites

[Define each new term before using it.]

## Normal operation

[Data flow, actor/resource/action, expected invariant; use a tiny diagram or table.]

## Concrete trace and failure

[Small synthetic example; exact decision/transformation that differs from expectation.]

## Evidence and alternatives

[What supports the explanation, what is inferred, what remains unknown, what would disprove it.]

## Root cause and impact

[Supported cause or cause hypotheses; practical consequence; no invented internal architecture.]

## Repair and regression

[Property to enforce, implementation options, normal allowed case, denied case, adjacent case.]

## SOC perspective

[Telemetry, proposed detection logic, false positives, visibility gaps, response considerations.]

## Local practice

[One small exercise with synthetic inputs; prepare an execution request if needed.]

## Check your understanding

1. [Explain the normal property.]
2. [Predict the changed condition.]
3. [Counterexample where the same observation is not a bug.]

## Suggested answers

[Answers separated from questions.]

## Deeper reading and transfer

[Primary sources, what generalizes, what does not, and how this changes the next investigation.]
