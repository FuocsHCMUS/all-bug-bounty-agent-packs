# Scoped posture observations

- Session / assets / dates / builds: [context]
- Coverage source: [path]
- Assessment limitation: [external sample/source review/supplied telemetry]

| Domain | Category | Observation and boundary | Date / build | Evidence | Confidence | Coverage / unknowns | Improvement / benefit | Verification |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| [domain] | [observed_strength / confirmed_weakness / plausible_risk / not_assessed] | [narrow result] | [observed context or unknown] | [E-IDs] | [reason] | [limits] | [action] | [test] |

## Prioritized improvements

[Root repair, structural option, detection opportunity; justify priority and regression risk.]

## SOC lesson

[Event fields, correlation logic, expected false positives, synthetic validation, missing telemetry.]

## Unassessed domains

[What cannot be inferred and which specific inputs would enable assessment. No company-wide grade.]
