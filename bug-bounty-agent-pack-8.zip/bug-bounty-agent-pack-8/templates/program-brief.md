# Program brief

Template: replace bracketed inputs with sourced facts; retain unknowns explicitly.

- Session / goal: [ID and answerable question]
- Program / platform: [name and type]
- Canonical policy URL / retrieved time: [URL and UTC timestamp]
- Local snapshot / source references: [paths]
- Requested assets: [exact expressions]
- Included assets: [policy-supported list and interpretation]
- Excluded assets and methods: [list]
- Allowed methods / identification / limits: [facts; unknown where absent]
- Account/tenant plan: [controlled labels and ownership; no secrets]
- Reporting/disclosure conditions: [source-backed summary]
- Current mode: [RESEARCH_ONLY / LOCAL_LAB / SCOPED_TESTING / ANALYSIS_ONLY / REPORTING / RETEST]
- User decisions and execution approvals: [references]
- Unresolved conditions: [specific questions]

## Application model

[Actors, resources, sensitive workflows, and known data flow. Label facts/inferences.]

## First hypotheses

| ID | Invariant | Supporting clue | Control | Next discriminating action |
| --- | --- | --- | --- | --- |
| [H-ID] | [property] | [evidence] | [comparison] | [action] |

## Next deliverable

[Concrete artifact and any execution request needed.]
