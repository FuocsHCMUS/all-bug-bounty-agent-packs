# Research source card

- Source ID / title / author: [facts]
- Canonical URL / publisher: [source]
- Published / retrieved times: [known dates]
- Artifact version / commit: [if relevant]
- Source type: [vendor advisory / patch / original disclosure / paper / CTF / summary]
- Verification status: [source claim / locally reproduced / deployment supported]

## Mechanism in original words

[Normal invariant, vulnerable decision, input/transformations, boundary, effect.]

## Prerequisites and evidence

[Required actor/configuration/version/state and the proof the author supplied.]

## Fix invariant

[What the repair changes and why it addresses the mechanism.]

## Transfer to our application

[Evidence supporting similarity, differences, CTF assumptions, and non-transferable conditions.]

## New hypothesis and falsifier

[Untested idea, smallest discriminating experiment/control, and what would disprove it.]

## Attribution and limits

[Short attributed excerpt only if necessary; source reliability, contradictions, and unanswered questions.]
