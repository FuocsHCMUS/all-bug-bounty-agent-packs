# Tool or integration request

- Capability needed: [specific research decision]
- Why existing tools are insufficient: [reason]
- Proposed tool/integration and official source: [publisher, URL, version/commit]
- Type: [portable / Python dependency / system install / MCP / plugin / skill]
- Destination: [workspace path or exact settings surface]
- Download size and runtime prerequisites: [known values or unknown]
- Provenance review: [hash/signature/source findings]
- Data read or transmitted: [fields and destinations]
- Actions available: [read/write/execution capabilities]
- Authentication and user setup: [no credentials in the file]
- Cost / persistence / privilege: [facts]
- Proposed configuration or commands: [reviewable content]
- Removal/disable path: [concrete steps]
- Requested user decision: [what to add/confirm]

For portable downloads and workspace Python dependencies, record the preauthorization that applies. Execution is a separate approval. System installs and adding MCP/plugin/skills require user confirmation.
