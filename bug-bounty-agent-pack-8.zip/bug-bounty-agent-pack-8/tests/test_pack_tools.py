"""Behavior checks for offline helpers; no network or third-party packages."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest


PACK = Path(__file__).resolve().parents[1]
SCRIPT = PACK / "scripts" / "pack_tools.py"


class PackToolsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "pack"
        self.root.mkdir()
        shutil.copytree(PACK / "templates", self.root / "templates")

    def run_cli(self, *args, root=None):
        return subprocess.run(
            [sys.executable, str(SCRIPT), "--root", str(root or self.root), *args],
            capture_output=True, text=True, encoding="utf-8", timeout=20,
        )

    def initialize(self):
        result = self.run_cli("init-session", "--id", "lesson-001")
        self.assertEqual(result.returncode, 0, result.stderr)
        return self.root / "sessions" / "lesson-001"

    def test_new_session_is_research_only_and_copies_working_records(self):
        session = self.initialize()
        state = json.loads((session / "state.json").read_text(encoding="utf-8"))
        scope = json.loads((session / "scope.json").read_text(encoding="utf-8"))
        self.assertEqual(state["session_id"], "lesson-001")
        self.assertEqual(state["status"], "research_only")
        self.assertEqual(scope["approved_batches"], [])
        self.assertEqual(scope["included_assets"], [])
        self.assertTrue((session / "hypotheses.csv").is_file())
        self.assertTrue((session / "evidence").is_dir())
        self.assertTrue((session / "handoff.md").is_file())

    def test_existing_session_is_preserved(self):
        session = self.initialize()
        marker = session / "state.json"
        marker.write_text('{"keep": true}', encoding="utf-8")
        result = self.run_cli("init-session", "--id", "lesson-001")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(marker.read_text(encoding="utf-8"), '{"keep": true}')

    def test_traversal_and_windows_device_names_are_rejected(self):
        for value in ("../outside", "..", "C:escape", "CON", "nul", "com1", "bad/name", "x" * 65):
            with self.subTest(value=value):
                result = self.run_cli("init-session", "--id", value)
                self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.root.parent / "outside").exists())

    def test_missing_template_fails_before_creating_session(self):
        (self.root / "templates" / "scope.json").unlink()
        result = self.run_cli("init-session", "--id", "lesson-001")
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.root / "sessions" / "lesson-001").exists())

    def test_evidence_hash_matches_bytes_and_updates_after_change(self):
        session = self.initialize()
        artifact = session / "evidence" / "trace.txt"
        artifact.write_bytes(b"synthetic evidence\n")
        result = self.run_cli("hash-evidence", "--session", "lesson-001")
        self.assertEqual(result.returncode, 0, result.stderr)
        path = session / "evidence-manifest.json"
        manifest = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(manifest["files"][0]["path"], "evidence/trace.txt")
        self.assertEqual(manifest["files"][0]["sha256"], hashlib.sha256(artifact.read_bytes()).hexdigest())
        old = manifest["files"][0]["sha256"]
        artifact.write_bytes(b"changed\n")
        result = self.run_cli("hash-evidence", "--session", "lesson-001")
        self.assertEqual(result.returncode, 0, result.stderr)
        new = json.loads(path.read_text(encoding="utf-8"))["files"][0]["sha256"]
        self.assertNotEqual(old, new)

    def test_empty_evidence_manifest_is_valid(self):
        session = self.initialize()
        result = self.run_cli("hash-evidence", "--session", "lesson-001")
        self.assertEqual(result.returncode, 0, result.stderr)
        manifest = json.loads((session / "evidence-manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["files"], [])

    def test_missing_session_is_not_created_by_hashing(self):
        result = self.run_cli("hash-evidence", "--session", "missing-001")
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.root / "sessions").exists())

    def test_validation_rejects_broken_local_link(self):
        shutil.copytree(PACK, self.root, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns(".venv", "__pycache__", "sessions", ".tools"))
        (self.root / "broken.md").write_text("[missing](not-present.md)\n", encoding="utf-8")
        result = self.run_cli("validate")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("not-present.md", result.stdout + result.stderr)

    def test_validation_rejects_invalid_json(self):
        shutil.copytree(PACK, self.root, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns(".venv", "__pycache__", "sessions", ".tools"))
        (self.root / "bad.json").write_text("{broken", encoding="utf-8")
        result = self.run_cli("validate")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("bad.json", result.stdout + result.stderr)

    def test_evidence_symlink_is_rejected_if_supported(self):
        session = self.initialize()
        outside = self.root.parent / "outside.txt"
        outside.write_text("outside", encoding="utf-8")
        link = session / "evidence" / "linked.txt"
        try:
            link.symlink_to(outside)
        except OSError:
            self.skipTest("Windows symlink privilege/developer mode unavailable")
        result = self.run_cli("hash-evidence", "--session", "lesson-001")
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse((session / "evidence-manifest.json").exists())


if __name__ == "__main__":
    unittest.main()
