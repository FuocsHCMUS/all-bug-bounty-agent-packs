# LEARNING-PATH.md — Cybersecurity Learning Path for Beginners

> A structured learning path from absolute beginner to bug bounty hunter. Every concept is broken down from the ground up.

---

## 🌱 Level 0: The Absolute Basics

### What Is a Computer Network?
```
Imagine a city. Every building (computer) has an address (IP address).
Roads connect buildings (network cables/WiFi). Traffic lights control
traffic flow (routers, switches, firewalls).

KEY CONCEPTS:
- IP Address: Like a home address (e.g., 192.168.1.1)
- Port: Like an apartment number (port 80=web, 443=HTTPS)
- Protocol: The language computers speak (HTTP, HTTPS, FTP, SSH, DNS)
- DNS: Phone book converting names (google.com) to addresses (142.250.x.x)
- Router: Post office directing traffic
- Firewall: Security guard checking who can enter
```

### How the Internet Works
```
YOU → Router → ISP → Internet Backbone → Target ISP → Target Router → Web Server

When you type "google.com":
1. Browser asks DNS: "What's the IP for google.com?"
2. DNS responds: "142.250.80.46"
3. Browser connects to 142.250.80.46:443 (HTTPS)
4. TCP handshake: SYN → SYN-ACK → ACK
5. TLS handshake (encryption)
6. Browser sends HTTP GET request
7. Server sends back HTML
8. Browser renders the page
```

### What Is HTTP?
```
HTTP = How browsers talk to web servers.

REQUEST:
GET /search?q=hello HTTP/1.1     ← Method, Path, Version
Host: google.com                  ← Which server
Cookie: session=abc123            ← Your identity

RESPONSE:
HTTP/1.1 200 OK                   ← Status code
Content-Type: text/html           ← Format
<html>...</html>                  ← Content

METHODS: GET(read), POST(create), PUT(update), PATCH(partial update), DELETE(remove)
```

---

## 🌿 Level 1: Web Application Basics

### How Web Apps Work
```
Frontend (visible): HTML(structure) + CSS(style) + JavaScript(behavior)
Backend (hidden): Web Server(receives) + App Code(processes) + Database(stores)

Flow: Click Login → Browser sends POST /login → Server checks DB → Session created → Cookie sent
```

### What Is a Cookie?
```
A cookie = small data the server asks your browser to store.
Like a concert wristband proving you're allowed in.

session=abc123def456  ← Your "wristband"

Security flags:
- HttpOnly: JS can't read it (prevents XSS theft)
- Secure: Only sent over HTTPS
- SameSite: Controls cross-site sending (prevents CSRF)
```

---

## 🌳 Level 2: Security Fundamentals

### The CIA Triad
```
C - Confidentiality: Only authorized people can READ data
I - Integrity: Only authorized people can MODIFY data
A - Availability: System accessible when needed
```

### What Is a Vulnerability?
```
A weakness that can be exploited. Like a house with:
- Unlocked door = Missing authentication
- Weak lock = Poor encryption
- No alarm = No monitoring

RISK = THREAT × VULNERABILITY × IMPACT
```

### Common Vulnerability Types
```
1. INJECTION: Tricking system into running your commands (SQLi, XSS, CMDi)
2. BROKEN AUTH: Getting in without proper credentials
3. BROKEN ACCESS CONTROL: Accessing things you shouldn't (IDOR, privesc)
4. MISCONFIGURATION: System set up incorrectly
5. CRYPTO FAILURES: Weak/missing encryption
```

---

## 🌲 Level 3: Penetration Testing Basics

### What Is Pentesting?
```
Penetration testing = Authorized hacking with PERMISSION.

Types:
- Black Box: Know nothing (like real attacker)
- White Box: Full access to source code
- Gray Box: Some info (regular user account)

Process:
1. RECONNAISSANCE → Gather info
2. SCANNING → Find open doors
3. VULNERABILITY ASSESSMENT → Identify weaknesses
4. EXPLOITATION → Prove weakness is real
5. POST-EXPLOITATION → See how far you can go
6. REPORTING → Document everything
```

---

## 🏔️ Level 4: Bug Bounty Hunting

### Getting Started
```
1. Learn basics (Levels 0-3)
2. Practice on vulnerable apps:
   - PortSwigger Web Security Academy (FREE & EXCELLENT)
   - OWASP WebGoat, DVWA
   - HackTheBox, TryHackMe
3. Read bug bounty writeups daily
4. Start with easy programs on Bugcrowd
5. Focus on ONE vulnerability type at a time
6. Be patient — first bug might take weeks/months
```

### Resources
```
FREE: PortSwigger Academy, TryHackMe, OWASP, HackTricks (book.hacktricks.xyz)
YOUTUBE: LiveOverflow, John Hammond, IppSec, NahamSec, STOK, InsiderPhD
BOOKS: "Web Application Hacker's Handbook", "Bug Bounty Bootcamp", "Real-World Bug Hunting"
```

---

## 🗻 Level 5: Advanced Topics

### Specialization Areas
```
1. Web Application Security    6. Binary Exploitation
2. API Security (REST/GraphQL) 7. Cryptography
3. Mobile Security (Android/iOS) 8. Malware Analysis
4. Cloud Security (AWS/Azure/GCP) 9. Incident Response
5. Network Pentesting          10. Red Team Operations
```

### Career Paths
```
OFFENSIVE: Pentester, Red Team, Bug Bounty Hunter, Exploit Developer, Security Researcher
DEFENSIVE: SOC Analyst, Incident Responder, Threat Hunter, Security Engineer, Blue/Purple Team
GOVERNANCE: Security Auditor, Compliance Analyst, Risk Analyst, CISO
```

---

## 📖 Concept Deep-Dives

The agent will provide detailed concept explanations whenever a vulnerability is found. Each explanation follows this format:

```
📖 CONCEPT: [Name]

🌱 THE BASICS (Start Here):
[Everyday analogy and simple explanation]

🔍 THE PROBLEM:
[What goes wrong and why]

⚡ HOW IT WORKS:
[Step-by-step technical breakdown]

🎯 WHY IT MATTERS:
[Real-world impact]

🛠️ HOW TO TEST FOR IT:
[Practical testing steps]

📚 DEEPER DIVE:
[Advanced concepts for when ready]

🔗 RESOURCES:
[Links to learn more]
```

