# 🔴 Bug Bounty Super Agent Pack v9

> A comprehensive prompt engineering pack that transforms AI coding agents into elite offensive security professionals for bug bounty hunting.

---

## 🎯 What Is This?

This pack configures AI coding agents (Claude Code, Codex, OpenCode, Cline, Cursor, Antigravity) to act as senior penetration testers and bug bounty hunters. The agents can:

- **Hunt vulnerabilities** across web apps, APIs, mobile apps, cloud infrastructure
- **Research CVEs** and correlate with target technologies
- **Develop exploits** and proof-of-concept scripts
- **Chain vulnerabilities** for maximum impact
- **Analyze security posture** of target organizations
- **Teach cybersecurity** concepts from the ground up
- **Read and learn** from bug bounty writeups and CTF solutions

---

## 📁 File Structure

```
bug-bounty-agent-pack-9/
├── AGENTS.md              ← Claude Code agent instructions
├── SKILL.md               ← Cline skill definitions
├── .cursorrules           ← Cursor rules
├── .opencode.md           ← OpenCode configuration
├── codex.md               ← Codex agent instructions
├── antigravity.md         ← Antigravity agent instructions
├── METHODOLOGY.md         ← Complete pentest methodology
├── RECON.md               ← Reconnaissance automation guide
├── CVE-RESEARCH.md        ← CVE hunting & research guide
├── EXPLOIT-TECHNIQUES.md  ← Attack techniques encyclopedia
├── WRITEUP-ANALYSIS.md    ← Learning from writeups/CTFs
├── REPORTING-TEMPLATE.md  ← Bug bounty report templates
├── SECURITY-ANALYSIS.md   ← Security posture analysis framework
├── LEARNING-PATH.md       ← Cybersecurity learning path (beginner→advanced)
├── TOOLS-ARSENAL.md       ← Tools reference & installation
├── README.md              ← This file
└── scripts/
    ├── setup_tools.py         ← Install Python dependencies
    ├── recon_automation.py    ← Automated recon pipeline
    ├── cve_checker.py         ← CVE research & correlation
    ├── vuln_scanner.py        ← Web vulnerability scanner
    ├── subdomain_takeover.py  ← Subdomain takeover checker
    └── js_analyzer.py         ← JavaScript secret/endpoint extractor
```

---

## 🚀 Quick Start

### 1. Setup
```bash
cd bug-bounty-agent-pack-9
python scripts/setup_tools.py
```

### 2. For Each Agent

**Claude Code**: The `AGENTS.md` file is automatically read.

**Cline**: Reference `SKILL.md` in your Cline configuration.

**Cursor**: The `.cursorrules` file is automatically read.

**OpenCode**: The `.opencode.md` file is automatically read.

**Codex**: Reference `codex.md` in your Codex configuration.

**Antigravity**: Reference `antigravity.md` in your configuration.

### 3. Start Hunting
Tell your agent:
- "Hunt for bugs on [target domain]"
- "Research CVEs for Apache 2.4.49"
- "Analyze the security posture of [target]"
- "Explain SQL injection from basics"
- "Read this writeup and extract techniques: [URL]"

---

## 🛠️ Scripts Usage

```bash
# Automated Reconnaissance
python scripts/recon_automation.py -d target.com
python scripts/recon_automation.py -d target.com --passive-only

# CVE Research
python scripts/cve_checker.py -t apache -v 2.4.49
python scripts/cve_checker.py -u https://target.com

# Vulnerability Scanning
python scripts/vuln_scanner.py -u https://target.com

# Subdomain Takeover
python scripts/subdomain_takeover.py -f subdomains.txt

# JavaScript Analysis
python scripts/js_analyzer.py -u https://target.com
python scripts/js_analyzer.py -f js_urls.txt
```

---

## 📋 Agent Capabilities

| Capability | Description |
|-----------|-------------|
| Reconnaissance | Full passive + active recon pipeline |
| Vulnerability Scanning | OWASP Top 10 + advanced attack classes |
| CVE Research | NVD, Exploit-DB, vendor advisories |
| Exploit Development | Python PoCs, payload crafting, WAF bypass |
| Writeup Analysis | Extract techniques from published writeups |
| Security Posture | Comprehensive security assessment |
| Education | Beginner-friendly concept explanations |
| Creative Thinking | Novel attack vectors, chaining, edge cases |

---

## 🔧 Tool Policy

- **Auto-download**: Portable tools, pip packages, git repos → workspace folder
- **Ask user first**: System installs, admin tools, MCP servers, plugins
- **Python**: 3.14.x+ on Windows 11

---

## 📚 Learning Resources

See `LEARNING-PATH.md` for a complete beginner-to-advanced cybersecurity learning path.

---

## 🔄 Expanded Ideas

This pack expands beyond the original request with:

1. **Vulnerability Chaining Strategies** — Not just finding bugs, but chaining them for critical impact
2. **Parser Differential Attacks** — Exploiting differences between WAF and backend parsing
3. **Protocol-Level Attacks** — HTTP/2, WebSocket, DNS-level exploitation
4. **Supply Chain Analysis** — Third-party script and dependency vulnerability assessment
5. **Cloud-Native Attacks** — AWS/Azure/GCP misconfigurations, K8s escapes, CI/CD pipeline attacks
6. **Automated Security Posture Scoring** — Quantitative assessment across 8 security dimensions
7. **Educational Framework** — Every concept explained from absolute basics with analogies
8. **Creative Offensive Thinking Protocol** — Systematic approach to inventing novel attack vectors
9. **Polyglot Payload Development** — Files valid as multiple formats for bypass
10. **Race Condition Exploitation** — Concurrent request attacks for business logic flaws
