# RECON.md — Reconnaissance Automation Guide

> Reconnaissance is the foundation of bug bounty hunting. The more you know about the target, the more attack surface you can find.

---

## 🔍 Reconnaissance Pipeline

```
Target Domain
    ├── Subdomain Enumeration ──→ Live Host Detection ──→ Tech Fingerprinting
    │                                     ├── Port Scanning
    │                                     ├── Directory Bruteforcing
    │                                     └── Screenshot Capture
    ├── DNS Analysis ──→ Zone Transfers, Dangling CNAMEs
    ├── Certificate Transparency ──→ Historical Subdomains
    ├── Wayback Machine ──→ Old Endpoints, Parameters, JS Files
    ├── Google/GitHub Dorking ──→ Secrets, Internal URLs, Configs
    ├── JavaScript Analysis ──→ Hidden Endpoints, API Keys, Secrets
    ├── Cloud Asset Discovery ──→ S3 Buckets, Azure Blobs, GCP Storage
    └── Social/OSINT ──→ Employee Info, Tech Stack, Internal Tools
```

## 📡 Subdomain Enumeration

### Passive Sources (No direct contact with target)
```bash
# crt.sh — Certificate Transparency logs
curl -s "https://crt.sh/?q=%25.TARGET.com&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u

# subfinder, amass, assetfinder, findomain
subfinder -d TARGET.com -all -recursive -o subfinder.txt
amass enum -passive -d TARGET.com -o amass.txt
assetfinder --subs-only TARGET.com > assetfinder.txt
findomain -t TARGET.com -q > findomain.txt

# Combine and deduplicate
cat subfinder.txt amass.txt assetfinder.txt findomain.txt | sort -u > all_subs.txt
```

### Active Enumeration
```bash
puredns bruteforce wordlist.txt TARGET.com -r resolvers.txt -o bruteforce.txt
gotator -sub known_subs.txt -perm permutations.txt -depth 1 | puredns resolve -r resolvers.txt > permutation_subs.txt
dig axfr TARGET.com @ns1.TARGET.com
```

## 🌐 Live Host Detection & Fingerprinting
```bash
httpx -l all_subs.txt -ports 80,443,8080,8443,8000,3000,9090 \
  -title -tech-detect -status-code -content-length -follow-redirects -o live_hosts.txt
gowitness file -f live_hosts.txt -P screenshots/
whatweb -i live_hosts.txt --log-json=whatweb.json --aggression=3
```

## 🔌 Port Scanning
```bash
rustscan -a TARGET.com -r 1-65535 -- -sV -sC -oN ports.txt
nmap -sS -sV -sC -p- -T4 -A --script=vuln,default TARGET.com -oA nmap_full
nmap -sU --top-ports 200 TARGET.com -oN udp_scan.txt
```

## 📂 Content Discovery
```bash
ffuf -u https://TARGET.com/FUZZ -w wordlist.txt \
  -mc 200,201,301,302,307,401,403,405 -recursion -recursion-depth 2 \
  -e .php,.asp,.aspx,.jsp,.html,.js,.json,.xml,.txt,.bak,.old,.sql,.zip,.tar.gz \
  -o ffuf_results.json -of json

feroxbuster -u https://TARGET.com -w wordlist.txt --depth 4 \
  -x php,asp,aspx,jsp,html,js,json,xml,txt,bak,sql,zip -o ferox_results.txt

# API endpoint discovery
ffuf -u https://api.TARGET.com/FUZZ -w api-wordlist.txt -mc 200,201,401,403,405 -H "Content-Type: application/json"

# GraphQL introspection
curl -s -X POST https://TARGET.com/graphql -H "Content-Type: application/json" \
  -d '{"query":"{ __schema { types { name fields { name type { name } } } } }"}'
```

## 🕸️ JavaScript Analysis

JavaScript files contain: API endpoints, internal URLs, API keys, tokens, secrets, business logic, hidden parameters, debug code, comments with sensitive info.

```bash
cat wayback_urls.txt live_hosts.txt | grep -iE "\.js$" | sort -u > js_files.txt
mkdir js_downloaded
cat js_files.txt | while read url; do
  filename=$(echo "$url" | md5sum | cut -d' ' -f1).js
  curl -s "$url" -o "js_downloaded/$filename"
done
grep -rhoP '["'"'"'](\/[a-zA-Z0-9_\-\/\.]+)["'"'"']' js_downloaded/ | sort -u > js_endpoints.txt
grep -rhoP '(api[_-]?key|api[_-]?secret|token|password|secret|auth)['"'"'"\s]*[:=]['"'"'"\s]*[a-zA-Z0-9_\-]{16,}' js_downloaded/ > js_secrets.txt
```

## ☁️ Cloud Asset Discovery
```bash
# AWS S3
for name in TARGET target-dev target-staging target-prod target-assets target-backup; do
  aws s3 ls s3://$name --no-sign-request 2>/dev/null && echo "OPEN BUCKET: $name"
done

# Azure Blob Storage
for name in TARGET targetdev targetstaging; do
  curl -s "https://$name.blob.core.windows.net/\$root?restype=container&comp=list" | grep -q "EnumerationResults" && echo "OPEN AZURE: $name"
done

# GCP Storage
for name in TARGET target-dev target-staging; do
  curl -s "https://storage.googleapis.com/$name/" | grep -q "ListBucketResult" && echo "OPEN GCP: $name"
done
```

## 🔎 Google & GitHub Dorking

### Google Dorks
```
site:TARGET.com filetype:sql | filetype:db | filetype:log | filetype:bak
site:TARGET.com filetype:env | filetype:cfg | filetype:conf | filetype:ini
site:TARGET.com inurl:admin | inurl:login | inurl:dashboard
site:TARGET.com inurl:api | inurl:swagger | inurl:graphql
site:TARGET.com "error" | "exception" | "stack trace"
site:TARGET.com inurl:redirect= | inurl:url= | inurl:next=
site:TARGET.com inurl:file= | inurl:path= | inurl:document=
```

### GitHub Dorks
```
"TARGET.com" password OR secret OR api_key OR token
org:TARGETORG filename:.env
org:TARGETORG filename:docker-compose.yml
org:TARGETORG filename:.git-credentials
org:TARGETORG extension:pem private
org:TARGETORG extension:sql password
```

## 🔄 Wayback Machine & Historical Data
```bash
waybackurls TARGET.com > wayback.txt
gau TARGET.com >> wayback.txt
cat wayback.txt | sort -u > historical_urls.txt
grep -E "\?" historical_urls.txt | sort -u > params.txt
grep -iE "\.js(\?|$)" historical_urls.txt | sort -u > old_js.txt
grep -iE "\.(json|xml|csv|sql|log|bak|old|backup|zip|tar|gz|conf|cfg|env|ini)" historical_urls.txt | sort -u > sensitive_files.txt
httpx -l sensitive_files.txt -mc 200 -o still_alive.txt
```

## 🎯 Subdomain Takeover Detection

### What Is It?
When a subdomain points (CNAME) to a third-party service that has been decommissioned, an attacker can claim that service and serve content on the subdomain.

### Detection
```bash
subjack -w all_subs.txt -t 100 -timeout 30 -o takeover_results.txt
nuclei -l all_subs.txt -t takeovers/ -o nuclei_takeover.txt
```

### Common Vulnerable Services
| Service | CNAME Pattern | Takeover Method |
|---------|--------------|-----------------|
| GitHub Pages | *.github.io | Create repo with CNAME file |
| Heroku | *.herokuapp.com | Create app with matching name |
| AWS S3 | *.s3.amazonaws.com | Create bucket with same name |
| Shopify | *.myshopify.com | Add domain in Shopify admin |
| Fastly | *.fastly.net | Configure in Fastly dashboard |

## 🤖 Automation
See `scripts/recon_automation.py` for a Python script that automates the entire recon pipeline.

