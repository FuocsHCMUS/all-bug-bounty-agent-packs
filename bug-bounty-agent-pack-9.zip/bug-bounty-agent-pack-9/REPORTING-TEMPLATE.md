# REPORTING-TEMPLATE.md — Bug Bounty Report Templates

> Professional report templates for submitting vulnerabilities to bug bounty programs. A well-written report increases your chances of acceptance and higher rewards.

---

## 📋 Standard Vulnerability Report Template

```markdown
## Title
[Vulnerability Type] in [Feature/Endpoint] allows [Impact]

Example: "Stored XSS in User Profile Bio Field Allows Session Hijacking of Any User"

## Severity
[Critical / High / Medium / Low / Informational]

## CVSS Score
[Score] — [Vector String]
Example: 8.1 — CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:H/I:H/A:N

## Vulnerability Type
[CWE ID and Name]
Example: CWE-79: Improper Neutralization of Input During Web Page Generation (XSS)

## Description
[Clear, concise explanation of the vulnerability. What is it? Why does it exist?
Explain the root cause. A non-technical person should understand the risk.]

## Affected Endpoint(s)
- URL: https://target.com/api/v1/user/profile
- Method: POST
- Parameter: bio

## Steps to Reproduce
1. Navigate to https://target.com/login
2. Log in with valid credentials
3. Go to Profile Settings (https://target.com/settings/profile)
4. In the "Bio" field, enter: `<img src=x onerror=alert(document.cookie)>`
5. Click "Save"
6. Visit your public profile page
7. Observe: JavaScript executes, displaying session cookies

## Proof of Concept

### HTTP Request
[Include the raw HTTP request]

### HTTP Response
[Include relevant parts of the response]

### Screenshots
[Attach screenshots showing each step]

### Video (Optional)
[Link to screen recording]

### PoC Script (If applicable)
[Include minimal script that demonstrates the issue]

## Impact
[Describe the real-world impact. What can an attacker actually do?]

Example:
"An attacker can inject malicious JavaScript that executes in the context of any
user who views the attacker's profile. This allows:
1. Stealing session tokens → Full account takeover
2. Performing actions as the victim (CSRF)
3. Redirecting users to phishing pages
4. Keylogging on the affected page
5. Cryptocurrency mining in victim's browser

Given that this is a stored XSS, it affects ALL users who view the profile,
making it a wormable attack vector."

## Remediation
[Specific, actionable fix recommendations]

Example:
1. Sanitize all user input using a whitelist approach
2. Implement Content Security Policy (CSP) headers
3. Use output encoding appropriate to the context (HTML, JS, URL, CSS)
4. Consider using a library like DOMPurify for client-side sanitization
5. Implement HttpOnly and Secure flags on session cookies

## References
- [OWASP XSS Prevention Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Scripting_Prevention_Cheat_Sheet.html)
- [CWE-79](https://cwe.mitre.org/data/definitions/79.html)
- [Related CVE if applicable]
```

---

## 🔴 Critical Vulnerability Report Template

```markdown
## 🔴 CRITICAL: [Title]

### Executive Summary
[One paragraph explaining the vulnerability and its critical impact in business terms]

### Technical Details
- **Type**: [Vulnerability class]
- **CVSS**: [Score] (Critical)
- **CWE**: [CWE-ID]
- **Affected**: [Systems/endpoints]
- **Prerequisites**: [What attacker needs]

### Reproduction Steps
[Detailed numbered steps with HTTP requests]

### Proof of Concept
[Working PoC code/script — minimal and safe]

### Impact Analysis
- **Confidentiality**: [What data is exposed]
- **Integrity**: [What can be modified]
- **Availability**: [Can service be disrupted]
- **Business Impact**: [Financial, reputational, regulatory]

### Attack Scenario
[Realistic attack narrative showing how this would be exploited]

### Remediation
[Immediate mitigation + long-term fix]

### Timeline
- [Date]: Vulnerability discovered
- [Date]: Report submitted
```

---

## 📊 CVSS Scoring Quick Reference

### CVSS 3.1 Metrics
```
Attack Vector (AV):     Network(N) / Adjacent(A) / Local(L) / Physical(P)
Attack Complexity (AC):  Low(L) / High(H)
Privileges Required (PR): None(N) / Low(L) / High(H)
User Interaction (UI):   None(N) / Required(R)
Scope (S):              Unchanged(U) / Changed(C)
Confidentiality (C):    None(N) / Low(L) / High(H)
Integrity (I):          None(N) / Low(L) / High(H)
Availability (A):       None(N) / Low(L) / High(H)
```

### Common Scores
```
RCE (unauthenticated):           9.8 — CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H
SQLi (data exfiltration):        8.6 — CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:N/A:N
Stored XSS:                      6.1 — CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N
IDOR (read other user data):     6.5 — CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N
Open Redirect:                   4.7 — CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:N/I:L/A:N
Information Disclosure:          5.3 — CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N
```

---

## 💡 Report Writing Tips

1. **Be clear and concise** — Triagers read hundreds of reports
2. **Show, don't tell** — Screenshots and PoCs > paragraphs of text
3. **Demonstrate impact** — Don't just say "XSS", show what it enables
4. **One vulnerability per report** — Unless they're a chain
5. **Include remediation** — Shows professionalism and helps the team
6. **Be professional** — No threats, no demands, no attitude
7. **Follow up politely** — If no response after reasonable time
8. **Accept the decision** — If marked as duplicate or won't fix, learn from it
