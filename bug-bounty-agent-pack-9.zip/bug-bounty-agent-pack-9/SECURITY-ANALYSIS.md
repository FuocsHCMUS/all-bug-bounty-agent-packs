# SECURITY-ANALYSIS.md — Company Security Posture Analysis Framework

> After each engagement, analyze the target's overall security posture. This helps the user learn what good security looks like and what common weaknesses are.

---

## 📊 Security Posture Analysis Framework

### How to Assess a Company's Security

For every target you test, evaluate these dimensions:

```
SECURITY POSTURE REPORT
━━━━━━━━━━━━━━━━━━━━━━

🟢 STRENGTHS (What they do well):
- List specific security controls that are properly implemented
- Example: "Strong CSP headers with nonce-based script loading"
- Example: "Proper rate limiting on authentication endpoints"

🟡 NEEDS IMPROVEMENT:
- Areas where security exists but is incomplete or weak
- Example: "CORS policy allows credentials but origin validation is loose"
- Example: "Session tokens lack HttpOnly flag"

🔴 HIGH RISK:
- Critical security gaps that need immediate attention
- Example: "Admin panel accessible without authentication on staging subdomain"
- Example: "Running Apache 2.4.49 with known path traversal CVE"

🟠 RISK FACTORS:
- Architectural or organizational risks
- Example: "Large attack surface with 200+ subdomains"
- Example: "Multiple third-party JavaScript includes without SRI"
```

---

## 🎯 Assessment Categories

### 1. Input Validation & Output Encoding (Score: /10)
```
CHECK:
- Are all user inputs validated on the server side?
- Is output properly encoded for the context (HTML, JS, URL, CSS)?
- Are parameterized queries used for database access?
- Is file upload validated (type, size, content)?
- Are error messages generic (no stack traces, SQL errors)?

GOOD SIGNS:
✅ Parameterized queries everywhere
✅ Context-aware output encoding
✅ Strict input validation with whitelists
✅ Generic error messages

BAD SIGNS:
❌ SQL errors visible in responses
❌ User input reflected without encoding
❌ File uploads accept any type
❌ Verbose error messages with stack traces
```

### 2. Authentication & Session Management (Score: /10)
```
CHECK:
- Strong password policy enforced?
- Multi-factor authentication available/required?
- Session tokens sufficiently random and long?
- Proper session invalidation on logout?
- Account lockout after failed attempts?
- Secure password reset flow?

GOOD SIGNS:
✅ MFA enforced for sensitive operations
✅ Secure, HttpOnly, SameSite cookies
✅ Session timeout and rotation
✅ Rate limiting on login

BAD SIGNS:
❌ No account lockout
❌ Predictable session tokens
❌ Password reset via GET parameter
❌ No MFA option
```

### 3. Authorization & Access Control (Score: /10)
```
CHECK:
- Are all endpoints properly authorized?
- Can users access other users' data (IDOR)?
- Is role-based access control properly enforced?
- Are admin functions properly restricted?
- Is there proper tenant isolation (multi-tenant apps)?

GOOD SIGNS:
✅ Consistent authorization checks on all endpoints
✅ UUID-based resource identifiers
✅ Server-side role validation
✅ Proper tenant isolation

BAD SIGNS:
❌ Sequential/predictable resource IDs
❌ Client-side only access control
❌ Missing authorization on API endpoints
❌ Admin functions accessible to regular users
```

### 4. Cryptography (Score: /10)
```
CHECK:
- TLS 1.2+ enforced?
- Strong cipher suites?
- Proper certificate management?
- Passwords hashed with bcrypt/argon2?
- Sensitive data encrypted at rest?
- No hardcoded secrets in code?

GOOD SIGNS:
✅ TLS 1.3 with strong ciphers
✅ HSTS with long max-age and includeSubDomains
✅ Certificate pinning for mobile apps
✅ bcrypt/argon2 for password hashing

BAD SIGNS:
❌ TLS 1.0/1.1 supported
❌ Weak ciphers (RC4, DES)
❌ Self-signed certificates
❌ MD5/SHA1 for password hashing
```

### 5. Security Headers (Score: /10)
```
CHECK AND SCORE EACH:
- Content-Security-Policy (CSP)
- X-Content-Type-Options: nosniff
- X-Frame-Options / frame-ancestors
- Strict-Transport-Security (HSTS)
- X-XSS-Protection (legacy but still checked)
- Referrer-Policy
- Permissions-Policy
- Cross-Origin-Resource-Policy (CORP)
- Cross-Origin-Opener-Policy (COOP)
- Cross-Origin-Embedder-Policy (COEP)
```

### 6. API Security (Score: /10)
```
CHECK:
- Authentication required for all endpoints?
- Rate limiting implemented?
- Input validation on all parameters?
- Proper error handling (no data leakage)?
- API versioning?
- Documentation not publicly exposed (Swagger/OpenAPI)?
- GraphQL: introspection disabled in production?
- GraphQL: query depth/complexity limits?
```

### 7. Infrastructure Security (Score: /10)
```
CHECK:
- Unnecessary ports closed?
- Services up to date?
- Default credentials changed?
- Debug endpoints disabled in production?
- Proper network segmentation?
- Cloud resources properly configured?
- No exposed admin panels?
- Proper DNS configuration?
```

### 8. Logging & Monitoring (Score: /10)
```
CHECK:
- Are security events logged?
- Is there alerting on suspicious activity?
- Are logs protected from tampering?
- Is there incident response capability?
- Rate limiting and blocking of attacks?
```

---

## 📝 Security Posture Report Template

```
TARGET: [Company/Application Name]
DATE: [Assessment Date]
SCOPE: [What was tested]

OVERALL SECURITY MATURITY: [Beginner/Developing/Established/Advanced/Elite]
OVERALL RISK LEVEL: [Critical/High/Medium/Low]

DIMENSION SCORES:
┌─────────────────────────────┬───────┐
│ Input Validation            │  ?/10 │
│ Authentication              │  ?/10 │
│ Authorization               │  ?/10 │
│ Cryptography                │  ?/10 │
│ Security Headers            │  ?/10 │
│ API Security                │  ?/10 │
│ Infrastructure              │  ?/10 │
│ Logging & Monitoring        │  ?/10 │
├─────────────────────────────┼───────┤
│ OVERALL                     │  ?/80 │
└─────────────────────────────┴───────┘

TOP STRENGTHS:
1. [Strength 1]
2. [Strength 2]
3. [Strength 3]

TOP RISKS:
1. [Risk 1]
2. [Risk 2]
3. [Risk 3]

RECOMMENDATIONS:
1. [Immediate action needed]
2. [Short-term improvement]
3. [Long-term strategy]
```
