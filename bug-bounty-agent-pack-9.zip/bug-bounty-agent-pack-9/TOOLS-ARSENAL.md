# TOOLS-ARSENAL.md — Bug Bounty Tools Reference

> Complete reference of tools for each phase of bug bounty hunting. Organized by category with installation commands and usage examples.

---

## 🔍 Reconnaissance Tools

### Subdomain Enumeration
| Tool | Language | Install | Purpose |
|------|----------|---------|---------|
| subfinder | Go | `go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest` | Passive subdomain enum |
| amass | Go | `go install github.com/owasp-amass/amass/v4/...@master` | Comprehensive enum |
| assetfinder | Go | `go install github.com/tomnomnom/assetfinder@latest` | Fast passive enum |
| findomain | Rust | Download binary from GitHub | Fast subdomain enum |
| puredns | Go | `go install github.com/d3mondev/puredns/v2@latest` | DNS brute force |
| gotator | Go | `go install github.com/Josue87/gotator@latest` | Subdomain permutations |

### DNS & Network
| Tool | Install | Purpose |
|------|---------|---------|
| dnsx | `go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest` | DNS toolkit |
| nmap | System package | Port scanning, service detection |
| masscan | System package | Fast port scanning |
| rustscan | Download binary | Fastest port scanner |

### HTTP Probing & Fingerprinting
| Tool | Install | Purpose |
|------|---------|---------|
| httpx | `go install github.com/projectdiscovery/httpx/cmd/httpx@latest` | HTTP probing |
| whatweb | System package | Technology fingerprinting |
| wafw00f | `pip install wafw00f` | WAF detection |

### Content Discovery
| Tool | Install | Purpose |
|------|---------|---------|
| ffuf | `go install github.com/ffuf/ffuf/v2@latest` | Fast web fuzzer |
| feroxbuster | Download binary | Recursive content discovery |
| dirsearch | `pip install dirsearch` | Directory brute force |
| gobuster | `go install github.com/OJ/gobuster/v3@latest` | Directory/DNS brute |

### JavaScript & Secret Analysis
| Tool | Install | Purpose |
|------|---------|---------|
| LinkFinder | `pip install linkfinder` | Extract endpoints from JS |
| SecretFinder | Clone from GitHub | Find secrets in JS |
| trufflehog | `pip install trufflehog` | Secret scanning |
| gitleaks | Download binary | Git secret scanning |

### Historical Data
| Tool | Install | Purpose |
|------|---------|---------|
| waybackurls | `go install github.com/tomnomnom/waybackurls@latest` | Wayback Machine URLs |
| gau | `go install github.com/lc/gau/v2/cmd/gau@latest` | Get All URLs |

### Screenshots
| Tool | Install | Purpose |
|------|---------|---------|
| gowitness | `go install github.com/sensepost/gowitness@latest` | Web screenshots |
| eyewitness | Clone from GitHub | Screenshots + categorization |

---

## ⚔️ Vulnerability Scanning Tools

### General Scanners
| Tool | Install | Purpose |
|------|---------|---------|
| nuclei | `go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest` | Template-based scanner |
| nikto | System package | Web server scanner |
| wpscan | `gem install wpscan` | WordPress scanner |
| sqlmap | `pip install sqlmap` | SQL injection automation |
| dalfox | `go install github.com/hahwul/dalfox/v2@latest` | XSS scanner |

### Specialized Tools
| Tool | Install | Purpose |
|------|---------|---------|
| Arjun | `pip install arjun` | Hidden parameter discovery |
| paramspider | `pip install paramspider` | Parameter mining |
| kiterunner | Download binary | API endpoint discovery |
| graphqlmap | Clone from GitHub | GraphQL testing |
| jwt_tool | Clone from GitHub | JWT attack toolkit |
| SSRFmap | Clone from GitHub | SSRF exploitation |
| tplmap | Clone from GitHub | SSTI exploitation |

---

## 🛠️ Exploitation Tools

### Proxy & Interception
| Tool | Purpose |
|------|---------|
| Burp Suite (Community) | HTTP proxy, scanner, repeater, intruder |
| OWASP ZAP | Free alternative to Burp Suite |
| mitmproxy | Python-based HTTP proxy |
| Caido | Modern web security testing tool |

### Payload Generation
| Tool | Purpose |
|------|---------|
| ysoserial | Java deserialization payloads |
| phpggc | PHP deserialization payloads |
| PayloadsAllTheThings | Comprehensive payload repository |

---

## 📦 Wordlists

### Essential Wordlists
| Wordlist | Source | Purpose |
|----------|--------|---------|
| SecLists | github.com/danielmiessler/SecLists | Everything |
| fuzzdb | github.com/fuzzdb-project/fuzzdb | Fuzzing patterns |
| PayloadsAllTheThings | github.com/swisskyrepo/PayloadsAllTheThings | Attack payloads |
| assetnote wordlists | wordlists.assetnote.io | Content discovery |

### Key Wordlist Files
```
SecLists/Discovery/Web-Content/common.txt
SecLists/Discovery/Web-Content/directory-list-2.3-medium.txt
SecLists/Discovery/Web-Content/raft-large-words.txt
SecLists/Discovery/DNS/subdomains-top1million-5000.txt
SecLists/Fuzzing/LFI/LFI-Jhaddix.txt
SecLists/Passwords/Common-Credentials/10-million-password-list-top-10000.txt
```

---

## 🐍 Python Libraries for Bug Bounty

```bash
pip install requests          # HTTP requests
pip install httpx             # Async HTTP client
pip install aiohttp           # Async HTTP
pip install beautifulsoup4    # HTML parsing
pip install lxml              # XML/HTML parsing
pip install pycurl            # Low-level HTTP
pip install dnspython         # DNS queries
pip install python-nmap       # Nmap wrapper
pip install shodan            # Shodan API
pip install censys            # Censys API
pip install pyjwt             # JWT manipulation
pip install cryptography      # Crypto operations
pip install selenium          # Browser automation
pip install playwright        # Modern browser automation
pip install scrapy            # Web scraping
pip install paramiko          # SSH client
pip install impacket          # Network protocols
pip install scapy             # Packet manipulation
```

---

## 🔧 Installation Script

See `scripts/setup_tools.py` for automated tool installation.
