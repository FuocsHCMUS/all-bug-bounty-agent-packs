#!/usr/bin/env python3
"""
CVE Checker — Automated CVE Research & Correlation
Usage: python cve_checker.py -t apache -v 2.4.49
       python cve_checker.py -u https://target.com
Requirements: pip install requests rich
"""
import argparse, json, re, subprocess, sys

try:
    import requests
    from rich.console import Console
    from rich.table import Table
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests", "rich"])
    import requests
    from rich.console import Console
    from rich.table import Table

console = Console()

class CVEChecker:
    def __init__(self):
        self.nvd_api = "https://services.nvd.nist.gov/rest/json/cves/2.0"
        self.results = []

    def search_nvd(self, keyword, max_results=20):
        console.print(f"[blue]Searching NVD for: {keyword}[/]")
        try:
            r = requests.get(self.nvd_api, params={"keywordSearch":keyword,"resultsPerPage":max_results}, timeout=30)
            if r.status_code == 200:
                vulns = r.json().get("vulnerabilities", [])
                console.print(f"[green]Found {len(vulns)} CVEs[/]")
                return vulns
            return []
        except Exception as e:
            console.print(f"[red]NVD error: {e}[/]"); return []

    def parse_cve(self, vuln_data):
        cve = vuln_data.get("cve", {})
        cve_id = cve.get("id", "Unknown")
        descs = cve.get("descriptions", [])
        desc = next((d["value"] for d in descs if d["lang"]=="en"), "No description")
        metrics = cve.get("metrics", {})
        cvss_score, severity = "N/A", "N/A"
        for v in ["cvssMetricV31","cvssMetricV30","cvssMetricV2"]:
            if v in metrics:
                cd = metrics[v][0].get("cvssData", {})
                cvss_score = cd.get("baseScore","N/A")
                severity = cd.get("baseSeverity","N/A")
                break
        refs = [r.get("url","") for r in cve.get("references",[])[:5]]
        return {"id":cve_id,"description":desc[:300],"cvss_score":cvss_score,
                "severity":severity,"references":refs,"published":cve.get("published","")}

    def check_technology(self, tech, version=None):
        keyword = f"{tech} {version}" if version else tech
        vulns = self.search_nvd(keyword)
        table = Table(title=f"CVEs for {keyword}")
        table.add_column("CVE ID", style="red bold")
        table.add_column("CVSS", style="yellow")
        table.add_column("Severity", style="magenta")
        table.add_column("Description", max_width=60)
        parsed = []
        for v in vulns:
            p = self.parse_cve(v); parsed.append(p)
            table.add_row(p["id"], str(p["cvss_score"]), p["severity"], p["description"][:60]+"...")
        console.print(table)
        self.results.extend(parsed)
        return parsed

    def detect_tech_from_url(self, url):
        console.print(f"[blue]Detecting tech for {url}...[/]")
        try:
            import urllib3; urllib3.disable_warnings()
            r = requests.get(url, timeout=10, verify=False, allow_redirects=True)
            detected = {}
            for h in ["Server","X-Powered-By"]:
                if r.headers.get(h): detected[h] = r.headers[h]; console.print(f"  {h}: {r.headers[h]}")
            patterns = {"WordPress":r'wp-content|wordpress',"Drupal":r'Drupal|drupal\.js',
                       "React":r'react\.production|__NEXT_DATA__',"Angular":r'ng-version|angular',
                       "Vue.js":r'vue\.js|__vue__',"jQuery":r'jquery[\.-]\d',
                       "Laravel":r'laravel_session',"Django":r'csrfmiddlewaretoken',
                       "ASP.NET":r'__VIEWSTATE|X-AspNet',"PHP":r'PHPSESSID|X-Powered-By.*PHP'}
            for tech, pat in patterns.items():
                if re.search(pat, r.text+str(r.headers), re.I):
                    detected[tech] = True; console.print(f"  Detected: {tech}")
            return detected
        except Exception as e:
            console.print(f"[red]Error: {e}[/]"); return {}

    def save_results(self, f="cve_results.json"):
        with open(f,"w") as fh: json.dump(self.results, fh, indent=2)
        console.print(f"[green]Saved to {f}[/]")

def main():
    p = argparse.ArgumentParser(description="CVE Checker")
    p.add_argument("-t","--tech"); p.add_argument("-v","--version")
    p.add_argument("-u","--url"); p.add_argument("-o","--output",default="cve_results.json")
    args = p.parse_args()
    c = CVEChecker()
    if args.url:
        det = c.detect_tech_from_url(args.url)
        for t,v in det.items(): c.check_technology(v if isinstance(v,str) else t)
    elif args.tech: c.check_technology(args.tech, args.version)
    else: p.print_help(); return
    c.save_results(args.output)

if __name__ == "__main__":
    main()
