#!/usr/bin/env python3
"""
JavaScript Analyzer — Extract endpoints, secrets from JS files
Usage: python js_analyzer.py -u https://target.com
       python js_analyzer.py -f js_urls.txt
Requirements: pip install requests rich
"""
import argparse, json, re, subprocess, sys
from urllib.parse import urljoin, urlparse
try:
    import requests
    from rich.console import Console
    from rich.table import Table
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests", "rich"])
    import requests
    from rich.console import Console
    from rich.table import Table

console = Console()

class JSAnalyzer:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent":"Mozilla/5.0 BugBountyAgent/1.0"})
        self.session.verify = False
        self.endpoints, self.secrets, self.interesting = set(), [], []
        import urllib3; urllib3.disable_warnings()

    SECRET_PATTERNS = [
        (r'["\']?api[_-]?key["\']?\s*[:=]\s*["\']([a-zA-Z0-9_\-]{16,})["\']', "API Key"),
        (r'["\']?password["\']?\s*[:=]\s*["\']([^"\']{6,})["\']', "Password"),
        (r'AKIA[0-9A-Z]{16}', "AWS Access Key"),
        (r'ghp_[a-zA-Z0-9]{36}', "GitHub Token"),
        (r'sk-[a-zA-Z0-9]{48}', "OpenAI Key"),
        (r'sk_live_[a-zA-Z0-9]{24,}', "Stripe Secret"),
        (r'eyJ[a-zA-Z0-9_\-]+\.eyJ[a-zA-Z0-9_\-]+\.[a-zA-Z0-9_\-]+', "JWT"),
        (r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----', "Private Key"),
        (r'xox[baprs]-[a-zA-Z0-9\-]+', "Slack Token"),
        (r'SG\.[a-zA-Z0-9_\-]{22}\.[a-zA-Z0-9_\-]{43}', "SendGrid Key"),
    ]

    def analyze_js(self, url):
        console.print(f"[blue]Analyzing: {url}[/]")
        try:
            r = self.session.get(url, timeout=15)
            c = r.text
            # Endpoints
            for pat in [r'["\'](\/[a-zA-Z0-9_\-\/\.]+)["\']',
                       r'["\'](https?:\/\/[^\s"\'<>]+)["\']',
                       r'(?:fetch|axios|get|post)\s*\(\s*["\']([^\s"\']+)["\']']:
                for m in re.findall(pat, c):
                    if len(m)>3 and not m.endswith(('.png','.jpg','.css','.svg')):
                        self.endpoints.add(m)
            # Secrets
            for pat, name in self.SECRET_PATTERNS:
                for m in re.finditer(pat, c):
                    self.secrets.append({"type":name,"value":m.group()[:100],"source":url})
                    console.print(f"[bold red]  🔑 {name}: {m.group()[:50]}...[/]")
            # Interesting
            for pat, desc in [(r'(?:innerHTML|outerHTML|document\.write)\s*[=+]',"DOM XSS Sink"),
                              (r'postMessage\s*\(',"postMessage"),(r'eval\s*\(',"eval() usage"),
                              (r'(?:TODO|FIXME|HACK)\s*:?\s*(.{10,60})',"Dev Comment")]:
                for m in re.finditer(pat, c, re.I):
                    self.interesting.append({"type":desc,"match":m.group()[:80],"source":url})
        except Exception as e: console.print(f"[red]  Error: {e}[/]")

    def find_js_files(self, url):
        js_urls = set()
        try:
            r = self.session.get(url, timeout=10)
            for m in re.findall(r'(?:src|href)\s*=\s*["\']([^"\']*\.js(?:\?[^"\']*)?)["\']', r.text):
                js_urls.add(urljoin(url, m))
        except: pass
        return js_urls

    def report(self, output="js_analysis.json"):
        console.print(f"\n[bold]JS Analysis: {len(self.endpoints)} endpoints, {len(self.secrets)} secrets[/]")
        if self.secrets:
            t = Table(title="Secrets Found")
            t.add_column("Type",style="red"); t.add_column("Value",max_width=50)
            for s in self.secrets: t.add_row(s["type"], s["value"][:50])
            console.print(t)
        with open(output,"w") as f:
            json.dump({"endpoints":sorted(self.endpoints),"secrets":self.secrets,
                       "interesting":self.interesting}, f, indent=2)

def main():
    p = argparse.ArgumentParser(description="JS Analyzer")
    p.add_argument("-u","--url"); p.add_argument("-f","--file")
    p.add_argument("-o","--output",default="js_analysis.json")
    args = p.parse_args()
    a = JSAnalyzer()
    if args.url:
        for js in a.find_js_files(args.url): a.analyze_js(js)
    elif args.file:
        with open(args.file) as f:
            for l in f:
                if l.strip(): a.analyze_js(l.strip())
    a.report(args.output)

if __name__ == "__main__":
    main()
