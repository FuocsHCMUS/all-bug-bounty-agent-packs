#!/usr/bin/env python3
"""
Bug Bounty Recon Automation Script
Usage: python recon_automation.py -d target.com [--full] [--passive-only]
Requirements: pip install requests dnspython rich beautifulsoup4 aiohttp
"""
import argparse, json, os, re, subprocess, sys, time
from datetime import datetime
from pathlib import Path

try:
    import requests, dns.resolver
    from rich.console import Console
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install",
                          "requests", "dnspython", "rich", "beautifulsoup4"])
    import requests, dns.resolver
    from rich.console import Console

console = Console()

class ReconAutomation:
    def __init__(self, domain, output_dir=None):
        self.domain = domain
        self.output_dir = output_dir or f"recon_{domain}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.subdomains = set()
        self.live_hosts = []
        self.dns_records = {}
        self.findings = []
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)

    def log(self, msg, level="info"):
        colors = {"info":"blue","success":"green","warning":"yellow","error":"red","critical":"bold red"}
        console.print(f"[{colors.get(level,'white')}][{level.upper()}] {msg}[/]")

    def enum_crtsh(self):
        self.log(f"Querying crt.sh for {self.domain}...")
        subs = set()
        try:
            r = requests.get(f"https://crt.sh/?q=%25.{self.domain}&output=json", timeout=30)
            if r.status_code == 200:
                for e in r.json():
                    for s in e.get("name_value","").split("\n"):
                        s = s.strip().lower().replace("*.","")
                        if s.endswith(self.domain): subs.add(s)
                self.log(f"crt.sh: {len(subs)} subdomains", "success")
        except Exception as e: self.log(f"crt.sh error: {e}", "error")
        return subs

    def enum_hackertarget(self):
        self.log(f"Querying HackerTarget for {self.domain}...")
        subs = set()
        try:
            r = requests.get(f"https://api.hackertarget.com/hostsearch/?q={self.domain}", timeout=30)
            if r.status_code == 200 and "error" not in r.text.lower():
                for line in r.text.strip().split("\n"):
                    if "," in line:
                        s = line.split(",")[0].strip().lower()
                        if s.endswith(self.domain): subs.add(s)
                self.log(f"HackerTarget: {len(subs)} subdomains", "success")
        except Exception as e: self.log(f"HackerTarget error: {e}", "error")
        return subs

    def enum_rapiddns(self):
        self.log(f"Querying RapidDNS for {self.domain}...")
        subs = set()
        try:
            r = requests.get(f"https://rapiddns.io/subdomain/{self.domain}?full=1", timeout=30)
            if r.status_code == 200:
                pattern = r'<td>([a-zA-Z0-9\-\.]+\.' + re.escape(self.domain) + r')</td>'
                subs = set(m.lower() for m in re.findall(pattern, r.text))
                self.log(f"RapidDNS: {len(subs)} subdomains", "success")
        except Exception as e: self.log(f"RapidDNS error: {e}", "error")
        return subs

    def enumerate_subdomains(self):
        self.log("Starting subdomain enumeration...")
        for src in [self.enum_crtsh, self.enum_hackertarget, self.enum_rapiddns]:
            try: self.subdomains.update(src())
            except Exception as e: self.log(f"Error: {e}", "error")
        self.log(f"Total unique subdomains: {len(self.subdomains)}", "success")
        with open(os.path.join(self.output_dir, "subdomains.txt"), "w") as f:
            f.writelines(f"{s}\n" for s in sorted(self.subdomains))

    def analyze_dns(self):
        self.log("Analyzing DNS records...")
        for sub in sorted(self.subdomains):
            self.dns_records[sub] = {}
            for rtype in ["A","AAAA","CNAME","MX","NS","TXT"]:
                try:
                    answers = dns.resolver.resolve(sub, rtype)
                    self.dns_records[sub][rtype] = [str(r) for r in answers]
                except: pass
            if "CNAME" in self.dns_records[sub] and "A" not in self.dns_records[sub]:
                cname = self.dns_records[sub]["CNAME"][0]
                self.findings.append(f"POTENTIAL SUBDOMAIN TAKEOVER: {sub} -> {cname}")
                self.log(f"Potential takeover: {sub} -> {cname}", "critical")
        with open(os.path.join(self.output_dir, "dns_records.json"), "w") as f:
            json.dump(self.dns_records, f, indent=2)

    def check_live_hosts(self):
        self.log("Checking for live hosts...")
        import urllib3; urllib3.disable_warnings()
        for sub in sorted(self.subdomains):
            for scheme in ["https","http"]:
                url = f"{scheme}://{sub}"
                try:
                    r = requests.get(url, timeout=5, allow_redirects=True, verify=False)
                    title = ""
                    m = re.search(r"<title[^>]*>(.*?)</title>", r.text, re.I|re.S)
                    if m: title = m.group(1).strip()[:100]
                    info = {"subdomain":sub,"url":url,"status":r.status_code,
                            "title":title,"server":r.headers.get("Server",""),
                            "content_length":len(r.content),"headers":dict(r.headers)}
                    self.live_hosts.append(info)
                    self.log(f"LIVE: {url} [{r.status_code}] {title}", "success")
                    break  # found live, skip other scheme
                except: pass
        with open(os.path.join(self.output_dir, "live_hosts.json"), "w") as f:
            json.dump(self.live_hosts, f, indent=2)
        self.log(f"Found {len(self.live_hosts)} live hosts")

    def analyze_security_headers(self):
        self.log("Analyzing security headers...")
        important = ["Content-Security-Policy","X-Content-Type-Options","X-Frame-Options",
                     "Strict-Transport-Security","Referrer-Policy","Permissions-Policy"]
        results = []
        for host in self.live_hosts:
            hdrs = {k.lower():v for k,v in host.get("headers",{}).items()}
            missing = [h for h in important if h.lower() not in hdrs]
            present = [h for h in important if h.lower() in hdrs]
            results.append({"url":host["url"],"present":present,"missing":missing})
            if missing:
                self.findings.append(f"Missing headers on {host['url']}: {', '.join(missing)}")
        with open(os.path.join(self.output_dir, "security_headers.json"), "w") as f:
            json.dump(results, f, indent=2)

    def generate_dorks(self):
        self.log("Generating Google dorks...")
        d = self.domain
        dorks = [
            f'site:{d} filetype:sql OR filetype:db OR filetype:log',
            f'site:{d} filetype:env OR filetype:cfg OR filetype:conf',
            f'site:{d} inurl:admin OR inurl:login OR inurl:dashboard',
            f'site:{d} inurl:api OR inurl:swagger OR inurl:graphql',
            f'site:{d} "error" OR "exception" OR "stack trace"',
            f'site:{d} inurl:redirect= OR inurl:url= OR inurl:next=',
            f'"{d}" password OR secret OR api_key site:github.com',
        ]
        with open(os.path.join(self.output_dir, "google_dorks.txt"), "w") as f:
            f.writelines(f"{dk}\n" for dk in dorks)

    def generate_report(self):
        subs = "\n".join(f"  - {s}" for s in sorted(self.subdomains))
        hosts = "\n".join(f"  - [{h['status']}] {h['url']} — {h['title']}" for h in self.live_hosts)
        finds = "\n".join(f"  🔴 {f}" for f in self.findings)
        report = f"""# Recon Report: {self.domain}
# Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Summary
- Subdomains: {len(self.subdomains)}
- Live Hosts: {len(self.live_hosts)}
- Findings: {len(self.findings)}

## Subdomains
{subs}

## Live Hosts
{hosts}

## Interesting Findings
{finds}
"""
        with open(os.path.join(self.output_dir, "report.md"), "w") as f:
            f.write(report)
        self.log("Report generated!", "success")
        console.print(report)

    def run(self, full=False, passive_only=False):
        console.print(f"\n[bold green]{'═'*60}[/]")
        console.print(f"[bold green]  Bug Bounty Recon — {self.domain}[/]")
        console.print(f"[bold green]{'═'*60}[/]\n")
        self.enumerate_subdomains()
        if not passive_only:
            self.analyze_dns()
            self.check_live_hosts()
            self.analyze_security_headers()
        self.generate_dorks()
        self.generate_report()
        console.print(f"\n[bold green]Done! Results: {self.output_dir}[/]")

def main():
    p = argparse.ArgumentParser(description="Bug Bounty Recon Automation")
    p.add_argument("-d","--domain", required=True)
    p.add_argument("-o","--output")
    p.add_argument("--full", action="store_true")
    p.add_argument("--passive-only", action="store_true")
    args = p.parse_args()
    ReconAutomation(args.domain, args.output).run(args.full, args.passive_only)

if __name__ == "__main__":
    main()

