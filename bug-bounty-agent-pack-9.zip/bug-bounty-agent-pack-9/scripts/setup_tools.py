#!/usr/bin/env python3
"""
Setup Tools — Install Python dependencies for bug bounty scripts
Usage: python setup_tools.py
"""
import subprocess, sys

PACKAGES = [
    "requests",
    "httpx",
    "aiohttp",
    "beautifulsoup4",
    "lxml",
    "dnspython",
    "rich",
    "pyjwt",
    "cryptography",
    "python-nmap",
    "paramiko",
    "scapy",
    "shodan",
    "censys",
]

def main():
    print("=" * 50)
    print("  Bug Bounty Agent — Python Setup")
    print("=" * 50)
    print(f"\nPython: {sys.version}")
    print(f"Installing {len(PACKAGES)} packages...\n")

    for pkg in PACKAGES:
        print(f"  Installing {pkg}...", end=" ")
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", pkg, "-q"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            print("✅")
        except subprocess.CalledProcessError:
            print("❌")

    print("\n✅ Setup complete!")
    print("\nAvailable scripts:")
    print("  python scripts/recon_automation.py -d target.com")
    print("  python scripts/cve_checker.py -t apache -v 2.4.49")
    print("  python scripts/vuln_scanner.py -u https://target.com")
    print("  python scripts/subdomain_takeover.py -f subdomains.txt")
    print("  python scripts/js_analyzer.py -u https://target.com")

if __name__ == "__main__":
    main()
