#!/usr/bin/env python3
"""
Subdomain Takeover Checker
Usage: python subdomain_takeover.py -f subdomains.txt
Requirements: pip install requests dnspython rich
"""
import argparse, json, subprocess, sys
try:
    import requests, dns.resolver
    from rich.console import Console
    from rich.table import Table
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests", "dnspython", "rich"])
    import requests, dns.resolver
    from rich.console import Console
    from rich.table import Table

console = Console()

FINGERPRINTS = {
    "github.io": {"cname":["github.io"],"fp":"There isn't a GitHub Pages site here"},
    "herokuapp.com": {"cname":["herokuapp.com"],"fp":"no-such-app"},
    "s3.amazonaws.com": {"cname":["s3.amazonaws.com"],"fp":"NoSuchBucket"},
    "azurewebsites.net": {"cname":["azurewebsites.net"],"fp":"404 Web Site not found"},
    "shopify.com": {"cname":["myshopify.com"],"fp":"Sorry, this shop is currently unavailable"},
    "fastly.net": {"cname":["fastly.net"],"fp":"Fastly error: unknown domain"},
    "zendesk.com": {"cname":["zendesk.com"],"fp":"Help Center Closed"},
    "surge.sh": {"cname":["surge.sh"],"fp":"project not found"},
    "ghost.io": {"cname":["ghost.io"],"fp":"The thing you were looking for is no longer here"},
    "tumblr.com": {"cname":["tumblr.com"],"fp":"There's nothing here"},
    "wordpress.com": {"cname":["wordpress.com"],"fp":"Do you want to register"},
    "webflow.io": {"cname":["proxy.webflow.com"],"fp":"The page you are looking for doesn't exist"},
    "statuspage.io": {"cname":["statuspage.io"],"fp":"You are being redirected"},
    "bitbucket.io": {"cname":["bitbucket.io"],"fp":"Repository not found"},
    "pantheonsite.io": {"cname":["pantheonsite.io"],"fp":"404 error unknown site"},
}

def check_sub(sub):
    result = {"subdomain":sub,"vulnerable":False,"cname":None,"service":None,"details":""}
    try:
        answers = dns.resolver.resolve(sub, "CNAME")
        cname = str(answers[0].target).rstrip(".")
        result["cname"] = cname
    except: return result
    for svc, fp in FINGERPRINTS.items():
        if any(c in cname for c in fp["cname"]):
            try:
                r = requests.get(f"https://{sub}", timeout=10, verify=False)
                if fp["fp"].lower() in r.text.lower():
                    result.update(vulnerable=True, service=svc, details=f"CNAME:{cname}")
            except:
                try:
                    r = requests.get(f"http://{sub}", timeout=10)
                    if fp["fp"].lower() in r.text.lower():
                        result.update(vulnerable=True, service=svc, details=f"CNAME:{cname}")
                except:
                    result.update(vulnerable=True, service=svc, details=f"CNAME:{cname}, unreachable")
            break
    return result

def main():
    p = argparse.ArgumentParser(description="Subdomain Takeover Checker")
    p.add_argument("-f","--file", required=True)
    p.add_argument("-o","--output", default="takeover_results.json")
    args = p.parse_args()
    import urllib3; urllib3.disable_warnings()
    with open(args.file) as f: subs = [l.strip() for l in f if l.strip()]
    console.print(f"[bold green]Checking {len(subs)} subdomains...[/]\n")
    vulns = []
    for sub in subs:
        r = check_sub(sub)
        if r["vulnerable"]:
            vulns.append(r)
            console.print(f"[bold red]🔴 VULNERABLE: {sub} → {r['cname']} ({r['service']})[/]")
        elif r["cname"]:
            console.print(f"[dim]  ✓ {sub} → {r['cname']}[/]")
    table = Table(title="Takeover Results")
    table.add_column("Subdomain",style="red bold"); table.add_column("CNAME",style="yellow")
    table.add_column("Service",style="magenta"); table.add_column("Details",max_width=40)
    for v in vulns: table.add_row(v["subdomain"],v["cname"],v["service"],v["details"])
    console.print(table)
    with open(args.output,"w") as f:
        json.dump({"total":len(subs),"vulnerable":len(vulns),"results":vulns}, f, indent=2)

if __name__ == "__main__":
    main()
