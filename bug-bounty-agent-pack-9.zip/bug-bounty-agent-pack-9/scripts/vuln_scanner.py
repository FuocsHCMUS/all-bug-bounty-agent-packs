#!/usr/bin/env python3
"""
Vulnerability Scanner — Automated Web Vulnerability Detection
Usage: python vuln_scanner.py -u https://target.com
Requirements: pip install requests rich beautifulsoup4
"""
import argparse, json, re, subprocess, sys, time
from urllib.parse import urlparse, parse_qs

try:
    import requests
    from rich.console import Console
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests", "rich", "beautifulsoup4"])
    import requests
    from rich.console import Console

console = Console()

class VulnScanner:
    def __init__(self, url):
        self.url = url.rstrip("/")
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers.update({"User-Agent":"Mozilla/5.0 BugBountyAgent/1.0"})
        self.findings = []
        import urllib3; urllib3.disable_warnings()

    def log(self, msg, level="info"):
        colors = {"info":"blue","vuln":"bold red","safe":"green","warn":"yellow"}
        console.print(f"[{colors.get(level,'white')}][{level.upper()}] {msg}[/]")

    def add_finding(self, title, severity, desc, evidence="", fix=""):
        self.findings.append({"title":title,"severity":severity,"description":desc,
                              "evidence":evidence,"remediation":fix,"url":self.url})
        self.log(f"🔴 {severity}: {title}", "vuln")

    def check_security_headers(self):
        self.log("Checking security headers...")
        try:
            r = self.session.get(self.url, timeout=10)
            for h,d in {"Content-Security-Policy":"Prevents XSS","X-Content-Type-Options":"Prevents MIME sniffing",
                        "X-Frame-Options":"Prevents clickjacking","Strict-Transport-Security":"Enforces HTTPS",
                        "Referrer-Policy":"Controls referrer info","Permissions-Policy":"Controls features"}.items():
                if h.lower() not in {k.lower() for k in r.headers}:
                    self.add_finding(f"Missing {h}", "Low", f"{h} not set. {d}.", fix=f"Add {h} header.")
                else: self.log(f"  ✅ {h} present", "safe")
            for h in ["Server","X-Powered-By","X-AspNet-Version"]:
                if h in r.headers:
                    self.add_finding(f"Info Disclosure: {h}", "Info",
                        f"{h} reveals: {r.headers[h]}", fix=f"Remove {h} header.")
        except Exception as e: self.log(f"Error: {e}", "warn")

    def check_cors(self):
        self.log("Checking CORS...")
        for origin in ["https://evil.com","null"]:
            try:
                r = self.session.get(self.url, headers={"Origin":origin}, timeout=10)
                acao = r.headers.get("Access-Control-Allow-Origin","")
                acac = r.headers.get("Access-Control-Allow-Credentials","")
                if acao == origin or acao == "*":
                    sev = "High" if acac.lower()=="true" else "Medium"
                    self.add_finding("CORS Misconfiguration", sev,
                        f"Origin '{origin}' allowed. Credentials: {acac}",
                        fix="Implement strict origin whitelist.")
            except: pass

    def check_open_redirect(self):
        self.log("Checking open redirects...")
        for param in ["url","redirect","next","return","returnTo","goto","dest","redirect_uri","continue"]:
            try:
                r = self.session.get(f"{self.url}?{param}=https://evil.com", timeout=10, allow_redirects=False)
                loc = r.headers.get("Location","")
                if "evil.com" in loc:
                    self.add_finding("Open Redirect", "Medium",
                        f"Parameter '{param}' redirects to attacker URL.", fix="Validate redirect URLs.")
            except: pass

    def check_reflected_xss(self):
        self.log("Checking reflected XSS...")
        canary = "xss_canary_9a8b7c"
        for param in ["q","search","query","s","keyword","id","name","page","input","text"]:
            try:
                r = self.session.get(f"{self.url}?{param}={canary}", timeout=10)
                if canary in r.text:
                    ctx = []
                    if re.search(f'<[^>]*{canary}', r.text): ctx.append("HTML")
                    if re.search(f'=["\'][^"\']*{canary}', r.text): ctx.append("attribute")
                    if re.search(f'<script[^>]*>[^<]*{canary}', r.text): ctx.append("JS")
                    self.add_finding("Potential Reflected XSS", "Medium",
                        f"Input reflected via '{param}'. Contexts: {ctx}", fix="Use output encoding + CSP.")
            except: pass

    def check_sensitive_files(self):
        self.log("Checking sensitive files...")
        checks = {
            "/.git/HEAD":"Exposed Git Repository","/.env":"Exposed Environment File",
            "/.svn/entries":"Exposed SVN","/.DS_Store":"Exposed DS_Store",
            "/robots.txt":"Robots.txt Found","/sitemap.xml":"Sitemap Found",
            "/.well-known/security.txt":"Security.txt Found",
            "/wp-login.php":"WordPress Login","/admin":"Admin Panel",
            "/swagger/":"Swagger UI","/graphql":"GraphQL Endpoint",
            "/api/docs":"API Documentation","/debug":"Debug Endpoint",
            "/phpinfo.php":"PHPInfo Exposed","/server-status":"Server Status",
            "/backup/":"Backup Directory","/.htaccess":"Exposed htaccess",
            "/config.json":"Config File","/package.json":"Package.json Exposed",
        }
        for path, title in checks.items():
            try:
                r = self.session.get(f"{self.url}{path}", timeout=5)
                if r.status_code == 200 and len(r.content) > 0:
                    sev = "Critical" if path in ["/.env","/.git/HEAD"] else \
                          "High" if path in ["/phpinfo.php","/server-status","/debug"] else \
                          "Medium" if path in ["/admin","/swagger/","/backup/"] else "Info"
                    self.add_finding(title, sev, f"Accessible at {self.url}{path}",
                        evidence=r.text[:200], fix=f"Restrict access to {path}")
            except: pass

    def check_http_methods(self):
        self.log("Checking HTTP methods...")
        try:
            r = self.session.options(self.url, timeout=10)
            allow = r.headers.get("Allow","")
            if allow:
                dangerous = [m for m in ["PUT","DELETE","TRACE","CONNECT"] if m in allow.upper()]
                if dangerous:
                    self.add_finding("Dangerous HTTP Methods Enabled", "Medium",
                        f"Methods enabled: {allow}. Dangerous: {dangerous}",
                        fix="Disable unnecessary HTTP methods.")
        except: pass

    def generate_report(self, output="vuln_scan_results.json"):
        with open(output, "w") as f:
            json.dump({"target":self.url,"date":time.strftime("%Y-%m-%d %H:%M:%S"),
                       "total":len(self.findings),"findings":self.findings}, f, indent=2)
        self.log(f"Report: {output}", "safe")
        console.print(f"\n[bold]{'═'*50}[/]")
        console.print(f"[bold]Scan: {self.url} | Findings: {len(self.findings)}[/]")
        for f in self.findings:
            color = {"Critical":"red","High":"red","Medium":"yellow","Low":"blue","Info":"dim"}.get(f["severity"],"white")
            console.print(f"  [{color}][{f['severity']}] {f['title']}[/]")

    def run(self, full=False):
        console.print(f"\n[bold green]Scanning: {self.url}[/]\n")
        self.check_security_headers()
        self.check_cors()
        self.check_open_redirect()
        self.check_reflected_xss()
        self.check_sensitive_files()
        self.check_http_methods()
        self.generate_report()

def main():
    p = argparse.ArgumentParser(description="Vulnerability Scanner")
    p.add_argument("-u","--url", required=True)
    p.add_argument("--full", action="store_true")
    p.add_argument("-o","--output", default="vuln_scan_results.json")
    args = p.parse_args()
    VulnScanner(args.url).run(args.full)

if __name__ == "__main__":
    main()

