---
name: bug-bounty-research
description: Use when working inside the Bug Bounty Agent Pack on program research, CVE applicability, bounded security experiments, vulnerability reports, or beginner pentest and SOC lessons.
---

# Workspace Skill Bridge

This bridge belongs to the complete Bug Bounty Agent Pack. Resolve paths from this file, not from a guessed current working directory.

1. Read [shared instructions](../../../AGENTS.md).
2. Read the [canonical portable skill](../../../SKILL.md).
3. Select only the references relevant to the current phase and use the linked artifact templates.

If the linked files are unavailable, report that the pack is incomplete. Do not guess missing instructions. This bridge is not a standalone global skill; retain the whole workspace.
