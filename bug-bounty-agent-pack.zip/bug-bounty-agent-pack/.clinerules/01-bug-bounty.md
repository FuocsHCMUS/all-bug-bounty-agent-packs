# Bug Bounty Agent Pack Loader

Read `AGENTS.md` and `SKILL.md` at the workspace root containing this `.clinerules` directory. Follow the canonical workflow and the owner's exact tool, download, pip, and confirmation preferences. Load references selectively. Produce English artifacts, explain foundational concepts, and prepare evidence-backed reports for owner review. This rule adds no separate permission grant or duplicated operating policy.
