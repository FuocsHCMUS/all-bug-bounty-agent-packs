# Bug Bounty Agent Pack

An English research and learning workspace for Claude Code, Codex, OpenCode, Cline, Cursor, and Google Antigravity. Designed for a cybersecurity student using Windows 11 and Python 3.14.x or later.

The pack combines senior penetration-testing judgment with beginner-friendly teaching: understand the system, formulate a precise hypothesis, collect evidence, distinguish a signal from a vulnerability, and explain the result from both offensive and defensive perspectives. It supplies instructions and local organizational utilities, not a scanner or an unattended exploitation service. No company has been tested as part of creating this pack.

## Start here

1. Open **this folder itself** as the agent's workspace. Opening its parent does not guarantee that a nested `AGENTS.md` will load.
2. Read [AGENTS.md](AGENTS.md), then [SKILL.md](SKILL.md).
3. Use [START-HERE.md](START-HERE.md) for copy-and-paste launch prompts.
4. Check [platform setup](adapters/SETUP.md) for your agent. Confirm the actual files loaded rather than assuming compatibility.
5. Begin with public program research or a local lab. A live session needs a current program brief, explicit scope, and a bounded test plan.

Everything written by the pack is English. An agent can explain material conversationally in another language if requested, while preserving English artifact names and technical terminology.

## What is included

| Resource | Purpose |
|---|---|
| [AGENTS.md](AGENTS.md) | Shared role, preferences, execution policy, evidence standards |
| [SKILL.md](SKILL.md) | Portable workflow and routing to detailed references |
| [Master prompt](prompts/MASTER-PROMPT.md) | Full session launch and orchestration prompt |
| [Prompt catalog](prompts/CATALOG.md) | Focused task prompts and expected outputs |
| [References](references/INDEX.md) | Foundations, CVEs, hypothesis design, web/API testing, reports, SOC, learning |
| [Templates](templates/INDEX.md) | Program, experiment, evidence, finding, lesson, and handoff records |
| [Example engagement](examples/harbor-notes/README.md) | Fictional end-to-end example using owned test identities |
| [Local helper](scripts/workspace.py) | Create an engagement folder and hash local evidence |
| [Validation](scripts/validate_pack.py) | Check local links, skill headers, examples, and required files |
| [Validation record](VALIDATION.md) | Executed checks, manual review, and integration coverage limits |
| [Sources](SOURCES.md) | Official platform sources and research entry points |
| [Evaluation scenarios](evals/SCENARIOS.md) | Behavioral acceptance checks; no live targets |

## Working directories

```text
bug-bounty-agent-pack/
  AGENTS.md
  SKILL.md
  .agents/skills/bug-bounty-research/SKILL.md
  .cursor/rules/bug-bounty.mdc
  .clinerules/01-bug-bounty.md
  .opencode/agents/bug-bounty-research.md
  adapters/
  prompts/
  references/
  templates/
  examples/
  scripts/
  evals/
  engagements/                 created when needed; private working records
  tools/                      portable acquisitions; created when needed
  .venv/                      optional workspace-local Python environment
```

`SKILL.md` at the root is the portable canonical workflow. The discovered skill under `.agents/skills/` is a small workspace bridge; it requires the complete pack, so do not copy only that bridge into a global skills directory. Claude Code and Cline can follow the root instructions without installing a skill. Their optional native skill setup is explained separately.

## Local utilities

These commands only inspect or write local files. They do not access the network or run downloaded programs. Future agents should still announce script execution as described in `AGENTS.md` unless it has already been approved for that session.

```powershell
python .\scripts\validate_pack.py
python .\scripts\workspace.py init my-program
python .\scripts\workspace.py hash .\engagements\my-program\evidence
```

The initializer refuses to overwrite an engagement. Hashing prints a manifest to standard output and does not modify evidence. The helpers use Python's standard library and were designed for Python 3.14 on Windows; no pip install is required.

## Working agreement

Public listings help discover programs; their current briefs define what can be tested. HackerOne and Bugcrowd are research and reporting platforms, not implied testing targets. The agent can research public material and build local experiments independently. It should execute a live test only when the particular asset, method, accounts, and activity budget are covered. Prepare reports for the owner to review and submit; do not submit or contact a company automatically.

No bounty, novelty, vulnerability, or company-wide security rating is guaranteed. Good outcomes include a validated finding, a disproven hypothesis, an evidence-backed control observation, or a useful lesson.
