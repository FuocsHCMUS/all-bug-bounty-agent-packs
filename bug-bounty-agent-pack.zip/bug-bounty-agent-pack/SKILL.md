---
name: bug-bounty-research
description: Use when researching a scoped bug-bounty program or local security lab, assessing CVE applicability, designing evidence-based experiments, drafting vulnerability reports, or teaching the resulting pentest and SOC concepts.
---

# Bug Bounty Research

Produce reproducible security research and a student learning trail. Read [AGENTS.md](AGENTS.md) for the owner's execution preferences. This is a portable skill entrypoint for the complete workspace, not permission to test arbitrary internet systems.

## Select the phase

| Situation | Read next | Deliverable |
|---|---|---|
| No program selected | [Program discovery](references/PROGRAM-DISCOVERY.md) | Shortlist, policy sources, recommended learning fit |
| Program chosen | [Engagement workflow](references/WORKFLOW.md) | Current brief, scope record, bounded plan |
| Product/version/CVE lead | [CVE research](references/CVE-RESEARCH.md) | Applicability matrix and missing prerequisites |
| New write-up or CTF technique | [Research](references/RESEARCH.md) | Source card and transferable invariant |
| Need better hypotheses | [Creative reasoning](references/CREATIVE-REASONING.md) | Ranked hypotheses and discriminating experiments |
| Web/API workflow | [Web and API methods](references/WEB-API.md) | Role/object matrix and minimal controlled checks |
| File, async, browser, cloud, or protocol boundary | [Advanced mechanisms](references/ADVANCED-MECHANISMS.md) | Mechanism model and lab-first plan |
| Tool/dependency needed | [Windows tooling](references/WINDOWS-TOOLS.md) | Concrete command plan and acquisition manifest |
| Suspicious result | [Validation](references/VALIDATION.md) | Evidence-backed finding, false positive, or uncertainty |
| Validated issue to report | [Reporting](references/REPORTING.md) | Owner-reviewable report and evidence index |
| Security strengths and risks | [Control observations](references/CONTROL-OBSERVATIONS.md) | Bounded assessment with confidence and unknowns |
| Beginner needs explanation | [Foundations](references/FOUNDATIONS.md), [Teaching](references/TEACHING.md) | Concept note and exercise |
| Connect offense to defense | [SOC bridge](references/SOC-BRIDGE.md) | Telemetry requirements and detection hypothesis |
| Resume or switch agent | [Continuity](references/CONTINUITY.md) | Handoff with exact state and evidence links |

## Core loop

1. Establish mode, objective, known context, and unresolved dependencies. If live authorization is missing, do public research or local analysis.
2. Model the legitimate system: actors, data, trust boundaries, invariants, and state changes. Explain prerequisites to the learner.
3. Build a short hypothesis ledger. Rank ideas by plausible impact, evidence quality, information gain, effort, and permitted testability.
4. Read primary sources and record exact prerequisites. Translate write-ups into mechanisms rather than copying attacks blindly.
5. Design the smallest experiment that distinguishes the hypothesis from normal behavior. Include a negative control and confounders.
6. Before execution, apply the owner's confirmation preferences and current program limits. A preapproved bounded plan can cover its listed commands.
7. Record facts separately from inference. Evaluate alternative explanations. Repeat only when needed for reproducibility or to resolve uncertainty.
8. Produce a concise finding or honest non-finding, remediation and retest criteria, a bounded control observation, and a beginner lesson.
9. Update state, budget, tool/source records, and the next useful question. Prepare reports for the owner to submit.

## Completion standard

A session is useful when it leaves one or more of: validated findings; disproven hypotheses; narrowed applicability; reproducible local demonstrations; sourced research cards; tested control observations; or a concrete learning artifact. Do not optimize for number of alerts, severity labels, or dramatic exploit claims.

Templates are indexed in [templates/INDEX.md](templates/INDEX.md). Task prompts are indexed in [prompts/CATALOG.md](prompts/CATALOG.md). For a worked fictional engagement, read [Harbor Notes](examples/harbor-notes/README.md).
