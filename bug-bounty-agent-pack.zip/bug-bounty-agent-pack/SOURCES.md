# Sources and Update Policy

Platform compatibility pages were consulted on 2026-11-03. They are point-in-time references; recheck before changing adapters. Security links are primary-source research entry points, not preloaded vulnerability intelligence. No specific live CVE applicability or current program eligibility is asserted by this pack.

## Agent configuration

- [Claude Code memory and AGENTS.md](https://code.claude.com/docs/en/memory): direct AGENTS support, precedence caveats, import fallback.
- [Claude Code skills](https://code.claude.com/docs/en/skills): native skill layout and discovery.
- [Codex project instructions](https://developers.openai.com/codex/guides/agents-md): instruction hierarchy and overrides.
- [Codex skills](https://developers.openai.com/codex/skills): shared project skill location and progressive loading.
- [OpenCode rules](https://opencode.ai/docs/rules/), [skills](https://opencode.ai/docs/skills/), [agents](https://opencode.ai/docs/agents/): project instruction, skill, and optional agent formats.
- [Cline rules](https://docs.cline.bot/customization/cline-rules), [skills](https://docs.cline.bot/customization/skills): AGENTS compatibility, native rules, native skill locations.
- [Cursor rules](https://cursor.com/docs/rules), [skills](https://cursor.com/docs/skills): MDC activation and shared discovery.
- [Antigravity rules](https://antigravity.google/docs/rules/), [skills](https://antigravity.google/docs/skills): AGENTS and shared skills; current trigger syntax.
- [Agent Skills specification](https://agentskills.io/specification): skill metadata and portable folder structure.
- [Python 3.14 virtual environments](https://docs.python.org/3.14/library/venv.html): isolated Python dependency environments.

## Programs and methodology

- [HackerOne researcher updates](https://www.hackerone.com/blog/whats-new-for-hackerone-researchers): platform scope presentation and exclusions; always inspect the individual brief.
- [HackerOne disclosure guidelines](https://www.hackerone.com/terms/disclosure-guidelines): program-specific policies and disclosure.
- [Bugcrowd engagement details](https://docs.bugcrowd.com/researchers/engagement-management/details/): interpreting the engagement brief and explicit targets.
- [OWASP Web Security Testing Guide](https://owasp.org/projects/web-security-testing-guide): test methodology reference. Record the precise version/page when using a specific test.
- [OWASP API Security](https://owasp.org/projects/api-security-project): API risk taxonomy; not proof that a target has any listed weakness.
- [FIRST CVSS v4 specification](https://www.first.org/cvss/v4.0/specification-document): scoring reference. Use the program's requested version and justify metrics.

## Live research entry points to fetch when needed

- [CVE Program](https://www.cve.org/): identifier records and CNA material.
- [NVD](https://nvd.nist.gov/vuln): vulnerability enrichment; compare against the original vendor advisory.
- [CISA KEV](https://www.cisa.gov/known-exploited-vulnerabilities-catalog): known exploitation prioritization; its absence is not a clean bill of health.
- [CISA KEV source repository](https://github.com/cisagov/kev-data): official alternate data source when the site is inaccessible.
- [GitHub Advisory Database](https://github.com/advisories): ecosystem advisories; follow the vendor/upstream references.
- [OSV](https://osv.dev/): ecosystem vulnerability records; establish exact package identity and version first.
- [MITRE CWE](https://cwe.mitre.org/): weakness classification; a CWE is not a CVE or a severity score.
- [MITRE ATT&CK](https://attack.mitre.org/): defensive behavior mapping when evidence supports it.
- [PortSwigger Web Security Academy](https://portswigger.net/web-security): author-maintained web labs and explanatory research.
- [HackerOne Hacktivity](https://hackerone.com/hacktivity): disclosed reports; check each report's actual public status and context.

Some entry-point pages use JavaScript or return access errors to automated readers. Do not claim to have read an inaccessible page. Record access status, find an official alternate, and retain uncertainty. Search results are leads; fetch the supporting page before using a precise claim. Cite original research authors, distinguish paraphrases from quotes, and keep copied excerpts short.
