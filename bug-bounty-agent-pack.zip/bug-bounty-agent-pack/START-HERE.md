# Launch Prompts

Open this folder as the workspace before pasting a prompt. The literal variables in angle brackets are operator inputs; do not treat them as facts if they have not been supplied.

## First session: program discovery and foundations

```text
Read AGENTS.md and SKILL.md in this workspace and follow prompts/MASTER-PROMPT.md.
Start in DISCOVER mode. I am a beginner using Windows 11 and Python 3.14.x+.
Research current public HackerOne and Bugcrowd program information. Prepare a
shortlist based on learning fit, explicit scope, available test identities,
and feature depth. Distinguish bounty programs from disclosure-only programs.
Do not run target tests. Save current policy sources and explain how DNS,
HTTP, authentication, and authorization relate to your proposed first session.
Create the session artifacts and list the concrete inputs needed for testing.
```

## Selected program

```text
Read AGENTS.md and SKILL.md. Use the program URL and brief I provide:
<program URL and saved policy, if available>.
My objective is <feature or learning objective>.
The available owned test identities are <account roles, no secrets>.
Refresh scope and exclusions, build a legitimate-flow model, and draft a bounded
test plan with commands, request budget, controls, stop conditions, and outputs.
Proceed with public research and documentation. Ask before tool/script execution
unless the exact action is already covered by an approval in this session.
Do not submit reports on my behalf.
```

## Entirely local learning

```text
Read AGENTS.md and SKILL.md. Start in LAB mode using only owner-controlled
local material. Teach object-level authorization from the foundations using
two fictional accounts and synthetic records. Draft a minimal local example,
an experiment, a corrected design, and SOC telemetry notes. Explain each term
before using it. Show script commands and ask before execution. Python
dependencies may be installed into a workspace-local venv as already allowed.
```

## Analyze a potential finding

```text
Read AGENTS.md and SKILL.md. Review the evidence under <path>.
Separate observations, hypotheses, local reproduction, target validation,
impact, and novelty. Try to disprove the claim. Produce a finding only if the
evidence supports it; otherwise document the missing discriminating test.
Draft an English report and a beginner lesson. Do not perform new target
activity or send the report without the appropriate scope and approval.
```

## Recheck that instructions loaded

```text
List the exact project instruction and skill files you loaded. State the
current mode, the execution preference for downloaded tools versus pip
dependencies, and the evidence required before calling a CVE applicable.
If a referenced file is not loaded, open it now. Do not claim a native
integration is working merely because a file exists on disk.
```
