# Platform Setup

Documentation checked on 2026-11-03. Installed versions, managed settings, workspace roots, and disabled features can change loading. The references below describe configuration, not a claim that all six clients were executed during pack validation.

Keep the complete pack together and open its root folder. Do not install a pack rule globally unless you deliberately want it applied to unrelated projects. Never overwrite existing agent configuration blindly.

| Agent | Shared instructions | Skill/workflow route in this pack |
|---|---|---|
| Claude Code | Root `AGENTS.md`, subject to native support and instruction-file selection | Explicitly read root `SKILL.md`; optional native skill installation below |
| Codex | Root `AGENTS.md` | Shared `.agents/skills/bug-bounty-research/SKILL.md` bridge |
| OpenCode | Root `AGENTS.md` | Shared skill bridge; optional primary agent in `.opencode/agents/` |
| Cline | Root `AGENTS.md` plus native `.clinerules/01-bug-bounty.md` | Native rule requests reading root `SKILL.md`; optional native skill below |
| Cursor | Root `AGENTS.md` plus `.cursor/rules/bug-bounty.mdc` | Shared `.agents/skills/` bridge |
| Antigravity | Root `AGENTS.md` | Shared `.agents/skills/` bridge |

## Claude Code

Current official documentation describes direct `AGENTS.md` support from v2.1.277. The default prefers `CLAUDE.md` instructions when a qualifying `CLAUDE.md` or `CLAUDE.local.md` exists in the current directory or above it. Consequently, an ancestor file can prevent the expected fallback. Inspect `/memory` or `/context` and the Project instructions setting; version and managed configuration matter. [Official memory documentation](https://code.claude.com/docs/en/memory).

This pack deliberately does not create a root `CLAUDE.md`. Use native `AGENTS.md` support and confirm it loaded. When support is unavailable, the optional [CLAUDE.md import template](claude-code/CLAUDE.md.example) contains `@AGENTS.md`; copy it to the pack root only if needed, or explicitly ask Claude to read both root files. Do not assume a plain sentence mentioning a path is an automatic import.

For native skill discovery, Claude documents `.claude/skills/<name>/SKILL.md`. The root workflow works without this installation. If you want a native skill, ask the agent to prepare a **self-contained copy of the root skill plus referenced files** under `.claude/skills/bug-bounty-research/`, show the copy plan, and obtain the owner's approval to add the skill. Do not copy the workspace bridge alone. [Official skills documentation](https://code.claude.com/docs/en/skills).

## Codex

Launch within the pack root. Check for a higher-priority `AGENTS.override.md` or configured instruction fallback if the wrong rules appear. The shared skill bridge loads the root workflow on demand; it is a project-local convenience. Confirm the skill list and ask the agent to identify loaded sources. No global Codex config changes are required. [Instructions](https://developers.openai.com/codex/guides/agents-md), [skills](https://developers.openai.com/codex/skills).

## OpenCode

Open the pack root and use its `AGENTS.md`. Optionally choose the `bug-bounty-research` primary agent supplied in `.opencode/agents/`. Its job is to load the same workflow; it does not grant extra tool permissions. Keep your existing provider/model/permission settings. External-file references are explicit reading instructions, not an assumed magic include syntax. [Rules](https://opencode.ai/docs/rules/), [skills](https://opencode.ai/docs/skills/), [agents](https://opencode.ai/docs/agents/).

## Cline

Enable the workspace rule in the Rules panel and confirm the root `AGENTS.md` is detected. The provided native rule is intentionally a short loader to avoid maintaining a second policy. Cline also documents native project skills under `.cline/skills/`; installation is optional and needs the owner's approval. As with Claude, prepare a self-contained copy rather than copying only a bridge. [Rules](https://docs.cline.bot/customization/cline-rules), [skills](https://docs.cline.bot/customization/skills).

## Cursor

Check that the project rule appears as Always Apply and that shared skill discovery lists `bug-bounty-research`. The `.mdc` frontmatter uses `alwaysApply: true`; this is Cursor syntax and should not be transplanted into Antigravity. Explicitly request reading the root files if your installed client does not load the expected source. [Rules](https://cursor.com/docs/rules), [skills](https://cursor.com/docs/skills).

## Antigravity

Current documentation supports root `AGENTS.md` and shared `.agents/skills/` in App, CLI, and IDE. Verify the active Customizations list. Root `GEMINI.md` is unnecessary for this pack. If adding a modular rule later, use current Antigravity frontmatter such as `trigger: always_on` or `trigger: model_decision`; invalid rule triggers can be silently ignored. Older `.agent/` layouts exist, but this pack uses the documented `.agents/` layout. [Rules](https://antigravity.google/docs/rules/), [skills](https://antigravity.google/docs/skills).

## Shared smoke check

Paste the instruction-loading check in [START-HERE.md](../START-HERE.md). Expected behavior: identify the correct files; select DISCOVER without a scope; distinguish acquisition from execution; describe an isolated pip environment; refuse to equate a version banner with target validation; prepare reports for owner review. A textual smoke check demonstrates instruction comprehension, not end-to-end browser or network testing.
