# Harbor Notes: A Fictional Learning Engagement

This is a synthetic reasoning example. There is no real company, live endpoint, executed network request, or discovered vulnerability here. The steps below are a designed scenario, not evidence of a performed test.

## Normal system

Harbor Notes lets users create private notes, share them, and queue a PDF export. Alice owns a synthetic note. Bob is a collaborator using another owned test account. The intended product rule in this example is: an export worker must verify that its requester still has access when the export executes, and downloads must also enforce current access.

That rule is an explicit assumption of the fictional product. A real product might document different snapshot semantics, so the researcher must establish the actual contract before claiming a violation.

```text
Bob's browser -> application -> permission check -> queue(job, Bob, note)
                                                      |
Alice revokes Bob's share                              v
                                             worker -> current check -> PDF
```

## Hypothesis and alternatives

`H-001`: the worker may reuse the request-time permission without checking current access. The potential gap is between a decision time and a later use time.

Alternative explanations include documented snapshot semantics, delayed revocation propagation, an inherited permission Bob still holds, a session mix-up, or a stale browser preview. A convincing experiment must distinguish these rather than treating any available PDF as a bypass.

## Local experiment design

Use a local model with two synthetic identities and a worker that can pause before processing. Create a private note owned by Alice, grant Bob access, and verify both identities and roles. Confirm that Bob can read while shared and cannot read after revocation. Queue the export before revocation, pause the worker, revoke access, then resume it.

The positive control is an export for a still-authorized user. The negative control is an export newly requested after Bob's permission is revoked. The decisive observation is the permission decision and resulting artifact at worker execution, not merely the initial HTTP response. Inspect the download decision separately.

No script is included that executes this scenario. A future agent should author and show the small local demonstration, then obtain execution confirmation under the owner's preference.

## Conclusions under possible outcomes

| Hypothetical outcome | Supported conclusion |
|---|---|
| Worker denies Bob and allows Alice | The modeled execution-time control works under these local conditions |
| Worker creates an artifact but download denies Bob | A stale internal operation may exist, but unauthorized retrieval is not shown |
| Worker and download both allow revoked Bob | The fictional contract is violated in the local model |
| Product intentionally grants immutable export snapshots | The original invariant assumption was wrong; investigate the documented contract |
| Identities or permission timing cannot be established | Inconclusive; fix the experiment before making a claim |

Even a successful local demonstration remains `LAB-REPRODUCED`. It does not validate a real service or assign a CVE.

## Root-cause explanation

Authentication answers who Bob is. Authorization answers whether Bob may export that note at the relevant time. A queue decouples when the request is accepted from when the work happens. If the worker uses a stale decision, it can violate a rule that was correctly enforced at request time.

The repair in this modeled design is to carry enough requester/resource/tenant context to make the required execution-time decision, then enforce current access when delivering the result. Implementation details depend on the real application's contract and architecture.

## Control observation

The direct note endpoint's denial would be an observed effective control on that path. It would not prove the worker is correct. Likewise, a worker gap would not justify saying the company lacks all authorization. This example shows why a coverage map is more useful than a whole-company score.

## SOC translation

Proposed events: job creation with requester and note IDs; permission revocation with effective time; worker execution with decision and outcome; artifact retrieval with principal and authorization result. A conceptual detector could join these events and flag a successful export that contradicts the defined permission semantics.

Those fields are proposed, not observed. False positives include clock skew, delayed ingestion, inherited permission, administrator exceptions, and a different snapshot policy.

## Student questions

1. Why does Bob being logged in not settle whether he may export the note?
2. Why is a 200 response from the queue endpoint insufficient to prove unauthorized retrieval?
3. If download access is denied, which part of the impact claim must be narrowed?
4. Which event field is needed to correlate a worker action with Bob's original request?
5. How would a documented snapshot contract change the hypothesis?
