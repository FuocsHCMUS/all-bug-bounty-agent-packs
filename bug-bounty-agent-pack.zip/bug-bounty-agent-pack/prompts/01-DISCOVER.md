# Public Program Research Prompt

```text
Read AGENTS.md, SKILL.md, and references/PROGRAM-DISCOVERY.md. Start in DISCOVER.
My interests are <web/API/identity/other/unknown>; available test accounts and
resources are <details/unknown>. Research current official public HackerOne
and Bugcrowd program information and shortlist a few suitable candidates.

For each candidate record the actual program page, operator, platform, program
type, brief retrieval time, verified eligible assets, exclusions, permitted
methods, account/access requirements, and unknowns. Distinguish a paid bounty
from disclosure-only participation and do not guess current reward amounts.

Compare learning fit, scope clarity, feature depth, evidence feasibility,
access cost, and Windows tooling requirements. Recommend one first feature
and explain its concepts from the prerequisites upward. If information is
inaccessible, mark it unknown and find an official alternate where possible.

Save a program comparison and source cards. Prepare the scope questions and
artifact-level objective for a first session. Do not run target tests, create
accounts, log in, or submit anything. Continue useful foundations work while
any owner selection is pending.
```
