# Feature Model and Experiment Plan

```text
Read AGENTS.md, SKILL.md, references/WORKFLOW.md, and references/WEB-API.md.
Program/lab: <URL/path>. Focus feature: <feature>. Available owned identities:
<roles/tenants>. Existing policy/evidence: <paths>.

Refresh the current brief if this is a live program. Record precise scope,
exclusions, method restrictions, and unresolved conditions. Model the normal
feature using actors, resources, actions, state transitions, and boundaries.
Explain the prerequisite concepts before introducing attack classes.

Build a role/object/action matrix and a short hypothesis ledger. For each
promising idea, specify a violated invariant, prerequisites, confidence,
baseline, changed factor, expected result, negative control, confounders,
minimal evidence, request budget, and stop condition. Choose a first experiment
based on information gain, impact evidence, effort, and permitted testability.

Save the program, scope, state, hypotheses, and experiment drafts. Show exact
tool/script commands and side effects before requesting execution confirmation.
Keep public research and local reasoning moving if live inputs are incomplete.
```
