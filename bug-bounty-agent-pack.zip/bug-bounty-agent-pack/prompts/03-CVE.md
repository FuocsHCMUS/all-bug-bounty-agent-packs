# CVE Applicability Research

```text
Read AGENTS.md, SKILL.md, and references/CVE-RESEARCH.md.
Observed component/build evidence: <evidence path/unknown>.
Candidate advisory or CVE: <identifier/URL/needs research>.
Relevant program/lab: <context>.

Fetch current primary advisories, CNA/CVE records, relevant upstream patches,
and release notes. Establish exact product/component/package identity,
affected version semantics, configuration, privileges, reachable code path,
platform/build assumptions, backports, and mitigations. Date the source cards.

Create an applicability matrix with supporting evidence, contradictions,
unknowns, and a next discriminating check for every prerequisite. Keep a header
fingerprint separate from deployment evidence. Separate lab reproduction from
target validation, technical severity from observed impact, and prioritization
signals from proof of exploitation.

Propose a harmless local mechanism demonstration or source review if useful.
Do not run exploit code or broaden scanning. Finish with an applicability state,
confidence, limitations, and a beginner explanation of CVE/CWE/CVSS differences.
```
