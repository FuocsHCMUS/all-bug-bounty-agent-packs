# Write-up, Patch, or CTF Deconstruction

```text
Read AGENTS.md, SKILL.md, and references/RESEARCH.md.
Source: <URL/path>. My current understanding: <beginner/notes>.

Read the original source and relevant primary references. Extract normal
behavior, protected invariant, attacker-controlled input, transformations,
trust boundary, prerequisites, actual observation, impact, and repair.
Identify the minimum concept chain a beginner needs and teach it in order.

If this is a CTF, list artificial assumptions and explain which would need
independent evidence in production. If this is a patch, identify the restored
invariant and relevant call sites without assuming every sibling is affected.

Produce a dated source card, a plain-language mechanism diagram, a transfer
checklist, and a small local exercise plan. Generate two or three related
hypotheses by changing meaningful state or representation assumptions; label
them hypotheses. Do not copy endpoint names or exploit steps into live tests
without applicability and scope evidence. Do not run downloaded code.
```
