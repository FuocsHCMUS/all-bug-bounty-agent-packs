# Creative Research Hypotheses

```text
Read AGENTS.md, SKILL.md, and references/CREATIVE-REASONING.md.
Feature/data-flow evidence: <paths>. Current known constraints: <details>.

Start with legitimate behavior and explicit security invariants. Generate
distinct hypotheses through identity/ownership, representation, time/state,
alternate surfaces, async delegation, cache keys, and feature composition.
Do not fill a quota with generic attack names or near-duplicate ideas.

For each hypothesis show the exact condition that could violate the invariant,
the evidence motivating it, prerequisites, two plausible benign explanations,
the smallest distinguishing observation, a negative control, and expected
learning value. Separate source-supported facts from architecture guesses.

Rank ideas using plausible impact, prerequisite confidence, information gain,
effort, and permitted testability. For a proposed chain, label every edge and
show that its effect satisfies the next prerequisite. Recommend a first local
or bounded approved experiment. Save the ledger and explain the reasoning so
I learn how to develop hypotheses myself. Do not execute the experiments yet.
```
