# Skeptical Finding Review

```text
Read AGENTS.md, SKILL.md, and references/VALIDATION.md.
Candidate claim: <claim>. Evidence: <paths>. Completed activity: <log path>.

Try to disprove the claim before improving its wording. Decompose it into actor,
action, resource, state, trust boundary, and effect. Verify identity labels,
roles, tenants, ownership, permissions, sessions, timing, cache, tool behavior,
and intended product semantics using existing evidence.

Build an evidence table separating observations, inferences, unsupported
extensions, contradictions, and missing controls. A planned request does not
count as an executed request. A local reproduction does not establish remote
applicability. Do not invent logs or response bodies.

Return TARGET-VALIDATED, LAB-REPRODUCED, DISPROVEN, or INCONCLUSIVE with a narrow
conclusion and confidence rationale. If uncertainty remains, specify the exact
smallest next check and its execution requirements. Save a review note and
update the hypothesis state. Teach the misconception most likely to have
caused a false positive. Do not start new target activity during this review.
```
