# Report Draft for Owner Submission

```text
Read AGENTS.md, SKILL.md, and references/REPORTING.md.
Validated claim and evidence index: <paths>. Program requirements: <path/URL>.

Draft a specific English title and summary that state starting privileges,
affected workflow, violated property, and demonstrated result. Include exact
prerequisites, numbered reproduction, expected versus actual behavior, observed
impact, evidence links, remediation, retest criteria, and limitations.

Separate hypothetical extensions and uncertain deployment reach. Use the
program's severity convention; justify any CVSS version/vector/metrics rather
than inventing a score. Redact secrets and personal data while preserving
causal evidence. Label lab-only or source-only results honestly.

Write a concise triage report and a separate beginner companion lesson. Prepare
the platform field mapping and attachment list locally. Identify any missing
fact that prevents a reproducible submission. I will review and submit the
report; do not contact the company, upload evidence, publish, or press Submit.
```
