# Security Strengths, Gaps, and Risk Notes

```text
Read AGENTS.md, SKILL.md, and references/CONTROL-OBSERVATIONS.md.
Available observations: <paths>. Tested coverage: <scope/experiment paths>.

Analyze what the evidence shows about authentication lifecycle, authorization,
tenant isolation, input handling, browser controls, secrets/data handling,
async workflows, patch evidence, and telemetry. Leave unavailable dimensions
NOT-ASSESSED or UNKNOWN. Do not infer internal company practices from headers.

For each control record objective, exact tested condition, evidence, observed
behavior, interpretation, confidence, coverage limits, residual risk, and a
concrete improvement or follow-up. Distinguish design, implementation,
operation, and visibility. Keep risk separate from confidence.

Describe observed effective controls as carefully as gaps. Explain which
security capability each observation teaches: secure design, AppSec review,
testing, vulnerability management, detection, triage, response, or recovery.
Produce a coverage map and prioritized evidence-backed recommendations. Avoid
company-wide maturity ratings or claims that no findings means secure.
```
