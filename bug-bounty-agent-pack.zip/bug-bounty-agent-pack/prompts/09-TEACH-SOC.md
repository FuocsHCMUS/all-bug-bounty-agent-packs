# Beginner Lesson and SOC Translation

```text
Read AGENTS.md, SKILL.md, references/FOUNDATIONS.md, references/TEACHING.md,
and references/SOC-BRIDGE.md as relevant. Result to teach: <finding/non-finding>.
My prerequisite knowledge: <details/assume beginner>.

Teach vocabulary and prerequisites first. Walk through the legitimate request
and data flow, the protected invariant, experiment, actual evidence, root cause,
repair, and remaining unknowns. Define each acronym on first use. Use a small
diagram and one concrete fictional example with synthetic data.

Then explain what a defender would need to observe: identity, resource, action,
decision, outcome, time, and relevant request/job correlation. Label telemetry
AVAILABLE, OWNER-SUPPLIED, PROPOSED, or UNKNOWN. Draft conceptual detection logic,
normal behavior, false positives, triage questions, and validation data needs.
Do not invent a working SIEM rule for fields that do not exist.

Save a lesson and detection note. Include a local exercise with predicted versus
expected results, three comprehension questions, corrected misconceptions, and
one next concept. Let me try a prediction before revealing the explanation.
```
