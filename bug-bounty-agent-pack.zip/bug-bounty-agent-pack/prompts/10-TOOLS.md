# Tool Acquisition and Execution Proposal

```text
Read AGENTS.md, SKILL.md, and references/WINDOWS-TOOLS.md.
Needed task: <task>. Candidate tool/library: <name/unknown>.

Check whether existing capabilities or Python's standard library suffice.
If a lightweight portable tool is useful, record its official source, version
or commit, expected size, workspace destination, compatibility, and purpose
before an allowed download/clone. Do not execute it just because it was cloned.

For authored Python scripts, use a workspace-local venv and current compatible
dependencies. Pip installation is already allowed there. Check Python 3.14
and Windows support, wheel availability, and runtime assumptions. If a build
requires system tools or another interpreter, explain alternatives and ask
before that system change.

Prepare exact commands, working directories, input/output paths, network
destinations, credential use, request/rate limits, retries, reversibility,
and stop conditions for any proposed execution. Identify what is already
approved and what still needs confirmation. Suggest an MCP/plugin/skill only
for a concrete need, and let me add it. Continue nondependent research meanwhile.
```
