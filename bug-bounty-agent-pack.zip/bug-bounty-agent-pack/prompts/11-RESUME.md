# Resume or Switch Agents

```text
Read AGENTS.md, SKILL.md, and references/CONTINUITY.md.
Engagement: <folder>. Latest checkpoint: <path/locate it>.

Read state, current program/scope, approval records, hypothesis ledger, activity
log, latest experiment, and relevant evidence. Identify exactly what was
executed versus merely planned. Preserve findings, non-findings, consumed
budget, unresolved confounders, and owner decisions with their limits.

Before new live activity, refresh policy and verify sessions/account roles and
environment assumptions. Shared instructions do not transfer browser sessions,
credentials, or application permissions to a different agent. Do not infer a
broad approval from a narrow earlier action.

Return a compact checkpoint: objective, mode, verified scope/time, evidence
state, key artifacts, approvals, spent/remaining budget, blockers, and the next
discriminating action. Save a handoff if switching tools. Continue research,
analysis, or teaching that does not depend on a pending owner answer. Do not
repeat broad reconnaissance simply because the chat context is new.
```
