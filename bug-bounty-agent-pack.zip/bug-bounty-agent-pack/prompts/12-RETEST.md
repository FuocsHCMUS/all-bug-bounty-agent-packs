# Repair Verification and Regression Thinking

```text
Read AGENTS.md, SKILL.md, references/VALIDATION.md, and references/REPORTING.md.
Original finding: <path>. Claimed repair: <source/description>. Current scope
and execution approval: <details/needs confirmation>.

Restate the original invariant and demonstrated conditions. Design a retest
that repeats the relevant sequence, includes a positive control proving the
legitimate feature still works, and checks the most relevant adjacent role,
state, or equivalent entrypoint. Keep the request budget small and explicit.

Distinguish an application repair from an intermediary block or unavailable
feature. If source is supplied, explain how the change restores the invariant;
if only external behavior is visible, state that limit. Do not call a local
regression result proof of a deployed production fix.

Show commands before required execution confirmation. After any approved
retest, report FIX-OBSERVED, STILL-REPRODUCIBLE, or INCONCLUSIVE for the tested
conditions, with exact evidence and remaining coverage limits. Update the
owner's report draft and lesson; do not submit a platform response automatically.
```
