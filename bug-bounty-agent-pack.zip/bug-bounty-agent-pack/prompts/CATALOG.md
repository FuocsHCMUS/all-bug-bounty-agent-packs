# Task Prompt Catalog

Read the shared instructions first. The prompts assume the entire pack is available and preserve its execution preferences. Replace input placeholders before use or explicitly mark them unknown.

| Prompt | Use when | Expected result |
|---|---|---|
| [Master](MASTER-PROMPT.md) | Starting a full session | Mode, plan, notebook, evidence/learning loop |
| [Discover](01-DISCOVER.md) | No program selected | Sourced shortlist and scope questions |
| [Plan](02-PLAN.md) | Program or lab selected | Feature model and bounded experiments |
| [CVE](03-CVE.md) | A component/advisory lead exists | Applicability matrix |
| [Write-up](04-WRITEUP.md) | Learning from research/CTF/patch | Mechanism card and transfer limits |
| [Hypotheses](05-HYPOTHESES.md) | Need original research directions | Ranked falsifiable hypotheses |
| [Validate](06-VALIDATE.md) | A suspicious observation exists | Claim review and decisive next check |
| [Report](07-REPORT.md) | Evidence supports a finding | Owner-reviewable report |
| [Controls](08-CONTROLS.md) | Want strengths/gaps/risk analysis | Coverage-bounded control assessment |
| [Teach/SOC](09-TEACH-SOC.md) | Need foundations and defensive transfer | Lesson, exercise, detection note |
| [Tools](10-TOOLS.md) | A tool or dependency is needed | Acquisition/compatibility/command plan |
| [Resume](11-RESUME.md) | Switching agents or sessions | Verified checkpoint and next action |
| [Retest](12-RETEST.md) | A repair is ready | Bounded regression/retest assessment |

These roles can be performed sequentially by one agent. Parallel agents are optional and require appropriate owner authorization and shared budget coordination.
