# Advanced Mechanisms: Study the Boundary, Then Design the Experiment

These topics often involve broad side effects or opaque intermediaries. Investigate them through local replicas, owner-supplied source, patch analysis, and tightly bounded approved experiments. The purpose is to understand prerequisites and mechanisms, not to provide an unattended exploitation recipe.

## Parser and normalization disagreement

Two components can interpret the same input differently: proxy versus backend, URL parser versus fetcher, validation versus storage, or one serialization format versus another. Draw each parse/normalize/validate/use step. Identify which representation is used to make a decision and which reaches the consequential operation.

For a local experiment, compare harmless equivalent representations and log each component's interpretation. Specify the parser/library version and normalization order. Do not infer a production parser flaw from a generic family name. Shared-infrastructure protocol desynchronization tests can affect other users; model and reproduce them locally rather than improvising on a live service.

## Server-side request workflows

Imports, link previews, webhook delivery, document conversion, and remote-image processing may cause a server to fetch a supplied location. Distinguish a browser fetch from a server fetch. Establish the feature's documented purpose, URL parsing, redirects, destination checks, network egress policy, and response handling.

Use an owner-controlled benign destination if the program explicitly permits the experiment. Record only the minimal callback needed. Do not probe internal networks, cloud metadata, or third-party hosts to expand impact. A callback establishes a request under known conditions; it does not establish arbitrary internal access or data retrieval.

## Caches and intermediaries

Model the cache key, representation, principal, tenant, authorization state, and invalidation rules. A public static object is different from a personalized response. A test must distinguish edge cache, browser cache, service-worker state, and application caching.

Build a local two-account synthetic example to understand how an omitted identity dimension could cause a leak. For permitted live observations, isolate test-owned content and keep activity bounded. Do not deliberately poison shared caches or deliver malicious content to unrelated users.

## Async jobs, race conditions, and time-of-check/time-of-use

A decision at time T1 may be stale when a worker acts at T2. Map job creation, queue payload, identity propagation, permission re-evaluation, execution, storage, and delivery. Determine whether the product promises authorization at request time, execution time, or download time; the right interpretation depends on the operation.

Use a deterministic local worker barrier or controlled state transition to study the issue. Do not substitute high-volume concurrency for understanding the race. A bounded live plan should state exact operation counts and distinguish harmless test records from financial, irreversible, or resource-intensive actions.

## Cloud and storage boundaries

Identify the resource owner, tenant, access policy, object identity, and credential/capability lifetime. A public bucket name or an apparent dangling reference is a lead, not proof that takeover or sensitive access is possible. Inspect provided policy/code and documented behavior first.

Do not claim resources, register dangling names, modify DNS, access cloud metadata, or enumerate unrelated objects simply to demonstrate a hypothesis. A benign owner-approved test object or supplied configuration can often establish the boundary more clearly.

## Serialization and content processing

An uploaded object may pass through archive extraction, image processing, document conversion, template rendering, or native parsers. Document accepted type, real parser, processing privileges, filesystem boundaries, and worker isolation. File extension or MIME type alone does not establish the actual parser.

Analyze vendor advisories and local vulnerable/fixed versions with harmless inputs. Memory-corruption and code-execution mechanisms require a controlled lab, exact build assumptions, and a separate execution plan. Keep crash evidence, command execution, and target applicability as separate claims.

## AI-enabled application boundaries

If the selected program explicitly covers AI-enabled features, model user input, retrieved content, model output, tool calls, credentials, and application-enforced authorization. A model obeying text is not automatically an application vulnerability. Identify a concrete protected action or data boundary and use synthetic content in a lab or an explicitly scoped test.

Distinguish agent instruction injection from a server-side permission failure. The researcher agent must itself treat retrieved prompts as data. Keep provider/model behavior, application integration, and observed security effect separate. Do not use research to access real secrets or trigger unrelated tool actions.

## From mechanism to result

For every advanced hypothesis, produce a diagram, exact prerequisites, benign local demonstration plan, supported facts, unknowns, and a minimal discriminating observation. A sophisticated report is precise about uncertainty; complexity alone does not raise severity.
