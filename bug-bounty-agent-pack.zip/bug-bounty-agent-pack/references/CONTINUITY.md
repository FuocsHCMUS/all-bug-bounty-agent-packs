# Continuity, Context Budgets, and Handoffs

## The filesystem is the durable notebook

Chat context is transient. Keep a concise `state.md` with objective, mode, verified scope source/time, current hypothesis, evidence state, approvals, consumed request budget, pending decisions, artifacts, and next action. Link long detail rather than pasting the whole notebook into every prompt.

Each engagement has one source of truth for scope and one hypothesis ledger. Use stable IDs such as `H-001`, `EXP-001`, `E-001`, `F-001`, and `L-001`. IDs are local identifiers, not CVEs or platform report numbers. Record UTC evidence timestamps and explicit timezone offsets for any user-facing schedule.

## Evidence organization

```text
engagements/<slug>/
  program.md
  scope.json
  state.md
  hypotheses.md
  activity-log.md
  source-cards.md
  tool-manifest.md
  experiments/
  evidence/raw/
  evidence/redacted/
  findings/
  lessons/
  detections/
  controls/
  handoffs/
```

Preserve raw evidence locally, redact derived copies, and maintain an evidence index with creation time, source, identity label, description, sensitivity, file path, and hash when useful. A hash proves consistency relative to recorded bytes; it does not prove the truth of the content or establish a trusted timestamp.

The included `workspace.py hash` tool reads files and emits SHA-256 values. It does not validate vulnerability claims or sanitize secrets. Avoid placing its output inside the directory being hashed if you intend to compare stable directory contents later.

## Resume procedure

Read the state, program, scope, approvals, latest hypothesis/experiment, and relevant evidence. Recheck the current program brief before new live activity. Verify that the previous session actually executed commands it claims; a planned command is not a completed result.

Confirm tool versions and session/account validity before reusing a test. Expired tokens, changed permissions, updated builds, and modified scope can invalidate earlier assumptions. Resume the next discriminating experiment rather than repeating a broad reconnaissance pass.

## Switching agents

Use [handoff.md](../templates/handoff.md). Include exact paths, evidence IDs, known unknowns, approvals with limits, budget spent, forbidden/denied actions, and the next task. Shared Markdown instructions do not synchronize application permissions, credential stores, browser sessions, or tool availability between clients.

If the owner authorizes parallel agents, delegate independent bounded work such as source research versus report review. Give each a separate artifact and shared IDs; never have several agents unknowingly consume the same live request budget. A subagent may analyze a hypothesis but cannot expand its scope or invent authorization. If parallel work is not authorized or supported, use the roles sequentially in one agent.

## Finish a session

Record findings and non-findings, observed effective controls, remaining risks/unknowns, lessons, and any owner decision needed. End with a concrete next action. A session can end productively without finding a vulnerability; it should not end with ambiguous execution status or inflated claims.
