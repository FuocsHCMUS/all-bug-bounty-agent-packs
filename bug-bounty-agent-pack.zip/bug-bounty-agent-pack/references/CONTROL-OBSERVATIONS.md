# Assessing Controls Without Inventing Company-Wide Conclusions

The owner wants to learn what a company does well, what could improve, and what creates risk. Evaluate the controls actually observed. A narrow external experiment cannot establish the maturity of the entire organization, its SOC, its engineering culture, or its internal logging.

## Observation format

For every statement record: control objective; tested surface; exact condition; evidence; observed behavior; interpretation; confidence; coverage limit; residual uncertainty; improvement; and useful follow-up. Use [control-observation.md](../templates/control-observation.md).

Separate **design**, **implementation**, **operation**, and **visibility**. A policy may describe a well-designed control without proving it is implemented. A successful block shows operation for that event without proving comprehensive coverage. A missing external signal does not prove the company lacks telemetry.

## Useful dimensions

| Dimension | Evidence-backed question |
|---|---|
| Authentication lifecycle | Are tested sessions invalidated according to documented semantics? |
| Authorization | Do selected principal/resource/action combinations enforce the expected boundary? |
| Tenant separation | Do synthetic cross-tenant checks preserve isolation in the tested paths? |
| Input handling | Is untrusted input treated consistently at the observed boundary? |
| Browser defenses | What do observed cookie/origin/content controls actually protect? |
| Secrets and data | What information is present in responses and exported artifacts? |
| Async processing | Does authority remain correctly bound to requester and current state? |
| Patch posture | Is reliable build/backport evidence available for the studied component? |
| Abuse controls | What happens within the allowed request budget? Do not stress-test limits. |
| Error handling | Are errors useful without exposing unnecessary internals? |
| Detection visibility | Which required logs are known, supplied, inferred, or unavailable? |
| Response process | What can be observed about the actual documented report interaction? |

## Outcome labels

Use `OBSERVED-EFFECTIVE`, `OBSERVED-GAP`, `PARTIALLY-TESTED`, `NOT-ASSESSED`, or `UNKNOWN`. Keep risk and confidence separate. An observed severe consequence with limited reproducibility can have high potential risk and moderate confidence. A control can be effective on one path and unassessed on another.

Describe risk through asset, threat scenario, prerequisites, likelihood evidence, impact evidence, existing controls, uncertainty, and suggested action. Avoid assigning precise probability percentages without a defensible model. If using high/medium/low categories, define their meaning within the engagement and explain the evidence.

## Examples of careful wording

“The direct note-read endpoint denied Bob's request for Alice's private synthetic note under the tested role and session. This supports an effective authorization check on that path. Export and attachment paths were not assessed.”

“The supplied application trace includes principal and object IDs but not the permission decision reason. That limits analysis of this event. We do not know whether another telemetry source captures it.”

“The version header is visible, but build and backport status are unknown. Patch posture cannot be rated from this signal.”

## Improvements and follow-up

Tie each improvement to an observed gap or a clearly labeled architectural question. Prioritize the failed invariant, potential reach, and ease of verifying a repair. Explain which team capability the lesson concerns: secure design, implementation review, regression testing, telemetry, detection engineering, incident triage, or vulnerability management.

Teach the student how prevention, detection, response, and recovery complement each other. Avoid treating any single layer as a complete answer. End with a coverage map so unknowns remain visible instead of silently becoming a company security score.
