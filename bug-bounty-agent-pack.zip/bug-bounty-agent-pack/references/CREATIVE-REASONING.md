# Creative Offensive Reasoning With Falsifiable Experiments

Creativity means proposing useful explanations and new tests, not increasing payload volume. Start with what the system must preserve and identify where representations, authority, or time can disagree.

## Invariant-first thinking

Write an invariant as a sentence that could be false: “A revoked collaborator cannot obtain a newly generated export.” Identify actors, actions, objects, state, and time. Then ask where the implementation may enforce a weaker property: at the UI only, at the request only, on one endpoint, on one object type, or before an asynchronous delay.

## Lenses for hypothesis generation

| Lens | Questions to ask | Useful local/controlled comparison |
|---|---|---|
| Identity | Which principal does each layer believe is acting? | Same owned object, two owned identities |
| Ownership | Is a child object's parent/tenant checked? | Valid object with changed parent context |
| Representation | Do two parsers normalize input differently? | Equivalent benign forms in a local replica |
| Time | Is a decision stale when the operation executes? | Before/after a controlled revocation |
| State | Can an operation occur in an invalid lifecycle state? | Draft/published/archived transitions |
| Surface | Is one entrypoint missing a shared control? | UI/API/export paths for the same owned object |
| Delegation | Does a powerful worker retain too much authority? | Requester context versus worker context |
| Cache | Is identity or state absent from a cache key? | Isolated owned accounts and synthetic responses |
| Composition | Do two correct-looking features combine incorrectly? | Explicitly model each edge before testing a chain |
| Negative space | What assumption has never been tested? | A negative control designed to fail |

Do not change all dimensions at once. A result is interpretable when the changed factor is explicit.

## Differential and metamorphic reasoning

Differential tests compare two paths expected to enforce the same property. For example, reading an owned note through the UI and exporting it should not have incompatible permission rules. Differences can be legitimate, so check the product contract before calling them a bug.

Metamorphic tests use relationships between inputs or states when the exact output is unknown. Revoking a share should not increase access. Reducing a role should not create a new privileged action. Serializing an innocuous object through two documented formats should preserve the intended ownership relation. These relationships produce test oracles without requiring exploit payloads.

## Chains and sophisticated mechanisms

Represent a proposed chain as a graph of prerequisites and effects. Label each edge observed, source-supported, or hypothetical. Prove that one edge's effect actually satisfies the next edge's prerequisite; similar words in two write-ups are insufficient.

Prefer a small local demonstration of the chain's invariant to speculative escalation on a live target. A partial chain can be reported as a bounded finding if its demonstrated impact is meaningful. Keep hypothetical higher impact in a clearly separated section. Do not claim account takeover, code execution, or cross-tenant reach unless evidence supports that exact outcome.

## Rank by information gain

Ask which next observation most reduces uncertainty. A manual check showing a feature is absent can eliminate ten speculative CVE ideas. A test verifying that two accounts truly belong to different tenants can rescue an otherwise invalid authorization experiment.

Use a qualitative score or documented weighted ranking for likely impact, prerequisite confidence, novelty evidence, information gain, effort, and allowed testability. Do not present arbitrary numerical scores as statistically calibrated probabilities.

## Adversarial self-review

Before believing a result, name at least two plausible benign explanations and one observation that would distinguish each. Ask what would make the claim false. Check sessions, account roles, cache state, error wrappers, stale data, asynchronous timing, and intended sharing behavior.

Record abandoned ideas and why they failed. A durable research notebook accumulates discriminating knowledge rather than repeating fashionable attack categories. Originality comes from a well-supported new combination or root-cause insight, not from asserting that a technique is “advanced.”
