# Foundations: From a Network Request to a Security Property

Teach in layers. Do not skip directly to exploit names. Use a fictional notes service, `notes.example.test`, and two synthetic identities, Alice and Bob. `.test` is used here for examples, not as a real company target.

## 1. Computers, processes, addresses, and ports

A process is a running program. An IP address helps route packets to a network interface. A transport port identifies an endpoint used by a service on that host; it is not a permanent guarantee of which software is listening. A socket represents a communication endpoint. Explain the distinction between the computer, the network address, and the application running there.

A request can pass through a router, a firewall, a load balancer, a reverse proxy, and an application before reaching a database or worker. Some layers are not visible from outside. A single public IP can serve several companies through shared hosting or a content delivery network (CDN). Shared infrastructure does not imply shared testing scope.

**Prediction exercise:** If two domain names resolve to the same IP, must their sessions or databases be shared? No. Name-based routing and separate applications can keep them independent; actual architecture needs evidence.

## 2. DNS, TCP, and TLS

The Domain Name System (DNS) maps names to records. An A record supplies an IPv4 address; AAAA supplies IPv6; CNAME identifies another name. A CNAME is a routing relationship, not proof that a company owns the destination service. Cached DNS answers can temporarily differ across resolvers.

Transmission Control Protocol (TCP) supplies an ordered byte stream between endpoints. Transport Layer Security (TLS) protects communication in transit and authenticates an endpoint under its certificate trust model. HTTPS is HTTP carried over TLS. TLS can terminate at a proxy, after which another connection carries the request internally. Encryption does not decide whether Alice may read Bob's note.

**Security distinction:** transport protection, endpoint identity, user identity, and data authorization solve different problems. A valid certificate does not establish correct application authorization.

## 3. HTTP messages

Hypertext Transfer Protocol (HTTP) is a request/response protocol. A conceptual message contains a method, a target, headers, and sometimes a body. Explain `GET` as normally retrieving a representation, `POST` as application-defined processing, and `PUT`/`PATCH`/`DELETE` in context rather than treating names as universal permission rules. Applications can violate method conventions.

```http
GET /api/notes/note-a HTTP/1.1
Host: notes.example.test
Accept: application/json
Cookie: session=<REDACTED_TEST_SESSION>
```

The path selects an application resource. A cookie can carry a session identifier. The server must decide which authenticated principal is associated with that session and whether that principal may access `note-a`. The client choosing an object ID does not make that object authorized.

Status codes summarize an outcome, not the full security decision. A `200` can contain an error object; a `403` can come from a proxy or application policy; a `404` may intentionally conceal an object. Compare body, object state, identity, and relevant logs. HTTP/2 and HTTP/3 frame messages differently; raw HTTP/1.1 syntax is a teaching representation, not necessarily the wire format.

## 4. Identity, authentication, authorization

**Identity:** who or what is making a request. **Authentication:** how the system verifies that claim. **Authorization:** what that verified identity may do to a specific resource in a particular context.

For a notes service, the invariant might be: “A principal can read a private note only if it owns the note or has an active share granting read permission.” Translate that into a decision involving principal, resource, action, tenant, and current state.

Authentication success does not imply universal access. Guess-resistant IDs reduce guessing but do not replace authorization. Browser-side hidden buttons are presentation controls. The server must enforce the relevant permission. Authentication and authorization can also apply to services, workers, and API keys, not only humans.

| Actor | Object | Action | Expected decision |
|---|---|---|---|
| Alice | Alice's private note | Read | Allow |
| Bob | Alice's private note | Read | Deny |
| Bob with current share | Alice's shared note | Read | Allow |
| Bob after share revocation | Same note | Read | Deny |

Use two owned test accounts to distinguish identity from object ownership. Never describe unknown third-party records as necessary learning material.

## 5. Sessions, cookies, and tokens

A session associates multiple requests with an authenticated context. A session cookie can reference server-side state. A bearer token grants capabilities to whoever presents it under the server's validation rules. A JSON Web Token (JWT) is a token format, not an automatic security guarantee; signature verification, accepted issuer, audience, expiry, and application authorization still matter.

Explain cookie attributes separately: `Secure` limits transport conditions, `HttpOnly` restricts JavaScript access to the cookie, and `SameSite` influences cross-site inclusion. None substitutes for an object authorization decision. A token appearing in a URL or log can create exposure, but demonstrate context and access before claiming impact.

## 6. Browser origin and server trust

An origin is based on scheme, host, and port. The same-origin policy constrains browser interactions. Cross-Origin Resource Sharing (CORS) controls when browser scripts can read certain cross-origin responses. It is not a server authentication system. Cross-Site Request Forgery (CSRF) concerns unintended authenticated actions; response readability is a different question.

For a browser issue, model the initiating origin, user interaction, authentication mechanism, request inclusion rules, and whether an attacker can read or change something meaningful. A permissive-looking header without a reachable sensitive effect is only a signal.

## 7. Trust boundaries and data flow

A trust boundary separates components with different authority or assumptions. Client to server, application to database, proxy to backend, worker to queue, and one tenant to another are useful boundaries. Mark where input enters, where identity is established, where validation occurs, and where a consequential operation executes.

```text
Browser -> edge/proxy -> application -> authorization decision -> object store
                              |
                              +-> queue -> worker -> generated export
```

Input may be parsed, normalized, stored, transformed, and used later. Validation at one stage does not prove all later consumers interpret it identically. Security research often discovers disagreement between representations or between a decision time and a later use time.

## 8. Vulnerability, exploit, impact, and confidence

A vulnerability is a weakness that violates a security property under particular conditions. An exploit is a method of triggering that violation. Impact describes the resulting loss of confidentiality, integrity, availability, or other meaningful business property. Confidence describes how strongly evidence supports the claim.

These are independent dimensions. A locally reproduced high-impact mechanism may be inapplicable to a remote deployment. A target-confirmed narrow access leak may have high confidence but limited impact. A weakness category (CWE), a vulnerability identifier (CVE), and a severity framework (CVSS) are different tools.

## 9. What a finding teaches defenders

A server-side permission failure suggests a prevention question: where should the decision be made and what context must it include? It also suggests a detection question: which requests, principals, resources, decisions, and resulting state changes must be logged? A useful SOC lesson connects an observable event to a plausible behavior without claiming that every unusual event is malicious.

End with three checks: explain authentication versus authorization in your own words; explain why a 403 is evidence about one request; draw the path a queued export takes after the initiating browser request ends.
