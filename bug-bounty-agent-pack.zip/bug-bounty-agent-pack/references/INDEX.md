# Reference Library

Read a reference when its question becomes relevant. This library is intentionally deeper than the always-loaded instructions.

| Reference | Question it answers |
|---|---|
| [Foundations](FOUNDATIONS.md) | What do networks, requests, identities, and trust boundaries actually mean? |
| [Program discovery](PROGRAM-DISCOVERY.md) | Which current public program fits the learner and available resources? |
| [Workflow](WORKFLOW.md) | How does a session move from brief to evidence and report? |
| [Research](RESEARCH.md) | How do we learn from advisories, write-ups, patches, and CTFs? |
| [CVE research](CVE-RESEARCH.md) | Is this exact vulnerability applicable to this deployment? |
| [Creative reasoning](CREATIVE-REASONING.md) | How do we generate original, testable hypotheses? |
| [Web/API methods](WEB-API.md) | Which invariants matter across common application workflows? |
| [Advanced mechanisms](ADVANCED-MECHANISMS.md) | How should complex parser, async, cloud, and processing boundaries be studied? |
| [Validation](VALIDATION.md) | What evidence distinguishes a real issue from an artifact? |
| [Reporting](REPORTING.md) | What makes a report reproducible and actionable? |
| [Control observations](CONTROL-OBSERVATIONS.md) | What can responsibly be said about strengths and risks? |
| [SOC bridge](SOC-BRIDGE.md) | What would defenders need to observe and detect the mechanism? |
| [Teaching](TEACHING.md) | How do we teach this from first principles? |
| [Windows tools](WINDOWS-TOOLS.md) | How do downloads, scripts, pip, and Python 3.14 work here? |
| [Continuity](CONTINUITY.md) | How do agents resume without losing evidence or approvals? |

For task prompts use [the catalog](../prompts/CATALOG.md). For record layouts use [templates](../templates/INDEX.md).
