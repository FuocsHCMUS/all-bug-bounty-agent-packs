# Public Program Discovery

## Objective

Find a program whose current rules, accessible features, and available test identities support meaningful learning and a feasible research session. Discovery can run independently of active testing. Do not promise income or claim that an apparently quiet program is easy.

## Research sequence

Start at official public platform listings and individual program pages. Search HackerOne and Bugcrowd public material, but distinguish the hosting platform from each program's assets. Record the actual program URL, operator, platform, program type, brief retrieval time, and access status. If a page needs authentication, record the limitation rather than inventing its contents or reusing another program's policy.

Read the entire available brief, including asset-specific notes and linked rules. Extract explicit eligible assets, exclusions, allowed methods, automation rules, headers/identifiers, account requirements, test data restrictions, reporting channel, and disclosure conditions. A vulnerability disclosure program may not pay a bounty. A program being public does not establish that every researcher, account tier, or method is eligible.

Compare three to five candidates when reliable sources are available. If fewer are accessible, report that fact. Do not pad the shortlist with guessed scope.

| Criterion | Useful question |
|---|---|
| Learning fit | Can a beginner model the feature and obtain controlled test identities? |
| Scope clarity | Are assets and methods explicit enough to plan an experiment? |
| Feature depth | Are there roles, tenants, sharing, APIs, imports, exports, or state changes? |
| Evidence feasibility | Can a result be shown with owned accounts and synthetic data? |
| Access cost | Does testing require payment, enterprise access, invitation, or special devices? |
| Operational fit | Are the requested tools and request budget feasible on this Windows workspace? |
| Research continuity | Can a session be resumed without repeatedly rediscovering context? |

Treat public statistics as context, not a probability of payout. A large reward ceiling does not establish that the learner can access a relevant path.

## Scope interpretation

Preserve exact patterns and their explanations. Apex domains, wildcard subdomains, URL path restrictions, mobile package identifiers, repositories, API hosts, and IP ranges are different asset types. A wildcard's practical meaning comes from the brief. Parent-brand ownership, acquisitions, a shared certificate, redirects, CDN address ranges, and linked third-party SaaS do not independently extend scope.

Record exclusions alongside inclusions so a summary cannot erase them. When a flow redirects or calls another host, assess that destination separately before following a test. Do not assume a browser's routine resource loading authorizes automated testing of every loaded dependency.

## Deliverable

Use the [program brief template](../templates/program.md). Add a comparison table containing verified facts, source links, retrieval date, unknowns, recommended first feature, required accounts, and the reason for the recommendation. Then prepare a scope record and a bounded plan for the preferred program.

If owner selection is needed, ask one focused question and continue foundational teaching or public documentation work. Do not create accounts, accept private invitations, send messages, or start active target tools merely to fill an incomplete shortlist.

## Refresh rule

Before a new active session, recheck the current brief and compare it with the saved snapshot. Save material changes and affected hypotheses. If access prevents verification, continue offline work and mark active testing pending. A prior snapshot supports historical context, not indefinite permission.
