# Reports the Owner Can Review and Submit

## Lead with the concrete result

Use a specific title naming the violated property and affected workflow. The first paragraph should identify the actor's starting access, the action, and the observed result. Avoid dramatic severity adjectives before the evidence supports them.

Use [finding.md](../templates/finding.md). Include program/asset context, validation state, retrieval/test times, assumptions, prerequisites, exact reproduction, expected versus actual behavior, impact, evidence index, remediation, retest criteria, and limitations. Keep the report concise enough for a triager while linking the deeper research notebook separately.

## Reproduction quality

Use numbered steps with two owned test identities where needed. State how the synthetic object was created and what makes it private. Label accounts by role; do not include passwords, reusable tokens, or other secrets. Keep request/response excerpts minimal and show how a triager can supply their own session.

Screenshots support a claim but should not replace the causal sequence. Preserve request IDs and timestamps where available. If the result was source-confirmed or lab-only, say so rather than writing target reproduction steps that were never performed.

## Impact language

Separate demonstrated impact from plausible but untested extensions. Explain why the violated property matters to the feature. If scope is uncertain, state the uncertainty before presenting broad claims. Do not assert account takeover, server compromise, complete tenant compromise, or universal customer exposure based on a narrow signal.

For a business logic flaw, describe the protected business rule and what an actor can do outside it. State any interaction, role, configuration, or timing requirements. A complex chain may have lower practical reach than a simple permission failure; complexity is not a severity multiplier.

## Remediation

Propose the invariant to restore and where to enforce it. Examples include server-side authorization with principal/resource/action/tenant context, permission re-evaluation in a worker, consistent canonicalization before decisions, or capability lifetimes tied to current permissions.

Separate immediate containment from the durable fix. Discuss tradeoffs and unknown architecture. Avoid claiming a specific internal implementation if the only evidence is external behavior. Recommend regression checks that cover the affected path and equivalent sibling paths without demanding an unrelated rewrite.

## Retest

Describe the same original sequence, an expected corrected result, a positive control proving intended functionality still works, and relevant adjacent states. Retest only with appropriate current scope and approval. A blocked request after remediation can reflect a proxy rule rather than a code fix, so specify what the retest can and cannot establish.

## Submission and communication

Prepare the final material locally for the owner. Use the platform's requested fields and redact attachments. Do not press Submit, send company messages, publish a write-up, or upload private evidence without explicit owner authorization. If clarification from the program is needed, draft the exact message and explain what answer would change the test plan.

Keep company responses factual. Record accepted, duplicate, informative, not applicable, and unresolved decisions separately from the research conclusion. A triage label is useful feedback but does not by itself replace technical analysis. Never fabricate a bounty amount, acceptance, fix date, or response.

## Learning companion

The report is for triage; the lesson is for the student. Keep detailed definitions, diagrams, failed hypotheses, and SOC discussion in the companion lesson so the report remains usable. Link them privately when appropriate and respect the program's disclosure requirements.
