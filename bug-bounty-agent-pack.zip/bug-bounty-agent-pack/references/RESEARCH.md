# Research From Advisories, Patches, Write-ups, and CTFs

## Source quality

Start with the original vendor advisory or researcher publication. Use CNA/CVE records, upstream code, patch diffs, release notes, protocol specifications, and official deployment documentation to establish prerequisites. Secondary summaries help discover leads but can omit important configuration, build, or authentication conditions.

For every source, record title, author/publisher, URL, publication/update date, retrieval date, access status, claim, relevant version/context, limitations, and a short paraphrase. Preserve conflicting sources instead of averaging them into a confident statement. A search snippet is not a substitute for reading the page.

## Turn a write-up into a mechanism

Extract the following in order:

1. Legitimate behavior and intended security property.
2. Attacker-controlled input or action.
3. Entry point and transformations.
4. Trust boundary crossed and missing or inconsistent decision.
5. Preconditions: identity, feature flag, configuration, version, timing, and user interaction.
6. Observation that demonstrates the violation.
7. Impact actually shown, separate from imagined chains.
8. Repair and why it restores the property.
9. A generalized experiment usable in a local or explicitly scoped environment.

For example, a share-revocation write-up may teach that a queued task must re-evaluate permission at the point of execution. The transferable idea is a stale authorization decision, not the original company's endpoint names.

## Read a patch critically

Identify the changed function, caller, input source, checks added or moved, and the consequential operation. Ask what invariant the patch restores, whether sibling call sites rely on the same helper, and which tests capture the intended behavior. Compare the vulnerable and corrected local versions when available.

Do not infer that every nearby function is vulnerable. A patch can be refactoring, defense in depth, or a partial mitigation. Distinguish source-confirmed reachability from a code pattern that only resembles the published bug.

## Learn from CTF material

A capture-the-flag challenge is deliberately constructed to be solvable. It may expose unusual configuration, intentionally weak credentials, artificial deployment assumptions, or a flag file that production systems do not have. Record those assumptions explicitly.

Translate the challenge into concepts: parser disagreement, object ownership, state machine, cryptographic misuse, serialization, or capability boundaries. Rebuild a small local demonstration if helpful. Then explain which assumptions would need evidence in a real system. Do not promote a challenge solution into a ready-made production exploit claim.

## Research queries

Build queries from observed product names, component names, feature behavior, vendor advisory IDs, relevant release series, and the suspected invariant. Narrow by official vendor/upstream domains. Avoid guessing technology from visual branding alone.

When reading an exploit repository, inspect source and dependencies before considering execution. Record provenance, commit, build steps, outbound destinations, destructive behavior, and whether the described versions match. Popularity, stars, and a CVE number do not establish trustworthy execution behavior.

## Synthesis

End each research batch with three columns: supported facts, unresolved claims, and discriminating checks. Link each hypothesis back to its source cards. Use short excerpts only where exact wording matters; paraphrase the rest. Store durable concepts in the knowledge base, but keep transient program facts in the engagement so they can expire and be refreshed.
