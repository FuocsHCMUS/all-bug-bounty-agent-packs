# From Offensive Observation to SOC Learning

A Security Operations Center (SOC) investigates events and coordinates detection/response. A penetration test observes a possible failure under controlled conditions. Connecting them requires specifying what defenders could observe, not inventing logs the researcher cannot access.

## Work backward from the invariant

For a cross-object authorization issue, the key facts may be principal, tenant, object owner, requested action, policy decision, and actual data returned. For a queued export, add job identity, initiating principal, permission version/time, execution time, artifact identity, and download principal.

Label telemetry as `AVAILABLE`, `OWNER-SUPPLIED`, `PROPOSED`, or `UNKNOWN`. Use [detection-note.md](../templates/detection-note.md). Never claim “the SOC would detect this” unless detection evidence exists.

## Telemetry layers

| Layer | Useful fields | Limitation |
|---|---|---|
| Edge/proxy | Time, request ID, host/path, method, status, routing | May not know object ownership or final business outcome |
| Application | Authenticated principal, tenant, action, object, authorization result | Can omit a later worker's decision |
| Identity provider | Session lifecycle, authentication method, token events | Successful login does not establish valid resource access |
| Queue/worker | Job ID, requester, state/version, execution result | Needs correlation to the original request |
| Storage/export | Artifact, owner, access decision, retrieval event | Signed links may obscure the original user unless designed carefully |
| Endpoint/network | Process or connection metadata when supplied | External testing often lacks this visibility |

Use structured fields rather than relying only on free-text messages. Synchronize clocks or record offsets. Correlation IDs help join events, but verify that they propagate across services and jobs. Avoid logging raw secrets or unnecessary content.

## Detection hypotheses

A detection hypothesis is a testable statement: “An export executed after the requester's access was revoked should be reviewed if current policy requires access at execution.” Define required fields, expected normal behavior, suspicious condition, suppression logic, false positives, and a validation dataset.

```text
Conceptual logic, not a production SIEM rule:
Join export_execution to its initiating job and permission history.
If the requester lacked the required permission at execution time,
and the operation succeeded, create a review event.
```

This requires reliable permission history and a clearly defined product policy. Without those fields, it is a telemetry proposal, not a working detector. A 403-count rule would observe denied attempts rather than the successful authorization failure itself.

## Triage narrative

Teach the analyst to reconstruct who acted, on which resource, when, under which role/session, what the system decided, what actually happened, and what else is unknown. Differentiate attempted activity from successful effect and suspected exposure from confirmed data access.

For an owner-approved simulated incident, preserve a small synthetic timeline and evaluate whether the proposed telemetry could answer those questions. Do not perform real containment, account suspension, credential rotation, or deletion as part of a learning note.

## Prevention, detection, and response

The durable fix restores the application invariant. Detection looks for violations or suspicious patterns when prevention fails or when telemetry reveals attempted abuse. Response establishes affected scope and containment using authorized procedures. Recovery restores intended operation and verifies the repair.

Map to MITRE ATT&CK only where the observed behavior fits and the mapping helps defenders. Not every web vulnerability maps cleanly to a technique. Avoid adding taxonomy IDs as decoration.

## Student exercise

Provide six synthetic events containing one valid export, one denied request, and one stale-permission worker execution. Ask the learner to identify what is suspicious and what extra field is needed. Then explain false positives: delayed event ingestion, role inheritance, permission snapshot semantics, and administrative exception. This teaches both detection logic and evidence limits.
