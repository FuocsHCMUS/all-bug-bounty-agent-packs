# Teaching From the Root Concept to the Finding

## Start with prerequisites

Check the learner's understanding using one small question. Explain the missing prerequisite before the advanced concept. Do not ask a beginner to understand OAuth, object authorization, asynchronous processing, and SIEM correlation in one unexplained paragraph.

Use the sequence: concrete everyday example, technical mental model, legitimate data flow, security invariant, experiment, observed result, root cause, repair, detection, exercise. An analogy is a starting point; state where it stops matching the real system.

## Required lesson components

1. **Vocabulary:** define terms and abbreviations before use; distinguish similar terms.
2. **Normal operation:** show the actor, request, decisions, and state changes.
3. **Protected property:** name what should always be true and why it matters.
4. **Mechanism:** identify the exact disagreement or missing decision.
5. **Evidence:** show the observation and its limits.
6. **Root cause:** explain the causal link; separate source-confirmed implementation from inference.
7. **Repair:** connect the change to the restored invariant.
8. **SOC view:** identify needed telemetry and plausible detection logic.
9. **Exercise:** a local/synthetic task with predicted and expected outcomes.
10. **Retrieval practice:** questions the learner answers without rereading.

Use [lesson.md](../templates/lesson.md). Link a finding and a control observation so the student sees the relationship between failure, effective defenses, and unknown coverage.

## Example: why a 403 is not a security verdict

First explain a request and response. Then explain that a status code describes the outcome of a particular request. Ask whether Alice and Bob have the same permissions. Show a table with Alice's own note allowed and Bob's request denied. This supports the tested decision, but does not assess exports, attachments, other roles, or other states.

Next explain logs: the edge may see the 403, while the application knows the principal and object. The SOC needs context to distinguish normal denial from repeated suspicious behavior. Do not infer internal logging from the external response.

Finally ask the learner to design one additional comparison. The answer should specify actor, object, state, expected outcome, and how to avoid session confusion. A list of attack names is not an adequate experiment.

## Scaffold difficulty

**Beginner:** DNS, request anatomy, sessions, authentication versus authorization, simple role/object matrices.

**Developing:** API contracts, browser origin, state machines, workers, storage, source-to-sink flow, negative controls.

**Intermediate:** patch analysis, dependency/build identity, parser consistency, differential tests, telemetry correlation, CVSS rationale.

**Advanced:** variant analysis, mechanism composition, concurrency models, capability lifetimes, architectural remediation. Advanced material still needs explicit assumptions and evidence.

Let the learner progress based on demonstrated understanding, not elapsed days or an impressive vocabulary list.

## Keep the notebook honest

Mark misconceptions corrected, unresolved questions, concept dependencies, and one next exercise. Use a short glossary that grows from actual sessions. Revisit a concept in a new context, such as direct access versus worker execution, to test transfer of understanding.

Avoid overwhelming the learner with every possible exploit. A detailed explanation of one verified mechanism can teach more than a shallow catalog. Preserve the dense reference material for later study, while each lesson has a clear learning goal and a manageable sequence.
