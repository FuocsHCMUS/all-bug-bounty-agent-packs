# Validation and False-Positive Reduction

## Claim decomposition

Write the claim as actor + action + resource + context + violated invariant + observed consequence. “Authorization bypass” is too vague. “An owned low-privilege test account can retrieve another owned account's private synthetic note after share revocation” is assessable if the stated conditions are verified.

Decompose a chain into individual edges. A demonstrated edge does not prove later speculative effects. Keep evidence states attached to each claim rather than assigning one blanket confidence to the whole story.

## Establish controls

Record legitimate baseline behavior and the expected denial or state restriction. Verify account roles, tenant membership, ownership, sharing, token freshness, object state, and timing. Use a negative control that should fail under the hypothesis and a positive control that confirms the feature works at all.

The experiment should change one relevant factor at a time where feasible. If several changes are unavoidable, acknowledge the ambiguity and design a follow-up that separates them.

## Examine confounders

| Confounder | How it can mislead |
|---|---|
| Session mix-up | The “attacker” request used the owner/admin cookie |
| Intended sharing | The object is public, shared, or covered by inherited permission |
| Cache | A prior authorized response appears under a later context |
| Error wrapper | Status and body describe different outcomes |
| Async timing | State has not propagated or the operation legitimately captured a snapshot |
| Test fixture | Both accounts accidentally share a tenant or elevated role |
| Middleware block | An intermediary masks an untested application path |
| Version/backport | A vulnerable-looking banner corresponds to patched code |
| Tool behavior | Automatic redirects, retries, or authentication change the request |

Do not dismiss every ambiguity as a false positive. Name the observation that would resolve it and remain inconclusive when necessary.

## Reproducibility

Capture the shortest meaningful sequence, identity labels, synthetic object creation, timestamps, relevant request/response excerpts, and state changes. Record tool versions and nondefault settings. Preserve exact evidence privately, and use redacted copies for reports.

Repeat only enough to establish reliability or examine a known confounder. If a phenomenon depends on timing, record conditions and rate of occurrence without increasing concurrency beyond the approved plan. For a local race, a deterministic synchronization point is often more informative than hundreds of trials.

## Impact and severity

State what was actually accessed, changed, or prevented. Separate confidentiality, integrity, availability, and business consequences. Distinguish the privileges required from those gained. Do not extrapolate one controlled object to all customers without evidence.

Use the program's severity convention. If CVSS is requested, state version, vector, metric rationale, and uncertainty; do not invent a numeric score from intuition. A program's bounty category and a CVSS base score answer different questions. Novelty and duplicate status may be unknown until the company responds.

## Decisions

- `TARGET-VALIDATED`: the relevant target environment demonstrates the mechanism and violation within the recorded scope.
- `LAB-REPRODUCED`: a controlled environment demonstrates the mechanism; remote applicability remains a separate issue.
- `DISPROVEN`: the tested hypothesis is contradicted under the documented conditions. Do not generalize to all configurations.
- `INCONCLUSIVE`: available evidence does not distinguish the claim from alternatives.

An exact reproduction can be blocked by access limits or unavailable telemetry. Report that honestly and retain useful analysis.

## Pre-report review

Check that every consequential statement has an evidence reference, identities are correct, secrets are redacted, steps are sufficient, expected versus actual behavior is explicit, and impact language stays within what is shown. A second reviewer should be able to explain what would falsify the claim. If no reviewer tool is available, do a fresh structured self-review and label that limitation.
