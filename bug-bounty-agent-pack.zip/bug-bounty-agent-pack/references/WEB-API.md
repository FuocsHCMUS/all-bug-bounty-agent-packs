# Web and API Investigation Methods

Use this as a hypothesis guide, not a checklist that automatically launches requests. Model the legitimate feature, map the required permissions, and select a small approved experiment.

## Authentication and session lifecycle

Map registration, login, verification, recovery, multifactor changes, logout, session expiry, and token revocation. Determine what identity proof each transition requires. Distinguish server-side invalidation from browser cookie deletion. Use only owned test accounts; an account-recovery idea does not justify targeting another person's account.

For a suspected lifecycle defect, document state before and after, the session or token used, expected revocation semantics, and actual effect. A token surviving an event may be intended; read the product contract and demonstrate a meaningful violation before reporting.

## Authorization and tenant isolation

Create a principal/resource/action matrix. Separate object-level permission, function-level permission, property-level permission, and tenant boundaries. Test identities must have verified roles and ownership. A public object, retained share, administrator role, or same-tenant assumption can invalidate a result.

Compare equivalent entrypoints for the same synthetic object: detail view, list, export, attachment, version history, and API endpoint where documented and in scope. Ask where the permission context enters each operation. Prefer two meaningful comparisons over broad identifier enumeration.

## Input handling and data processing

Track input from entrypoint through parsing, normalization, validation, storage, and use. Identify whether the input is interpreted as data, a query, a path, a template, or a command. Use source analysis and benign local markers to establish data flow before considering an exploit mechanism.

Injection labels alone are inadequate. The report needs the affected interpreter/context, attacker control, missing boundary, actual effect, and repair. High-risk command execution, memory-corruption, or deserialization research belongs first in an isolated lab or supplied-code analysis; do not run an unreviewed exploit against production.

## Browser security

For cross-site scripting (XSS), reason about source, transformation, rendering context, and actual execution context. Reflection alone is not execution. For CSRF, model ambient credentials, request initiation, anti-CSRF controls, and state-changing effect. For CORS, establish an actual browser-readable sensitive response under the relevant credentials and origin rules.

Explain the browser's part in the mechanism. A command-line client ignoring browser restrictions cannot prove a browser exploit. Content Security Policy (CSP), cookie attributes, and origin isolation are distinct controls; an observed header needs context.

## Business logic and state machines

List lifecycle states and allowed transitions. Consider invitation acceptance/revocation, approval delegation, trial-to-paid transitions, resource ownership changes, archived data, cancellation, and delayed exports. Identify the actual business invariant before suggesting variations.

Financial or resource-consuming flows require particular care: model them with sandbox features, synthetic balances, or local logic where available. Do not incur charges, trigger real payouts, or stress availability to demonstrate an idea.

## APIs and GraphQL

Use documented schemas or owner-supplied contracts where possible. Identify authentication at the gateway versus authorization in resolvers/services. Consider nested object relationships, field-level filtering, pagination, and alternate representations. Avoid large introspection or enumeration jobs without a bounded plan. An exposed schema is not itself a serious vulnerability without relevant policy and impact.

## Uploads, imports, and exports

Separate file acceptance, storage, metadata, content processing, preview generation, download authorization, and retention. A safe upload endpoint may feed a more powerful worker. Ask whether the original principal, tenant, and current permissions are preserved at each stage. Use synthetic harmless files and local processing replicas to investigate dangerous formats.

## Common false-positive traps

- A sensitive-looking field can be intentionally public or synthetic.
- A cached response can belong to a prior test identity rather than cross-account access.
- A 200 status can carry a denial, while a 403 body can still contain information.
- Random IDs reduce guessing but do not prove access checks.
- A client-side restriction may only be usability behavior.
- An error trace can be an information observation without demonstrated exploitability.

Finish each selected test with an evidence state, a narrowly worded conclusion, and the next discriminating question. Use [validation](VALIDATION.md) before drafting severity or impact claims.
