# Windows 11 and Python 3.14 Tooling

## Acquisition, installation, and execution are separate

The owner permits lightweight portable downloads/clones into this workspace and pip dependencies for authored Python scripts. The owner wants to confirm script/tool execution unless already covered by a concrete approved plan. System installation and adding MCP servers/plugins/skills require a separate request. Preserve these distinctions instead of asking about every read or silently running a downloaded setup script.

Before acquisition, record the publisher/repository URL, release or commit, purpose, expected size, destination, license/provenance notes, and compatibility assumptions in [tool-manifest.md](../templates/tool-manifest.md). Put repositories under `tools/repos/` and portable binaries under `tools/bin/` when useful. These are conventions, not folders that must be populated.

Do not install scanners or clone large lists merely because they are popular. Start with the smallest tool needed for the current experiment. Prefer existing capabilities and the Python standard library for local bookkeeping.

## Workspace-local Python environment

Explain these commands before execution and obtain any required session approval for running scripts. Dependency installation itself is preauthorized when used for an authored script inside this environment.

```powershell
python --version
python -m venv .venv
.\.venv\Scripts\python.exe -m pip --version
.\.venv\Scripts\python.exe -m pip install <reviewed-package-and-version>
```

The angle-bracket package argument is an operator input, not a valid literal command. Prefer invoking the venv interpreter directly; activation is optional and does not require changing PowerShell execution policy. Record exact package versions after installation. Do not assume the command named `python` is the expected interpreter; inspect its version and path first.

## Python 3.14 compatibility

Check each dependency's current supported Python versions and Windows wheel availability. A package being installable does not prove runtime compatibility. Some native dependencies lag a new interpreter, and source builds may require compilers, system headers, Rust, or Windows SDKs.

If a dependency fails: determine whether it is optional; look for a compatible official release or a pure-Python/standard-library alternative; inspect documented support; and retain a useful manual path. Installing another interpreter or build tool changes the system and needs owner confirmation. Do not silently downgrade the global interpreter or use machine-wide pip to work around a venv problem.

Package installation can execute build code. Prefer known publishers and compatible wheels when practical. Permission to install a Python dependency does not authorize an unrelated repository's bootstrap script, an opaque binary installer, or elevation.

## Command plans

State the command as it will run, working directory, input/output paths, expected network calls, credentials used, target request budget, timeouts, retry policy, and stop condition. Make the effect reviewable. A bounded approval can cover a sequence; record it so a resumed agent does not ask again or expand it.

Use PowerShell literal paths for file operations. Avoid mixing shells for recursive operations, building commands through string concatenation, or weakening execution policy. Resolve destinations inside the intended workspace before writes or cleanup. Keep downloads separate from evidence so deleting a tool cache cannot delete research artifacts.

## MCP and plugin suggestions

An existing browser connector can help read public briefs; a documentation connector can fetch vendor references; a repository connector can inspect patches. Recommend additions only when a concrete task needs them. State publisher, requested permissions, data exposure, authentication requirements, and a manual alternative. Let the owner add or enable them. Do not invent server names, endpoints, or settings that have not been verified in official documentation.

No MCP server, API key, browser extension, WSL, Docker, system scanner, or external package is required by the included local helper scripts.
