# Engagement Workflow

## Phase 0: Intake

Create an engagement under `engagements/<slug>/`. Record the owner's objective, current mode, program/lab identity, source material, available accounts, and what is already approved. Use the [state template](../templates/state.md). Missing information should become a precise dependency, not a reason to abandon independent research.

Select a narrow question such as “Does share revocation apply to queued exports?” rather than “Find everything.” Define an artifact-level goal: a validated claim, an applicability decision, or a disproven hypothesis with a lesson.

## Phase 1: Brief and scope

Read the current program policy. Record exact assets and exclusions in [scope.json](../templates/scope.json). This JSON is documentation only; no included script enforces URL matching. The operator and agent must still check destinations and method restrictions.

For a live plan, document the asset, method, identities, data, permitted techniques, request budget, concurrency, and stop conditions. If the program specifies a limit, comply with it; if none is stated, propose a small conservative budget for owner approval rather than inventing a platform-wide default.

## Phase 2: Model normal behavior

Walk through legitimate feature documentation and already available observations. Draw actors, objects, authorization decisions, and state transitions. Identify what the product promises. The promised invariant matters more than the name of a vulnerability category.

For source access, map relevant entrypoints, middleware, service functions, queries, storage operations, and background jobs. For black-box work, mark invisible components as inferred. Keep a feature map with role, action, object, state, and expected result.

## Phase 3: Research and rank

Generate a small hypothesis set using [creative reasoning](CREATIVE-REASONING.md). Add relevant CVEs only after identifying a plausible product/component relationship. Read primary documentation and original write-ups. Record confidence, prerequisites, information gain, effort, and the next decisive observation.

Prioritize the experiment with the best expected learning or evidence gain under current constraints. A quick way to eliminate a major false premise may be more valuable than another broad scan.

## Phase 4: Prepare execution

Inspect tool acquisition and execution needs. Show the exact command plan before running scripts/tools as required by the owner's preferences. Plan output destinations, timeouts, retries, maximum requests, and redaction. Confirm that browser automation will not silently create records, send invitations, purchase items, or follow unscoped hosts.

Use [experiment.md](../templates/experiment.md). Include a baseline, one meaningful variable, a negative control, and alternative explanations. For high-risk mechanisms, prefer local replicas, supplied source, protocol traces, or patch analysis.

## Phase 5: Run and observe

Execute only the approved bounded experiment. Record UTC timestamps for evidence, the user's Asia/Saigon time when scheduling matters, tool versions, identity labels, environment, exact requests, and relevant state before/after. Update request consumption; failed requests and retries count too.

If scope changes, a rate-limit response appears, the tested environment becomes unstable, unrelated sensitive data appears, or the next step exceeds the plan, stop that activity and preserve minimal evidence. Do not convert an unsuccessful test into a larger uncontrolled campaign.

## Phase 6: Validate and report

Apply [validation](VALIDATION.md). Separate a local mechanism from target evidence and distinguish observed impact from hypothetical extensions. A report needs a violated invariant, reproducible steps, affected context, and evidence references. Prepare it for owner review using [finding.md](../templates/finding.md).

If the result is inconclusive or disproven, record why and what observation would change the conclusion. Non-findings are useful when they prevent repeated false positives.

## Phase 7: Learn and hand off

Create a [lesson](../templates/lesson.md), a [control observation](../templates/control-observation.md), and a detection hypothesis where the evidence supports them. Save a checkpoint with consumed budget, approvals, artifacts, pending actions, and the next experiment. An agent should resume from this checkpoint, not reinterpret a stale chat as an unlimited instruction.
