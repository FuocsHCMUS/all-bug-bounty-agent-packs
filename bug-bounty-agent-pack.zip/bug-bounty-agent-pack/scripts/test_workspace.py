"""Local tests for filesystem behavior; no target or network interactions."""

import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from workspace import hash_evidence, init_engagement, validate_slug


class WorkspaceTests(unittest.TestCase):
    def test_initialization_fills_records_without_inventing_scope(self):
        with tempfile.TemporaryDirectory() as directory:
            target = init_engagement("learning-lab", Path(directory))
            scope = json.loads((target / "scope.json").read_text(encoding="utf-8"))
            self.assertEqual(scope["engagement"], "learning-lab")
            self.assertEqual(scope["mode"], "DISCOVER")
            self.assertFalse(scope["live_testing_ready"])
            self.assertEqual(scope["in_scope_assets"], [])
            self.assertEqual(scope["approved_execution_plans"], [])
            self.assertTrue((target / "evidence/raw").is_dir())
            self.assertNotIn("{{", (target / "state.md").read_text(encoding="utf-8"))

    def test_existing_notebook_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            target = init_engagement("existing", base)
            marker = target / "state.md"
            marker.write_text("Owner's private notes", encoding="utf-8")
            with self.assertRaises(FileExistsError):
                init_engagement("existing", base)
            self.assertEqual(marker.read_text(encoding="utf-8"), "Owner's private notes")

    def test_slug_rejects_traversal_reserved_names_and_absolute_paths(self):
        for slug in ("../escape", "a/b", "a\\b", "C:\\temp", "CON", "con", "lpt9", "a.", "-a", "a-", "", "a" * 65):
            with self.subTest(slug=slug), self.assertRaises(ValueError):
                validate_slug(slug)
        validate_slug("lab-14")

    def test_hashes_known_bytes_and_does_not_write(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "nested").mkdir()
            (root / "a.txt").write_bytes(b"abc")
            (root / "nested/b.bin").write_bytes(b"\x00\xff")
            before = sorted(p.relative_to(root).as_posix() for p in root.rglob("*"))
            result = hash_evidence(root)
            by_path = {item["path"]: item for item in result["files"]}
            self.assertEqual(by_path["a.txt"]["sha256"], hashlib.sha256(b"abc").hexdigest())
            self.assertEqual(by_path["nested/b.bin"]["bytes"], 2)
            self.assertEqual(before, sorted(p.relative_to(root).as_posix() for p in root.rglob("*")))

    def test_single_file_empty_directory_and_missing_target(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.assertEqual(hash_evidence(root)["files"], [])
            file = root / "one"
            file.write_bytes(b"x")
            self.assertEqual(hash_evidence(file)["files"][0]["path"], "one")
            with self.assertRaises(FileNotFoundError):
                hash_evidence(root / "missing")


if __name__ == "__main__":
    unittest.main()
