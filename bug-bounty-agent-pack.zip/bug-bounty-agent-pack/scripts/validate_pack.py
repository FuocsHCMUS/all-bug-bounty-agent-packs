"""Validate this pack's local structure; never fetch links or contact targets."""

from __future__ import annotations

import ast
import json
from pathlib import Path
import re
from urllib.parse import unquote, urlsplit


ROOT = Path(__file__).resolve().parents[1]
REQUIRED = (
    "README.md", "AGENTS.md", "SKILL.md", "START-HERE.md", "SOURCES.md",
    "adapters/SETUP.md", ".agents/skills/bug-bounty-research/SKILL.md",
    ".cursor/rules/bug-bounty.mdc", ".clinerules/01-bug-bounty.md",
    ".opencode/agents/bug-bounty-research.md", "prompts/MASTER-PROMPT.md",
    "references/INDEX.md", "templates/INDEX.md", "templates/scope.json",
    "examples/harbor-notes/README.md", "evals/SCENARIOS.md",
    "scripts/workspace.py", "scripts/test_workspace.py",
)


def validate(root: Path = ROOT) -> tuple[list[str], dict[str, int]]:
    errors: list[str] = []
    for name in REQUIRED:
        if not (root / name).is_file():
            errors.append(f"Missing required file: {name}")

    files = sorted(
        p for p in root.rglob("*")
        if p.is_file() and not any(part in {".venv", "tools", "engagements", "__pycache__", ".git"}
                                   for part in p.relative_to(root).parts)
    )
    links_checked = 0
    words = 0
    markdown_count = 0
    for path in files:
        if path.suffix in {".md", ".mdc", ".example"}:
            markdown_count += 1
            body = path.read_text(encoding="utf-8-sig")
            words += len(body.split())
            for match in re.finditer(r"\[[^\]]*\]\(([^\s)]+)(?:\s+\"[^\"]*\")?\)", body):
                target = match.group(1).strip("<>")
                parsed = urlsplit(target)
                if parsed.scheme or target.startswith("#"):
                    continue
                local = unquote(parsed.path)
                if not local:
                    continue
                links_checked += 1
                resolved = (path.parent / local).resolve()
                if not resolved.is_relative_to(root.resolve()):
                    errors.append(f"Local link escapes pack: {path.relative_to(root)} -> {target}")
                elif not resolved.exists():
                    errors.append(f"Broken link: {path.relative_to(root)} -> {target}")

            if path.name == "SKILL.md":
                front = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|$)", body, re.S)
                if not front:
                    errors.append(f"Missing skill frontmatter: {path.relative_to(root)}")
                else:
                    name = re.search(r"^name:\s*([a-z0-9-]+)\s*$", front.group(1), re.M)
                    description = re.search(r"^description:\s*(.+)$", front.group(1), re.M)
                    if not name or len(name.group(1)) > 64 or not description:
                        errors.append(f"Invalid skill metadata: {path.relative_to(root)}")
                    if description and len(description.group(1)) > 1024:
                        errors.append(f"Skill description too long: {path.relative_to(root)}")
                    if path.parent != root and name and name.group(1) != path.parent.name:
                        errors.append(f"Skill folder/name mismatch: {path.relative_to(root)}")
        elif path.suffix == ".json":
            try:
                json.loads(path.read_text(encoding="utf-8"))
            except ValueError as error:
                errors.append(f"Invalid JSON in {path.relative_to(root)}: {error}")
        elif path.suffix == ".py":
            try:
                ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            except SyntaxError as error:
                errors.append(f"Invalid Python in {path.relative_to(root)}: {error}")

    scope_path = root / "templates/scope.json"
    if scope_path.exists():
        try:
            scope = json.loads(scope_path.read_text(encoding="utf-8"))
            if scope.get("mode") != "DISCOVER" or scope.get("live_testing_ready") is not False:
                errors.append("Scope template must begin in DISCOVER with live_testing_ready false.")
            if scope.get("in_scope_assets") or scope.get("approved_execution_plans"):
                errors.append("Scope template must not invent assets or execution approvals.")
        except ValueError:
            pass  # Already reported above.

    cursor_path = root / ".cursor/rules/bug-bounty.mdc"
    if cursor_path.exists() and "alwaysApply: true" not in cursor_path.read_text(encoding="utf-8"):
        errors.append("Cursor loader must have its documented activation field.")

    return errors, {"files": len(files), "markdown_files": markdown_count,
                    "local_links_checked": links_checked, "markdown_words": words}


def main() -> int:
    errors, stats = validate()
    print(json.dumps({"status": "PASS" if not errors else "FAIL", "stats": stats,
                      "errors": errors}, indent=2))
    return int(bool(errors))


if __name__ == "__main__":
    raise SystemExit(main())
