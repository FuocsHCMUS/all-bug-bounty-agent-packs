"""Local engagement scaffolding and evidence hashing. No network operations."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys


PACK_ROOT = Path(__file__).resolve().parents[1]
INITIAL_TEMPLATES = (
    "program.md", "scope.json", "state.md", "hypotheses.md",
    "activity-log.md", "source-cards.md", "tool-manifest.md", "evidence-index.md",
)
DIRECTORIES = (
    "experiments", "evidence/raw", "evidence/redacted", "findings",
    "lessons", "detections", "controls", "handoffs",
)
RESERVED_WINDOWS_NAMES = {
    "con", "prn", "aux", "nul",
    *(f"com{i}" for i in range(1, 10)),
    *(f"lpt{i}" for i in range(1, 10)),
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def validate_slug(slug: str) -> None:
    if not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?", slug):
        raise ValueError("Use a 1-64 character lowercase slug with letters, digits, and internal hyphens.")
    if slug in RESERVED_WINDOWS_NAMES:
        raise ValueError("The engagement name is reserved by Windows.")


def init_engagement(slug: str, base: Path | None = None) -> Path:
    """Create a fresh local notebook; never overwrite an existing engagement."""
    validate_slug(slug)
    requested_base = base if base is not None else PACK_ROOT / "engagements"
    if requested_base.is_symlink():
        raise ValueError("The engagement base must not be a symbolic link.")
    base_path = requested_base.resolve()
    if base is None and not base_path.is_relative_to(PACK_ROOT):
        raise ValueError("The default engagement base must stay inside this pack.")
    destination = base_path / slug
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f"Refusing to overwrite existing engagement: {destination}")

    # Read every source before creating the destination, so missing templates
    # cannot leave a misleading partly initialized notebook.
    created = utc_now()
    rendered: dict[str, str] = {}
    for name in INITIAL_TEMPLATES:
        source = (PACK_ROOT / "templates" / name).read_text(encoding="utf-8")
        rendered[name] = source.replace("{{ENGAGEMENT}}", slug).replace("{{CREATED_UTC}}", created)
    json.loads(rendered["scope.json"])

    base_path.mkdir(parents=True, exist_ok=True)
    destination.mkdir()  # Exclusive creation also handles concurrent callers.
    for directory in DIRECTORIES:
        (destination / directory).mkdir(parents=True, exist_ok=True)
    for name, content in rendered.items():
        (destination / name).write_text(content, encoding="utf-8", newline="\n")
    return destination


def hash_evidence(target: Path) -> dict[str, object]:
    """Read regular local files and return a SHA-256 manifest without writing."""
    if target.is_symlink():
        raise ValueError("Refusing to hash a symbolic-link target.")
    root = target.resolve(strict=True)
    if root.is_file():
        paths = [root]
        relative_base = root.parent
    elif root.is_dir():
        entries = sorted(root.rglob("*"), key=lambda p: p.as_posix())
        if any(path.is_symlink() for path in entries):
            raise ValueError("Evidence directories must not contain symbolic links.")
        paths = [path for path in entries if path.is_file()]
        relative_base = root
    else:
        raise ValueError("Evidence target must be a regular file or directory.")

    files: list[dict[str, object]] = []
    for path in paths:
        digest = hashlib.sha256()
        size = 0
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                size += len(chunk)
                digest.update(chunk)
        files.append({
            "path": path.relative_to(relative_base).as_posix(),
            "bytes": size,
            "sha256": digest.hexdigest(),
        })
    return {"generated_utc": utc_now(), "root": str(root), "files": files}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    init_parser = sub.add_parser("init", help="Create engagements/<slug> without overwriting.")
    init_parser.add_argument("slug")
    hash_parser = sub.add_parser("hash", help="Print a read-only SHA-256 evidence manifest.")
    hash_parser.add_argument("path", type=Path)
    args = parser.parse_args()
    try:
        if args.command == "init":
            print(init_engagement(args.slug))
        else:
            print(json.dumps(hash_evidence(args.path), ensure_ascii=True, indent=2))
    except (OSError, ValueError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
