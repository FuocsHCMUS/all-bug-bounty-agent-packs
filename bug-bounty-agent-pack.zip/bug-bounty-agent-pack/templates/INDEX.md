# Artifact Templates

Copy only templates needed for a real session. Template fields are intentionally blank/unknown; they are not facts. Replace `{{ENGAGEMENT}}` and `{{CREATED_UTC}}` during initialization. Do not replace unknowns with invented data.

| Template | Purpose |
|---|---|
| [program.md](program.md) | Current program brief and scope interpretation |
| [scope.json](scope.json) | Structured planning record; no enforcement engine |
| [state.md](state.md) | Resume checkpoint and approvals |
| [hypotheses.md](hypotheses.md) | Ranked hypotheses and outcomes |
| [activity-log.md](activity-log.md) | Planned/executed actions and budget |
| [source-cards.md](source-cards.md) | Research provenance and applicability |
| [tool-manifest.md](tool-manifest.md) | Acquisitions, dependencies, and execution |
| [experiment.md](experiment.md) | Baseline, controlled variable, controls, stop conditions |
| [cve-applicability.md](cve-applicability.md) | Prerequisite-by-prerequisite CVE assessment |
| [evidence-index.md](evidence-index.md) | Private/raw and redacted evidence links |
| [finding.md](finding.md) | Owner-reviewable triage report |
| [control-observation.md](control-observation.md) | Strength/gap/risk with bounded coverage |
| [lesson.md](lesson.md) | Foundation-to-mechanism learning note |
| [detection-note.md](detection-note.md) | Telemetry and SOC detection hypothesis |
| [handoff.md](handoff.md) | Cross-session or cross-agent transfer |
| [execution-request.md](execution-request.md) | Concrete script/tool confirmation request |

The local initializer copies the first seven working records plus an evidence index. It creates directories for the remaining records without populating speculative findings or CVEs.
