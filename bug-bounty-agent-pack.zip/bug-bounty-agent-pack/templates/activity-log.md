# Activity Log: {{ENGAGEMENT}}

Created: {{CREATED_UTC}}

| UTC time | Action ID | PLANNED/EXECUTED/FAILED/CANCELLED | Mode | Command or action | Approval/plan ID | Destination/output | Requests incl. retries | Result/evidence |
|---|---|---|---|---|---|---|---|---|

## Budget accounting

Authorized maximum, consumed requests including failures/retries, remaining budget, concurrency, rate, and source:

## Interruptions and stop conditions

Record rate limiting, scope changes, instability, unintended data, denied actions, and why activity stopped. A planned or cancelled action is never counted as an observed result.
