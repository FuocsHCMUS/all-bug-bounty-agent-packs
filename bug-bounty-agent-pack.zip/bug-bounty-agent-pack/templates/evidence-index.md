# Evidence Index: {{ENGAGEMENT}}

Created: {{CREATED_UTC}}

| Evidence ID | UTC time/source | Identity/context | Description | Raw private path | Redacted path | SHA-256 if recorded | Sensitivity | Claim supported/limits |
|---|---|---|---|---|---|---|---|---|

Keep secrets out of this index. Hashes identify recorded bytes; they do not establish truth or trusted time. Redaction must preserve the property being demonstrated without exposing unrelated data.
