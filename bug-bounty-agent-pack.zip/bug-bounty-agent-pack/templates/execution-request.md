# Concrete Execution Request

- Task/experiment ID and purpose:
- Already approved actions and exact limits:
- New command/action needing confirmation:
- Working directory:
- Exact command text:
- Inputs and created/modified files:
- Network destinations and target scope source:
- Credential/account labels used:
- Maximum requests, rate, concurrency, retries, and duration:
- Expected output and success/failure criteria:
- Side effects and reversibility:
- Stop conditions:
- Why an existing/manual alternative is insufficient:
- Independent work continuing while this is pending:

Request a decision about this concrete action. Do not treat a delayed answer as consent or enlarge an existing approval.
