# Experiment

- Experiment/hypothesis IDs: UNKNOWN
- Mode and current program/lab: UNKNOWN
- Evidence state before test: HYPOTHESIS
- Invariant and falsifiable claim: UNKNOWN
- Asset/method policy coverage and source/time: UNKNOWN
- Exact owned identities, roles, tenants, objects: UNKNOWN
- Prerequisites/configuration: UNKNOWN

## Design

- Legitimate baseline:
- Single relevant factor changed:
- Expected result if true:
- Expected result if false:
- Positive control:
- Negative control:
- Alternative explanations and distinguishing observations:

## Execution plan

- Exact commands/actions and working directory:
- Approval/plan ID or pending confirmation:
- Inputs/output paths:
- Network destinations and redirect boundaries:
- Credentials referenced by label, never copied:
- Maximum requests/rate/concurrency/retries/time:
- Stop conditions and reversal/cleanup of test-owned changes:

## Observations

Timestamp, exact action, evidence IDs, state before/after, request consumption, and anomalies:

## Decision

Supported claim, evidence state, confidence, limitations, next decisive action, and lesson link:
