# Finding: Specific Affected Workflow and Violated Property

- Finding ID and validation state: UNKNOWN
- Program/asset and policy source/time: UNKNOWN
- Tested date/environment: UNKNOWN
- Proposed severity and convention: UNKNOWN
- Evidence index: UNKNOWN

## Summary

Starting actor/privilege, action, protected resource, violated invariant, and demonstrated effect:

## Prerequisites

Roles/tenants, synthetic object creation, feature/configuration, timing, and required interaction:

## Reproduction

1. Establish the legitimate baseline with labeled owned identities.
2. Perform the minimal recorded sequence using the triager's own sessions.
3. Show the actual result and link evidence.

## Expected versus actual

Expected permission/state rule and observed behavior:

## Impact

Demonstrated effect, affected context, prerequisites, confidence, and clearly separated untested extensions:

## Evidence

Minimal redacted requests/responses/state changes, timestamps, request IDs, and attachment mapping:

## Root cause and remediation

Source-confirmed or inferred cause, invariant to restore, immediate containment, durable repair, and tradeoffs:

## Retest criteria

Original sequence, expected corrected result, positive control, and relevant adjacent state/path:

## Limitations and submission status

Unknown reach/novelty/duplicates, untested paths, and owner-review status. Default: DRAFT — NOT SUBMITTED.
