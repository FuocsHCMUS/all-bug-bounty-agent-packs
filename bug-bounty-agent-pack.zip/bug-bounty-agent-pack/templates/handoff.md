# Research Handoff

- Engagement/objective/mode: UNKNOWN
- Handoff time and authoring agent: UNKNOWN
- Current policy source/time: UNKNOWN
- Current evidence state: UNKNOWN

## Read these artifacts first

Exact paths to state, scope, hypotheses, activity log, current experiment, evidence index, findings, and lessons:

## Verified completed versus planned work

Executed actions/results, planned actions, closed ideas, current confounders, and evidence limits:

## Approvals and resources

Exact approved/denied actions, limits, request budget spent/remaining, required account labels, tool versions, and sessions needing refresh. Do not copy secrets.

## Next task

Smallest discriminating action, prerequisites, expected output, pending owner decisions, and independent work available meanwhile:
