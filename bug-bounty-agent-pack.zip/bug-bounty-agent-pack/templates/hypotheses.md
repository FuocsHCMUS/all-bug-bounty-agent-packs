# Hypothesis Ledger: {{ENGAGEMENT}}

Created: {{CREATED_UTC}}

| ID | Invariant and suspected violation | Motivation/evidence | Prerequisites | State/confidence | Impact if true | Next decisive observation | Outcome |
|---|---|---|---|---|---|---|---|

## Ranking rationale

Compare information gain, prerequisite confidence, permitted testability, effort, and plausible impact. Scores, if used, are heuristic rather than probabilities.

## Alternative explanations

For each promoted hypothesis record at least two plausible alternatives and how a controlled observation distinguishes them.

## Closed ideas

Keep disproven or deferred ideas with evidence and reopening conditions so a later agent does not repeat them without reason.
