# Lesson

- Lesson ID and linked result: UNKNOWN
- Learning goal: UNKNOWN
- Prerequisite knowledge checked: UNKNOWN

## Vocabulary and mental model

Define terms, distinguish related concepts, and explain the analogy's limits:

## Normal data flow and invariant

Actors, request, decisions, state changes, diagram, and protected property:

## Mechanism and evidence

Experiment, observation, root cause, alternative explanations, and uncertainty:

## Repair and defensive perspective

How the invariant is restored, regression checks, required logs, conceptual detection, and false positives:

## Local exercise

Synthetic setup, task, prediction question, expected result, and explanation:

## Retrieval practice

1. Explain the central concept in your own words.
2. Identify what would falsify the conclusion.
3. Apply the invariant to a different feature.

## Progress

Misconception corrected, remaining question, glossary additions, and next concept:
