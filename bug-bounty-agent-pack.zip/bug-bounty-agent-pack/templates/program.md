# Program Brief: {{ENGAGEMENT}}

Created: {{CREATED_UTC}}

- Program/lab name: UNKNOWN
- Official page and operator: UNKNOWN
- Platform and program type: UNKNOWN
- Current brief retrieval time and access status: UNKNOWN
- Saved brief path/hash: UNKNOWN
- Owner learning/research objective: UNKNOWN
- Eligibility/account requirements: UNKNOWN
- Bounty availability: UNKNOWN; do not assume payment

## Scope

| Exact asset/pattern | Asset type | Explicit source | Restrictions | Interpretation/unknowns |
|---|---|---|---|---|

## Exclusions and method conditions

- Excluded assets/classes: UNKNOWN
- Automation/rate/concurrency conditions: UNKNOWN
- Required test identifier/header: UNKNOWN
- Data/account restrictions: UNKNOWN
- Third-party dependencies and redirect boundaries: UNKNOWN
- Reporting and disclosure requirements: UNKNOWN

## First feature and prerequisites

Normal flow, required roles/tenants, synthetic objects, expected invariant, and the first useful learning question:

## Policy refresh

| Retrieval time | Source | Material change | Affected tests | Decision |
|---|---|---|---|---|
