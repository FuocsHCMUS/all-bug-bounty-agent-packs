# Source Cards: {{ENGAGEMENT}}

Created: {{CREATED_UTC}}

## Source card

- Source ID: UNKNOWN
- Title/author/publisher: UNKNOWN
- Original URL or local path: UNKNOWN
- Published/updated/retrieved dates: UNKNOWN
- Access status: UNKNOWN
- Primary source or discovery lead: UNKNOWN
- Product/version/configuration/context: UNKNOWN
- Claim supported: UNKNOWN
- Short paraphrase and mechanism: UNKNOWN
- Preconditions and limitations: UNKNOWN
- Conflicting sources: UNKNOWN
- Relevance to hypothesis/experiment: UNKNOWN
- Next discriminating check: UNKNOWN

Keep quotations short. Do not treat a search snippet or an inaccessible page as read evidence.
