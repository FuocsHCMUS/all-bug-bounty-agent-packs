# Session State: {{ENGAGEMENT}}

Created: {{CREATED_UTC}}

- Objective: UNKNOWN
- Mode: DISCOVER
- Latest checkpoint UTC: UNKNOWN
- Current policy source/retrieval: UNKNOWN
- Current hypothesis and evidence state: UNKNOWN
- Current account/tenant labels: UNKNOWN; no secrets here
- Request budget spent/remaining: UNKNOWN

## Approvals and owner decisions

| Decision ID | Exact approved/denied action | Program coverage | Limits | Owner instruction/time | Still applicable? |
|---|---|---|---|---|---|

Portable acquisition and local-venv pip preferences are in root `AGENTS.md`. Record execution approvals separately; silence is not approval.

## Verified completed work

Link artifacts and executed activity records. Keep planned work in the next section.

## Next discriminating action

Question, prerequisite, command plan if relevant, expected information gain, and stop condition:

## Pending decisions and independent work

What needs the owner's input, why it matters, and what can continue without it:

## Context for resumption

Changed scope, expired sessions, negative results, confounders, tool availability, and assumptions needing refresh:
